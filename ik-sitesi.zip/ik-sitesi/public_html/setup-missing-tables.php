<?php
// Setup Missing Tables - Direct MySQL execution
$host = 'localhost';
$dbname = 'u978874874_ik';
$username = 'u978874874_ik';
$password = 'Szb2013@+-!';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
    
    echo "✅ Database connected\n";
    
    // 1. Create work_settings table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS work_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            monthly_hours_limit INT DEFAULT 225,
            weekly_hours_limit INT DEFAULT 45,
            daily_hours_limit INT DEFAULT 11,
            overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
            holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
            is_automatic_schedule TINYINT(1) DEFAULT 1,
            hourly_wage DECIMAL(10,2) DEFAULT 50.00,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_company_id (company_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
    
    // Insert default work settings
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM work_settings WHERE company_id = 1");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $pdo->exec("
            INSERT INTO work_settings (company_id, monthly_hours_limit, weekly_hours_limit, daily_hours_limit, overtime_multiplier, holiday_multiplier, hourly_wage)
            VALUES (1, 225, 45, 11, 1.50, 2.00, 50.00)
        ");
        echo "✅ work_settings table created and populated\n";
    } else {
        echo "✅ work_settings already exists\n";
    }
    
    // 2. Create public_holidays table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS public_holidays (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            date DATE NOT NULL,
            year INT NOT NULL,
            type VARCHAR(50) DEFAULT 'national',
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_date (date),
            INDEX idx_year (year)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
    
    // Insert 2025 holidays if not exist
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM public_holidays WHERE year = 2025");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $holidays = [
            ['Yılbaşı', '2025-01-01'],
            ['Ulusal Egemenlik ve Çocuk Bayramı', '2025-04-23'],
            ['Emek ve Dayanışma Günü', '2025-05-01'],
            ['Atatürk\'ü Anma, Gençlik ve Spor Bayramı', '2025-05-19'],
            ['Demokrasi ve Milli Birlik Günü', '2025-07-15'],
            ['Zafer Bayramı', '2025-08-30'],
            ['Cumhuriyet Bayramı', '2025-10-29'],
            ['Ramazan Bayramı 1. Gün', '2025-03-31'],
            ['Ramazan Bayramı 2. Gün', '2025-04-01'],
            ['Ramazan Bayramı 3. Gün', '2025-04-02'],
            ['Kurban Bayramı 1. Gün', '2025-06-07'],
            ['Kurban Bayramı 2. Gün', '2025-06-08'],
            ['Kurban Bayramı 3. Gün', '2025-06-09'],
            ['Kurban Bayramı 4. Gün', '2025-06-10']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO public_holidays (name, date, year, type) VALUES (?, ?, 2025, 'national')");
        foreach ($holidays as $holiday) {
            $stmt->execute($holiday);
        }
        echo "✅ public_holidays table created and populated\n";
    } else {
        echo "✅ public_holidays already exists\n";
    }
    
    // 3. Create attendance_activities table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS attendance_activities (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            name VARCHAR(255) NOT NULL,
            activity_type ENUM('checkin', 'checkout', 'break_start', 'break_end', 'meal_start', 'meal_end', 'work_in', 'work_out') NOT NULL,
            description TEXT,
            is_paid TINYINT(1) DEFAULT 1,
            color_code VARCHAR(7) DEFAULT '#007bff',
            max_duration_minutes INT DEFAULT NULL,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_company_id (company_id),
            INDEX idx_type (activity_type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
    
    // Insert default activities
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance_activities WHERE company_id = 1");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $activities = [
            [1, 'İş Giriş', 'work_in', 'Günlük iş başlangıcı', 1, '#28a745'],
            [1, 'İş Çıkış', 'work_out', 'Günlük iş bitişi', 1, '#dc3545'],
            [1, 'Öğle Yemeği Başlangıç', 'meal_start', 'Öğle yemeği molası başlangıcı', 0, '#ffc107'],
            [1, 'Öğle Yemeği Bitiş', 'meal_end', 'Öğle yemeği molası bitişi', 0, '#ffc107'],
            [1, 'Çay Molası Başlangıç', 'break_start', 'Çay/kahve molası başlangıcı', 0, '#17a2b8'],
            [1, 'Çay Molası Bitiş', 'break_end', 'Çay/kahve molası bitişi', 0, '#17a2b8']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO attendance_activities (company_id, name, activity_type, description, is_paid, color_code) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($activities as $activity) {
            $stmt->execute($activity);
        }
        echo "✅ attendance_activities table created and populated\n";
    } else {
        echo "✅ attendance_activities already exists\n";
    }
    
    // 4. Update qr_locations table if needed
    $stmt = $pdo->query("SHOW COLUMNS FROM qr_locations LIKE 'qr_code'");
    if ($stmt->rowCount() === 0) {
        $pdo->exec("ALTER TABLE qr_locations ADD COLUMN qr_code VARCHAR(100) UNIQUE");
        echo "✅ qr_locations.qr_code column added\n";
    }
    
    // 5. Check sessions table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sessions (
            session_id VARCHAR(128) PRIMARY KEY,
            session_data TEXT,
            session_time INT UNSIGNED NOT NULL,
            INDEX idx_time (session_time)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
    echo "✅ sessions table ready\n";
    
    echo "\n🎉 All tables setup completed successfully!\n";
    
} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>