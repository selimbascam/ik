<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>⚙️ Work Settings Database Setup</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Include holiday calculator
    require_once 'includes/holiday-calculator.php';
    
    // Create work_settings table
    $sql = "
    CREATE TABLE IF NOT EXISTS work_settings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        company_id INT NOT NULL,
        monthly_hours INT DEFAULT 225,
        weekly_hours INT DEFAULT 45,
        daily_max_hours INT DEFAULT 11,
        hourly_rate DECIMAL(10,2) DEFAULT 50.00,
        overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
        holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
        weekly_holiday INT DEFAULT 1,
        auto_schedule TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_company (company_id),
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    $conn->exec($sql);
    echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ work_settings table created successfully";
    echo "</div>";
    
    // Insert default settings for existing companies
    $stmt = $conn->query("SELECT id, company_name FROM companies ORDER BY id");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($companies as $company) {
        $stmt = $conn->prepare("
            INSERT IGNORE INTO work_settings 
            (company_id, monthly_hours, weekly_hours, daily_max_hours, hourly_rate, overtime_multiplier, holiday_multiplier, weekly_holiday, auto_schedule) 
            VALUES (?, 225, 45, 11, 50.00, 1.50, 2.00, 1, 1)
        ");
        $stmt->execute([$company['id']]);
        
        echo "<div style='background: #f8f9fa; padding: 8px; border-left: 4px solid #007bff; margin: 5px 0;'>";
        echo "🏢 Default settings added for: " . htmlspecialchars($company['company_name']);
        echo "</div>";
    }
    
    // Create enhanced public_holidays table
    $sql2 = "
    CREATE TABLE IF NOT EXISTS public_holidays (
        id INT PRIMARY KEY AUTO_INCREMENT,
        company_id INT NOT NULL,
        holiday_date DATE NOT NULL,
        holiday_name VARCHAR(255) NOT NULL,
        holiday_type ENUM('national', 'religious') DEFAULT 'national',
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_company_date (company_id, holiday_date),
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    $conn->exec($sql2);
    echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ public_holidays table created successfully";
    echo "</div>";
    
    // Auto-populate current year holidays using calculator
    $currentYear = date('Y');
    $nextYear = $currentYear + 1;
    
    foreach ($companies as $company) {
        // Populate current year
        $currentInserted = TurkishHolidayCalculator::populateHolidaysForYear($company['id'], $currentYear, $conn);
        
        // Populate next year
        $nextInserted = TurkishHolidayCalculator::populateHolidaysForYear($company['id'], $nextYear, $conn);
        
        echo "<div style='background: #fff3cd; padding: 8px; border-left: 4px solid #ffc107; margin: 5px 0;'>";
        echo "🎉 " . htmlspecialchars($company['company_name']) . ": ";
        echo "$currentYear ($currentInserted tatil) + $nextYear ($nextInserted tatil) eklendi";
        echo "</div>";
    }
    
    echo "<h2>✅ Setup Complete!</h2>";
    echo "<div style='background: #d1ecf1; padding: 20px; border-radius: 10px; margin: 20px 0;'>";
    echo "<h3>📊 Work Settings Features:</h3>";
    echo "<ul style='margin: 10px 0; padding-left: 20px;'>";
    echo "<li>✓ Aylık çalışma saati: 225 saat</li>";
    echo "<li>✓ Haftalık normal mesai: 45 saat</li>";
    echo "<li>✓ Günlük maksimum: 11 saat</li>";
    echo "<li>✓ Fazla mesai çarpanı: 1.5x</li>";
    echo "<li>✓ Tatil günü çarpanı: 2.0x</li>";
    echo "<li>✓ Haftalık izin: 1 gün</li>";
    echo "<li>✓ Otomatik planlama: Aktif</li>";
    echo "<li>✓ 2025 resmi tatilleri eklendi</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='admin/work-settings.php' style='background: #28a745; color: white; padding: 15px 25px; text-decoration: none; border-radius: 8px; font-weight: bold;'>⚙️ Çalışma Ayarları</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ SETUP ERROR</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>