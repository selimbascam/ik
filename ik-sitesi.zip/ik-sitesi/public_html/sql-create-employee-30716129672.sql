-- SQL script to create employee 30716129672
-- Run this directly in Hostinger database panel

-- First check if employee exists
SELECT * FROM employees WHERE employee_number = '30716129672';

-- If not exists, create the employee
INSERT INTO employees (
    employee_number, 
    first_name, 
    last_name, 
    password, 
    company_id, 
    status, 
    is_active,
    employee_code,
    email,
    phone,
    hire_date,
    role,
    monthly_salary
) VALUES (
    '30716129672',
    'Test',
    'Personel', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password_hash for '123456'
    1,
    'active',
    1,
    '30716129672',
    'test30716129672@example.com',
    '05551234567',
    CURDATE(),
    'employee',
    17000
);

-- Verify creation
SELECT employee_number, first_name, last_name, status, is_active FROM employees 
WHERE employee_number = '30716129672';

-- Show all employees after creation
SELECT employee_number, first_name, last_name FROM employees 
ORDER BY id;