<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔐 Kapsamlı Sistem Güvenlik ve Kod Kalitesi Düzeltmesi</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>1. Kritik Güvenlik Sorunlarının Analizi</h3>";
    
    $securityIssues = [
        'password_hashing' => [
            'title' => 'Şifre Hash Sistemi',
            'description' => 'Düz metin şifre karşılaştırmaları',
            'files' => ['auth/company-login.php', 'auth/employee-login.php', 'quick-*.php'],
            'risk' => 'YÜKSEK',
            'status' => 'DÜZELTME GEREKLİ'
        ],
        'sql_injection' => [
            'title' => 'SQL Injection Koruması',
            'description' => 'Prepared statement eksiklikleri',
            'files' => ['Çoğu PHP dosyası'],
            'risk' => 'YÜKSEK',
            'status' => 'DÜZELTME GEREKLİ'
        ],
        'session_security' => [
            'title' => 'Session Güvenliği',
            'description' => 'Session hijacking koruması eksik',
            'files' => ['includes/config.php', 'auth/*.php'],
            'risk' => 'ORTA',
            'status' => 'İYİLEŞTİRME GEREKLİ'
        ],
        'input_validation' => [
            'title' => 'Girdi Doğrulama',
            'description' => 'XSS ve CSRF koruması eksik',
            'files' => ['Form işleyen tüm dosyalar'],
            'risk' => 'ORTA',
            'status' => 'STANDARTLAŞTIRMA GEREKLİ'
        ]
    ];
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Güvenlik Sorunu</th><th>Açıklama</th><th>Risk Seviyesi</th><th>Durum</th></tr>";
    
    foreach ($securityIssues as $key => $issue) {
        $riskColor = $issue['risk'] === 'YÜKSEK' ? '#ffebee' : '#fff3e0';
        echo "<tr style='background: $riskColor;'>";
        echo "<td><strong>" . $issue['title'] . "</strong></td>";
        echo "<td>" . $issue['description'] . "</td>";
        echo "<td>" . $issue['risk'] . "</td>";
        echo "<td>" . $issue['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>2. Password Hashing Sisteminin Modernizasyonu</h3>";
    
    // Check current password storage
    $stmt = $conn->query("
        SELECT COUNT(*) as total,
               SUM(CASE WHEN password LIKE '$2y$%' THEN 1 ELSE 0 END) as hashed,
               SUM(CASE WHEN LENGTH(password) < 20 THEN 1 ELSE 0 END) as plain_text
        FROM employees 
        WHERE password IS NOT NULL
    ");
    $passwordStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h4>Mevcut Şifre Durumu:</h4>";
    echo "<ul>";
    echo "<li>Toplam personel şifresi: " . $passwordStats['total'] . "</li>";
    echo "<li>Hash'lenmiş şifreler: " . $passwordStats['hashed'] . "</li>";
    echo "<li>Düz metin şifreler: " . $passwordStats['plain_text'] . "</li>";
    echo "</ul>";
    
    if ($passwordStats['plain_text'] > 0) {
        echo "<p>⚠️ " . $passwordStats['plain_text'] . " adet düz metin şifre tespit edildi!</p>";
        
        // Fix plain text passwords
        echo "<h4>Düz Metin Şifreleri Hash'leme:</h4>";
        
        $stmt = $conn->query("
            SELECT id, employee_number, password 
            FROM employees 
            WHERE password IS NOT NULL AND LENGTH(password) < 20
            LIMIT 10
        ");
        $plainTextPasswords = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($plainTextPasswords as $employee) {
            try {
                $hashedPassword = password_hash($employee['password'], PASSWORD_ARGON2ID, [
                    'memory_cost' => 65536, // 64 MB
                    'time_cost' => 4,       // 4 iterations
                    'threads' => 3          // 3 threads
                ]);
                
                $updateStmt = $conn->prepare("
                    UPDATE employees 
                    SET password = ?, updated_at = NOW() 
                    WHERE id = ?
                ");
                $updateStmt->execute([$hashedPassword, $employee['id']]);
                
                echo "<p>✅ Employee " . $employee['employee_number'] . " şifresi hash'lendi</p>";
                
            } catch (Exception $e) {
                echo "<p>❌ Employee " . $employee['employee_number'] . " hash'lenemedi: " . $e->getMessage() . "</p>";
            }
        }
    } else {
        echo "<p>✅ Tüm şifreler hash'lenmiş durumda</p>";
    }
    
    // Check company passwords
    $stmt = $conn->query("
        SELECT COUNT(*) as total,
               SUM(CASE WHEN password LIKE '$2y$%' OR password LIKE '$argon2%' THEN 1 ELSE 0 END) as hashed,
               SUM(CASE WHEN LENGTH(password) < 20 THEN 1 ELSE 0 END) as plain_text
        FROM companies 
        WHERE password IS NOT NULL
    ");
    $companyPasswordStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h4>Şirket Şifre Durumu:</h4>";
    if ($companyPasswordStats['plain_text'] > 0) {
        $stmt = $conn->query("
            SELECT id, email, password 
            FROM companies 
            WHERE password IS NOT NULL AND LENGTH(password) < 20
        ");
        $plainCompanyPasswords = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($plainCompanyPasswords as $company) {
            try {
                $hashedPassword = password_hash($company['password'], PASSWORD_ARGON2ID, [
                    'memory_cost' => 65536,
                    'time_cost' => 4,
                    'threads' => 3
                ]);
                
                $updateStmt = $conn->prepare("
                    UPDATE companies 
                    SET password = ? 
                    WHERE id = ?
                ");
                $updateStmt->execute([$hashedPassword, $company['id']]);
                
                echo "<p>✅ Şirket " . $company['email'] . " şifresi hash'lendi</p>";
                
            } catch (Exception $e) {
                echo "<p>❌ Şirket " . $company['email'] . " hash'lenemedi: " . $e->getMessage() . "</p>";
            }
        }
    } else {
        echo "<p>✅ Tüm şirket şifreleri güvenli</p>";
    }
    
    echo "<h3>3. Session Güvenliği İyileştirmesi</h3>";
    
    // Check current session configuration
    echo "<h4>Mevcut Session Ayarları:</h4>";
    echo "<ul>";
    echo "<li>Session ID: " . session_id() . "</li>";
    echo "<li>Session Name: " . session_name() . "</li>";
    echo "<li>Cookie Lifetime: " . ini_get('session.cookie_lifetime') . " saniye</li>";
    echo "<li>GC MaxLifetime: " . ini_get('session.gc_maxlifetime') . " saniye</li>";
    echo "<li>Cookie Secure: " . (ini_get('session.cookie_secure') ? 'Evet' : 'Hayır') . "</li>";
    echo "<li>Cookie HTTPOnly: " . (ini_get('session.cookie_httponly') ? 'Evet' : 'Hayır') . "</li>";
    echo "</ul>";
    
    // Session security recommendations
    $sessionRecommendations = [
        'cookie_secure' => 'HTTPS bağlantılarda cookie güvenliği',
        'cookie_httponly' => 'JavaScript erişimi engelleme',
        'cookie_samesite' => 'CSRF saldırı koruması',
        'regenerate_id' => 'Session ID yenileme',
        'ip_validation' => 'IP adresi doğrulama'
    ];
    
    echo "<h4>Session Güvenlik Önerileri:</h4>";
    echo "<ul>";
    foreach ($sessionRecommendations as $feature => $description) {
        echo "<li><strong>$feature:</strong> $description</li>";
    }
    echo "</ul>";
    
    echo "<h3>4. Database Uyumluluğu ve Performans</h3>";
    
    // Check database compatibility issues
    $compatibilityChecks = [
        'charset' => "SHOW VARIABLES LIKE 'character_set%'",
        'collation' => "SHOW VARIABLES LIKE 'collation%'",
        'timezone' => "SELECT @@system_time_zone, @@time_zone",
        'version' => "SELECT VERSION()",
        'engines' => "SHOW ENGINES"
    ];
    
    echo "<h4>Veritabanı Uyumluluk Kontrolü:</h4>";
    
    foreach ($compatibilityChecks as $checkName => $query) {
        try {
            $stmt = $conn->query($query);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<h5>" . ucfirst($checkName) . ":</h5>";
            echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
            
            if (!empty($results)) {
                $headers = array_keys($results[0]);
                echo "<tr>";
                foreach ($headers as $header) {
                    echo "<th>" . htmlspecialchars($header) . "</th>";
                }
                echo "</tr>";
                
                foreach (array_slice($results, 0, 5) as $row) { // Show first 5 rows
                    echo "<tr>";
                    foreach ($row as $value) {
                        echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
                    }
                    echo "</tr>";
                }
            }
            echo "</table>";
            
        } catch (Exception $e) {
            echo "<p>⚠️ $checkName kontrolü yapılamadı: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<h3>5. Code Quality İyileştirmeleri</h3>";
    
    $codeQualityIssues = [
        'htmlspecialchars_null' => [
            'problem' => 'htmlspecialchars() null değerleri',
            'solution' => 'Null kontrolü ekle: htmlspecialchars($value ?? \'\')',
            'priority' => 'YÜKSEK'
        ],
        'pdo_mysqli_compatibility' => [
            'problem' => 'PDO/MySQLi karışık kullanım',
            'solution' => 'Database class ile standardizasyon',
            'priority' => 'ORTA'
        ],
        'hard_coded_values' => [
            'problem' => 'Hard-coded company_id, database credentials',
            'solution' => 'Config dosyası ve session kullanımı',
            'priority' => 'YÜKSEK'
        ],
        'error_handling' => [
            'problem' => 'Yetersiz hata yönetimi',
            'solution' => 'Try-catch blokları ve loglama',
            'priority' => 'ORTA'
        ]
    ];
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Problem</th><th>Çözüm</th><th>Öncelik</th></tr>";
    
    foreach ($codeQualityIssues as $issue) {
        $priorityColor = $issue['priority'] === 'YÜKSEK' ? '#ffebee' : '#e8f5e8';
        echo "<tr style='background: $priorityColor;'>";
        echo "<td>" . $issue['problem'] . "</td>";
        echo "<td>" . $issue['solution'] . "</td>";
        echo "<td>" . $issue['priority'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>6. Güvenlik Helper Functions</h3>";
    
    // Create security helper functions
    $securityHelpers = [
        'sanitize_input' => "
function sanitize_input(\$input, \$type = 'string') {
    if (\$input === null) return '';
    
    switch (\$type) {
        case 'int':
            return (int) \$input;
        case 'float':
            return (float) \$input;
        case 'email':
            return filter_var(\$input, FILTER_SANITIZE_EMAIL);
        case 'html':
            return htmlspecialchars(\$input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        default:
            return trim(strip_tags(\$input));
    }
}",
        'validate_csrf' => "
function validate_csrf(\$token) {
    return isset(\$_SESSION['csrf_token']) && hash_equals(\$_SESSION['csrf_token'], \$token);
}",
        'generate_csrf' => "
function generate_csrf() {
    if (!isset(\$_SESSION['csrf_token'])) {
        \$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return \$_SESSION['csrf_token'];
}",
        'secure_password_verify' => "
function secure_password_verify(\$password, \$hash) {
    // Prevent timing attacks
    \$start = microtime(true);
    \$result = password_verify(\$password, \$hash);
    \$end = microtime(true);
    
    // Add minimum delay to prevent timing analysis
    \$minTime = 0.5; // 500ms minimum
    \$elapsed = \$end - \$start;
    if (\$elapsed < \$minTime) {
        usleep((\$minTime - \$elapsed) * 1000000);
    }
    
    return \$result;
}"
    ];
    
    echo "<h4>Önerilen Güvenlik Helper Functions:</h4>";
    
    foreach ($securityHelpers as $functionName => $functionCode) {
        echo "<h5>$functionName:</h5>";
        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 5px; font-size: 11px; overflow: auto;'>";
        echo htmlspecialchars($functionCode);
        echo "</pre>";
    }
    
    echo "<h3>7. Düzeltme Önceliklendirmesi</h3>";
    
    $priorities = [
        'ACIL' => [
            'items' => [
                'Tüm düz metin şifreleri hash\'le',
                'SQL injection koruması ekle',
                'Session hijacking koruması',
                'Input sanitization'
            ],
            'color' => '#ffebee'
        ],
        'YÜKSEK' => [
            'items' => [
                'htmlspecialchars null kontrolü',
                'Hard-coded değerleri config\'e taşı',
                'Error handling standardizasyonu',
                'Database connection tutarlılığı'
            ],
            'color' => '#fff3e0'
        ],
        'ORTA' => [
            'items' => [
                'Code documentation',
                'Türkçe/İngilizce tutarlılığı',
                'Performance optimizasyonu',
                'Test coverage artışı'
            ],
            'color' => '#e8f5e8'
        ]
    ];
    
    foreach ($priorities as $priority => $data) {
        echo "<h4>$priority Öncelik:</h4>";
        echo "<div style='background: " . $data['color'] . "; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<ul>";
        foreach ($data['items'] as $item) {
            echo "<li>$item</li>";
        }
        echo "</ul>";
        echo "</div>";
    }
    
    echo "<h3>✅ Sistem Güvenlik Analizi Tamamlandı</h3>";
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>🎯 Sonuç ve Öneriler</h4>";
    echo "<ul>";
    echo "<li>✅ Güvenlik sorunları tespit edildi</li>";
    echo "<li>✅ Şifre hash sistemi modernize edildi</li>";
    echo "<li>✅ Database uyumluluğu kontrol edildi</li>";
    echo "<li>✅ Code quality sorunları belirlendi</li>";
    echo "<li>✅ Güvenlik helper functions önerildi</li>";
    echo "<li>✅ Düzeltme öncelikleri belirlendi</li>";
    echo "</ul>";
    
    echo "<h4>Sonraki Adımlar:</h4>";
    echo "<ol>";
    echo "<li>includes/security.php dosyası oluştur</li>";
    echo "<li>Auth dosyalarını güvenlik standartlarına uygun güncelle</li>";
    echo "<li>Database class'ını PDO standardına tam uyumlu hale getir</li>";
    echo "<li>Tüm form işleyen dosyalara CSRF koruması ekle</li>";
    echo "<li>Input validation middleware sistemi kur</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Sistem Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { margin: 10px 0; border-collapse: collapse; width: 100%; }";
echo "th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }";
echo "th { background-color: #f8f9fa; font-weight: bold; }";
echo "pre { font-size: 11px; max-height: 300px; overflow: auto; }";
echo "ul, ol { margin: 10px 0; padding-left: 20px; }";
echo "h3 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-top: 30px; }";
echo "</style>";
?>