<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'add_user') {
            // Check if email already exists
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND company_id = ?");
            $stmt->execute([$_POST['email'], $_SESSION['company_id']]);
            
            if ($stmt->rowCount() > 0) {
                $error = "Bu e-posta adresi zaten kullanılıyor.";
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO users (company_id, email, password_hash, role, first_name, last_name, is_active, created_at)
                    VALUES (?, ?, SHA2(?, 256), ?, ?, ?, 1, NOW())
                ");
                $stmt->execute([
                    $_SESSION['company_id'],
                    $_POST['email'],
                    $_POST['password'],
                    $_POST['role'],
                    $_POST['first_name'],
                    $_POST['last_name']
                ]);
                $success = "Yeni kullanıcı başarıyla eklendi.";
            }
        }
        
        if ($action === 'update_user') {
            $stmt = $conn->prepare("
                UPDATE users SET 
                    email = ?, role = ?, first_name = ?, last_name = ?, is_active = ?, updated_at = NOW()
                WHERE id = ? AND company_id = ?
            ");
            $stmt->execute([
                $_POST['email'],
                $_POST['role'],
                $_POST['first_name'],
                $_POST['last_name'],
                $_POST['is_active'],
                $_POST['user_id'],
                $_SESSION['company_id']
            ]);
            $success = "Kullanıcı bilgileri güncellendi.";
        }
        
        if ($action === 'change_user_password') {
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            if ($new_password !== $confirm_password) {
                $error = "Şifreler eşleşmiyor.";
            } elseif (strlen($new_password) < 6) {
                $error = "Şifre en az 6 karakter olmalıdır.";
            } else {
                $stmt = $conn->prepare("
                    UPDATE users SET password_hash = SHA2(?, 256), updated_at = NOW() 
                    WHERE id = ? AND company_id = ?
                ");
                $stmt->execute([
                    $new_password,
                    $_POST['user_id'],
                    $_SESSION['company_id']
                ]);
                $success = "Kullanıcı şifresi başarıyla değiştirildi.";
            }
        }
        
        if ($action === 'toggle_user_status') {
            $stmt = $conn->prepare("
                UPDATE users SET is_active = CASE 
                    WHEN is_active = 1 THEN 0 
                    ELSE 1 
                END, updated_at = NOW()
                WHERE id = ? AND company_id = ?
            ");
            $stmt->execute([
                $_POST['user_id'],
                $_SESSION['company_id']
            ]);
            $success = "Kullanıcı durumu güncellendi.";
        }
    }
    
    // Get company users
    $stmt = $conn->prepare("
        SELECT id, email, first_name, last_name, role, is_active, created_at, last_login,
               CONCAT(first_name, ' ', last_name) as full_name
        FROM users 
        WHERE company_id = ?
        ORDER BY role, first_name, last_name, email
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
    $users = []; // Initialize empty array in case of error
}

// Safety check for users variable
if (!isset($users) || !is_array($users)) {
    $users = [];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Kullanıcı Yönetimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">👤</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Kullanıcı Yönetimi</h1>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'Şirket'); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <?php if (isset($success)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Add User Form -->
            <div class="bg-white rounded-lg shadow mb-8">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Yeni Kullanıcı Ekle</h2>
                </div>
                <div class="p-6">
                    <form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <input type="hidden" name="action" value="add_user">
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Ad</label>
                            <input type="text" name="first_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Soyad</label>
                            <input type="text" name="last_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">E-posta</label>
                            <input type="email" name="email" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Şifre</label>
                            <input type="password" name="password" required minlength="6"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Rol</label>
                            <select name="role" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                                <option value="">Rol Seçin</option>
                                <option value="admin">Admin</option>
                                <option value="hr">İK Uzmanı</option>
                                <option value="manager">Yönetici</option>
                                <option value="user">Kullanıcı</option>
                            </select>
                        </div>
                        
                        <div class="md:col-span-2 lg:col-span-3">
                            <button type="submit" 
                                    class="bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500">
                                Kullanıcı Ekle
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Users Table -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">
                        Kullanıcı Listesi (<?php echo count($users); ?>)
                    </h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kullanıcı</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İletişim</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rol</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($users as $user): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                                                <span class="text-purple-600 font-medium">
                                                    <?php echo strtoupper(substr($user['full_name'] ?? $user['email'], 0, 2)); ?>
                                                </span>
                                            </div>
                                            <div>
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo htmlspecialchars($user['full_name'] ?? ($user['first_name'] . ' ' . $user['last_name'])); ?>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($user['email']); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <?php echo htmlspecialchars($user['email'] ?? '-'); ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full
                                            <?php 
                                            switch($user['role']) {
                                                case 'admin': echo 'bg-red-100 text-red-800'; break;
                                                case 'hr': echo 'bg-blue-100 text-blue-800'; break;
                                                case 'manager': echo 'bg-yellow-100 text-yellow-800'; break;
                                                default: echo 'bg-gray-100 text-gray-800';
                                            }
                                            ?>">
                                            <?php 
                                            switch($user['role']) {
                                                case 'admin': echo 'Admin'; break;
                                                case 'hr': echo 'İK'; break;
                                                case 'manager': echo 'Yönetici'; break;
                                                default: echo 'Kullanıcı';
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            <?php echo $user['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo $user['is_active'] ? 'Aktif' : 'Pasif'; ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm font-medium">
                                        <div class="flex flex-col space-y-1">
                                            <a href="javascript:void(0)" onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)" 
                                               class="text-indigo-600 hover:text-indigo-900">✏️ Düzenle</a>
                                            <a href="javascript:void(0)" onclick="changeUserPassword(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['full_name'] ?? ($user['first_name'] . ' ' . $user['last_name'])); ?>')" 
                                               class="text-orange-600 hover:text-orange-900">🔑 Şifre Değiştir</a>
                                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                                <a href="javascript:void(0)" onclick="toggleUserStatus(<?php echo $user['id']; ?>, <?php echo $user['is_active']; ?>)" 
                                                   class="<?php echo $user['is_active'] ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'; ?>">
                                                   <?php echo $user['is_active'] ? '❌ Pasif Yap' : '✅ Aktif Yap'; ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div id="editUserModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg max-w-2xl w-full p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Kullanıcı Düzenle</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="update_user">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Ad</label>
                            <input type="text" name="first_name" id="edit_first_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Soyad</label>
                            <input type="text" name="last_name" id="edit_last_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">E-posta</label>
                            <input type="email" name="email" id="edit_email" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Rol</label>
                            <select name="role" id="edit_role" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                                <option value="admin">Admin</option>
                                <option value="hr">İK Uzmanı</option>
                                <option value="manager">Yönetici</option>
                                <option value="user">Kullanıcı</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Durum</label>
                            <select name="is_active" id="edit_is_active" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                                <option value="1">Aktif</option>
                                <option value="0">Pasif</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closeEditUserModal()" 
                                class="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                            İptal
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Password Change Modal -->
    <div id="passwordUserModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg max-w-md w-full p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Kullanıcı Şifresi Değiştir</h3>
                <p class="text-sm text-gray-600 mb-4">Kullanıcı: <span id="password_user_name" class="font-medium"></span></p>
                
                <form method="POST">
                    <input type="hidden" name="action" value="change_user_password">
                    <input type="hidden" name="user_id" id="password_user_id">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Yeni Şifre</label>
                            <input type="password" name="new_password" required minlength="6"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                            <p class="text-xs text-gray-500 mt-1">En az 6 karakter olmalıdır</p>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Şifre Tekrar</label>
                            <input type="password" name="confirm_password" required minlength="6"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closePasswordUserModal()" 
                                class="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                            İptal
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700">
                            Şifre Değiştir
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function editUser(user) {
        document.getElementById('edit_user_id').value = user.id;
        document.getElementById('edit_first_name').value = user.first_name || '';
        document.getElementById('edit_last_name').value = user.last_name || '';
        document.getElementById('edit_email').value = user.email || '';
        document.getElementById('edit_role').value = user.role || '';
        document.getElementById('edit_is_active').value = user.is_active || '1';
        
        document.getElementById('editUserModal').classList.remove('hidden');
    }
    
    function closeEditUserModal() {
        document.getElementById('editUserModal').classList.add('hidden');
    }
    
    function changeUserPassword(userId, userName) {
        document.getElementById('password_user_id').value = userId;
        document.getElementById('password_user_name').textContent = userName;
        document.getElementById('passwordUserModal').classList.remove('hidden');
    }
    
    function closePasswordUserModal() {
        document.getElementById('passwordUserModal').classList.add('hidden');
    }
    
    function toggleUserStatus(userId, currentStatus) {
        const newStatus = currentStatus ? 'pasif' : 'aktif';
        if (confirm(`Bu kullanıcıyı ${newStatus} yapmak istediğinizden emin misiniz?`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="toggle_user_status">
                <input type="hidden" name="user_id" value="${userId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Close modals when clicking outside
    document.getElementById('editUserModal').addEventListener('click', function(e) {
        if (e.target === this) closeEditUserModal();
    });
    
    document.getElementById('passwordUserModal').addEventListener('click', function(e) {
        if (e.target === this) closePasswordUserModal();
    });
    </script>
</body>
</html>