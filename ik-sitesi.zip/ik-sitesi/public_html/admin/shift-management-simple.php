<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$message = '';
$messageType = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'assign_shift') {
            try {
                $employeeId = $_POST['employee_id'] ?? 0;
                $shiftTemplateId = $_POST['shift_template_id'] ?? 0;
                $shiftDate = $_POST['shift_date'] ?? date('Y-m-d');
                
                $stmt = $conn->prepare("
                    INSERT INTO employee_shifts 
                    (employee_id, shift_template_id, shift_date, status, created_at) 
                    VALUES (?, ?, ?, 'scheduled', NOW())
                ");
                $stmt->execute([$employeeId, $shiftTemplateId, $shiftDate]);
                
                $message = "Vardiya başarıyla atandı";
                $messageType = "success";
                
            } catch (Exception $e) {
                $message = "Vardiya atanamadı: " . $e->getMessage();
                $messageType = "error";
            }
        }
    }
    
    // Get employees
    $employees = [];
    try {
        $stmt = $conn->prepare("
            SELECT id, first_name, last_name, employee_number
            FROM employees 
            WHERE company_id = ? 
            ORDER BY first_name, last_name
            LIMIT 50
        ");
        $stmt->execute([$_SESSION['company_id']]);
        
        if ($conn instanceof PDO) {
            $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $employees = [];
            while ($row = $stmt->fetch_assoc()) {
                $employees[] = $row;
            }
        }
    } catch (Exception $e) {
        // Keep empty array
    }
    
    // Get shift templates
    $shiftTemplates = [];
    try {
        $stmt = $conn->prepare("
            SELECT id, name, start_time, end_time
            FROM shift_templates 
            WHERE company_id = ? AND is_active = 1 
            ORDER BY name
        ");
        $stmt->execute([$_SESSION['company_id']]);
        
        if ($conn instanceof PDO) {
            $shiftTemplates = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $shiftTemplates = [];
            while ($row = $stmt->fetch_assoc()) {
                $shiftTemplates[] = $row;
            }
        }
    } catch (Exception $e) {
        // Keep empty array
    }
    
    // Get recent shift assignments
    $recentShifts = [];
    try {
        $stmt = $conn->prepare("
            SELECT 
                es.id,
                es.shift_date,
                es.status,
                COALESCE(e.first_name, '') as first_name,
                COALESCE(e.last_name, '') as last_name,
                COALESCE(st.name, 'Vardiya') as shift_name
            FROM employee_shifts es
            LEFT JOIN employees e ON es.employee_id = e.id
            LEFT JOIN shift_templates st ON es.shift_template_id = st.id
            WHERE es.shift_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            ORDER BY es.shift_date DESC
            LIMIT 20
        ");
        $stmt->execute();
        
        if ($conn instanceof PDO) {
            $recentShifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $recentShifts = [];
            while ($row = $stmt->fetch_assoc()) {
                $recentShifts[] = $row;
            }
        }
    } catch (Exception $e) {
        // Keep empty array
    }
    
} catch (Exception $e) {
    $message = "Veritabanı hatası: " . $e->getMessage();
    $messageType = "error";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vardiya Yönetimi - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        .container { max-width: 1200px; margin: 0 auto; }
        .message { padding: 15px; border-radius: 5px; margin: 20px 0; }
        .message.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .message.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .form-group { margin: 15px 0; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input { padding: 8px; border: 1px solid #ddd; border-radius: 4px; width: 100%; max-width: 300px; }
        button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f8f9fa; }
        .section { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="container">
        <h1>📋 Vardiya Yönetimi</h1>
        
        <?php if ($message): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="section">
            <h2>🏢 Vardiya Ata</h2>
            <form method="POST">
                <input type="hidden" name="action" value="assign_shift">
                
                <div class="form-group">
                    <label>Personel:</label>
                    <select name="employee_id" required>
                        <option value="">Personel Seçin</option>
                        <?php foreach ($employees as $emp): ?>
                            <option value="<?php echo $emp['id']; ?>">
                                <?php echo htmlspecialchars(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '') . ' (' . ($emp['employee_number'] ?? 'N/A') . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Vardiya Şablonu:</label>
                    <select name="shift_template_id" required>
                        <option value="">Vardiya Seçin</option>
                        <?php foreach ($shiftTemplates as $template): ?>
                            <option value="<?php echo $template['id']; ?>">
                                <?php echo htmlspecialchars(($template['name'] ?? 'Vardiya') . ' (' . substr($template['start_time'] ?? '09:00', 0, 5) . '-' . substr($template['end_time'] ?? '17:00', 0, 5) . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Tarih:</label>
                    <input type="date" name="shift_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <button type="submit">Vardiya Ata</button>
            </form>
        </div>
        
        <div class="section">
            <h2>📊 Son Vardiya Atamaları</h2>
            <?php if (!empty($recentShifts)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Personel</th>
                            <th>Vardiya</th>
                            <th>Tarih</th>
                            <th>Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentShifts as $shift): ?>
                            <tr>
                                <td><?php echo htmlspecialchars(($shift['first_name'] ?? '') . ' ' . ($shift['last_name'] ?? '')); ?></td>
                                <td><?php echo htmlspecialchars($shift['shift_name'] ?? 'Vardiya'); ?></td>
                                <td><?php echo htmlspecialchars($shift['shift_date'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($shift['status'] ?? 'scheduled'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Henüz vardiya ataması yapılmamış.</p>
            <?php endif; ?>
        </div>
        
        <div class="section">
            <h2>📈 Sistem Durumu</h2>
            <ul>
                <li>Toplam Personel: <?php echo count($employees); ?></li>
                <li>Aktif Vardiya Şablonu: <?php echo count($shiftTemplates); ?></li>
                <li>Son 7 Günde Atama: <?php echo count($recentShifts); ?></li>
            </ul>
        </div>
        
        <div class="section">
            <h2>🔗 Bağlantılar</h2>
            <p><a href="../test-shift-queries.php">Vardiya Test Sorguları</a></p>
            <p><a href="../quick-shift-test.php">Hızlı Test</a></p>
            <p><a href="shift-management-debug.php">Debug</a></p>
            <p><a href="../auth/logout.php">Çıkış</a></p>
        </div>
    </div>
</body>
</html>