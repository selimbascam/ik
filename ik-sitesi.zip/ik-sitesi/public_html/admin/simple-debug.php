<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1); // Debug için açık

if (!isset($_SESSION['company_id'])) {
    die("<h1>Erişim Reddedildi</h1><p>Lütfen önce giriş yapın.</p>");
}

require_once '../includes/database.php';

echo "<h1>QR Lokasyon Debug Testi</h1>";
echo "<p>Şirket ID: " . htmlspecialchars($_SESSION['company_id']) . "</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Test ID'leri
    $test_ids = [94, 95, 96];
    $placeholders = implode(',', array_fill(0, count($test_ids), '?'));
    
    echo "<h2>1. Seçili Lokasyonların Durumu (Company Filter İLE):</h2>";
    $stmt = $conn->prepare("SELECT id, name, location_type, company_id FROM qr_locations WHERE company_id = ? AND id IN ($placeholders) ORDER BY id");
    $params = array_merge([$_SESSION['company_id']], $test_ids);
    $stmt->execute($params);
    $results = $stmt->fetchAll();
    
    if (empty($results)) {
        echo "<p style='color: red;'><strong>❌ Company filter ile hiç kayıt bulunamadı!</strong></p>";
        
        echo "<h2>2. Aynı ID'ler Company Filter OLMADAN:</h2>";
        $stmt2 = $conn->prepare("SELECT id, name, location_type, company_id FROM qr_locations WHERE id IN ($placeholders) ORDER BY id");
        $stmt2->execute($test_ids);
        $all_results = $stmt2->fetchAll();
        
        if (empty($all_results)) {
            echo "<p style='color: red;'>❌ Hiç kayıt yok! ID'ler mevcut değil.</p>";
        } else {
            foreach ($all_results as $row) {
                $match = ($row['company_id'] == $_SESSION['company_id']) ? "✅ MATCH" : "❌ MISMATCH";
                echo "<p>$match ID: {$row['id']}, İsim: " . htmlspecialchars($row['name']) . 
                     ", Tür: '" . htmlspecialchars($row['location_type']) . 
                     "', Şirket: {$row['company_id']} (Benim: {$_SESSION['company_id']})</p>";
            }
        }
    } else {
        foreach ($results as $row) {
            echo "<p>✅ ID: {$row['id']}, İsim: " . htmlspecialchars($row['name']) . 
                 ", Tür: '" . htmlspecialchars($row['location_type']) . 
                 "', Şirket: {$row['company_id']}</p>";
        }
    }
    
    // Manual update test
    if (isset($_POST['manual_update']) && $_POST['manual_update'] === 'test') {
        echo "<h2>3. Manuel Güncelleme Testi:</h2>";
        
        // Test: Empty type'ları güncelle
        $update_stmt = $conn->prepare("UPDATE qr_locations SET location_type = 'check_in' WHERE id = ? AND company_id = ? AND (location_type = '' OR location_type IS NULL)");
        $update_result = $update_stmt->execute([94, $_SESSION['company_id']]);
        
        echo "<p>Empty Type Update - Etkilenen: " . $update_stmt->rowCount() . "</p>";
        
        // Test 2: Force update different value  
        $update_stmt2 = $conn->prepare("UPDATE qr_locations SET location_type = 'FORCE_TEST' WHERE id = ? AND company_id = ?");
        $update_result2 = $update_stmt2->execute([94, $_SESSION['company_id']]);
        
        echo "<p>Force Update sonucu: " . ($update_result2 ? '✅ BAŞARILI' : '❌ BAŞARISIZ') . "</p>";
        echo "<p>Force Update Etkilenen: " . $update_stmt2->rowCount() . "</p>";
        
        if ($update_stmt->rowCount() === 0) {
            echo "<p style='color: orange;'>⚠️ Hiç satır etkilenmedi. Company ID uyuşmuyor veya kayıt yok.</p>";
        }
    }
    
    echo "<h2>4. Test Butonu:</h2>";
    echo "<form method='POST'>";
    echo "<button type='submit' name='manual_update' value='test' style='background: blue; color: white; padding: 10px;'>🔧 ID 94 Manuel Update Test</button>";
    echo "</form>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ HATA: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>