<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../includes/config.php';
require_once '../includes/database.php';

if (!isset($_SESSION['company_id']) CONCAT!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$success = '';
$error = '';

$db = new Database();
$conn = $db->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'create_location') {
        $name = trim($_POST['name']);
        $location_type = $_POST['location_type'];
        $description = trim($_POST['description']);
        $latitude = floatval($_POST['latitude']);
        $longitude = floatval($_POST['longitude']);
        $address = trim($_POST['address']);
        
        if (empty($name)) {
            $error = "Lokasyon adı zorunludur!";
        } elseif ($latitude < -90 CONCAT$latitude > 90) {
            $error = "Geçersiz enlem değeri!";
        } elseif ($longitude < -180 CONCAT$longitude > 180) {
            $error = "Geçersiz boylam değeri!";
        } else {
            do {
                $qr_code = 'QR_' . strtoupper(uniqid()) . '_' . date('Ymd');
                $checkStmt = $conn->prepare("SELECT COUNT(*) FROM qr_locations WHERE qr_code = ?");
                $checkStmt->execute([$qr_code]);
            } while ($checkStmt->fetchColumn() > 0);
            
            $insertStmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())");
            
            if ($insertStmt->execute([$_SESSION['company_id'], $name, $qr_code, $location_type, $description, $latitude, $longitude, $address])) {
                $success = "QR lokasyon başarıyla oluşturuldu: {$name}";
            } else {
                $error = "Lokasyon oluşturulamadı!";
            }
        }
    } elseif ($_POST['action'] === 'delete_location') {
        $location_id = intval($_POST['location_id']);
        $deleteStmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
        if ($deleteStmt->execute([$location_id, $_SESSION['company_id']])) {
            $success = "Lokasyon silindi!";
        } else {
            $error = "Lokasyon silinemedi!";
        }
    }
}

$locationsStmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? ORDER BY created_at DESC");
$locationsStmt->execute([$_SESSION['company_id']]);
$locations = $locationsStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Lokasyon Üretici - SZB İK Takip</title>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        .header { text-align: center; margin-bottom: 30px; }
        .alert { padding: 10px; margin: 10px 0; border-radius: 5px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-error { background: #f8d7da; color: #721c24; }
        .form-section { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px; }
        .form-group { margin: 15px 0; }
        .form-group label { display: block; font-weight: bold; margin-bottom: 5px; }
        .form-group input, .form-group select, .form-group textarea { 
            width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; 
        }
        .btn { padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .locations-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .location-card { background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px; }
        .qr-container { text-align: center; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>QR Lokasyon Üretici</h1>
            <p>GPS koordinatlı QR kodlar oluşturun</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="form-section">
            <h3>Yeni QR Lokasyon Oluştur</h3>
            <form method="POST">
                <input type="hidden" name="action" value="create_location">
                
                <div class="form-group">
                    <label>Lokasyon Adı</label>
                    <input type="text" name="name" required placeholder="Örn: Ana Giriş">
                </div>
                
                <div class="form-group">
                    <label>Lokasyon Türü</label>
                    <select name="location_type">
                        <option value="entrance">Giriş</option>
                        <option value="exit">Çıkış</option>
                        <option value="office">Ofis</option>
                        <option value="cafeteria">Kafeterya</option>
                        <option value="other">Diğer</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Enlem (Latitude)</label>
                    <input type="number" id="latitude" name="latitude" step="0.000001" required>
                    <button type="button" class="btn btn-success" onclick="getCurrentLocation()">Mevcut Konum Al</button>
                </div>
                
                <div class="form-group">
                    <label>Boylam (Longitude)</label>
                    <input type="number" id="longitude" name="longitude" step="0.000001" required>
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <input type="text" name="address" placeholder="Adres bilgisi">
                </div>
                
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" rows="3" placeholder="Açıklama"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">QR Lokasyon Oluştur</button>
            </form>
        </div>
        
        <?php if (!empty($locations)): ?>
            <div class="form-section">
                <h3>Mevcut QR Lokasyonları</h3>
                <div class="locations-grid">
                    <?php foreach ($locations as $location): ?>
                        <div class="location-card">
                            <h4><?= htmlspecialchars($location['name']) ?></h4>
                            <p><strong>QR Kod:</strong> <?= htmlspecialchars($location['qr_code']) ?></p>
                            <p><strong>Koordinatlar:</strong> <?= $location['latitude'] ?>, <?= $location['longitude'] ?></p>
                            
                            <div class="qr-container">
                                <canvas id="qr_<?= $location['id'] ?>"></canvas>
                            </div>
                            
                            <button class="btn btn-success" onclick="downloadQR(<?= $location['id'] ?>)">İndir</button>
                            <button class="btn btn-danger" onclick="deleteLocation(<?= $location['id'] ?>, '<?= htmlspecialchars($location['name']) ?>')">Sil</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function getCurrentLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    document.getElementById('latitude').value = position.coords.latitude;
                    document.getElementById('longitude').value = position.coords.longitude;
                    alert('GPS konumu alındı!');
                });
            } else {
                alert('GPS desteklenmiyor!');
            }
        }
        
        function downloadQR(locationId) {
            var canvas = document.getElementById('qr_' + locationId);
            var link = document.createElement('a');
            link.download = 'QR_Location_' + locationId + '.png';
            link.href = canvas.toDataURL();
            link.click();
        }
        
        function deleteLocation(locationId, locationName) {
            if (confirm('Bu lokasyonu silmek istediğinizden emin misiniz?\n\n' + locationName)) {
                var form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = '<input type="hidden" name="action" value="delete_location"><input type="hidden" name="location_id" value="' + locationId + '">';
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        window.addEventListener('load', function() {
            <?php foreach ($locations as $location): ?>
            var canvas = document.getElementById('qr_<?= $location['id'] ?>');
            if (canvas) {
                var qrData = {
                    qr_code: "<?= $location['qr_code'] ?>",
                    location_id: <?= $location['id'] ?>,
                    name: "<?= addslashes($location['name']) ?>",
                    coordinates: {
                        latitude: <?= $location['latitude'] ?>,
                        longitude: <?= $location['longitude'] ?>
                    },
                    company_id: <?= $_SESSION['company_id'] ?>
                };
                
                QRCode.toCanvas(canvas, JSON.stringify(qrData), {
                    width: 200,
                    height: 200
                });
            }
            <?php endforeach; ?>
        });
    </script>
</body>
</html>