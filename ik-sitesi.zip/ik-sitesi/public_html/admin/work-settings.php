<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as admin
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$message = '';
$messageType = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Create work_settings table if it doesn't exist - Fixed schema with all required columns
    $conn->exec("
        CREATE TABLE IF NOT EXISTS work_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            daily_work_hours INT DEFAULT 8,
            weekly_work_hours INT DEFAULT 45,
            monthly_work_hours INT DEFAULT 225,
            overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
            holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
            weekend_multiplier DECIMAL(3,2) DEFAULT 1.50,
            grace_period_minutes INT DEFAULT 15,
            late_penalty_amount DECIMAL(10,2) DEFAULT 0,
            min_break_duration INT DEFAULT 30,
            max_break_duration INT DEFAULT 60,
            hourly_rate DECIMAL(10,2) DEFAULT 50.00,
            weekly_holiday INT DEFAULT 1,
            auto_schedule TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_company (company_id)
        )
    ");
    
    // Ensure daily_work_hours column exists (fix for column not found error)
    try {
        $result = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'daily_work_hours'");
        $columns = $result->fetchAll();
        if (count($columns) === 0) {
            $conn->exec("ALTER TABLE work_settings ADD COLUMN daily_work_hours INT DEFAULT 8 AFTER company_id");
        }
    } catch (Exception $e) {
        // If column check fails, try to add anyway
        try {
            $conn->exec("ALTER TABLE work_settings ADD COLUMN daily_work_hours INT DEFAULT 8 AFTER company_id");
        } catch (Exception $e2) {
            // Column might already exist or other issue
        }
    }
    
    // Check and add missing auto_schedule column if it doesn't exist
    try {
        $result = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'auto_schedule'");
        $columns = $result->fetchAll();
        if (count($columns) === 0) {
            $conn->exec("ALTER TABLE work_settings ADD COLUMN auto_schedule TINYINT(1) DEFAULT 1");
        }
    } catch (Exception $e) {
        // If column check fails, ignore - column might exist or table might not exist yet
    }
    
    $companyId = $_SESSION['company_id'] ?? null;
    if (!$companyId && $_SESSION['user_role'] === 'super_admin') {
        $companyId = $_GET['company_id'] ?? null;
    }
    
    if (!$companyId) {
        throw new Exception('Şirket ID bulunamadı');
    }
    
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'update_work_settings') {
            $dailyWorkHours = (int)$_POST['daily_work_hours'];
            $weeklyWorkHours = (int)$_POST['weekly_work_hours'];
            $monthlyWorkHours = (int)$_POST['monthly_work_hours'];
            $overtimeMultiplier = (float)$_POST['overtime_multiplier'];
            $holidayMultiplier = (float)$_POST['holiday_multiplier'];
            $weekendMultiplier = (float)$_POST['weekend_multiplier'];
            $gracePeriodMinutes = (int)$_POST['grace_period_minutes'];
            $latePenaltyAmount = (float)$_POST['late_penalty_amount'];
            $minBreakDuration = (int)$_POST['min_break_duration'];
            $maxBreakDuration = (int)$_POST['max_break_duration'];
            $hourlyRate = (float)$_POST['hourly_rate'];
            $weeklyHoliday = (int)$_POST['weekly_holiday'];
            $autoSchedule = isset($_POST['auto_schedule']) ? 1 : 0;
            
            // Check if auto_schedule column exists for safer queries
            $hasAutoSchedule = false;
            try {
                $result = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'auto_schedule'");
                $columns = $result->fetchAll();
                $hasAutoSchedule = (count($columns) > 0);
            } catch (PDOException $e) {
                // If check fails, assume column doesn't exist
                $hasAutoSchedule = false;
            }
            
            // Update or insert work settings with conditional auto_schedule
            try {
                if ($hasAutoSchedule) {
                    $stmt = $conn->prepare("
                        INSERT INTO work_settings 
                        (company_id, daily_work_hours, weekly_work_hours, monthly_work_hours, overtime_multiplier, holiday_multiplier, weekend_multiplier, grace_period_minutes, late_penalty_amount, min_break_duration, max_break_duration, hourly_rate, weekly_holiday, auto_schedule, updated_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE
                        daily_work_hours = VALUES(daily_work_hours),
                        weekly_work_hours = VALUES(weekly_work_hours),
                        monthly_work_hours = VALUES(monthly_work_hours),
                        overtime_multiplier = VALUES(overtime_multiplier),
                        holiday_multiplier = VALUES(holiday_multiplier),
                        weekend_multiplier = VALUES(weekend_multiplier),
                        grace_period_minutes = VALUES(grace_period_minutes),
                        late_penalty_amount = VALUES(late_penalty_amount),
                        min_break_duration = VALUES(min_break_duration),
                        max_break_duration = VALUES(max_break_duration),
                        hourly_rate = VALUES(hourly_rate),
                        weekly_holiday = VALUES(weekly_holiday),
                        auto_schedule = VALUES(auto_schedule),
                        updated_at = NOW()
                    ");
                    $params = [
                        $companyId, $dailyWorkHours, $weeklyWorkHours, $monthlyWorkHours, 
                        $overtimeMultiplier, $holidayMultiplier, $weekendMultiplier,
                        $gracePeriodMinutes, $latePenaltyAmount, $minBreakDuration, $maxBreakDuration,
                        $hourlyRate, $weeklyHoliday, $autoSchedule
                    ];
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO work_settings 
                        (company_id, daily_work_hours, weekly_work_hours, monthly_work_hours, overtime_multiplier, holiday_multiplier, weekend_multiplier, grace_period_minutes, late_penalty_amount, min_break_duration, max_break_duration, hourly_rate, weekly_holiday, updated_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE
                        daily_work_hours = VALUES(daily_work_hours),
                        weekly_work_hours = VALUES(weekly_work_hours),
                        monthly_work_hours = VALUES(monthly_work_hours),
                        overtime_multiplier = VALUES(overtime_multiplier),
                        holiday_multiplier = VALUES(holiday_multiplier),
                        weekend_multiplier = VALUES(weekend_multiplier),
                        grace_period_minutes = VALUES(grace_period_minutes),
                        late_penalty_amount = VALUES(late_penalty_amount),
                        min_break_duration = VALUES(min_break_duration),
                        max_break_duration = VALUES(max_break_duration),
                        hourly_rate = VALUES(hourly_rate),
                        weekly_holiday = VALUES(weekly_holiday),
                        updated_at = NOW()
                    ");
                    $params = [
                        $companyId, $dailyWorkHours, $weeklyWorkHours, $monthlyWorkHours, 
                        $overtimeMultiplier, $holidayMultiplier, $weekendMultiplier,
                        $gracePeriodMinutes, $latePenaltyAmount, $minBreakDuration, $maxBreakDuration,
                        $hourlyRate, $weeklyHoliday
                    ];
                }
                $stmt->execute($params);
            } catch (PDOException $e) {
                // Check for specific column errors and provide helpful error messages
                if (strpos($e->getMessage(), "Unknown column 'daily_work_hours'") !== false) {
                    $message = "Database sütun hatası tespit edildi. <a href='../debug/fix-work-settings-column.php' class='text-blue-600 underline'>🚨 Hızlı Düzelt</a> linkine tıklayarak sorunu giderin.";
                    $messageType = 'error';
                    throw new Exception($message);
                }
                
                // Fallback: create table and try again
                $conn->exec("
                    CREATE TABLE IF NOT EXISTS work_settings (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        company_id INT NOT NULL,
                        daily_work_hours INT DEFAULT 8,
                        weekly_work_hours INT DEFAULT 45,
                        monthly_work_hours INT DEFAULT 225,
                        overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
                        holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
                        weekend_multiplier DECIMAL(3,2) DEFAULT 1.50,
                        grace_period_minutes INT DEFAULT 15,
                        late_penalty_amount DECIMAL(10,2) DEFAULT 0,
                        min_break_duration INT DEFAULT 30,
                        max_break_duration INT DEFAULT 60,
                        hourly_rate DECIMAL(10,4) DEFAULT 50.0000,
                        weekly_holiday INT DEFAULT 1,
                        auto_schedule TINYINT(1) DEFAULT 1,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        UNIQUE KEY unique_company (company_id)
                    )
                ");
                
                $stmt = $conn->prepare("
                    INSERT INTO work_settings 
                    (company_id, daily_work_hours, weekly_work_hours, monthly_work_hours, overtime_multiplier, holiday_multiplier, weekend_multiplier, grace_period_minutes, late_penalty_amount, min_break_duration, max_break_duration, hourly_rate, weekly_holiday, auto_schedule, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE
                    daily_work_hours = VALUES(daily_work_hours),
                    weekly_work_hours = VALUES(weekly_work_hours),
                    monthly_work_hours = VALUES(monthly_work_hours),
                    overtime_multiplier = VALUES(overtime_multiplier),
                    holiday_multiplier = VALUES(holiday_multiplier),
                    weekend_multiplier = VALUES(weekend_multiplier),
                    grace_period_minutes = VALUES(grace_period_minutes),
                    late_penalty_amount = VALUES(late_penalty_amount),
                    min_break_duration = VALUES(min_break_duration),
                    max_break_duration = VALUES(max_break_duration),
                    hourly_rate = VALUES(hourly_rate),
                    weekly_holiday = VALUES(weekly_holiday),
                    auto_schedule = VALUES(auto_schedule),
                    updated_at = NOW()
                ");
                $stmt->execute([
                    $companyId, $dailyWorkHours, $weeklyWorkHours, $monthlyWorkHours, 
                    $overtimeMultiplier, $holidayMultiplier, $weekendMultiplier,
                    $gracePeriodMinutes, $latePenaltyAmount, $minBreakDuration, $maxBreakDuration,
                    $hourlyRate, $weeklyHoliday, $autoSchedule
                ]);
            }
            
            $message = "✅ Çalışma ayarları başarıyla güncellendi!";
            $messageType = "success";
        }
    }
    
    // Get current work settings with fallback
    try {
        $stmt = $conn->prepare("SELECT * FROM work_settings WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $workSettings = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Create table if it doesn't exist and set empty settings
        $conn->exec("
            CREATE TABLE IF NOT EXISTS work_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                daily_work_hours INT DEFAULT 8,
                weekly_work_hours INT DEFAULT 45,
                monthly_work_hours INT DEFAULT 225,
                overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
                holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
                weekend_multiplier DECIMAL(3,2) DEFAULT 1.50,
                grace_period_minutes INT DEFAULT 15,
                late_penalty_amount DECIMAL(10,2) DEFAULT 0,
                min_break_duration INT DEFAULT 30,
                max_break_duration INT DEFAULT 60,
                hourly_rate DECIMAL(10,4) DEFAULT 50.0000,
                weekly_holiday INT DEFAULT 1,
                auto_schedule TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_company (company_id)
            )
        ");
        $workSettings = false;
    }
    
    // Default values if no settings exist or ensure all keys exist
    if (!$workSettings || !is_array($workSettings)) {
        $workSettings = [];
    }
    
    // Set default values for missing keys - Updated to match database schema
    $defaults = [
        'daily_work_hours' => 8,
        'weekly_work_hours' => 45,
        'monthly_work_hours' => 225,
        'overtime_multiplier' => 1.5,
        'holiday_multiplier' => 2.0,
        'weekend_multiplier' => 1.5,
        'grace_period_minutes' => 15,
        'late_penalty_amount' => 0,
        'min_break_duration' => 30,
        'max_break_duration' => 60,
        'hourly_rate' => 50.00,
        'weekly_holiday' => 1,
        'auto_schedule' => 1
    ];
    
    foreach ($defaults as $key => $default) {
        if (!isset($workSettings[$key]) || $workSettings[$key] === null) {
            $workSettings[$key] = $default;
        }
    }
    
} catch (Exception $e) {
    $message = "❌ Hata: " . $e->getMessage();
    $messageType = "error";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çalışma Ayarları - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">⚙️</span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Çalışma Ayarları</h1>
            <p class="text-gray-600 mt-2">Mesai, ücret ve çalışma planı ayarları</p>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                    ($messageType === 'error' ? 'bg-red-100 text-red-800 border border-red-200' : 
                    'bg-yellow-100 text-yellow-800 border border-yellow-200'); 
            ?>">
                <?php echo strpos($message, '<a href=') !== false ? $message : htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Work Settings Form -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <form method="POST" class="space-y-6">
                <input type="hidden" name="action" value="update_work_settings">
                
                <!-- Working Hours Settings -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ⏰ Günlük Çalışma Saati
                        </label>
                        <input 
                            type="number" 
                            name="daily_work_hours" 
                            value="<?php echo htmlspecialchars($workSettings['daily_work_hours'] ?? ''); ?>"
                            min="6" 
                            max="11"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">Standart: 8 saat/gün</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            📊 Haftalık Çalışma Saati
                        </label>
                        <input 
                            type="number" 
                            name="weekly_work_hours" 
                            value="<?php echo htmlspecialchars($workSettings['weekly_work_hours'] ?? ''); ?>"
                            min="35" 
                            max="60"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">Fazla mesai hesabı için</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            📅 Aylık Çalışma Saati
                        </label>
                        <input 
                            type="number" 
                            name="monthly_work_hours" 
                            value="<?php echo htmlspecialchars($workSettings['monthly_work_hours'] ?? ''); ?>"
                            min="160" 
                            max="300"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">Standart: 225 saat/ay</p>
                    </div>
                </div>

                <!-- Rate Settings -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            💰 Saatlik Ücret (₺)
                        </label>
                        <input 
                            type="number" 
                            step="0.0001"
                            name="hourly_rate" 
                            value="<?php echo htmlspecialchars(number_format($workSettings['hourly_rate'] ?? 0, 4, '.', '')); ?>"
                            min="30" 
                            max="500"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">Normal çalışma saati ücreti</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            📈 Fazla Mesai Çarpanı
                        </label>
                        <select 
                            name="overtime_multiplier" 
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                            <option value="1.25" <?php echo ($workSettings['overtime_multiplier'] ?? 1.5) == 1.25 ? 'selected' : ''; ?>>1.25x (25% artış)</option>
                            <option value="1.5" <?php echo ($workSettings['overtime_multiplier'] ?? 1.5) == 1.5 ? 'selected' : ''; ?>>1.5x (50% artış)</option>
                            <option value="2.0" <?php echo ($workSettings['overtime_multiplier'] ?? 1.5) == 2.0 ? 'selected' : ''; ?>>2.0x (100% artış)</option>
                        </select>
                        <p class="text-xs text-gray-500 mt-1">Haftalık 45 saat üzeri</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            🌟 Hafta Sonu Çarpanı
                        </label>
                        <select 
                            name="weekend_multiplier" 
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                            <option value="1.0" <?php echo ($workSettings['weekend_multiplier'] ?? 1.5) == 1.0 ? 'selected' : ''; ?>>1.0x (Normal ücret)</option>
                            <option value="1.25" <?php echo ($workSettings['weekend_multiplier'] ?? 1.5) == 1.25 ? 'selected' : ''; ?>>1.25x (25% artış)</option>
                            <option value="1.5" <?php echo ($workSettings['weekend_multiplier'] ?? 1.5) == 1.5 ? 'selected' : ''; ?>>1.5x (50% artış)</option>
                            <option value="2.0" <?php echo ($workSettings['weekend_multiplier'] ?? 1.5) == 2.0 ? 'selected' : ''; ?>>2.0x (100% artış)</option>
                        </select>
                        <p class="text-xs text-gray-500 mt-1">Hafta sonu çalışmaları</p>
                    </div>
                </div>

                <!-- Work Rules Settings -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            🎉 Resmi Tatil Çarpanı
                        </label>
                        <select 
                            name="holiday_multiplier" 
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                            <option value="1.5" <?php echo ($workSettings['holiday_multiplier'] ?? 2.0) == 1.5 ? 'selected' : ''; ?>>1.5x (50% artış)</option>
                            <option value="2.0" <?php echo ($workSettings['holiday_multiplier'] ?? 2.0) == 2.0 ? 'selected' : ''; ?>>2.0x (100% artış)</option>
                            <option value="2.5" <?php echo ($workSettings['holiday_multiplier'] ?? 2.0) == 2.5 ? 'selected' : ''; ?>>2.5x (150% artış)</option>
                        </select>
                        <p class="text-xs text-gray-500 mt-1">Resmi tatil günleri</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            🏖️ Haftalık İzin Günü
                        </label>
                        <select 
                            name="weekly_holiday" 
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                            <option value="1" <?php echo ($workSettings['weekly_holiday'] ?? 1) == 1 ? 'selected' : ''; ?>>1 gün</option>
                            <option value="2" <?php echo ($workSettings['weekly_holiday'] ?? 1) == 2 ? 'selected' : ''; ?>>2 gün</option>
                        </select>
                        <p class="text-xs text-gray-500 mt-1">Haftalık dinlenme günü sayısı</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ⏰ Hoşgörü Süresi (dk)
                        </label>
                        <input 
                            type="number" 
                            name="grace_period_minutes" 
                            value="<?php echo htmlspecialchars($workSettings['grace_period_minutes'] ?? ''); ?>"
                            min="0" 
                            max="30"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">Geç kalma toleransı</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            💸 Geç Kalma Cezası (₺)
                        </label>
                        <input 
                            type="number" 
                            step="0.01"
                            name="late_penalty_amount" 
                            value="<?php echo htmlspecialchars($workSettings['late_penalty_amount'] ?? ''); ?>"
                            min="0" 
                            max="100"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">0 = ceza yok</p>
                    </div>
                </div>

                <!-- Break Settings -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ☕ Minimum Mola Süresi (dk)
                        </label>
                        <input 
                            type="number" 
                            name="min_break_duration" 
                            value="<?php echo htmlspecialchars($workSettings['min_break_duration'] ?? ''); ?>"
                            min="15" 
                            max="120"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">Zorunlu minimum mola</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            ⏱️ Maksimum Mola Süresi (dk)
                        </label>
                        <input 
                            type="number" 
                            name="max_break_duration" 
                            value="<?php echo htmlspecialchars($workSettings['max_break_duration'] ?? ''); ?>"
                            min="30" 
                            max="180"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                        <p class="text-xs text-gray-500 mt-1">İzin verilen max mola</p>
                    </div>
                </div>

                <!-- Schedule Settings -->
                <div class="border-t pt-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">📋 Çalışma Planı Ayarları</h3>
                    
                    <div class="flex items-center space-x-3">
                        <input 
                            type="checkbox" 
                            id="auto_schedule" 
                            name="auto_schedule" 
                            value="1"
                            <?php echo ($workSettings['auto_schedule'] ?? 1) ? 'checked' : ''; ?>
                            class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                        >
                        <label for="auto_schedule" class="text-sm font-medium text-gray-700">
                            🤖 Otomatik Çalışma Planı Oluşturma
                        </label>
                    </div>
                    <p class="text-xs text-gray-500 mt-2 ml-7">
                        Etkinleştirildiğinde sistem otomatik olarak günlük maksimum saat sınırını kontrol eder
                    </p>
                </div>

                <!-- Current Calculations Display -->
                <div class="border-t pt-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">📊 Mevcut Hesaplamalar</h3>
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div class="bg-blue-50 p-4 rounded-lg text-center">
                            <div class="text-xl font-bold text-blue-700" id="normal-rate">
                                ₺<?php echo number_format(floatval($workSettings['hourly_rate'] ?? 50), 4); ?>
                            </div>
                            <div class="text-xs text-blue-600">Normal Saat Ücreti</div>
                        </div>
                        <div class="bg-yellow-50 p-4 rounded-lg text-center">
                            <div class="text-xl font-bold text-yellow-700" id="overtime-rate">
                                ₺<?php echo number_format(floatval($workSettings['hourly_rate'] ?? 50) * floatval($workSettings['overtime_multiplier'] ?? 1.5), 4); ?>
                            </div>
                            <div class="text-xs text-yellow-600">Fazla Mesai Ücreti</div>
                        </div>
                        <div class="bg-green-50 p-4 rounded-lg text-center">
                            <div class="text-xl font-bold text-green-700" id="holiday-rate">
                                ₺<?php echo number_format(floatval($workSettings['hourly_rate'] ?? 50) * floatval($workSettings['holiday_multiplier'] ?? 2.0), 4); ?>
                            </div>
                            <div class="text-xs text-green-600">Tatil Gün Ücreti</div>
                        </div>
                        <div class="bg-purple-50 p-4 rounded-lg text-center">
                            <div class="text-xl font-bold text-purple-700" id="monthly-max">
                                ₺<?php echo number_format(floatval($workSettings['hourly_rate'] ?? 50) * intval($workSettings['monthly_work_hours'] ?? 225), 4); ?>
                            </div>
                            <div class="text-xs text-purple-600">Aylık Maksimum</div>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="flex justify-end">
                    <button 
                        type="submit" 
                        class="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition-colors font-semibold"
                    >
                        💾 Ayarları Kaydet
                    </button>
                </div>
            </form>
        </div>

        <!-- Navigation -->
        <div class="text-center space-y-3">
            <a href="../dashboard/company-dashboard.php" class="inline-block text-indigo-600 hover:text-indigo-500 font-medium">
                ← Yönetici Paneli
            </a>
        </div>
    </div>

    <script>
        // Real-time calculation updates
        function updateCalculations() {
            const hourlyRate = parseFloat(document.querySelector('input[name="hourly_rate"]').value) || 0;
            const overtimeMultiplier = parseFloat(document.querySelector('select[name="overtime_multiplier"]').value) || 1.5;
            const holidayMultiplier = parseFloat(document.querySelector('select[name="holiday_multiplier"]').value) || 2.0;
            const monthlyHours = parseFloat(document.querySelector('input[name="monthly_work_hours"]').value) || 225;
            
            document.getElementById('normal-rate').textContent = '₺' + hourlyRate.toFixed(4);
            document.getElementById('overtime-rate').textContent = '₺' + (hourlyRate * overtimeMultiplier).toFixed(4);
            document.getElementById('holiday-rate').textContent = '₺' + (hourlyRate * holidayMultiplier).toFixed(4);
            document.getElementById('monthly-max').textContent = '₺' + (hourlyRate * monthlyHours).toFixed(4);
        }
        
        // Update calculations on input change
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('input[name="hourly_rate"], select[name="overtime_multiplier"], select[name="holiday_multiplier"], input[name="monthly_work_hours"]');
            inputs.forEach(input => {
                input.addEventListener('change', updateCalculations);
                input.addEventListener('input', updateCalculations);
            });
        });
    </script>
</body>
</html>