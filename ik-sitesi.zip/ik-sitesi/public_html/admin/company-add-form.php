<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// MySQL compatible company addition form
$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Get form data with MySQL safe handling
        $companyName = trim($_POST['company_name'] ?? '');
        $companyCode = trim($_POST['company_code'] ?? '');
        $adminEmail = trim($_POST['admin_email'] ?? '');
        $adminPassword = trim($_POST['admin_password'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $taxNumber = trim($_POST['tax_number'] ?? '');
        $companyType = $_POST['company_type'] ?? 'corporate';
        
        // Validate required fields
        if (empty($companyName) || empty($companyCode) || empty($adminEmail) || empty($adminPassword)) {
            throw new Exception("Şirket adı, kod, yönetici e-posta ve şifre zorunludur.");
        }
        
        // Check if company code exists
        $checkStmt = $conn->prepare("SELECT id FROM companies WHERE company_code = ?");
        $checkStmt->execute([$companyCode]);
        if ($checkStmt->fetch()) {
            throw new Exception("Bu şirket kodu zaten kullanılıyor.");
        }
        
        // Check if admin email exists
        $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $checkStmt->execute([$adminEmail]);
        if ($checkStmt->fetch()) {
            throw new Exception("Bu e-posta adresi zaten kullanılıyor.");
        }
        
        // Start MySQL transaction
        $conn->beginTransaction();
        
        // Insert company (MySQL compatible)
        $stmt = $conn->prepare("
            INSERT INTO companies (
                company_name, company_code, email, phone, address, 
                tax_number, company_type, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())
        ");
        $stmt->execute([$companyName, $companyCode, $adminEmail, $phone, $address, $taxNumber, $companyType]);
        $companyId = $conn->lastInsertId();
        
        // Insert admin user with MySQL SHA2 hash
        $stmt = $conn->prepare("
            INSERT INTO users (
                email, password_hash, first_name, last_name, 
                role, company_id, is_active, created_at
            ) VALUES (?, SHA2(?, 256), ?, ?, 'admin', ?, 1, NOW())
        ");
        $names = explode(' ', $companyName, 2);
        $firstName = $names[0];
        $lastName = $names[1] ?? 'Admin';
        $stmt->execute([$adminEmail, $adminPassword, $firstName, $lastName, $companyId]);
        
        // Create default departments
        $stmt = $conn->prepare("
            INSERT INTO departments (company_id, name, description, is_active, created_at) 
            VALUES 
            (?, 'İnsan Kaynakları', 'İK Departmanı', 1, NOW()),
            (?, 'Genel Müdürlük', 'Yönetim Departmanı', 1, NOW()),
            (?, 'Operasyon', 'Operasyon Departmanı', 1, NOW())
        ");
        $stmt->execute([$companyId, $companyId, $companyId]);
        
        // Create QR locations
        $locations = [
            ['Ana Giriş', 'GIRIS_' . $companyCode, 'entrance', 'Ana giriş kapısı'],
            ['Ofis', 'OFIS_' . $companyCode, 'office', 'Çalışma alanı'],
            ['Yemekhane', 'YEMEK_' . $companyCode, 'dining', 'Personel yemekhanesi'],
            ['Mola Alanı', 'MOLA_' . $companyCode, 'break', 'Dinlenme alanı']
        ];
        
        foreach ($locations as $index => $location) {
            $qrCode = 'QR_' . $companyCode . '_' . str_pad($index + 1, 3, '0', STR_PAD_LEFT);
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (
                    company_id, name, location_code, qr_code, 
                    location_type, description, is_active, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, 1, NOW())
            ");
            $stmt->execute([$companyId, $location[0], $location[1], $qrCode, $location[2], $location[3]]);
        }
        
        // Create work settings - with auto table creation and correct column names
        try {
            // First ensure table exists with correct schema
            $conn->exec("
                CREATE TABLE IF NOT EXISTS work_settings (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    monthly_hours INT DEFAULT 225,
                    weekly_hours INT DEFAULT 45,
                    daily_max_hours INT DEFAULT 11,
                    hourly_rate DECIMAL(10,2) DEFAULT 50.00,
                    overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
                    holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
                    weekly_holiday INT DEFAULT 1,
                    auto_schedule TINYINT(1) DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_company (company_id)
                )
            ");
            
            $stmt = $conn->prepare("
                INSERT INTO work_settings (
                    company_id, monthly_hours, weekly_hours, daily_max_hours,
                    hourly_rate, overtime_multiplier, holiday_multiplier, 
                    weekly_holiday, auto_schedule, created_at
                ) VALUES (?, 225, 45, 11, 50.00, 1.50, 2.00, 1, 1, NOW())
            ");
            $stmt->execute([$companyId]);
        } catch (PDOException $e) {
            // If still fails, create minimal settings
            try {
                $stmt = $conn->prepare("
                    INSERT INTO work_settings (company_id, created_at) 
                    VALUES (?, NOW())
                ");
                $stmt->execute([$companyId]);
            } catch (PDOException $e2) {
                // Continue without work settings - can be set later
            }
        }
        
        $conn->commit();
        
        $message = "✅ Şirket başarıyla oluşturuldu!<br>
            <strong>Giriş Bilgileri:</strong><br>
            • Şirket Kodu: <strong>$companyCode</strong><br>
            • E-posta: <strong>$adminEmail</strong><br>
            • Şifre: <strong>" . htmlspecialchars($adminPassword) . "</strong><br>
            • Şirket ID: <strong>$companyId</strong><br><br>
            🔗 <a href='../auth/company-login.php' class='text-blue-600 underline'>Şimdi giriş yapın</a>";
        $messageType = 'success';
        
    } catch (Exception $e) {
        if ($conn->inTransaction()) {
            $conn->rollback();
        }
        $message = "Hata: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Generate next company code
function generateNextCompanyCode($conn) {
    try {
        $stmt = $conn->query("SELECT company_code FROM companies ORDER BY company_code DESC LIMIT 1");
        $lastCode = $stmt->fetchColumn();
        
        if ($lastCode) {
            $letters = substr($lastCode, 0, 3);
            $number = intval(substr($lastCode, 3));
            $number++;
            
            if ($number > 99999) {
                // Increment letters
                $letters++;
                $number = 1;
            }
            
            return $letters . str_pad($number, 5, '0', STR_PAD_LEFT);
        }
        
        return 'AAA00001';
    } catch (Exception $e) {
        return 'AAA00001';
    }
}

$nextCompanyCode = 'AAA00001';
try {
    $db = new Database();
    $conn = $db->getConnection();
    $nextCompanyCode = generateNextCompanyCode($conn);
} catch (Exception $e) {
    // Use default code
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Şirket Ekle - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .form-group { margin-bottom: 1.5rem; }
        .form-label { display: block; font-weight: 500; color: #374151; margin-bottom: 0.5rem; }
        .form-input { width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.5rem; }
        .form-input:focus { outline: none; border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
        .btn-primary { background-color: #3b82f6; color: white; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: 500; }
        .btn-primary:hover { background-color: #2563eb; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="max-w-4xl mx-auto py-8 px-4">
        <!-- Header -->
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Yeni Şirket Ekle</h1>
            <p class="text-gray-600 mt-2">Sistemde yeni bir şirket kaydı oluşturun</p>
        </div>

        <!-- Back Button -->
        <div class="mb-6">
            <a href="../super-admin/index.php" class="text-blue-600 hover:text-blue-800">
                ← Süper Admin Paneline Dön
            </a>
        </div>

        <!-- Messages -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                    'bg-red-100 text-red-800 border border-red-200'; 
            ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Company Addition Form -->
        <div class="bg-white shadow rounded-lg">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Şirket Bilgileri</h2>
                <p class="text-sm text-gray-500 mt-1">Tüm gerekli alanları doldurun</p>
            </div>
            
            <div class="p-6">
                <form method="POST" class="space-y-6">
                    <!-- Company Type -->
                    <div class="form-group">
                        <label for="company_type" class="form-label">Şirket Türü *</label>
                        <select id="company_type" name="company_type" required class="form-input">
                            <option value="corporate">🏢 Tüzel Kişi</option>
                            <option value="individual">👤 Gerçek Kişi</option>
                        </select>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Company Name -->
                        <div class="form-group">
                            <label for="company_name" class="form-label">Şirket Adı *</label>
                            <input type="text" id="company_name" name="company_name" required 
                                   class="form-input" placeholder="Örnek: ABC İnşaat Ltd. Şti.">
                        </div>

                        <!-- Company Code -->
                        <div class="form-group">
                            <label for="company_code" class="form-label">Şirket Kodu *</label>
                            <input type="text" id="company_code" name="company_code" required 
                                   class="form-input" value="<?php echo htmlspecialchars($nextCompanyCode); ?>" 
                                   placeholder="Örnek: ABC12345">
                        </div>

                        <!-- Admin Email -->
                        <div class="form-group">
                            <label for="admin_email" class="form-label">Yönetici E-posta *</label>
                            <input type="email" id="admin_email" name="admin_email" required 
                                   class="form-input" placeholder="admin@sirket.com">
                        </div>

                        <!-- Admin Password -->
                        <div class="form-group">
                            <label for="admin_password" class="form-label">Yönetici Şifresi *</label>
                            <input type="password" id="admin_password" name="admin_password" required 
                                   class="form-input" placeholder="Güvenli şifre girin">
                        </div>

                        <!-- Phone -->
                        <div class="form-group">
                            <label for="phone" class="form-label">Telefon</label>
                            <input type="tel" id="phone" name="phone" 
                                   class="form-input" placeholder="0212 XXX XX XX">
                        </div>

                        <!-- Tax Number -->
                        <div class="form-group">
                            <label for="tax_number" class="form-label">Vergi No</label>
                            <input type="text" id="tax_number" name="tax_number" 
                                   class="form-input" placeholder="1234567890">
                        </div>
                    </div>

                    <!-- Address -->
                    <div class="form-group">
                        <label for="address" class="form-label">Adres</label>
                        <textarea id="address" name="address" rows="3" 
                                  class="form-input" placeholder="Şirket adresini girin"></textarea>
                    </div>

                    <!-- Submit Button -->
                    <div class="flex justify-end space-x-4">
                        <a href="../super-admin/index.php" 
                           class="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                            İptal
                        </a>
                        <button type="submit" class="btn-primary">
                            ✅ Şirket Oluştur
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Info Box -->
        <div class="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 class="font-semibold text-blue-900 mb-2">Şirket Oluşturulunca Neler Olur?</h3>
            <ul class="text-blue-800 text-sm space-y-1">
                <li>• Şirket kaydı oluşturulur</li>
                <li>• Yönetici kullanıcısı otomatik oluşturulur</li>
                <li>• 3 varsayılan departman eklenir (İK, Genel Müdürlük, Operasyon)</li>
                <li>• 4 QR lokasyon oluşturulur (Giriş, Ofis, Yemekhane, Mola)</li>
                <li>• Çalışma ayarları tanımlanır (225 saat/ay, 45 saat/hafta)</li>
                <li>• Şirket hemen kullanıma hazır olur</li>
            </ul>
        </div>
    </div>
</body>
</html>