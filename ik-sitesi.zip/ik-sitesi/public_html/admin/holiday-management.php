<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/holiday-calculator.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as admin
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$message = '';
$messageType = '';

// Initialize variables
$holidays = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $companyId = $_SESSION['company_id'] ?? null;
    if (!$companyId && $_SESSION['user_role'] === 'super_admin') {
        $companyId = $_GET['company_id'] ?? null;
    }
    
    if (!$companyId) {
        throw new Exception('Şirket ID bulunamadı');
    }
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'populate_year') {
            $year = (int)$_POST['year'];
            if ($year >= 2020 && $year <= 2030) {
                try {
                    // Create table if it doesn't exist
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS public_holidays (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            holiday_date DATE NOT NULL,
                            holiday_name VARCHAR(255) NOT NULL,
                            holiday_type ENUM('national', 'religious', 'company') DEFAULT 'national',
                            description TEXT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            UNIQUE KEY unique_company_date (company_id, holiday_date)
                        )
                    ");
                    
                    if (class_exists('TurkishHolidayCalculator')) {
                        $inserted = TurkishHolidayCalculator::populateHolidaysForYear($companyId, $year, $conn);
                    } else {
                        // Fallback: Add basic Turkish holidays manually
                        $holidays = [
                            ['date' => "$year-01-01", 'name' => 'Yılbaşı', 'type' => 'national'],
                            ['date' => "$year-04-23", 'name' => 'Ulusal Egemenlik ve Çocuk Bayramı', 'type' => 'national'],
                            ['date' => "$year-05-01", 'name' => 'İşçi Bayramı', 'type' => 'national'],
                            ['date' => "$year-05-19", 'name' => 'Atatürk\'ü Anma, Gençlik ve Spor Bayramı', 'type' => 'national'],
                            ['date' => "$year-07-15", 'name' => 'Demokrasi ve Millî Birlik Günü', 'type' => 'national'],
                            ['date' => "$year-08-30", 'name' => 'Zafer Bayramı', 'type' => 'national'],
                            ['date' => "$year-10-29", 'name' => 'Cumhuriyet Bayramı', 'type' => 'national']
                        ];
                        
                        $inserted = 0;
                        $stmt = $conn->prepare("
                            INSERT INTO public_holidays (company_id, holiday_date, holiday_name, holiday_type) 
                            VALUES (?, ?, ?, ?) 
                            ON DUPLICATE KEY UPDATE holiday_name = VALUES(holiday_name)
                        ");
                        
                        foreach ($holidays as $holiday) {
                            $stmt->execute([$companyId, $holiday['date'], $holiday['name'], $holiday['type']]);
                            if ($stmt->rowCount() > 0) $inserted++;
                        }
                    }
                    
                    $message = "✅ $year yılı için $inserted tatil günü eklendi!";
                    $messageType = "success";
                } catch (Exception $e) {
                    $message = "❌ Hata: " . $e->getMessage();
                    $messageType = "error";
                }
            } else {
                $message = "❌ Geçersiz yıl seçimi";
                $messageType = "error";
            }
        }
        
        if ($action === 'add_custom') {
            $holidayDate = $_POST['holiday_date'] ?? '';
            $holidayName = trim($_POST['holiday_name'] ?? '');
            $holidayType = $_POST['holiday_type'] ?? 'company';
            $description = trim($_POST['description'] ?? '');
            
            if ($holidayDate && $holidayName) {
                try {
                    // Create table if it doesn't exist
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS public_holidays (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            holiday_date DATE NOT NULL,
                            holiday_name VARCHAR(255) NOT NULL,
                            holiday_type ENUM('national', 'religious', 'company') DEFAULT 'national',
                            description TEXT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            UNIQUE KEY unique_company_date (company_id, holiday_date)
                        )
                    ");
                    
                    $stmt = $conn->prepare("
                        INSERT INTO public_holidays 
                        (company_id, holiday_date, holiday_name, holiday_type, description) 
                        VALUES (?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE
                        holiday_name = VALUES(holiday_name),
                        holiday_type = VALUES(holiday_type),
                        description = VALUES(description)
                    ");
                    
                    $stmt->execute([$companyId, $holidayDate, $holidayName, $holidayType, $description]);
                    $message = "✅ Özel tatil günü eklendi: $holidayName";
                    $messageType = "success";
                } catch (Exception $e) {
                    $message = "❌ Hata: " . $e->getMessage();
                    $messageType = "error";
                }
            } else {
                $message = "❌ Lütfen tarih ve tatil adını giriniz";
                $messageType = "error";
            }
        }
        
        if ($action === 'delete_holiday') {
            $holidayId = (int)$_POST['holiday_id'];
            $stmt = $conn->prepare("DELETE FROM public_holidays WHERE id = ? AND company_id = ?");
            $stmt->execute([$holidayId, $companyId]);
            $message = "✅ Tatil günü silindi";
            $messageType = "success";
        }
    }
    
    // Get existing holidays - with table creation fallback
    try {
        $stmt = $conn->prepare("
            SELECT * FROM public_holidays 
            WHERE company_id = ? 
            ORDER BY holiday_date DESC
        ");
        $stmt->execute([$companyId]);
        $holidays = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Create table if it doesn't exist
        $conn->exec("
            CREATE TABLE IF NOT EXISTS public_holidays (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                holiday_date DATE NOT NULL,
                holiday_name VARCHAR(255) NOT NULL,
                holiday_type ENUM('national', 'religious', 'company') DEFAULT 'national',
                description TEXT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_company_date (company_id, holiday_date)
            )
        ");
        $holidays = []; // Empty array for new table
    }
    
} catch (Exception $e) {
    $message = "❌ Hata: " . $e->getMessage();
    $messageType = "error";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tatil Günleri Yönetimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">🎉</span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Tatil Günleri Yönetimi</h1>
            <p class="text-gray-600 mt-2">Resmi tatil ve özel günleri yönetin</p>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                    ($messageType === 'error' ? 'bg-red-100 text-red-800 border border-red-200' : 
                    'bg-yellow-100 text-yellow-800 border border-yellow-200'); 
            ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Actions Panel -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <!-- Auto-populate holidays -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4">🤖 Otomatik Tatil Ekleme</h2>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="populate_year">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Yıl Seçin</label>
                        <select 
                            name="year" 
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                            <?php for ($y = date('Y') - 1; $y <= date('Y') + 5; $y++): ?>
                                <option value="<?php echo $y; ?>" <?php echo $y == date('Y') ? 'selected' : ''; ?>>
                                    <?php echo $y; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <button 
                        type="submit" 
                        class="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                        🎯 Türk Resmi Tatillerini Ekle
                    </button>
                </form>
                <div class="mt-4 text-xs text-gray-500">
                    <p>• Ulusal bayramlar</p>
                    <p>• Ramazan ve Kurban bayramları</p>
                    <p>• Otomatik tarih hesaplama</p>
                </div>
            </div>

            <!-- Custom holiday -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-lg font-semibold text-gray-800 mb-4">➕ Özel Tatil Ekleme</h2>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="add_custom">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tarih</label>
                        <input 
                            type="date" 
                            name="holiday_date" 
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tatil Adı</label>
                        <input 
                            type="text" 
                            name="holiday_name" 
                            placeholder="Örn: Şirket Kuruluş Günü"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                            required
                        >
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tür</label>
                        <select 
                            name="holiday_type" 
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        >
                            <option value="national">Ulusal</option>
                            <option value="religious">Dini</option>
                            <option value="company">Şirket Özel</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Açıklama (Opsiyonel)</label>
                        <textarea 
                            name="description" 
                            rows="2"
                            placeholder="Tatil günü hakkında kısa açıklama"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        ></textarea>
                    </div>
                    <button 
                        type="submit" 
                        class="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                    >
                        ➕ Özel Tatil Ekle
                    </button>
                </form>
            </div>
        </div>

        <!-- Holidays List -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">📅 Mevcut Tatil Günleri</h2>
            
            <?php if (empty($holidays)): ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="text-4xl mb-2">📝</div>
                    <p>Henüz tatil günü tanımlanmamış.</p>
                    <p class="text-sm mt-1">Yukarıdaki formları kullanarak tatil günleri ekleyebilirsiniz.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tarih</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tatil Adı</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tür</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Açıklama</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlem</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($holidays as $holiday): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo date('d.m.Y', strtotime($holiday['holiday_date'])); ?>
                                        <div class="text-xs text-gray-500">
                                            <?php echo date('l', strtotime($holiday['holiday_date'])); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <?php echo htmlspecialchars($holiday['holiday_name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                            <?php 
                                            echo $holiday['holiday_type'] === 'national' ? 'bg-blue-100 text-blue-800' : 
                                                ($holiday['holiday_type'] === 'religious' ? 'bg-green-100 text-green-800' : 
                                                'bg-purple-100 text-purple-800'); 
                                            ?>">
                                            <?php 
                                            echo $holiday['holiday_type'] === 'national' ? '🇹🇷 Ulusal' : 
                                                ($holiday['holiday_type'] === 'religious' ? '🕌 Dini' : 
                                                '🏢 Şirket'); 
                                            ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-500">
                                        <?php echo htmlspecialchars($holiday['description'] ?? '-'); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <form method="POST" class="inline" onsubmit="return confirm('Bu tatil günü silinsin mi?')">
                                            <input type="hidden" name="action" value="delete_holiday">
                                            <input type="hidden" name="holiday_id" value="<?php echo $holiday['id']; ?>">
                                            <button type="submit" class="text-red-600 hover:text-red-900">
                                                🗑️ Sil
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Navigation -->
        <div class="text-center mt-6 space-y-3">
            <a href="../dashboard/company-dashboard.php" class="inline-block text-indigo-600 hover:text-indigo-500 font-medium">
                ← Yönetici Paneli
            </a>
        </div>
    </div>
</body>
</html>