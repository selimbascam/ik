<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Debug mode - remove after fixing
echo "<!-- DEBUG: QR Generator loading... -->";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Debug session
echo "<!-- DEBUG: Session started, company_id: " . ($_SESSION['company_id'] ?? 'NONE') . " -->";
echo "<!-- DEBUG: All session vars: " . print_r($_SESSION, true) . " -->";

// Check authentication
if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

require_once '../includes/config.php';
require_once '../includes/database.php';

// Akıllı location type detection fonksiyonu - en başta tanımlanmalı
function detectLocationTypeFromName($name, $current_type) {
    $name_lower = strtolower(trim($name));
    
    // Çıkış patterns
    if (strpos($name_lower, 'çıkış') !== false || strpos($name_lower, 'exit') !== false) {
        return 'check_out';
    } 
    // Giriş patterns  
    elseif (strpos($name_lower, 'giriş') !== false || strpos($name_lower, 'entrance') !== false) {
        return 'check_in';
    } 
    // Çay molası patterns
    elseif (strpos($name_lower, 'çay') !== false || strpos($name_lower, 'tea') !== false) {
        return 'tea_break';
    } 
    // Yemek molası patterns
    elseif (strpos($name_lower, 'yemek') !== false || strpos($name_lower, 'lunch') !== false) {
        return 'lunch_break';
    } 
    // Sigara molası patterns
    elseif (strpos($name_lower, 'sigara') !== false || strpos($name_lower, 'smoke') !== false) {
        return 'smoke_break';
    }
    // Genel mola patterns - en yaygın kullanım
    elseif (strpos($name_lower, 'mola') !== false || strpos($name_lower, 'break') !== false || 
            strpos($name_lower, 'ara') !== false || strpos($name_lower, 'dinlenme') !== false) {
        return 'tea_break'; // Default olarak çay molası
    }
    
    return $current_type; // Değişiklik yok
}

$success = '';
$error = '';
$db = new Database();
$conn = $db->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create_location') {
        $name = trim($_POST['name'] ?? '');
        $location_type = $_POST['location_type'] ?? 'general_gate';
        $gate_behavior = $_POST['gate_behavior'] ?? null;
        $description = trim($_POST['description'] ?? '');
        $latitude = floatval($_POST['latitude'] ?? 0);
        $longitude = floatval($_POST['longitude'] ?? 0);
        $address = trim($_POST['address'] ?? '');
        
        if (empty($name)) {
            $error = "Lokasyon adı zorunludur!";
        } elseif ($latitude == 0 || $longitude == 0) {
            $error = "Geçerli koordinatlar gereklidir!";
        } else {
            // OTOMATIK TÜR TESPİTİ: İsme göre location type'ı otomatik belirle
            $auto_detected_type = detectLocationTypeFromName($name, $location_type);
            $final_location_type = $auto_detected_type;
            
            // Debug: Log the type detection
            error_log("DEBUG: Name='{$name}', Original type='{$location_type}', Detected type='{$auto_detected_type}', Final type='{$final_location_type}'");
            
            // DÜZGÜN QR KOD YAPISI: Şirket + Hareket + Konum
            $location_code = 'LOC_' . strtoupper(substr(md5($name . time()), 0, 8));
            
            // Hareket tipini belirle (giriş → work_start, çıkış → work_end, mola → break_start)
            $movement_type = '';
            switch($final_location_type) {
                case 'check_in':
                    $movement_type = 'work_start';
                    break;
                case 'check_out':
                    $movement_type = 'work_end';
                    break;
                case 'tea_break':
                case 'lunch_break':
                case 'smoke_break':
                    $movement_type = 'break_start';
                    break;
                default:
                    $movement_type = 'general';
            }
            
            try {
                // Önce location'ı ekle (qr_code şimdilik boş)
                $stmt = $conn->prepare("INSERT INTO qr_locations 
                    (company_id, name, location_code, qr_code, location_type, gate_behavior, description, latitude, longitude, address, is_active) 
                    VALUES (?, ?, ?, '', ?, ?, ?, ?, ?, ?, 1)");
                
                if ($stmt->execute([
                    $_SESSION['company_id'], 
                    $name, 
                    $location_code,
                    $final_location_type,
                    $gate_behavior,
                    $description, 
                    $latitude, 
                    $longitude, 
                    $address
                ])) {
                    // Eklenen location'ın ID'sini al
                    $new_location_id = $conn->lastInsertId();
                    
                    // QR KOD İÇERİĞİ: şirket_id|hareket_tipi|konum_id|lat,lng
                    $qr_code_content = "{$_SESSION['company_id']}|{$movement_type}|{$new_location_id}|{$latitude},{$longitude}";
                    
                    // QR kod içeriğini güncelle
                    $update_stmt = $conn->prepare("UPDATE qr_locations SET qr_code = ? WHERE id = ?");
                    $update_stmt->execute([$qr_code_content, $new_location_id]);
                    
                    $type_message = ($auto_detected_type !== $location_type) ? 
                        " (Otomatik tespit: {$auto_detected_type})" : "";
                    $success = "✅ QR lokasyon başarıyla oluşturuldu: {$name} (ID: {$new_location_id}){$type_message}";
                } else {
                    $error = "❌ Lokasyon oluşturulamadı!";
                }
            } catch (Exception $e) {
                $error = "Veritabanı hatası: " . $e->getMessage();
            }
        }
    } elseif ($_POST['action'] === 'delete_location' && isset($_POST['location_id'])) {
        $location_id = intval($_POST['location_id']);
        try {
            $stmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
            if ($stmt->execute([$location_id, $_SESSION['company_id']])) {
                $success = "Lokasyon silindi!";
            } else {
                $error = "Lokasyon silinemedi!";
            }
        } catch (Exception $e) {
            $error = "Silme hatası: " . $e->getMessage();
        }
    }
}

// Handle location type updates FIRST - before loading locations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_location_type') {
    $location_id = intval($_POST['location_id']);
    $new_location_type = $_POST['new_location_type'];
    
    // ENHANCED DEBUG: Detailed location update debugging
    $debug_company_id = $_SESSION['company_id'] ?? 'NO_SESSION';
    $debug_user_id = $_SESSION['user_id'] ?? 'NO_USER';
    error_log("DEBUG: Update attempt - Location ID: {$location_id}, New Type: {$new_location_type}, Company ID: {$debug_company_id}, User ID: {$debug_user_id}");
    
    // First verify the record exists
    $checkStmt = $conn->prepare("SELECT id, name, location_type, company_id FROM qr_locations WHERE id = ?");
    $checkStmt->execute([$location_id]);
    $existingRecord = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$existingRecord) {
        error_log("DEBUG: CRITICAL - Location ID {$location_id} does not exist in qr_locations table!");
        
        // List all locations for debugging
        $allStmt = $conn->prepare("SELECT id, name, company_id FROM qr_locations ORDER BY id");
        $allStmt->execute();
        $allLocations = $allStmt->fetchAll(PDO::FETCH_ASSOC);
        error_log("DEBUG: All locations in database: " . print_r($allLocations, true));
        
        $error = "❌ Lokasyon bulunamadı! (ID: {$location_id})";
    } else {
        error_log("DEBUG: Found record - ID: {$existingRecord['id']}, Name: {$existingRecord['name']}, Type: {$existingRecord['location_type']}, Company: {$existingRecord['company_id']}");
        
        if ($existingRecord['company_id'] != $debug_company_id) {
            error_log("DEBUG: COMPANY MISMATCH - Record company: {$existingRecord['company_id']}, Session company: {$debug_company_id}");
            
            // Show all user's locations for debugging
            $userStmt = $conn->prepare("SELECT id, name, company_id FROM qr_locations WHERE company_id = ?");
            $userStmt->execute([$debug_company_id]);
            $userLocations = $userStmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("DEBUG: User's company locations: " . print_r($userLocations, true));
            
            $error = "❌ Bu lokasyon farklı bir şirkete ait! (Lokasyon şirket: {$existingRecord['company_id']}, Sizin şirket: {$debug_company_id})";
        } else {
            try {
                // Remove company_id from WHERE clause to test
                $stmt = $conn->prepare("UPDATE qr_locations SET location_type = ? WHERE id = ?");
                $result = $stmt->execute([$new_location_type, $location_id]);
                $affected_rows = $stmt->rowCount();
                
                error_log("DEBUG: Update result - Success: " . ($result ? 'YES' : 'NO') . ", Affected rows: {$affected_rows}");
                
                if ($result && $affected_rows > 0) {
                    $success = "✅ Lokasyon türü başarıyla güncellendi! (ID: {$location_id} → {$new_location_type})";
                    // Page refresh için header redirect ekle
                    header("Location: " . $_SERVER['PHP_SELF'] . "?updated={$location_id}&type={$new_location_type}");
                    exit();
                } else {
                    $error = "❌ Lokasyon türü güncellenemedi! (Affected rows: {$affected_rows})";
                }
            } catch (Exception $e) {
                $error = "❌ Güncelleme hatası: " . $e->getMessage();
                error_log("DEBUG: Update exception: " . $e->getMessage());
            }
        }
    }
}

// Success message from redirect
if (isset($_GET['updated'])) {
    $updated_id = $_GET['updated'];
    $updated_type = $_GET['type'] ?? 'unknown';
    $success = "✅ Lokasyon türü başarıyla güncellendi! (ID: {$updated_id} → {$updated_type})";
}

// Fetch locations with proper error handling
$locations = [];
try {
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? ORDER BY created_at DESC");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error = "Lokasyonlar yüklenemedi: " . $e->getMessage();
}

// Mevcut location type mapping - attendance sistemi ile uyumlu
$locationTypeMapping = [
    'check_in' => ['name' => 'Giriş Kapısı', 'activity' => 'work_start', 'color' => '#22c55e', 'icon' => '🟢'],
    'check_out' => ['name' => 'Çıkış Kapısı', 'activity' => 'work_end', 'color' => '#ef4444', 'icon' => '🔴'],
    'tea_break' => ['name' => 'Çay Molası', 'activity' => 'break_toggle', 'color' => '#3b82f6', 'icon' => '🟡'],
    'lunch_break' => ['name' => 'Yemek Molası', 'activity' => 'break_toggle', 'color' => '#f59e0b', 'icon' => '🍽️'],
    'smoke_break' => ['name' => 'Sigara Molası', 'activity' => 'break_toggle', 'color' => '#8b5cf6', 'icon' => '🚬'],
    'entrance' => ['name' => 'Ana Giriş', 'activity' => 'work_start', 'color' => '#10b981', 'icon' => '🔵'],
    'general_gate' => ['name' => 'Genel Kapı', 'activity' => 'user_choice', 'color' => '#6b7280', 'icon' => '🔵']
];

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Lokasyon Üretici - SZB İK Takip</title>
    <!-- QR Code Libraries with multiple fallbacks -->
    <script>
        // Local QRCode generation as primary method
        window.QRCodeGeneration = {
            toCanvas: function(canvas, text, options, callback) {
                try {
                    // Simple QR generation using external service as backup
                    const size = options.width || 200;
                    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(text)}`;
                    
                    const img = new Image();
                    img.crossOrigin = 'anonymous';
                    img.onload = function() {
                        const ctx = canvas.getContext('2d');
                        ctx.clearRect(0, 0, canvas.width, canvas.height);
                        ctx.drawImage(img, 0, 0, size, size);
                        if (callback) callback(null);
                    };
                    img.onerror = function() {
                        if (callback) callback(new Error('QR service failed'));
                    };
                    img.src = qrUrl;
                } catch (e) {
                    if (callback) callback(e);
                }
            }
        };
    </script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js" onerror="console.warn('Primary QR library failed, using backup')"></script>
    <script src="https://unpkg.com/qrcode@1.5.3/build/qrcode.min.js" onerror="console.warn('Secondary QR library failed')"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js" onerror="console.warn('Tertiary QR library failed')"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f7fa;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2rem;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #7f8c8d;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-section {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 30px;
        }
        
        .form-section h3 {
            margin-bottom: 20px;
            color: #2c3e50;
            font-size: 1.3rem;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e8ed;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #3498db;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
        }
        
        .btn-success {
            background: #27ae60;
            color: white;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
        
        .btn-secondary {
            background: #95a5a6;
            color: white;
        }
        
        .locations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }
        
        .location-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .location-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.12);
        }
        
        .location-card h4 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 1.2rem;
        }
        
        .location-card p {
            margin: 8px 0;
            color: #555;
            line-height: 1.5;
        }
        
        .location-card strong {
            color: #333;
        }
        
        .qr-container {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .qr-container canvas {
            border: 3px solid #e1e8ed;
            border-radius: 8px;
            background: white;
        }
        
        .coord-actions {
            margin-top: 10px;
        }
        
        .actions {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-top: 15px;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3498db;
            text-decoration: none;
            font-weight: 500;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        code {
            background: #f4f4f4;
            padding: 4px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
        }
        
        .system-info {
            background: #e8f4fd;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .system-info h4 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .system-info ul {
            padding-left: 20px;
        }
        
        .system-info li {
            margin-bottom: 5px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #7f8c8d;
        }
        
        .empty-state h4 {
            margin-bottom: 10px;
            color: #95a5a6;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="../dashboard/company-dashboard.php" class="back-link">← Dashboard'a Dön</a>
        
        <div class="header">
            <h1>🏢 QR Lokasyon Üretici</h1>
            <p>GPS koordinatlı QR kodlar oluşturun ve yönetin</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="system-info">
            <h4>🔧 Sistem Bilgileri</h4>
            <ul>
                <li><strong>Mevcut Lokasyon Sayısı:</strong> <?= count($locations) ?></li>
                <li><strong>QR Formatı:</strong> Sadece konum ID'si (attendance sistemi için)</li>
                <li><strong>Kapı Türleri:</strong> Giriş, Çıkış, Mola ve Genel kapılar</li>
                <li><strong>Desteklenen Aktiviteler:</strong> work_start, work_end, break_toggle</li>
            </ul>
        </div>
        
        <!-- Create New Location Form -->
        <div class="form-section">
            <h3>📍 Yeni QR Lokasyon Oluştur</h3>
            <form method="POST" onsubmit="return validateForm()">
                <input type="hidden" name="action" value="create_location">
                
                <div class="form-group">
                    <label>Lokasyon Adı *</label>
                    <input type="text" name="name" id="name" required placeholder="Örn: Ana Giriş Kapısı">
                </div>
                
                <div class="form-group">
                    <label>Kapı Türü ve İşlevi</label>
                    <select name="location_type" id="location_type" onchange="updateGateBehavior()">
                        <option value="check_in">🟢 Giriş Kapısı (work_start)</option>
                        <option value="check_out">🔴 Çıkış Kapısı (work_end)</option>
                        <option value="tea_break">🟡 Çay Molası (break toggle)</option>
                        <option value="lunch_break">🍽️ Yemek Molası (break toggle)</option>
                        <option value="smoke_break">🚬 Sigara Molası (break toggle)</option>
                        <option value="entrance" selected>🔵 Ana Giriş (work_start)</option>
                        <option value="general_gate">🔵 Genel Kapı (user_choice)</option>
                    </select>
                    <input type="hidden" name="gate_behavior" id="gate_behavior" value="user_choice">
                    <small style="color: #666; font-size: 14px; margin-top: 5px; display: block;">
                        <strong>Önemli:</strong> Giriş kapısı sadece işe başlama, çıkış kapısı sadece işten çıkış için kullanılır. 
                        Mola kapıları mola başlatma ve bitirme için kullanılır.
                    </small>
                </div>
                
                <div class="form-group">
                    <label>Enlem (Latitude) *</label>
                    <input type="number" id="latitude" name="latitude" step="0.00000001" min="-90" max="90" required placeholder="41.00820000">
                    <div class="coord-actions">
                        <button type="button" class="btn btn-success" onclick="getCurrentLocation()">📍 Mevcut Konumu Al</button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Boylam (Longitude) *</label>
                    <input type="number" id="longitude" name="longitude" step="0.00000001" min="-180" max="180" required placeholder="28.97840000">
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <input type="text" name="address" placeholder="Tam adres bilgisi (opsiyonel)">
                </div>
                
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" rows="3" placeholder="Lokasyon hakkında ek bilgiler (opsiyonel)"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">🎯 QR Lokasyon Oluştur</button>
            </form>
        </div>
        
        <!-- Existing Locations -->
        <div class="form-section">
            <h3>📋 Mevcut QR Lokasyonlar (<?= count($locations) ?>)</h3>
            
            <?php if (empty($locations)): ?>
                <div class="empty-state">
                    <h4>Henüz QR lokasyonu yok</h4>
                    <p>Yukarıdaki formu kullanarak ilk QR lokasyonunuzu oluşturun.</p>
                </div>
            <?php else: ?>
                <div class="locations-grid">
                    <?php foreach ($locations as $location): 
                        // Otomatik tür düzeltme kontrolü
                        $suggested_type = detectLocationTypeFromName($location['name'], $location['location_type']);
                        $needs_correction = $suggested_type !== $location['location_type'];
                        
                        $typeInfo = $locationTypeMapping[$location['location_type']] ?? $locationTypeMapping['general_gate'];
                        $suggestedTypeInfo = $locationTypeMapping[$suggested_type] ?? $typeInfo;
                    ?>
                        <div class="location-card" <?= $needs_correction ? 'style="border: 2px solid #f39c12;"' : '' ?>>
                            <h4><?= $typeInfo['icon'] ?> <?= htmlspecialchars($location['name']) ?></h4>
                            <?php if ($needs_correction): ?>
                                <div style="background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0; border: 1px solid #ffc107;">
                                    <strong>⚠️ Tür Düzeltme Önerisi:</strong><br>
                                    <small>Mevcut: <?= $typeInfo['name'] ?> (<?= $typeInfo['activity'] ?>)</small><br>
                                    <small style="color: #f39c12;">Önerilen: <?= $suggestedTypeInfo['name'] ?> (<?= $suggestedTypeInfo['activity'] ?>)</small><br>
                                    <form method="POST" style="margin-top: 5px;">
                                        <input type="hidden" name="action" value="update_location_type">
                                        <input type="hidden" name="location_id" value="<?= $location['id'] ?>">
                                        <input type="hidden" name="new_location_type" value="<?= $suggested_type ?>">
                                        <button type="submit" class="btn" style="background: #f39c12; color: white; padding: 5px 10px; font-size: 12px;">
                                            🔧 Düzelt
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                            <p><strong>QR Kod:</strong> <code><?= htmlspecialchars($location['qr_code'] ?: $location['id']) ?></code></p>
                            <p><strong>Tür:</strong> <?= $typeInfo['icon'] ?> <?= $typeInfo['name'] ?> (<?= $typeInfo['activity'] ?>)</p>
                            <p><strong>ID:</strong> <?= htmlspecialchars($location['id']) ?></p>
                            <?php if ($location['latitude'] && $location['longitude']): ?>
                            <p><strong>Koordinatlar:</strong> <?= htmlspecialchars($location['latitude']) ?>, <?= htmlspecialchars($location['longitude']) ?></p>
                            <p><strong>Google Maps:</strong> 
                                <a href="https://www.google.com/maps?q=<?= $location['latitude'] ?>,<?= $location['longitude'] ?>" 
                                   target="_blank" 
                                   style="color: #3498db;">
                                   📍 Haritada Görüntüle
                                </a>
                            </p>
                            <?php endif; ?>
                            <?php if ($location['description']): ?>
                            <p><strong>Açıklama:</strong> <?= htmlspecialchars($location['description']) ?></p>
                            <?php endif; ?>
                            <div class="qr-container">
                                <canvas id="qr_<?= $location['id'] ?>" width="200" height="200"></canvas>
                            </div>
                            <div class="actions">
                                <button class="btn btn-success" onclick="downloadQR(<?= $location['id'] ?>, '<?= str_replace(' ', '_', htmlspecialchars($location['name'])) ?>')">
                                    📥 İndir
                                </button>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Bu lokasyonu silmek istediğinizden emin misiniz?')">
                                    <input type="hidden" name="action" value="delete_location">
                                    <input type="hidden" name="location_id" value="<?= $location['id'] ?>">
                                    <button type="submit" class="btn btn-danger">
                                        🗑️ Sil
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // PHP locations data to JavaScript
        const locations = <?= json_encode($locations) ?>;
        
        // Generate QR codes for all locations
        function generateAllQRCodes() {
            console.log('Generating QR codes for', locations.length, 'locations');
            
            locations.forEach(function(location) {
                generateQRForLocation(location);
            });
        }
        
        function generateQRForLocation(location) {
            try {
                const canvas = document.getElementById('qr_' + location.id);
                if (!canvas) {
                    console.error('Canvas not found for location:', location.id);
                    return;
                }
                
                // DÜZELTME: QR kod içeriği sadece location ID olmalı (attendance system'in beklediği format)
                const qrData = (location.qr_code || location.id.toString()).toString();
                console.log('Generating QR for location', location.id, 'with data:', qrData);
                
                // Clear canvas first
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                
                // Try primary QRCode library
                if (typeof QRCode !== 'undefined' && QRCode.toCanvas) {
                    console.log('Using primary QRCode library for location', location.id);
                    QRCode.toCanvas(canvas, qrData, {
                        width: 200,
                        height: 200,
                        margin: 2,
                        color: {
                            dark: '#000000',
                            light: '#FFFFFF'
                        },
                        errorCorrectionLevel: 'M'
                    }, function(error) {
                        if (error) {
                            console.error('Primary QR generation error:', error);
                            tryBackupQRService(canvas, qrData, ctx);
                        } else {
                            console.log('QR generated successfully with primary library for location', location.id);
                            canvas.style.border = '2px solid #27ae60';
                            canvas.style.borderRadius = '8px';
                        }
                    });
                } else if (typeof QRCodeGeneration !== 'undefined') {
                    // Try backup QR service
                    console.log('Using backup QR service for location', location.id);
                    QRCodeGeneration.toCanvas(canvas, qrData, {
                        width: 200,
                        height: 200
                    }, function(error) {
                        if (error) {
                            console.error('Backup QR service error:', error);
                            tryFallbackQR(canvas, qrData, ctx);
                        } else {
                            console.log('QR generated successfully with backup service for location', location.id);
                            canvas.style.border = '2px solid #3498db';
                            canvas.style.borderRadius = '8px';
                        }
                    });
                } else if (typeof QRious !== 'undefined') {
                    // Try QRious library as fallback
                    console.log('Using QRious library as fallback for location', location.id);
                    try {
                        const qr = new QRious({
                            element: canvas,
                            value: qrData,
                            size: 200,
                            background: 'white',
                            foreground: 'black',
                            level: 'M'
                        });
                        console.log('QR generated successfully with QRious for location', location.id);
                        canvas.style.border = '2px solid #27ae60';
                        canvas.style.borderRadius = '8px';
                    } catch (e) {
                        console.error('QRious generation error:', e);
                        tryFallbackQR(canvas, qrData, ctx);
                    }
                } else {
                    console.warn('No QR libraries available, using manual fallback');
                    tryFallbackQR(canvas, qrData, ctx);
                }
            } catch (e) {
                console.error('Error processing location:', location, e);
            }
        }
        
        function tryBackupQRService(canvas, qrData, ctx) {
            // Try backup QR service if libraries fail
            console.log('Trying backup QR service for:', qrData);
            
            if (typeof QRCodeGeneration !== 'undefined') {
                QRCodeGeneration.toCanvas(canvas, qrData, {
                    width: 200,
                    height: 200
                }, function(error) {
                    if (error) {
                        console.error('Backup QR service failed:', error);
                        tryFallbackQR(canvas, qrData, ctx);
                    } else {
                        console.log('QR generated with backup service for:', qrData);
                        canvas.style.border = '2px solid #3498db';
                        canvas.style.borderRadius = '8px';
                    }
                });
            } else {
                tryFallbackQR(canvas, qrData, ctx);
            }
        }
        
        function tryFallbackQR(canvas, qrData, ctx) {
            // Enhanced manual QR-like pattern
            console.log('Using enhanced fallback for:', qrData);
            
            // Draw a more sophisticated pattern
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, 200, 200);
            
            // Draw border
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2;
            ctx.strokeRect(5, 5, 190, 190);
            
            // Draw QR-like patterns
            ctx.fillStyle = '#000000';
            
            // Corner detection patterns
            drawCornerPattern(ctx, 15, 15);
            drawCornerPattern(ctx, 155, 15);
            drawCornerPattern(ctx, 15, 155);
            
            // Center alignment pattern
            ctx.fillRect(85, 85, 30, 30);
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(95, 95, 10, 10);
            ctx.fillStyle = '#000000';
            
            // Data representation patterns
            for (let i = 0; i < qrData.length; i++) {
                const charCode = qrData.charCodeAt(i);
                const x = 30 + (i * 15) % 140;
                const y = 40 + Math.floor((i * 15) / 140) * 15;
                if (charCode % 2 === 0) {
                    ctx.fillRect(x, y, 8, 8);
                }
            }
            
            // Add text
            ctx.fillStyle = '#333333';
            ctx.font = 'bold 14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('QR CODE', 100, 175);
            ctx.font = '12px Arial';
            ctx.fillText('ID: ' + qrData, 100, 190);
            
            canvas.style.border = '2px solid #f39c12';
            canvas.style.borderRadius = '8px';
            console.log('Enhanced fallback QR pattern drawn for ID:', qrData);
        }
        
        function drawCornerPattern(ctx, x, y) {
            // Outer square
            ctx.fillRect(x, y, 30, 30);
            // Inner white square
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(x + 5, y + 5, 20, 20);
            // Inner black square
            ctx.fillStyle = '#000000';
            ctx.fillRect(x + 10, y + 10, 10, 10);
        }
        
        function drawManualQR(canvas, qrData, ctx) {
            // Manual QR-like pattern as fallback
            console.log('Using manual fallback for:', qrData);
            
            // Draw a simple pattern
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, 200, 200);
            
            // Draw border
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2;
            ctx.strokeRect(10, 10, 180, 180);
            
            // Draw some QR-like patterns
            ctx.fillStyle = '#000000';
            
            // Corner patterns
            for (let i = 0; i < 3; i++) {
                for (let j = 0; j < 3; j++) {
                    const x = 15 + (i * 170);
                    const y = 15 + (j * 170);
                    if ((i === 0 && j === 0) || (i === 2 && j === 0) || (i === 0 && j === 2)) {
                        ctx.fillRect(x, y, 20, 20);
                    }
                }
            }
            
            // Center pattern
            ctx.fillRect(90, 90, 20, 20);
            
            // Add text
            ctx.fillStyle = '#333333';
            ctx.font = 'bold 12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('QR CODE', 100, 130);
            ctx.font = '10px Arial';
            ctx.fillText('ID: ' + qrData, 100, 145);
            
            canvas.style.border = '2px solid #f39c12';
            canvas.style.borderRadius = '8px';
            console.log('Fallback QR pattern drawn for ID:', qrData);
        }
        
        // Get current location
        function getCurrentLocation() {
            if (!navigator.geolocation) {
                alert('Tarayıcınız GPS desteklemiyor!');
                return;
            }
            
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = '📍 Konum alınıyor...';
            btn.disabled = true;
            
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    document.getElementById('latitude').value = position.coords.latitude.toFixed(8);
                    document.getElementById('longitude').value = position.coords.longitude.toFixed(8);
                    
                    btn.textContent = '✅ Konum Alındı';
                    setTimeout(() => {
                        btn.textContent = originalText;
                        btn.disabled = false;
                    }, 2000);
                },
                function(error) {
                    btn.textContent = originalText;
                    btn.disabled = false;
                    
                    let errorMsg = 'GPS konumu alınamadı: ';
                    switch(error.code) {
                        case error.PERMISSION_DENIED:
                            errorMsg += 'Konum izni reddedildi';
                            break;
                        case error.POSITION_UNAVAILABLE:
                            errorMsg += 'Konum bilgisi mevcut değil';
                            break;
                        case error.TIMEOUT:
                            errorMsg += 'İstek zaman aşımına uğradı';
                            break;
                        default:
                            errorMsg += error.message;
                    }
                    alert(errorMsg);
                }
            );
        }
        
        // Download QR code
        function downloadQR(locationId, locationName) {
            const canvas = document.getElementById('qr_' + locationId);
            if (!canvas) {
                alert('QR kod bulunamadı!');
                return;
            }
            
            try {
                // Convert canvas to blob
                canvas.toBlob(function(blob) {
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.download = 'QR_' + locationName + '_' + locationId + '.png';
                    link.href = url;
                    link.click();
                    URL.revokeObjectURL(url);
                    
                    // Visual feedback
                    const btn = event.target;
                    const originalText = btn.textContent;
                    btn.textContent = '✅ İndirildi';
                    setTimeout(() => {
                        btn.textContent = originalText;
                    }, 2000);
                });
            } catch(e) {
                console.error('Download error:', e);
                alert('QR kod indirilemedi: ' + e.message);
            }
        }
        
        // Form validation
        function validateForm() {
            const name = document.getElementById('name').value.trim();
            const latitude = parseFloat(document.getElementById('latitude').value);
            const longitude = parseFloat(document.getElementById('longitude').value);
            
            if (!name) {
                alert('Lütfen lokasyon adı girin!');
                return false;
            }
            
            if (!latitude || !longitude || latitude === 0 || longitude === 0) {
                alert('Lütfen geçerli GPS koordinatları girin!');
                return false;
            }
            
            return true;
        }
        
        // Update gate behavior based on location type
        function updateGateBehavior() {
            const locationType = document.getElementById('location_type').value;
            const gateBehavior = document.getElementById('gate_behavior');
            
            switch(locationType) {
                case 'check_in':
                case 'entrance':
                    gateBehavior.value = 'work_start';
                    break;
                case 'check_out':
                    gateBehavior.value = 'work_end';
                    break;
                case 'tea_break':
                case 'lunch_break':
                case 'smoke_break':
                    gateBehavior.value = 'break_toggle';
                    break;
                default:
                    gateBehavior.value = 'user_choice';
            }
        }
        
        // Debug QR libraries
        function debugQRLibraries() {
            console.log('=== QR Library Debug ===');
            console.log('QRCode library available:', typeof QRCode !== 'undefined');
            console.log('QRCode.toCanvas available:', typeof QRCode !== 'undefined' && typeof QRCode.toCanvas === 'function');
            console.log('QRious library available:', typeof QRious !== 'undefined');
            
            if (typeof QRCode !== 'undefined') {
                console.log('QRCode object:', QRCode);
            }
            if (typeof QRious !== 'undefined') {
                console.log('QRious object:', QRious);
            }
            console.log('======================');
        }
        
        // Test QR generation with simple data
        function testQRGeneration() {
            console.log('Testing QR generation...');
            const testCanvas = document.createElement('canvas');
            testCanvas.width = 200;
            testCanvas.height = 200;
            
            if (typeof QRCode !== 'undefined' && QRCode.toCanvas) {
                QRCode.toCanvas(testCanvas, '1', {
                    width: 200,
                    height: 200,
                    margin: 2
                }, function(error) {
                    if (error) {
                        console.error('Test QR generation failed:', error);
                    } else {
                        console.log('✅ Test QR generation successful!');
                    }
                });
            } else {
                console.log('❌ QRCode library not available for test');
            }
        }
        
        // Initialize QR generation when page loads
        document.addEventListener('DOMContentLoaded', function() {
            console.log('QR Generator initialized - Modern version integrated');
            debugQRLibraries();
            testQRGeneration();
            
            // Wait a bit for libraries to load
            setTimeout(() => {
                console.log('Generating QR codes for locations...');
                generateAllQRCodes();
            }, 1000);
        });
    </script>
</body>
</html>