<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Test Page</h1>";

// Session test
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "<h2>Session Info:</h2>";
echo "Company ID: " . ($_SESSION['company_id'] ?? 'NOT SET') . "<br>";
echo "User ID: " . ($_SESSION['user_id'] ?? 'NOT SET') . "<br>";

// Database test  
try {
    require_once '../includes/config.php';
    echo "<h2>Config loaded successfully</h2>";
    
    require_once '../includes/database.php';
    echo "<h2>Database class loaded successfully</h2>";
    
    $db = new Database();
    $conn = $db->getConnection();
    echo "<h2>Database connection established</h2>";
    
    // Test query
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ?");
    $stmt->execute([$_SESSION['company_id'] ?? 0]);
    $result = $stmt->fetch();
    echo "<h2>QR Locations count: " . $result['count'] . "</h2>";
    
} catch (Exception $e) {
    echo "<h2 style='color: red;'>Error: " . $e->getMessage() . "</h2>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<h2>All tests completed</h2>";
?>