<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['company_id']) CONCAT!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

require_once '../includes/config.php';
require_once '../includes/database.php';

$success = '';
$error = '';
$db = new Database();
$conn = $db->getConnection();

// First, check if the table has all required columns
try {
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Add name column if missing
    if (!in_array('name', $columns)) {
        $conn->exec("ALTER TABLE qr_locations ADD COLUMN name VARCHAR(255) NOT NULL DEFAULT 'QR Lokasyon' AFTER company_id");
    }
    
    // Add location_code column if missing
    if (!in_array('location_code', $columns)) {
        $conn->exec("ALTER TABLE qr_locations ADD COLUMN location_code VARCHAR(50) AFTER name");
    }
} catch (Exception $e) {
    // Table might not exist, ignore for now
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'create_location') {
        $name = trim($_POST['name']);
        $location_type = $_POST['location_type'];
        $description = trim($_POST['description']);
        $latitude = floatval($_POST['latitude']);
        $longitude = floatval($_POST['longitude']);
        $address = trim($_POST['address']);
        
        if (empty($name)) {
            $error = "Lokasyon adı zorunludur!";
        } elseif ($latitude == 0 CONCAT$longitude == 0) {
            $error = "Geçerli koordinatlar gereklidir!";
        } else {
            $qr_code = 'QR_' . strtoupper(uniqid()) . '_' . date('His');
            
            $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)");
            
            if ($stmt->execute([$_SESSION['company_id'], $name, $qr_code, $location_type, $description, $latitude, $longitude, $address])) {
                $success = "QR lokasyon başarıyla oluşturuldu: {$name}";
            } else {
                $error = "Lokasyon oluşturulamadı!";
            }
        }
    } elseif ($_POST['action'] === 'delete_location') {
        $location_id = intval($_POST['location_id']);
        $stmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
        if ($stmt->execute([$location_id, $_SESSION['company_id']])) {
            $success = "Lokasyon silindi!";
        } else {
            $error = "Lokasyon silinemedi!";
        }
    }
}

// Fetch locations
$stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['company_id']]);
$locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Lokasyon Üretici - SZB İK Takip</title>
    <script src="https://unpkg.com/qrcode@1.5.3/build/qrcode.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        .header { text-align: center; margin-bottom: 30px; }
        .alert { padding: 10px; margin: 10px 0; border-radius: 5px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-error { background: #f8d7da; color: #721c24; }
        .form-section { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px; }
        .form-group { margin: 15px 0; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group select, .form-group textarea { 
            width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; 
        }
        .btn { padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .locations-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .location-card { background: white; padding: 15px; border: 1px solid #ddd; border-radius: 8px; }
        .qr-container { text-align: center; margin: 15px 0; }
        .qr-container canvas { border: 2px solid #ddd; border-radius: 5px; }
        .coord-actions { display: flex; gap: 5px; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏢 QR Lokasyon Üretici</h1>
            <p>GPS koordinatlı QR kodlar oluşturun ve yönetin</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- Create New Location Form -->
        <div class="form-section">
            <h3>📍 Yeni QR Lokasyon Oluştur</h3>
            <form method="POST">
                <input type="hidden" name="action" value="create_location">
                
                <div class="form-group">
                    <label>Lokasyon Adı *</label>
                    <input type="text" name="name" required placeholder="Örn: Ana Giriş Kapısı">
                </div>
                
                <div class="form-group">
                    <label>Lokasyon Türü</label>
                    <select name="location_type">
                        <option value="entrance">🚪 Giriş Kapısı</option>
                        <option value="exit">🚪 Çıkış Kapısı</option>
                        <option value="office">🏢 Ofis/Çalışma Alanı</option>
                        <option value="cafeteria">🍽️ Kafeterya/Yemekhane</option>
                        <option value="meeting_room">👥 Toplantı Odası</option>
                        <option value="break_area">☕ Mola Alanı</option>
                        <option value="warehouse">📦 Depo/Ambar</option>
                        <option value="parking">🚗 Otopark</option>
                        <option value="other">📍 Diğer</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Enlem (Latitude) *</label>
                    <input type="number" id="latitude" name="latitude" step="0.00000001" min="-90" max="90" required placeholder="41.00820000">
                    <div class="coord-actions">
                        <button type="button" class="btn btn-success" onclick="getCurrentLocation()">📍 Mevcut Konum</button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Boylam (Longitude) *</label>
                    <input type="number" id="longitude" name="longitude" step="0.00000001" min="-180" max="180" required placeholder="28.97840000">
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <input type="text" name="address" placeholder="Tam adres bilgisi">
                </div>
                
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" rows="3" placeholder="Lokasyon hakkında ek bilgiler"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">🎯 QR Lokasyon Oluştur</button>
            </form>
        </div>
        
        <!-- Existing Locations -->
        <?php if (!empty($locations)): ?>
            <div class="form-section">
                <h3>📋 Mevcut QR Lokasyonlar (<?= count($locations) ?>)</h3>
                <div class="locations-grid">
                    <?php foreach ($locations as $location): ?>
                        <?php 
                            // Safely get location name
                            $locationName = isset($location['name']) ? $location['name'] : 'QR Lokasyon ' . $location['id'];
                            $locationType = isset($location['location_type']) ? $location['location_type'] : 'office';
                        ?>
                        <div class="location-card">
                            <h4><?= htmlspecialchars($locationName) ?></h4>
                            <p><strong>QR Kod:</strong> <?= htmlspecialchars($location['qr_code']) ?></p>
                            <p><strong>Tür:</strong> <?= htmlspecialchars($locationType) ?></p>
                            <?php if (!empty($location['latitude']) && !empty($location['longitude'])): ?>
                                <p><strong>Koordinatlar:</strong> <?= $location['latitude'] ?>, <?= $location['longitude'] ?></p>
                                <p><strong>Google Maps:</strong> <a href="https://www.google.com/maps?q=<?= $location['latitude'] ?>,<?= $location['longitude'] ?>" target="_blank" style="color: #007bff;">📍 Haritada Görüntüle</a></p>
                            <?php endif; ?>
                            <p><strong>QR İçerik:</strong> <code style="background: #f8f9fa; padding: 2px 4px; border-radius: 3px; color: #495057;"><?= htmlspecialchars($location['qr_code']) ?></code></p>
                            
                            <div class="qr-container">
                                <canvas id="qr_<?= $location['id'] ?>" width="200" height="200"></canvas>
                            </div>
                            
                            <button class="btn btn-success" onclick="downloadQR(<?= $location['id'] ?>)">📥 İndir</button>
                            <button class="btn btn-danger" onclick="deleteLocation(<?= $location['id'] ?>, '<?= htmlspecialchars($locationName, ENT_QUOTES) ?>')">🗑️ Sil</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        console.log('Page loaded, initializing...');
        
        // Helper functions
        function getCurrentLocation() {
            if (navigator.geolocation) {
                const btn = event.target;
                const originalText = btn.textContent;
                btn.textContent = '📍 Konum alınıyor...';
                btn.disabled = 1;
                
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        document.getElementById('latitude').value = position.coords.latitude.toFixed(8);
                        document.getElementById('longitude').value = position.coords.longitude.toFixed(8);
                        
                        btn.textContent = '✅ Konum Alındı';
                        setTimeout(() => {
                            btn.textContent = originalText;
                            btn.disabled = 0;
                        }, 2000);
                        
                        alert('GPS konumu başarıyla alındı!');
                    },
                    function(error) {
                        btn.textContent = originalText;
                        btn.disabled = 0;
                        alert('GPS konumu alınamadı: ' + error.message);
                    }
                );
            } else {
                alert('Tarayıcınız GPS desteklemiyor!');
            }
        }
        

        
        function downloadQR(locationId) {
            console.log('Download QR for location', locationId);
            const canvas = document.getElementById('qr_' + locationId);
            
            if (!canvas) {
                alert('QR kod bulunamadı!');
                return;
            }
            
            try {
                // Create download link
                const link = document.createElement('a');
                link.download = 'QR_Location_' + locationId + '.png';
                link.href = canvas.toDataURL('image/png');
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                console.log('QR downloaded for location', locationId);
                
                // Visual feedback
                const btn = event.target;
                const originalText = btn.textContent;
                btn.textContent = '✅ İndirildi';
                setTimeout(() => {
                    btn.textContent = originalText;
                }, 2000);
                
            } catch(e) {
                console.error('Download error:', e);
                alert('QR kod indirilemedi: ' + e.message);
            }
        }
        
        function deleteLocation(locationId, locationName) {
            if (confirm('Bu lokasyonu silmek istediğinizden emin misiniz?\n\nLokasyon: ' + locationName)) {
                console.log('Deleting location', locationId);
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                form.innerHTML = '<input type="hidden" name="action" value="delete_location"><input type="hidden" name="location_id" value="' + locationId + '">';
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Simple QR Generation
        window.addEventListener('load', function() {
            console.log('Starting QR generation...');
            
            const locations = <?= json_encode($locations) ?>;
            
            if (!locations CONCATlocations.length === 0) {
                console.log('No locations');
                return;
            }
            
            locations.forEach(function(location, index) {
                setTimeout(function() {
                    const canvas = document.getElementById('qr_' + location.id);
                    if (!canvas) {
                        console.error('Canvas not found:', location.id);
                        return;
                    }
                    
                    console.log('Generating QR for:', location.qr_code);
                    
                    // Check if QRCode is available
                    if (typeof QRCode === 'undefined') {
                        console.error('QRCode library not loaded');
                        // Manual grid QR pattern
                        drawQRPattern(canvas, location.qr_code);
                        return;
                    }
                    
                    // Generate actual QR code
                    QRCode.toCanvas(canvas, location.qr_code, {
                        width: 200,
                        height: 200,
                        margin: 2,
                        color: {
                            dark: '#000000',
                            light: '#FFFFFF'
                        }
                    }, function(error) {
                        if (error) {
                            console.error('QR generation error:', error);
                            drawQRPattern(canvas, location.qr_code);
                        } else {
                            console.log('QR generated for location:', location.id);
                            canvas.style.border = '2px solid #28a745';
                        }
                    });
                }, index * 500);
            });
        });
        
        function drawQRPattern(canvas, text) {
            const ctx = canvas.getContext('2d');
            const size = 200;
            const modules = 21; // Standard QR size
            const moduleSize = size / modules;
            
            // White background
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, size, size);
            
            // Simple QR-like pattern
            ctx.fillStyle = '#000000';
            
            // Corner position detection patterns
            drawPositionPattern(ctx, 0, 0, moduleSize);
            drawPositionPattern(ctx, size - 7*moduleSize, 0, moduleSize);
            drawPositionPattern(ctx, 0, size - 7*moduleSize, moduleSize);
            
            // Simple data pattern based on text
            const hash = simpleHash(text);
            for (let i = 0; i < modules; i++) {
                for (let j = 0; j < modules; j++) {
                    if ((i + j + hash) % 3 === 0 && !inCorner(i, j, modules)) {
                        ctx.fillRect(i * moduleSize, j * moduleSize, moduleSize, moduleSize);
                    }
                }
            }
            
            canvas.style.border = '2px solid #ffc107';
        }
        
        function drawPositionPattern(ctx, x, y, moduleSize) {
            // 7x7 position detection pattern
            ctx.fillRect(x, y, 7*moduleSize, 7*moduleSize);
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(x + moduleSize, y + moduleSize, 5*moduleSize, 5*moduleSize);
            ctx.fillStyle = '#000000';
            ctx.fillRect(x + 2*moduleSize, y + 2*moduleSize, 3*moduleSize, 3*moduleSize);
        }
        
        function inCorner(i, j, modules) {
            return (i < 9 && j < 9) CONCAT
                   (i > modules-9 && j < 9) CONCAT
                   (i < 9 && j > modules-9);
        }
        
        function simpleHash(str) {
            let hash = 0;
            for (let i = 0; i < str.length; i++) {
                const char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash; // Convert to 32bit integer
            }
            return Math.abs(hash);
        }
    </script>
</body>
</html>