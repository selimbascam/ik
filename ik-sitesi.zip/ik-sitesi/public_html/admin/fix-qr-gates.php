<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin authentication
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$message = '';
$messageType = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle QR gate fixes
    if (isset($_POST['action']) && $_POST['action'] === 'fix_qr_gates') {
        $fixedCount = 0;
        
        // 1. Add gate_behavior column if it doesn't exist
        try {
            $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
            if ($stmt->rowCount() === 0) {
                $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(50) DEFAULT 'user_choice'");
                echo "gate_behavior sütunu eklendi.<br>";
            }
        } catch (Exception $e) {
            echo "Gate behavior sütunu zaten mevcut.<br>";
        }
        
        // 2. Fix entrance gates (Giriş)
        $stmt = $conn->prepare("
            UPDATE qr_locations 
            SET location_type = 'entrance_gate', gate_behavior = 'work_start' 
            WHERE (name LIKE '%giriş%' OR name LIKE '%Giriş%' OR name LIKE '%GİRİŞ%' OR location_type = 'entrance')
        ");
        $stmt->execute();
        $entranceFixed = $stmt->rowCount();
        $fixedCount += $entranceFixed;
        
        // 3. Fix exit gates (Çıkış)
        $stmt = $conn->prepare("
            UPDATE qr_locations 
            SET location_type = 'exit_gate', gate_behavior = 'work_end' 
            WHERE (name LIKE '%çıkış%' OR name LIKE '%Çıkış%' OR name LIKE '%ÇIKIŞ%' OR location_type = 'exit')
        ");
        $stmt->execute();
        $exitFixed = $stmt->rowCount();
        $fixedCount += $exitFixed;
        
        // 4. Fix break gates (Mola)
        $stmt = $conn->prepare("
            UPDATE qr_locations 
            SET location_type = 'break_gate', gate_behavior = 'break_toggle' 
            WHERE (name LIKE '%mola%' OR name LIKE '%Mola%' OR name LIKE '%MOLA%' OR location_type = 'break_area' OR location_type = 'cafeteria')
        ");
        $stmt->execute();
        $breakFixed = $stmt->rowCount();
        $fixedCount += $breakFixed;
        
        // 5. Set general gates for everything else
        $stmt = $conn->prepare("
            UPDATE qr_locations 
            SET location_type = 'general_gate', gate_behavior = 'user_choice' 
            WHERE gate_behavior IS NULL OR gate_behavior = '' OR location_type NOT IN ('entrance_gate', 'exit_gate', 'break_gate')
        ");
        $stmt->execute();
        $generalFixed = $stmt->rowCount();
        $fixedCount += $generalFixed;
        
        $message = "✅ QR kapı düzeltmeleri tamamlandı!<br>";
        $message .= "- Giriş kapıları: {$entranceFixed} düzeltildi<br>";
        $message .= "- Çıkış kapıları: {$exitFixed} düzeltildi<br>";
        $message .= "- Mola kapıları: {$breakFixed} düzeltildi<br>";
        $message .= "- Genel kapılar: {$generalFixed} düzeltildi<br>";
        $message .= "Toplam {$fixedCount} QR lokasyonu güncellendi.";
        $messageType = 'success';
    }
    
    // Get current QR locations
    $companyId = $_SESSION['company_id'] ?? 1;
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? ORDER BY id");
    $stmt->execute([$companyId]);
    $qrLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $message = "❌ Hata: " . $e->getMessage();
    $messageType = 'error';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Kapı Düzeltmeleri - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">🛠️</span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">QR Kapı Düzeltmeleri</h1>
            <p class="text-gray-600 mt-2">QR kodlarının giriş/çıkış davranışlarını düzelt</p>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                    'bg-red-100 text-red-800 border border-red-200'; 
            ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Fix Button -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">🔧 Otomatik Düzeltme</h3>
            <p class="text-gray-600 mb-4">
                Bu işlem tüm QR lokasyonlarını isimlerine göre otomatik olarak doğru kapı türlerine ayarlar:
            </p>
            <ul class="text-sm text-gray-600 mb-4 space-y-1">
                <li>• "Giriş" içeren QR'lar → <strong>Giriş Kapısı</strong> (İşe başlama)</li>
                <li>• "Çıkış" içeren QR'lar → <strong>Çıkış Kapısı</strong> (İşten çıkış)</li>
                <li>• "Mola" içeren QR'lar → <strong>Mola Kapısı</strong> (Mola başlat/bitir)</li>
                <li>• Diğerleri → <strong>Genel Kapı</strong> (Kullanıcı seçimi)</li>
            </ul>
            
            <form method="POST" onsubmit="return confirm('QR kapı düzeltmeleri yapılsın mı?');">
                <input type="hidden" name="action" value="fix_qr_gates">
                <button type="submit" class="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors font-semibold">
                    🔧 QR Kapılarını Düzelt
                </button>
            </form>
        </div>

        <!-- Current QR Locations -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">📍 Mevcut QR Lokasyonları</h3>
            
            <?php if (empty($qrLocations)): ?>
                <p class="text-gray-600">Henüz QR lokasyonu bulunmuyor.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">İsim</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kapı Türü</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Davranış</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($qrLocations as $location): ?>
                                <?php
                                $gateTypes = [
                                    'entrance_gate' => ['🚪', 'Giriş Kapısı', 'text-green-600'],
                                    'exit_gate' => ['🚪', 'Çıkış Kapısı', 'text-red-600'],
                                    'break_gate' => ['☕', 'Mola Kapısı', 'text-yellow-600'],
                                    'general_gate' => ['🏢', 'Genel Kapı', 'text-blue-600']
                                ];
                                
                                $behaviors = [
                                    'work_start' => ['🟢', 'İşe Başlama'],
                                    'work_end' => ['🔴', 'İşten Çıkış'],
                                    'break_toggle' => ['🟡', 'Mola Aç/Kapat'],
                                    'user_choice' => ['🔄', 'Kullanıcı Seçimi']
                                ];
                                
                                $locationType = $location['location_type'] ?? 'general_gate';
                                $gateBehavior = $location['gate_behavior'] ?? 'user_choice';
                                
                                $gateInfo = $gateTypes[$locationType] ?? $gateTypes['general_gate'];
                                $behaviorInfo = $behaviors[$gateBehavior] ?? $behaviors['user_choice'];
                                ?>
                                <tr>
                                    <td class="px-4 py-4 text-sm text-gray-900"><?php echo $location['id']; ?></td>
                                    <td class="px-4 py-4 text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($location['name']); ?>
                                    </td>
                                    <td class="px-4 py-4 text-sm <?php echo $gateInfo[2]; ?>">
                                        <?php echo $gateInfo[0] . ' ' . $gateInfo[1]; ?>
                                    </td>
                                    <td class="px-4 py-4 text-sm">
                                        <?php echo $behaviorInfo[0] . ' ' . $behaviorInfo[1]; ?>
                                    </td>
                                    <td class="px-4 py-4 text-sm">
                                        <?php if ($location['is_active']): ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                                Aktif
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                                                Pasif
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Navigation -->
        <div class="text-center mt-6 space-y-3">
            <a href="qr-generator.php" class="inline-block text-indigo-600 hover:text-indigo-500 font-medium">
                ← QR Kod Yöneticisi
            </a>
            <br>
            <a href="../dashboard/company-dashboard.php" class="inline-block text-gray-600 hover:text-gray-500">
                Ana Panel
            </a>
        </div>
    </div>
</body>
</html>