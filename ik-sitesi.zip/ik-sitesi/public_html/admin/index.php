<?php
/**
 * Admin Panel Ana Sayfası
 */
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if user is logged in as company admin
if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../auth/company-login.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 1; // Default to 1 for super admin

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get company info
    $stmt = $conn->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$company_id]);
    $company = $stmt->fetch();
    
    if (!$company) {
        throw new Exception("Şirket bulunamadı");
    }
    
    // Get quick stats
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE company_id = ?");
    $stmt->execute([$company_id]);
    $employee_count = $stmt->fetch()['count'];
    
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM attendance_records WHERE company_id = ? AND DATE(recorded_at) = CURDATE()");
    $stmt->execute([$company_id]);
    $today_attendance = $stmt->fetch()['count'];
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
    $company = ['company_name' => 'Bilinmeyen Şirket'];
    $employee_count = 0;
    $today_attendance = 0;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">A</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Admin Panel</h1>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($company['company_name'] ?? 'Şirket Adı'); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            📊 Dashboard
                        </a>
                        <a href="../auth/logout.php" class="text-gray-600 hover:text-gray-900">
                            🚪 Çıkış
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Quick Stats -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                            <span class="text-white text-sm font-bold"><?php echo $employee_count; ?></span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Toplam Personel</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $employee_count; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                            <span class="text-white text-sm font-bold"><?php echo $today_attendance; ?></span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Bugünkü Devam</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $today_attendance; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                            <span class="text-white text-sm font-bold">✓</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Sistem Durumu</p>
                            <p class="text-2xl font-bold text-green-600">Aktif</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Admin Menu -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <a href="employee-management.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                        <span class="text-blue-600 text-xl">👥</span>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Personel Yönetimi</h3>
                    <p class="text-gray-600 text-sm">Personel ekleme, düzenleme ve takip</p>
                </a>

                <a href="qr-generator.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                        <span class="text-green-600 text-xl">📱</span>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">QR Kod Üreteci</h3>
                    <p class="text-gray-600 text-sm">QR kodları oluştur ve yönet</p>
                </a>

                <a href="attendance-tracking.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                        <span class="text-purple-600 text-xl">📋</span>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Devam Takibi</h3>
                    <p class="text-gray-600 text-sm">Personel devam kayıtlarını görüntüle</p>
                </a>

                <a href="reports.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                        <span class="text-orange-600 text-xl">📊</span>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Raporlar</h3>
                    <p class="text-gray-600 text-sm">Detaylı raporları görüntüle ve dışa aktar</p>
                </a>

                <a href="company-settings.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                        <span class="text-red-600 text-xl">⚙️</span>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Şirket Ayarları</h3>
                    <p class="text-gray-600 text-sm">Şirket bilgileri ve çalışma kuralları</p>
                </a>

                <a href="company-holiday-management.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div class="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                        <span class="text-indigo-600 text-xl">🏢</span>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Şirket Tatil Yönetimi</h3>
                    <p class="text-gray-600 text-sm">Tüm personeller için tatil günleri belirleme</p>
                </a>

                <a href="../view-device-records.php" class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                    <div class="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
                        <span class="text-teal-600 text-xl">📱</span>
                    </div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Cihaz Kayıtları</h3>
                    <p class="text-gray-600 text-sm">Personel cihaz ve lokasyon takibi</p>
                </a>
            </div>
        </div>
    </div>
</body>
</html>