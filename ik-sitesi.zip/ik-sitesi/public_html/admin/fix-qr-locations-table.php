<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    die("Unauthorized access");
}

require_once '../includes/config.php';
require_once '../includes/database.php';

$db = new Database();
$conn = $db->getConnection();

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<title>QR Locations Table Fix</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; }";
echo ".success { color: green; }";
echo ".error { color: red; }";
echo ".info { color: blue; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<h1>QR Locations Table Fix</h1>";

try {
    // Check if table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'qr_locations'");
    if ($stmt->rowCount() == 0) {
        echo "<p class='error'>qr_locations table does not exist. Creating it...</p>";
        
        // Create table with all required columns
        $sql = "CREATE TABLE IF NOT EXISTS qr_locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            name VARCHAR(255) NOT NULL DEFAULT 'QR Lokasyon',
            location_code VARCHAR(50),
            qr_code VARCHAR(100) NOT NULL,
            location_type VARCHAR(50) DEFAULT 'office',
            description TEXT,
            latitude DECIMAL(10, 8),
            longitude DECIMAL(11, 8),
            address VARCHAR(500),
            tolerance_radius INT DEFAULT 50,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURTIME()STAMP,
            updated_at TIMESTAMP DEFAULT CURTIME()STAMP ON UPDATE CURTIME()STAMP,
            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
            UNIQUE KEY unique_qr_code (qr_code),
            INDEX idx_company_id (company_id),
            INDEX idx_location_code (location_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        echo "<p class='success'>✅ qr_locations table created successfully!</p>";
    } else {
        echo "<p class='info'>qr_locations table exists. Checking columns...</p>";
        
        // Get existing columns
        $stmt = $conn->query("SHOW COLUMNS FROM qr_locations");
        $existingColumns = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $existingColumns[] = $row['Field'];
        }
        
        echo "<p>Existing columns: " . implode(', ', $existingColumns) . "</p>";
        
        // Add missing columns
        $requiredColumns = [
            'name' => "ADD COLUMN name VARCHAR(255) NOT NULL DEFAULT 'QR Lokasyon' AFTER company_id",
            'location_code' => "ADD COLUMN location_code VARCHAR(50) AFTER name",
            'location_type' => "ADD COLUMN location_type VARCHAR(50) DEFAULT 'office' AFTER qr_code",
            'description' => "ADD COLUMN description TEXT AFTER location_type",
            'latitude' => "ADD COLUMN latitude DECIMAL(10, 8) AFTER description",
            'longitude' => "ADD COLUMN longitude DECIMAL(11, 8) AFTER latitude",
            'address' => "ADD COLUMN address VARCHAR(500) AFTER longitude",
            'tolerance_radius' => "ADD COLUMN tolerance_radius INT DEFAULT 50 AFTER address",
            'is_active' => "ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER tolerance_radius",
            'created_at' => "ADD COLUMN created_at TIMESTAMP DEFAULT CURTIME()STAMP",
            'updated_at' => "ADD COLUMN updated_at TIMESTAMP DEFAULT CURTIME()STAMP ON UPDATE CURTIME()STAMP"
        ];
        
        foreach ($requiredColumns as $column => $addQuery) {
            if (!in_array($column, $existingColumns)) {
                try {
                    $conn->exec("ALTER TABLE qr_locations " . $addQuery);
                    echo "<p class='success'>✅ Added column: {$column}</p>";
                } catch (Exception $e) {
                    echo "<p class='error'>❌ Failed to add column {$column}: " . $e->getMessage() . "</p>";
                }
            } else {
                echo "<p class='info'>Column {$column} already exists</p>";
            }
        }
    }
    
    // Update existing records that have NULL name
    $conn->exec("UPDATE qr_locations SET name = CONCAT('QR Lokasyon ', id) WHERE name IS NULL OR name = ''");
    echo "<p class='success'>✅ Updated NULL names</p>";
    
    // Display current data
    echo "<h2>Current QR Locations</h2>";
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? ORDER BY id DESC");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($locations)) {
        echo "<p>No locations found for your company.</p>";
    } else {
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Name</th>";
        echo "<th>QR Code</th>";
        echo "<th>Type</th>";
        echo "<th>Latitude</th>";
        echo "<th>Longitude</th>";
        echo "<th>Created</th>";
        echo "</tr>";
        
        foreach ($locations as $location) {
            echo "<tr>";
            echo "<td>" . $location['id'] . "</td>";
            echo "<td>" . htmlspecialchars($location['name'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($location['qr_code'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($location['location_type'] ?? 'N/A') . "</td>";
            echo "<td>" . ($location['latitude'] ?? 'N/A') . "</td>";
            echo "<td>" . ($location['longitude'] ?? 'N/A') . "</td>";
            echo "<td>" . ($location['created_at'] ?? 'N/A') . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    echo "<br><p class='success'><strong>✅ Table check complete!</strong></p>";
    echo "<p><a href='qr-generator.php'>← Back to QR Generator</a></p>";
    
} catch (Exception $e) {
    echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
}

echo "</body>";
echo "</html>";
?>