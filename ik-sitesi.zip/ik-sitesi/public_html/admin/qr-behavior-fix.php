<?php
/**
 * QR Behavior Fix Tool - Kapı Davranışları Düzeltme Aracı
 * Tüm QR kodların davranışlarını kontrol eder ve düzeltir
 */
require_once '../includes/config.php';
require_once '../includes/database.php';

session_start();

// Check if user is admin or super admin
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    die("❌ Yetkisiz erişim! Sadece admin veya süper admin bu işlemi yapabilir.");
}

$success = '';
$error = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if gate_behavior column exists
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
    $hasBehaviorColumn = $stmt->rowCount() > 0;
    
    if (!$hasBehaviorColumn) {
        // Add gate_behavior column if it doesn't exist
        $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(50) DEFAULT 'user_choice'");
        $success .= "✅ gate_behavior kolonu eklendi!<br>";
    }
    
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if ($_POST['action'] === 'fix_all') {
            // Get company ID
            $companyId = $_SESSION['company_id'];
            
            // Automatically fix all QR locations based on their names
            $stmt = $conn->prepare("SELECT id, name, gate_behavior FROM qr_locations WHERE company_id = ?");
            $stmt->execute([$companyId]);
            $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $fixCount = 0;
            foreach ($locations as $location) {
                $name = mb_strtolower(trim($location['name']), 'UTF-8');
                
                // Determine correct behavior based on name
                $correctBehavior = null;
                if (stripos($name, 'giriş') !== false || stripos($name, 'giris') !== false || 
                    stripos($name, 'entrance') !== false) {
                    $correctBehavior = 'work_start';
                } elseif (stripos($name, 'çıkış') !== false || stripos($name, 'cikis') !== false || 
                          stripos($name, 'exit') !== false) {
                    $correctBehavior = 'work_end';
                } elseif (stripos($name, 'mola') !== false || stripos($name, 'break') !== false) {
                    $correctBehavior = 'break_toggle';
                } else {
                    $correctBehavior = 'user_choice';
                }
                
                // Update if behavior is different
                if ($location['gate_behavior'] !== $correctBehavior) {
                    $stmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE id = ?");
                    $stmt->execute([$correctBehavior, $location['id']]);
                    $fixCount++;
                }
            }
            
            $success = "✅ $fixCount QR lokasyonunun davranışı düzeltildi!";
        } elseif ($_POST['action'] === 'update_single' && isset($_POST['location_id']) && isset($_POST['behavior'])) {
            $locationId = (int)$_POST['location_id'];
            $behavior = $_POST['behavior'];
            $companyId = $_SESSION['company_id'];
            
            $stmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE id = ? AND company_id = ?");
            if ($stmt->execute([$behavior, $locationId, $companyId])) {
                $success = "✅ QR lokasyon davranışı güncellendi!";
            } else {
                $error = "❌ Güncelleme başarısız!";
            }
        }
    }
    
    // Get all locations for current company
    $companyId = $_SESSION['company_id'];
    $stmt = $conn->prepare("SELECT id, name, gate_behavior, location_type FROM qr_locations WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error = "❌ Hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Davranış Düzeltme - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen py-8">
        <div class="max-w-6xl mx-auto px-4">
            <header class="bg-white rounded-lg shadow-lg p-6 mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">🔧 QR Davranış Düzeltme Aracı</h1>
                <p class="text-gray-600">QR kodlarının kapı davranışlarını kontrol edin ve düzeltin</p>
            </header>

            <?php if ($success): ?>
                <div class="bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded-lg mb-6">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-200 text-red-800 px-4 py-3 rounded-lg mb-6">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Auto Fix Button -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Otomatik Düzeltme</h2>
                <p class="text-gray-600 mb-4">QR lokasyon isimlerine göre otomatik olarak doğru davranışları ayarlar</p>
                <form method="POST" class="inline">
                    <input type="hidden" name="action" value="fix_all">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-semibold">
                        🔄 Tüm QR Davranışlarını Otomatik Düzelt
                    </button>
                </form>
            </div>

            <!-- Current Locations -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-6">📍 Mevcut QR Lokasyonları</h2>
                
                <?php if (empty($locations)): ?>
                    <div class="text-center py-8">
                        <div class="text-6xl mb-4">📍</div>
                        <p class="text-gray-600">Henüz QR lokasyonu bulunmuyor.</p>
                        <a href="qr-generator.php" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 mt-4 inline-block">
                            QR Lokasyon Oluştur
                        </a>
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full table-auto">
                            <thead>
                                <tr class="bg-gray-50">
                                    <th class="px-4 py-3 text-left font-semibold text-gray-900">QR Lokasyon</th>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-900">Mevcut Davranış</th>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-900">Önerilen Davranış</th>
                                    <th class="px-4 py-3 text-left font-semibold text-gray-900">İşlemler</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php foreach ($locations as $location): ?>
                                    <?php
                                    $name = mb_strtolower(trim($location['name']), 'UTF-8');
                                    $suggestedBehavior = 'user_choice';
                                    $suggestion = '';
                                    
                                    if (stripos($name, 'giriş') !== false || stripos($name, 'giris') !== false || 
                                        stripos($name, 'entrance') !== false) {
                                        $suggestedBehavior = 'work_start';
                                        $suggestion = '🟢 Giriş Kapısı';
                                    } elseif (stripos($name, 'çıkış') !== false || stripos($name, 'cikis') !== false || 
                                              stripos($name, 'exit') !== false) {
                                        $suggestedBehavior = 'work_end';
                                        $suggestion = '🔴 Çıkış Kapısı';
                                    } elseif (stripos($name, 'mola') !== false || stripos($name, 'break') !== false) {
                                        $suggestedBehavior = 'break_toggle';
                                        $suggestion = '🟡 Mola Kapısı';
                                    } else {
                                        $suggestion = '⚪ Genel Kapı';
                                    }
                                    
                                    $isCorrect = $location['gate_behavior'] === $suggestedBehavior;
                                    $statusColor = $isCorrect ? 'text-green-600' : 'text-red-600';
                                    $statusIcon = $isCorrect ? '✅' : '❌';
                                    ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-4 py-3">
                                            <div class="font-semibold text-gray-900"><?php echo htmlspecialchars($location['name']); ?></div>
                                            <div class="text-sm text-gray-600">ID: <?php echo $location['id']; ?></div>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="<?php echo $statusColor; ?>">
                                                <?php echo $statusIcon; ?> 
                                                <?php
                                                $behaviorNames = [
                                                    'work_start' => 'İşe Başlama',
                                                    'work_end' => 'İşten Çıkış',
                                                    'break_toggle' => 'Mola Açma/Kapama',
                                                    'user_choice' => 'Kullanıcı Seçimi'
                                                ];
                                                echo $behaviorNames[$location['gate_behavior']] ?? $location['gate_behavior'];
                                                ?>
                                            </span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <span class="text-blue-600">
                                                <?php echo $suggestion; ?> 
                                                (<?php echo $behaviorNames[$suggestedBehavior] ?? $suggestedBehavior; ?>)
                                            </span>
                                        </td>
                                        <td class="px-4 py-3">
                                            <?php if (!$isCorrect): ?>
                                                <form method="POST" class="inline">
                                                    <input type="hidden" name="action" value="update_single">
                                                    <input type="hidden" name="location_id" value="<?php echo $location['id']; ?>">
                                                    <input type="hidden" name="behavior" value="<?php echo $suggestedBehavior; ?>">
                                                    <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">
                                                        🔧 Düzelt
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-green-600 text-sm">✅ Doğru</span>
                                            <?php endif; ?>
                                            
                                            <!-- Manual selection -->
                                            <form method="POST" class="inline ml-2">
                                                <input type="hidden" name="action" value="update_single">
                                                <input type="hidden" name="location_id" value="<?php echo $location['id']; ?>">
                                                <select name="behavior" onchange="this.form.submit()" class="text-sm border border-gray-300 rounded px-2 py-1">
                                                    <option value="work_start" <?php echo $location['gate_behavior'] === 'work_start' ? 'selected' : ''; ?>>İşe Başlama</option>
                                                    <option value="work_end" <?php echo $location['gate_behavior'] === 'work_end' ? 'selected' : ''; ?>>İşten Çıkış</option>
                                                    <option value="break_toggle" <?php echo $location['gate_behavior'] === 'break_toggle' ? 'selected' : ''; ?>>Mola Açma/Kapama</option>
                                                    <option value="user_choice" <?php echo $location['gate_behavior'] === 'user_choice' ? 'selected' : ''; ?>>Kullanıcı Seçimi</option>
                                                </select>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Info Box -->
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mt-8">
                <h3 class="text-lg font-bold text-blue-900 mb-4">📋 Kapı Davranışları Açıklaması</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-800">
                    <div>
                        <h4 class="font-semibold">🟢 İşe Başlama (work_start)</h4>
                        <p>Personelin iş günü başlatması için kullanılır. Giriş kapıları için uygundur.</p>
                    </div>
                    <div>
                        <h4 class="font-semibold">🔴 İşten Çıkış (work_end)</h4>
                        <p>Personelin iş günü bitirmesi için kullanılır. Çıkış kapıları için uygundur.</p>
                    </div>
                    <div>
                        <h4 class="font-semibold">🟡 Mola Açma/Kapama (break_toggle)</h4>
                        <p>Mola başlatma ve bitirme için kullanılır. Sınırsız mola döngüsü destekler.</p>
                    </div>
                    <div>
                        <h4 class="font-semibold">⚪ Kullanıcı Seçimi (user_choice)</h4>
                        <p>Kullanıcı hangi işlemi yapmak istediğini seçer. Akıllı sistem önerir.</p>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="text-center mt-8">
                <a href="index.php" class="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors">
                    ← Admin Panel'e Dön
                </a>
            </div>
        </div>
    </div>
</body>
</html>