<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) CONCAT!isset($_SESSION['company_id'])) {
    header('Location: ../auth/company-login.php');
    exit;
}

$company_id = $_SESSION['company_id'];
$success = '';
$error = '';

// Create locations table if not exists
try {
    $create_table_sql = "
    CREATE TABLE IF NOT EXISTS qr_locations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        name VARCHAR(255) NOT NULL,
        qr_code VARCHAR(255) UNIQUE,
        location_type ENUM('entrance', 'exit', 'office', 'cafeteria', 'meeting_room', 'break_area', 'warehouse', 'parking', 'other') DEFAULT 'office',
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        address TEXT,
        description TEXT,
        tolerance_radius INT DEFAULT 100,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURTIME()STAMP,
        updated_at TIMESTAMP DEFAULT CURTIME()STAMP ON UPDATE CURTIME()STAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($create_table_sql);
} catch (PDOException $e) {
    $error = "Veritabanı hatası: " . $e->getMessage();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create_location') {
        $name = trim($_POST['name'] ?? '');
        $location_type = $_POST['location_type'] ?? 'office';
        $latitude = floatval($_POST['latitude'] ?? 0);
        $longitude = floatval($_POST['longitude'] ?? 0);
        $address = trim($_POST['address'] ?? '');
        $description = trim($_POST['description'] ?? '');
        
        if (empty($name)) {
            $error = 'Lokasyon adı gereklidir.';
        } elseif ($latitude == 0 CONCAT$longitude == 0) {
            $error = 'Geçerli GPS koordinatları gereklidir.';
        } else {
            try {
                // Generate unique QR code that works with scanner
                $location_temp_id = rand(100, 999); // Temporary ID for this location
                $qr_code = 'LOC_' . $location_temp_id; // Simple format that scanner can parse
                
                $stmt = $pdo->prepare("
                    INSERT INTO qr_locations (company_id, name, qr_code, location_type, latitude, longitude, address, description) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $result = $stmt->execute([
                    $company_id, $name, $qr_code, $location_type, 
                    $latitude, $longitude, $address, $description
                ]);
                
                if ($result) {
                    $success = "QR lokasyon '$name' başarıyla oluşturuldu!";
                } else {
                    $error = 'Lokasyon oluşturulamadı.';
                }
            } catch (PDOException $e) {
                $error = 'Veritabanı hatası: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_location') {
        $location_id = (int)($_POST['location_id'] ?? 0);
        
        if ($location_id > 0) {
            try {
                $stmt = $pdo->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
                $result = $stmt->execute([$location_id, $company_id]);
                
                if ($result && $stmt->rowCount() > 0) {
                    $success = 'Lokasyon başarıyla silindi.';
                } else {
                    $error = 'Lokasyon silinemedi.';
                }
            } catch (PDOException $e) {
                $error = 'Silme hatası: ' . $e->getMessage();
            }
        }
    }
}

// Fetch existing locations
$locations = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM qr_locations WHERE company_id = ? AND is_active = 1 ORDER BY created_at DESC");
    $stmt->execute([$company_id]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = 'Lokasyonlar yüklenemedi: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Lokasyon Üretici - SZB İK Takip</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .form-section {
            padding: 30px;
            border-bottom: 1px solid #eee;
        }
        
        .form-section:last-child {
            border-bottom: none;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #3498db;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.3);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #27ae60, #229954);
            color: white;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            color: white;
        }
        
        .locations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .location-card {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            border: 2px solid #e9ecef;
            transition: all 0.3s;
        }
        
        .location-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }
        
        .qr-container {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background: white;
            border-radius: 10px;
            border: 3px solid #3498db;
        }
        
        .actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin: 20px;
            font-weight: 600;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .back-link {
            display: inline-block;
            margin: 20px;
            color: #3498db;
            text-decoration: none;
            font-weight: 600;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        .qr-display {
            width: 200px;
            height: 200px;
            margin: 0 auto;
            border: 2px solid #ddd;
            border-radius: 8px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .coord-actions {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="../dashboard/company-dashboard.php" class="back-link">← Dashboard'a Dön</a>
        
        <div class="header">
            <h1>📱 QR Lokasyon Üretici</h1>
            <p>GPS koordinatlı QR kodlar oluşturun ve yönetin</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- Create New Location Form -->
        <div class="form-section">
            <h3>📍 Yeni QR Lokasyon Oluştur</h3>
            <form method="POST" onsubmit="return validateForm()">
                <input type="hidden" name="action" value="create_location">
                
                <div class="form-group">
                    <label>Lokasyon Adı *</label>
                    <input type="text" name="name" id="name" required placeholder="Örn: Ana Giriş Kapısı">
                </div>
                
                <div class="form-group">
                    <label>Lokasyon Türü</label>
                    <select name="location_type" id="location_type">
                        <option value="entrance">🚪 Giriş Kapısı</option>
                        <option value="exit">🚪 Çıkış Kapısı</option>
                        <option value="office" selected>🏢 Ofis/Çalışma Alanı</option>
                        <option value="cafeteria">🍽️ Kafeterya/Yemekhane</option>
                        <option value="meeting_room">👥 Toplantı Odası</option>
                        <option value="break_area">☕ Mola Alanı</option>
                        <option value="warehouse">📦 Depo/Ambar</option>
                        <option value="parking">🚗 Otopark</option>
                        <option value="other">📍 Diğer</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Enlem (Latitude) *</label>
                    <input type="number" id="latitude" name="latitude" step="0.00000001" min="-90" max="90" required placeholder="41.00820000">
                    <div class="coord-actions">
                        <button type="button" class="btn btn-success" onclick="getCurrentLocation()">📍 Mevcut Konumu Al</button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Boylam (Longitude) *</label>
                    <input type="number" id="longitude" name="longitude" step="0.00000001" min="-180" max="180" required placeholder="28.97840000">
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <input type="text" name="address" placeholder="Tam adres bilgisi (opsiyonel)">
                </div>
                
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" rows="3" placeholder="Lokasyon hakkında ek bilgiler (opsiyonel)"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">🎯 QR Lokasyon Oluştur</button>
            </form>
        </div>
        
        <!-- Existing Locations -->
        <?php if (!empty($locations)): ?>
            <div class="form-section">
                <h3>📋 Mevcut QR Lokasyonlar (<?= count($locations) ?>)</h3>
                <div class="locations-grid">
                    <?php foreach ($locations as $location): ?>
                        <?php 
                            $id = $location['id'] ?? 0;
                            $name = $location['name'] ?? 'QR Lokasyon ' . $id;
                            $qr_code = $location['qr_code'] ?? 'QR_UNKNOWN';
                            $location_type = $location['location_type'] ?? 'office';
                            $latitude = $location['latitude'] ?? null;
                            $longitude = $location['longitude'] ?? null;
                            $address = $location['address'] ?? '';
                            $description = $location['description'] ?? '';
                            
                            $typeLabels = [
                                'entrance' => '🚪 Giriş',
                                'exit' => '🚪 Çıkış',
                                'office' => '🏢 Ofis',
                                'cafeteria' => '🍽️ Kafeterya',
                                'meeting_room' => '👥 Toplantı',
                                'break_area' => '☕ Mola',
                                'warehouse' => '📦 Depo',
                                'parking' => '🚗 Otopark',
                                'other' => '📍 Diğer'
                            ];
                            
                            $typeLabel = $typeLabels[$location_type] ?? '📍 ' . ucfirst($location_type);
                        ?>
                        <div class="location-card">
                            <h4><?= htmlspecialchars($name) ?></h4>
                            <p><strong>QR Kod:</strong> <code><?= htmlspecialchars($qr_code) ?></code></p>
                            <p><strong>Tür:</strong> <?= $typeLabel ?></p>
                            
                            <?php if ($latitude && $longitude): ?>
                                <p><strong>Koordinatlar:</strong> <?= number_format($latitude, 8) ?>, <?= number_format($longitude, 8) ?></p>
                                <p><strong>Google Maps:</strong> 
                                    <a href="https://www.google.com/maps?q=<?= $latitude ?>,<?= $longitude ?>" 
                                       target="_blank" 
                                       style="color: #3498db;">
                                       📍 Haritada Görüntüle
                                    </a>
                                </p>
                            <?php endif; ?>
                            
                            <?php if ($address): ?>
                                <p><strong>Adres:</strong> <?= htmlspecialchars($address) ?></p>
                            <?php endif; ?>
                            
                            <?php if ($description): ?>
                                <p><strong>Açıklama:</strong> <?= htmlspecialchars($description) ?></p>
                            <?php endif; ?>
                            
                            <div class="qr-container">
                                <div class="qr-display" id="qr_<?= $id ?>" data-qr-code="<?= htmlspecialchars($qr_code) ?>">
                                    QR Kod Yükleniyor...
                                </div>
                            </div>
                            
                            <div class="actions">
                                <button class="btn btn-success" onclick="downloadQR(<?= $id ?>, '<?= htmlspecialchars($name, ENT_QUOTES) ?>')">
                                    📥 İndir
                                </button>
                                <button class="btn btn-danger" onclick="deleteLocation(<?= $id ?>, '<?= htmlspecialchars($name, ENT_QUOTES) ?>')">
                                    🗑️ Sil
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="form-section">
                <p style="text-align: center; color: #7f8c8d;">Henüz QR lokasyon oluşturulmamış.</p>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Simple QR Code generation without external libraries
        function generateQRCode(text, size = 200) {
            // Create a simple visual QR-like pattern
            const canvas = document.createElement('canvas');
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');
            
            // White background
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, size, size);
            
            // Black border
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2;
            ctx.strokeRect(5, 5, size-10, size-10);
            
            // Generate pattern based on text
            const hash = simpleHash(text);
            const cellSize = Math.floor((size - 20) / 25);
            
            ctx.fillStyle = '#000000';
            
            // Corner squares (QR finder patterns)
            drawFinderPattern(ctx, 10, 10, cellSize * 7);
            drawFinderPattern(ctx, size - cellSize * 7 - 10, 10, cellSize * 7);
            drawFinderPattern(ctx, 10, size - cellSize * 7 - 10, cellSize * 7);
            
            // Data pattern based on hash
            for (let i = 0; i < 25; i++) {
                for (let j = 0; j < 25; j++) {
                    if (shouldDrawCell(i, j, hash)) {
                        const x = 10 + cellSize + i * cellSize;
                        const y = 10 + cellSize + j * cellSize;
                        
                        // Skip finder pattern areas
                        if (!isInFinderPattern(i, j)) {
                            ctx.fillRect(x, y, cellSize - 1, cellSize - 1);
                        }
                    }
                }
            }
            
            // Add text at bottom
            ctx.fillStyle = '#333333';
            ctx.font = 'bold 12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('QR CODE', size/2, size - 25);
            
            ctx.font = '10px Arial';
            const shortText = text.length > 15 ? text.substring(0, 15) + '...' : text;
            ctx.fillText(shortText, size/2, size - 10);
            
            return canvas;
        }
        
        function simpleHash(str) {
            let hash = 0;
            for (let i = 0; i < str.length; i++) {
                const char = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + char;
                hash = hash & hash; // Convert to 32-bit integer
            }
            return Math.abs(hash);
        }
        
        function drawFinderPattern(ctx, x, y, size) {
            // Outer square
            ctx.fillRect(x, y, size, size);
            
            // Inner white square
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(x + size/7, y + size/7, size * 5/7, size * 5/7);
            
            // Inner black square
            ctx.fillStyle = '#000000';
            ctx.fillRect(x + size * 2/7, y + size * 2/7, size * 3/7, size * 3/7);
        }
        
        function isInFinderPattern(i, j) {
            // Top-left
            if (i < 8 && j < 8) return true;
            // Top-right
            if (i > 16 && j < 8) return true;
            // Bottom-left
            if (i < 8 && j > 16) return true;
            return false;
        }
        
        function shouldDrawCell(i, j, hash) {
            return ((hash + i * 31 + j * 17) % 3) === 0;
        }
        
        // Initialize QR codes
        function initializeQRCodes() {
            const qrDisplays = document.querySelectorAll('.qr-display');
            
            qrDisplays.forEach(function(display) {
                const qrCode = display.getAttribute('data-qr-code');
                
                if (qrCode) {
                    console.log('Generating QR for:', qrCode);
                    
                    const canvas = generateQRCode(qrCode, 180);
                    canvas.style.border = '2px solid #27ae60';
                    canvas.style.borderRadius = '8px';
                    
                    // Clear the display and add canvas
                    display.innerHTML = '';
                    display.appendChild(canvas);
                    
                    // Store canvas reference for download
                    display.qrCanvas = canvas;
                }
            });
        }
        
        // Form validation
        function validateForm() {
            const name = document.getElementById('name').value.trim();
            const latitude = parseFloat(document.getElementById('latitude').value);
            const longitude = parseFloat(document.getElementById('longitude').value);
            
            if (!name) {
                alert('Lütfen lokasyon adı girin!');
                return false;
            }
            
            if (!latitude CONCAT!longitude CONCATlatitude === 0 CONCATlongitude === 0) {
                alert('Lütfen geçerli GPS koordinatları girin!');
                return false;
            }
            
            return true;
        }
        
        // Get current location
        function getCurrentLocation() {
            if (!navigator.geolocation) {
                alert('Tarayıcınız GPS desteklemiyor!');
                return;
            }
            
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = '📍 Konum alınıyor...';
            btn.disabled = 1;
            
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    document.getElementById('latitude').value = position.coords.latitude.toFixed(8);
                    document.getElementById('longitude').value = position.coords.longitude.toFixed(8);
                    
                    btn.textContent = '✅ Konum Alındı';
                    setTimeout(() => {
                        btn.textContent = originalText;
                        btn.disabled = 0;
                    }, 2000);
                },
                function(error) {
                    btn.textContent = originalText;
                    btn.disabled = 0;
                    
                    let errorMsg = 'GPS konumu alınamadı: ';
                    switch(error.code) {
                        case error.PERMISSION_DENIED:
                            errorMsg += 'Konum izni reddedildi';
                            break;
                        case error.POSITION_UNAVAILABLE:
                            errorMsg += 'Konum bilgisi mevcut değil';
                            break;
                        case error.TIMEOUT:
                            errorMsg += 'İstek zaman aşımına uğradı';
                            break;
                        default:
                            errorMsg += error.message;
                    }
                    alert(errorMsg);
                }
            );
        }
        
        // Download QR code
        function downloadQR(locationId, locationName) {
            const display = document.getElementById('qr_' + locationId);
            const canvas = display.qrCanvas;
            
            if (!canvas) {
                alert('QR kod bulunamadı!');
                return;
            }
            
            try {
                canvas.toBlob(function(blob) {
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.download = 'QR_' + locationName.replace(/[^a-z0-9]/gi, '_') + '_' + locationId + '.png';
                    link.href = url;
                    link.click();
                    URL.revokeObjectURL(url);
                    
                    // Visual feedback
                    const btn = event.target;
                    const originalText = btn.textContent;
                    btn.textContent = '✅ İndirildi';
                    setTimeout(() => {
                        btn.textContent = originalText;
                    }, 2000);
                });
            } catch(e) {
                console.error('Download error:', e);
                alert('QR kod indirilemedi: ' + e.message);
            }
        }
        
        // Delete location
        function deleteLocation(locationId, locationName) {
            if (!confirm('Bu lokasyonu silmek istediğinizden emin misiniz?\n\nLokasyon: ' + locationName)) {
                return;
            }
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete_location';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'location_id';
            idInput.value = locationId;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        }
        
        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Initializing QR codes...');
            initializeQRCodes();
        });
    </script>
</body>
</html>