<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin authentication
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/admin-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check system status
    $systemStatus = [
        'qr_locations_table' => false,
        'gate_behavior_column' => false,
        'location_count' => 0,
        'gate_types' => []
    ];
    
    // Check if qr_locations table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'qr_locations'");
    $systemStatus['qr_locations_table'] = $stmt->rowCount() > 0;
    
    if ($systemStatus['qr_locations_table']) {
        // Check if gate_behavior column exists
        $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
        $systemStatus['gate_behavior_column'] = $stmt->rowCount() > 0;
        
        // Count locations by company
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ?");
        $stmt->execute([$_SESSION['company_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $systemStatus['location_count'] = $result['count'];
        
        // Get gate type distribution
        $stmt = $conn->prepare("
            SELECT location_type, COUNT(*) as count 
            FROM qr_locations 
            WHERE company_id = ? 
            GROUP BY location_type
        ");
        $stmt->execute([$_SESSION['company_id']]);
        $systemStatus['gate_types'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
} catch (Exception $e) {
    $error = "Sistem kontrolü hatası: " . $e->getMessage();
}

header('Content-Type: application/json');
echo json_encode([
    'status' => 'success',
    'system_status' => $systemStatus,
    'needs_migration' => !$systemStatus['gate_behavior_column'],
    'ready_for_use' => $systemStatus['qr_locations_table'] && $systemStatus['gate_behavior_column']
]);
?>