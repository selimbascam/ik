<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Session already started in config.php

// Check admin access
if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../auth/company-login.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 1; // Default to 1 for super admin

$selectedMonth = $_GET['month'] ?? date('Y-m');
$selectedYear = date('Y', strtotime($selectedMonth . '-01'));
$selectedMonthName = date('n', strtotime($selectedMonth . '-01'));

// Turkish month names
$turkishMonths = [
    1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
    5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
    9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık'
];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get company info
    $stmt = $conn->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$company_id]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Initialize variables with default values
    $employees = [];
    $totalEmployees = 0;
    $totalDaysWorked = 0;
    $totalHours = 0;
    $averageHoursPerEmployee = 0;
    
    // First ensure employee_number column exists
    try {
        $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
        if ($columnCheck->rowCount() === 0) {
            // Column doesn't exist, add it
            $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
            
            // Generate employee numbers for existing employees
            $existingEmps = $conn->query("SELECT id FROM employees WHERE employee_number IS NULL OR employee_number = ''");
            foreach ($existingEmps->fetchAll(PDO::FETCH_ASSOC) as $emp) {
                $empNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
                $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
                $updateStmt->execute([$empNumber, $emp['id']]);
            }
        }
    } catch (Exception $e) {
        // If column creation fails, we'll handle it in the error catch below
    }
    
    // Get all employees with their attendance data for the selected month
    $stmt = $conn->prepare("
        SELECT 
            e.id,
            COALESCE(e.employee_number, COALESCE(e.employee_code, CONCAT('EMP', LPAD(e.id, 4, '0')))) as employee_number,
            e.first_name,
            e.last_name,
            e.email,
            e.position,
            d.name as department_name,
            e.status,
            COALESCE(e.salary, 0) as salary,
            COUNT(DISTINCT DATE(ar.check_in)) as days_worked,
            COALESCE(SUM(
                CASE 
                    WHEN ar.check_in IS NOT NULL AND ar.check_out IS NOT NULL 
                    THEN TIMESTAMPDIFF(MINUTE, ar.check_in, ar.check_out) / 60.0
                    ELSE 0
                END
            ), 0) as total_hours,
            MIN(DATE(ar.check_in)) as first_work_date,
            MAX(DATE(ar.check_in)) as last_work_date
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN attendance_records ar ON e.id = ar.employee_id 
            AND ar.date BETWEEN ? AND ?
        WHERE e.company_id = ?
        GROUP BY e.id
        ORDER BY e.first_name, e.last_name
    ");
    
    $monthStart = $selectedMonth . '-01';
    $monthEnd = date('Y-m-t', strtotime($monthStart));
    $stmt->execute([$monthStart, $monthEnd, $company_id]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate summary statistics
    $totalEmployees = count($employees);
    $totalDaysWorked = array_sum(array_column($employees, 'days_worked'));
    $totalHours = array_sum(array_column($employees, 'total_hours'));
    $averageHoursPerEmployee = $totalEmployees > 0 ? ($totalHours / $totalEmployees) : 0;
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
    
    // Initialize variables on error to prevent undefined variable warnings
    if (!isset($employees)) $employees = [];
    if (!isset($totalEmployees)) $totalEmployees = 0;
    if (!isset($totalDaysWorked)) $totalDaysWorked = 0;
    if (!isset($totalHours)) $totalHours = 0;
    if (!isset($averageHoursPerEmployee)) $averageHoursPerEmployee = 0;
    
    // Add diagnostic links for different errors
    if (strpos($e->getMessage(), 'employee_number') !== false) {
        $error .= '<br><br><a href="../debug/fix-employee-number-column.php" class="inline-block mt-2 bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm">🔧 Employee Number Sütunu Düzeltme</a>';
    }
    $error .= '<br><br><a href="../debug/fix-attendance-tracking.php" class="inline-block mt-2 bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-sm">📊 Aylık Devam Takibi Tanı</a>';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Devam Takibi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">📊</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Personel Devam Takibi</h1>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($company['company_name'] ?? 'Şirket'); ?> - <?php echo $turkishMonths[$selectedMonthName] . ' ' . $selectedYear; ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo strpos($error, '<a href=') !== false ? $error : htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Month Selection -->
            <div class="bg-white shadow rounded-lg mb-6">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Ay Seçimi</h2>
                </div>
                <div class="p-6">
                    <form method="GET" class="flex items-center space-x-4">
                        <div>
                            <label for="month" class="block text-sm font-medium text-gray-700">Ay ve Yıl Seçin</label>
                            <input type="month" 
                                   id="month" 
                                   name="month" 
                                   value="<?php echo htmlspecialchars($selectedMonth); ?>"
                                   class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                                   onchange="this.form.submit()">
                        </div>
                        <div class="pt-6">
                            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                                Göster
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Summary Stats -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <div class="bg-white overflow-hidden shadow rounded-lg">
                    <div class="p-5">
                        <div class="flex items-center">
                            <div class="flex-shrink-0">
                                <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                                    <span class="text-white text-sm font-bold"><?php echo $totalEmployees; ?></span>
                                </div>
                            </div>
                            <div class="ml-5 w-0 flex-1">
                                <dl>
                                    <dt class="text-sm font-medium text-gray-500 truncate">Toplam Personel</dt>
                                    <dd class="text-lg font-medium text-gray-900"><?php echo $totalEmployees; ?></dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow rounded-lg">
                    <div class="p-5">
                        <div class="flex items-center">
                            <div class="flex-shrink-0">
                                <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                                    <span class="text-white text-sm font-bold"><?php echo $totalDaysWorked; ?></span>
                                </div>
                            </div>
                            <div class="ml-5 w-0 flex-1">
                                <dl>
                                    <dt class="text-sm font-medium text-gray-500 truncate">Toplam Çalışılan Gün</dt>
                                    <dd class="text-lg font-medium text-gray-900"><?php echo $totalDaysWorked; ?></dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow rounded-lg">
                    <div class="p-5">
                        <div class="flex items-center">
                            <div class="flex-shrink-0">
                                <div class="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                                    <span class="text-white text-sm font-bold"><?php echo round($totalHours); ?></span>
                                </div>
                            </div>
                            <div class="ml-5 w-0 flex-1">
                                <dl>
                                    <dt class="text-sm font-medium text-gray-500 truncate">Toplam Saat</dt>
                                    <dd class="text-lg font-medium text-gray-900"><?php echo number_format((float)$totalHours, 1); ?></dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow rounded-lg">
                    <div class="p-5">
                        <div class="flex items-center">
                            <div class="flex-shrink-0">
                                <div class="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                                    <span class="text-white text-sm font-bold"><?php echo round($averageHoursPerEmployee); ?></span>
                                </div>
                            </div>
                            <div class="ml-5 w-0 flex-1">
                                <dl>
                                    <dt class="text-sm font-medium text-gray-500 truncate">Ortalama Saat/Personel</dt>
                                    <dd class="text-lg font-medium text-gray-900"><?php echo number_format((float)$averageHoursPerEmployee, 1); ?></dd>
                                </dl>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Employee List -->
            <div class="bg-white shadow rounded-lg">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">
                        Personel Devam Durumu - <?php echo $turkishMonths[$selectedMonthName] . ' ' . $selectedYear; ?>
                    </h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Personel
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Pozisyon / Departman
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Çalışılan Gün
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Toplam Saat
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    İlk Giriş
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Son Giriş
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Durum
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    İşlemler
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if (empty($employees)): ?>
                                <tr>
                                    <td colspan="8" class="px-6 py-4 text-center text-gray-500">
                                        Henüz personel bulunmuyor.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($employees as $employee): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center mr-3">
                                                    <span class="text-gray-600 font-medium text-sm">
                                                        <?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?>
                                                    </span>
                                                </div>
                                                <div>
                                                    <div class="text-sm font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                                    </div>
                                                    <div class="text-sm text-gray-500">
                                                        <?php echo htmlspecialchars($employee['employee_number']); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($employee['position'] ?? 'Belirtilmemiş'); ?></div>
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($employee['department_name'] ?? 'Departman Yok'); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                                <?php echo ($employee['days_worked'] ?? 0) > 15 ? 'bg-green-100 text-green-800' : 
                                                    (($employee['days_worked'] ?? 0) > 10 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'); ?>">
                                                <?php echo ($employee['days_worked'] ?? 0); ?> gün
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <?php echo number_format($employee['total_hours'] ?? 0, 1); ?> saat
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo $employee['first_work_date'] ? date('d.m.Y', strtotime($employee['first_work_date'])) : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo $employee['last_work_date'] ? date('d.m.Y', strtotime($employee['last_work_date'])) : '-'; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                                <?php echo $employee['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                                <?php echo $employee['status'] === 'active' ? 'Aktif' : 'Pasif'; ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <a href="../attendance/records.php?employee_id=<?php echo $employee['id']; ?>&date=<?php echo $selectedMonth; ?>" 
                                               class="text-green-600 hover:text-green-900 mr-3">
                                                Detay Gör
                                            </a>
                                            <a href="../reports/earnings-calculator.php?employee_id=<?php echo $employee['id']; ?>&month=<?php echo $selectedMonth; ?>" 
                                               class="text-blue-600 hover:text-blue-900">
                                                Kazanç
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Export Options -->
            <div class="mt-6 flex justify-end space-x-4">
                <button onclick="window.print()" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                    🖨️ Yazdır
                </button>
                <a href="?month=<?php echo $selectedMonth; ?>&export=excel" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    📊 Excel Çıktısı
                </a>
            </div>
        </main>
    </div>

    <style>
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
            .shadow { box-shadow: none !important; }
        }
    </style>
</body>
</html>