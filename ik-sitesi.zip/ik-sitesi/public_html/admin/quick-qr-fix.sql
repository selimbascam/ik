-- QR Gate Behavior Quick Fix
-- Bu SQL scripti QR kodlarının doğru davranışlarını ayarlar

-- 1. gate_behavior sütunu ekle (varsa hata vermez)
ALTER TABLE qr_locations 
ADD COLUMN gate_behavior ENUM('work_start', 'work_end', 'break_toggle', 'user_choice') DEFAULT 'user_choice';

-- 2. Giriş kapılarını düzelt (İşe başlama)
UPDATE qr_locations 
SET location_type = 'entrance_gate', gate_behavior = 'work_start' 
WHERE name LIKE '%giriş%' OR name LIKE '%Giriş%' OR name LIKE '%GİRİŞ%' 
   OR location_type = 'entrance' OR name = 'giriş';

-- 3. Çıkış kapılarını düzelt (İşten çıkış)
UPDATE qr_locations 
SET location_type = 'exit_gate', gate_behavior = 'work_end' 
WHERE name LIKE '%çıkış%' OR name LIKE '%Çıkış%' OR name LIKE '%ÇIKIŞ%' 
   OR location_type = 'exit' OR name = 'çıkış';

-- 4. Mola kapılarını düzelt
UPDATE qr_locations 
SET location_type = 'break_gate', gate_behavior = 'break_toggle' 
WHERE name LIKE '%mola%' OR name LIKE '%Mola%' OR name LIKE '%MOLA%' 
   OR location_type = 'break_area' OR location_type = 'cafeteria';

-- 5. Diğer tüm kapıları genel kapı yap
UPDATE qr_locations 
SET location_type = 'general_gate', gate_behavior = 'user_choice' 
WHERE location_type NOT IN ('entrance_gate', 'exit_gate', 'break_gate');

-- 6. Kontrol sorgusu - tüm QR lokasyonlarını listele
SELECT 
    id, 
    name, 
    location_type, 
    gate_behavior,
    CASE gate_behavior
        WHEN 'work_start' THEN '🟢 İşe Başlama'
        WHEN 'work_end' THEN '🔴 İşten Çıkış'
        WHEN 'break_toggle' THEN '🟡 Mola Aç/Kapat'
        WHEN 'user_choice' THEN '🔄 Kullanıcı Seçimi'
        ELSE '❓ Belirsiz'
    END as behavior_description
FROM qr_locations 
ORDER BY id;