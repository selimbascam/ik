<?php
/**
 * Quick MySQL Format Fix for Navigation Links
 * Hızlı MySQL Format Düzeltmesi
 */
require_once '../includes/config.php';
require_once '../includes/database.php';

session_start();

// Check if user is super admin
if (!isset($_SESSION['super_admin'])) {
    die("❌ Yetkisiz erişim! Sadece süper admin bu işlemi yapabilir.");
}

echo "<h1>🔧 Hızlı MySQL Format Link Düzeltmesi</h1>";
echo "<div style='font-family: monospace; background: #f5f5f5; padding: 20px; border-radius: 5px;'>";

$fixes = [
    'reports.php CONCAT hatası' => false,
    'attendance-tracking.php yanlış path' => false,
    'view-device-records.php yanlış path' => false,
    'MySQL uyumsuz sorgular' => false
];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // 1. Fix reports.php CONCAT error (already fixed by previous edit)
    if (file_exists('reports.php')) {
        $content = file_get_contents('reports.php');
        if (strpos($content, 'CONCAT($_SESSION[\'user_role\']') === false) {
            $fixes['reports.php CONCAT hatası'] = true;
            echo "✅ reports.php CONCAT hatası zaten düzeltilmiş<br>";
        }
    }
    
    // 2. Fix attendance-tracking.php path issue (already fixed by previous edit)
    if (file_exists('attendance-tracking.php')) {
        $content = file_get_contents('attendance-tracking.php');
        if (strpos($content, 'Location: /../auth/') === false) {
            $fixes['attendance-tracking.php yanlış path'] = true;
            echo "✅ attendance-tracking.php path hatası zaten düzeltilmiş<br>";
        }
    }
    
    // 3. Check main navigation files for MySQL compatibility
    $navFiles = [
        'index.php' => '../',
        '../dashboard/company-dashboard.php' => '../',
        '../super-admin/index.php' => '../'
    ];
    
    echo "<h3>📂 Ana Navigasyon Dosyaları Kontrol Ediliyor:</h3>";
    
    foreach ($navFiles as $file => $prefix) {
        if (file_exists($file)) {
            $content = file_get_contents($file);
            echo "<strong>✅ $file</strong> - MySQL uyumlu<br>";
            
            // Check for specific MySQL compatibility issues
            if (strpos($content, 'PostgreSQL') !== false) {
                echo "&nbsp;&nbsp;⚠️ PostgreSQL referansı bulundu<br>";
            }
            
            if (strpos($content, 'SERIAL') !== false) {
                echo "&nbsp;&nbsp;⚠️ SERIAL kullanımı bulundu - AUTO_INCREMENT'e çevrilmeli<br>";
            }
            
            if (preg_match('/e\.(name|full_name)\b/', $content)) {
                echo "&nbsp;&nbsp;⚠️ Employee name field kullanımı - CONCAT gerekli<br>";
            }
        } else {
            echo "⚠️ $file bulunamadı<br>";
        }
    }
    
    // 4. Test database connections
    echo "<h3>🗄️ Veritabanı Bağlantısı Test Ediliyor:</h3>";
    
    // Test basic tables
    $testTables = ['companies', 'employees', 'attendance_records', 'qr_locations'];
    
    foreach ($testTables as $table) {
        try {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM `$table` LIMIT 1");
            $result = $stmt->fetch();
            echo "✅ Tablo `$table` erişilebilir ({$result['count']} kayıt)<br>";
        } catch (Exception $e) {
            echo "❌ Tablo `$table` hatası: " . $e->getMessage() . "<br>";
        }
    }
    
    // 5. Check critical page links exist
    echo "<h3>🔗 Kritik Sayfa Linkleri Kontrol Ediliyor:</h3>";
    
    $criticalPages = [
        'employee-management.php' => 'Personel Yönetimi',
        'qr-generator.php' => 'QR Kod Üretici',
        'attendance-tracking.php' => 'Devam Takibi',
        'reports.php' => 'Raporlar',
        'company-settings.php' => 'Şirket Ayarları',
        '../dashboard/company-dashboard.php' => 'Ana Dashboard',
        '../view-device-records.php' => 'Cihaz Kayıtları'
    ];
    
    foreach ($criticalPages as $page => $title) {
        if (file_exists($page)) {
            echo "✅ $title ($page)<br>";
        } else {
            echo "❌ $title eksik ($page)<br>";
        }
    }
    
    echo "<h3>📊 Durum Özeti:</h3>";
    echo "<div style='background: white; padding: 15px; border: 1px solid #ddd; border-radius: 5px;'>";
    
    $allFixed = true;
    foreach ($fixes as $fix => $status) {
        if (!$status) $allFixed = false;
        echo ($status ? "✅" : "❌") . " $fix<br>";
    }
    
    if ($allFixed) {
        echo "<br><strong style='color: green;'>🎉 Tüm ana linkler MySQL formatına uygun!</strong><br>";
    } else {
        echo "<br><strong style='color: orange;'>⚠️ Bazı düzeltmeler gerekebilir.</strong><br>";
    }
    
    echo "</div>";
    
    echo "<br><h3>🔄 Test Önerileri:</h3>";
    echo "<ul>";
    echo "<li>1. <a href='../dashboard/company-dashboard.php'>Ana Dashboard</a> sayfasını test edin</li>";
    echo "<li>2. <a href='employee-management.php'>Personel Yönetimi</a> sayfasına gidin</li>";
    echo "<li>3. <a href='qr-generator.php'>QR Kod Üretici</a> test edin</li>";
    echo "<li>4. <a href='../admin/test-gate-system.php'>Gate Test Sistemi</a> kontrol edin</li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<div style='color: #721c24; background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ Hata: " . $e->getMessage();
    echo "</div>";
}

echo "</div>";
echo "<br><a href='../super-admin/' style='text-decoration: none; padding: 10px 15px; background: #3b82f6; color: white; border-radius: 5px;'>← Süper Admin'e Dön</a>";
?>