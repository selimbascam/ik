<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin authentication
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/admin-login.php');
    exit;
}

$message = '';
$messageType = '';

// Handle setup action
if (isset($_POST['action']) && $_POST['action'] === 'setup_documents') {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Create employee_documents table
        $sql = "CREATE TABLE IF NOT EXISTS employee_documents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            company_id INT NOT NULL,
            document_type VARCHAR(100) NOT NULL,
            document_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_size INT,
            mime_type VARCHAR(100),
            uploaded_by INT,
            upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            expiry_date DATE NULL,
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
            FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_employee_documents (employee_id),
            INDEX idx_company_documents (company_id),
            INDEX idx_document_type (document_type),
            INDEX idx_document_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        
        // Create document types reference table
        $sql2 = "CREATE TABLE IF NOT EXISTS document_types (
            id INT AUTO_INCREMENT PRIMARY KEY,
            type_code VARCHAR(50) UNIQUE NOT NULL,
            type_name VARCHAR(255) NOT NULL,
            description TEXT,
            is_required BOOLEAN DEFAULT FALSE,
            gender_specific ENUM('all', 'male', 'female') DEFAULT 'all',
            sort_order INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql2);
        
        // Check if document types exist
        $checkSql = "SELECT COUNT(*) FROM document_types";
        $stmt = $conn->prepare($checkSql);
        $stmt->execute();
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            // Insert predefined document types based on Turkish employment requirements
            $documentTypes = [
                ['kan_grubu', 'Kan Grubu', 'Personelin kan grubu belgesi', 1, 'all', 1],
                ['askerlik_belgesi', 'Askerlik Durumu Belgesi (e-devlet)', 'Erkek çalışanlar için askerlik durumu belgesi', 1, 'male', 2],
                ['sgk_hizmet_listesi', 'Barkodlu SGK Hizmet Listesi (e-devlet)', 'SGK hizmet listesi belgesi', 1, 'all', 3],
                ['hijyen_egitimi', 'Hijyen Eğitim Belgesi', 'Hijyen eğitimi sertifikası', 1, 'all', 4],
                ['vesikalik_foto', '2 Adet Vesikalık Fotoğraf', 'Güncel vesikalık fotoğraflar', 1, 'all', 5],
                ['adli_sicil', 'Adli Sicil Kaydı (e-devlet)', 'Adli sicil kayıt belgesi', 1, 'all', 6],
                ['diploma_kopyasi', 'Diploma Fotokopisi', 'Diploma veya mezuniyet belgesi fotokopisi (e-devlet çıktısı, lise altı için beyan formu)', 1, 'all', 7],
                ['saglik_raporu', 'İşe Giriş Sağlık Raporu', 'Aile hekiminden alınan sağlık raporu', 1, 'all', 8],
                ['is_guvenligi_egitimi', 'İş Güvenliği ve Sağlığı Eğitimi', 'İSG eğitim sertifikası', 1, 'all', 9],
                ['ikametgah_belgesi', 'İkametgâh Belgesi (e-devlet)', 'Güncel ikametgâh belgesi', 1, 'all', 10],
                ['nufus_kayit_ornegi', 'Nüfus Kayıt Örneği (e-devlet)', 'Nüfus kayıt örneği belgesi', 1, 'all', 11],
                ['nufus_cuzdani_kopyasi', 'Nüfus Cüzdanı Fotokopisi', 'TC kimlik kartı fotokopisi', 1, 'all', 12],
                ['kep_adresi', 'KEP Adresi (PTT - 3 yıllık)', 'Belirsiz süreli iş sözleşmesi için KEP adresi', 0, 'all', 13]
            ];
            
            $insertSql = "INSERT INTO document_types (type_code, type_name, description, is_required, gender_specific, sort_order) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insertSql);
            
            foreach ($documentTypes as $doc) {
                $stmt->execute($doc);
            }
        }
        
        // Create upload directory if it doesn't exist
        $uploadDir = '../uploads/documents/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $message = "✅ Evrak yönetim sistemi başarıyla kuruldu!";
        $messageType = "success";
        
    } catch (Exception $e) {
        $message = "❌ Kurulum hatası: " . $e->getMessage();
        $messageType = "error";
    }
}

// Get current table status
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if tables exist
    $tablesExist = [];
    $tables = ['employee_documents', 'document_types'];
    
    foreach ($tables as $table) {
        $stmt = $conn->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$table]);
        $tablesExist[$table] = $stmt->rowCount() > 0;
    }
    
    // Get document types count
    $docTypesCount = 0;
    if ($tablesExist['document_types']) {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM document_types");
        $stmt->execute();
        $docTypesCount = $stmt->fetchColumn();
    }
    
} catch (Exception $e) {
    $error = "Veritabanı kontrol hatası: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evrak Yönetim Sistemi Kurulumu - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="dashboard.php" class="mr-4 text-gray-600 hover:text-gray-800">
                        <i data-lucide="arrow-left" class="w-5 h-5"></i>
                    </a>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Evrak Yönetim Sistemi Kurulumu</h1>
                        <p class="text-sm text-gray-600">Personel evrak yönetimi için gerekli tabloları oluşturun</p>
                    </div>
                </div>
                <div class="text-sm text-gray-600">
                    <?php echo $_SESSION['first_name'] . ' ' . $_SESSION['last_name']; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Message -->
        <?php if (!empty($message)): ?>
        <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'; ?>">
            <?php echo $message; ?>
        </div>
        <?php endif; ?>

        <!-- System Status -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">📊 Sistem Durumu</h2>
            
            <div class="space-y-3">
                <div class="flex justify-between items-center">
                    <span class="text-gray-700">employee_documents tablosu:</span>
                    <span class="<?php echo $tablesExist['employee_documents'] ? 'text-green-600' : 'text-red-600'; ?>">
                        <?php echo $tablesExist['employee_documents'] ? '✅ Mevcut' : '❌ Mevcut Değil'; ?>
                    </span>
                </div>
                
                <div class="flex justify-between items-center">
                    <span class="text-gray-700">document_types tablosu:</span>
                    <span class="<?php echo $tablesExist['document_types'] ? 'text-green-600' : 'text-red-600'; ?>">
                        <?php echo $tablesExist['document_types'] ? '✅ Mevcut' : '❌ Mevcut Değil'; ?>
                    </span>
                </div>
                
                <div class="flex justify-between items-center">
                    <span class="text-gray-700">Evrak türleri:</span>
                    <span class="text-gray-600">
                        <?php echo $docTypesCount; ?> tür tanımlı
                    </span>
                </div>
                
                <div class="flex justify-between items-center">
                    <span class="text-gray-700">Upload dizini:</span>
                    <span class="<?php echo is_dir('../uploads/documents/') ? 'text-green-600' : 'text-red-600'; ?>">
                        <?php echo is_dir('../uploads/documents/') ? '✅ Hazır' : '❌ Mevcut Değil'; ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Setup Action -->
        <div class="bg-white rounded-lg shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">🚀 Kurulum İşlemleri</h2>
            
            <?php if (!$tablesExist['employee_documents'] || !$tablesExist['document_types'] || $docTypesCount === 0): ?>
            <div class="mb-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p class="text-yellow-800">
                    <strong>Dikkat:</strong> Evrak yönetim sistemi henüz kurulmamış. Aşağıdaki butona tıklayarak kurulumu başlatın.
                </p>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="setup_documents">
                <button type="submit" 
                        class="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 inline-flex items-center">
                    <i data-lucide="download" class="w-5 h-5 mr-2"></i>
                    Evrak Yönetim Sistemini Kur
                </button>
            </form>
            <?php else: ?>
            <div class="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p class="text-green-800">
                    <strong>✅ Tamamlandı:</strong> Evrak yönetim sistemi başarıyla kurulmuş ve kullanıma hazır.
                </p>
            </div>
            
            <div class="mt-4 flex space-x-4">
                <a href="../employee/profile.php" 
                   class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 inline-flex items-center">
                    <i data-lucide="user" class="w-4 h-4 mr-2"></i>
                    Personel Profili Görüntüle
                </a>
                <a href="employee-list.php" 
                   class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 inline-flex items-center">
                    <i data-lucide="users" class="w-4 h-4 mr-2"></i>
                    Personel Listesi
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Features -->
        <div class="bg-white rounded-lg shadow-sm p-6 mt-6">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">📄 Evrak Yönetim Özellikleri</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <h3 class="font-medium text-gray-900 mb-2">✅ Desteklenen Evrak Türleri</h3>
                    <ul class="text-sm text-gray-600 space-y-1">
                        <li>• Kan Grubu</li>
                        <li>• Askerlik Durumu Belgesi (Erkekler)</li>
                        <li>• SGK Hizmet Listesi</li>
                        <li>• Hijyen Eğitim Belgesi</li>
                        <li>• Vesikalık Fotoğraflar</li>
                        <li>• Adli Sicil Kaydı</li>
                        <li>• Diploma Fotokopisi</li>
                        <li>• İş Güvenliği Eğitimi</li>
                        <li>• Nüfus ve İkametgah Belgeleri</li>
                        <li>• KEP Adresi</li>
                    </ul>
                </div>
                
                <div>
                    <h3 class="font-medium text-gray-900 mb-2">🔧 Sistem Özellikleri</h3>
                    <ul class="text-sm text-gray-600 space-y-1">
                        <li>• Dosya türü kontrolleri (PDF, JPG, PNG, DOC)</li>
                        <li>• 10MB maksimum dosya boyutu</li>
                        <li>• Evrak onay sistemi (Bekliyor, Onaylandı, Reddedildi)</li>
                        <li>• Admin bypass desteği</li>
                        <li>• Güvenli dosya depolama</li>
                        <li>• Evrak tamamlanma takibi</li>
                        <li>• Personel bazında evrak yönetimi</li>
                        <li>• Dosya görüntüleme ve değiştirme</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>