<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$employee_id = $_GET['employee_id'] ?? '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // First ensure employee_number column exists
    try {
        $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
        if ($columnCheck->rowCount() === 0) {
            // Column doesn't exist, add it
            $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
            
            // Generate employee numbers for existing employees
            $existingEmps = $conn->query("SELECT id FROM employees WHERE employee_number IS NULL OR employee_number = ''");
            foreach ($existingEmps->fetchAll(PDO::FETCH_ASSOC) as $emp) {
                $empNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
                $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
                $updateStmt->execute([$empNumber, $emp['id']]);
            }
        }
    } catch (Exception $e) {
        // If column creation fails, we'll handle it in the error catch below
    }
    
    // Get employees for filter
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, 
               COALESCE(employee_number, CONCAT('EMP', LPAD(id, 4, '0'))) as employee_number 
        FROM employees 
        WHERE company_id = ? AND COALESCE(status, 'active') = 'active'
        ORDER BY first_name, last_name
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get attendance report data
    $whereEmployee = $employee_id ? "AND e.id = ?" : "";
    $params = [$_SESSION['company_id'], $start_date, $end_date];
    if ($employee_id) {
        $params[] = $employee_id;
    }
    
    $stmt = $conn->prepare("
        SELECT 
            e.id,
            e.first_name,
            e.last_name,
            COALESCE(e.employee_number, CONCAT('EMP', LPAD(e.id, 4, '0'))) as employee_number,
            d.name as department_name,
            DATE(aa.timestamp) as work_date,
            MIN(CASE WHEN aa.activity_type = 'work_start' THEN aa.timestamp END) as first_check_in,
            MAX(CASE WHEN aa.activity_type = 'work_end' THEN aa.timestamp END) as last_check_out,
            COUNT(CASE WHEN aa.activity_type LIKE '%_start' THEN 1 END) as total_activities
        FROM employees e
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN attendance_activities aa ON e.id = aa.employee_id 
            AND DATE(aa.timestamp) BETWEEN ? AND ?
        WHERE e.company_id = ? $whereEmployee
        GROUP BY e.id, DATE(aa.timestamp)
        ORDER BY e.first_name, e.last_name, work_date DESC
    ");
    
    $reportParams = [$start_date, $end_date, $_SESSION['company_id']];
    if ($employee_id) {
        $reportParams[] = $employee_id;
    }
    $stmt->execute($reportParams);
    $report_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Veri çekme hatası: " . $e->getMessage();
    
    // Add diagnostic links for different errors
    if (strpos($e->getMessage(), 'employee_number') !== false) {
        $error .= '<br><br><a href="../debug/fix-employee-number-column.php" class="inline-block mt-2 bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm">🔧 Employee Number Sütunu Düzeltme</a>';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raporlar - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">📊</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Devam Raporları</h1>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'Şirket'); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <?php echo strpos($error, '<a href=') !== false ? $error : htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="bg-white rounded-lg shadow mb-8">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Rapor Filtreleri</h2>
                </div>
                <div class="p-6">
                    <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Başlangıç Tarihi</label>
                            <input type="date" name="start_date" value="<?php echo $start_date; ?>" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Bitiş Tarihi</label>
                            <input type="date" name="end_date" value="<?php echo $end_date; ?>" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Personel</label>
                            <select name="employee_id" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Tüm Personel</option>
                                <?php foreach ($employees as $emp): ?>
                                    <option value="<?php echo $emp['id']; ?>" <?php echo $employee_id == $emp['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="flex items-end">
                            <button type="submit" 
                                    class="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                Raporu Getir
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Report Results -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">
                        Devam Raporu (<?php echo count($report_data); ?> kayıt)
                    </h2>
                    <p class="text-sm text-gray-600">
                        <?php echo date('d.m.Y', strtotime($start_date)); ?> - <?php echo date('d.m.Y', strtotime($end_date)); ?>
                    </p>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Personel</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tarih</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İlk Giriş</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Son Çıkış</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Çalışma Süresi</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aktivite</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($report_data as $row): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            No: <?php echo htmlspecialchars($row['employee_number']); ?>
                                        </div>
                                        <div class="text-xs text-gray-400">
                                            <?php echo htmlspecialchars($row['department_name'] ?? '-'); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <?php if ($row['work_date']): ?>
                                            <?php echo date('d.m.Y', strtotime($row['work_date'])); ?>
                                            <div class="text-xs text-gray-500">
                                                <?php echo date('l', strtotime($row['work_date'])); ?>
                                            </div>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <?php if ($row['first_check_in']): ?>
                                            <span class="text-green-600">
                                                <?php echo date('H:i', strtotime($row['first_check_in'])); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <?php if ($row['last_check_out']): ?>
                                            <span class="text-red-600">
                                                <?php echo date('H:i', strtotime($row['last_check_out'])); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <?php if ($row['first_check_in'] && $row['last_check_out']): ?>
                                            <?php
                                            $start = new DateTime($row['first_check_in']);
                                            $end = new DateTime($row['last_check_out']);
                                            $diff = $start->diff($end);
                                            $hours = $diff->h + ($diff->days * 24);
                                            $minutes = $diff->i;
                                            ?>
                                            <span class="font-medium">
                                                <?php echo $hours; ?>s <?php echo $minutes; ?>d
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <span class="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                                            <?php echo $row['total_activities']; ?> aktivite
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>