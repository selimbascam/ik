<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    die("Yetkilendirme hatası");
}

require_once '../includes/config.php';
require_once '../includes/database.php';

$db = new Database();
$conn = $db->getConnection();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>QR Direkt Düzeltme</title>
    <style>
        body { font-family: Arial; margin: 20px; background: #f5f5f5; }
        .box { background: white; padding: 20px; border-radius: 8px; margin: 20px auto; max-width: 800px; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .btn { padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="box">
        <h1>🔧 QR Locations Direkt Düzeltme</h1>
        
        <?php
        try {
            // Drop and recreate the table completely
            echo "<p>Tablo yeniden oluşturuluyor...</p>";
            
            // First disable foreign key checks
            $conn->exec("SET FOREIGN_KEY_CHECKS = 0");
            
            // Drop existing table
            $conn->exec("DROP TABLE IF EXISTS qr_locations");
            
            // Create table with all columns
            $createSQL = "CREATE TABLE qr_locations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                name VARCHAR(255) NOT NULL DEFAULT 'QR Lokasyon',
                location_code VARCHAR(50),
                qr_code VARCHAR(100) NOT NULL,
                location_type VARCHAR(50) DEFAULT 'office',
                description TEXT,
                latitude DECIMAL(10, 8),
                longitude DECIMAL(11, 8),
                address VARCHAR(500),
                tolerance_radius INT DEFAULT 50,
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURTIME()STAMP,
                updated_at TIMESTAMP DEFAULT CURTIME()STAMP ON UPDATE CURTIME()STAMP,
                INDEX idx_company (company_id),
                INDEX idx_qr_code (qr_code),
                UNIQUE KEY uk_qr_code (qr_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
            
            $conn->exec($createSQL);
            
            // Add foreign key
            $conn->exec("ALTER TABLE qr_locations ADD CONSTRAINT fk_qr_company 
                        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE");
            
            // Re-enable foreign key checks
            $conn->exec("SET FOREIGN_KEY_CHECKS = 1");
            
            echo "<p class='success'>✅ Tablo başarıyla oluşturuldu!</p>";
            
            // Test insert
            $testQR = 'QR_TEST_' . time();
            $testCode = 'LOC_TEST_' . time();
            
            $stmt = $conn->prepare("INSERT INTO qr_locations 
                (company_id, name, location_code, qr_code, location_type, description, latitude, longitude, address) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $result = $stmt->execute([
                $_SESSION['company_id'],
                'Test Lokasyon',
                $testCode,
                $testQR,
                'office',
                'Test açıklama',
                41.0082,
                28.9784,
                'Test adres'
            ]);
            
            if ($result) {
                echo "<p class='success'>✅ Test ekleme başarılı!</p>";
                // Clean up test
                $conn->exec("DELETE FROM qr_locations WHERE qr_code = '$testQR'");
                echo "<p>Test verisi temizlendi.</p>";
            }
            
            echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
            echo "<h2 style='color: #155724; margin: 0;'>✅ Düzeltme Tamamlandı!</h2>";
            echo "<p style='color: #155724;'>QR lokasyon tablosu başarıyla düzeltildi. Artık QR kod oluşturabilirsiniz.</p>";
            echo "</div>";
            
        } catch (Exception $e) {
            echo "<p class='error'>❌ Hata: " . $e->getMessage() . "</p>";
            
            // Try to re-enable foreign keys on error
            try { $conn->exec("SET FOREIGN_KEY_CHECKS = 1"); } catch (Exception $e2) {}
        }
        ?>
        
        <a href="qr-generator.php" class="btn">QR Generator'a Git</a>
    </div>
</body>
</html>