<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/google-maps-config.php';

$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Autocommit modunu etkinleştir
        $conn->setAttribute(PDO::ATTR_AUTOCOMMIT, true);
        
        if ($action === 'add_company') {
            $companyName = trim($_POST['company_name'] ?? '');
            $companyCode = trim($_POST['company_code'] ?? '');
            $adminEmail = trim($_POST['admin_email'] ?? '');
            $adminPassword = trim($_POST['admin_password'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $address = trim($_POST['address'] ?? '');
            $taxNumber = trim($_POST['tax_number'] ?? '');
            $companyType = $_POST['company_type'] ?? 'corporate'; // corporate or individual
            
            // Validate required fields
            if (empty($companyName) || empty($companyCode) || empty($adminEmail) || empty($adminPassword)) {
                throw new Exception("Şirket adı, kod, yönetici e-posta ve şifre zorunludur.");
            }
            
            // Check if company code exists - with error handling
            try {
                $checkStmt = $conn->prepare("SELECT id FROM companies WHERE company_code = ?");
                $checkStmt->execute([$companyCode]);
                if ($checkStmt->fetch()) {
                    throw new Exception("Bu şirket kodu zaten kullanılıyor. Farklı bir kod seçin.");
                }
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'company_code') !== false) {
                    throw new Exception("Veritabanı hatası: company_code kolonu bulunamadı. Lütfen sistem yöneticisine başvurun.");
                }
                throw $e;
            }
            
            // Check if admin email exists
            $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $checkStmt->execute([$adminEmail]);
            if ($checkStmt->fetch()) {
                throw new Exception("Bu e-posta adresi zaten kullanılıyor.");
            }
            
            // Start transaction
            $conn->beginTransaction();
            
            try {
                // Insert company with type - with error handling
                try {
                    $stmt = $conn->prepare("
                        INSERT INTO companies (company_name, company_code, email, phone, address, tax_number, company_type, status, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())
                    ");
                    $stmt->execute([$companyName, $companyCode, $adminEmail, $phone, $address, $taxNumber, $companyType]);
                } catch (PDOException $e) {
                    if (strpos($e->getMessage(), 'company_code') !== false || strpos($e->getMessage(), 'company_type') !== false) {
                        throw new Exception("Veritabanı hatası: Eksik kolonlar tespit edildi. Lütfen sistem yöneticisine başvurun.");
                    }
                    throw $e;
                }
                $companyId = $conn->lastInsertId();
                
                // Insert admin user (MySQL compatible)
                $stmt = $conn->prepare("
                    INSERT INTO users (email, password_hash, first_name, last_name, role, company_id, is_active, created_at) 
                    VALUES (?, SHA2(?, 256), ?, ?, 'admin', ?, 1, NOW())
                ");
                $names = explode(' ', $companyName, 2);
                $firstName = $names[0];
                $lastName = $names[1] ?? 'Admin';
                
                $stmt->execute([$adminEmail, $adminPassword, $firstName, $lastName, $companyId]);
                $adminId = $conn->lastInsertId();
                
                // Create default departments (MySQL compatible)
                $stmt = $conn->prepare("
                    INSERT INTO departments (company_id, name, description, is_active, created_at) 
                    VALUES 
                    (?, 'İnsan Kaynakları', 'İK Departmanı', 1, NOW()),
                    (?, 'Genel Müdürlük', 'Yönetim Departmanı', 1, NOW()),
                    (?, 'Operasyon', 'Operasyon Departmanı', 1, NOW())
                ");
                $stmt->execute([$companyId, $companyId, $companyId]);
                
                // Create sample QR locations
                $defaultLocations = [
                    ['Ana Giriş', 'GIRIS_' . $companyCode, 'entrance', 'Ana giriş kapısı'],
                    ['Ofis', 'OFIS_' . $companyCode, 'office', 'Çalışma alanı'],
                    ['Yemekhane', 'YEMEK_' . $companyCode, 'dining', 'Personel yemekhanesi'],
                    ['Mola Alanı', 'MOLA_' . $companyCode, 'break', 'Dinlenme alanı']
                ];
                
                foreach ($defaultLocations as $index => $location) {
                    $qrCode = 'QR_' . $companyCode . '_' . str_pad($index + 1, 3, '0', STR_PAD_LEFT);
                    $stmt = $conn->prepare("
                        INSERT INTO qr_locations (company_id, name, location_code, qr_code, location_type, description, is_active, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, 1, NOW())
                    ");
                    $stmt->execute([$companyId, $location[0], $location[1], $qrCode, $location[2], $location[3]]);
                }
                
                // Create default work settings with auto table creation
                try {
                    // Create work_settings table if it doesn't exist
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS work_settings (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            hourly_rate DECIMAL(10,2) DEFAULT 15.00,
                            monthly_hours INT DEFAULT 225,
                            weekly_hours_limit INT DEFAULT 45,
                            daily_hours_limit INT DEFAULT 8,
                            overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
                            weekend_multiplier DECIMAL(3,2) DEFAULT 2.00,
                            holiday_multiplier DECIMAL(3,2) DEFAULT 2.50,
                            auto_schedule TINYINT(1) DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            UNIQUE KEY unique_company (company_id)
                        )
                    ");
                    
                    $stmt = $conn->prepare("
                        INSERT INTO work_settings (
                            company_id, hourly_rate, monthly_hours, weekly_hours_limit, daily_hours_limit,
                            overtime_multiplier, weekend_multiplier, holiday_multiplier, auto_schedule, created_at
                        ) VALUES (?, 15.00, 225, 45, 8, 1.5, 2.0, 2.5, 1, NOW())
                    ");
                    $stmt->execute([$companyId]);
                } catch (PDOException $e) {
                    // Continue if work_settings creation fails
                    error_log('Work settings creation failed: ' . $e->getMessage());
                }
                
                // Transaction'ı sadece aktifse commit yap
                if ($conn->inTransaction()) {
                    $conn->commit();
                }
                $message = "✅ Şirket başarıyla oluşturuldu! 
                <br><strong>Giriş Bilgileri:</strong>
                <br>• Şirket Kodu: <strong>$companyCode</strong>
                <br>• E-posta: <strong>$adminEmail</strong>
                <br>• Şifre: <strong>" . htmlspecialchars($adminPassword ?? '') . "</strong>
                <br>• Şirket ID: <strong>$companyId</strong>
                <br><br>🔗 <a href='../auth/company-login.php' class='text-blue-600 underline'>Şimdi giriş yapın</a>";
                $messageType = 'success';
                
            } catch (Exception $e) {
                // Transaction'ı sadece aktifse rollback yap
                if ($conn->inTransaction()) {
                    $conn->rollback();
                }
                throw $e;
            }
        }
        
    } catch (Exception $e) {
        $message = "Hata: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Generate next company code
function generateNextCompanyCode($conn) {
    try {
        $stmt = $conn->query("SELECT company_code FROM companies WHERE company_code REGEXP '^[A-Z]{3}[0-9]{5}$' ORDER BY company_code DESC LIMIT 1");
        $lastCode = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($lastCode && $lastCode['company_code']) {
            // Extract the numeric part
            $lastNumber = intval(substr($lastCode['company_code'], 3));
            $nextNumber = $lastNumber + 1;
            
            // Get the letter part or generate new one
            $letterPart = substr($lastCode['company_code'], 0, 3);
            
            // If we've reached 99999, increment the letter part
            if ($nextNumber > 99999) {
                $nextNumber = 1;
                $letterPart = incrementLetterCode($letterPart);
            }
            
            return $letterPart . str_pad($nextNumber, 5, '0', STR_PAD_LEFT);
        } else {
            // First company - start with AAA00001
            return 'AAA00001';
        }
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'company_code') !== false) {
            // Column doesn't exist, return a default code
            return 'AAA00001';
        }
        // Fallback to random generation
        return generateRandomCompanyCode();
    }
}

function incrementLetterCode($letterCode) {
    $letters = str_split($letterCode);
    
    // Increment from right to left
    for ($i = 2; $i >= 0; $i--) {
        if ($letters[$i] < 'Z') {
            $letters[$i] = chr(ord($letters[$i]) + 1);
            break;
        } else {
            $letters[$i] = 'A';
            if ($i == 0) {
                // All letters are Z, wrap to AAA
                return 'AAA';
            }
        }
    }
    
    return implode('', $letters);
}

function generateRandomCompanyCode() {
    $letters = '';
    for ($i = 0; $i < 3; $i++) {
        $letters .= chr(rand(65, 90)); // A-Z
    }
    $numbers = str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
    return $letters . $numbers;
}

// Get existing companies and next code
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Try to select companies with error handling
    try {
        $stmt = $conn->query("SELECT * FROM companies ORDER BY created_at DESC");
        $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'created_at') !== false) {
            // created_at column missing, try without it
            $stmt = $conn->query("SELECT * FROM companies ORDER BY id DESC");
            $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            throw $e;
        }
    }
    
    $nextCompanyCode = generateNextCompanyCode($conn);
} catch (Exception $e) {
    $companies = [];
    $nextCompanyCode = 'AAA00001';
    $message = "Veritabanı bağlantı hatası: " . $e->getMessage();
    $messageType = 'error';
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Yönetimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Maps functionality removed for MySQL compatibility -->
    <!-- Google Maps API (Replace YOUR_GOOGLE_MAPS_API_KEY with actual key) -->
    <script>
        // Check if Google Maps API key is configured
        const GOOGLE_MAPS_API_KEY = 'YOUR_GOOGLE_MAPS_API_KEY'; // Replace with actual key
        if (GOOGLE_MAPS_API_KEY !== 'YOUR_GOOGLE_MAPS_API_KEY') {
            const script = document.createElement('script');
            script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places&callback=initAutocomplete`;
            script.async = 1;
            script.defer = 1;
            document.head.appendChild(script);
        } else {
            // API key not configured - provide fallback
            window.initAutocomplete = function() {
                console.warn('Google Maps API key not configured');
            };
        }
    </script>
    <style>
        .pac-container {
            z-index: 9999 !important;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen py-12">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-900">Şirket Yönetimi</h1>
                <p class="text-gray-600 mt-2">Yeni şirket oluşturun ve mevcut şirketleri yönetin</p>
            </div>

            <!-- Messages -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                        'bg-red-100 text-red-800 border border-red-200'; 
                ?>">
                    <?php echo $message; // Don't escape HTML for success messages with links ?>
                    <?php if (strpos($message, 'Veritabanı hatası') !== false): ?>
                        <br><br>
                        <a href="../dashboard/company-dashboard.php" class="bg-blue-600 text-white px-4 py-2 rounded inline-block hover:bg-blue-700">
                            🏠 Yönetici Paneline Dön
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Add New Company Form -->
            <div class="bg-white shadow rounded-lg mb-8">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Yeni Şirket Oluştur</h2>
                </div>
                <div class="p-6">
                    <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <input type="hidden" name="action" value="add_company">
                        
                        <div class="md:col-span-2">
                            <label for="company_type" class="block text-sm font-medium text-gray-700">Şirket Türü *</label>
                            <select 
                                id="company_type" 
                                name="company_type" 
                                required
                                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                onchange="updateFormFields()"
                            >
                                <option value="corporate">🏢 Tüzel Kişi (Şirket/Kurum)</option>
                                <option value="individual">👤 Gerçek Kişi (Şahıs İşletmesi)</option>
                            </select>
                        </div>

                        <div class="md:col-span-2">
                            <label for="company_name" class="block text-sm font-medium text-gray-700">
                                <span id="company_name_label">Şirket Adı</span> *
                            </label>
                            <input 
                                type="text" 
                                id="company_name" 
                                name="company_name" 
                                required
                                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                placeholder="Örnek: ABC Teknoloji A.Ş."
                            >
                        </div>

                        <div>
                            <label for="company_code" class="block text-sm font-medium text-gray-700">Şirket Kodu *</label>
                            <div class="flex items-center space-x-2">
                                <input 
                                    type="text" 
                                    id="company_code" 
                                    name="company_code" 
                                    required
                                    maxlength="8"
                                    value="<?php echo htmlspecialchars($nextCompanyCode); ?>"
                                    class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="ABC00001"
                                    readonly
                                >
                                <button 
                                    type="button" 
                                    onclick="generateNewCode()"
                                    class="mt-1 bg-gray-500 text-white px-3 py-2 rounded-md hover:bg-gray-600 text-sm"
                                    title="Yeni kod oluştur"
                                >
                                    🔄
                                </button>
                            </div>
                            <p class="text-xs text-gray-500 mt-1">Otomatik oluşturulan benzersiz kod (3 harf + 5 rakam)</p>
                        </div>

                        <div>
                            <label for="tax_number" class="block text-sm font-medium text-gray-700">
                                <span id="tax_number_label">Vergi Numarası</span>
                            </label>
                            <input 
                                type="text" 
                                id="tax_number" 
                                name="tax_number" 
                                maxlength="11"
                                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                placeholder="12345678901"
                            >
                            <p id="tax_number_help" class="text-xs text-gray-500 mt-1">Tüzel kişi için vergi numarası</p>
                        </div>

                        <div>
                            <label for="admin_email" class="block text-sm font-medium text-gray-700">Yönetici E-posta *</label>
                            <input 
                                type="email" 
                                id="admin_email" 
                                name="admin_email" 
                                required
                                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                placeholder="admin@sirket.com"
                            >
                        </div>

                        <div>
                            <label for="admin_password" class="block text-sm font-medium text-gray-700">Yönetici Şifresi *</label>
                            <input 
                                type="password" 
                                id="admin_password" 
                                name="admin_password" 
                                required
                                minlength="6"
                                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                placeholder="Güvenli şifre"
                            >
                        </div>

                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700">Telefon</label>
                            <input 
                                type="tel" 
                                id="phone" 
                                name="phone"
                                class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                placeholder="+90 312 123 4567"
                            >
                        </div>

                        <div>
                            <label for="address" class="block text-sm font-medium text-gray-700">Adres</label>
                            <div class="relative">
                                <textarea 
                                    id="address" 
                                    name="address"
                                    rows="3"
                                    class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="Şirket adresini yazın veya aşağıdan seçin..."
                                ></textarea>
                                <button 
                                    type="button" 
                                    onclick="searchAddress()" 
                                    class="absolute top-2 right-2 bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600"
                                    title="Google Maps'ten adres ara"
                                    id="address-search-btn"
                                >
                                    🔍 Ara
                                </button>
                            </div>
                            <div id="address-suggestions" class="mt-2 hidden bg-white border border-gray-300 rounded-md shadow-lg max-h-48 overflow-y-auto z-10 absolute w-full"></div>
                        </div>

                        <div class="md:col-span-2">
                            <button 
                                type="submit"
                                class="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                            >
                                🏢 Şirket Oluştur
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Existing Companies -->
            <div class="bg-white shadow rounded-lg">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Mevcut Şirketler</h2>
                    <p class="text-sm text-gray-600">Toplam <?php echo count($companies); ?> şirket</p>
                </div>
                <div class="overflow-x-auto">
                    <?php if (empty($companies)): ?>
                        <div class="p-6 text-center text-gray-500">
                            <p>Henüz şirket eklenmemiş.</p>
                            <p class="text-sm mt-2">Yukarıdaki formu kullanarak ilk şirketi ekleyin.</p>
                        </div>
                    <?php else: ?>
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Şirket</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İletişim</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Oluşturulma</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($companies as $company): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                                                    <span class="text-blue-600 font-medium text-sm">
                                                        <?php echo strtoupper(substr($company['company_code'] ?? $company['company_name'], 0, 2)); ?>
                                                    </span>
                                                </div>
                                                <div>
                                                    <div class="text-sm font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($company['company_name']); ?>
                                                    </div>
                                                    <div class="text-sm text-gray-500">
                                                        Kod: <?php echo htmlspecialchars($company['company_code'] ?? 'N/A'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            <div><?php echo htmlspecialchars($company['email'] ?? '-'); ?></div>
                                            <div class="text-gray-500"><?php echo htmlspecialchars($company['phone'] ?? '-'); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php if (($company['status'] ?? 'active') === 'active'): ?>
                                                <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                    Aktif
                                                </span>
                                            <?php else: ?>
                                                <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                    Pasif
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo date('d.m.Y', strtotime($company['created_at'] ?? 'now')); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <?php if ($company['company_code']): ?>
                                                <a href="../auth/company-login.php?demo=<?php echo $company['company_code']; ?>" 
                                                   class="text-indigo-600 hover:text-indigo-900">
                                                    Giriş Yap
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="mt-8 text-center">
                <?php if (isset($_GET['from']) && $_GET['from'] === 'super-admin'): ?>
                    <a href="../super-admin/" class="inline-block bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors mr-4">
                        ← Süper Admin Panel
                    </a>
                <?php else: ?>
                    <a href="../auth/company-login.php" class="inline-block bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition-colors mr-4">
                        ← Şirket Girişi
                    </a>
                <?php endif; ?>
                <a href="../test-login.php" class="inline-block bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
                    Demo Test
                </a>
            </div>
        </div>
    </div>

    <script>
        let autocomplete;
        let map;
        let marker;

        function initAutocomplete() {
            // Check if Google Maps is loaded
            if (typeof google === 'undefined' || !google.maps) {
                console.warn('Google Maps API not loaded - address search disabled');
                // Hide search button if no API
                const searchBtn = document.querySelector('button[onclick="searchAddress()"]');
                if (searchBtn) {
                    searchBtn.style.display = 'none';
                }
                return;
            }

            try {
                // Initialize Google Places Autocomplete
                autocomplete = new google.maps.places.Autocomplete(
                    document.getElementById('address'),
                    {
                        types: ['establishment', 'geocode'],
                        componentRestrictions: { country: 'TR' } // Restrict to Turkey
                    }
                );

                // Listen for place selection
                autocomplete.addListener('place_changed', function() {
                    const place = autocomplete.getPlace();
                    
                    if (!place.geometry) {
                        console.log("No details available for input: '" + place.name + "'");
                        return;
                    }

                    // Update address field with formatted address
                    document.getElementById('address').value = place.formatted_address;
                    
                    // Store coordinates for later use
                    window.selectedLocation = {
                        lat: place.geometry.location.lat(),
                        lng: place.geometry.location.lng(),
                        address: place.formatted_address,
                        place_id: place.place_id
                    };
                    
                    console.log('Selected location:', window.selectedLocation);
                });
            } catch (error) {
                console.error('Error initializing Google Places:', error);
            }
        }

        function searchAddress() {
            const addressInput = document.getElementById('address');
            const query = addressInput.value.trim();
            
            if (!query) {
                alert('Lütfen aranacak adresi girin');
                return;
            }

            // Check if Google Maps is available
            if (typeof google === 'undefined' || !google.maps) {
                alert('Google Maps API yapılandırılmadı. Adresi manuel olarak girin.');
                return;
            }
            
            try {
                // Trigger Places API search
                const service = new google.maps.places.PlacesService(document.createElement('div'));
                
                service.textSearch({
                    query: query + ' Turkey',
                    type: 'establishment'
                }, function(results, status) {
                    if (status === google.maps.places.PlacesServiceStatus.OK) {
                        showAddressSuggestions(results);
                    } else {
                        alert('Adres arama başarısız. Lütfen farklı bir terim deneyin.');
                    }
                });
            } catch (error) {
                console.error('Address search error:', error);
                alert('Adres arama hatası. Adresi manuel olarak girin.');
            }
        }

        function showAddressSuggestions(results) {
            const suggestionsDiv = document.getElementById('address-suggestions');
            suggestionsDiv.innerHTML = '';
            suggestionsDiv.classList.remove('hidden');
            
            results.slice(0, 10).forEach(function(place, index) {
                const suggestion = document.createElement('div');
                suggestion.className = 'p-3 border-b border-gray-200 hover:bg-gray-50 cursor-pointer';
                suggestion.innerHTML = `
                    <div class="flex items-start">
                        <div class="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                            <span class="text-blue-600 text-xs font-medium">${index + 1}</span>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="text-sm font-medium text-gray-900">${place.name}</div>
                            <div class="text-sm text-gray-500 truncate">${place.formatted_address}</div>
                            <div class="text-xs text-gray-400 mt-1">Rating: ${place.rating || 'N/A'} | ${place.types?.[0] || 'Unknown'}</div>
                        </div>
                    </div>
                `;
                
                suggestion.onclick = function() {
                    selectAddress(place);
                };
                
                suggestionsDiv.appendChild(suggestion);
            });
        }

        function selectAddress(place) {
            // Update form field
            document.getElementById('address').value = place.formatted_address;
            
            // Store location data
            window.selectedLocation = {
                lat: place.geometry ? place.geometry.location.lat : null,
                lng: place.geometry ? place.geometry.location.lng : null,
                address: place.formatted_address,
                place_id: place.place_id,
                name: place.name
            };
            
            // Hide suggestions
            document.getElementById('address-suggestions').classList.add('hidden');
            
            console.log('Selected address:', window.selectedLocation);
        }

        // Hide suggestions when clicking outside
        document.addEventListener('click', function(event) {
            const suggestionsDiv = document.getElementById('address-suggestions');
            const addressInput = document.getElementById('address');
            
            if (!suggestionsDiv.contains(event.target) && event.target !== addressInput) {
                suggestionsDiv.classList.add('hidden');
            }
        });

        // Initialize when page loads
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Google Maps after a short delay to ensure API is loaded
            setTimeout(function() {
                if (typeof initAutocomplete === 'function') {
                    initAutocomplete();
                }
            }, 1000);
        });

    </script>
    
    <script>
    // Update form fields based on company type
    function updateFormFields() {
        const companyType = document.getElementById('company_type').value;
        const companyNameLabel = document.getElementById('company_name_label');
        const companyNameInput = document.getElementById('company_name');
        const taxNumberLabel = document.getElementById('tax_number_label');
        const taxNumberHelp = document.getElementById('tax_number_help');
        
        if (companyType === 'individual') {
            companyNameLabel.textContent = 'Ad Soyad / İşletme Adı';
            companyNameInput.placeholder = 'Örnek: Mehmet YILMAZ veya Mehmet YILMAZ İnşaat';
            taxNumberLabel.textContent = 'TC Kimlik No / Vergi No';
            taxNumberHelp.textContent = 'Gerçek kişi için TC Kimlik Numarası';
        } else {
            companyNameLabel.textContent = 'Şirket Adı';
            companyNameInput.placeholder = 'Örnek: ABC Teknoloji A.Ş.';
            taxNumberLabel.textContent = 'Vergi Numarası';
            taxNumberHelp.textContent = 'Tüzel kişi için vergi numarası';
        }
    }

    function generateNewCode() {
        // Generate a new random company code
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        let code = '';
        
        // Generate 3 random letters
        for (let i = 0; i < 3; i++) {
            code += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        
        // Generate 5 random numbers
        const numbers = Math.floor(Math.random() * 99999) + 1;
        code += numbers.toString().padStart(5, '0');
        
        document.getElementById('company_code').value = code;
    }
    
    // Auto-generate company code from company name
    document.getElementById('company_name').addEventListener('input', function() {
        const companyName = this.value.toUpperCase();
        const codeInput = document.getElementById('company_code');
        
        if (companyName.length >= 3 && codeInput.value === '<?php echo $nextCompanyCode; ?>') {
            // Extract first 3 letters from company name
            let letters = '';
            for (let char of companyName) {
                if (char.match(/[A-Z]/)) {
                    letters += char;
                    if (letters.length === 3) break;
                }
            }
            
            // Pad with random letters if needed
            while (letters.length < 3) {
                const randomLetter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.charAt(Math.floor(Math.random() * 26));
                letters += randomLetter;
            }
            
            // Generate 5 random numbers
            const numbers = Math.floor(Math.random() * 99999) + 1;
            const newCode = letters + numbers.toString().padStart(5, '0');
            
            codeInput.value = newCode;
        }
    });

    // Initialize form on page load
    document.addEventListener('DOMContentLoaded', function() {
        updateFormFields();
    });
    </script>
</body>
</html>