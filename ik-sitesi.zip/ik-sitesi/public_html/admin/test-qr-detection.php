<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "<h1>QR Gate Detection Test</h1>";

// Test QR names
$testNames = ['giriş', 'Giriş', 'GIRIŞ', 'giris', 'çıkış', 'Çıkış', 'ÇIKIŞ', 'cikis', 'mola', 'Mola'];

foreach ($testNames as $testName) {
    // Türkçe karakter uyumlu küçük harf dönüşümü
    $qrName = mb_strtolower(trim($testName), 'UTF-8');
    
    // Ekstra Türkçe karakter temizliği
    $qrName = str_replace(['İ', 'I'], 'i', $qrName);
    $qrName = str_replace(['Ğ'], 'ğ', $qrName);
    $qrName = str_replace(['Ü'], 'ü', $qrName);
    $qrName = str_replace(['Ş'], 'ş', $qrName);
    $qrName = str_replace(['Ö'], 'ö', $qrName);
    $qrName = str_replace(['Ç'], 'ç', $qrName);
    
    echo "<p><strong>Test Name: '$testName' → Processed: '$qrName'</strong></p>";
    
    if (stripos($qrName, 'giriş') !== false || stripos($qrName, 'giris') !== false || 
        stripos($qrName, 'entrance') !== false) {
        echo "<span style='color: green'>✅ Detected as ENTRANCE gate (work_start)</span><br>";
    } elseif (stripos($qrName, 'çıkış') !== false || stripos($qrName, 'cikis') !== false || 
              stripos($qrName, 'çikış') !== false || stripos($qrName, 'exit') !== false) {
        echo "<span style='color: red'>✅ Detected as EXIT gate (work_end)</span><br>";
    } elseif (stripos($qrName, 'mola') !== false || stripos($qrName, 'break') !== false) {
        echo "<span style='color: orange'>✅ Detected as BREAK gate (break_toggle)</span><br>";
    } else {
        echo "<span style='color: gray'>❌ Not detected - will use default</span><br>";
    }
    echo "<hr>";
}

// Check actual QR locations from database
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>Actual QR Locations in Database</h2>";
    $stmt = $conn->prepare("SELECT id, name, location_type, gate_behavior FROM qr_locations ORDER BY id");
    $stmt->execute();
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($locations as $location) {
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 5px;'>";
        echo "<strong>ID: {$location['id']}</strong><br>";
        echo "Name: '{$location['name']}'<br>";
        echo "Type: {$location['location_type']}<br>";
        echo "Behavior: {$location['gate_behavior']}<br>";
        
        // Test detection on this name
        $qrName = mb_strtolower(trim($location['name']), 'UTF-8');
        $qrName = str_replace(['İ', 'I'], 'i', $qrName);
        $qrName = str_replace(['Ğ'], 'ğ', $qrName);
        $qrName = str_replace(['Ü'], 'ü', $qrName);
        $qrName = str_replace(['Ş'], 'ş', $qrName);
        $qrName = str_replace(['Ö'], 'ö', $qrName);
        $qrName = str_replace(['Ç'], 'ç', $qrName);
        
        if (stripos($qrName, 'giriş') !== false || stripos($qrName, 'giris') !== false || stripos($qrName, 'entrance') !== false) {
            echo "<span style='color: green'>→ Will be detected as ENTRANCE</span><br>";
        } elseif (stripos($qrName, 'çıkış') !== false || stripos($qrName, 'cikis') !== false || stripos($qrName, 'exit') !== false) {
            echo "<span style='color: red'>→ Will be detected as EXIT</span><br>";
        } elseif (stripos($qrName, 'mola') !== false || stripos($qrName, 'break') !== false) {
            echo "<span style='color: orange'>→ Will be detected as BREAK</span><br>";
        } else {
            echo "<span style='color: gray'>→ Will use database settings</span><br>";
        }
        echo "</div>";
    }
} catch (Exception $e) {
    echo "Database error: " . $e->getMessage();
}
?>