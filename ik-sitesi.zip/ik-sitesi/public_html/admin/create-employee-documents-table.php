<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Create employee documents table
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Create employee_documents table
    $sql = "CREATE TABLE IF NOT EXISTS employee_documents (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        company_id INT NOT NULL,
        document_type VARCHAR(100) NOT NULL,
        document_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_size INT,
        mime_type VARCHAR(100),
        uploaded_by INT,
        upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        expiry_date DATE NULL,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_employee_documents (employee_id),
        INDEX idx_company_documents (company_id),
        INDEX idx_document_type (document_type),
        INDEX idx_document_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($sql);
    echo "✅ employee_documents tablosu başarıyla oluşturuldu!<br>";
    
    // Create document types reference table
    $sql2 = "CREATE TABLE IF NOT EXISTS document_types (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type_code VARCHAR(50) UNIQUE NOT NULL,
        type_name VARCHAR(255) NOT NULL,
        description TEXT,
        is_required BOOLEAN DEFAULT FALSE,
        gender_specific ENUM('all', 'male', 'female') DEFAULT 'all',
        sort_order INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($sql2);
    echo "✅ document_types tablosu başarıyla oluşturuldu!<br>";
    
    // Insert predefined document types
    $documentTypes = [
        ['kan_grubu', 'Kan Grubu', 'Personelin kan grubu belgesi', 1, 'all', 1],
        ['askerlik_belgesi', 'Askerlik Durumu Belgesi (e-devlet)', 'Erkek çalışanlar için askerlik durumu belgesi', 1, 'male', 2],
        ['sgk_hizmet_listesi', 'Barkodlu SGK Hizmet Listesi (e-devlet)', 'SGK hizmet listesi belgesi', 1, 'all', 3],
        ['hijyen_egitimi', 'Hijyen Eğitim Belgesi', 'Hijyen eğitimi sertifikası', 1, 'all', 4],
        ['vesikalik_foto', '2 Adet Vesikalık Fotoğraf', 'Güncel vesikalık fotoğraflar', 1, 'all', 5],
        ['adli_sicil', 'Adli Sicil Kaydı (e-devlet)', 'Adli sicil kayıt belgesi', 1, 'all', 6],
        ['diploma_kopyasi', 'Diploma Fotokopisi', 'Diploma veya mezuniyet belgesi fotokopisi', 1, 'all', 7],
        ['saglik_raporu', 'İşe Giriş Sağlık Raporu', 'Aile hekiminden alınan sağlık raporu', 1, 'all', 8],
        ['is_guvenligi_egitimi', 'İş Güvenliği ve Sağlığı Eğitimi', 'İSG eğitim sertifikası', 1, 'all', 9],
        ['ikametgah_belgesi', 'İkametgâh Belgesi (e-devlet)', 'Güncel ikametgâh belgesi', 1, 'all', 10],
        ['nufus_kayit_ornegi', 'Nüfus Kayıt Örneği (e-devlet)', 'Nüfus kayıt örneği belgesi', 1, 'all', 11],
        ['nufus_cuzdani_kopyasi', 'Nüfus Cüzdanı Fotokopisi', 'TC kimlik kartı fotokopisi', 1, 'all', 12],
        ['kep_adresi', 'KEP Adresi (PTT - 3 yıllık)', 'Belirsiz süreli iş sözleşmesi için KEP adresi', 0, 'all', 13]
    ];
    
    $checkSql = "SELECT COUNT(*) FROM document_types";
    $stmt = $conn->prepare($checkSql);
    $stmt->execute();
    $count = $stmt->fetchColumn();
    
    if ($count == 0) {
        $insertSql = "INSERT INTO document_types (type_code, type_name, description, is_required, gender_specific, sort_order) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        
        foreach ($documentTypes as $doc) {
            $stmt->execute($doc);
        }
        echo "✅ Varsayılan evrak türleri başarıyla eklendi!<br>";
    } else {
        echo "ℹ️ Evrak türleri zaten mevcut.<br>";
    }
    
    echo "<br>🎉 Evrak yönetim sistemi hazır!";
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evrak Tabloları Oluşturma</title>
</head>
<body>
    <h2>Personel Evrak Sistemi Kurulumu</h2>
    <p><a href="../admin/dashboard.php">← Admin Paneli'ne Dön</a></p>
</body>
</html>