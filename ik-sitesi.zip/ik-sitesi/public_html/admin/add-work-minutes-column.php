<?php
// Add work_minutes column to attendance_records table if it doesn't exist
require_once '../includes/config.php';
require_once '../includes/db.php';

session_start();

// Check if user is logged in as admin or super admin
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    die("❌ Yetkisiz erişim!");
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if work_minutes column exists
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records LIKE 'work_minutes'");
    if ($stmt->rowCount() == 0) {
        // Add work_minutes column
        $conn->exec("ALTER TABLE attendance_records ADD COLUMN work_minutes INT DEFAULT 0 AFTER check_out");
        echo "✅ work_minutes sütunu başarıyla eklendi!<br>";
    } else {
        echo "ℹ️ work_minutes sütunu zaten mevcut.<br>";
    }
    
    echo "<br><a href='test-gate-system.php' class='text-blue-600 hover:underline'>← Test Paneline Dön</a>";
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage();
}
?>