<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['company_id'])) {
    die("Lütfen giriş yapın.");
}

require_once '../includes/database.php';

echo "<h1>Mevcut QR Kodları Güncelle</h1>";
echo "<p>Şirket ID: " . $_SESSION['company_id'] . "</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Mevcut QR lokasyonları getir
    $stmt = $conn->prepare("SELECT id, name, location_type, latitude, longitude, qr_code FROM qr_locations WHERE company_id = ?");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll();
    
    echo "<h2>Mevcut QR Kodları:</h2>";
    echo "<table border='1' cellpadding='8'>";
    echo "<tr><th>ID</th><th>İsim</th><th>Tür</th><th>Eski QR</th><th>Yeni QR</th><th>Durum</th></tr>";
    
    $updated_count = 0;
    
    foreach ($locations as $loc) {
        // Hareket tipini belirle
        $movement_type = '';
        switch($loc['location_type']) {
            case 'check_in':
                $movement_type = 'work_start';
                break;
            case 'check_out':
                $movement_type = 'work_end';
                break;
            case 'tea_break':
            case 'lunch_break':
            case 'smoke_break':
                $movement_type = 'break_start';
                break;
            default:
                $movement_type = 'general';
        }
        
        // Yeni QR kod içeriği: şirket_id|hareket_tipi|konum_id|lat,lng
        $new_qr_content = "{$_SESSION['company_id']}|{$movement_type}|{$loc['id']}|{$loc['latitude']},{$loc['longitude']}";
        
        echo "<tr>";
        echo "<td>{$loc['id']}</td>";
        echo "<td>" . htmlspecialchars($loc['name']) . "</td>";
        echo "<td>{$loc['location_type']}</td>";
        echo "<td>" . htmlspecialchars($loc['qr_code']) . "</td>";
        echo "<td>" . htmlspecialchars($new_qr_content) . "</td>";
        
        // QR kodu güncelle
        if ($_POST['update_all'] ?? false) {
            $update_stmt = $conn->prepare("UPDATE qr_locations SET qr_code = ? WHERE id = ? AND company_id = ?");
            $update_result = $update_stmt->execute([$new_qr_content, $loc['id'], $_SESSION['company_id']]);
            
            if ($update_result && $update_stmt->rowCount() > 0) {
                echo "<td style='color: green;'>✅ Güncellendi</td>";
                $updated_count++;
            } else {
                echo "<td style='color: red;'>❌ Hata</td>";
            }
        } else {
            echo "<td>-</td>";
        }
        
        echo "</tr>";
    }
    
    echo "</table>";
    
    if ($_POST['update_all'] ?? false) {
        echo "<h2>Sonuç: {$updated_count} QR kod güncellendi!</h2>";
    } else {
        echo "<form method='POST'>";
        echo "<button type='submit' name='update_all' value='1' style='background: green; color: white; padding: 15px; font-size: 16px; margin: 20px 0;'>🔄 Tüm QR Kodları Güncelle</button>";
        echo "</form>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Hata: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>