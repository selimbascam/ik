<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    // Allow super admin bypass
    if (!isset($_SESSION['super_admin_bypass'])) {
        header('Location: ../auth/company-login.php');
        exit;
    }
}

// Get company users
$users = [];
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get company info
    $stmt = $conn->prepare("SELECT company_name, company_code FROM companies WHERE id = ?");
    $stmt->execute([$_SESSION['company_id']]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get all users for this company
    $stmt = $conn->prepare("
        SELECT u.id, u.email, u.role, u.first_name, u.last_name, u.created_at, u.updated_at,
               CASE WHEN e.id IS NOT NULL THEN 
                   CONCAT(e.first_name, ' ', e.last_name) 
               ELSE 
                   CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, ''))
               END as full_name
        FROM users u
        LEFT JOIN employees e ON u.id = e.user_id AND e.company_id = u.company_id
        WHERE u.company_id = ?
        ORDER BY u.role DESC, u.email ASC
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $message = "Kullanıcılar yüklenirken hata: " . $e->getMessage();
    $messageType = 'error';
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Şifreleri - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen py-12">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Header -->
            <div class="text-center mb-8">
                <h1 class="text-3xl font-bold text-gray-900">Kullanıcı Şifreleri</h1>
                <p class="text-gray-600 mt-2">
                    <?php echo htmlspecialchars($company['company_name'] ?? 'Şirket'); ?> - 
                    Tüm kullanıcı şifreleri
                </p>
            </div>

            <!-- Users List -->
            <div class="bg-white shadow rounded-lg">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Şirket Kullanıcıları</h2>
                    <p class="text-sm text-gray-500">Varsayılan şifre: <span class="font-mono bg-gray-100 px-2 py-1 rounded">szb123456</span></p>
                </div>
                
                <?php if (empty($users)): ?>
                    <div class="p-6 text-center text-gray-500">
                        Henüz kullanıcı eklenmemiş
                    </div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Kullanıcı Bilgileri
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Rol
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Kayıt Tarihi
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Şifre
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($users as $user): ?>
                                    <tr id="user-<?php echo $user['id']; ?>">
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                                    <span class="text-blue-600 font-medium text-sm">
                                                        <?php echo strtoupper(substr($user['email'], 0, 2)); ?>
                                                    </span>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900">
                                                        <?php echo htmlspecialchars(trim($user['full_name']) ?: 'İsimsiz'); ?>
                                                    </div>
                                                    <div class="text-sm text-gray-500">
                                                        <?php echo htmlspecialchars($user['email']); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?php 
                                                echo $user['role'] === 'admin' ? 'bg-red-100 text-red-800' : 
                                                    ($user['role'] === 'manager' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'); 
                                            ?>">
                                                <?php 
                                                    echo $user['role'] === 'admin' ? '👑 Admin' : 
                                                        ($user['role'] === 'manager' ? '👔 Yönetici' : '👤 Personel'); 
                                                ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo date('d.m.Y H:i', strtotime($user['created_at'])); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="bg-blue-50 border border-blue-200 rounded-lg px-4 py-2">
                                                <div class="font-mono text-sm font-medium text-blue-800 select-all">
                                                    szb123456
                                                </div>
                                                <div class="text-xs text-blue-600 mt-1">
                                                    🔒 Varsayılan Şifre
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Navigation -->
            <div class="mt-8 text-center space-x-4">
                <a href="../dashboard/company-dashboard.php" class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition">
                    ← Anasayfaya Dön
                </a>
                <?php if (isset($_SESSION['super_admin_bypass'])): ?>
                    <a href="../super-admin/" class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition">
                        👑 Süper Admin Paneli
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Select all functionality for password field
        document.addEventListener('DOMContentLoaded', function() {
            const passwordFields = document.querySelectorAll('.select-all');
            passwordFields.forEach(field => {
                field.addEventListener('click', function() {
                    // Select the text content
                    const range = document.createRange();
                    range.selectNodeContents(this);
                    const selection = window.getSelection();
                    selection.removeAllRanges();
                    selection.addRange(range);
                    
                    // Optional: Copy to clipboard
                    try {
                        document.execCommand('copy');
                        // Show brief feedback
                        const originalBg = this.parentElement.style.backgroundColor;
                        this.parentElement.style.backgroundColor = '#dcfce7';
                        setTimeout(() => {
                            this.parentElement.style.backgroundColor = originalBg;
                        }, 500);
                    } catch (err) {
                        console.log('Clipboard copy failed');
                    }
                });
            });
        });
    </script>
</body>
</html>