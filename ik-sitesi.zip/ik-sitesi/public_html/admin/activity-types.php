<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if admin is logged in
if (!isset($_SESSION['company_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: ../auth/company-login.php');
    exit;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_activity'])) {
        $activity_code = $_POST['activity_code'] ?? '';
        $activity_name = $_POST['activity_name'] ?? '';
        $category = $_POST['category'] ?? '';
        $icon = $_POST['icon'] ?? '';
        
        if (!empty($activity_code) && !empty($activity_name)) {
            try {
                $db = new Database();
                $conn = $db->getConnection();
                
                $stmt = $conn->prepare("
                    INSERT INTO activity_types (company_id, activity_code, activity_name, category, icon, is_active) 
                    VALUES (?, ?, ?, ?, ?, 1)
                ");
                $stmt->execute([$_SESSION['company_id'], $activity_code, $activity_name, $category, $icon]);
                $success = "Yeni aktivite türü eklendi.";
            } catch (Exception $e) {
                $error = "Hata: " . $e->getMessage();
            }
        }
    }
    
    if (isset($_POST['toggle_activity'])) {
        $activity_id = $_POST['activity_id'] ?? '';
        if (!empty($activity_id)) {
            try {
                $db = new Database();
                $conn = $db->getConnection();
                
                $stmt = $conn->prepare("
                    UPDATE activity_types 
                    SET is_active = NOT is_active 
                    WHERE id = ? AND company_id = ?
                ");
                $stmt->execute([$activity_id, $_SESSION['company_id']]);
                $success = "Aktivite durumu güncellendi.";
            } catch (Exception $e) {
                $error = "Hata: " . $e->getMessage();
            }
        }
    }
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get all activity types for this company
    $stmt = $conn->prepare("
        SELECT * FROM activity_types 
        WHERE company_id = ? 
        ORDER BY category, activity_name
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $activityTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Veri yüklenirken hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktivite Türleri - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                        <span class="text-white font-bold">A</span>
                    </div>
                    <div>
                        <h1 class="text-xl font-semibold text-gray-900">Aktivite Türleri Yönetimi</h1>
                        <p class="text-sm text-gray-600"><?php echo htmlspecialchars($_SESSION['company_name']); ?></p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="../dashboard/admin-dashboard.php" class="text-blue-600 hover:text-blue-500">
                        ← Admin Paneli
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- Add New Activity Type -->
        <div class="bg-white shadow rounded-lg mb-6">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Yeni Aktivite Türü Ekle</h2>
            </div>
            <div class="p-6">
                <form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    <div>
                        <label for="activity_code" class="block text-sm font-medium text-gray-700">Kod</label>
                        <input 
                            type="text" 
                            id="activity_code" 
                            name="activity_code" 
                            required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            placeholder="custom_break_start"
                        >
                    </div>
                    <div>
                        <label for="activity_name" class="block text-sm font-medium text-gray-700">Aktivite Adı</label>
                        <input 
                            type="text" 
                            id="activity_name" 
                            name="activity_name" 
                            required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            placeholder="Özel Mola Başlangıcı"
                        >
                    </div>
                    <div>
                        <label for="category" class="block text-sm font-medium text-gray-700">Kategori</label>
                        <select 
                            id="category" 
                            name="category" 
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        >
                            <option value="work">İş</option>
                            <option value="break">Mola</option>
                            <option value="meal">Yemek</option>
                            <option value="other">Diğer</option>
                        </select>
                    </div>
                    <div>
                        <label for="icon" class="block text-sm font-medium text-gray-700">İkon</label>
                        <input 
                            type="text" 
                            id="icon" 
                            name="icon" 
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            placeholder="🔧"
                        >
                    </div>
                    <div class="flex items-end">
                        <button 
                            name="add_activity"
                            type="submit"
                            class="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
                        >
                            ➕ Ekle
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Activity Types List -->
        <div class="bg-white shadow rounded-lg">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Mevcut Aktivite Türleri</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kod</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aktivite</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kategori</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İkon</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durum</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($activityTypes)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                                    Henüz özel aktivite türü eklenmemiş. Varsayılan türler QR scanner'da mevcut.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($activityTypes as $activity): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($activity['activity_code']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo htmlspecialchars($activity['activity_name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo htmlspecialchars($activity['category']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo htmlspecialchars($activity['icon']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $activity['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo $activity['is_active'] ? 'Aktif' : 'Pasif'; ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <form method="POST" class="inline">
                                            <input type="hidden" name="activity_id" value="<?php echo $activity['id']; ?>">
                                            <button 
                                                name="toggle_activity"
                                                type="submit"
                                                class="<?php echo $activity['is_active'] ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'; ?>"
                                            >
                                                <?php echo $activity['is_active'] ? 'Pasif Yap' : 'Aktif Yap'; ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Default Activities Info -->
        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
            <h3 class="text-sm font-medium text-blue-800 mb-2">Varsayılan Aktivite Türleri:</h3>
            <div class="text-xs text-blue-700 grid grid-cols-2 md:grid-cols-4 gap-2">
                <div>🚪 İş Giriş</div>
                <div>🏠 İşten Çıkış</div>
                <div>🍽️ Yemek Başlangıcı</div>
                <div>✅ Yemek Bitişi</div>
                <div>🚬 Sigara Molası Giriş</div>
                <div>🚬 Sigara Molası Çıkış</div>
                <div>☕ Çay Molası Giriş</div>
                <div>☕ Çay Molası Çıkış</div>
            </div>
        </div>
    </main>
</body>
</html>