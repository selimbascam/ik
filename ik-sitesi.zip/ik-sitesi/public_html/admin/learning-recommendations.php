<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$db = new Database();
$conn = $db->getConnection();

$error = '';
$success = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'generate_recommendations') {
        $employee_id = intval($_POST['employee_id'] ?? 0);
        
        if ($employee_id > 0) {
            // Generate recommendations for specific employee
            $recommendations = generateEmployeeRecommendations($conn, $employee_id, $_SESSION['company_id']);
            
            // Save recommendations to database
            foreach ($recommendations as $rec) {
                $stmt = $conn->prepare("
                    INSERT INTO learning_recommendations 
                    (company_id, employee_id, recommendation_type, title, description, priority_score, ai_confidence, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE
                    description = VALUES(description),
                    priority_score = VALUES(priority_score),
                    ai_confidence = VALUES(ai_confidence),
                    updated_at = NOW()
                ");
                
                $stmt->execute([
                    $_SESSION['company_id'],
                    $employee_id,
                    $rec['type'],
                    $rec['title'],
                    $rec['description'],
                    $rec['priority'],
                    $rec['confidence']
                ]);
            }
            
            $success = "Personel için " . count($recommendations) . " adet öğrenme önerisi oluşturuldu.";
        }
    }
    
    if ($action === 'bulk_generate') {
        // Generate recommendations for all employees
        $stmt = $conn->prepare("SELECT id FROM employees WHERE company_id = ? AND is_active = TRUE");
        $stmt->execute([$_SESSION['company_id']]);
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $total_recommendations = 0;
        foreach ($employees as $emp) {
            $recommendations = generateEmployeeRecommendations($conn, $emp['id'], $_SESSION['company_id']);
            
            foreach ($recommendations as $rec) {
                $stmt = $conn->prepare("
                    INSERT INTO learning_recommendations 
                    (company_id, employee_id, recommendation_type, title, description, priority_score, ai_confidence, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE
                    description = VALUES(description),
                    priority_score = VALUES(priority_score),
                    ai_confidence = VALUES(ai_confidence),
                    updated_at = NOW()
                ");
                
                $stmt->execute([
                    $_SESSION['company_id'],
                    $emp['id'],
                    $rec['type'],
                    $rec['title'],
                    $rec['description'],
                    $rec['priority'],
                    $rec['confidence']
                ]);
                $total_recommendations++;
            }
        }
        
        $success = "Tüm personel için toplam {$total_recommendations} öğrenme önerisi oluşturuldu.";
    }
}

// Function to generate recommendations using AI analysis
function generateEmployeeRecommendations($conn, $employee_id, $company_id) {
    $recommendations = [];
    
    // Get employee data
    $stmt = $conn->prepare("
        SELECT e.*, d.name as department_name 
        FROM employees e 
        LEFT JOIN departments d ON e.department_id = d.id 
        WHERE e.id = ? AND e.company_id = ?
    ");
    $stmt->execute([$employee_id, $company_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) return $recommendations;
    
    // Analyze attendance patterns
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_days,
            AVG(TIMESTAMPDIFF(HOUR, check_in_time, check_out_time)) as avg_hours,
            COUNT(CASE WHEN check_in_time > '09:30:00' THEN 1 END) as late_arrivals,
            COUNT(CASE WHEN TIMESTAMPDIFF(HOUR, check_in_time, check_out_time) > 9 THEN 1 END) as overtime_days
        FROM attendance_records 
        WHERE employee_id = ? AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute([$employee_id]);
    $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Analyze training history
    $stmt = $conn->prepare("
        SELECT COUNT(*) as completed_trainings,
        AVG(DATEDIFF(completion_date, start_date)) as avg_completion_days
        FROM employee_trainings 
        WHERE employee_id = ? AND status = 'completed'
        AND completion_date >= DATE_SUB(NOW(), INTERVAL 90 DAY)
    ");
    $stmt->execute([$employee_id]);
    $training = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Generate time management recommendations
    if ($attendance && $attendance['late_arrivals'] > 3) {
        $recommendations[] = [
            'type' => 'time_management',
            'title' => 'Zaman Yönetimi Eğitimi',
            'description' => 'Son 30 günde ' . $attendance['late_arrivals'] . ' kez geç kalındı. Zaman yönetimi becerilerini geliştirmek için özel eğitim önerilir.',
            'priority' => calculatePriority($attendance['late_arrivals'], 10, 'higher_worse'),
            'confidence' => 0.85
        ];
    }
    
    // Generate productivity recommendations
    if ($attendance && $attendance['overtime_days'] > 10) {
        $recommendations[] = [
            'type' => 'productivity',
            'title' => 'Verimlilik ve İş Organizasyonu',
            'description' => 'Fazla mesai günleri yüksek (' . $attendance['overtime_days'] . ' gün). Verimlilik artırıcı teknikler eğitimi önerilir.',
            'priority' => calculatePriority($attendance['overtime_days'], 15, 'higher_worse'),
            'confidence' => 0.78
        ];
    }
    
    // Generate career development recommendations
    if ($training && $training['completed_trainings'] < 2) {
        $recommendations[] = [
            'type' => 'career_development',
            'title' => 'Mesleki Gelişim Programı',
            'description' => 'Son 3 ayda tamamlanan eğitim sayısı düşük. Kariyer gelişimi için ek eğitimler önerilir.',
            'priority' => calculatePriority($training['completed_trainings'], 5, 'lower_worse'),
            'confidence' => 0.72
        ];
    }
    
    // Generate department-specific recommendations
    $dept_recommendations = getDepartmentSpecificRecommendations($employee['department_name'], $employee);
    $recommendations = array_merge($recommendations, $dept_recommendations);
    
    // Generate soft skills recommendations
    $soft_skills = generateSoftSkillsRecommendations($conn, $employee_id);
    $recommendations = array_merge($recommendations, $soft_skills);
    
    return $recommendations;
}

function calculatePriority($value, $threshold, $type) {
    if ($type === 'higher_worse') {
        return min(100, ($value / $threshold) * 100);
    } else {
        return min(100, (($threshold - $value) / $threshold) * 100);
    }
}

function getDepartmentSpecificRecommendations($department, $employee) {
    $recommendations = [];
    
    switch (strtolower($department)) {
        case 'it':
        case 'bilgi işlem':
            $recommendations[] = [
                'type' => 'technical_skills',
                'title' => 'Siber Güvenlik Farkındalığı',
                'description' => 'IT departmanı için güncel siber güvenlik tehditleri ve koruma yöntemleri eğitimi.',
                'priority' => 75,
                'confidence' => 0.90
            ];
            break;
            
        case 'sales':
        case 'satış':
            $recommendations[] = [
                'type' => 'sales_skills',
                'title' => 'Dijital Satış Teknikleri',
                'description' => 'Online satış kanalları ve dijital müşteri ilişkileri yönetimi eğitimi.',
                'priority' => 80,
                'confidence' => 0.88
            ];
            break;
            
        case 'hr':
        case 'insan kaynakları':
            $recommendations[] = [
                'type' => 'hr_skills',
                'title' => 'Çalışan Motivasyonu ve Katılım',
                'description' => 'Modern çalışan deneyimi ve motivasyon artırıcı yaklaşımlar eğitimi.',
                'priority' => 70,
                'confidence' => 0.82
            ];
            break;
    }
    
    return $recommendations;
}

function generateSoftSkillsRecommendations($conn, $employee_id) {
    $recommendations = [];
    
    // Analyze communication patterns (example based on meeting participation)
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total_meetings 
        FROM meeting_participations 
        WHERE employee_id = ? AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute([$employee_id]);
    $meetings = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($meetings && $meetings['total_meetings'] < 5) {
        $recommendations[] = [
            'type' => 'communication',
            'title' => 'İletişim Becerileri Geliştirme',
            'description' => 'Toplantı katılımı düşük. Etkili iletişim ve sunum becerileri eğitimi önerilir.',
            'priority' => 65,
            'confidence' => 0.70
        ];
    }
    
    // Leadership potential assessment
    $stmt = $conn->prepare("
        SELECT position, DATEDIFF(NOW(), hire_date) as tenure_days 
        FROM employees 
        WHERE id = ?
    ");
    $stmt->execute([$employee_id]);
    $emp_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($emp_info && $emp_info['tenure_days'] > 365 && strpos(strtolower($emp_info['position']), 'senior') !== 0) {
        $recommendations[] = [
            'type' => 'leadership',
            'title' => 'Liderlik Gelişim Programı',
            'description' => 'Kıdem ve pozisyon bazında liderlik potansiyeli mevcut. Liderlik becerileri eğitimi önerilir.',
            'priority' => 85,
            'confidence' => 0.75
        ];
    }
    
    return $recommendations;
}

// Get employees for dropdown
$stmt = $conn->prepare("
    SELECT e.id, e.first_name, e.last_name, e.employee_code, d.name as department_name
    FROM employees e 
    LEFT JOIN departments d ON e.department_id = d.id 
    WHERE e.company_id = ? AND COALESCE(e.status, 'active') = 'active'
    ORDER BY e.first_name, e.last_name
");
$stmt->execute([$_SESSION['company_id']]);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent recommendations
$stmt = $conn->prepare("
    SELECT lr.*, e.first_name, e.last_name, e.employee_code
    FROM learning_recommendations lr
    JOIN employees e ON lr.employee_id = e.id
    WHERE lr.company_id = ?
    ORDER BY lr.priority_score DESC, lr.created_at DESC
    LIMIT 20
");
$stmt->execute([$_SESSION['company_id']]);
$recent_recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_recommendations,
        AVG(priority_score) as avg_priority,
        COUNT(DISTINCT employee_id) as employees_with_recommendations,
        AVG(ai_confidence) as avg_confidence
    FROM learning_recommendations 
    WHERE company_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
");
$stmt->execute([$_SESSION['company_id']]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaptif Öğrenme Önerileri - SZB İK Takip</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            min-height: 100vh; 
            padding: 20px; 
        }
        .container { 
            max-width: 1400px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 15px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.15); 
            overflow: hidden; 
        }
        .header { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            padding: 30px; 
            text-align: center; 
        }
        .header h1 { font-size: 32px; margin-bottom: 10px; }
        .header p { opacity: 0.9; font-size: 16px; }
        .content { padding: 30px; }
        .stats-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 20px; 
            margin-bottom: 30px; 
        }
        .stat-card { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            padding: 25px; 
            border-radius: 12px; 
            text-align: center; 
        }
        .stat-number { font-size: 36px; font-weight: bold; margin-bottom: 8px; }
        .stat-label { font-size: 14px; opacity: 0.9; }
        .form-container { 
            background: #f8f9fa; 
            border-radius: 12px; 
            padding: 25px; 
            margin-bottom: 30px; 
            border-left: 4px solid #667eea; 
        }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { 
            display: block; 
            font-weight: 600; 
            color: #495057; 
            margin-bottom: 8px; 
            font-size: 14px; 
        }
        .form-control { 
            width: 100%; 
            padding: 12px 15px; 
            border: 2px solid #dee2e6; 
            border-radius: 8px; 
            font-size: 14px; 
            transition: border-color 0.2s; 
        }
        .form-control:focus { 
            outline: none; 
            border-color: #667eea; 
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); 
        }
        .btn { 
            background: #667eea; 
            color: white; 
            padding: 12px 24px; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-weight: 600; 
            font-size: 14px; 
            transition: all 0.2s; 
            text-decoration: none; 
            display: inline-block; 
            margin: 5px; 
        }
        .btn:hover { background: #5a67d8; transform: translateY(-1px); }
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        .btn-warning { background: #ffc107; color: #000; }
        .btn-warning:hover { background: #e0a800; }
        .alert { 
            padding: 15px 20px; 
            border-radius: 8px; 
            margin-bottom: 20px; 
            font-weight: 500; 
        }
        .alert-success { 
            background: #d4edda; 
            color: #155724; 
            border-left: 4px solid #28a745; 
        }
        .alert-danger { 
            background: #f8d7da; 
            color: #721c24; 
            border-left: 4px solid #dc3545; 
        }
        .recommendations-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr)); 
            gap: 20px; 
            margin-top: 30px; 
        }
        .recommendation-card { 
            background: white; 
            border: 2px solid #e9ecef; 
            border-radius: 12px; 
            padding: 20px; 
            transition: all 0.2s; 
            position: relative; 
        }
        .recommendation-card:hover { 
            border-color: #667eea; 
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.1); 
        }
        .rec-header { 
            display: flex; 
            justify-content: space-between; 
            align-items: start; 
            margin-bottom: 15px; 
        }
        .rec-title { font-size: 18px; font-weight: 700; color: #495057; margin-bottom: 5px; }
        .rec-type { 
            font-size: 12px; 
            color: #667eea; 
            font-weight: 600; 
            text-transform: uppercase; 
        }
        .rec-employee { font-size: 13px; color: #6c757d; margin-bottom: 10px; }
        .rec-description { 
            color: #495057; 
            line-height: 1.5; 
            margin-bottom: 15px; 
            font-size: 14px; 
        }
        .rec-metrics { 
            display: flex; 
            justify-content: space-between; 
            background: #f8f9fa; 
            padding: 10px; 
            border-radius: 6px; 
            font-size: 12px; 
        }
        .priority-high { border-left-color: #dc3545; }
        .priority-medium { border-left-color: #ffc107; }
        .priority-low { border-left-color: #28a745; }
        .back-link { 
            display: inline-block; 
            margin-bottom: 20px; 
            color: #667eea; 
            text-decoration: none; 
            font-weight: 600; 
        }
        .back-link:hover { color: #5a67d8; }
        .ai-badge { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            padding: 4px 8px; 
            border-radius: 12px; 
            font-size: 10px; 
            font-weight: 600; 
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧠 Adaptif Öğrenme Önerileri</h1>
            <p>AI destekli personel gelişim ve eğitim önerileri sistemi</p>
        </div>
        
        <div class="content">
            <a href="../dashboard/company-dashboard.php" class="back-link">← Ana Dashboard'a Dön</a>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            
            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($stats['total_recommendations'] ?? 0) ?></div>
                    <div class="stat-label">Toplam Öneri</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($stats['avg_priority'] ?? 0, 1) ?>%</div>
                    <div class="stat-label">Ortalama Öncelik</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($stats['employees_with_recommendations'] ?? 0) ?></div>
                    <div class="stat-label">Personel Sayısı</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format(($stats['avg_confidence'] ?? 0) * 100, 1) ?>%</div>
                    <div class="stat-label">AI Güven Oranı</div>
                </div>
            </div>
            
            <!-- Generate Recommendations Form -->
            <div class="form-container">
                <h3 style="margin-bottom: 20px; color: #495057;">Yeni Öneriler Oluştur</h3>
                
                <form method="POST" action="">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="employee_id">Personel Seçin</label>
                            <select id="employee_id" name="employee_id" class="form-control">
                                <option value="">Personel seçin...</option>
                                <?php foreach ($employees as $emp): ?>
                                    <option value="<?= $emp['id'] ?>">
                                        <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> 
                                        (<?= htmlspecialchars($emp['employee_code']) ?>) - 
                                        <?= htmlspecialchars($emp['department_name'] ?? 'Departman yok') ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group" style="display: flex; align-items: end; gap: 10px;">
                            <button type="submit" name="action" value="generate_recommendations" class="btn btn-success">
                                🎯 Seçilen Personel için Öneri Oluştur
                            </button>
                        </div>
                    </div>
                    
                    <div style="text-align: center; margin-top: 20px;">
                        <button type="submit" name="action" value="bulk_generate" class="btn btn-warning" 
                                onclick="return confirm('Tüm aktif personel için öneri oluşturulacak. Bu işlem biraz zaman alabilir. Devam etmek istiyor musunuz?')">
                            🚀 Tüm Personel için Toplu Öneri Oluştur
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Recent Recommendations -->
            <div style="background: white; border-radius: 12px; border: 2px solid #e9ecef;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px 10px 0 0;">
                    <h3 style="margin: 0; font-size: 24px;">
                        Son Öneriler (<?= count($recent_recommendations) ?>)
                    </h3>
                </div>
                
                <div style="padding: 30px;">
                    <?php if (empty($recent_recommendations)): ?>
                        <div style="text-align: center; padding: 60px 20px; color: #6c757d;">
                            <div style="font-size: 64px; margin-bottom: 20px;">🎯</div>
                            <h3>Henüz öneri oluşturulmamış</h3>
                            <p>Yukarıdaki formu kullanarak personel için öğrenme önerileri oluşturun</p>
                        </div>
                    <?php else: ?>
                        <div class="recommendations-grid">
                            <?php foreach ($recent_recommendations as $rec): ?>
                                <?php 
                                $priority_class = 'priority-low';
                                if ($rec['priority_score'] > 70) $priority_class = 'priority-high';
                                elseif ($rec['priority_score'] > 40) $priority_class = 'priority-medium';
                                ?>
                                <div class="recommendation-card <?= $priority_class ?>">
                                    <div class="rec-header">
                                        <div>
                                            <div class="rec-title"><?= htmlspecialchars($rec['title']) ?></div>
                                            <div class="rec-type"><?= htmlspecialchars($rec['recommendation_type']) ?></div>
                                        </div>
                                        <div class="ai-badge">AI ÖNERİ</div>
                                    </div>
                                    
                                    <div class="rec-employee">
                                        👤 <?= htmlspecialchars($rec['first_name'] . ' ' . $rec['last_name']) ?> 
                                        (<?= htmlspecialchars($rec['employee_code']) ?>)
                                    </div>
                                    
                                    <div class="rec-description">
                                        <?= htmlspecialchars($rec['description']) ?>
                                    </div>
                                    
                                    <div class="rec-metrics">
                                        <span>📊 Öncelik: <strong><?= number_format($rec['priority_score'], 1) ?>%</strong></span>
                                        <span>🤖 Güven: <strong><?= number_format($rec['ai_confidence'] * 100, 1) ?>%</strong></span>
                                        <span>📅 <?= date('d.m.Y', strtotime($rec['created_at'])) ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>