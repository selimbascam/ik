<?php
// QR Generator - Google Maps Enhanced Version
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/google-maps-config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) CONCAT($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'add_location') {
            // Generate unique QR code
            $qrCode = 'QR_' . strtoupper(substr($_SESSION['company_code'] ?? 'LOC', 0, 3)) . '_' . 
                     str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT) . '_' . time();
            
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([
                $_SESSION['company_id'],
                $_POST['name'],
                $qrCode,
                $_POST['location_type'],
                $_POST['description'],
                $_POST['latitude'] ?: null,
                $_POST['longitude'] ?: null,
                $_POST['address'] ?: null
            ]);
            $success = "QR lokasyon başarıyla eklendi. Kod: " . $qrCode;
        }
        
        if ($action === 'delete_location') {
            $stmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
            $stmt->execute([$_POST['location_id'], $_SESSION['company_id']]);
            $success = "QR lokasyon silindi.";
        }
        
        if ($action === 'update_location') {
            $stmt = $conn->prepare("
                UPDATE qr_locations SET 
                    name = ?, location_type = ?, description = ?, 
                    latitude = ?, longitude = ?, address = ?, is_active = ?
                WHERE id = ? AND company_id = ?
            ");
            $stmt->execute([
                $_POST['name'],
                $_POST['location_type'],
                $_POST['description'],
                $_POST['latitude'] ?: null,
                $_POST['longitude'] ?: null,
                $_POST['address'] ?: null,
                $_POST['is_active'],
                $_POST['location_id'],
                $_SESSION['company_id']
            ]);
            $success = "QR lokasyon güncellendi.";
        }
    }
    
    // Get QR locations
    $stmt = $conn->prepare("
        SELECT * FROM qr_locations 
        WHERE company_id = ?
        ORDER BY name
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Kod Üretici - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php echo getGoogleMapsScript(); ?>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <!-- Google Maps API - Will be loaded conditionally -->
    <script>
        // Google Maps will be loaded via PHP include with the correct API key
        const hasValidApiKey = <?php echo isGoogleMapsEnabled() ? 'true' : 'false'; ?>;
    </script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">📱</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">QR Kod Üretici</h1>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'Şirket'); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <?php if (isset($success)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Add Location Form -->
            <div class="bg-white rounded-lg shadow mb-8">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">🗺️ Yeni QR Lokasyon Ekle</h2>
                    <p class="text-sm text-gray-600">Google Maps üzerinden adres seçebilir veya manuel koordinat girebilirsiniz</p>
                </div>
                <div class="p-6">
                    <form method="POST" id="locationForm" class="space-y-6">
                        <input type="hidden" name="action" value="add_location">
                        
                        <!-- Basic Info -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Lokasyon Adı *</label>
                                <input type="text" name="name" id="locationName" required placeholder="Ör: Ana Giriş Kapısı"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Lokasyon Türü *</label>
                                <select name="location_type" required 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                                    <option value="">Seçin</option>
                                    <option value="entrance">🚪 Giriş Kapısı</option>
                                    <option value="exit">🚪 Çıkış Kapısı</option>
                                    <option value="office">🏢 Ofis/Çalışma Alanı</option>
                                    <option value="cafeteria">🍽️ Kafeterya/Yemekhane</option>
                                    <option value="meeting_room">👥 Toplantı Odası</option>
                                    <option value="break_area">☕ Mola Alanı</option>
                                    <option value="warehouse">📦 Depo/Ambar</option>
                                    <option value="parking">🚗 Otopark</option>
                                    <option value="other">📍 Diğer</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- Address Search -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">🔍 Adres Arama (Google Maps)</label>
                            <input type="text" id="addressSearch" placeholder="Adres yazın veya haritadan seçin..."
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                            <p class="text-xs text-gray-500 mt-1">Adres yazmaya başladığınızda otomatik tamamlama görünecektir</p>
                        </div>
                        
                        <!-- Map Container -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">📍 Harita Konumu</label>
                            <div id="map" class="w-full h-64 border border-gray-300 rounded-md bg-gray-100 flex items-center justify-center">
                                <div id="mapPlaceholder" class="text-gray-500 text-center">
                                    <div class="text-2xl mb-2">🗺️</div>
                                    <div>Google Maps API Key Gerekli</div>
                                    <div class="text-xs mt-1">Manuel koordinat girişi kullanabilirsiniz</div>
                                    <a href="../google-maps-setup.php" class="text-blue-600 underline text-sm mt-2 inline-block">API Key Nasıl Alınır?</a>
                                </div>
                            </div>
                            <p class="text-xs text-gray-500 mt-1">Haritaya tıklayarak konum seçebilirsiniz</p>
                        </div>
                        
                        <!-- Coordinates (Auto-filled from map) -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">📍 Enlem (Latitude)</label>
                                <input type="number" name="latitude" id="latitude" step="any" placeholder="41.0082"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">📍 Boylam (Longitude)</label>
                                <input type="number" name="longitude" id="longitude" step="any" placeholder="28.9784"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500">
                            </div>
                        </div>
                        
                        <!-- Full Address (Hidden field) -->
                        <input type="hidden" name="address" id="fullAddress">
                        
                        <!-- Description -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">📝 Açıklama</label>
                            <textarea name="description" rows="3" placeholder="Lokasyon hakkında detay bilgi, çalışma saatleri, özel talimatlar..."
                                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"></textarea>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="flex flex-col sm:flex-row gap-4">
                            <button type="button" onclick="getCurrentLocation()" 
                                    class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                📱 Mevcut Konumu Al
                            </button>
                            <button type="submit" 
                                    class="bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500">
                                ✅ QR Lokasyon Oluştur
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- QR Locations -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">
                        QR Lokasyonları (<?php echo count($locations); ?>)
                    </h2>
                </div>
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php foreach ($locations as $location): ?>
                            <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                                <div class="flex items-start justify-between mb-4">
                                    <div class="flex-1">
                                        <h3 class="text-lg font-medium text-gray-900"><?php echo htmlspecialchars($location['name']); ?></h3>
                                        <p class="text-sm text-blue-600 font-medium"><?php 
                                            $types = [
                                                'entrance' => '🚪 Giriş Kapısı',
                                                'exit' => '🚪 Çıkış Kapısı', 
                                                'office' => '🏢 Ofis/Çalışma Alanı',
                                                'cafeteria' => '🍽️ Kafeterya/Yemekhane',
                                                'meeting_room' => '👥 Toplantı Odası',
                                                'break_area' => '☕ Mola Alanı',
                                                'warehouse' => '📦 Depo/Ambar',
                                                'parking' => '🚗 Otopark',
                                                'other' => '📍 Diğer'
                                            ];
                                            echo $types[$location['location_type']] ?? htmlspecialchars($location['location_type']);
                                        ?></p>
                                        <p class="text-xs text-gray-500 mt-1">QR Kod: <?php echo htmlspecialchars($location['qr_code'] ?? $location['location_code'] ?? 'N/A'); ?></p>
                                        <?php if ($location['latitude'] && $location['longitude']): ?>
                                            <p class="text-xs text-gray-500">📍 <?php echo round($location['latitude'], 6); ?>, <?php echo round($location['longitude'], 6); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex flex-col items-end space-y-2">
                                        <span class="px-2 py-1 text-xs rounded-full <?php echo $location['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo $location['is_active'] ? '✅ Aktif' : '❌ Pasif'; ?>
                                        </span>
                                        <button onclick="deleteLocation(<?php echo $location['id']; ?>, '<?php echo addslashes($location['name']); ?>')" 
                                                class="text-red-600 hover:text-red-800 text-xs">
                                            🗑️ Sil
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- QR Code Canvas -->
                                <div class="bg-white border-2 border-gray-200 rounded-lg p-4 mb-4 text-center">
                                    <canvas id="qr-<?php echo $location['id']; ?>" class="mx-auto"></canvas>
                                    <div class="text-xs text-gray-500 mt-2">QR kod otomatik oluşturuldu</div>
                                </div>
                                
                                <!-- Action Buttons -->
                                <div class="grid grid-cols-2 gap-2">
                                    <button onclick="downloadQR('qr-<?php echo $location['id']; ?>', '<?php echo htmlspecialchars($location['name']); ?>')" 
                                            class="bg-blue-600 text-white px-3 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors">
                                        💾 İndir
                                    </button>
                                    <button onclick="printQR('qr-<?php echo $location['id']; ?>', '<?php echo htmlspecialchars($location['name']); ?>', '<?php echo htmlspecialchars($location['qr_code'] ?? $location['location_code'] ?? ''); ?>')" 
                                            class="bg-green-600 text-white px-3 py-2 rounded-md text-sm hover:bg-green-700 transition-colors">
                                        🖨️ Yazdır
                                    </button>
                                </div>
                                
                                <!-- Google Maps Link -->
                                <?php if ($location['latitude'] && $location['longitude']): ?>
                                    <div class="mt-3">
                                        <a href="https://www.google.com/maps?q=<?php echo $location['latitude']; ?>,<?php echo $location['longitude']; ?>" 
                                           target="_blank" 
                                           class="text-xs text-blue-600 hover:text-blue-800 underline">
                                            🗺️ Google Maps'te Görüntüle
                                        </a>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($location['description']): ?>
                                    <div class="mt-3 p-2 bg-gray-50 rounded text-xs text-gray-600">
                                        <strong>Not:</strong> <?php echo htmlspecialchars($location['description']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    let map;
    let marker;
    let autocomplete;
    let geocoder;
    
    // Initialize Google Maps
    function initMap() {
        // Default location (Istanbul)
        const defaultLocation = { lat: 41.0082, lng: 28.9784 };
        
        map = new google.maps.Map(document.getElementById('map'), {
            center: defaultLocation,
            zoom: 13,
            mapTypeControl: 1,
            streetViewControl: 1,
            fullscreenControl: true
        });
        
        // Initialize geocoder
        geocoder = new google.maps.Geocoder();
        
        // Add click listener to map
        map.addListener('click', function(event) {
            placeMarker(event.latLng);
            updateCoordinates(event.latLng.lat(), event.latLng.lng());
            reverseGeocode(event.latLng);
        });
        
        // Initialize autocomplete for address search
        const addressInput = document.getElementById('addressSearch');
        if (addressInput) {
            autocomplete = new google.maps.places.Autocomplete(addressInput, {
                componentRestrictions: { country: 'tr' }, // Restrict to Turkey
                fields: ['place_id', 'geometry', 'name', 'formatted_address']
            });
            
            autocomplete.addListener('place_changed', function() {
                const place = autocomplete.getPlace();
                if (place.geometry) {
                    const location = place.geometry.location;
                    map.setCenter(location);
                    map.setZoom(17);
                    placeMarker(location);
                    updateCoordinates(location.lat(), location.lng());
                    document.getElementById('fullAddress').value = place.formatted_address;
                }
            });
        }
    }
    
    // Place marker on map
    function placeMarker(location) {
        if (marker) {
            marker.setMap(null);
        }
        
        marker = new google.maps.Marker({
            position: location,
            map: map,
            title: 'Seçilen Konum',
            icon: {
                url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="red">
                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                    </svg>
                `),
                scaledSize: new google.maps.Size(40, 40),
                anchor: new google.maps.Point(20, 40)
            }
        });
    }
    
    // Update coordinate inputs
    function updateCoordinates(lat, lng) {
        document.getElementById('latitude').value = lat.toFixed(8);
        document.getElementById('longitude').value = lng.toFixed(8);
    }
    
    // Reverse geocode to get address
    function reverseGeocode(latLng) {
        geocoder.geocode({ location: latLng }, function(results, status) {
            if (status === 'OK' && results[0]) {
                document.getElementById('addressSearch').value = results[0].formatted_address;
                document.getElementById('fullAddress').value = results[0].formatted_address;
            }
        });
    }
    
    // Get current location (works without Google Maps)
    function getCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                
                // Update coordinate inputs
                document.getElementById('latitude').value = lat.toFixed(8);
                document.getElementById('longitude').value = lng.toFixed(8);
                
                // If Google Maps is available, update map
                if (typeof map !== 'undefined' && map) {
                    const location = new google.maps.LatLng(lat, lng);
                    map.setCenter(location);
                    map.setZoom(17);
                    placeMarker(location);
                    reverseGeocode(location);
                } else {
                    // Without Google Maps, show coordinates only
                    document.getElementById('addressSearch').value = `Koordinat: ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
                    document.getElementById('fullAddress').value = `GPS Koordinat: ${lat}, ${lng}`;
                }
                
                alert('✅ Mevcut konumunuz başarıyla alındı!\nEnlem: ' + lat.toFixed(6) + '\nBoylam: ' + lng.toFixed(6));
            }, function(error) {
                let errorMsg = 'Konum alınamadı: ';
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMsg += 'Konum izni reddedildi. Tarayıcı ayarlarından izin verin.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMsg += 'Konum bilgisi kullanılamıyor.';
                        break;
                    case error.TIMEOUT:
                        errorMsg += 'Konum alma zaman aşımına uğradı.';
                        break;
                    default:
                        errorMsg += 'Bilinmeyen hata.';
                        break;
                }
                alert('❌ ' + errorMsg);
            }, {
                enableHighAccuracy: 1,
                timeout: 10000,
                maximumAge: 60000
            });
        } else {
            alert('❌ Tarayıcınız konum servisleri desteklemiyor.');
        }
    }
    
    // Delete location with confirmation
    function deleteLocation(locationId, locationName) {
        if (confirm(`"${locationName}" lokasyonunu silmek istediğinizden emin misiniz?\n\nBu işlem geri alınamaz!`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'delete_location';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.name = 'location_id';
            idInput.value = locationId;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Generate QR codes for all locations
    document.addEventListener('DOMContentLoaded', function() {
        <?php foreach ($locations as $location): ?>
            const qrData<?php echo $location['id']; ?> = JSON.stringify({
                location_id: <?php echo $location['id']; ?>,
                qr_code: '<?php echo addslashes($location['qr_code'] ?? $location['location_code'] ?? ''); ?>',
                location_name: '<?php echo addslashes($location['name']); ?>',
                company_id: <?php echo $_SESSION['company_id']; ?>,
                latitude: <?php echo $location['latitude'] ?: 'null'; ?>,
                longitude: <?php echo $location['longitude'] ?: 'null'; ?>
            });
            
            QRCode.toCanvas(
                document.getElementById('qr-<?php echo $location['id']; ?>'), 
                qrData<?php echo $location['id']; ?>, 
                {
                    width: 150,
                    margin: 2,
                    color: {
                        dark: '#7C3AED', // Purple color
                        light: '#FFFFFF'
                    },
                    errorCorrectionLevel: 'M'
                }
            ).catch(function(error) {
                console.error('QR kod oluşturma hatası:', error);
                document.getElementById('qr-<?php echo $location['id']; ?>').innerHTML = '<div class="text-red-500 text-xs">QR kod oluşturulamadı</div>';
            });
        <?php endforeach; ?>
    });

    function downloadQR(canvasId, locationName) {
        const canvas = document.getElementById(canvasId);
        if (canvas) {
            try {
                const link = document.createElement('a');
                link.download = 'QR_' + locationName.replace(/[^a-zA-Z0-9ığüşöçİĞÜŞÖÇ]/g, '_') + '_' + new Date().getTime() + '.png';
                link.href = canvas.toDataURL('image/png', 1.0);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                // Show success message  
                setTimeout(() => {
                    alert('✅ QR kod başarıyla indirildi!');
                }, 100);
            } catch (error) {
                console.error('İndirme hatası:', error);
                alert('❌ QR kod indirilemedi: ' + error.message);
            }
        } else {
            alert('❌ QR kod indirilemedi. Canvas elemanı bulunamadı.');
        }
    }

    function printQR(canvasId, locationName, qrCode) {
        const canvas = document.getElementById(canvasId);
        if (canvas) {
            try {
                const dataURL = canvas.toDataURL('image/png', 1.0);
                
                const printWindow = window.open('', '_blank', 'width=800,height=600');
                if (!printWindow) {
                    alert('❌ Pop-up engelleyici aktif. Lütfen pop-up engelleyiciyi devre dışı bırakın.');
                    return;
                }
                
                printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                    <head>
                        <title>QR Kod - ${locationName}</title>
                        <style>
                            body { 
                                font-family: Arial, sans-serif; 
                                text-align: center; 
                                padding: 20px;
                                margin: 0;
                            }
                            .qr-container { 
                                border: 3px solid #7C3AED; 
                                padding: 30px; 
                                display: inline-block; 
                                margin: 20px;
                                border-radius: 10px;
                                background: white;
                            }
                            h1 { 
                                font-size: 28px; 
                                margin-bottom: 15px; 
                                color: #7C3AED;
                                font-weight: bold;
                            }
                            .code { 
                                font-size: 14px; 
                                color: #666; 
                                margin-top: 10px; 
                                font-family: monospace;
                            }
                            .company { 
                                font-size: 16px; 
                                color: #333; 
                                margin-top: 15px; 
                                font-weight: bold;
                            }
                            img { 
                                max-width: 200px; 
                                border: 1px solid #ddd;
                                border-radius: 5px;
                            }
                            .instructions {
                                font-size: 12px;
                                color: #888;
                                margin-top: 20px;
                                max-width: 300px;
                                margin-left: auto;
                                margin-right: auto;
                            }
                            @media print {
                                body { background: white; }
                                .qr-container { 
                                    border: 2px solid #000; 
                                    page-break-inside: avoid;
                                }
                            }
                        </style>
                    </head>
                    <body>
                        <div class="qr-container">
                            <h1>${locationName}</h1>
                            <img src="${dataURL}" alt="QR Kod">
                            <div class="code">QR Kod: ${qrCode}</div>
                            <div class="company"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'SZB İK Takip'); ?></div>
                            <div class="instructions">
                                Bu QR kodu tarayarak lokasyonunuza giriş/çıkış işlemlerinizi gerçekleştirebilirsiniz.
                            </div>
                        </div>
                        <script>
                            window.onload = function() {
                                setTimeout(function() {
                                    window.print();
                                }, 500);
                            };
                        </script>
                    </body>
                </html>
                `);
                printWindow.document.close();
                
                // Show success message
                setTimeout(() => {
                    alert('✅ QR kod yazdırma sayfası açıldı!');
                }, 100);
                
            } catch (error) {
                console.error('Yazdırma hatası:', error);
                alert('❌ QR kod yazdırılamadı: ' + error.message);
            }
        } else {
            alert('❌ QR kod yazdırılamadı. Canvas elemanı bulunamadı.');
        }
    }

    function printQR(canvasId, locationName, qrCode) {
        const canvas = document.getElementById(canvasId);
        if (canvas) {
            const dataURL = canvas.toDataURL('image/png', 1.0);
            
            const printWindow = window.open('', '_blank', 'width=800,height=600');
            if (printWindow) {
                printWindow.document.write(`
                    <!DOCTYPE html>
                    <html>
                        <head>
                            <title>QR Kod - ${locationName}</title>
                            <style>
                                body { 
                                    font-family: Arial, sans-serif; 
                                    text-align: center; 
                                    padding: 20px;
                                    margin: 0;
                                }
                                .qr-container { 
                                    border: 3px solid #7C3AED; 
                                    padding: 30px; 
                                    display: inline-block; 
                                    margin: 20px;
                                    border-radius: 10px;
                                    background: white;
                                }
                                h1 { 
                                    font-size: 28px; 
                                    margin-bottom: 15px; 
                                    color: #7C3AED;
                                    font-weight: bold;
                                }
                                .code { 
                                    font-size: 14px; 
                                    color: #666; 
                                    margin-top: 10px; 
                                    font-family: monospace;
                                }
                                .company { 
                                    font-size: 16px; 
                                    color: #333; 
                                    margin-top: 15px; 
                                    font-weight: bold;
                                }
                                img { 
                                    max-width: 200px; 
                                    border: 1px solid #ddd;
                                    border-radius: 5px;
                                }
                                .instructions {
                                    font-size: 12px;
                                    color: #888;
                                    margin-top: 20px;
                                    max-width: 300px;
                                    margin-left: auto;
                                    margin-right: auto;
                                }
                                @media print {
                                    body { background: white; }
                                    .qr-container { 
                                        border: 2px solid #000; 
                                        page-break-inside: avoid;
                                    }
                                }
                            </style>
                        </head>
                        <body>
                            <div class="qr-container">
                                <h1>${locationName}</h1>
                                <img src="${dataURL}" alt="QR Kod">
                                <div class="code">QR Kod: ${qrCode}</div>
                                <div class="company"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'SZB İK Takip'); ?></div>
                                <div class="instructions">
                                    Bu QR kodu tarayarak lokasyonunuza giriş/çıkış işlemlerinizi gerçekleştirebilirsiniz.
                                </div>
                            </div>
                            <script>
                                window.onload = function() {
                                    setTimeout(function() {
                                        window.print();
                                    }, 500);
                                };
                            </script>
                        </body>
                    </html>
                `);
                printWindow.document.close();
            } else {
                alert('❌ Yazdırma penceresi açılamadı. Pop-up engelleyici kontrol edin.');
            }
        } else {
            alert('❌ QR kod yazdırılamadı. Canvas elemanı bulunamadı.');
        }
    }
    
    // Handle map loading errors
    window.gm_authFailure = function() {
        document.getElementById('map').innerHTML = `
            <div class="text-center text-red-600 p-8">
                <div class="text-4xl mb-4">⚠️</div>
                <div class="font-semibold mb-2">Google Maps API Hatası</div>
                <div class="text-sm mb-4">
                    API anahtarı geçersiz veya kotası aşılmış olabilir.<br>
                    Manuel koordinat girişi kullanabilirsiniz.
                </div>
                <div class="space-y-2">
                    <button onclick="useIstanbulCoords()" class="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700">
                        İstanbul Koordinatlarını Kullan
                    </button><br>
                    <button onclick="getCurrentLocation()" class="bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700">
                        📱 Mevcut Konumu Al
                    </button>
                </div>
            </div>
        `;
    };
    
    // Istanbul coordinates quick fill
    function useIstanbulCoords() {
        document.getElementById('latitude').value = '41.0082';
        document.getElementById('longitude').value = '28.9784';
        document.getElementById('addressSearch').value = 'İstanbul, Türkiye';
        document.getElementById('fullAddress').value = 'İstanbul, Türkiye';
        alert('✅ İstanbul koordinatları eklendi');
    }
    
    // Initialize fallback map display
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            if (typeof google === 'undefined' CONCAT!hasValidApiKey) {
                const mapElement = document.getElementById('map');
                if (mapElement) {
                    mapElement.innerHTML = `
                        <div class="text-center text-gray-600 p-8">
                            <div class="text-4xl mb-4">🗺️</div>
                            <div class="font-semibold mb-2">${hasValidApiKey ? 'Google Maps Yükleniyor...' : 'Manuel Koordinat Girişi'}</div>
                            <div class="text-sm mb-4">
                                ${hasValidApiKey ? 'Lütfen bekleyin...' : 'Manuel koordinat girişi kullanabilirsiniz<br>İstanbul koordinatları: 41.0082, 28.9784'}
                            </div>
                            <div class="space-y-2">
                                <button onclick="useIstanbulCoords()" class="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700">
                                    İstanbul Koordinatlarını Kullan
                                </button><br>
                                <button onclick="getCurrentLocation()" class="bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700">
                                    📱 Mevcut Konumu Al
                                </button>
                            </div>
                        </div>
                    `;
                }
            }
        }, 2000);
    });
    
    // Get current location function
    function getCurrentLocation() {
        if ("geolocation" in navigator) {
            const button = event.target;
            const originalText = button.textContent;
            button.textContent = '📍 Konum alınıyor...';
            button.disabled = 1;
            
            navigator.geolocation.getCurrentPosition(function(position) {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                
                document.getElementById('latitude').value = lat.toFixed(6);
                document.getElementById('longitude').value = lng.toFixed(6);
                
                // Update map if available
                if (typeof map !== 'undefined' && map) {
                    const newLocation = { lat: lat, lng: lng };
                    map.setCenter(newLocation);
                    placeMarker(newLocation);
                    reverseGeocode(newLocation);
                }
                
                button.textContent = '✅ Konum Alındı';
                button.style.backgroundColor = '#10B981';
                setTimeout(() => {
                    button.textContent = originalText;
                    button.style.backgroundColor = '';
                    button.disabled = 0;
                }, 2000);
                
                alert('✅ Mevcut konum başarıyla alındı!\nEnlem: ' + lat.toFixed(6) + '\nBoylam: ' + lng.toFixed(6));
            }, function(error) {
                button.textContent = originalText;
                button.disabled = 0;
                
                let errorMessage = 'Konum alınamadı: ';
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMessage += 'Konum izni reddedildi. Tarayıcı ayarlarından konum izni verin.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMessage += 'Konum bilgisi mevcut değil.';
                        break;
                    case error.TIMEOUT:
                        errorMessage += 'Konum alma işlemi zaman aşımına uğradı.';
                        break;
                    default:
                        errorMessage += 'Bilinmeyen hata.';
                }
                alert('❌ ' + errorMessage);
            }, {
                enableHighAccuracy: 1,
                timeout: 10000,
                maximumAge: 0
            });
        } else {
            alert('❌ Tarayıcınız konum özelliğini desteklemiyor.');
        }
    }

    // Helper function to use Istanbul coordinates
    function useIstanbulCoords() {
        document.getElementById('latitude').value = '41.0082';
        document.getElementById('longitude').value = '28.9784';
        document.getElementById('addressSearch').value = 'İstanbul, Türkiye';
        document.getElementById('fullAddress').value = 'İstanbul, Türkiye';
        alert('✅ İstanbul koordinatları eklendi!');
    }

    // Delete location function
    function deleteLocation(locationId, locationName) {
        if (confirm('⚠️ Bu lokasyonu silmek istediğinizden emin misiniz?\n\nLokasyon: ' + locationName + '\n\nSilme işlemi geri alınamaz.')) {
            // Create form and submit
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            form.innerHTML = `
                <input type="hidden" name="action" value="delete_location">
                <input type="hidden" name="location_id" value="${locationId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    </script>
</body>
</html>