<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Minimal authentication check
if (!isset($_SESSION['company_id'])) {
    echo "Session yok - login olun";
    exit();
}

echo "<!DOCTYPE html><html><head><title>Basit QR Generator</title></head><body>";
echo "<h1>QR Generator - Çalışıyor!</h1>";
echo "<p>Company ID: " . $_SESSION['company_id'] . "</p>";

// Database connection test
try {
    require_once '../includes/database.php';
    $db = new Database();
    $conn = $db->getConnection();
    echo "<p>✅ Database bağlantısı başarılı</p>";
    
    // Location type düzeltme
    if ($_POST['fix_location'] ?? false) {
        $location_id = intval($_POST['location_id']);
        $new_type = $_POST['new_type'];
        
        $stmt = $conn->prepare("UPDATE qr_locations SET location_type = ? WHERE id = ? AND company_id = ?");
        if ($stmt->execute([$new_type, $location_id, $_SESSION['company_id']])) {
            echo "<p>✅ Lokasyon #{$location_id} güncellendi: {$new_type}</p>";
        }
    }
    
    // Location listesi
    $stmt = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE company_id = ?");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll();
    
    echo "<h2>Mevcut Lokasyonlar:</h2>";
    foreach ($locations as $loc) {
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 5px;'>";
        echo "<strong>" . htmlspecialchars($loc['name']) . "</strong> (ID: {$loc['id']})<br>";
        echo "Tür: " . htmlspecialchars($loc['location_type']) . "<br>";
        
        // Otomatik düzeltme önerisi
        $name_lower = strtolower($loc['name']);
        $suggested_type = null;
        
        if (strpos($name_lower, 'çıkış') !== false) $suggested_type = 'check_out';
        elseif (strpos($name_lower, 'mola') !== false) $suggested_type = 'tea_break';
        elseif (strpos($name_lower, 'giriş') !== false) $suggested_type = 'check_in';
        
        if ($suggested_type && $suggested_type !== $loc['location_type']) {
            echo "<form method='POST' style='display:inline;'>";
            echo "<input type='hidden' name='fix_location' value='1'>";
            echo "<input type='hidden' name='location_id' value='{$loc['id']}'>";
            echo "<input type='hidden' name='new_type' value='{$suggested_type}'>";
            echo "<button type='submit'>🔧 {$suggested_type} olarak düzelt</button>";
            echo "</form>";
        }
        
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Hata: " . $e->getMessage() . "</p>";
}

echo "</body></html>";
?>