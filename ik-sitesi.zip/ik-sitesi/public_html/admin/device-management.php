<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'trust_device') {
            $stmt = $conn->prepare("
                UPDATE employee_devices ed
                JOIN employees e ON ed.employee_id = e.id
                SET ed.is_trusted = 1, ed.trust_granted_by = ?, ed.trust_granted_at = NOW()
                WHERE ed.id = ? AND e.company_id = ?
            ");
            $stmt->execute([$_SESSION['user_id'], $_POST['device_id'], $_SESSION['company_id']]);
            
            // Log security event
            $stmt = $conn->prepare("
                INSERT INTO device_security_logs (
                    employee_id, device_fingerprint, event_type, 
                    severity, description
                ) SELECT 
                    ed.employee_id, ed.device_fingerprint, 'trust_granted', 
                    'low', 'Device marked as trusted by admin'
                FROM employee_devices ed WHERE ed.id = ?
            ");
            $stmt->execute([$_POST['device_id']]);
            
            $success = "Cihaz güvenilir olarak işaretlendi.";
        }
        
        if ($action === 'block_device') {
            $stmt = $conn->prepare("
                UPDATE employee_devices ed
                JOIN employees e ON ed.employee_id = e.id
                SET ed.is_trusted = 0
                WHERE ed.id = ? AND e.company_id = ?
            ");
            $stmt->execute([$_POST['device_id'], $_SESSION['company_id']]);
            
            // Log security event
            $stmt = $conn->prepare("
                INSERT INTO device_security_logs (
                    employee_id, device_fingerprint, event_type, 
                    severity, description
                ) SELECT 
                    ed.employee_id, ed.device_fingerprint, 'blocked_attempt', 
                    'high', 'Device blocked by admin'
                FROM employee_devices ed WHERE ed.id = ?
            ");
            $stmt->execute([$_POST['device_id']]);
            
            $success = "Cihaz engellendi.";
        }
        
        if ($action === 'update_device_notes') {
            $stmt = $conn->prepare("
                UPDATE employee_devices ed
                JOIN employees e ON ed.employee_id = e.id
                SET ed.notes = ? 
                WHERE ed.id = ? AND e.company_id = ?
            ");
            $stmt->execute([
                $_POST['notes'], 
                $_POST['device_id'], 
                $_SESSION['company_id']
            ]);
            $success = "Cihaz notları güncellendi.";
        }
    }
    
    // Ensure employee_number column exists
    try {
        $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
        $columns = $columnCheck->fetchAll();
        
        if (count($columns) == 0) {
            $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
            
            // Generate employee numbers for existing employees
            $existingEmps = $conn->query("SELECT id FROM employees WHERE employee_number IS NULL OR employee_number = ''");
            $employees = $existingEmps->fetchAll();
            
            foreach ($employees as $emp) {
                $employeeNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
                $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
                $updateStmt->execute([$employeeNumber, $emp['id']]);
            }
        }
    } catch (Exception $e) {
        // Continue even if column addition fails
    }
    
    // Get devices (only if tables exist)
    $devices = [];
    try {
        // Try with employee_number column, fallback without it
        try {
            $stmt = $conn->prepare("
                SELECT 
                    ed.*,
                    e.first_name,
                    e.last_name,
                    e.employee_number,
                    (SELECT COUNT(*) FROM device_records WHERE device_fingerprint = ed.device_fingerprint AND recorded_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as weekly_usage,
                    (SELECT MAX(recorded_at) FROM device_records WHERE device_fingerprint = ed.device_fingerprint) as last_activity,
                    (SELECT COUNT(DISTINCT ip_address) FROM device_records WHERE device_fingerprint = ed.device_fingerprint) as ip_count
                FROM employee_devices ed
                JOIN employees e ON ed.employee_id = e.id
                WHERE e.company_id = ?
                ORDER BY COALESCE(ed.last_seen_at, ed.created_at) DESC
            ");
        } catch (Exception $e1) {
            // Fallback without employee_number column
            $stmt = $conn->prepare("
                SELECT 
                    ed.*,
                    e.first_name,
                    e.last_name,
                    CONCAT('EMP', LPAD(e.id, 4, '0')) as employee_number,
                    0 as weekly_usage,
                    ed.last_seen_at as last_activity,
                    1 as ip_count
                FROM employee_devices ed
                JOIN employees e ON ed.employee_id = e.id
                WHERE e.company_id = ?
                ORDER BY COALESCE(ed.last_seen_at, ed.created_at) DESC
            ");
        }
        $stmt->execute([$_SESSION['company_id']]);
        $devices = $stmt->fetchAll();
    } catch (Exception $e) {
        if (strpos($e->getMessage(), "doesn't exist") !== false || strpos($e->getMessage(), "Table") !== false) {
            $error = "Cihaz yönetimi tabloları bulunamadı. Lütfen önce database düzeltme scriptini çalıştırın.";
        } else {
            $error = "Cihaz verileri yüklenemedi: " . $e->getMessage();
        }
    }
    
    // Get security events (only if tables exist)
    $security_events = [];
    try {
        if (!isset($error)) {
            // Try with employee_number column, fallback without it
            try {
                $stmt = $conn->prepare("
                    SELECT 
                        dsl.*,
                        e.first_name,
                        e.last_name,
                        e.employee_number
                    FROM device_security_logs dsl
                    JOIN employees e ON dsl.employee_id = e.id
                    WHERE e.company_id = ? AND dsl.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                    ORDER BY dsl.created_at DESC
                    LIMIT 20
                ");
            } catch (Exception $e2) {
                // Fallback without employee_number column
                $stmt = $conn->prepare("
                    SELECT 
                        dsl.*,
                        e.first_name,
                        e.last_name,
                        CONCAT('EMP', LPAD(e.id, 4, '0')) as employee_number
                    FROM device_security_logs dsl
                    JOIN employees e ON dsl.employee_id = e.id
                    WHERE e.company_id = ? AND dsl.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                    ORDER BY dsl.created_at DESC
                    LIMIT 20
                ");
            }
            $stmt->execute([$_SESSION['company_id']]);
            $security_events = $stmt->fetchAll();
        }
    } catch (Exception $e) {
        // Ignore errors if tables don't exist
    }
    
    // Get statistics (only if tables exist)
    $stats = ['total_devices' => 0, 'trusted_devices' => 0, 'blocked_devices' => 0, 'active_24h' => 0];
    try {
        if (!isset($error)) {
            // Try with is_blocked column first, fallback without it
            try {
                $stmt = $conn->prepare("
                    SELECT 
                        COUNT(*) as total_devices,
                        COUNT(CASE WHEN ed.is_trusted = 1 THEN 1 END) as trusted_devices,
                        COUNT(CASE WHEN COALESCE(ed.is_blocked, 0) = 1 THEN 1 END) as blocked_devices,
                        COUNT(CASE WHEN COALESCE(ed.last_seen_at, ed.created_at) >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as active_24h
                    FROM employee_devices ed
                    JOIN employees e ON ed.employee_id = e.id
                    WHERE e.company_id = ?
                ");
            } catch (PDOException $e1) {
                // Fallback without is_blocked column
                $stmt = $conn->prepare("
                    SELECT 
                        COUNT(*) as total_devices,
                        COUNT(CASE WHEN ed.is_trusted = 1 THEN 1 END) as trusted_devices,
                        0 as blocked_devices,
                        COUNT(CASE WHEN COALESCE(ed.last_seen_at, ed.created_at) >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as active_24h
                    FROM employee_devices ed
                    JOIN employees e ON ed.employee_id = e.id
                    WHERE e.company_id = ?
                ");
            }
            $stmt->execute([$_SESSION['company_id']]);
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    } catch (Exception $e) {
        // Ignore errors if tables don't exist
    }
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cihaz Yönetimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">🛡️</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Cihaz Yönetimi</h1>
                            <p class="text-sm text-gray-600">Personel cihazları ve güvenlik yönetimi</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../view-device-records.php" class="text-indigo-600 hover:text-indigo-900">
                            📊 Detaylı Kayıtlar
                        </a>
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <?php if (isset($success)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6 relative">
                    <strong>⚠️ Database Hatası:</strong> <?php echo htmlspecialchars($error); ?>
                    
                    <?php if (strpos($error, "tabloları bulunamadı") !== false): ?>
                        <div class="mt-4 p-4 bg-yellow-50 border border-yellow-300 rounded">
                            <h4 class="font-bold text-yellow-800 mb-2">🔧 Çözüm:</h4>
                            <p class="text-yellow-700 mb-3">Cihaz yönetimi için gerekli database tabloları eksik. Aşağıdaki düzeltme scriptini çalıştırın:</p>
                            <div class="flex gap-2">
                                <a href="../debug/create-device-tables-only.php" 
                                   class="inline-block bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded font-semibold">
                                    🚀 Hızlı Düzelt
                                </a>
                                <a href="../debug/fix-device-records.php" 
                                   class="inline-block bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded font-semibold">
                                    🛠️ Detaylı Tanı
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                            <span class="text-white text-sm font-bold"><?php echo $stats['total_devices']; ?></span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Toplam Cihaz</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $stats['total_devices']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                            <span class="text-white text-sm font-bold"><?php echo $stats['trusted_devices']; ?></span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Güvenilir Cihaz</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $stats['trusted_devices']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                            <span class="text-white text-sm font-bold"><?php echo $stats['blocked_devices']; ?></span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Engellenmiş Cihaz</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $stats['blocked_devices']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                            <span class="text-white text-sm font-bold"><?php echo $stats['active_24h']; ?></span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Son 24 Saat Aktif</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $stats['active_24h']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Devices Table -->
            <div class="bg-white rounded-lg shadow mb-8">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Personel Cihazları</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Personel</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cihaz Bilgisi</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aktivite</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($devices as $device): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center mr-3">
                                                <span class="text-gray-600 font-medium text-sm">
                                                    <?php echo strtoupper(substr($device['first_name'] ?? 'U', 0, 1) . substr($device['last_name'] ?? 'N', 0, 1)); ?>
                                                </span>
                                            </div>
                                            <div>
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo htmlspecialchars(($device['first_name'] ?? 'Unknown') . ' ' . ($device['last_name'] ?? '')); ?>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    No: <?php echo htmlspecialchars($device['employee_number'] ?? 'N/A'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars($device['device_name'] ?? 'Unknown Device'); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo htmlspecialchars($device['device_type'] ?? 'unknown'); ?>
                                        </div>
                                        <div class="text-xs text-gray-400">
                                            ID: <?php echo substr($device['device_fingerprint'], 0, 8); ?>...
                                        </div>
                                        <div class="text-xs text-gray-400">
                                            <?php echo $device['ip_count']; ?> farklı IP
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">
                                            <?php echo $device['usage_count']; ?> kullanım
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            Son 7 gün: <?php echo $device['weekly_usage']; ?>
                                        </div>
                                        <div class="text-xs text-gray-400">
                                            Son görülme: <?php echo $device['last_activity'] ? date('d.m.Y H:i', strtotime($device['last_activity'])) : 'Hiç'; ?>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <?php if (($device['is_blocked'] ?? 0)): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                ❌ Engellenmiş
                                            </span>
                                        <?php elseif ($device['is_trusted']): ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                                ✅ Güvenilir
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                                ⚠️ Bilinmeyen
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="px-6 py-4 text-sm font-medium">
                                        <div class="flex flex-col space-y-1">
                                            <?php if (!$device['is_trusted']): ?>
                                                <form method="POST" class="inline">
                                                    <input type="hidden" name="action" value="trust_device">
                                                    <input type="hidden" name="device_id" value="<?php echo $device['id']; ?>">
                                                    <button type="submit" class="text-green-600 hover:text-green-900">✅ Güvenilir Yap</button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <?php if (!($device['is_blocked'] ?? 0)): ?>
                                                <form method="POST" class="inline" onsubmit="return confirm('Bu cihazı engellemek istediğinizden emin misiniz?')">
                                                    <input type="hidden" name="action" value="block_device">
                                                    <input type="hidden" name="device_id" value="<?php echo $device['id']; ?>">
                                                    <button type="submit" class="text-red-600 hover:text-red-900">❌ Engelle</button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <a href="javascript:void(0)" onclick="editDeviceNotes(<?php echo $device['id']; ?>, '<?php echo htmlspecialchars($device['notes'] ?? ''); ?>')" 
                                               class="text-blue-600 hover:text-blue-900">📝 Not Ekle</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Security Events -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Son Güvenlik Olayları (7 gün)</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Personel</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Olay Türü</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Önem</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Açıklama</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Zaman</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($security_events as $event): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars(($event['first_name'] ?? 'Unknown') . ' ' . ($event['last_name'] ?? '')); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            No: <?php echo htmlspecialchars($event['employee_number'] ?? 'N/A'); ?>
                                        </div>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <span class="text-sm text-gray-900">
                                            <?php 
                                            switch($event['event_type']) {
                                                case 'new_device': echo '📱 Yeni Cihaz'; break;
                                                case 'suspicious_location': echo '🗺️ Şüpheli Lokasyon'; break;
                                                case 'multiple_devices': echo '🔄 Çoklu Cihaz'; break;
                                                case 'blocked_device': echo '❌ Cihaz Engellendi'; break;
                                                case 'trusted_device': echo '✅ Cihaz Onaylandı'; break;
                                                default: echo htmlspecialchars($event['event_type']);
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full
                                            <?php 
                                            switch($event['severity']) {
                                                case 'critical': echo 'bg-red-100 text-red-800'; break;
                                                case 'high': echo 'bg-orange-100 text-orange-800'; break;
                                                case 'medium': echo 'bg-yellow-100 text-yellow-800'; break;
                                                case 'low': echo 'bg-green-100 text-green-800'; break;
                                                default: echo 'bg-gray-100 text-gray-800';
                                            }
                                            ?>">
                                            <?php echo ucfirst($event['severity']); ?>
                                        </span>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">
                                            <?php echo htmlspecialchars($event['description']); ?>
                                        </div>
                                        <?php if ($event['ip_address']): ?>
                                            <div class="text-xs text-gray-500">
                                                IP: <?php echo htmlspecialchars($event['ip_address']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-900">
                                            <?php echo date('d.m.Y', strtotime($event['created_at'])); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo date('H:i:s', strtotime($event['created_at'])); ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Notes Modal -->
    <div id="notesModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg max-w-md w-full p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Cihaz Notları</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="update_device_notes">
                    <input type="hidden" name="device_id" id="notes_device_id">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Notlar</label>
                        <textarea name="notes" id="device_notes" rows="4" 
                                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                  placeholder="Cihaz hakkında notlarınızı buraya yazın..."></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closeNotesModal()" 
                                class="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                            İptal
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function editDeviceNotes(deviceId, currentNotes) {
        document.getElementById('notes_device_id').value = deviceId;
        document.getElementById('device_notes').value = currentNotes;
        document.getElementById('notesModal').classList.remove('hidden');
    }
    
    function closeNotesModal() {
        document.getElementById('notesModal').classList.add('hidden');
    }
    
    // Close modal when clicking outside
    document.getElementById('notesModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeNotesModal();
        }
    });
    </script>
</body>
</html>