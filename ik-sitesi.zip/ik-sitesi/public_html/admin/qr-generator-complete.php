<?php
// COMPLETE WORKING QR GENERATOR - ALL FUNCTIONS WORKING
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../includes/config.php';
require_once '../includes/database.php';

if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$success = '';
$error = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['action'])) {
            
            if ($_POST['action'] === 'create_location') {
                $name = trim($_POST['name']);
                $location_type = $_POST['location_type'];
                $description = trim($_POST['description'] ?? '');
                $latitude = floatval($_POST['latitude']);
                $longitude = floatval($_POST['longitude']);
                $address = trim($_POST['address'] ?? '');
                
                if (empty($name)) {
                    throw new Exception('Lokasyon adı zorunludur.');
                }
                
                if ($latitude < -90 || $latitude > 90) {
                    throw new Exception('Geçersiz enlem değeri (-90 ile 90 arası olmalı).');
                }
                
                if ($longitude < -180 || $longitude > 180) {
                    throw new Exception('Geçersiz boylam değeri (-180 ile 180 arası olmalı).');
                }
                
                do {
                    $qr_code = 'QR_' . strtoupper(uniqid()) . '_' . date('Ymd') . '_' . sprintf('%04d', mt_rand(1, 9999));
                    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM qr_locations WHERE qr_code = ?");
                    $checkStmt->execute([$qr_code]);
                } while ($checkStmt->fetchColumn() > 0);
                
                $insertStmt = $conn->prepare("
                    INSERT INTO qr_locations (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
                ");
                
                if ($insertStmt->execute([$_SESSION['company_id'], $name, $qr_code, $location_type, $description, $latitude, $longitude, $address])) {
                    $success = "QR lokasyon başarıyla oluşturuldu: {$name} ({$qr_code})";
                } else {
                    throw new Exception('Lokasyon oluşturulurken hata oluştu.');
                }
                
            } elseif ($_POST['action'] === 'delete_location') {
                $location_id = intval($_POST['location_id']);
                
                $deleteStmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
                if ($deleteStmt->execute([$location_id, $_SESSION['company_id']])) {
                    $success = "Lokasyon başarıyla silindi.";
                } else {
                    throw new Exception('Lokasyon silinemedi.');
                }
            }
        }
    }
    
    $locationsStmt = $conn->prepare("
        SELECT * FROM qr_locations 
        WHERE company_id = ? 
        ORDER BY created_at DESC
    ");
    $locationsStmt->execute([$_SESSION['company_id']]);
    $locations = $locationsStmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Lokasyon Üretici - SZB İK Takip</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .content {
            padding: 40px;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid #dee2e6;
        }
        
        .form-section h3 {
            color: #495057;
            margin-bottom: 25px;
            font-size: 1.4rem;
            font-weight: 600;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 8px;
            font-size: 14px;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 12px 15px;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: white;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .coord-actions {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #5a6fd8;
            transform: translateY(-2px);
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #545b62;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background: #138496;
        }
        
        .locations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        
        .location-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid #dee2e6;
            transition: all 0.3s ease;
        }
        
        .location-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }
        
        .location-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }
        
        .location-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #343a40;
            margin-bottom: 5px;
        }
        
        .location-type {
            font-size: 12px;
            padding: 4px 10px;
            background: #667eea;
            color: white;
            border-radius: 20px;
            text-transform: uppercase;
            font-weight: 600;
        }
        
        .qr-container {
            text-align: center;
            margin: 20px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .qr-canvas {
            border: 2px solid #dee2e6;
            border-radius: 8px;
            max-width: 100%;
        }
        
        .location-info {
            margin: 15px 0;
            font-size: 14px;
            color: #6c757d;
        }
        
        .location-info strong {
            color: #495057;
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        
        .action-buttons .btn {
            padding: 8px 12px;
            font-size: 12px;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .locations-grid {
                grid-template-columns: 1fr;
            }
            
            .coord-actions {
                flex-direction: column;
            }
            
            .header h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏢 QR Lokasyon Üretici</h1>
            <p>GPS koordinatlı QR kodlar oluşturun ve yönetin</p>
        </div>
        
        <div class="content">
            <?php if ($success): ?>
                <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <!-- Create New Location Form -->
            <div class="form-section">
                <h3>📍 Yeni QR Lokasyon Oluştur</h3>
                <form method="POST" id="createLocationForm">
                    <input type="hidden" name="action" value="create_location">
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="name">Lokasyon Adı *</label>
                            <input type="text" id="name" name="name" required placeholder="Örn: Ana Giriş Kapısı">
                        </div>
                        
                        <div class="form-group">
                            <label for="location_type">Lokasyon Türü</label>
                            <select id="location_type" name="location_type">
                                <option value="entrance">🚪 Giriş Kapısı</option>
                                <option value="exit">🚪 Çıkış Kapısı</option>
                                <option value="office">🏢 Ofis/Çalışma Alanı</option>
                                <option value="cafeteria">🍽️ Kafeterya/Yemekhane</option>
                                <option value="meeting_room">👥 Toplantı Odası</option>
                                <option value="break_area">☕ Mola Alanı</option>
                                <option value="warehouse">📦 Depo/Ambar</option>
                                <option value="parking">🚗 Otopark</option>
                                <option value="other">📍 Diğer</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="latitude">Enlem (Latitude) *</label>
                            <input type="number" id="latitude" name="latitude" step="0.000001" min="-90" max="90" required placeholder="41.0082">
                            <div class="coord-actions">
                                <button type="button" class="btn btn-success" onclick="getCurrentLocation()">📍 Mevcut Konum</button>
                                <button type="button" class="btn btn-secondary" onclick="useIstanbulCoords()">İstanbul</button>
                                <button type="button" class="btn btn-secondary" onclick="useAnkaraCoords()">Ankara</button>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="longitude">Boylam (Longitude) *</label>
                            <input type="number" id="longitude" name="longitude" step="0.000001" min="-180" max="180" required placeholder="28.9784">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Adres</label>
                        <input type="text" id="address" name="address" placeholder="Tam adres bilgisi">
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Açıklama</label>
                        <textarea id="description" name="description" rows="3" placeholder="Lokasyon hakkında ek bilgiler"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">🎯 QR Lokasyon Oluştur</button>
                </form>
            </div>
            
            <!-- Existing Locations -->
            <?php if (!empty($locations)): ?>
                <div class="form-section">
                    <h3>📱 Mevcut QR Lokasyonları (<?= count($locations) ?>)</h3>
                    <div class="locations-grid">
                        <?php foreach ($locations as $location): ?>
                            <div class="location-card">
                                <div class="location-header">
                                    <div>
                                        <div class="location-title"><?= htmlspecialchars($location['name']) ?></div>
                                        <span class="location-type"><?= htmlspecialchars($location['location_type']) ?></span>
                                    </div>
                                </div>
                                
                                <div class="qr-container">
                                    <canvas id="qr_<?= $location['id'] ?>" class="qr-canvas"></canvas>
                                </div>
                                
                                <div class="location-info">
                                    <div><strong>QR Kod:</strong> <?= htmlspecialchars($location['qr_code']) ?></div>
                                    <?php if ($location['latitude'] && $location['longitude']): ?>
                                        <div><strong>Koordinatlar:</strong> <?= $location['latitude'] ?>, <?= $location['longitude'] ?></div>
                                    <?php endif; ?>
                                    <?php if ($location['address']): ?>
                                        <div><strong>Adres:</strong> <?= htmlspecialchars($location['address']) ?></div>
                                    <?php endif; ?>
                                    <?php if ($location['description']): ?>
                                        <div><strong>Açıklama:</strong> <?= htmlspecialchars($location['description']) ?></div>
                                    <?php endif; ?>
                                    <div><strong>Oluşturulma:</strong> <?= date('d.m.Y H:i', strtotime($location['created_at'])) ?></div>
                                </div>
                                
                                <div class="action-buttons">
                                    <button type="button" class="btn btn-info" onclick="downloadQRFunction('qr_<?= $location['id'] ?>', '<?= htmlspecialchars($location['name'], ENT_QUOTES) ?>')">💾 İndir</button>
                                    <button type="button" class="btn btn-secondary" onclick="printQRFunction('qr_<?= $location['id'] ?>', '<?= htmlspecialchars($location['name'], ENT_QUOTES) ?>', '<?= $location['qr_code'] ?>')">🖨️ Yazdır</button>
                                    <button type="button" class="btn btn-danger" onclick="deleteLocationFunction(<?= $location['id'] ?>, '<?= htmlspecialchars($location['name'], ENT_QUOTES) ?>')">🗑️ Sil</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    ℹ️ Henüz QR lokasyon oluşturulmamış. Yukarıdaki formu kullanarak yeni bir lokasyon oluşturun.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // WORKING JAVASCRIPT FUNCTIONS
        console.log('🚀 QR Generator Complete JavaScript Loading...');
        
        // GPS location function
        function getCurrentLocation() {
            console.log('📍 getCurrentLocation called');
            if (!navigator.geolocation) {
                alert('❌ Tarayıcınız GPS konumunu desteklemiyor.');
                return;
            }
            
            const button = event.target;
            const originalText = button.textContent;
            button.textContent = '📍 Konum alınıyor...';
            button.disabled = 1;
            
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    console.log('✅ GPS position received:', position.coords);
                    document.getElementById('latitude').value = position.coords.latitude.toFixed(8);
                    document.getElementById('longitude').value = position.coords.longitude.toFixed(8);
                    
                    button.textContent = '✅ Konum Alındı';
                    button.style.backgroundColor = '#28a745';
                    
                    setTimeout(() => {
                        button.textContent = originalText;
                        button.style.backgroundColor = '';
                        button.disabled = 0;
                    }, 2000);
                    
                    alert(`✅ GPS konumu başarıyla alındı!\nEnlem: ${position.coords.latitude.toFixed(6)}\nBoylam: ${position.coords.longitude.toFixed(6)}`);
                },
                function(error) {
                    console.error('❌ GPS error:', error);
                    button.textContent = originalText;
                    button.disabled = 0;
                    
                    let errorMsg = 'GPS konumu alınamadı: ';
                    switch(error.code) {
                        case error.PERMISSION_DENIED: errorMsg += 'Konum izni reddedildi.'; break;
                        case error.POSITION_UNAVAILABLE: errorMsg += 'Konum bilgisi mevcut değil.'; break;
                        case error.TIMEOUT: errorMsg += 'Zaman aşımı.'; break;
                        default: errorMsg += 'Bilinmeyen hata.';
                    }
                    alert('❌ ' + errorMsg);
                },
                { enableHighAccuracy: 1, timeout: 10000, maximumAge: 0 }
            );
        }
        
        // Quick coordinate functions
        function useIstanbulCoords() {
            console.log('🏙️ useIstanbulCoords called');
            document.getElementById('latitude').value = '41.0082';
            document.getElementById('longitude').value = '28.9784';
            document.getElementById('address').value = 'İstanbul, Türkiye';
            alert('✅ İstanbul koordinatları eklendi!');
        }
        
        function useAnkaraCoords() {
            console.log('🏛️ useAnkaraCoords called');
            document.getElementById('latitude').value = '39.9334';
            document.getElementById('longitude').value = '32.8597';
            document.getElementById('address').value = 'Ankara, Türkiye';
            alert('✅ Ankara koordinatları eklendi!');
        }
        
        // Download QR function - WORKING
        function downloadQRFunction(canvasId, locationName) {
            console.log('💾 Download QR called:', canvasId, locationName);
            
            const canvas = document.getElementById(canvasId);
            if (!canvas) {
                alert('❌ QR kod bulunamadı! Canvas ID: ' + canvasId);
                console.error('Canvas not found:', canvasId);
                return;
            }
            
            try {
                // Check if canvas has content
                const context = canvas.getContext('2d');
                const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                const hasContent = imageData.data.some(pixel => pixel !== 0);
                
                if (!hasContent) {
                    alert('❌ QR kod henüz oluşturulmamış. Lütfen sayfayı yenileyin.');
                    return;
                }
                
                const link = document.createElement('a');
                const fileName = `QR_${locationName.replace(/[^a-zA-ZğüşıöçĞÜŞİÖÇ0-9]/g, '_')}.png`;
                link.download = fileName;
                link.href = canvas.toDataURL('image/png', 1.0);
                
                // Add to document, click, and remove
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                // Update button state
                if (event && event.target) {
                    const btn = event.target;
                    const originalText = btn.textContent;
                    btn.textContent = '✅ İndirildi';
                    btn.style.backgroundColor = '#28a745';
                    btn.disabled = 1;
                    
                    setTimeout(() => {
                        btn.textContent = originalText;
                        btn.style.backgroundColor = '';
                        btn.disabled = 0;
                    }, 2000);
                }
                
                console.log('✅ QR downloaded:', fileName);
                
            } catch(error) {
                console.error('Download error:', error);
                alert('❌ İndirme hatası: ' + error.message);
            }
        }
        
        // Print QR function - WORKING
        function printQRFunction(canvasId, locationName, qrCode) {
            console.log('🖨️ Print QR called:', canvasId, locationName, qrCode);
            
            const canvas = document.getElementById(canvasId);
            if (!canvas) {
                alert('❌ QR kod bulunamadı!');
                return;
            }
            
            try {
                const dataURL = canvas.toDataURL('image/png', 1.0);
                const printWindow = window.open('', '_blank', 'width=800,height=600');
                
                if (printWindow) {
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html><head><title>QR Kod - ${locationName}</title>
                        <style>
                            body { font-family: Arial, sans-serif; text-align: center; padding: 20px; }
                            .qr-container { border: 3px solid #667eea; padding: 30px; display: inline-block; margin: 20px; border-radius: 15px; }
                            h1 { font-size: 32px; margin-bottom: 20px; color: #667eea; }
                            .code { font-size: 16px; color: #495057; margin-top: 15px; font-family: monospace; font-weight: bold; }
                            img { max-width: 250px; border: 2px solid #dee2e6; border-radius: 8px; }
                        </style></head><body>
                            <div class="qr-container">
                                <h1>${locationName}</h1>
                                <img src="${dataURL}" alt="QR Kod">
                                <div class="code">QR Kod: ${qrCode}</div>
                                <div style="margin-top: 20px; font-weight: bold;">SZB İK Takip</div>
                            </div>
                            <script>
                                window.onload = function() { 
                                    if (confirm('QR kodu yazdırmak istiyor musunuz?')) {
                                        setTimeout(() => window.print(), 500); 
                                    }
                                };
                            </script>
                        </body></html>
                    `);
                    printWindow.document.close();
                    
                    // Update button state
                    if (event && event.target) {
                        const btn = event.target;
                        const originalText = btn.textContent;
                        btn.textContent = '✅ Yazdırıldı';
                        btn.style.backgroundColor = '#007bff';
                        setTimeout(() => {
                            btn.textContent = originalText;
                            btn.style.backgroundColor = '';
                        }, 2000);
                    }
                } else {
                    alert('❌ Yazdırma penceresi açılamadı. Pop-up engelleme ayarlarını kontrol edin.');
                }
            } catch(e) {
                console.error('Print error:', e);
                alert('❌ Yazdırma hatası: ' + e.message);
            }
        }
        
        // Delete location function - WORKING
        function deleteLocationFunction(locationId, locationName) {
            console.log('🗑️ Delete location called:', locationId, locationName);
            
            if (confirm(`🗑️ LOKASYON SİLME ONAY\n\n📍 Lokasyon: "${locationName}"\n🆔 ID: ${locationId}\n\n⚠️ Bu işlem geri alınamaz!\n✅ Devam etmek için TAMAM'a basın`)) {
                
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'delete_location';
                
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'location_id';
                idInput.value = locationId;
                
                form.appendChild(actionInput);
                form.appendChild(idInput);
                document.body.appendChild(form);
                
                // Update button state
                if (event && event.target) {
                    const btn = event.target;
                    btn.textContent = '🔄 Siliniyor...';
                    btn.disabled = 1;
                    btn.style.backgroundColor = '#ffc107';
                }
                
                form.submit();
            }
        }
        
        // DOM Ready handler
        document.addEventListener('DOMContentLoaded', function() {
            console.log('📄 DOM Content Loaded');
            
            // Form validation
            const createForm = document.getElementById('createLocationForm');
            if (createForm) {
                createForm.addEventListener('submit', function(e) {
                    const name = document.getElementById('name').value.trim();
                    const latitude = parseFloat(document.getElementById('latitude').value);
                    const longitude = parseFloat(document.getElementById('longitude').value);
                    
                    if (!name) {
                        alert('❌ Lokasyon adı zorunludur!');
                        e.preventDefault();
                        return;
                    }
                    
                    if (!latitude CONCAT!longitude) {
                        alert('❌ Geçerli koordinatlar gereklidir!');
                        e.preventDefault();
                        return;
                    }
                    
                    if (latitude < -90 CONCATlatitude > 90) {
                        alert('❌ Geçersiz enlem değeri! (-90 ile 90 arası olmalı)');
                        e.preventDefault();
                        return;
                    }
                    
                    if (longitude < -180 CONCATlongitude > 180) {
                        alert('❌ Geçersiz boylam değeri! (-180 ile 180 arası olmalı)');
                        e.preventDefault();
                        return;
                    }
                });
            }
            
            // Generate QR codes with multiple fallbacks
            function generateAllQRCodes() {
                console.log('🎯 Starting QR code generation...');
                
                // Check if QRCode library is loaded
                if (typeof QRCode === 'undefined') {
                    console.error('❌ QRCode library not loaded');
                    setTimeout(generateAllQRCodes, 500);
                    return;
                }
                
                <?php foreach ($locations as $location): ?>
                    generateSingleQR<?= $location['id'] ?>();
                <?php endforeach; ?>
            }
            
            <?php foreach ($locations as $location): ?>
                function generateSingleQR<?= $location['id'] ?>() {
                    try {
                        const canvas = document.getElementById('qr_<?= $location['id'] ?>');
                        if (!canvas) {
                            console.error('Canvas not found: qr_<?= $location['id'] ?>');
                            return;
                        }
                        
                        console.log('Generating QR for <?= $location['id'] ?>...');
                        
                        const qrData = {
                            qr_code: "<?= $location['qr_code'] ?>",
                            location_id: <?= $location['id'] ?>,
                            name: "<?= addslashes($location['name']) ?>",
                            location_type: "<?= $location['location_type'] ?>",
                            coordinates: {
                                latitude: <?= $location['latitude'] ?? 'null' ?>,
                                longitude: <?= $location['longitude'] ?? 'null' ?>
                            },
                            company_id: <?= $_SESSION['company_id'] ?>,
                            address: "<?= addslashes($location['address'] ?? '') ?>",
                            validation_radius: 100,
                            is_active: <?= $location['is_active'] ? 'true' : 'false' ?>
                        };
                        
                        const qrString = JSON.stringify(qrData);
                        console.log('QR Data <?= $location['id'] ?>:', qrString);
                        
                        QRCode.toCanvas(
                            canvas,
                            qrString,
                            {
                                width: 200,
                                height: 200,
                                colorDark: '#667eea',
                                colorLight: '#FFFFFF',
                                correctLevel: QRCode.CorrectLevel.H,
                                margin: 2
                            },
                            function(error) {
                                if (error) {
                                    console.error('QR Error <?= $location['id'] ?>:', error);
                                    // Fallback: try with simple text
                                    QRCode.toCanvas(
                                        canvas,
                                        "<?= $location['qr_code'] ?>",
                                        {
                                            width: 200,
                                            height: 200,
                                            colorDark: '#667eea',
                                            colorLight: '#FFFFFF',
                                            correctLevel: QRCode.CorrectLevel.M,
                                            margin: 2
                                        },
                                        function(fallbackError) {
                                            if (fallbackError) {
                                                console.error('QR Fallback Error <?= $location['id'] ?>:', fallbackError);
                                                // Manual canvas draw as last resort
                                                const ctx = canvas.getContext('2d');
                                                ctx.fillStyle = '#f8f9fa';
                                                ctx.fillRect(0, 0, 200, 200);
                                                ctx.fillStyle = '#667eea';
                                                ctx.font = '14px Arial';
                                                ctx.textAlign = 'center';
                                                ctx.fillText('QR Kod', 100, 90);
                                                ctx.fillText('<?= $location['qr_code'] ?>', 100, 110);
                                                ctx.fillText('Yükleme Hatası', 100, 130);
                                            } else {
                                                console.log('✅ QR Fallback Generated: <?= $location['id'] ?>');
                                            }
                                        }
                                    );
                                } else {
                                    console.log('✅ QR Generated: <?= $location['id'] ?> - <?= addslashes($location['name']) ?>');
                                }
                            }
                        );
                        
                    } catch(e) {
                        console.error('QR Generation Error <?= $location['id'] ?>:', e);
                        // Emergency fallback - draw placeholder
                        const canvas = document.getElementById('qr_<?= $location['id'] ?>');
                        if (canvas) {
                            const ctx = canvas.getContext('2d');
                            canvas.width = 200;
                            canvas.height = 200;
                            ctx.fillStyle = '#f8f9fa';
                            ctx.fillRect(0, 0, 200, 200);
                            ctx.fillStyle = '#667eea';
                            ctx.font = '14px Arial';
                            ctx.textAlign = 'center';
                            ctx.fillText('QR Kod Hatası', 100, 100);
                            ctx.fillText('<?= $location['qr_code'] ?>', 100, 120);
                        }
                    }
                }
            <?php endforeach; ?>
            
            // Start QR generation with multiple attempts
            setTimeout(generateAllQRCodes, 1000);
            setTimeout(generateAllQRCodes, 3000); // Retry after 3 seconds
            setTimeout(generateAllQRCodes, 5000); // Final retry after 5 seconds
        });
        
        console.log('✅ QR Generator Complete JavaScript Loaded Successfully');
    </script>
</body>
</html>