<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin authentication
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$message = '';
$messageType = '';
$testResult = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle test scenarios
    if (isset($_POST['action']) && $_POST['action'] === 'test_scenario') {
        $scenario = $_POST['scenario'];
        $employeeId = intval($_POST['employee_id'] ?? 1);
        $today = date('Y-m-d');
        
        switch($scenario) {
            case 'fresh_start':
                // Clear all records for today
                $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
                $stmt->execute([$employeeId, $today]);
                $testResult = "✅ Personel kaydı temizlendi. Şimdi GIRIŞ kapısından giriş yapabilir.";
                break;
                
            case 'simulate_checkin':
                // Simulate check-in
                $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
                $stmt->execute([$employeeId, $today]);
                
                $stmt = $conn->prepare("INSERT INTO attendance_records (employee_id, company_id, date, check_in, created_at) VALUES (?, 1, ?, NOW(), NOW())");
                $stmt->execute([$employeeId, $today]);
                $testResult = "✅ Giriş simüle edildi. Şimdi:\n- GIRIŞ kapısı: Hata verecek (zaten giriş yapılmış)\n- ÇIKIŞ kapısı: Çıkış yapabilir\n- MOLA kapısı: Mola başlatabilir";
                break;
                
            case 'simulate_break':
                // Simulate in break
                $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
                $stmt->execute([$employeeId, $today]);
                
                $stmt = $conn->prepare("INSERT INTO attendance_records (employee_id, company_id, date, check_in, break_start, created_at) VALUES (?, 1, ?, NOW(), NOW(), NOW())");
                $stmt->execute([$employeeId, $today]);
                $testResult = "✅ Molada simüle edildi. Şimdi:\n- MOLA kapısı: Mola bitirebilir\n- ÇIKIŞ kapısı: Molayı bitirip çıkış yapar";
                break;
                
            case 'simulate_workday':
                // Simulate full workday
                $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
                $stmt->execute([$employeeId, $today]);
                
                $stmt = $conn->prepare("INSERT INTO attendance_records (employee_id, company_id, date, check_in, break_start, break_end, check_out, created_at) VALUES (?, 1, ?, '09:00:00', '12:00:00', '13:00:00', '18:00:00', NOW())");
                $stmt->execute([$employeeId, $today]);
                $testResult = "✅ Tam gün simüle edildi. Şimdi:\n- TÜM kapılar: Hata verecek (gün tamamlanmış)";
                break;
        }
    }
    
    // Get test employee
    $companyId = $_SESSION['company_id'] ?? 1;
    $stmt = $conn->prepare("
        SELECT e.id, e.first_name, e.last_name, 
               ar.check_in, ar.break_start, ar.break_end, ar.check_out
        FROM employees e
        LEFT JOIN attendance_records ar ON e.id = ar.employee_id AND ar.date = CURDATE()
        WHERE e.company_id = ?
        ORDER BY e.id
        LIMIT 1
    ");
    $stmt->execute([$companyId]);
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $message = "Hata: " . $e->getMessage();
    $messageType = 'error';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Test Rehberi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-purple-50 to-pink-100 min-h-screen">
    <div class="container mx-auto px-4 py-6 max-w-4xl">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">📚</span>
            </div>
            <h1 class="text-3xl font-bold text-gray-900">QR Test Rehberi</h1>
            <p class="text-gray-600 mt-2">Kapı sistemini test etme rehberi</p>
        </div>

        <!-- Current Status -->
        <?php if ($testEmployee): ?>
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">👤 Test Personeli Durumu</h2>
            <div class="bg-gray-50 p-4 rounded-lg">
                <p class="font-semibold mb-2"><?php echo htmlspecialchars($testEmployee['first_name'] . ' ' . $testEmployee['last_name']); ?></p>
                <div class="grid grid-cols-2 gap-2 text-sm">
                    <div>Giriş: <?php echo $testEmployee['check_in'] ? '✅ ' . date('H:i', strtotime($testEmployee['check_in'])) : '❌ Yok'; ?></div>
                    <div>Mola Başla: <?php echo $testEmployee['break_start'] ? '✅ ' . date('H:i', strtotime($testEmployee['break_start'])) : '❌ Yok'; ?></div>
                    <div>Mola Bitir: <?php echo $testEmployee['break_end'] ? '✅ ' . date('H:i', strtotime($testEmployee['break_end'])) : '❌ Yok'; ?></div>
                    <div>Çıkış: <?php echo $testEmployee['check_out'] ? '✅ ' . date('H:i', strtotime($testEmployee['check_out'])) : '❌ Yok'; ?></div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Test Result -->
        <?php if ($testResult): ?>
        <div class="bg-green-100 border border-green-300 text-green-800 p-4 rounded-lg mb-6">
            <pre class="whitespace-pre-wrap"><?php echo $testResult; ?></pre>
        </div>
        <?php endif; ?>

        <!-- Test Scenarios -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">🧪 Test Senaryoları</h2>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="test_scenario">
                <input type="hidden" name="employee_id" value="<?php echo isset($testEmployee) ? $testEmployee['id'] : 1; ?>">
                
                <div class="grid gap-3">
                    <button type="submit" name="scenario" value="fresh_start" class="bg-green-500 text-white p-4 rounded-lg hover:bg-green-600 text-left">
                        <div class="font-bold">🆕 Temiz Başlangıç</div>
                        <div class="text-sm mt-1">Bugünkü tüm kayıtları sil - İlk giriş senaryosu</div>
                    </button>
                    
                    <button type="submit" name="scenario" value="simulate_checkin" class="bg-blue-500 text-white p-4 rounded-lg hover:bg-blue-600 text-left">
                        <div class="font-bold">🟢 Giriş Yapılmış</div>
                        <div class="text-sm mt-1">Sadece giriş yapılmış durumu simüle et</div>
                    </button>
                    
                    <button type="submit" name="scenario" value="simulate_break" class="bg-yellow-500 text-white p-4 rounded-lg hover:bg-yellow-600 text-left">
                        <div class="font-bold">🟡 Molada</div>
                        <div class="text-sm mt-1">Giriş yapılmış ve molada durumu simüle et</div>
                    </button>
                    
                    <button type="submit" name="scenario" value="simulate_workday" class="bg-red-500 text-white p-4 rounded-lg hover:bg-red-600 text-left">
                        <div class="font-bold">🔴 Gün Tamamlanmış</div>
                        <div class="text-sm mt-1">Tam iş günü tamamlanmış durumu simüle et</div>
                    </button>
                </div>
            </form>
        </div>

        <!-- Gate Behaviors Guide -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">🚪 Kapı Davranışları</h2>
            
            <div class="space-y-4">
                <div class="border-l-4 border-green-500 pl-4">
                    <h3 class="font-bold text-green-700">🟢 GIRIŞ KAPISI (work_start)</h3>
                    <ul class="text-sm text-gray-700 mt-2 space-y-1">
                        <li>✅ İzin Verir: Hiç giriş yapılmamışsa</li>
                        <li>✅ İzin Verir: Çıkış yapılmışsa (yeni gün)</li>
                        <li>❌ Hata Verir: Zaten giriş yapılmışsa</li>
                    </ul>
                </div>
                
                <div class="border-l-4 border-red-500 pl-4">
                    <h3 class="font-bold text-red-700">🔴 ÇIKIŞ KAPISI (work_end)</h3>
                    <ul class="text-sm text-gray-700 mt-2 space-y-1">
                        <li>✅ İzin Verir: Giriş yapılmış ve çıkış yapılmamışsa</li>
                        <li>✅ Otomatik: Molada ise molayı bitirip çıkış yapar</li>
                        <li>⏱️ Hesaplama: Toplam çalışma süresinden mola sürelerini düşer</li>
                        <li>❌ Hata Verir: Giriş yapılmamışsa</li>
                        <li>❌ Hata Verir: Zaten çıkış yapılmışsa</li>
                    </ul>
                </div>
                
                <div class="border-l-4 border-yellow-500 pl-4">
                    <h3 class="font-bold text-yellow-700">🟡 MOLA KAPISI (break_toggle)</h3>
                    <ul class="text-sm text-gray-700 mt-2 space-y-1">
                        <li>✅ Mola Başlatır: Giriş yapılmış, mola başlamamışsa veya mola bitmişse</li>
                        <li>✅ Mola Bitirir: Mola başlamış, bitmemişse</li>
                        <li>🔄 Sınırsız: Çıkış yapılana kadar istediği kadar mola yapabilir</li>
                        <li>❌ Hata Verir: Giriş yapılmamışsa</li>
                        <li>❌ Hata Verir: Çıkış yapılmışsa</li>
                    </ul>
                </div>
                
                <div class="border-l-4 border-blue-500 pl-4">
                    <h3 class="font-bold text-blue-700">🔵 GENEL KAPI (user_choice)</h3>
                    <ul class="text-sm text-gray-700 mt-2 space-y-1">
                        <li>🤖 Akıllı: Duruma göre otomatik karar verir</li>
                        <li>📊 Öncelik: Giriş → Mola → Çıkış sırası</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Common Issues -->
        <div class="bg-yellow-50 rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">⚠️ Sık Karşılaşılan Durumlar</h2>
            
            <div class="space-y-3">
                <div class="bg-white p-3 rounded-lg">
                    <p class="font-semibold text-red-600">Sorun: "Bu giriş kapısı! Zaten işe başlamışsınız"</p>
                    <p class="text-sm text-gray-700 mt-1">Çözüm: Bu bir hata değil! Personel zaten giriş yapmış. Test için "Temiz Başlangıç" butonuna basın.</p>
                </div>
                
                <div class="bg-white p-3 rounded-lg">
                    <p class="font-semibold text-red-600">Sorun: "Bu çıkış kapısı! Önce giriş kapısından işe başlamalısınız"</p>
                    <p class="text-sm text-gray-700 mt-1">Çözüm: Doğru davranış. Önce giriş yapılmalı. "Giriş Yapılmış" senaryosunu test edin.</p>
                </div>
                
                <div class="bg-white p-3 rounded-lg">
                    <p class="font-semibold text-orange-600">Sorun: Kapı türü tespit edilmiyor</p>
                    <p class="text-sm text-gray-700 mt-1">Çözüm: QR lokasyon adında "giriş", "çıkış" veya "mola" kelimesi olmalı. QR Yönetimi'nden düzenleyin.</p>
                </div>
            </div>
        </div>

        <!-- Navigation -->
        <div class="text-center space-x-3">
            <a href="test-gate-system.php" class="inline-block bg-purple-600 text-white py-3 px-6 rounded-lg hover:bg-purple-700">
                🧪 Test Paneli
            </a>
            <a href="qr-generator.php" class="inline-block bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700">
                📱 QR Yönetimi
            </a>
            <a href="../dashboard/company-dashboard.php" class="inline-block bg-gray-600 text-white py-3 px-6 rounded-lg hover:bg-gray-700">
                🏠 Dashboard
            </a>
        </div>
    </div>
</body>
</html>