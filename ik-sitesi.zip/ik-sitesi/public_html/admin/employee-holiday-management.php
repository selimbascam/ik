<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $message = '';
    $messageType = '';
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'bulk_assign_holidays') {
            try {
                $selectedEmployees = $_POST['employee_ids'] ?? [];
                $selectedDays = $_POST['holiday_days'] ?? [];
                
                if (empty($selectedEmployees)) {
                    throw new Exception("Lütfen en az bir personel seçin");
                }
                
                if (empty($selectedDays)) {
                    throw new Exception("Lütfen en az bir tatil günü seçin");
                }
                
                // Check if table exists, if not create it
                $checkTable = $conn->query("SHOW TABLES LIKE 'employee_weekly_holidays'");
                if ($checkTable->rowCount() === 0) {
                    $conn->exec("
                        CREATE TABLE employee_weekly_holidays (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            employee_id INT NOT NULL,
                            company_id INT NOT NULL,
                            monday BOOLEAN DEFAULT 0,
                            tuesday BOOLEAN DEFAULT 0,
                            wednesday BOOLEAN DEFAULT 0,
                            thursday BOOLEAN DEFAULT 0,
                            friday BOOLEAN DEFAULT 0,
                            saturday BOOLEAN DEFAULT 1,
                            sunday BOOLEAN DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                            UNIQUE KEY unique_employee (employee_id)
                        )
                    ");
                }
                
                $assignedCount = 0;
                foreach ($selectedEmployees as $employeeId) {
                    // Get employee info
                    $stmt = $conn->prepare("SELECT company_id FROM employees WHERE id = ?");
                    $stmt->execute([$employeeId]);
                    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($employee) {
                        // Prepare day values
                        $dayValues = [
                            'monday' => in_array('1', $selectedDays) ? 1 : 0,
                            'tuesday' => in_array('2', $selectedDays) ? 1 : 0,
                            'wednesday' => in_array('3', $selectedDays) ? 1 : 0,
                            'thursday' => in_array('4', $selectedDays) ? 1 : 0,
                            'friday' => in_array('5', $selectedDays) ? 1 : 0,
                            'saturday' => in_array('6', $selectedDays) ? 1 : 0,
                            'sunday' => in_array('0', $selectedDays) ? 1 : 0
                        ];
                        
                        // Insert or update employee holidays
                        $stmt = $conn->prepare("
                            INSERT INTO employee_weekly_holidays 
                            (employee_id, company_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE
                            monday = VALUES(monday),
                            tuesday = VALUES(tuesday),
                            wednesday = VALUES(wednesday),
                            thursday = VALUES(thursday),
                            friday = VALUES(friday),
                            saturday = VALUES(saturday),
                            sunday = VALUES(sunday),
                            updated_at = CURRENT_TIMESTAMP
                        ");
                        
                        $stmt->execute([
                            $employeeId,
                            $employee['company_id'],
                            $dayValues['monday'],
                            $dayValues['tuesday'],
                            $dayValues['wednesday'],
                            $dayValues['thursday'],
                            $dayValues['friday'],
                            $dayValues['saturday'],
                            $dayValues['sunday']
                        ]);
                        
                        $assignedCount++;
                    }
                }
                
                $message = "✅ $assignedCount personele haftalık tatil günleri atandı!";
                $messageType = "success";
                
            } catch (Exception $e) {
                $message = "❌ Atama hatası: " . $e->getMessage();
                $messageType = "error";
            }
        }
    }
    
    // Get all employees with their holiday settings
    $stmt = $conn->prepare("
        SELECT 
            e.id,
            e.first_name,
            e.last_name,
            e.employee_number,
            e.department,
            ewh.monday,
            ewh.tuesday,
            ewh.wednesday,
            ewh.thursday,
            ewh.friday,
            ewh.saturday,
            ewh.sunday,
            ewh.updated_at
        FROM employees e
        LEFT JOIN employee_weekly_holidays ewh ON e.id = ewh.employee_id
        WHERE e.company_id = ?
        ORDER BY e.first_name, e.last_name
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Day names in Turkish
    $dayNames = [
        'sunday' => 'Pazar',
        'monday' => 'Pazartesi', 
        'tuesday' => 'Salı',
        'wednesday' => 'Çarşamba',
        'thursday' => 'Perşembe',
        'friday' => 'Cuma',
        'saturday' => 'Cumartesi'
    ];
    
} catch (Exception $e) {
    $message = "❌ Sistem hatası: " . $e->getMessage();
    $messageType = "error";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Tatil Yönetimi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <h1 class="text-2xl font-bold text-gray-900">🏖️ Personel Tatil Yönetimi</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                        ← Ana Sayfa
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto py-8 px-4">
        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Bulk Assignment Form -->
        <div class="bg-white rounded-xl shadow-lg mb-8">
            <div class="px-6 py-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
                <h2 class="text-xl font-bold text-gray-900">⚡ Toplu Tatil Günü Ataması</h2>
                <p class="text-gray-600 mt-1">Birden fazla personele aynı tatil günlerini atayın</p>
            </div>

            <div class="p-6">
                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="bulk_assign_holidays">
                    
                    <!-- Employee Selection -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-3">Personel Seçimi:</label>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-60 overflow-y-auto border rounded-lg p-4">
                            <label class="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded">
                                <input type="checkbox" id="select-all" class="rounded">
                                <span class="font-medium text-blue-600">Tümünü Seç</span>
                            </label>
                            
                            <?php foreach ($employees as $employee): ?>
                                <label class="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded employee-checkbox">
                                    <input type="checkbox" name="employee_ids[]" value="<?php echo $employee['id']; ?>" class="rounded">
                                    <span class="text-sm">
                                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                        <?php if ($employee['employee_number']): ?>
                                            <span class="text-gray-500">(<?php echo $employee['employee_number']; ?>)</span>
                                        <?php endif; ?>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Day Selection -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-3">Tatil Günleri:</label>
                        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                            <?php 
                            $dayOptions = [
                                '0' => ['name' => 'Pazar', 'icon' => '☀️'],
                                '1' => ['name' => 'Pazartesi', 'icon' => '💼'],
                                '2' => ['name' => 'Salı', 'icon' => '📊'],
                                '3' => ['name' => 'Çarşamba', 'icon' => '⚡'],
                                '4' => ['name' => 'Perşembe', 'icon' => '🎯'],
                                '5' => ['name' => 'Cuma', 'icon' => '🕌'],
                                '6' => ['name' => 'Cumartesi', 'icon' => '🎉']
                            ];
                            
                            foreach ($dayOptions as $dayNum => $dayInfo): ?>
                                <label class="flex flex-col items-center p-3 border-2 border-gray-200 rounded-lg hover:border-blue-300 cursor-pointer transition-colors">
                                    <input type="checkbox" name="holiday_days[]" value="<?php echo $dayNum; ?>" class="mb-2">
                                    <span class="text-2xl mb-1"><?php echo $dayInfo['icon']; ?></span>
                                    <span class="text-sm font-medium text-center"><?php echo $dayInfo['name']; ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="flex justify-end">
                        <button type="submit" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                            💾 Toplu Atama Yap
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Current Employee Holiday Settings -->
        <div class="bg-white rounded-xl shadow-lg">
            <div class="px-6 py-4 border-b">
                <h2 class="text-xl font-bold text-gray-900">📋 Mevcut Personel Tatil Durumu</h2>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Personel</th>
                            <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Paz</th>
                            <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Pzt</th>
                            <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Sal</th>
                            <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Çar</th>
                            <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Per</th>
                            <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Cum</th>
                            <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Cmt</th>
                            <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Son Güncelleme</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($employees as $employee): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                    </div>
                                    <?php if ($employee['employee_number']): ?>
                                        <div class="text-sm text-gray-500"><?php echo $employee['employee_number']; ?></div>
                                    <?php endif; ?>
                                    <?php if ($employee['department']): ?>
                                        <div class="text-xs text-gray-400"><?php echo $employee['department']; ?></div>
                                    <?php endif; ?>
                                </td>
                                
                                <?php 
                                $days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
                                foreach ($days as $day): 
                                    $isHoliday = isset($employee[$day]) ? (bool)$employee[$day] : ($day === 'saturday' || $day === 'sunday');
                                ?>
                                    <td class="px-3 py-4 text-center">
                                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium
                                            <?php echo $isHoliday ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                                            <?php echo $isHoliday ? '🚫' : '✅'; ?>
                                        </span>
                                    </td>
                                <?php endforeach; ?>
                                
                                <td class="px-6 py-4 text-center text-sm text-gray-500">
                                    <?php 
                                    echo $employee['updated_at'] ? 
                                        date('d.m.Y H:i', strtotime($employee['updated_at'])) : 
                                        'Varsayılan';
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Select all functionality
        document.getElementById('select-all').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.employee-checkbox input[type="checkbox"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });
        
        // Update select all when individual checkboxes change
        document.querySelectorAll('.employee-checkbox input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const allCheckboxes = document.querySelectorAll('.employee-checkbox input[type="checkbox"]');
                const checkedCheckboxes = document.querySelectorAll('.employee-checkbox input[type="checkbox"]:checked');
                const selectAllCheckbox = document.getElementById('select-all');
                
                if (checkedCheckboxes.length === allCheckboxes.length) {
                    selectAllCheckbox.checked = true;
                    selectAllCheckbox.indeterminate = false;
                } else if (checkedCheckboxes.length > 0) {
                    selectAllCheckbox.checked = false;
                    selectAllCheckbox.indeterminate = true;
                } else {
                    selectAllCheckbox.checked = false;
                    selectAllCheckbox.indeterminate = false;
                }
            });
        });
    </script>
</body>
</html>