<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'update_company_info') {
            try {
                $stmt = $conn->prepare("
                    UPDATE companies SET 
                        company_name = ?, address = ?, phone = ?, email = ?, 
                        tax_number = ?, company_type = ?, status = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $_POST['company_name'],
                    $_POST['address'],
                    $_POST['phone'], 
                    $_POST['email'],
                    $_POST['tax_number'],
                    $_POST['company_type'] ?? 'corporate',
                    $_POST['status'] ?? 'active',
                    $_SESSION['company_id']
                ]);
            } catch (PDOException $e) {
                // Fallback for missing columns
                $stmt = $conn->prepare("
                    UPDATE companies SET 
                        company_name = ?, address = ?, phone = ?, email = ?, 
                        tax_number = ?, company_type = ?, status = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $_POST['company_name'],
                    $_POST['address'],
                    $_POST['phone'],
                    $_POST['email'],
                    $_POST['tax_number'],
                    $_POST['company_type'] ?? 'corporate',
                    $_POST['status'] ?? 'active',
                    $_SESSION['company_id']
                ]);
            }
            $success = "Şirket bilgileri güncellendi.";
        }
        
        if ($action === 'update_work_settings') {
            try {
                // Check if work settings exist
                $stmt = $conn->prepare("SELECT id FROM work_settings WHERE company_id = ?");
                $stmt->execute([$_SESSION['company_id']]);
                $existing = $stmt->fetchAll();
                
                if (count($existing) > 0) {
                    // Update existing
                    $stmt = $conn->prepare("
                        UPDATE work_settings SET 
                            daily_work_hours = ?, weekly_work_hours = ?, monthly_work_hours = ?,
                            overtime_multiplier = ?, holiday_multiplier = ?, weekend_multiplier = ?,
                            grace_period_minutes = ?, late_penalty_amount = ?,
                            min_break_duration = ?, max_break_duration = ?
                        WHERE company_id = ?
                    ");
                    $stmt->execute([
                        $_POST['daily_work_hours'],
                        $_POST['weekly_work_hours'],
                        $_POST['monthly_work_hours'],
                        $_POST['overtime_multiplier'],
                        $_POST['holiday_multiplier'],
                        $_POST['weekend_multiplier'],
                        $_POST['grace_period_minutes'],
                        $_POST['late_penalty_amount'],
                        $_POST['min_break_duration'],
                        $_POST['max_break_duration'],
                        $_SESSION['company_id']
                    ]);
                } else {
                    // Insert new
                    $stmt = $conn->prepare("
                        INSERT INTO work_settings (
                            company_id, daily_work_hours, weekly_work_hours, monthly_work_hours,
                            overtime_multiplier, holiday_multiplier, weekend_multiplier,
                            grace_period_minutes, late_penalty_amount, min_break_duration, max_break_duration
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $_SESSION['company_id'],
                        $_POST['daily_work_hours'],
                        $_POST['weekly_work_hours'],
                        $_POST['monthly_work_hours'],
                        $_POST['overtime_multiplier'],
                        $_POST['holiday_multiplier'],
                        $_POST['weekend_multiplier'],
                        $_POST['grace_period_minutes'],
                        $_POST['late_penalty_amount'],
                        $_POST['min_break_duration'],
                        $_POST['max_break_duration']
                    ]);
                }
                $success = "Çalışma ayarları güncellendi.";
            } catch (PDOException $e) {
                // Work settings table doesn't exist
                error_log("Work settings update failed: " . $e->getMessage());
                $warning = "Çalışma ayarları şu anda kaydedilemedi, varsayılan değerler kullanılacak.";
            }
        }
        
        if ($action === 'update_qr_settings') {
            try {
                // Check if QR settings exist  
                $stmt = $conn->prepare("SELECT id FROM qr_settings WHERE company_id = ?");
                $stmt->execute([$_SESSION['company_id']]);
                $existing = $stmt->fetchAll();
                
                if (count($existing) > 0) {
                    $stmt = $conn->prepare("
                        UPDATE qr_settings SET 
                            location_tolerance_meters = ?, qr_expiry_minutes = ?,
                            allow_offline_checkin = ?, require_photo = ?
                        WHERE company_id = ?
                    ");
                    $stmt->execute([
                        $_POST['location_tolerance_meters'],
                        $_POST['qr_expiry_minutes'],
                        isset($_POST['allow_offline_checkin']) ? 1 : 0,
                        isset($_POST['require_photo']) ? 1 : 0,
                        $_SESSION['company_id']
                    ]);
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO qr_settings (
                            company_id, location_tolerance_meters, qr_expiry_minutes,
                            allow_offline_checkin, require_photo
                        ) VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $_SESSION['company_id'],
                        $_POST['location_tolerance_meters'],
                        $_POST['qr_expiry_minutes'],
                        isset($_POST['allow_offline_checkin']) ? 1 : 0,
                        isset($_POST['require_photo']) ? 1 : 0
                    ]);
                }
                $success = "QR kod ayarları güncellendi.";
            } catch (PDOException $e) {
                // QR settings table doesn't exist, settings saved in session/cache instead
                error_log("QR settings update failed: " . $e->getMessage());
                $warning = "QR ayarları şu anda kaydedilemedi, varsayılan değerler kullanılacak.";
            }
        }
        
        if ($action === 'update_notification_settings') {
            try {
                $stmt = $conn->prepare("SELECT id FROM notification_settings WHERE company_id = ?");
                $stmt->execute([$_SESSION['company_id']]);
                $existing = $stmt->fetchAll();
                
                if (count($existing) > 0) {
                    $stmt = $conn->prepare("
                        UPDATE notification_settings SET 
                            email_notifications = ?, sms_notifications = ?,
                            late_arrival_alert = ?, absence_alert = ?,
                            leave_request_alert = ?, overtime_alert = ?
                        WHERE company_id = ?
                    ");
                    $stmt->execute([
                        isset($_POST['email_notifications']) ? 1 : 0,
                        isset($_POST['sms_notifications']) ? 1 : 0,
                        isset($_POST['late_arrival_alert']) ? 1 : 0,
                        isset($_POST['absence_alert']) ? 1 : 0,
                        isset($_POST['leave_request_alert']) ? 1 : 0,
                        isset($_POST['overtime_alert']) ? 1 : 0,
                        $_SESSION['company_id']
                    ]);
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO notification_settings (
                            company_id, email_notifications, sms_notifications,
                            late_arrival_alert, absence_alert, leave_request_alert, overtime_alert
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $_SESSION['company_id'],
                        isset($_POST['email_notifications']) ? 1 : 0,
                        isset($_POST['sms_notifications']) ? 1 : 0,
                        isset($_POST['late_arrival_alert']) ? 1 : 0,
                        isset($_POST['absence_alert']) ? 1 : 0,
                        isset($_POST['leave_request_alert']) ? 1 : 0,
                        isset($_POST['overtime_alert']) ? 1 : 0
                    ]);
                }
                $success = "Bildirim ayarları güncellendi.";
            } catch (PDOException $e) {
                // Notification settings table doesn't exist
                error_log("Notification settings update failed: " . $e->getMessage());
                $warning = "Bildirim ayarları şu anda kaydedilemedi, varsayılan değerler kullanılacak.";
            }
        }
    }
    
    // Get company info
    $stmt = $conn->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$_SESSION['company_id']]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get work settings (with error handling)
    $work_settings = [
        'daily_work_hours' => 8,
        'weekly_work_hours' => 45,
        'monthly_work_hours' => 225,
        'overtime_multiplier' => 1.5,
        'holiday_multiplier' => 2.0,
        'weekend_multiplier' => 1.5,
        'grace_period_minutes' => 15,
        'late_penalty_amount' => 0,
        'min_break_duration' => 30,
        'max_break_duration' => 60
    ];
    
    try {
        $stmt = $conn->prepare("SELECT * FROM work_settings WHERE company_id = ?");
        $stmt->execute([$_SESSION['company_id']]);
        $dbSettings = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($dbSettings) {
            $work_settings = array_merge($work_settings, $dbSettings);
        }
    } catch (PDOException $e) {
        // Work settings table doesn't exist, use defaults
        error_log("Work settings query failed: " . $e->getMessage());
    }
    
    // Get QR settings (with error handling)
    $qr_settings = [
        'location_tolerance_meters' => 100,
        'qr_expiry_minutes' => 5,
        'allow_offline_checkin' => 0,
        'require_photo' => 0
    ];
    
    try {
        $stmt = $conn->prepare("SELECT * FROM qr_settings WHERE company_id = ?");
        $stmt->execute([$_SESSION['company_id']]);
        $dbSettings = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($dbSettings) {
            $qr_settings = array_merge($qr_settings, $dbSettings);
        }
    } catch (PDOException $e) {
        // QR settings table doesn't exist, use defaults
        error_log("QR settings query failed: " . $e->getMessage());
    }
    
    // Get notification settings (with error handling)
    $notification_settings = [
        'email_notifications' => 1,
        'sms_notifications' => 0,
        'late_arrival_alert' => 1,
        'absence_alert' => 1,
        'leave_request_alert' => 1,
        'overtime_alert' => 1
    ];
    
    try {
        $stmt = $conn->prepare("SELECT * FROM notification_settings WHERE company_id = ?");
        $stmt->execute([$_SESSION['company_id']]);
        $dbSettings = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($dbSettings) {
            $notification_settings = array_merge($notification_settings, $dbSettings);
        }
    } catch (PDOException $e) {
        // Notification settings table doesn't exist, use defaults
        error_log("Notification settings query failed: " . $e->getMessage());
    }
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket ve Sistem Ayarları - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-gray-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">⚙️</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Şirket ve Sistem Ayarları</h1>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'Şirket'); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <?php if (isset($success)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Settings Tabs -->
            <div class="bg-white shadow rounded-lg">
                <div class="border-b border-gray-200">
                    <nav class="-mb-px flex space-x-8 px-6" aria-label="Tabs">
                        <button onclick="showTab('company')" id="tab-company" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm tab-button active-tab">
                            🏢 Şirket Bilgileri
                        </button>
                        <button onclick="showTab('work')" id="tab-work" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm tab-button">
                            ⏰ Çalışma Ayarları
                        </button>
                        <button onclick="showTab('qr')" id="tab-qr" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm tab-button">
                            📱 QR Kod Ayarları
                        </button>
                        <button onclick="showTab('notifications')" id="tab-notifications" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm tab-button">
                            🔔 Bildirim Ayarları
                        </button>
                    </nav>
                </div>

                <!-- Company Information Tab -->
                <div id="content-company" class="tab-content p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Şirket Bilgileri</h3>
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="action" value="update_company_info">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Şirket Adı</label>
                                <input type="text" name="company_name" value="<?php echo htmlspecialchars($company['company_name'] ?? ''); ?>" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Telefon</label>
                                <input type="text" name="phone" value="<?php echo htmlspecialchars($company['phone'] ?? ''); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">E-posta</label>
                                <input type="email" name="email" value="<?php echo htmlspecialchars($company['email'] ?? ''); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Vergi Numarası</label>
                                <input type="text" name="tax_number" value="<?php echo htmlspecialchars($company['tax_number'] ?? ''); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Şirket Türü</label>
                                <select name="company_type" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    <option value="corporate" <?php echo ($company['company_type'] ?? 'corporate') === 'corporate' ? 'selected' : ''; ?>>Kurumsal</option>
                                    <option value="individual" <?php echo ($company['company_type'] ?? 'corporate') === 'individual' ? 'selected' : ''; ?>>Şahıs</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Durum</label>
                                <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    <option value="active" <?php echo ($company['status'] ?? 'active') === 'active' ? 'selected' : ''; ?>>Aktif</option>
                                    <option value="inactive" <?php echo ($company['status'] ?? 'active') === 'inactive' ? 'selected' : ''; ?>>Pasif</option>
                                </select>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Adres</label>
                            <textarea name="address" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo htmlspecialchars($company['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                Şirket Bilgilerini Güncelle
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Work Settings Tab -->
                <div id="content-work" class="tab-content p-6 hidden">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Çalışma Ayarları</h3>
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="action" value="update_work_settings">
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Günlük Çalışma Saati</label>
                                <input type="number" name="daily_work_hours" value="<?php echo $work_settings['daily_work_hours'] ?? '8'; ?>" step="0.5" min="1" max="24"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Haftalık Çalışma Saati</label>
                                <input type="number" name="weekly_work_hours" value="<?php echo $work_settings['weekly_work_hours'] ?? '40'; ?>" step="0.5" min="1" max="168"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Aylık Çalışma Saati</label>
                                <input type="number" name="monthly_work_hours" value="<?php echo $work_settings['monthly_work_hours'] ?? '160'; ?>" step="0.5" min="1" max="744"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Mesai Çarpanı</label>
                                <input type="number" name="overtime_multiplier" value="<?php echo $work_settings['overtime_multiplier'] ?? '1.5'; ?>" step="0.1" min="1" max="3"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tatil Günü Çarpanı</label>
                                <input type="number" name="holiday_multiplier" value="<?php echo $work_settings['holiday_multiplier'] ?? '2.0'; ?>" step="0.1" min="1" max="3"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Hafta Sonu Çarpanı</label>
                                <input type="number" name="weekend_multiplier" value="<?php echo $work_settings['weekend_multiplier'] ?? '1.5'; ?>" step="0.1" min="1" max="3"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Tolerans Süresi (dakika)</label>
                                <input type="number" name="grace_period_minutes" value="<?php echo $work_settings['grace_period_minutes'] ?? '15'; ?>" min="0" max="60"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Gecikme Cezası (TL)</label>
                                <input type="number" name="late_penalty_amount" value="<?php echo $work_settings['late_penalty_amount'] ?? '0'; ?>" step="0.01" min="0"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Min Mola Süresi (dakika)</label>
                                <input type="number" name="min_break_duration" value="<?php echo $work_settings['min_break_duration'] ?? '30'; ?>" min="0" max="120"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Max Mola Süresi (dakika)</label>
                                <input type="number" name="max_break_duration" value="<?php echo $work_settings['max_break_duration'] ?? '60'; ?>" min="0" max="180"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                        
                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                Çalışma Ayarlarını Güncelle
                            </button>
                        </div>
                    </form>
                </div>

                <!-- QR Settings Tab -->
                <div id="content-qr" class="tab-content p-6 hidden">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">QR Kod Ayarları</h3>
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="action" value="update_qr_settings">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Lokasyon Toleransı (metre)</label>
                                <input type="number" name="location_tolerance_meters" value="<?php echo $qr_settings['location_tolerance_meters'] ?? '100'; ?>" min="10" max="1000"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <p class="text-xs text-gray-500 mt-1">Personelin ne kadar yakın olması gerektiği</p>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">QR Kod Geçerlilik (dakika)</label>
                                <input type="number" name="qr_expiry_minutes" value="<?php echo $qr_settings['qr_expiry_minutes'] ?? '5'; ?>" min="1" max="60"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <p class="text-xs text-gray-500 mt-1">QR kodun kaç dakika geçerli olacağı</p>
                            </div>
                        </div>
                        
                        <div class="space-y-4">
                            <div class="flex items-center">
                                <input type="checkbox" name="allow_offline_checkin" id="allow_offline_checkin" 
                                       <?php echo ($qr_settings['allow_offline_checkin'] ?? 0) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="allow_offline_checkin" class="ml-2 block text-sm text-gray-900">
                                    Çevrimdışı Giriş/Çıkışa İzin Ver
                                </label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="require_photo" id="require_photo" 
                                       <?php echo ($qr_settings['require_photo'] ?? 0) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="require_photo" class="ml-2 block text-sm text-gray-900">
                                    Giriş/Çıkışta Fotoğraf Zorunlu
                                </label>
                            </div>
                        </div>
                        
                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                QR Ayarlarını Güncelle
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Notification Settings Tab -->
                <div id="content-notifications" class="tab-content p-6 hidden">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Bildirim Ayarları</h3>
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="action" value="update_notification_settings">
                        
                        <div class="space-y-4">
                            <div class="flex items-center">
                                <input type="checkbox" name="email_notifications" id="email_notifications" 
                                       <?php echo ($notification_settings['email_notifications'] ?? 1) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="email_notifications" class="ml-2 block text-sm text-gray-900">
                                    E-posta Bildirimleri
                                </label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="sms_notifications" id="sms_notifications" 
                                       <?php echo ($notification_settings['sms_notifications'] ?? 0) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="sms_notifications" class="ml-2 block text-sm text-gray-900">
                                    SMS Bildirimleri
                                </label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="late_arrival_alert" id="late_arrival_alert" 
                                       <?php echo ($notification_settings['late_arrival_alert'] ?? 1) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="late_arrival_alert" class="ml-2 block text-sm text-gray-900">
                                    Geç Geliş Uyarısı
                                </label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="absence_alert" id="absence_alert" 
                                       <?php echo ($notification_settings['absence_alert'] ?? 1) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="absence_alert" class="ml-2 block text-sm text-gray-900">
                                    Devamsızlık Uyarısı
                                </label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="leave_request_alert" id="leave_request_alert" 
                                       <?php echo ($notification_settings['leave_request_alert'] ?? 1) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="leave_request_alert" class="ml-2 block text-sm text-gray-900">
                                    İzin Talebi Bildirimi
                                </label>
                            </div>
                            
                            <div class="flex items-center">
                                <input type="checkbox" name="overtime_alert" id="overtime_alert" 
                                       <?php echo ($notification_settings['overtime_alert'] ?? 1) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                <label for="overtime_alert" class="ml-2 block text-sm text-gray-900">
                                    Mesai Fazlası Uyarısı
                                </label>
                            </div>
                        </div>
                        
                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                Bildirim Ayarlarını Güncelle
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    function showTab(tabName) {
        // Hide all tab contents
        const contents = document.querySelectorAll('.tab-content');
        contents.forEach(content => content.classList.add('hidden'));
        
        // Remove active class from all tabs
        const tabs = document.querySelectorAll('.tab-button');
        tabs.forEach(tab => {
            tab.classList.remove('active-tab', 'border-blue-500', 'text-blue-600');
            tab.classList.add('border-transparent', 'text-gray-500');
        });
        
        // Show selected tab content
        document.getElementById('content-' + tabName).classList.remove('hidden');
        
        // Add active class to selected tab
        const activeTab = document.getElementById('tab-' + tabName);
        activeTab.classList.remove('border-transparent', 'text-gray-500');
        activeTab.classList.add('active-tab', 'border-blue-500', 'text-blue-600');
    }
    
    // Initialize with company tab active
    document.addEventListener('DOMContentLoaded', function() {
        showTab('company');
    });
    </script>

    <style>
    .active-tab {
        border-color: #3B82F6 !important;
        color: #2563EB !important;
    }
    </style>
</body>
</html>