<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../includes/config.php';
require_once '../includes/database.php';

if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$success = '';
$error = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['action'])) {
            
            if ($_POST['action'] === 'create_location') {
                $name = trim($_POST['name']);
                $location_type = $_POST['location_type'];
                $description = trim($_POST['description'] ?? '');
                $latitude = floatval($_POST['latitude']);
                $longitude = floatval($_POST['longitude']);
                $address = trim($_POST['address'] ?? '');
                
                if (empty($name)) {
                    throw new Exception('Lokasyon adı zorunludur.');
                }
                
                if ($latitude < -90 || $latitude > 90) {
                    throw new Exception('Geçersiz enlem değeri (-90 ile 90 arası olmalı).');
                }
                
                if ($longitude < -180 || $longitude > 180) {
                    throw new Exception('Geçersiz boylam değeri (-180 ile 180 arası olmalı).');
                }
                
                do {
                    $qr_code = 'QR_' . strtoupper(uniqid()) . '_' . date('Ymd') . '_' . sprintf('%04d', mt_rand(1, 9999));
                    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM qr_locations WHERE qr_code = ?");
                    $checkStmt->execute([$qr_code]);
                } while ($checkStmt->fetchColumn() > 0);
                
                $insertStmt = $conn->prepare("
                    INSERT INTO qr_locations (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
                ");
                
                if ($insertStmt->execute([$_SESSION['company_id'], $name, $qr_code, $location_type, $description, $latitude, $longitude, $address])) {
                    $success = "QR lokasyon başarıyla oluşturuldu: {$name} ({$qr_code})";
                } else {
                    throw new Exception('Lokasyon oluşturulurken hata oluştu.');
                }
                
            } elseif ($_POST['action'] === 'delete_location') {
                $location_id = intval($_POST['location_id']);
                
                $deleteStmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
                if ($deleteStmt->execute([$location_id, $_SESSION['company_id']])) {
                    $success = "Lokasyon başarıyla silindi.";
                } else {
                    throw new Exception('Lokasyon silinemedi.');
                }
            }
        }
    }
    
    $locationsStmt = $conn->prepare("
        SELECT * FROM qr_locations 
        WHERE company_id = ? 
        ORDER BY created_at DESC
    ");
    $locationsStmt->execute([$_SESSION['company_id']]);
    $locations = $locationsStmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Lokasyon Üretici - SZB İK Takip</title>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        .header { text-align: center; margin-bottom: 30px; }
        .alert { padding: 15px; margin: 10px 0; border-radius: 5px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .form-section { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px; }
        .form-group { display: flex; flex-direction: column; }
        .form-group label { font-weight: bold; margin-bottom: 5px; }
        .form-group input, .form-group select, .form-group textarea { 
            padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; 
        }
        .btn { padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .locations-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .location-card { background: white; border: 1px solid #ddd; border-radius: 8px; padding: 20px; }
        .qr-container { text-align: center; margin: 15px 0; }
        .qr-canvas { border: 1px solid #ddd; border-radius: 5px; }
        .action-buttons { text-align: center; margin-top: 15px; }
        @media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>QR Lokasyon Üretici</h1>
            <p>GPS koordinatlı QR kodlar oluşturun ve yönetin</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- Create New Location Form -->
        <div class="form-section">
            <h3>Yeni QR Lokasyon Oluştur</h3>
            <form method="POST">
                <input type="hidden" name="action" value="create_location">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Lokasyon Adı *</label>
                        <input type="text" name="name" required placeholder="Örn: Ana Giriş Kapısı">
                    </div>
                    
                    <div class="form-group">
                        <label>Lokasyon Türü</label>
                        <select name="location_type">
                            <option value="entrance">Giriş Kapısı</option>
                            <option value="exit">Çıkış Kapısı</option>
                            <option value="office">Ofis/Çalışma Alanı</option>
                            <option value="cafeteria">Kafeterya/Yemekhane</option>
                            <option value="meeting_room">Toplantı Odası</option>
                            <option value="break_area">Mola Alanı</option>
                            <option value="warehouse">Depo/Ambar</option>
                            <option value="parking">Otopark</option>
                            <option value="other">Diğer</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Enlem (Latitude) *</label>
                        <input type="number" id="latitude" name="latitude" step="0.000001" min="-90" max="90" required placeholder="41.0082">
                        <div style="margin-top: 10px;">
                            <button type="button" class="btn btn-success" onclick="getCurrentLocation()">Mevcut Konum Al</button>
                            <button type="button" class="btn btn-secondary" onclick="setIstanbul()">İstanbul</button>
                            <button type="button" class="btn btn-secondary" onclick="setAnkara()">Ankara</button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Boylam (Longitude) *</label>
                        <input type="number" id="longitude" name="longitude" step="0.000001" min="-180" max="180" required placeholder="28.9784">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <input type="text" id="address" name="address" placeholder="Tam adres bilgisi">
                </div>
                
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" rows="3" placeholder="Lokasyon hakkında ek bilgiler"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">QR Lokasyon Oluştur</button>
            </form>
        </div>
        
        <!-- Existing Locations -->
        <?php if (!empty($locations)): ?>
            <div class="form-section">
                <h3>Mevcut QR Lokasyonları (<?= count($locations) ?>)</h3>
                <div class="locations-grid">
                    <?php foreach ($locations as $location): ?>
                        <div class="location-card">
                            <h4><?= htmlspecialchars($location['name']) ?></h4>
                            <p><strong>Tür:</strong> <?= htmlspecialchars($location['location_type']) ?></p>
                            <p><strong>QR Kod:</strong> <?= htmlspecialchars($location['qr_code']) ?></p>
                            
                            <?php if ($location['latitude'] && $location['longitude']): ?>
                                <p><strong>Koordinatlar:</strong> <?= $location['latitude'] ?>, <?= $location['longitude'] ?></p>
                            <?php endif; ?>
                            
                            <div class="qr-container">
                                <canvas id="qr_<?= $location['id'] ?>" class="qr-canvas"></canvas>
                            </div>
                            
                            <div class="action-buttons">
                                <button class="btn btn-success" onclick="downloadQR(<?= $location['id'] ?>)">İndir</button>
                                <button class="btn btn-secondary" onclick="printQR(<?= $location['id'] ?>)">Yazdır</button>
                                <button class="btn btn-danger" onclick="deleteLocation(<?= $location['id'] ?>, '<?= htmlspecialchars($location['name']) ?>')">Sil</button>
                            </div>
                            
                            <?php if ($location['description']): ?>
                                <p style="margin-top: 10px; font-style: italic;"><?= htmlspecialchars($location['description']) ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        console.log('QR Generator Loading...');
        
        // GPS location function
        function getCurrentLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        document.getElementById('latitude').value = position.coords.latitude.toFixed(8);
                        document.getElementById('longitude').value = position.coords.longitude.toFixed(8);
                        alert('GPS konumu alındı!');
                    },
                    function(error) {
                        alert('GPS konumu alınamadı: ' + error.message);
                    }
                );
            } else {
                alert('Tarayıcınız GPS desteklemiyor.');
            }
        }
        
        function setIstanbul() {
            document.getElementById('latitude').value = '41.0082';
            document.getElementById('longitude').value = '28.9784';
            document.getElementById('address').value = 'İstanbul, Türkiye';
        }
        
        function setAnkara() {
            document.getElementById('latitude').value = '39.9334';
            document.getElementById('longitude').value = '32.8597';
            document.getElementById('address').value = 'Ankara, Türkiye';
        }
        
        function downloadQR(locationId) {
            var canvas = document.getElementById('qr_' + locationId);
            if (canvas) {
                var link = document.createElement('a');
                link.download = 'QR_Location_' + locationId + '.png';
                link.href = canvas.toDataURL();
                link.click();
            }
        }
        
        function printQR(locationId) {
            var canvas = document.getElementById('qr_' + locationId);
            if (canvas) {
                var printWindow = window.open('', '_blank');
                var dataURL = canvas.toDataURL();
                printWindow.document.write('<html><head><title>QR Kod</title></head><body style="text-align:center;"><img src="' + dataURL + '" style="max-width:100%;"><br><br><button onclick="window.print()">Yazdır</button></body></html>');
                printWindow.document.close();
            }
        }
        
        function deleteLocation(locationId, locationName) {
            if (confirm('Bu lokasyonu silmek istediğinizden emin misiniz?\n\n' + locationName)) {
                var form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = '<input type="hidden" name="action" value="delete_location"><input type="hidden" name="location_id" value="' + locationId + '">';
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Generate QR codes after page loads
        window.addEventListener('load', function() {
            if (typeof QRCode === 'undefined') {
                console.error('QRCode library not loaded');
                return;
            }
            
            setTimeout(function() {
                console.log('Generating QR codes...');
                
                <?php foreach ($locations as $location): ?>
                var canvas<?= $location['id'] ?> = document.getElementById('qr_<?= $location['id'] ?>');
                if (canvas<?= $location['id'] ?>) {
                    var qrData<?= $location['id'] ?> = {
                        qr_code: "<?= $location['qr_code'] ?>",
                        location_id: <?= $location['id'] ?>,
                        name: "<?= addslashes($location['name']) ?>",
                        location_type: "<?= $location['location_type'] ?>",
                        coordinates: {
                            latitude: <?= $location['latitude'] ?? 'null' ?>,
                            longitude: <?= $location['longitude'] ?? 'null' ?>
                        },
                        company_id: <?= $_SESSION['company_id'] ?>,
                        validation_radius: 100
                    };
                    
                    QRCode.toCanvas(canvas<?= $location['id'] ?>, JSON.stringify(qrData<?= $location['id'] ?>), {
                        width: 200,
                        height: 200,
                        colorDark: '#000000',
                        colorLight: '#FFFFFF',
                        correctLevel: QRCode.CorrectLevel.M
                    }, function(error) {
                        if (error) {
                            console.error('QR Error for <?= $location['id'] ?>:', error);
                        } else {
                            console.log('QR Generated for <?= $location['id'] ?>');
                        }
                    });
                }
                <?php endforeach; ?>
                
            }, 1000);
        });
        
        console.log('QR Generator Ready');
    </script>
</body>
</html>