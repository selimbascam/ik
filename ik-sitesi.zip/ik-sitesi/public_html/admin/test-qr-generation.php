<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['company_id'])) {
    die("Yetkilendirme hatası");
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>QR Kod Test</title>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
        }
        .test-section {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        canvas {
            border: 2px solid #333;
            margin: 10px;
        }
        .success { color: green; }
        .error { color: red; }
        .info { color: blue; }
    </style>
</head>
<body>
    <div class="container">
        <h1>QR Kod Kütüphane Testi</h1>
        
        <div class="test-section">
            <h2>Test 1: Basit QR Kod</h2>
            <canvas id="test1" width="200" height="200"></canvas>
            <div id="result1"></div>
        </div>
        
        <div class="test-section">
            <h2>Test 2: Alternatif Yöntem</h2>
            <div id="qrcode2"></div>
            <div id="result2"></div>
        </div>
        
        <div class="test-section">
            <h2>Test 3: API ile QR Kod</h2>
            <img id="qrapi" src="" alt="QR Code">
            <div id="result3"></div>
        </div>
        
        <script>
            // Test 1: Canvas QR Code
            document.addEventListener('DOMContentLoaded', function() {
                const testData = 'QR_TEST_12345';
                
                // Test 1
                try {
                    if (typeof QRCode !== 'undefined' && QRCode.toCanvas) {
                        const canvas = document.getElementById('test1');
                        QRCode.toCanvas(canvas, testData, {
                            width: 200,
                            height: 200,
                            margin: 2
                        }, function(error) {
                            if (error) {
                                document.getElementById('result1').innerHTML = '<span class="error">Hata: ' + error + '</span>';
                            } else {
                                document.getElementById('result1').innerHTML = '<span class="success">✓ QRCode.toCanvas başarılı!</span>';
                            }
                        });
                    } else {
                        document.getElementById('result1').innerHTML = '<span class="error">QRCode kütüphanesi yüklenmedi!</span>';
                    }
                } catch (e) {
                    document.getElementById('result1').innerHTML = '<span class="error">Exception: ' + e + '</span>';
                }
                
                // Test 2: QRCode.js library (if available)
                try {
                    if (typeof QRCode !== 'undefined' && typeof QRCode === 'function') {
                        new QRCode(document.getElementById("qrcode2"), {
                            text: testData,
                            width: 200,
                            height: 200
                        });
                        document.getElementById('result2').innerHTML = '<span class="success">✓ QRCode.js başarılı!</span>';
                    } else {
                        document.getElementById('result2').innerHTML = '<span class="info">QRCode.js mevcut değil</span>';
                    }
                } catch (e) {
                    document.getElementById('result2').innerHTML = '<span class="error">Exception: ' + e + '</span>';
                }
                
                // Test 3: External API
                try {
                    const apiUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent(testData);
                    document.getElementById('qrapi').src = apiUrl;
                    document.getElementById('result3').innerHTML = '<span class="success">✓ API QR kodu yüklendi!</span>';
                } catch (e) {
                    document.getElementById('result3').innerHTML = '<span class="error">Exception: ' + e + '</span>';
                }
            });
        </script>
        
        <div style="margin-top: 30px;">
            <a href="qr-generator.php" style="padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;">← QR Generator'a Dön</a>
        </div>
    </div>
</body>
</html>