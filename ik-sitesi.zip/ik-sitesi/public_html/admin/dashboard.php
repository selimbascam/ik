<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['company_id']) && !isset($_SESSION['user_type'])) {
    header('Location: ../auth/company-login-fixed.php');
    exit;
}

$companyId = $_SESSION['company_id'] ?? null;
$companyName = $_SESSION['company_name'] ?? 'Şirket';
$adminEmail = $_SESSION['admin_email'] ?? '';

// Get basic company stats
$totalEmployees = 0;
$todayAttendance = 0;

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get table names
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $employeesTable = in_array('çalışanlar', $tables) ? 'çalışanlar' : 
                     (in_array('employees', $tables) ? 'employees' : null);
    
    if ($employeesTable && $companyId) {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM `$employeesTable` WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $totalEmployees = $result['count'] ?? 0;
    }
} catch (Exception $e) {
    // Silent fail for now
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                        <span class="text-white font-bold">S</span>
                    </div>
                    <div>
                        <h1 class="text-xl font-semibold text-gray-900"><?php echo APP_NAME; ?></h1>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($companyName); ?></p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600"><?php echo htmlspecialchars($adminEmail); ?></span>
                    <a href="../auth/logout.php" class="text-red-600 hover:text-red-800 text-sm">Çıkış</a>
                </div>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Welcome Message -->
        <div class="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 mb-8 text-white">
            <h2 class="text-2xl font-bold mb-2">Hoş Geldiniz!</h2>
            <p class="text-blue-100">İK yönetim panelinize başarıyla giriş yaptınız.</p>
        </div>

        <!-- Quick Stats -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg p-6 shadow-sm">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span class="text-blue-600 text-xl">👥</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Toplam Personel</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo $totalEmployees; ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg p-6 shadow-sm">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <span class="text-green-600 text-xl">✅</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Bugün Katılım</p>
                        <p class="text-2xl font-bold text-gray-900"><?php echo $todayAttendance; ?></p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg p-6 shadow-sm">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <span class="text-yellow-600 text-xl">📋</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">QR Konumları</p>
                        <p class="text-2xl font-bold text-gray-900">-</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg p-6 shadow-sm">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span class="text-purple-600 text-xl">⏰</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Aktif Vardiyalar</p>
                        <p class="text-2xl font-bold text-gray-900">-</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Menu Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Employee Management -->
            <div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span class="text-blue-600 text-xl">👥</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 ml-3">Personel Yönetimi</h3>
                </div>
                <p class="text-gray-600 mb-4">Çalışan bilgileri, profilleri ve dokümantasyon yönetimi</p>
                <div class="space-y-2">
                    <a href="employee-management.php" class="block text-blue-600 hover:text-blue-800">• Personel Listesi</a>
                    <a href="company-user-management.php" class="block text-blue-600 hover:text-blue-800">• Kullanıcı Yönetimi</a>
                    <a href="user-password-management.php" class="block text-blue-600 hover:text-blue-800">• Şifre Yönetimi</a>
                </div>
            </div>

            <!-- Attendance System -->
            <div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <span class="text-green-600 text-xl">📊</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 ml-3">Devam Takibi</h3>
                </div>
                <p class="text-gray-600 mb-4">QR kod tabanlı devam takibi ve raporlama</p>
                <div class="space-y-2">
                    <a href="attendance-tracking.php" class="block text-blue-600 hover:text-blue-800">• Devam Kayıtları</a>
                    <a href="employee-attendance-list.php" class="block text-blue-600 hover:text-blue-800">• Personel Devamı</a>
                    <a href="reports.php" class="block text-blue-600 hover:text-blue-800">• Raporlar</a>
                </div>
            </div>

            <!-- QR System -->
            <div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span class="text-purple-600 text-xl">📱</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 ml-3">QR Kod Sistemi</h3>
                </div>
                <p class="text-gray-600 mb-4">QR kod üretimi ve konum yönetimi</p>
                <div class="space-y-2">
                    <a href="qr-generator.php" class="block text-blue-600 hover:text-blue-800">• QR Kod Üretici</a>
                    <a href="qr-system-status.php" class="block text-blue-600 hover:text-blue-800">• Sistem Durumu</a>
                    <a href="qr-debug.php" class="block text-blue-600 hover:text-blue-800">• QR Debug</a>
                </div>
            </div>

            <!-- Shift Management -->
            <div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <span class="text-yellow-600 text-xl">⏰</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 ml-3">Vardiya Yönetimi</h3>
                </div>
                <p class="text-gray-600 mb-4">Çalışma saatleri ve vardiya planlaması</p>
                <div class="space-y-2">
                    <a href="shift-management.php" class="block text-blue-600 hover:text-blue-800">• Vardiya Planı</a>
                    <a href="work-settings.php" class="block text-blue-600 hover:text-blue-800">• Çalışma Ayarları</a>
                    <a href="holiday-management.php" class="block text-blue-600 hover:text-blue-800">• Tatil Yönetimi</a>
                </div>
            </div>

            <!-- Settings -->
            <div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                        <span class="text-gray-600 text-xl">⚙️</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 ml-3">Sistem Ayarları</h3>
                </div>
                <p class="text-gray-600 mb-4">Şirket bilgileri ve sistem yapılandırması</p>
                <div class="space-y-2">
                    <a href="company-settings.php" class="block text-blue-600 hover:text-blue-800">• Şirket Ayarları</a>
                    <a href="device-management.php" class="block text-blue-600 hover:text-blue-800">• Cihaz Yönetimi</a>
                    <a href="learning-recommendations.php" class="block text-blue-600 hover:text-blue-800">• Öğrenme Önerileri</a>
                </div>
            </div>

            <!-- System Tools -->
            <div class="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                        <span class="text-red-600 text-xl">🔧</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 ml-3">Sistem Araçları</h3>
                </div>
                <p class="text-gray-600 mb-4">Debug araçları ve sistem bakımı</p>
                <div class="space-y-2">
                    <a href="../super-admin/index.php" class="block text-blue-600 hover:text-blue-800">• Süper Admin</a>
                    <a href="../final-system-test.php" class="block text-blue-600 hover:text-blue-800">• Sistem Testi</a>
                    <a href="../test-connection.php" class="block text-blue-600 hover:text-blue-800">• Bağlantı Testi</a>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="mt-12 text-center text-gray-500 text-sm">
            <p>© 2025 <?php echo APP_NAME; ?> - İnsan Kaynakları Yönetim Sistemi</p>
            <p class="mt-2">
                <a href="../index.php" class="text-blue-600 hover:text-blue-800">Ana Sayfa</a> |
                <a href="../turkish-table-login-test.php" class="text-blue-600 hover:text-blue-800">Sistem Durumu</a>
            </p>
        </div>
    </div>
</body>
</html>