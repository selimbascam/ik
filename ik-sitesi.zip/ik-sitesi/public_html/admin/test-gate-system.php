<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin authentication
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

$message = '';
$messageType = '';
$employees = [];
$qrLocations = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle reset action
    if (isset($_POST['action']) && $_POST['action'] === 'reset_employee') {
        $employeeId = intval($_POST['employee_id']);
        $today = date('Y-m-d');
        
        // Delete today's attendance record to allow fresh testing
        $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
        $stmt->execute([$employeeId, $today]);
        
        $message = "✅ Personel kaydı sıfırlandı. Şimdi yeniden test edebilirsiniz.";
        $messageType = 'success';
    }
    
    // Get company employees
    $companyId = $_SESSION['company_id'] ?? 1;
    $stmt = $conn->prepare("
        SELECT e.id, e.first_name, e.last_name, 
               ar.check_in, ar.break_start, ar.break_end, ar.check_out
        FROM employees e
        LEFT JOIN attendance_records ar ON e.id = ar.employee_id AND ar.date = CURDATE()
        WHERE e.company_id = ?
        ORDER BY e.first_name, e.last_name
    ");
    $stmt->execute([$companyId]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get QR locations
    $stmt = $conn->prepare("
        SELECT id, name, location_type, gate_behavior 
        FROM qr_locations 
        WHERE company_id = ? 
        ORDER BY location_type, name
    ");
    $stmt->execute([$companyId]);
    $qrLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $message = "❌ Hata: " . $e->getMessage();
    $messageType = 'error';
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapı Sistemi Test - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">🧪</span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Kapı Sistemi Test Paneli</h1>
            <p class="text-gray-600 mt-2">QR kapı sistemi test ve kontrol</p>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                    'bg-red-100 text-red-800 border border-red-200'; 
            ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- QR Locations -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">📍 QR Lokasyonları</h2>
            <div class="grid gap-3">
                <?php 
                $gateLabels = [
                    'entrance_gate' => ['icon' => '🟢', 'text' => 'Giriş Kapısı'],
                    'exit_gate' => ['icon' => '🔴', 'text' => 'Çıkış Kapısı'],
                    'break_gate' => ['icon' => '🟡', 'text' => 'Mola Kapısı'],
                    'general_gate' => ['icon' => '🔵', 'text' => 'Genel Kapı']
                ];
                
                $behaviorLabels = [
                    'work_start' => 'İşe Başlama',
                    'work_end' => 'İşten Çıkış',
                    'break_toggle' => 'Mola Aç/Kapa',
                    'user_choice' => 'Kullanıcı Seçimi'
                ];
                
                if (!empty($qrLocations)):
                    foreach ($qrLocations as $location):
                        $gateInfo = $gateLabels[$location['location_type']] ?? ['icon' => '⚪', 'text' => 'Belirsiz'];
                        $behaviorText = $behaviorLabels[$location['gate_behavior']] ?? 'Belirsiz';
                    ?>
                        <div class="border rounded-lg p-3 flex items-center justify-between">
                            <div>
                                <span class="text-2xl mr-2"><?php echo $gateInfo['icon']; ?></span>
                                <strong><?php echo htmlspecialchars($location['name']); ?></strong>
                                <span class="text-gray-600 ml-2">(<?php echo $gateInfo['text']; ?>)</span>
                            </div>
                            <div class="text-sm text-gray-500">
                                Davranış: <strong><?php echo $behaviorText; ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center text-gray-500 py-4">
                        Henüz QR lokasyonu tanımlanmamış.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Employee Status -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">👥 Personel Durumu</h2>
            <div class="overflow-x-auto">
                <table class="w-full border-collapse">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="border p-2 text-left">Personel</th>
                            <th class="border p-2 text-center">Giriş</th>
                            <th class="border p-2 text-center">Mola Başla</th>
                            <th class="border p-2 text-center">Mola Bitir</th>
                            <th class="border p-2 text-center">Çıkış</th>
                            <th class="border p-2 text-center">Durum</th>
                            <th class="border p-2 text-center">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($employees)): ?>
                        <?php foreach ($employees as $employee): ?>
                            <tr>
                                <td class="border p-2">
                                    <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                </td>
                                <td class="border p-2 text-center">
                                    <?php echo $employee['check_in'] ? '✅ ' . date('H:i', strtotime($employee['check_in'])) : '❌'; ?>
                                </td>
                                <td class="border p-2 text-center">
                                    <?php echo $employee['break_start'] ? '✅ ' . date('H:i', strtotime($employee['break_start'])) : '❌'; ?>
                                </td>
                                <td class="border p-2 text-center">
                                    <?php echo $employee['break_end'] ? '✅ ' . date('H:i', strtotime($employee['break_end'])) : '❌'; ?>
                                </td>
                                <td class="border p-2 text-center">
                                    <?php echo $employee['check_out'] ? '✅ ' . date('H:i', strtotime($employee['check_out'])) : '❌'; ?>
                                </td>
                                <td class="border p-2 text-center">
                                    <?php 
                                    if (!$employee['check_in']) {
                                        echo '<span class="text-gray-500">Gelmedi</span>';
                                    } elseif ($employee['check_out']) {
                                        echo '<span class="text-red-600">Çıkış Yaptı</span>';
                                    } elseif ($employee['break_start'] && !$employee['break_end']) {
                                        echo '<span class="text-yellow-600">Molada</span>';
                                    } else {
                                        echo '<span class="text-green-600">Çalışıyor</span>';
                                    }
                                    ?>
                                </td>
                                <td class="border p-2 text-center">
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="reset_employee">
                                        <input type="hidden" name="employee_id" value="<?php echo $employee['id']; ?>">
                                        <button type="submit" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 text-xs">
                                            🔄 Temiz Başlangıç
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="border p-4 text-center text-gray-500">
                                Henüz personel kaydı bulunmamaktadır.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Info Box -->
        <div class="bg-blue-100 border border-blue-300 rounded-lg p-4 mt-6">
            <h3 class="font-bold text-blue-900 mb-2">ℹ️ Test Rehberi</h3>
            <ul class="text-blue-800 space-y-1">
                <li>• <strong>Giriş Kapısı:</strong> Sadece işe başlama için kullanılır. Giriş yapılmışsa hata verir.</li>
                <li>• <strong>Çıkış Kapısı:</strong> Sadece işten çıkış için kullanılır. Giriş yapılmamışsa hata verir.</li>
                <li>• <strong>Mola Kapısı:</strong> Mola başlatma/bitirme için kullanılır. Akıllı geçiş yapar.</li>
                <li>• <strong>Genel Kapı:</strong> Duruma göre otomatik karar verir.</li>
                <li>• <strong>Sıfırla:</strong> Personelin bugünkü kaydını siler, yeniden test etmenizi sağlar.</li>
            </ul>
        </div>

        <!-- Navigation -->
        <div class="text-center mt-6 space-y-3">
            <a href="qr-generator.php" class="inline-block bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700">
                📱 QR Yönetimi
            </a>
            <a href="fix-qr-gates.php" class="inline-block bg-yellow-600 text-white py-3 px-6 rounded-lg hover:bg-yellow-700 ml-3">
                🛠️ Kapı Düzeltmeleri
            </a>
            <a href="../dashboard/company-dashboard.php" class="inline-block bg-gray-600 text-white py-3 px-6 rounded-lg hover:bg-gray-700 ml-3">
                🏠 Dashboard
            </a>
        </div>
    </div>
</body>
</html>