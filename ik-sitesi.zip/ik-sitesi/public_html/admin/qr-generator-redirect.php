<?php
// Simple redirect to new QR Generator
header('Location: qr-generator-new.php');
exit;
?>