<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    die("Yetkilendirme hatası");
}

require_once '../includes/config.php';
require_once '../includes/database.php';

$db = new Database();
$conn = $db->getConnection();

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<title>QR Locations Acil Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }";
echo ".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }";
echo ".success { color: #28a745; font-weight: bold; }";
echo ".error { color: #dc3545; font-weight: bold; }";
echo ".info { color: #007bff; }";
echo ".warning { color: #ff6b00; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";
echo "<h1>🚨 QR Locations Acil Tablo Düzeltme</h1>";

try {
    // First, drop the problematic table if it exists
    echo "<p class='warning'>⚠️ Mevcut qr_locations tablosu yeniden oluşturulacak...</p>";
    
    // Disable foreign key checks temporarily
    $conn->exec("SET FOREIGN_KEY_CHECKS=0");
    
    // Drop existing table
    $conn->exec("DROP TABLE IF EXISTS qr_locations");
    echo "<p class='info'>✓ Eski tablo silindi</p>";
    
    // Create new table with ALL columns from the start
    $sql = "CREATE TABLE qr_locations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        name VARCHAR(255) NOT NULL DEFAULT 'QR Lokasyon',
        location_code VARCHAR(50),
        qr_code VARCHAR(100) NOT NULL,
        location_type VARCHAR(50) DEFAULT 'office',
        description TEXT,
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        address VARCHAR(500),
        tolerance_radius INT DEFAULT 50,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURTIME()STAMP,
        updated_at TIMESTAMP DEFAULT CURTIME()STAMP ON UPDATE CURTIME()STAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        UNIQUE KEY unique_qr_code (qr_code),
        INDEX idx_company_id (company_id),
        INDEX idx_location_code (location_code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($sql);
    echo "<p class='success'>✅ Yeni qr_locations tablosu başarıyla oluşturuldu!</p>";
    
    // Re-enable foreign key checks
    $conn->exec("SET FOREIGN_KEY_CHECKS=1");
    
    // Show the created table structure
    echo "<h2>✅ Oluşturulan Tablo Yapısı:</h2>";
    echo "<table border='1' cellpadding='5' cellspacing='0' style='width: 100%; border-collapse: collapse;'>";
    echo "<tr style='background: #f8f9fa;'><th>Sütun</th><th>Tip</th><th>Null</th><th>Key</th><th>Varsayılan</th></tr>";
    
    $stmt = $conn->query("DESCRIBE qr_locations");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Test with a sample insert
    echo "<h2>Test Ekleme:</h2>";
    try {
        $testData = [
            $_SESSION['company_id'],
            'Test Lokasyon',
            'LOC_TEST_' . time(),
            'QR_TEST_' . time(),
            'office',
            'Test açıklama',
            41.0082,
            28.9784,
            'Test Adres, İstanbul',
            50,
            1
        ];
        
        $stmt = $conn->prepare("INSERT INTO qr_locations 
            (company_id, name, location_code, qr_code, location_type, description, latitude, longitude, address, tolerance_radius, is_active) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        if ($stmt->execute($testData)) {
            echo "<p class='success'>✅ Test verisi başarıyla eklendi!</p>";
            
            // Delete test data
            $conn->exec("DELETE FROM qr_locations WHERE location_code LIKE 'LOC_TEST_%'");
            echo "<p class='info'>✓ Test verisi temizlendi</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Test hatası: " . $e->getMessage() . "</p>";
    }
    
    echo "<div style='margin-top: 30px; padding: 20px; background: #d4edda; border-radius: 8px;'>";
    echo "<h3 style='color: #155724; margin: 0 0 10px 0;'>🎉 Düzeltme Tamamlandı!</h3>";
    echo "<p style='color: #155724; margin: 10px 0;'>QR lokasyon tablosu başarıyla yeniden oluşturuldu. Artık QR kod oluşturabilirsiniz.</p>";
    echo "<a href='qr-generator.php' style='display: inline-block; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin-top: 10px;'>QR Generator'a Git</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Kritik Hata: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
    
    // Try to re-enable foreign key checks on error
    try {
        $conn->exec("SET FOREIGN_KEY_CHECKS=1");
    } catch (Exception $e2) {
        // Ignore
    }
}

echo "</div>";
echo "</body>";
echo "</html>";
?>