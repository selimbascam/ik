<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle clear admin bypass
if (isset($_GET['clear_bypass']) && $_GET['clear_bypass'] === '1') {
    unset($_SESSION['admin_bypass'], $_SESSION['admin_bypass_employee_id'], $_SESSION['admin_bypass_employee_name']);
    header('Location: employee-attendance-list.php');
    exit;
}

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../auth/admin-login.php');
    exit;
}

$companyId = $_SESSION['company_id'];
$companyName = $_SESSION['company_name'] ?? 'Firma';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get all employees for this company
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, 
               COALESCE(employee_code, COALESCE(employee_number, CONCAT('EMP', LPAD(id, 4, '0')))) as employee_number,
               email, status, created_at
        FROM employees 
        WHERE company_id = ? 
        ORDER BY first_name, last_name
    ");
    $stmt->execute([$companyId]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get today's attendance summary for each employee
    $today = date('Y-m-d');
    $attendanceSummary = [];
    
    foreach ($employees as $employee) {
        $stmt = $conn->prepare("
            SELECT 
                MIN(CASE WHEN activity_type = 'check_in' THEN created_at END) as first_in,
                MAX(CASE WHEN activity_type = 'check_out' THEN created_at END) as last_out,
                COUNT(*) as total_records,
                GROUP_CONCAT(DISTINCT activity_type) as activities
            FROM attendance_records 
            WHERE employee_id = ? AND DATE(created_at) = ?
        ");
        $stmt->execute([$employee['id'], $today]);
        $attendanceSummary[$employee['id']] = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
} catch (Exception $e) {
    $error = "Veri çekme hatası: " . $e->getMessage();
    error_log("Employee attendance list error: " . $e->getMessage());
    
    // Add diagnostic link for column errors
    if (strpos($e->getMessage(), 'employee_number') !== false) {
        $error .= '<br><br><a href="../debug/fix-employee-number-column.php" class="inline-block mt-2 bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm">🔧 Employee Number Sütunu Düzeltme</a>';
    }
}

function calculateWorkTime($firstIn, $lastOut) {
    if (!$firstIn || !$lastOut) return '--';
    $start = new DateTime($firstIn);
    $end = new DateTime($lastOut);
    $diff = $start->diff($end);
    return $diff->format('%H:%I');
}

function getStatusColor($status) {
    switch ($status) {
        case 'active': return 'bg-green-100 text-green-800';
        case 'inactive': return 'bg-red-100 text-red-800';
        default: return 'bg-gray-100 text-gray-800';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Devam Listesi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .online { background-color: #10b981; }
        .offline { background-color: #6b7280; }
        .break { background-color: #f59e0b; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">👥 Personel Devam Listesi</h1>
                    <p class="text-gray-600"><?php echo htmlspecialchars($companyName); ?> - <?php echo date('d.m.Y'); ?></p>
                </div>
                <div class="flex gap-3">
                    <a href="company-dashboard.php" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition">
                        🏠 Dashboard
                    </a>
                    <button onclick="refreshPage()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
                        🔄 Yenile
                    </button>
                </div>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- Employee List -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-800">📊 Bugünkü Devam Durumu</h2>
            </div>
            
            <?php if (empty($employees)): ?>
                <div class="text-center py-12 text-gray-500">
                    <div class="text-4xl mb-4">👥</div>
                    <p>Henüz personel kaydı bulunmuyor.</p>
                    <a href="employee-management.php" class="text-blue-600 hover:text-blue-800 mt-2 inline-block">
                        Personel Ekle →
                    </a>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Personel Bilgileri
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Durum
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    İlk Giriş
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Son Çıkış
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Toplam Süre
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Kayıt Sayısı
                                </th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    İşlemler
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($employees as $employee): 
                                $attendance = $attendanceSummary[$employee['id']] ?? [];
                                $hasAttendance = !empty($attendance['total_records']);
                                
                                // Determine current status
                                $currentStatus = 'offline';
                                $statusText = 'Çevrimdışı';
                                if ($hasAttendance) {
                                    $activities = explode(',', $attendance['activities'] ?? '');
                                    $lastActivity = end($activities);
                                    
                                    switch ($lastActivity) {
                                        case 'check_in':
                                            $currentStatus = 'online';
                                            $statusText = 'İşyerinde';
                                            break;
                                        case 'break_start':
                                            $currentStatus = 'break';
                                            $statusText = 'Molada';
                                            break;
                                        case 'break_end':
                                            $currentStatus = 'online';
                                            $statusText = 'İşyerinde';
                                            break;
                                        case 'check_out':
                                            $currentStatus = 'offline';
                                            $statusText = 'Çıkış Yaptı';
                                            break;
                                    }
                                }
                            ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                                                <span class="text-indigo-600 font-medium">
                                                    <?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?>
                                                </span>
                                            </div>
                                            <div class="ml-4">
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    <?php echo htmlspecialchars($employee['employee_number']); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <span class="status-dot <?php echo $currentStatus; ?>"></span>
                                            <span class="text-sm text-gray-900"><?php echo $statusText; ?></span>
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <span class="px-2 py-1 rounded-full text-xs <?php echo getStatusColor($employee['status']); ?>">
                                                <?php echo ucfirst($employee['status']); ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo $attendance['first_in'] ? date('H:i', strtotime($attendance['first_in'])) : '--'; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo $attendance['last_out'] ? date('H:i', strtotime($attendance['last_out'])) : '--'; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                                        <?php echo calculateWorkTime($attendance['first_in'], $attendance['last_out']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                                            <?php echo $attendance['total_records'] ?: '0'; ?> kayıt
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="../employee/dashboard.php?admin_bypass=<?php echo urlencode(base64_encode($employee['id'] . '|' . $employee['first_name'] . ' ' . $employee['last_name'])); ?>" 
                                           class="text-indigo-600 hover:text-indigo-900 mr-3"
                                           title="Personelin paneline geç">
                                            👁️ Detay Gör
                                        </a>
                                        <a href="employee-management.php?edit=<?php echo $employee['id']; ?>" 
                                           class="text-gray-600 hover:text-gray-900">
                                            ✏️ Düzenle
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Summary Stats -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mt-6">
            <?php
            $totalEmployees = count($employees);
            $activeToday = array_filter($attendanceSummary, function($att) { return !empty($att['total_records']); });
            $currentlyWorking = 0;
            $onBreak = 0;
            
            foreach ($attendanceSummary as $att) {
                if (!empty($att['activities'])) {
                    $activities = explode(',', $att['activities']);
                    $lastActivity = end($activities);
                    if (in_array($lastActivity, ['check_in', 'break_end'])) $currentlyWorking++;
                    if ($lastActivity === 'break_start') $onBreak++;
                }
            }
            ?>
            
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-blue-100 rounded-lg">
                        <span class="text-2xl">👥</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-lg font-semibold text-gray-800"><?php echo $totalEmployees; ?></h3>
                        <p class="text-sm text-gray-600">Toplam Personel</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-green-100 rounded-lg">
                        <span class="text-2xl">✅</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-lg font-semibold text-gray-800"><?php echo count($activeToday); ?></h3>
                        <p class="text-sm text-gray-600">Bugün Aktif</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-indigo-100 rounded-lg">
                        <span class="text-2xl">💼</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-lg font-semibold text-gray-800"><?php echo $currentlyWorking; ?></h3>
                        <p class="text-sm text-gray-600">Şu An Çalışıyor</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-yellow-100 rounded-lg">
                        <span class="text-2xl">☕</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-lg font-semibold text-gray-800"><?php echo $onBreak; ?></h3>
                        <p class="text-sm text-gray-600">Molada</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function refreshPage() {
            window.location.reload();
        }
        
        // Auto refresh every 30 seconds
        setInterval(refreshPage, 30000);
    </script>
</body>
</html>