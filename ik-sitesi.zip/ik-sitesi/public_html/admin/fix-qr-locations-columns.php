<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    die("Yetkilendirme hatası");
}

require_once '../includes/config.php';
require_once '../includes/database.php';

$db = new Database();
$conn = $db->getConnection();

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<title>QR Locations Tablo Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }";
echo ".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }";
echo ".success { color: #28a745; font-weight: bold; }";
echo ".error { color: #dc3545; font-weight: bold; }";
echo ".info { color: #007bff; }";
echo "table { width: 100%; border-collapse: collapse; margin: 20px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background: #f8f9fa; }";
echo ".btn { padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }";
echo ".btn:hover { background: #0056b3; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";
echo "<h1>🔧 QR Locations Tablo Düzeltme</h1>";

try {
    // First check if table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'qr_locations'");
    if ($stmt->rowCount() == 0) {
        echo "<p class='error'>❌ qr_locations tablosu bulunamadı!</p>";
        echo "<p>Tablo oluşturuluyor...</p>";
        
        // Create complete table
        $sql = "CREATE TABLE IF NOT EXISTS qr_locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            name VARCHAR(255) NOT NULL DEFAULT 'QR Lokasyon',
            location_code VARCHAR(50),
            qr_code VARCHAR(100) NOT NULL,
            location_type VARCHAR(50) DEFAULT 'office',
            description TEXT,
            latitude DECIMAL(10, 8),
            longitude DECIMAL(11, 8),
            address VARCHAR(500),
            tolerance_radius INT DEFAULT 50,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURTIME()STAMP,
            updated_at TIMESTAMP DEFAULT CURTIME()STAMP ON UPDATE CURTIME()STAMP,
            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
            UNIQUE KEY unique_qr_code (qr_code),
            INDEX idx_company_id (company_id),
            INDEX idx_location_code (location_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        echo "<p class='success'>✅ qr_locations tablosu başarıyla oluşturuldu!</p>";
    }
    
    // Get current columns
    echo "<h2>Mevcut Sütunları Kontrol Ediliyor...</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations");
    $existingColumns = [];
    
    echo "<table>";
    echo "<tr><th>Sütun Adı</th><th>Tip</th><th>Null</th><th>Key</th><th>Varsayılan</th></tr>";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $existingColumns[] = $row['Field'];
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Add missing columns
    echo "<h2>Eksik Sütunlar Ekleniyor...</h2>";
    
    $requiredColumns = [
        'name' => [
            'sql' => "ADD COLUMN name VARCHAR(255) NOT NULL DEFAULT 'QR Lokasyon' AFTER company_id",
            'desc' => 'Lokasyon adı'
        ],
        'location_code' => [
            'sql' => "ADD COLUMN location_code VARCHAR(50) AFTER name",
            'desc' => 'Lokasyon kodu'
        ],
        'location_type' => [
            'sql' => "ADD COLUMN location_type VARCHAR(50) DEFAULT 'office' AFTER qr_code",
            'desc' => 'Lokasyon türü'
        ],
        'description' => [
            'sql' => "ADD COLUMN description TEXT AFTER location_type",
            'desc' => 'Açıklama'
        ],
        'latitude' => [
            'sql' => "ADD COLUMN latitude DECIMAL(10, 8) AFTER description",
            'desc' => 'Enlem'
        ],
        'longitude' => [
            'sql' => "ADD COLUMN longitude DECIMAL(11, 8) AFTER latitude",
            'desc' => 'Boylam'
        ],
        'address' => [
            'sql' => "ADD COLUMN address VARCHAR(500) AFTER longitude",
            'desc' => 'Adres'
        ],
        'tolerance_radius' => [
            'sql' => "ADD COLUMN tolerance_radius INT DEFAULT 50 AFTER address",
            'desc' => 'Tolerans yarıçapı'
        ],
        'is_active' => [
            'sql' => "ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER tolerance_radius",
            'desc' => 'Aktiflik durumu'
        ],
        'created_at' => [
            'sql' => "ADD COLUMN created_at TIMESTAMP DEFAULT CURTIME()STAMP",
            'desc' => 'Oluşturulma tarihi'
        ],
        'updated_at' => [
            'sql' => "ADD COLUMN updated_at TIMESTAMP DEFAULT CURTIME()STAMP ON UPDATE CURTIME()STAMP",
            'desc' => 'Güncellenme tarihi'
        ]
    ];
    
    $addedCount = 0;
    foreach ($requiredColumns as $column => $config) {
        if (!in_array($column, $existingColumns)) {
            try {
                $conn->exec("ALTER TABLE qr_locations " . $config['sql']);
                echo "<p class='success'>✅ Eklendi: {$column} ({$config['desc']})</p>";
                $addedCount++;
            } catch (Exception $e) {
                echo "<p class='error'>❌ Eklenemedi: {$column} - " . $e->getMessage() . "</p>";
            }
        } else {
            echo "<p class='info'>ℹ️ Zaten mevcut: {$column} ({$config['desc']})</p>";
        }
    }
    
    if ($addedCount > 0) {
        echo "<p class='success'><strong>✅ {$addedCount} yeni sütun eklendi!</strong></p>";
    } else {
        echo "<p class='info'><strong>ℹ️ Tüm sütunlar zaten mevcut.</strong></p>";
    }
    
    // Update NULL names
    $updated = $conn->exec("UPDATE qr_locations SET name = CONCAT('QR Lokasyon ', id) WHERE name IS NULL OR name = ''");
    if ($updated > 0) {
        echo "<p class='success'>✅ {$updated} kayıt için boş isimler güncellendi.</p>";
    }
    
    // Show final table structure
    echo "<h2>Son Tablo Yapısı</h2>";
    $stmt = $conn->query("DESCRIBE qr_locations");
    echo "<table>";
    echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Key</th><th>Varsayılan</th><th>Extra</th></tr>";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<div style='margin-top: 30px; padding: 20px; background: #e8f4fd; border-radius: 8px;'>";
    echo "<h3>✅ Düzeltme Tamamlandı!</h3>";
    echo "<p>Artık QR lokasyon oluşturabilirsiniz.</p>";
    echo "<a href='qr-generator.php' class='btn'>QR Generator'a Dön</a>";
    echo "<a href='../dashboard/company-dashboard.php' class='btn'>Dashboard'a Git</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Kritik Hata: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>