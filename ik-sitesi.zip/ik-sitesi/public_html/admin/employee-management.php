<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check admin access
if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../auth/company-login.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 1; // Default to 1 for super admin

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'add_employee') {
            $stmt = $conn->prepare("
                INSERT INTO employees (company_id, employee_code, first_name, last_name, email, phone, department_id, position, hire_date, wage_per_day, is_active, password_hash)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE, '$2y$10$6MsFMh/k0NpH1x4OIxEWXeQH5hA5H4Y4hqOsXPHGkiEddIeKdL7W6')
            ");
            $stmt->execute([
                $company_id,
                $_POST['employee_code'],
                $_POST['first_name'],
                $_POST['last_name'],
                $_POST['email'],
                $_POST['phone'],
                $_POST['department_id'] ?: null,
                $_POST['position'],
                $_POST['hire_date'],
                $_POST['wage_per_day']
            ]);
            $success = "Personel başarıyla eklendi.";
        }
        
        if ($action === 'update_employee') {
            $stmt = $conn->prepare("
                UPDATE employees SET 
                    employee_code = ?, first_name = ?, last_name = ?, email = ?, phone = ?, 
                    department_id = ?, position = ?, wage_per_day = ?, is_active = ?
                WHERE id = ? AND company_id = ?
            ");
            $stmt->execute([
                $_POST['employee_code'],
                $_POST['first_name'],
                $_POST['last_name'],
                $_POST['email'],
                $_POST['phone'],
                $_POST['department_id'] ?: null,
                $_POST['position'],
                $_POST['wage_per_day'],
                ($_POST['status'] === 'active') ? 1 : 0,
                $_POST['employee_id'],
                $company_id
            ]);
            $success = "Personel bilgileri güncellendi.";
        }
        
        if ($action === 'change_password') {
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            if ($new_password !== $confirm_password) {
                $error = "Şifreler eşleşmiyor.";
            } elseif (strlen($new_password) < 6) {
                $error = "Şifre en az 6 karakter olmalıdır.";
            } else {
                $stmt = $conn->prepare("
                    UPDATE employees SET password_hash = PASSWORD(?) 
                    WHERE id = ? AND company_id = ?
                ");
                $stmt->execute([
                    $new_password,
                    $_POST['employee_id'],
                    $_SESSION['company_id']
                ]);
                $success = "Personel şifresi başarıyla değiştirildi.";
            }
        }
        
        if ($action === 'toggle_status') {
            $stmt = $conn->prepare("
                UPDATE employees SET is_active = CASE 
                    WHEN is_active = 1 THEN 0 
                    ELSE 1 
                END 
                WHERE id = ? AND company_id = ?
            ");
            $stmt->execute([
                $_POST['employee_id'],
                $company_id
            ]);
            $success = "Personel durumu güncellendi.";
        }
        
        if ($action === 'delete_employee') {
            $employee_id = $_POST['employee_id'];
            
            // Check if employee has any related data
            $hasData = 0;
            $relatedData = [];
            
            // Check attendance records
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM attendance_records WHERE employee_id = ?");
            $stmt->execute([$employee_id]);
            $attendanceCount = $stmt->fetch()['count'];
            if ($attendanceCount > 0) {
                $hasData = 1;
                $relatedData[] = "Devam kayıtları ($attendanceCount kayıt)";
            }
            
            // Check employee shifts
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employee_shifts WHERE employee_id = ?");
            $stmt->execute([$employee_id]);
            $shiftsCount = $stmt->fetch()['count'];
            if ($shiftsCount > 0) {
                $hasData = 1;
                $relatedData[] = "Vardiya kayıtları ($shiftsCount kayıt)";
            }
            
            // Check device records (with table existence check)
            try {
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM device_records WHERE employee_id = ?");
                $stmt->execute([$employee_id]);
                $deviceCount = $stmt->fetch()['count'];
                if ($deviceCount > 0) {
                    $hasData = 1;
                    $relatedData[] = "Cihaz kayıtları ($deviceCount kayıt)";
                }
            } catch (PDOException $e) {
                // Table might not exist, ignore this check
                if (strpos($e->getMessage(), "doesn't exist") === 0) {
                    throw $e; // Re-throw if it's a different error
                }
            }
            
            // Check employee devices (with table existence check)
            try {
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employee_devices WHERE employee_id = ?");
                $stmt->execute([$employee_id]);
                $employeeDeviceCount = $stmt->fetch()['count'];
                if ($employeeDeviceCount > 0) {
                    $hasData = 1;
                    $relatedData[] = "Kayıtlı cihazlar ($employeeDeviceCount cihaz)";
                }
            } catch (PDOException $e) {
                // Table might not exist, ignore this check
                if (strpos($e->getMessage(), "doesn't exist") === 0) {
                    throw $e; // Re-throw if it's a different error
                }
            }
            
            // Check leave requests (if table exists)
            try {
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM leave_requests WHERE employee_id = ?");
                $stmt->execute([$employee_id]);
                $leaveCount = $stmt->fetch()['count'];
                if ($leaveCount > 0) {
                    $hasData = 1;
                    $relatedData[] = "İzin talepleri ($leaveCount talep)";
                }
            } catch (Exception $e) {
                // Table might not exist, ignore
            }
            
            if ($hasData) {
                $error = "Bu personel silinemez! Aşağıdaki verilerle ilişkili kayıtlar bulundu:<br>• " . implode("<br>• ", $relatedData) . "<br><br>Önce bu kayıtları temizleyin veya personeli pasif duruma getirin.";
            } else {
                // Safe to delete - no related data found
                $stmt = $conn->prepare("DELETE FROM employees WHERE id = ? AND company_id = ?");
                $stmt->execute([$employee_id, $company_id]);
                
                if ($stmt->rowCount() > 0) {
                    $success = "Personel başarıyla silindi.";
                } else {
                    $error = "Personel silinemedi. Personel bulunamadı veya yetkisiz erişim.";
                }
            }
        }
    }
    
    // Get employees with delete safety check
    $stmt = $conn->prepare("
        SELECT e.*, d.name as department_name 
        FROM employees e 
        LEFT JOIN departments d ON e.department_id = d.id 
        WHERE e.company_id = ?
        ORDER BY e.first_name, e.last_name
    ");
    $stmt->execute([$company_id]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check delete safety for each employee
    foreach ($employees as &$employee) {
        $hasRelatedData = 0;
        
        // Quick check for any related data (with safe table checks)
        $totalRelated = 0;
        
        // Check attendance_records
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM attendance_records WHERE employee_id = ?");
            $stmt->execute([$employee['id']]);
            $totalRelated += $stmt->fetchColumn();
        } catch (PDOException $e) {
            // Table might not exist, continue
        }
        
        // Check employee_shifts
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM employee_shifts WHERE employee_id = ?");
            $stmt->execute([$employee['id']]);
            $totalRelated += $stmt->fetchColumn();
        } catch (PDOException $e) {
            // Table might not exist, continue
        }
        
        // Check device_records
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM device_records WHERE employee_id = ?");
            $stmt->execute([$employee['id']]);
            $totalRelated += $stmt->fetchColumn();
        } catch (PDOException $e) {
            // Table might not exist, continue
        }
        
        // Check employee_devices
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) FROM employee_devices WHERE employee_id = ?");
            $stmt->execute([$employee['id']]);
            $totalRelated += $stmt->fetchColumn();
        } catch (PDOException $e) {
            // Table might not exist, continue
        }
        
        $employee['can_delete'] = ($totalRelated == 0);
        $employee['related_records_count'] = $totalRelated;
    }
    unset($employee); // Break reference
    
    // Get departments
    $stmt = $conn->prepare("SELECT * FROM departments WHERE company_id = ? ORDER BY name");
    $stmt->execute([$company_id]);
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Yönetimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">👥</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Personel Yönetimi</h1>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'Şirket'); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <?php if (isset($success)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Add Employee Form -->
            <div class="bg-white rounded-lg shadow mb-8">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">Yeni Personel Ekle</h2>
                </div>
                <div class="p-6">
                    <form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <input type="hidden" name="action" value="add_employee">
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Personel No</label>
                            <input type="text" name="employee_code" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Ad</label>
                            <input type="text" name="first_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Soyad</label>
                            <input type="text" name="last_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">E-posta</label>
                            <input type="email" name="email" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Telefon</label>
                            <input type="text" name="phone" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Departman</label>
                            <select name="department_id" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Departman Seçin</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Pozisyon</label>
                            <input type="text" name="position" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">İşe Giriş Tarihi</label>
                            <input type="date" name="hire_date" required value="<?php echo date('Y-m-d'); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Maaş (TL)</label>
                            <input type="number" name="wage_per_day" step="0.01" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div class="md:col-span-2 lg:col-span-3">
                            <button type="submit" 
                                    class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
                                Personel Ekle
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Employees Table -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-medium text-gray-900">
                        Personel Listesi (<?php echo count($employees); ?>)
                    </h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Personel</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İletişim</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Departman/Pozisyon</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Maaş</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($employees as $employee): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                                                <span class="text-blue-600 font-medium">
                                                    <?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?>
                                                </span>
                                            </div>
                                            <div>
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    No: <?php echo htmlspecialchars($employee['tc_identity'] ?? $employee['employee_code'] ?? 'Belirtilmemiş'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <div><?php echo htmlspecialchars($employee['email'] ?? '-'); ?></div>
                                        <div class="text-gray-500"><?php echo htmlspecialchars($employee['phone'] ?? '-'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <div><?php echo htmlspecialchars($employee['department_name'] ?? '-'); ?></div>
                                        <div class="text-gray-500"><?php echo htmlspecialchars($employee['position'] ?? '-'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <?php if ($employee['wage_per_day']): ?>
                                            ₺<?php echo number_format($employee['wage_per_day'], 2); ?>/gün
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            <?php echo $employee['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo $employee['is_active'] ? 'Aktif' : 'Pasif'; ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm font-medium">
                                        <div class="flex flex-col space-y-1">
                                            <a href="../attendance/records.php?employee_id=<?php echo $employee['id']; ?>" 
                                               class="text-blue-600 hover:text-blue-900">📊 Devam Kayıtları</a>
                                            <a href="javascript:void(0)" onclick="editEmployee(<?php echo htmlspecialchars(json_encode($employee)); ?>)" 
                                               class="text-indigo-600 hover:text-indigo-900">✏️ Düzenle</a>
                                            <a href="javascript:void(0)" onclick="changePassword(<?php echo $employee['id']; ?>, '<?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>')" 
                                               class="text-orange-600 hover:text-orange-900">🔑 Şifre Değiştir</a>
                                            <a href="javascript:void(0)" onclick="toggleStatus(<?php echo $employee['id']; ?>, <?php echo $employee['is_active'] ? 1 : 0; ?>)" 
                                               class="<?php echo $employee['is_active'] ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'; ?>">
                                               <?php echo $employee['is_active'] ? '❌ Pasif Yap' : '✅ Aktif Yap'; ?>
                                            </a>
                                            
                                            <?php if ($employee['can_delete']): ?>
                                                <a href="javascript:void(0)" onclick="deleteEmployee(<?php echo $employee['id']; ?>, '<?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>')" 
                                                   class="text-red-600 hover:text-red-900">🗑️ Sil</a>
                                            <?php else: ?>
                                                <span class="text-gray-400 cursor-not-allowed" 
                                                      title="Bu personel silinemez. <?php echo $employee['related_records_count']; ?> adet kayıt bulundu.">🗑️ Sil (<?php echo $employee['related_records_count']; ?>)</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Employee Modal -->
    <div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg max-w-2xl w-full p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Personel Düzenle</h3>
                <form id="editForm" method="POST">
                    <input type="hidden" name="action" value="update_employee">
                    <input type="hidden" name="employee_id" id="edit_employee_id">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Personel No</label>
                            <input type="text" name="employee_code" id="edit_employee_code" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Ad</label>
                            <input type="text" name="first_name" id="edit_first_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Soyad</label>
                            <input type="text" name="last_name" id="edit_last_name" required 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">E-posta</label>
                            <input type="email" name="email" id="edit_email" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Telefon</label>
                            <input type="text" name="phone" id="edit_phone" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Departman</label>
                            <select name="department_id" id="edit_department_id" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Departman Seçin</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Pozisyon</label>
                            <input type="text" name="position" id="edit_position" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Maaş (TL)</label>
                            <input type="number" name="wage_per_day" id="edit_wage_per_day" step="0.01" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Durum</label>
                            <select name="status" id="edit_status" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="active">Aktif</option>
                                <option value="inactive">Pasif</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closeEditModal()" 
                                class="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                            İptal
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Password Change Modal -->
    <div id="passwordModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg max-w-md w-full p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Şifre Değiştir</h3>
                <p class="text-sm text-gray-600 mb-4">Personel: <span id="password_employee_name" class="font-medium"></span></p>
                
                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    <input type="hidden" name="employee_id" id="password_employee_id">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Yeni Şifre</label>
                            <input type="password" name="new_password" required minlength="6"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <p class="text-xs text-gray-500 mt-1">En az 6 karakter olmalıdır</p>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Şifre Tekrar</label>
                            <input type="password" name="confirm_password" required minlength="6"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closePasswordModal()" 
                                class="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                            İptal
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700">
                            Şifre Değiştir
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function editEmployee(employee) {
        document.getElementById('edit_employee_id').value = employee.id;
        document.getElementById('edit_employee_code').value = employee.employee_code || '';
        document.getElementById('edit_first_name').value = employee.first_name || '';
        document.getElementById('edit_last_name').value = employee.last_name || '';
        document.getElementById('edit_email').value = employee.email || '';
        document.getElementById('edit_phone').value = employee.phone || '';
        document.getElementById('edit_department_id').value = employee.department_id || '';
        document.getElementById('edit_position').value = employee.position || '';
        document.getElementById('edit_wage_per_day').value = employee.wage_per_day || '';
        document.getElementById('edit_status').value = employee.is_active ? 'active' : 'inactive';
        
        document.getElementById('editModal').classList.remove('hidden');
    }
    
    function closeEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }
    
    function changePassword(employeeId, employeeName) {
        document.getElementById('password_employee_id').value = employeeId;
        document.getElementById('password_employee_name').textContent = employeeName;
        document.getElementById('passwordModal').classList.remove('hidden');
    }
    
    function closePasswordModal() {
        document.getElementById('passwordModal').classList.add('hidden');
    }
    
    function toggleStatus(employeeId, currentStatus) {
        const newStatus = currentStatus === 1 ? 'pasif' : 'aktif';
        if (confirm(`Bu personeli ${newStatus} yapmak istediğinizden emin misiniz?`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="toggle_status">
                <input type="hidden" name="employee_id" value="${employeeId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function deleteEmployee(employeeId, employeeName) {
        // Show confirmation dialog with warning
        const confirmMsg = `⚠️ UYARI: Bu işlem geri alınamaz!\n\n` +
                          `"${employeeName}" adlı personeli kalıcı olarak silmek istediğinizden emin misiniz?\n\n` +
                          `• Tüm personel bilgileri silinecek\n` +
                          `• Bu işlem geri alınamaz\n` +
                          `• Sadece hiç veri girişi olmayan personeller silinebilir\n\n` +
                          `Devam etmek için "OK" tuşuna basın.`;
        
        if (confirm(confirmMsg)) {
            // Double confirmation for safety
            if (confirm(`Son onay: "${employeeName}" personelini SİLMEK istediğinizden EMİN MİSİNİZ?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete_employee">
                    <input type="hidden" name="employee_id" value="${employeeId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    }
    
    // Close modals when clicking outside
    document.getElementById('editModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeEditModal();
        }
    });
    
    document.getElementById('passwordModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closePasswordModal();
        }
    });
    </script>
</body>
</html>