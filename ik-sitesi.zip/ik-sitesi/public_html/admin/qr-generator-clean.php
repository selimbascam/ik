<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Debug session
if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    echo "Session Debug: company_id=" . ($_SESSION['company_id'] ?? 'NULL') . ", user_id=" . ($_SESSION['user_id'] ?? 'NULL');
    header('Location: ../auth/login.php');
    exit();
}

try {
    require_once '../includes/config.php';
    require_once '../includes/database.php';
} catch (Exception $e) {
    die("Include Error: " . $e->getMessage());
}

$success = '';
$error = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    if (!$conn) {
        throw new Exception("Database connection failed");
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if ($_POST['action'] === 'create_location') {
        $name = trim($_POST['name']);
        $location_type = $_POST['location_type'];
        $description = trim($_POST['description']);
        $latitude = floatval($_POST['latitude']);
        $longitude = floatval($_POST['longitude']);
        $address = trim($_POST['address']);
        
        if (empty($name)) {
            $error = "Lokasyon adı zorunludur!";
        } elseif ($latitude < -90 || $latitude > 90) {
            $error = "Geçersiz enlem değeri!";
        } elseif ($longitude < -180 || $longitude > 180) {
            $error = "Geçersiz boylam değeri!";
        } else {
            // Generate unique QR code
            do {
                $qr_code = 'QR_' . strtoupper(uniqid()) . '_' . date('Ymd');
                $checkStmt = $conn->prepare("SELECT COUNT(*) FROM qr_locations WHERE qr_code = ?");
                $checkStmt->execute([$qr_code]);
            } while ($checkStmt->fetchColumn() > 0);
            
            // Insert into database
            $insertStmt = $conn->prepare("
                INSERT INTO qr_locations 
                (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
            ");
            
            $params = [
                $_SESSION['company_id'], 
                $name, 
                $qr_code, 
                $location_type, 
                $description, 
                $latitude, 
                $longitude, 
                $address
            ];
            
            if ($insertStmt->execute($params)) {
                $success = "QR lokasyon başarıyla oluşturuldu: {$name} ({$qr_code})";
                // Refresh page to show new location
                header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
                exit();
            } else {
                $errorInfo = $insertStmt->errorInfo();
                $error = "Lokasyon oluşturulamadı! Hata: " . $errorInfo[2];
            }
        }
        } elseif ($_POST['action'] === 'delete_location') {
            $location_id = intval($_POST['location_id']);
            $deleteStmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
            if ($deleteStmt->execute([$location_id, $_SESSION['company_id']])) {
                $success = "Lokasyon silindi!";
                header("Location: " . $_SERVER['PHP_SELF'] . "?deleted=1");
                exit();
            } else {
                $errorInfo = $deleteStmt->errorInfo();
                $error = "Lokasyon silinemedi! Hata: " . $errorInfo[2];
            }
        }
    } catch (Exception $e) {
        $error = "Form işlem hatası: " . $e->getMessage();
    }
}

// Handle GET parameters for success messages
if (isset($_GET['success'])) {
    $success = "QR lokasyon başarıyla oluşturuldu!";
}
if (isset($_GET['deleted'])) {
    $success = "Lokasyon başarıyla silindi!";
}

// Fetch existing locations
try {
    $locationsStmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? ORDER BY created_at DESC");
    $locationsStmt->execute([$_SESSION['company_id']]);
    $locations = $locationsStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error = "Lokasyonlar yüklenemedi: " . $e->getMessage();
    $locations = [];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Lokasyon Üretici - SZB İK Takip</title>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        .header { text-align: center; margin-bottom: 30px; }
        .alert { padding: 10px; margin: 10px 0; border-radius: 5px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-error { background: #f8d7da; color: #721c24; }
        .form-section { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px; }
        .form-group { margin: 15px 0; }
        .form-group label { display: block; font-weight: bold; margin-bottom: 5px; }
        .form-group input, .form-group select, .form-group textarea { 
            width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;
        }
        .btn { padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .locations-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .location-card { background: white; border: 1px solid #ddd; border-radius: 8px; padding: 15px; }
        .qr-container { text-align: center; margin: 15px 0; }
        .coord-row { display: flex; gap: 10px; }
        .coord-row .form-group { flex: 1; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>QR Lokasyon Üretici</h1>
            <p>GPS koordinatlı QR kodlar oluşturun</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="form-section">
            <h3>Yeni QR Lokasyon Oluştur</h3>
            <form method="POST">
                <input type="hidden" name="action" value="create_location">
                
                <div class="form-group">
                    <label>Lokasyon Adı *</label>
                    <input type="text" name="name" required placeholder="Örn: Ana Giriş Kapısı">
                </div>
                
                <div class="form-group">
                    <label>Lokasyon Türü</label>
                    <select name="location_type">
                        <option value="entrance">Giriş Kapısı</option>
                        <option value="office">Ofis/Çalışma Alanı</option>
                        <option value="break_area">Mola Alanı</option>
                        <option value="dining">Yemekhane</option>
                        <option value="other">Diğer</option>
                    </select>
                </div>
                
                <div class="coord-row">
                    <div class="form-group">
                        <label>Enlem (Latitude) *</label>
                        <input type="number" id="latitude" name="latitude" step="0.000001" required placeholder="41.0082">
                    </div>
                    
                    <div class="form-group">
                        <label>Boylam (Longitude) *</label>
                        <input type="number" id="longitude" name="longitude" step="0.000001" required placeholder="28.9784">
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="button" class="btn btn-success" onclick="getCurrentLocation()">Mevcut Konum Al</button>
                    <button type="button" class="btn btn-success" onclick="setIstanbul()">İstanbul</button>
                    <button type="button" class="btn btn-success" onclick="setAnkara()">Ankara</button>
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <input type="text" name="address" placeholder="Tam adres bilgisi">
                </div>
                
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" rows="3" placeholder="Lokasyon hakkında ek bilgiler"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">QR Lokasyon Oluştur</button>
            </form>
        </div>
        
        <?php if (!empty($locations)): ?>
            <div class="form-section">
                <h3>Mevcut QR Lokasyonları (<?= count($locations) ?>)</h3>
                <div class="locations-grid">
                    <?php foreach ($locations as $location): ?>
                        <div class="location-card">
                            <h4><?= htmlspecialchars($location['name']) ?></h4>
                            <p><strong>QR Kod:</strong> <?= htmlspecialchars($location['qr_code']) ?></p>
                            <p><strong>Tür:</strong> <?= htmlspecialchars($location['location_type']) ?></p>
                            <?php if ($location['latitude'] && $location['longitude']): ?>
                                <p><strong>Koordinatlar:</strong> <?= $location['latitude'] ?>, <?= $location['longitude'] ?></p>
                            <?php endif; ?>
                            
                            <div class="qr-container">
                                <canvas id="qr_<?= $location['id'] ?>" width="200" height="200"></canvas>
                            </div>
                            
                            <button class="btn btn-success" onclick="downloadQR(<?= $location['id'] ?>)">İndir</button>
                            <button class="btn btn-danger" onclick="deleteLocation(<?= $location['id'] ?>, '<?= htmlspecialchars($location['name']) ?>')">Sil</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function getCurrentLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    document.getElementById('latitude').value = position.coords.latitude.toFixed(8);
                    document.getElementById('longitude').value = position.coords.longitude.toFixed(8);
                    alert('GPS konumu alındı!');
                }, function(error) {
                    alert('GPS konumu alınamadı: ' + error.message);
                });
            } else {
                alert('Tarayıcınız GPS desteklemiyor!');
            }
        }
        
        function setIstanbul() {
            document.getElementById('latitude').value = '41.0082';
            document.getElementById('longitude').value = '28.9784';
        }
        
        function setAnkara() {
            document.getElementById('latitude').value = '39.9334';
            document.getElementById('longitude').value = '32.8597';
        }
        
        function downloadQR(locationId) {
            var canvas = document.getElementById('qr_' + locationId);
            if (canvas) {
                var link = document.createElement('a');
                link.download = 'QR_Location_' + locationId + '.png';
                link.href = canvas.toDataURL();
                link.click();
            }
        }
        
        function deleteLocation(locationId, locationName) {
            if (confirm('Bu lokasyonu silmek istediğinizden emin misiniz?\n\n' + locationName)) {
                var form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = '<input type="hidden" name="action" value="delete_location"><input type="hidden" name="location_id" value="' + locationId + '">';
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Generate QR codes after page loads
        document.addEventListener('DOMContentLoaded', function() {
            console.log('DOM loaded, checking QRCode library...');
            
            function generateQRCodes() {
                if (typeof QRCode === 'undefined') {
                    console.error('QRCode library not loaded, retrying...');
                    setTimeout(generateQRCodes, 500);
                    return;
                }
                
                console.log('QRCode library loaded, generating codes...');
                
                <?php foreach ($locations as $location): ?>
                try {
                    var canvas_<?= $location['id'] ?> = document.getElementById('qr_<?= $location['id'] ?>');
                    if (canvas_<?= $location['id'] ?>) {
                        var qrData_<?= $location['id'] ?> = {
                            qr_code: "<?= htmlspecialchars($location['qr_code'], ENT_QUOTES) ?>",
                            location_id: <?= $location['id'] ?>,
                            name: "<?= htmlspecialchars($location['name'], ENT_QUOTES) ?>",
                            location_type: "<?= htmlspecialchars($location['location_type'], ENT_QUOTES) ?>",
                            coordinates: {
                                latitude: <?= $location['latitude'] ? $location['latitude'] : 'null' ?>,
                                longitude: <?= $location['longitude'] ? $location['longitude'] : 'null' ?>
                            },
                            company_id: <?= $_SESSION['company_id'] ?>,
                            validation_radius: 100,
                            created_at: "<?= $location['created_at'] ?>"
                        };
                        
                        console.log('Generating QR for location <?= $location['id'] ?>:', qrData_<?= $location['id'] ?>);
                        
                        QRCode.toCanvas(
                            canvas_<?= $location['id'] ?>, 
                            JSON.stringify(qrData_<?= $location['id'] ?>), 
                            {
                                width: 200,
                                height: 200,
                                colorDark: '#000000',
                                colorLight: '#FFFFFF',
                                correctLevel: QRCode.CorrectLevel.M
                            }, 
                            function(error) {
                                if (error) {
                                    console.error('QR Error for location <?= $location['id'] ?>:', error);
                                    canvas_<?= $location['id'] ?>.style.border = '2px solid red';
                                } else {
                                    console.log('✅ QR Generated successfully for location <?= $location['id'] ?>');
                                    canvas_<?= $location['id'] ?>.style.border = '2px solid green';
                                }
                            }
                        );
                    } else {
                        console.error('Canvas not found for location <?= $location['id'] ?>');
                    }
                } catch(e) {
                    console.error('Exception generating QR for location <?= $location['id'] ?>:', e);
                }
                <?php endforeach; ?>
            }
            
            // Start generating QR codes
            setTimeout(generateQRCodes, 1000);
        });
    </script>
</body>
</html>