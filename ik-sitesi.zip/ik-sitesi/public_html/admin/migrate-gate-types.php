<?php
session_start();

// Check authentication
if (!isset($_SESSION['company_id']) || !isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

require_once '../includes/config.php';
require_once '../includes/database.php';

$success = '';
$error = '';
$db = new Database();
$conn = $db->getConnection();

try {
    // Add gate_behavior column if it doesn't exist
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
    if ($stmt->rowCount() === 0) {
        $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(50) DEFAULT NULL AFTER location_type");
        $success .= "✅ gate_behavior sütunu eklendi.<br>";
    }
    
    // Update existing locations with proper gate behaviors based on their names
    $stmt = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE company_id = ?");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $updated = 0;
    foreach ($locations as $location) {
        $name = mb_strtolower(trim($location['name']), 'UTF-8');
        $newType = null;
        $newBehavior = null;
        
        // Detect gate type from name
        if (stripos($name, 'giriş') !== false || stripos($name, 'giris') !== false || 
            stripos($name, 'entrance') !== false) {
            $newType = 'entrance_gate';
            $newBehavior = 'work_start';
        } elseif (stripos($name, 'çıkış') !== false || stripos($name, 'cikis') !== false || 
                  stripos($name, 'exit') !== false) {
            $newType = 'exit_gate';
            $newBehavior = 'work_end';
        } elseif (stripos($name, 'mola') !== false || stripos($name, 'break') !== false) {
            $newType = 'break_gate';
            $newBehavior = 'break_toggle';
        } else {
            // General gate for others
            $newType = 'general_gate';
            $newBehavior = 'user_choice';
        }
        
        // Update the location
        $updateStmt = $conn->prepare("UPDATE qr_locations SET location_type = ?, gate_behavior = ? WHERE id = ?");
        $updateStmt->execute([$newType, $newBehavior, $location['id']]);
        $updated++;
    }
    
    $success .= "✅ {$updated} lokasyon güncellendi.<br>";
    $success .= "✅ Kapı türü migrasyonu tamamlandı!";
    
} catch (Exception $e) {
    $error = "❌ Migrasyon hatası: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapı Sistemi Migrasyonu - SZB İK Takip</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f7fa;
            color: #333;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: 500;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
            background: #3498db;
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        p {
            color: #7f8c8d;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>🔄 Kapı Sistemi Migrasyonu</h1>
        <p>QR kod lokasyonlarınız yeni kapı türü sistemine güncellendi.</p>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= $error ?></div>
        <?php endif; ?>
        
        <h3>📊 Kapı Türleri:</h3>
        <ul>
            <li><strong>🟢 Giriş Kapısı:</strong> Sadece işe giriş için kullanılır</li>
            <li><strong>🔴 Çıkış Kapısı:</strong> Sadece işten çıkış için kullanılır</li>
            <li><strong>🟡 Mola Kapısı:</strong> Mola başlatma/bitirme için kullanılır</li>
            <li><strong>🔵 Genel Kapı:</strong> Kullanıcı seçimine göre çalışır</li>
        </ul>
        
        <a href="qr-generator.php" class="btn">✅ QR Yönetimine Dön</a>
        <a href="../dashboard/company-dashboard.php" class="btn">🏠 Dashboard'a Dön</a>
    </div>
</body>
</html>