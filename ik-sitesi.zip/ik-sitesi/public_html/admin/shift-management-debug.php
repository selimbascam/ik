<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔧 Shift Management Debug</h1>";

// Check session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "<h3>📋 Session Check</h3>";
echo "<p>Session active: " . (session_status() === PHP_SESSION_ACTIVE ? 'Yes' : 'No') . "</p>";
echo "<p>User role: " . ($_SESSION['user_role'] ?? 'Not set') . "</p>";
echo "<p>Company ID: " . ($_SESSION['company_id'] ?? 'Not set') . "</p>";

// Check files
echo "<h3>📁 File Check</h3>";
$requiredFiles = [
    '../includes/config.php',
    '../includes/database.php'
];

foreach ($requiredFiles as $file) {
    $exists = file_exists($file);
    echo "<p>" . htmlspecialchars($file) . ": " . ($exists ? '✅ Found' : '❌ Missing') . "</p>";
}

// Test database connection
echo "<h3>🔌 Database Test</h3>";
try {
    require_once '../includes/config.php';
    require_once '../includes/database.php';
    
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<p>✅ Database connection successful</p>";
    echo "<p>Connection type: " . get_class($conn) . "</p>";
    
    // Test basic query
    $stmt = $conn->query("SELECT 'test' as result");
    if ($conn instanceof PDO) {
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        $result = $stmt->fetch_assoc();
    }
    echo "<p>✅ Query test: " . ($result['result'] ?? 'Failed') . "</p>";
    
} catch (Exception $e) {
    echo "<p>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Check tables
echo "<h3>📊 Table Check</h3>";
try {
    if (isset($conn)) {
        $tables = ['employees', 'shift_templates', 'employee_shifts'];
        
        foreach ($tables as $table) {
            try {
                $stmt = $conn->query("SELECT COUNT(*) as count FROM $table");
                if ($conn instanceof PDO) {
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    $count = $result['count'];
                } else {
                    $result = $stmt->fetch_assoc();
                    $count = $result['count'];
                }
                echo "<p>✅ $table: $count records</p>";
            } catch (Exception $e) {
                echo "<p>❌ $table: " . $e->getMessage() . "</p>";
            }
        }
    }
} catch (Exception $e) {
    echo "<p>❌ Table check failed: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "<h3>🔗 Actions</h3>";
echo "<p><a href='../auth/company-login.php'>Company Login</a></p>";
echo "<p><a href='shift-management-simple.php'>Simple Shift Management</a></p>";

echo "<style>body { font-family: Arial, sans-serif; margin: 20px; }</style>";
?>