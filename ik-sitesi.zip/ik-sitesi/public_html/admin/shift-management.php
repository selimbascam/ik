<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../auth/company-login.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 1; // Default to 1 for super admin

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $message = '';
    $messageType = '';
    
    // Initialize shiftTemplates early to prevent undefined variable error
    $shiftTemplates = [];
    
    // Load shift templates before processing forms to prevent undefined variable
    try {
        $stmt = $conn->prepare("
            SELECT 
                id,
                name,
                start_time,
                end_time,
                COALESCE(break_duration, 60) as break_duration,
                COALESCE(description, '') as description,
                COALESCE(color_code, '#3B82F6') as color_code
            FROM shift_templates 
            WHERE company_id = ? AND is_active = 1 
            ORDER BY name
        ");
        $stmt->execute([$company_id]);
        
        if ($conn instanceof PDO) {
            $rawTemplates = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            // MySQLi compatibility
            $rawTemplates = [];
            while ($row = $stmt->fetch_assoc()) {
                $rawTemplates[] = $row;
            }
        }
        
        foreach ($rawTemplates as $template) {
            $shiftTemplates[] = [
                'id' => $template['id'] ?? '',
                'name' => $template['name'] ?? 'Unnamed Shift',
                'start_time' => $template['start_time'] ?? '09:00',
                'end_time' => $template['end_time'] ?? '17:00',
                'break_duration' => $template['break_duration'] ?? 60,
                'description' => $template['description'] ?? '',
                'color_code' => $template['color_code'] ?? '#3B82F6'
            ];
        }
    } catch (PDOException $e) {
        // Fallback to shifts table or empty array
        $shiftTemplates = [];
    }
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'create_shift_template') {
            try {
                // First try shift_templates table
                $stmt = $conn->prepare("
                    INSERT INTO shift_templates (company_id, name, start_time, end_time, break_duration, description)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $company_id,
                    $_POST['name'],
                    $_POST['start_time'],
                    $_POST['end_time'],
                    intval($_POST['break_duration']),
                    $_POST['description'] ?? ''
                ]);
                $message = "Vardiya şablonu başarıyla oluşturuldu.";
                $messageType = "success";
            } catch (PDOException $e) {
                // Fallback to shifts table if shift_templates doesn't exist
                try {
                    $stmt = $conn->prepare("
                        INSERT INTO shifts (company_id, name, start_time, end_time, break_duration)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $company_id,
                        $_POST['name'],
                        $_POST['start_time'],
                        $_POST['end_time'],
                        intval($_POST['break_duration'])
                    ]);
                    $message = "Vardiya başarıyla oluşturuldu (shifts tablosunda).";
                    $messageType = "success";
                } catch (PDOException $e2) {
                    $message = "Vardiya oluşturulamadı: " . $e2->getMessage();
                    $messageType = "error";
                }
            }
        }
        
        if ($action === 'bulk_delete_shifts') {
            try {
                if (!empty($_POST['shift_ids']) && is_array($_POST['shift_ids'])) {
                    $shiftIds = array_map('intval', $_POST['shift_ids']);
                    $placeholders = str_repeat('?,', count($shiftIds) - 1) . '?';
                    
                    $stmt = $conn->prepare("DELETE FROM employee_shifts WHERE id IN ($placeholders) AND employee_id IN (SELECT id FROM employees WHERE company_id = ?)");
                    $params = array_merge($shiftIds, [$_SESSION['company_id']]);
                    
                    if ($stmt->execute($params)) {
                        $deletedCount = $stmt->rowCount();
                        $message = "$deletedCount vardiya ataması başarıyla silindi.";
                        $messageType = 'success';
                    } else {
                        $message = "Vardiya atamaları silinirken hata oluştu.";
                        $messageType = 'error';
                    }
                } else {
                    $message = "Silinecek vardiya seçilmedi.";
                    $messageType = 'error';
                }
            } catch (Exception $e) {
                $message = "Hata: " . $e->getMessage();
                $messageType = 'error';
            }
        }
        
        if ($action === 'assign_shifts') {
            $employeeIds = $_POST['employee_ids'] ?? [];
            $shiftTemplateId = $_POST['shift_template_id'];
            $startDate = $_POST['start_date'];
            $endDate = $_POST['end_date'];
            $workdays = $_POST['workdays'] ?? [1,2,3,4,5]; // Monday to Friday default
            
            $assignmentCount = 0;
            $start = new DateTime($startDate);
            $end = new DateTime($endDate);
            
            foreach ($employeeIds as $employeeId) {
                for ($date = clone $start; $date <= $end; $date->add(new DateInterval('P1D'))) {
                    // Check if this day is in selected workdays
                    if (in_array($date->format('N'), $workdays)) {
                        // Try different column names for shift template ID
                        $insertQuery = "";
                        try {
                            // First try with shift_template_id
                            $stmt = $conn->prepare("INSERT IGNORE INTO employee_shifts (employee_id, shift_template_id, shift_date) VALUES (?, ?, ?)");
                            $stmt->execute([$employeeId, $shiftTemplateId, $date->format('Y-m-d')]);
                        } catch (PDOException $e1) {
                            try {
                                // Try with shift_id
                                $stmt = $conn->prepare("INSERT IGNORE INTO employee_shifts (employee_id, shift_id, shift_date) VALUES (?, ?, ?)");
                                $stmt->execute([$employeeId, $shiftTemplateId, $date->format('Y-m-d')]);
                            } catch (PDOException $e2) {
                                try {
                                    // Try with template_id
                                    $stmt = $conn->prepare("INSERT IGNORE INTO employee_shifts (employee_id, template_id, shift_date) VALUES (?, ?, ?)");
                                    $stmt->execute([$employeeId, $shiftTemplateId, $date->format('Y-m-d')]);
                                } catch (PDOException $e3) {
                                    // Create the table if it doesn't exist
                                    $conn->exec("
                                        CREATE TABLE IF NOT EXISTS employee_shifts (
                                            id INT AUTO_INCREMENT PRIMARY KEY,
                                            employee_id INT NOT NULL,
                                            shift_template_id INT NOT NULL,
                                            shift_date DATE NOT NULL,
                                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                            UNIQUE KEY unique_employee_date (employee_id, shift_date),
                                            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
                                        )
                                    ");
                                    
                                    // Now try the insert again
                                    $stmt = $conn->prepare("INSERT IGNORE INTO employee_shifts (employee_id, shift_template_id, shift_date) VALUES (?, ?, ?)");
                                    $stmt->execute([$employeeId, $shiftTemplateId, $date->format('Y-m-d')]);
                                }
                            }
                        }
                        $assignmentCount++;
                    }
                }
            }
            $message = "{$assignmentCount} vardiya ataması yapıldı.";
            $messageType = "success";
            
            // Always redirect after assignment attempt to refresh the page
            $_SESSION['success_message'] = $message;
            $_SESSION['success_type'] = $messageType;
            
            // Add a small delay to ensure database writes are committed
            if ($assignmentCount > 0) {
                // Force MySQL to commit the transaction
                $conn->exec('COMMIT');
                usleep(100000); // 100ms delay
            }
            
            header('Location: ' . $_SERVER['PHP_SELF'] . '?refresh=' . time());
            exit;
        }
        
        if ($action === 'update_shift_status') {
            $stmt = $conn->prepare("
                UPDATE employee_shifts 
                SET status = ?, late_reason = ?, early_leave_reason = ?, absence_reason = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $_POST['status'],
                $_POST['late_reason'] ?? null,
                $_POST['early_leave_reason'] ?? null,
                $_POST['absence_reason'] ?? null,
                $_POST['shift_id']
            ]);
            $message = "Vardiya durumu güncellendi.";
            $messageType = "success";
        }
        
        // Edit assigned shift functionality
        if ($action === 'edit_assigned_shift') {
            try {
                $stmt = $conn->prepare("
                    UPDATE employee_shifts 
                    SET employee_id = ?, shift_template_id = ?, shift_date = ?, status = ?
                    WHERE id = ?
                ");
                $stmt->execute([
                    $_POST['employee_id'],
                    $_POST['shift_template_id'],
                    $_POST['shift_date'],
                    $_POST['status'] ?? 'scheduled',
                    $_POST['shift_assignment_id']
                ]);
                $message = "Vardiya ataması başarıyla güncellendi.";
                $messageType = "success";
            } catch (PDOException $e) {
                $message = "Vardiya ataması güncellenemedi: " . $e->getMessage();
                $messageType = "error";
            }
        }
        
        // Delete assigned shift functionality
        if ($action === 'delete_assigned_shift') {
            try {
                $stmt = $conn->prepare("DELETE FROM employee_shifts WHERE id = ?");
                $stmt->execute([$_POST['shift_assignment_id']]);
                $message = "Vardiya ataması başarıyla silindi.";
                $messageType = "success";
            } catch (PDOException $e) {
                $message = "Vardiya ataması silinemedi: " . $e->getMessage();
                $messageType = "error";
            }
        }
        
        // Bulk delete assigned shifts
        if ($action === 'bulk_delete_shifts') {
            $shiftIds = $_POST['shift_ids'] ?? [];
            if (!empty($shiftIds)) {
                try {
                    $placeholders = str_repeat('?,', count($shiftIds) - 1) . '?';
                    $stmt = $conn->prepare("DELETE FROM employee_shifts WHERE id IN ($placeholders)");
                    $stmt->execute($shiftIds);
                    $deletedCount = $stmt->rowCount();
                    $message = "{$deletedCount} vardiya ataması silindi.";
                    $messageType = "success";
                } catch (PDOException $e) {
                    $message = "Vardiya atamaları silinemedi: " . $e->getMessage();
                    $messageType = "error";
                }
            } else {
                $message = "Silinecek vardiya seçilmedi.";
                $messageType = "warning";
            }
        }
        
        // Add edit shift template functionality
        if ($action === 'edit_shift_template') {
            try {
                $stmt = $conn->prepare("
                    UPDATE shift_templates 
                    SET name = ?, start_time = ?, end_time = ?, break_duration = ?, description = ?
                    WHERE id = ? AND company_id = ?
                ");
                $stmt->execute([
                    $_POST['name'],
                    $_POST['start_time'],
                    $_POST['end_time'],
                    intval($_POST['break_duration']),
                    $_POST['description'] ?? '',
                    $_POST['template_id'],
                    $company_id
                ]);
                $message = "Vardiya şablonu başarıyla güncellendi.";
                $messageType = "success";
            } catch (PDOException $e) {
                // Try fallback to shifts table
                try {
                    $stmt = $conn->prepare("
                        UPDATE shifts 
                        SET name = ?, start_time = ?, end_time = ?, break_duration = ?
                        WHERE id = ? AND company_id = ?
                    ");
                    $stmt->execute([
                        $_POST['name'],
                        $_POST['start_time'],
                        $_POST['end_time'],
                        intval($_POST['break_duration']),
                        $_POST['template_id'],
                        $company_id
                    ]);
                    $message = "Vardiya şablonu güncellendi.";
                    $messageType = "success";
                } catch (PDOException $e2) {
                    $message = "Vardiya güncellenemedi: " . $e2->getMessage();
                    $messageType = "error";
                }
            }
        }
        
        // Add delete shift template functionality
        if ($action === 'delete_shift_template') {
            try {
                // First check if template is being used - try different column names
                $activeAssignments = 0;
                try {
                    $stmt = $conn->prepare("
                        SELECT COUNT(*) FROM employee_shifts 
                        WHERE shift_template_id = ? AND shift_date >= CURDATE()
                    ");
                    $stmt->execute([$_POST['template_id']]);
                    $activeAssignments = $stmt->fetchColumn();
                } catch (PDOException $e1) {
                    try {
                        $stmt = $conn->prepare("
                            SELECT COUNT(*) FROM employee_shifts 
                            WHERE shift_id = ? AND shift_date >= CURDATE()
                        ");
                        $stmt->execute([$_POST['template_id']]);
                        $activeAssignments = $stmt->fetchColumn();
                    } catch (PDOException $e2) {
                        try {
                            $stmt = $conn->prepare("
                                SELECT COUNT(*) FROM employee_shifts 
                                WHERE template_id = ? AND shift_date >= CURDATE()
                            ");
                            $stmt->execute([$_POST['template_id']]);
                            $activeAssignments = $stmt->fetchColumn();
                        } catch (PDOException $e3) {
                            $activeAssignments = 0; // Assume no assignments if table doesn't exist
                        }
                    }
                }
                
                if ($activeAssignments > 0) {
                    $message = "Bu vardiya şablonu aktif atamalarda kullanılıyor. Önce atamaları kaldırın.";
                    $messageType = "error";
                } else {
                    // Safe to delete - just mark as inactive
                    $stmt = $conn->prepare("
                        UPDATE shift_templates 
                        SET is_active = 0 
                        WHERE id = ? AND company_id = ?
                    ");
                    $stmt->execute([$_POST['template_id'], $_SESSION['company_id']]);
                    $message = "Vardiya şablonu devre dışı bırakıldı.";
                    $messageType = "success";
                }
            } catch (PDOException $e) {
                // Try fallback to shifts table
                try {
                    $stmt = $conn->prepare("
                        UPDATE shifts 
                        SET is_active = 0 
                        WHERE id = ? AND company_id = ?
                    ");
                    $stmt->execute([$_POST['template_id'], $_SESSION['company_id']]);
                    $message = "Vardiya şablonu devre dışı bırakıldı.";
                    $messageType = "success";
                } catch (PDOException $e2) {
                    $message = "Vardiya silinemedi: " . $e2->getMessage();
                    $messageType = "error";
                }
            }
        }
    }
    
    // Initialize variables to prevent undefined errors
    if (!isset($message)) $message = '';
    if (!isset($messageType)) $messageType = '';
    
    // Check for success message from redirect
    if (isset($_SESSION['success_message'])) {
        $message = $_SESSION['success_message'];
        $messageType = $_SESSION['success_type'] ?? 'success';
        unset($_SESSION['success_message']);
        unset($_SESSION['success_type']);
    }
    
    // Refresh shift templates after any database changes (only if empty)
    if (empty($shiftTemplates)) {
        try {
            $stmt = $conn->prepare("
                SELECT 
                    id,
                    name,
                    start_time,
                    end_time,
                    COALESCE(break_duration, 60) as break_duration,
                    COALESCE(description, '') as description,
                    COALESCE(color_code, '#3B82F6') as color_code
                FROM shift_templates 
                WHERE company_id = ? AND is_active = 1 
                ORDER BY name
            ");
            $stmt->execute([$company_id]);
            $rawTemplates = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($rawTemplates as $template) {
                $shiftTemplates[] = [
                    'id' => $template['id'] ?? '',
                    'name' => $template['name'] ?? 'Unnamed Shift',
                    'start_time' => $template['start_time'] ?? '09:00',
                    'end_time' => $template['end_time'] ?? '17:00',
                    'break_duration' => $template['break_duration'] ?? 60,
                    'description' => $template['description'] ?? '',
                    'color_code' => $template['color_code'] ?? '#3B82F6'
                ];
            }
        } catch (PDOException $e) {
            if (empty($message)) {
                $message = "Vardiya tabloları bulunamadı. Lütfen veritabanı kurulumunu kontrol edin.<br><br>";
                $message .= '<a href="../debug/fix-shift-tables.php" class="inline-block mt-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm">📅 Vardiya Tabloları Düzeltme</a>';
                $messageType = "warning";
            }
        }
    }
    
    // Get employees with MySQL compatibility and better error handling
    $employees = [];
    try {
        // Fixed query with COALESCE for missing columns - try to include tc_identity
        try {
            $stmt = $conn->prepare("
                SELECT 
                    id, 
                    COALESCE(first_name, '') as first_name, 
                    COALESCE(last_name, '') as last_name, 
                    COALESCE(employee_number, CONCAT('EMP', id)) as employee_number,
                    COALESCE(department_id, 0) as department_id,
                    COALESCE(tc_no, '') as tc_identity,
                    COALESCE(employee_code, '') as employee_code
                FROM employees 
                WHERE company_id = ? AND COALESCE(is_active, 1) = 1 AND COALESCE(status, 'active') = 'active'
                ORDER BY first_name, last_name
            ");
        } catch (PDOException $e) {
            // Fallback without tc_no column if it doesn't exist
            $stmt = $conn->prepare("
                SELECT 
                    id, 
                    COALESCE(first_name, '') as first_name, 
                    COALESCE(last_name, '') as last_name, 
                    COALESCE(employee_number, CONCAT('EMP', id)) as employee_number,
                    COALESCE(department_id, 0) as department_id,
                    '' as tc_identity,
                    COALESCE(employee_code, '') as employee_code
                FROM employees 
                WHERE company_id = ? AND COALESCE(is_active, 1) = 1 AND COALESCE(status, 'active') = 'active'
                ORDER BY first_name, last_name
            ");
        }
        $stmt->execute([$company_id]);
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Debug: Check if employees found
        if (empty($employees)) {
            // Fallback query without constraints - try to include tc_no
            try {
                $stmt = $conn->prepare("
                    SELECT 
                        id, 
                        COALESCE(first_name, '') as first_name, 
                        COALESCE(last_name, '') as last_name, 
                        COALESCE(employee_number, CONCAT('EMP', id)) as employee_number,
                        COALESCE(department_id, 0) as department_id,
                        COALESCE(tc_no, '') as tc_identity,
                        COALESCE(employee_code, '') as employee_code
                    FROM employees 
                    WHERE company_id = ? 
                    ORDER BY first_name, last_name
                    LIMIT 100
                ");
            } catch (PDOException $e) {
                // Fallback without tc_no column if it doesn't exist
                $stmt = $conn->prepare("
                    SELECT 
                        id, 
                        COALESCE(first_name, '') as first_name, 
                        COALESCE(last_name, '') as last_name, 
                        COALESCE(employee_number, CONCAT('EMP', id)) as employee_number,
                        COALESCE(department_id, 0) as department_id,
                        '' as tc_identity,
                        COALESCE(employee_code, '') as employee_code
                    FROM employees 
                    WHERE company_id = ? 
                    ORDER BY first_name, last_name
                    LIMIT 100
                ");
            }
            $stmt->execute([$company_id]);
            $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
    } catch (PDOException $e) {
        // Fallback with simpler query
        try {
            $stmt = $conn->prepare("
                SELECT id, first_name, last_name, employee_number 
                FROM employees 
                WHERE company_id = ? 
                ORDER BY id
                LIMIT 50
            ");
            $stmt->execute([$company_id]);
            $rawEmployees = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Ensure safe field access
            foreach ($rawEmployees as $emp) {
                $employees[] = [
                    'id' => $emp['id'] ?? 0,
                    'first_name' => $emp['first_name'] ?? 'Ad',
                    'last_name' => $emp['last_name'] ?? 'Soyad',
                    'employee_number' => $emp['employee_number'] ?? 'EMP' . ($emp['id'] ?? '000'),
                    'department_id' => 0
                ];
            }
        } catch (PDOException $e2) {
            $employees = [];
            // Enhanced error handling with automatic diagnostics
            $debugMessage = "Personel listesi alınamadı. Şirket ID: " . ($_SESSION['company_id'] ?? 'not set');
            
            // Try emergency fallback - create minimal employee data if possible
            try {
                // Check if there are ANY employees for this company
                $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE company_id = ?");
                $checkStmt->execute([$_SESSION['company_id']]);
                $employeeCount = $checkStmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
                
                if ($employeeCount == 0) {
                    $debugMessage .= " (Hiç personel kaydı yok)";
                } else {
                    $debugMessage .= " (Veritabanında $employeeCount personel var ama erişim sorunu)";
                }
            } catch (Exception $e3) {
                $debugMessage .= " (Veritabanı bağlantı sorunu)";
            }
            
            if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'super_admin') {
                $debugMessage .= " | Error: " . $e2->getMessage();
                $debugMessage .= " | <a href='../debug/fix-shift-employee-list.php?company_id=" . ($_SESSION['company_id'] ?? '4') . "' style='color: #dc2626; text-decoration: underline; font-weight: bold;'>🔧 Sorun Giderme Aracı</a>";
            } else {
                $debugMessage .= " | Lütfen sistem yöneticisiyle iletişime geçin.";
            }
            $message = $debugMessage;
            $messageType = "warning";
        }
    }
    
    // Get recent shift assignments - MySQL optimized query
    $recentShifts = [];
    try {
        // MySQL-specific query with proper indexing and optimized joins - try to include TC identity
        try {
            $stmt = $conn->prepare("
                SELECT 
                    es.id,
                    es.employee_id,
                    es.shift_template_id,
                    DATE_FORMAT(es.shift_date, '%Y-%m-%d') as shift_date,
                    DATE_FORMAT(es.created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                    COALESCE(es.status, 'scheduled') as status,
                    COALESCE(st.name, 'Vardiya') as shift_name,
                    COALESCE(st.start_time, '09:00:00') as start_time,
                    COALESCE(st.end_time, '17:00:00') as end_time,
                    COALESCE(st.color_code, '#3B82F6') as color_code,
                    COALESCE(e.first_name, '') as first_name, 
                    COALESCE(e.last_name, '') as last_name, 
                    COALESCE(e.employee_number, CONCAT('EMP', e.id)) as employee_number,
                    e.tc_identity,
                    e.employee_code
                FROM employee_shifts es
                INNER JOIN employees e ON es.employee_id = e.id AND e.company_id = ?
                LEFT JOIN shift_templates st ON es.shift_template_id = st.id
                WHERE es.shift_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                ORDER BY es.created_at DESC
                LIMIT 20
            ");
        } catch (PDOException $e) {
            // Fallback without tc_identity column if it doesn't exist
            $stmt = $conn->prepare("
                SELECT 
                    es.id,
                    es.employee_id,
                    es.shift_template_id,
                    DATE_FORMAT(es.shift_date, '%Y-%m-%d') as shift_date,
                    DATE_FORMAT(es.created_at, '%Y-%m-%d %H:%i:%s') as created_at,
                    COALESCE(es.status, 'scheduled') as status,
                    COALESCE(st.name, 'Vardiya') as shift_name,
                    COALESCE(st.start_time, '09:00:00') as start_time,
                    COALESCE(st.end_time, '17:00:00') as end_time,
                    COALESCE(st.color_code, '#3B82F6') as color_code,
                    COALESCE(e.first_name, '') as first_name, 
                    COALESCE(e.last_name, '') as last_name, 
                    COALESCE(e.employee_number, CONCAT('EMP', e.id)) as employee_number,
                    NULL as tc_identity,
                    NULL as employee_code
                FROM employee_shifts es
                INNER JOIN employees e ON es.employee_id = e.id AND e.company_id = ?
                LEFT JOIN shift_templates st ON es.shift_template_id = st.id
                WHERE es.shift_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                ORDER BY es.created_at DESC
                LIMIT 20
            ");
        }
        
        $stmt->execute([$company_id]);
        $recentShifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Add debug info for super admin
        if ($_SESSION['user_role'] === 'super_admin') {
            $debugStmt = $conn->prepare("SELECT COUNT(*) as total FROM employee_shifts es INNER JOIN employees e ON es.employee_id = e.id WHERE e.company_id = ?");
            $debugStmt->execute([$_SESSION['company_id']]);
            $debugResult = $debugStmt->fetch(PDO::FETCH_ASSOC);
            $message .= " [Debug: " . count($recentShifts) . " recent shifts, Total: " . ($debugResult['total'] ?? 0) . "]";
            
            // Also check shift_templates count
            $templateStmt = $conn->prepare("SELECT COUNT(*) as total FROM shift_templates WHERE company_id = ?");
            $templateStmt->execute([$_SESSION['company_id']]);
            $templateResult = $templateStmt->fetch(PDO::FETCH_ASSOC);
            $message .= " [Templates: " . ($templateResult['total'] ?? 0) . "]";
        }
        
    } catch (PDOException $e) {
        $recentShifts = [];
        if ($_SESSION['user_role'] === 'super_admin') {
            $message .= " [Error: " . $e->getMessage() . "]";
        }
        
        // Try to recreate missing indexes or tables
        try {
            $conn->exec("CREATE INDEX IF NOT EXISTS idx_employee ON employee_shifts(employee_id)");
            $conn->exec("CREATE INDEX IF NOT EXISTS idx_created_at ON employee_shifts(created_at)");
        } catch (Exception $indexError) {
            // Ignore index creation errors
        }
    }
    
} catch (Exception $e) {
    $message = "Hata: " . $e->getMessage();
    $messageType = "error";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vardiya Yönetimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">

    <!-- Edit Template Modal -->
    <div id="editTemplateModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3 text-center">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Vardiya Şablonunu Düzenle</h3>
                <form id="editTemplateForm" method="POST">
                    <input type="hidden" name="action" value="edit_shift_template">
                    <input type="hidden" name="template_id" id="edit_template_id">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Vardiya Adı</label>
                            <input type="text" name="name" id="edit_name" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Başlangıç</label>
                                <input type="time" name="start_time" id="edit_start_time" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Bitiş</label>
                                <input type="time" name="end_time" id="edit_end_time" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Mola Süresi (dk)</label>
                            <input type="number" name="break_duration" id="edit_break_duration" min="0" max="480"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                            <textarea name="description" id="edit_description" rows="2"
                                      class="w-full px-3 py-2 border border-gray-300 rounded-md"></textarea>
                        </div>
                    </div>
                    
                    <div class="flex space-x-4 mt-6">
                        <button type="button" onclick="closeEditModal()" 
                                class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400">
                            İptal
                        </button>
                        <button type="submit"
                                class="flex-1 bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Shift Assignment Modal -->
    <div id="editShiftModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3 text-center">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Vardiya Atamasını Düzenle</h3>
                <form id="editShiftForm" method="POST">
                    <input type="hidden" name="action" value="edit_assigned_shift">
                    <input type="hidden" name="shift_assignment_id" id="edit_shift_assignment_id">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Personel</label>
                            <select name="employee_id" id="edit_employee_id" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <?php foreach ($employees as $employee): ?>
                                    <option value="<?php echo $employee['id']; ?>">
                                        <?php echo htmlspecialchars(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? '')); ?>
                                        (<?php echo htmlspecialchars($employee['employee_number'] ?? ''); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Vardiya Şablonu</label>
                            <select name="shift_template_id" id="edit_shift_template_id" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <?php foreach ($shiftTemplates as $template): ?>
                                    <option value="<?php echo $template['id']; ?>">
                                        <?php echo htmlspecialchars($template['name']); ?>
                                        (<?php echo substr($template['start_time'], 0, 5); ?>-<?php echo substr($template['end_time'], 0, 5); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Tarih</label>
                            <input type="date" name="shift_date" id="edit_shift_date" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Durum</label>
                            <select name="status" id="edit_status"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <option value="scheduled">Planlandı</option>
                                <option value="completed">Tamamlandı</option>
                                <option value="absent">Gelmedi</option>
                                <option value="late">Geç Geldi</option>
                                <option value="early_leave">Erken Çıktı</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex space-x-4 mt-6">
                        <button type="button" onclick="closeEditShiftModal()" 
                                class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400">
                            İptal
                        </button>
                        <button type="submit"
                                class="flex-1 bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteConfirmModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3 text-center">
                <div class="text-red-500 text-4xl mb-4">⚠️</div>
                <h3 class="text-lg font-medium text-gray-900 mb-4">Vardiya Atamasını Sil</h3>
                <div id="deleteMessage" class="text-gray-600 mb-6"></div>
                
                <form id="deleteShiftForm" method="POST">
                    <input type="hidden" name="action" value="delete_assigned_shift">
                    <input type="hidden" name="shift_assignment_id" id="delete_shift_assignment_id">
                    
                    <div class="flex space-x-4">
                        <button type="button" onclick="closeDeleteModal()" 
                                class="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400">
                            İptal
                        </button>
                        <button type="submit"
                                class="flex-1 bg-red-600 text-white py-2 px-4 rounded-md hover:bg-red-700">
                            Sil
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">🕒</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">Vardiya Yönetimi</h1>
                            <p class="text-sm text-gray-600">Çalışma saatleri ve vardiya planlaması</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="../dashboard/company-dashboard.php" class="text-gray-600 hover:text-gray-900">
                            ← Dashboard'a Dön
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <?php if ($message): ?>
                <div class="mb-6 p-4 rounded-lg <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                        'bg-red-100 text-red-800 border border-red-200'; 
                ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <!-- Tabs -->
            <div class="mb-8">
                <div class="border-b border-gray-200">
                    <nav class="-mb-px flex space-x-8">
                        <button onclick="showTab('templates')" class="tab-btn active py-4 px-1 border-b-2 border-indigo-500 font-medium text-sm text-indigo-600">
                            Vardiya Şablonları
                        </button>
                        <button onclick="showTab('assignments')" class="tab-btn py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
                            Vardiya Atamaları
                        </button>
                        <button onclick="showTab('schedule')" class="tab-btn py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
                            Çalışma Programı
                        </button>
                    </nav>
                </div>
            </div>

            <!-- Tab Content: Shift Templates -->
            <div id="templates-tab" class="tab-content">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Create New Template -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-medium text-gray-900 mb-6">Yeni Vardiya Şablonu</h2>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="create_shift_template">
                            
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Vardiya Adı</label>
                                    <input type="text" name="name" required 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                           placeholder="Örn: Sabah Vardiyası">
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Başlangıç Saati</label>
                                        <input type="time" name="start_time" required 
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Bitiş Saati</label>
                                        <input type="time" name="end_time" required 
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Mola Süresi (dk)</label>
                                        <input type="number" name="break_duration" min="0" max="480" value="60"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Renk</label>
                                        <input type="color" name="color_code" value="#3B82F6"
                                               class="w-full h-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Açıklama</label>
                                    <textarea name="description" rows="3"
                                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                              placeholder="Vardiya hakkında açıklama..."></textarea>
                                </div>
                            </div>
                            
                            <button type="submit" 
                                    class="mt-6 w-full bg-indigo-600 text-white py-3 px-4 rounded-md hover:bg-indigo-700 transition-colors">
                                Vardiya Şablonunu Oluştur
                            </button>
                        </form>
                    </div>
                    
                    <!-- Existing Templates -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-medium text-gray-900 mb-6">Mevcut Vardiya Şablonları</h2>
                        
                        <div class="space-y-4">
                            <?php foreach ($shiftTemplates as $template): ?>
                                <div class="border border-gray-200 rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-2">
                                        <h3 class="font-medium text-gray-900"><?php echo htmlspecialchars($template['name']); ?></h3>
                                        <div class="flex items-center space-x-2">
                                            <span class="w-4 h-4 rounded-full" style="background-color: <?php echo htmlspecialchars($template['color_code']); ?>"></span>
                                            <button onclick="editShiftTemplate(<?php echo htmlspecialchars(json_encode($template)); ?>)" 
                                                    class="text-blue-600 hover:text-blue-800 text-sm">
                                                ✏️ Düzenle
                                            </button>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Bu vardiya şablonunu silmek istediğinizden emin misiniz?')">
                                                <input type="hidden" name="action" value="delete_shift_template">
                                                <input type="hidden" name="template_id" value="<?php echo $template['id']; ?>">
                                                <button type="submit" class="text-red-600 hover:text-red-800 text-sm">
                                                    🗑️ Sil
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        <p>🕐 <?php echo substr($template['start_time'] ?? '09:00', 0, 5); ?> - <?php echo substr($template['end_time'] ?? '17:00', 0, 5); ?></p>
                                        <p>☕ Mola: <?php echo intval($template['break_duration'] ?? 60); ?> dakika</p>
                                        <?php if (!empty($template['description'])): ?>
                                            <p class="mt-1"><?php echo htmlspecialchars($template['description']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php if (empty($shiftTemplates)): ?>
                                <div class="text-center text-gray-500 py-8">
                                    <p>Henüz vardiya şablonu oluşturulmamış.</p>
                                    <p class="text-sm mt-2">Sol taraftaki formdan yeni vardiya şablonu oluşturabilirsiniz.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tab Content: Shift Assignments -->
            <div id="assignments-tab" class="tab-content hidden">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Bulk Assignment -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-medium text-gray-900 mb-6">Toplu Vardiya Atama</h2>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="assign_shifts">
                            
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Personeller 
                                        <span class="text-xs text-gray-500">(<?php echo count($employees); ?> personel)</span>
                                    </label>
                                    <div class="max-h-32 overflow-y-auto border border-gray-300 rounded-md p-2">
                                        <?php if (!empty($employees)): ?>
                                            <?php foreach ($employees as $employee): ?>
                                                <label class="flex items-center space-x-2 p-1 hover:bg-gray-50">
                                                    <input type="checkbox" name="employee_ids[]" value="<?php echo $employee['id']; ?>"
                                                           class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                                    <span class="text-sm">
                                                        <?php echo htmlspecialchars(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? '')); ?>
                                                        (<?php 
                                                        // Personel yönetimi ile tutarlılık için aynı öncelik sırası
                                                        if (!empty($employee['tc_identity'])) {
                                                            echo htmlspecialchars($employee['tc_identity']);
                                                        } elseif (!empty($employee['employee_code'])) {
                                                            echo htmlspecialchars($employee['employee_code']);
                                                        } elseif (!empty($employee['employee_number'])) {
                                                            echo htmlspecialchars($employee['employee_number']);
                                                        } else {
                                                            echo 'EMP' . $employee['id'];
                                                        }
                                                        ?>)
                                                    </span>
                                                </label>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <div class="p-4 text-center text-gray-500 text-sm">
                                                <p>Henüz personel kaydı bulunamadı.</p>
                                                <p class="mt-1">Önce personel eklemelisiniz.</p>
                                                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'super_admin'): ?>
                                                    <div class="mt-3 p-3 bg-red-50 border border-red-200 rounded">
                                                        <p class="text-xs text-red-600 font-medium">
                                                            🔍 Debug: Company ID = <?php echo $_SESSION['company_id'] ?? 'not set'; ?>
                                                        </p>
                                                        <?php if (($_SESSION['company_id'] ?? 0) == 4): ?>
                                                            <a href="../debug/fix-company-4-personnel.php" 
                                                               class="inline-block mt-2 bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-xs">
                                                                🚨 Şirket ID 4 Acil Düzeltme
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if (!empty($employees)): ?>
                                        <div class="mt-2 text-xs text-gray-500">
                                            <button type="button" onclick="checkAllEmployees(true)" class="text-blue-600 hover:text-blue-800">
                                                Tümünü Seç
                                            </button> |
                                            <button type="button" onclick="checkAllEmployees(false)" class="text-blue-600 hover:text-blue-800">
                                                Seçimi Temizle
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Vardiya Şablonu</label>
                                    <select name="shift_template_id" required
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                        <option value="">Vardiya seçin...</option>
                                        <?php foreach ($shiftTemplates as $template): ?>
                                            <option value="<?php echo $template['id']; ?>">
                                                <?php echo htmlspecialchars($template['name']); ?> 
                                                (<?php echo substr($template['start_time'], 0, 5); ?>-<?php echo substr($template['end_time'], 0, 5); ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Başlangıç Tarihi</label>
                                        <input type="date" name="start_date" required
                                               value="<?php echo date('Y-m-d'); ?>"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Bitiş Tarihi</label>
                                        <input type="date" name="end_date" required
                                               value="<?php echo date('Y-m-d', strtotime('+1 month')); ?>"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Çalışma Günleri</label>
                                    <div class="grid grid-cols-7 gap-2">
                                        <?php 
                                        $days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];
                                        for ($i = 1; $i <= 7; $i++): 
                                        ?>
                                            <label class="flex flex-col items-center space-y-1">
                                                <input type="checkbox" name="workdays[]" value="<?php echo $i; ?>"
                                                       <?php echo $i <= 5 ? 'checked' : ''; ?>
                                                       class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                                <span class="text-xs"><?php echo substr($days[$i-1], 0, 3); ?></span>
                                            </label>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <button type="submit" 
                                    class="mt-6 w-full bg-green-600 text-white py-3 px-4 rounded-md hover:bg-green-700 transition-colors">
                                Vardiyaları Ata
                            </button>
                        </form>
                    </div>
                    
                    <!-- Recent Assignments -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-lg font-medium text-gray-900">Son Vardiya Atamaları</h2>
                            <?php if (!empty($recentShifts)): ?>
                                <div class="flex items-center space-x-4">
                                    <label class="flex items-center space-x-2">
                                        <input type="checkbox" id="selectAllShifts" onchange="toggleShiftSelection(this)"
                                               class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                                        <span class="text-sm text-gray-600">Tümünü Seç</span>
                                    </label>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Bulk Actions -->
                        <div id="bulkActions" style="display: none;" class="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                            <div class="flex items-center justify-between">
                                <span class="text-sm text-blue-800">Seçili vardiyalarla işlem yapın:</span>
                                <button onclick="bulkDeleteShifts()" 
                                        class="bg-red-600 text-white px-3 py-1 text-sm rounded hover:bg-red-700">
                                    🗑️ Seçilenleri Sil
                                </button>
                            </div>
                        </div>
                        
                        <div class="space-y-3 max-h-96 overflow-y-auto">
                            <?php if (!empty($recentShifts)): ?>
                                <?php foreach ($recentShifts as $shift): ?>
                                    <div class="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition-colors">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center space-x-3">
                                                <input type="checkbox" class="shift-checkbox rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" 
                                                       value="<?php echo $shift['id']; ?>" 
                                                       onchange="updateBulkActions()">
                                                <div>
                                                    <span class="font-medium text-sm">
                                                        <?php echo htmlspecialchars(($shift['first_name'] ?? '') . ' ' . ($shift['last_name'] ?? '')); ?>
                                                        <span class="text-xs text-gray-500 ml-1">(<?php 
                                                        // Personel yönetimi ile tutarlılık için aynı öncelik sırası
                                                        if (!empty($shift['tc_identity'])) {
                                                            echo htmlspecialchars($shift['tc_identity']);
                                                        } elseif (!empty($shift['employee_code'])) {
                                                            echo htmlspecialchars($shift['employee_code']);
                                                        } elseif (!empty($shift['employee_number'])) {
                                                            echo htmlspecialchars($shift['employee_number']);
                                                        } else {
                                                            echo 'EMP' . ($shift['employee_id'] ?? $shift['id']);
                                                        }
                                                        ?>)</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <span class="text-xs text-gray-500">
                                                <?php echo date('d.m.Y', strtotime($shift['shift_date'] ?? date('Y-m-d'))); ?>
                                            </span>
                                        </div>
                                        <div class="flex items-center space-x-2">
                                            <span class="w-3 h-3 rounded-full" style="background-color: <?php echo htmlspecialchars($shift['color_code'] ?? '#3B82F6'); ?>"></span>
                                            <span class="text-sm text-gray-600">
                                                <?php echo htmlspecialchars($shift['shift_name'] ?? 'Vardiya'); ?>
                                                (<?php echo substr($shift['start_time'] ?? '09:00:00', 0, 5); ?>-<?php echo substr($shift['end_time'] ?? '17:00:00', 0, 5); ?>)
                                            </span>
                                        </div>
                                        <div class="mt-2 flex items-center justify-between">
                                            <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full
                                                <?php 
                                                $status = $shift['status'] ?? 'scheduled';
                                                switch($status) {
                                                    case 'scheduled': echo 'bg-blue-100 text-blue-800'; break;
                                                    case 'completed': echo 'bg-green-100 text-green-800'; break;
                                                    case 'absent': echo 'bg-red-100 text-red-800'; break;
                                                    case 'late': echo 'bg-yellow-100 text-yellow-800'; break;
                                                    case 'early_leave': echo 'bg-purple-100 text-purple-800'; break;
                                                    default: echo 'bg-gray-100 text-gray-800';
                                                }
                                                ?>">
                                                <?php 
                                                switch($status) {
                                                    case 'scheduled': echo 'Planlandı'; break;
                                                    case 'completed': echo 'Tamamlandı'; break;
                                                    case 'absent': echo 'Gelmedi'; break;
                                                    case 'late': echo 'Geç Geldi'; break;
                                                    case 'early_leave': echo 'Erken Çıktı'; break;
                                                    default: echo ucfirst($status);
                                                }
                                                ?>
                                            </span>
                                            
                                            <div class="flex items-center space-x-2">
                                                <?php if (isset($shift['created_at'])): ?>
                                                    <span class="text-xs text-gray-400">
                                                        <?php echo date('H:i', strtotime($shift['created_at'])); ?>
                                                    </span>
                                                <?php endif; ?>
                                                
                                                <!-- Edit and Delete Buttons -->
                                                <div class="flex space-x-1">
                                                    <button onclick="editShiftAssignment(<?php echo htmlspecialchars(json_encode([
                                                        'id' => $shift['id'],
                                                        'employee_id' => $shift['employee_id'],
                                                        'shift_template_id' => $shift['shift_template_id'],
                                                        'shift_date' => $shift['shift_date'],
                                                        'status' => $shift['status'],
                                                        'employee_name' => ($shift['first_name'] ?? '') . ' ' . ($shift['last_name'] ?? ''),
                                                        'shift_name' => $shift['shift_name'] ?? 'Vardiya'
                                                    ])); ?>)"
                                                            class="p-1 text-xs bg-blue-100 text-blue-600 hover:bg-blue-200 rounded"
                                                            title="Düzenle">
                                                        ✏️
                                                    </button>
                                                    
                                                    <button onclick="confirmDeleteShift(<?php echo $shift['id']; ?>, '<?php echo htmlspecialchars(($shift['first_name'] ?? '') . ' ' . ($shift['last_name'] ?? '')); ?>', '<?php echo htmlspecialchars($shift['shift_name'] ?? 'Vardiya'); ?>', '<?php echo $shift['shift_date']; ?>')"
                                                            class="p-1 text-xs bg-red-100 text-red-600 hover:bg-red-200 rounded"
                                                            title="Sil">
                                                        🗑️
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="text-center py-8">
                                    <div class="text-gray-400 text-4xl mb-4">📅</div>
                                    <h3 class="text-lg font-medium text-gray-900 mb-2">Henüz Atama Yapılmadı</h3>
                                    <p class="text-gray-600">Son 30 gün içinde yapılan vardiya atamaları burada görünecek.</p>
                                    <button onclick="window.location.reload()" class="mt-4 text-sm text-blue-600 hover:text-blue-800 underline">
                                        🔄 Yenile
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tab Content: Schedule -->
            <div id="schedule-tab" class="tab-content hidden">
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h2 class="text-lg font-medium text-gray-900">Haftalık Çalışma Programı</h2>
                        <div class="flex items-center space-x-3">
                            <input type="week" id="schedule-week" 
                                   value="<?php echo date('Y-\\WW'); ?>"
                                   class="border border-gray-300 rounded-md px-3 py-2 text-sm"
                                   onchange="loadWeeklySchedule(this.value)">
                            <button onclick="loadWeeklySchedule()" 
                                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm">
                                🔄 Yenile
                            </button>
                        </div>
                    </div>
                    
                    <?php
                    // Get current week or selected week
                    $currentWeek = $_GET['week'] ?? date('Y-\\WW');
                    $year = substr($currentWeek, 0, 4);
                    $week = substr($currentWeek, 6, 2);
                    
                    // Calculate week start and end dates
                    $weekStart = new DateTime();
                    $weekStart->setISODate($year, $week, 1); // Monday
                    $weekEnd = clone $weekStart;
                    $weekEnd->modify('+6 days'); // Sunday
                    
                    // Days of the week in Turkish
                    $turkishDays = [
                        'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'
                    ];
                    
                    // Get all employees with their shift assignments for this week
                    $weeklySchedule = [];
                    if (!empty($employees)) {
                        try {
                            $startDate = $weekStart->format('Y-m-d');
                            $endDate = $weekEnd->format('Y-m-d');
                            
                            foreach ($employees as $employee) {
                                $employeeId = $employee['id'];
                                $employeeName = trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''));
                                if (empty($employeeName)) {
                                    $employeeName = $employee['employee_number'] ?? 'EMP' . $employeeId;
                                }
                                
                                // Initialize employee schedule
                                $weeklySchedule[$employeeId] = [
                                    'name' => $employeeName,
                                    'employee_number' => $employee['employee_number'] ?? 'EMP' . $employeeId,
                                    'shifts' => []
                                ];
                                
                                // Get shift assignments for this week
                                try {
                                    $stmt = $conn->prepare("
                                        SELECT 
                                            es.shift_date,
                                            COALESCE(st.name, 'Vardiya') as shift_name,
                                            COALESCE(st.start_time, '09:00:00') as start_time,
                                            COALESCE(st.end_time, '17:00:00') as end_time,
                                            COALESCE(st.color_code, '#3B82F6') as color_code,
                                            COALESCE(st.break_duration, 60) as break_duration
                                        FROM employee_shifts es
                                        LEFT JOIN shift_templates st ON es.shift_template_id = st.id
                                        WHERE es.employee_id = ? 
                                        AND es.shift_date BETWEEN ? AND ?
                                        ORDER BY es.shift_date
                                    ");
                                    $stmt->execute([$employeeId, $startDate, $endDate]);
                                    $shifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    foreach ($shifts as $shift) {
                                        $weeklySchedule[$employeeId]['shifts'][$shift['shift_date']] = $shift;
                                    }
                                } catch (PDOException $e) {
                                    // Continue with empty shifts for this employee if shift query fails
                                    // Employee will still be displayed in the schedule
                                }
                            }
                        } catch (PDOException $e) {
                            // If employee processing fails, show employees without shifts
                            foreach ($employees as $employee) {
                                $employeeId = $employee['id'];
                                $employeeName = trim(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? ''));
                                if (empty($employeeName)) {
                                    $employeeName = $employee['employee_number'] ?? 'EMP' . $employeeId;
                                }
                                
                                $weeklySchedule[$employeeId] = [
                                    'name' => $employeeName,
                                    'employee_number' => $employee['employee_number'] ?? 'EMP' . $employeeId,
                                    'shifts' => []
                                ];
                            }
                        }
                    }
                    ?>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full border border-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-r border-gray-200">
                                        Personel
                                    </th>
                                    <?php 
                                    $currentDate = clone $weekStart;
                                    for ($i = 0; $i < 7; $i++): 
                                        $dayName = $turkishDays[$i];
                                        $dateStr = $currentDate->format('d/m');
                                        $isWeekend = $i >= 5; // Saturday = 5, Sunday = 6
                                    ?>
                                        <th class="px-3 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-r border-gray-200 <?php echo $isWeekend ? 'bg-red-50' : ''; ?>">
                                            <div><?php echo $dayName; ?></div>
                                            <div class="text-xs text-gray-400"><?php echo $dateStr; ?></div>
                                        </th>
                                    <?php 
                                        $currentDate->modify('+1 day');
                                    endfor; 
                                    ?>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php if (!empty($weeklySchedule)): ?>
                                    <?php foreach ($weeklySchedule as $employeeId => $schedule): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-4 py-4 border-r border-gray-200">
                                                <div class="text-sm font-medium text-gray-900">
                                                    <?php echo htmlspecialchars($schedule['name']); ?>
                                                </div>
                                                <div class="text-xs text-gray-500">
                                                    <?php echo htmlspecialchars($schedule['employee_number']); ?>
                                                </div>
                                            </td>
                                            <?php 
                                            $currentDate = clone $weekStart;
                                            for ($i = 0; $i < 7; $i++): 
                                                $dateStr = $currentDate->format('Y-m-d');
                                                $shift = $schedule['shifts'][$dateStr] ?? null;
                                                $isWeekend = $i >= 5;
                                            ?>
                                                <td class="px-2 py-4 text-center border-r border-gray-200 <?php echo $isWeekend ? 'bg-gray-50' : ''; ?>">
                                                    <?php if ($shift): ?>
                                                        <div class="text-xs p-2 rounded-md text-white" 
                                                             style="background-color: <?php echo htmlspecialchars($shift['color_code']); ?>">
                                                            <div class="font-medium">
                                                                <?php echo htmlspecialchars($shift['shift_name']); ?>
                                                            </div>
                                                            <div class="text-xs opacity-90">
                                                                <?php echo substr($shift['start_time'], 0, 5); ?> - <?php echo substr($shift['end_time'], 0, 5); ?>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="text-xs text-gray-400">
                                                            <?php echo $isWeekend ? 'Hafta sonu' : 'İzinli'; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                            <?php 
                                                $currentDate->modify('+1 day');
                                            endfor; 
                                            ?>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="px-4 py-8 text-center text-gray-500">
                                            <div class="text-center">
                                                <?php if (empty($employees)): ?>
                                                    <p>📋 Personel listesi yüklenemedi.</p>
                                                    <p class="text-sm mt-2">Önce personel eklemelisiniz.</p>
                                                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'super_admin'): ?>
                                                        <div class="mt-2 space-y-1">
                                                            <a href="../debug/fix-company-4-personnel.php" 
                                                               class="inline-block text-red-600 hover:text-red-800 text-sm underline">
                                                                🚨 Şirket ID 4 Özel Düzeltme
                                                            </a>
                                                            <br>
                                                            <a href="../debug/fix-shift-employee-list.php" 
                                                               class="inline-block text-blue-600 hover:text-blue-800 text-sm underline">
                                                                🔧 Genel Personel Listesi Düzeltme
                                                            </a>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <p>📅 Bu hafta için henüz vardiya ataması yapılmamış.</p>
                                                    <p class="text-sm mt-2">"Vardiya Atamaları" sekmesinden atama yapabilirsiniz.</p>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Schedule Legend -->
                    <div class="mt-6 border-t pt-4">
                        <h3 class="text-sm font-medium text-gray-900 mb-3">Renk Açıklaması</h3>
                        <div class="flex flex-wrap gap-4">
                            <?php if (!empty($shiftTemplates)): ?>
                                <?php foreach ($shiftTemplates as $template): ?>
                                    <div class="flex items-center space-x-2">
                                        <div class="w-4 h-4 rounded" style="background-color: <?php echo htmlspecialchars($template['color_code']); ?>"></div>
                                        <span class="text-sm text-gray-700">
                                            <?php echo htmlspecialchars($template['name']); ?>
                                            (<?php echo substr($template['start_time'] ?? '09:00', 0, 5); ?>-<?php echo substr($template['end_time'] ?? '17:00', 0, 5); ?>)
                                        </span>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            <div class="flex items-center space-x-2">
                                <div class="w-4 h-4 rounded bg-gray-200"></div>
                                <span class="text-sm text-gray-700">İzinli / Tatil</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Summary Stats -->
                    <div class="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <div class="text-sm font-medium text-blue-800">Toplam Personel</div>
                            <div class="text-2xl font-bold text-blue-900"><?php echo count($employees); ?></div>
                        </div>
                        <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                            <div class="text-sm font-medium text-green-800">Aktif Vardiyalar</div>
                            <div class="text-2xl font-bold text-green-900">
                                <?php 
                                $totalShifts = 0;
                                foreach ($weeklySchedule as $schedule) {
                                    $totalShifts += count($schedule['shifts']);
                                }
                                echo $totalShifts;
                                ?>
                            </div>
                        </div>
                        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                            <div class="text-sm font-medium text-yellow-800">Hafta Dönemi</div>
                            <div class="text-sm font-bold text-yellow-900">
                                <?php echo $weekStart->format('d.m.Y'); ?> - <?php echo $weekEnd->format('d.m.Y'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script>
        // Tab switching
        function showTab(tabName) {
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('border-indigo-500', 'text-indigo-600');
                btn.classList.add('border-transparent', 'text-gray-500');
            });
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            document.getElementById(tabName + '-tab').classList.remove('hidden');
            
            // Update button styling
            const activeButton = document.querySelector(`[onclick="showTab('${tabName}')"]`);
            if (activeButton) {
                activeButton.classList.remove('border-transparent', 'text-gray-500');
                activeButton.classList.add('border-indigo-500', 'text-indigo-600');
            }
        }
        
        // Weekly schedule loading
        function loadWeeklySchedule(week) {
            if (week) {
                const url = new URL(window.location);
                url.searchParams.set('week', week);
                window.location.href = url.toString();
            } else {
                window.location.reload();
            }
        }
        
        // Employee selection functions
        function checkAllEmployees(check) {
            const checkboxes = document.querySelectorAll('input[name="employee_ids[]"]');
            checkboxes.forEach(cb => cb.checked = check);
        }
        
        // Edit template modal functions
        function editShiftTemplate(template) {
            document.getElementById('edit_template_id').value = template.id;
            document.getElementById('edit_name').value = template.name;
            document.getElementById('edit_start_time').value = template.start_time;
            document.getElementById('edit_end_time').value = template.end_time;
            document.getElementById('edit_break_duration').value = template.break_duration;
            document.getElementById('edit_description').value = template.description || '';
            
            document.getElementById('editTemplateModal').classList.remove('hidden');
        }
        
        function closeEditModal() {
            document.getElementById('editTemplateModal').classList.add('hidden');
        }
        
        // Close modal when clicking outside
        document.getElementById('editTemplateModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeEditModal();
            }
        });
        
        // Edit shift assignment modal functions
        function editShiftAssignment(shiftData) {
            document.getElementById('edit_shift_assignment_id').value = shiftData.id;
            document.getElementById('edit_employee_id').value = shiftData.employee_id;
            document.getElementById('edit_shift_template_id').value = shiftData.shift_template_id;
            document.getElementById('edit_shift_date').value = shiftData.shift_date;
            document.getElementById('edit_status').value = shiftData.status;
            
            document.getElementById('editShiftModal').classList.remove('hidden');
        }
        
        function closeEditShiftModal() {
            document.getElementById('editShiftModal').classList.add('hidden');
        }
        
        // Delete confirmation modal functions
        function confirmDeleteShift(shiftId, employeeName, shiftName, shiftDate) {
            document.getElementById('delete_shift_assignment_id').value = shiftId;
            document.getElementById('deleteMessage').innerHTML = 
                `<strong>${employeeName}</strong> personelinin <strong>${shiftDate}</strong> tarihindeki <strong>${shiftName}</strong> vardiya atamasını silmek istediğinizden emin misiniz?<br><br>Bu işlem geri alınamaz.`;
            
            document.getElementById('deleteConfirmModal').classList.remove('hidden');
        }
        
        function closeDeleteModal() {
            document.getElementById('deleteConfirmModal').classList.add('hidden');
        }
        
        // Close modals when clicking outside
        document.getElementById('editShiftModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeEditShiftModal();
            }
        });
        
        document.getElementById('deleteConfirmModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeDeleteModal();
            }
        });
        
        // Bulk operations for shift assignments
        function toggleShiftSelection(checkbox) {
            const shiftCheckboxes = document.querySelectorAll('.shift-checkbox');
            shiftCheckboxes.forEach(cb => {
                cb.checked = checkbox.checked;
            });
            updateBulkActions();
        }
        
        function updateBulkActions() {
            const checkedBoxes = document.querySelectorAll('.shift-checkbox:checked');
            const bulkActions = document.getElementById('bulkActions');
            if (bulkActions) {
                bulkActions.style.display = checkedBoxes.length > 0 ? 'block' : 'none';
            }
            
            // Update master checkbox state
            const masterCheckbox = document.getElementById('selectAllShifts');
            const totalCheckboxes = document.querySelectorAll('.shift-checkbox');
            if (masterCheckbox) {
                masterCheckbox.checked = checkedBoxes.length === totalCheckboxes.length && totalCheckboxes.length > 0;
            }
        }
        
        function bulkDeleteShifts() {
            const checkedBoxes = document.querySelectorAll('.shift-checkbox:checked');
            if (checkedBoxes.length === 0) {
                alert('Lütfen silinecek vardiyaları seçin.');
                return;
            }
            
            if (confirm(`${checkedBoxes.length} vardiya atamasını silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = '<input type="hidden" name="action" value="bulk_delete_shifts">';
                
                checkedBoxes.forEach(checkbox => {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'shift_ids[]';
                    input.value = checkbox.value;
                    form.appendChild(input);
                });
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Initialize first tab
        document.addEventListener('DOMContentLoaded', function() {
            showTab('templates');
        });
    </script>
</body>
</html>