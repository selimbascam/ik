<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../auth/company-login.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 1;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İzin Yönetimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 py-6">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">İzin Yönetimi</h1>
                    <a href="../dashboard/company-dashboard.php" class="text-blue-600 hover:text-blue-800">← Dashboard'a Dön</a>
                </div>
            </div>
        </header>

        <main class="max-w-7xl mx-auto px-4 py-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">🏖️</div>
                    <h2 class="text-xl font-semibold mb-2">İzin Yönetimi</h2>
                    <p class="text-gray-600 mb-6">İzin talepleri ve onay süreçleri</p>
                    <div class="text-sm text-gray-500">Bu özellik yakında aktif olacak</div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>