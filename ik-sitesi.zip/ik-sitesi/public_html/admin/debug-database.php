<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "<h1>Database Debug</h1>";

if (!isset($_SESSION['company_id'])) {
    echo "<p>No session - please login first</p>";
    exit();
}

echo "<p>Company ID: " . $_SESSION['company_id'] . "</p>";

try {
    require_once '../includes/database.php';
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>✅ Database Connection Success</h2>";
    
    // Test query - recent QR locations
    $stmt = $conn->prepare("SELECT id, name, location_type, created_at FROM qr_locations WHERE company_id = ? ORDER BY id DESC LIMIT 5");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll();
    
    echo "<h2>Recent QR Locations:</h2>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th><th>Type</th><th>Created</th></tr>";
    
    foreach ($locations as $loc) {
        echo "<tr>";
        echo "<td>" . $loc['id'] . "</td>";
        echo "<td>" . htmlspecialchars($loc['name']) . "</td>";
        echo "<td>" . htmlspecialchars($loc['location_type']) . "</td>";
        echo "<td>" . ($loc['created_at'] ?? 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Auto-fix empty location types
    if ($_POST['auto_fix'] ?? false) {
        // Define the function inline since we can't include the full generator
        function detectLocationTypeFromName($name, $current_type) {
            $name_lower = strtolower(trim($name));
            
            // Çıkış patterns
            if (strpos($name_lower, 'çıkış') !== false || strpos($name_lower, 'exit') !== false) {
                return 'check_out';
            } 
            // Giriş patterns  
            elseif (strpos($name_lower, 'giriş') !== false || strpos($name_lower, 'entrance') !== false) {
                return 'check_in';
            } 
            // Çay molası patterns
            elseif (strpos($name_lower, 'çay') !== false || strpos($name_lower, 'tea') !== false) {
                return 'tea_break';
            } 
            // Yemek molası patterns
            elseif (strpos($name_lower, 'yemek') !== false || strpos($name_lower, 'lunch') !== false) {
                return 'lunch_break';
            } 
            // Sigara molası patterns
            elseif (strpos($name_lower, 'sigara') !== false || strpos($name_lower, 'smoke') !== false) {
                return 'smoke_break';
            }
            // Genel mola patterns - en yaygın kullanım
            elseif (strpos($name_lower, 'mola') !== false || strpos($name_lower, 'break') !== false || 
                    strpos($name_lower, 'ara') !== false || strpos($name_lower, 'dinlenme') !== false) {
                return 'tea_break'; // Default olarak çay molası
            }
            
            return $current_type; // Değişiklik yok
        }
        
        echo "<h2>Auto-Fix Empty Types:</h2>";
        
        $empty_stmt = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE company_id = ? AND (location_type = '' OR location_type IS NULL)");
        $empty_stmt->execute([$_SESSION['company_id']]);
        $empty_locations = $empty_stmt->fetchAll();
        
        foreach ($empty_locations as $loc) {
            $detected_type = detectLocationTypeFromName($loc['name'], 'general_gate');
            
            echo "<p>ID {$loc['id']}: '{$loc['name']}' → {$detected_type}</p>";
            
            // Debug: Show current values
            echo "<p style='margin-left: 10px; color: blue;'>Debug: Current type='{$loc['location_type']}', Company={$_SESSION['company_id']}</p>";
            
            $fix_stmt = $conn->prepare("UPDATE qr_locations SET location_type = ? WHERE id = ? AND company_id = ?");
            $fix_result = $fix_stmt->execute([$detected_type, $loc['id'], $_SESSION['company_id']]);
            
            // Try to get affected rows in a compatible way
            $fix_affected = 0;
            if (method_exists($fix_stmt, 'rowCount')) {
                $fix_affected = $fix_stmt->rowCount();
            } else if (property_exists($conn, 'mysqli') && isset($conn->mysqli)) {
                $fix_affected = $conn->mysqli->affected_rows;
            }
            
            echo "<p style='margin-left: 20px;'>Debug: Result=" . ($fix_result ? 'TRUE' : 'FALSE') . ", Affected={$fix_affected}</p>";
            echo "<p style='margin-left: 20px;'>→ " . ($fix_result && $fix_affected > 0 ? '✅ FIXED' : '❌ FAILED') . "</p>";
        }
        
        echo "<p><strong>Refresh page to see results!</strong></p>";
    }

    // Test update query
    if ($_POST['test_update'] ?? false) {
        $test_id = intval($_POST['test_id']);
        $new_type = $_POST['new_type'];
        
        echo "<h2>Update Test:</h2>";
        echo "<p>Trying to update ID {$test_id} to {$new_type}</p>";
        
        $update_stmt = $conn->prepare("UPDATE qr_locations SET location_type = ? WHERE id = ? AND company_id = ?");
        $result = $update_stmt->execute([$new_type, $test_id, $_SESSION['company_id']]);
        $affected = $update_stmt->rowCount();
        
        echo "<p>Result: " . ($result ? 'SUCCESS' : 'FAILED') . "</p>";
        echo "<p>Affected rows: {$affected}</p>";
    }
    
    // Auto-fix form
    echo "<h2>🔧 Auto-Fix Empty Types:</h2>";
    echo "<form method='POST'>";
    echo "<input type='hidden' name='auto_fix' value='1'>";
    echo "<button type='submit' style='background: orange; color: white; padding: 10px; font-size: 16px;'>🚀 Fix All Empty Types</button>";
    echo "</form>";

    // Test form
    if (!empty($locations)) {
        $first_loc = $locations[0];
        echo "<h2>Test Update Form:</h2>";
        echo "<form method='POST'>";
        echo "<input type='hidden' name='test_update' value='1'>";
        echo "<input type='hidden' name='test_id' value='{$first_loc['id']}'>";
        echo "<select name='new_type'>";
        echo "<option value='check_in'>check_in</option>";
        echo "<option value='check_out'>check_out</option>";
        echo "<option value='tea_break'>tea_break</option>";
        echo "</select>";
        echo "<button type='submit'>Test Update ID {$first_loc['id']}</button>";
        echo "</form>";
    }
    
} catch (Exception $e) {
    echo "<h2>❌ Error: " . $e->getMessage() . "</h2>";
}
?>