<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $message = '';
    $messageType = '';
    
    // Get company info
    $companyId = $_SESSION['company_id'] ?? 1;
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'set_company_holidays') {
            try {
                $selectedDays = $_POST['holiday_days'] ?? [];
                
                if (empty($selectedDays)) {
                    throw new Exception("Lütfen en az bir tatil günü seçin");
                }
                
                // Check if table exists, if not create it
                $checkTable = $conn->query("SHOW TABLES LIKE 'employee_weekly_holidays'");
                if ($checkTable->rowCount() === 0) {
                    $conn->exec("
                        CREATE TABLE employee_weekly_holidays (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            employee_id INT NOT NULL,
                            company_id INT NOT NULL,
                            monday BOOLEAN DEFAULT 0,
                            tuesday BOOLEAN DEFAULT 0,
                            wednesday BOOLEAN DEFAULT 0,
                            thursday BOOLEAN DEFAULT 0,
                            friday BOOLEAN DEFAULT 0,
                            saturday BOOLEAN DEFAULT 1,
                            sunday BOOLEAN DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                            UNIQUE KEY unique_employee (employee_id)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                }
                
                // Get all employees in the company
                $stmt = $conn->prepare("SELECT id, first_name, last_name FROM employees WHERE company_id = ? ORDER BY first_name");
                $stmt->execute([$companyId]);
                $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $assignedCount = 0;
                foreach ($employees as $employee) {
                    // Prepare day values
                    $dayValues = [
                        'monday' => in_array('1', $selectedDays) ? 1 : 0,
                        'tuesday' => in_array('2', $selectedDays) ? 1 : 0,
                        'wednesday' => in_array('3', $selectedDays) ? 1 : 0,
                        'thursday' => in_array('4', $selectedDays) ? 1 : 0,
                        'friday' => in_array('5', $selectedDays) ? 1 : 0,
                        'saturday' => in_array('6', $selectedDays) ? 1 : 0,
                        'sunday' => in_array('0', $selectedDays) ? 1 : 0
                    ];
                    
                    // Insert or update employee holidays
                    $stmt = $conn->prepare("
                        INSERT INTO employee_weekly_holidays 
                        (employee_id, company_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE
                        monday = VALUES(monday),
                        tuesday = VALUES(tuesday),
                        wednesday = VALUES(wednesday),
                        thursday = VALUES(thursday),
                        friday = VALUES(friday),
                        saturday = VALUES(saturday),
                        sunday = VALUES(sunday),
                        updated_at = CURRENT_TIMESTAMP
                    ");
                    
                    $stmt->execute([
                        $employee['id'],
                        $companyId,
                        $dayValues['monday'],
                        $dayValues['tuesday'],
                        $dayValues['wednesday'],
                        $dayValues['thursday'],
                        $dayValues['friday'],
                        $dayValues['saturday'],
                        $dayValues['sunday']
                    ]);
                    
                    $assignedCount++;
                }
                
                // Update existing shifts to respect new holiday settings
                $stmt = $conn->prepare("
                    DELETE es FROM employee_shifts es 
                    INNER JOIN employee_weekly_holidays ewh ON es.employee_id = ewh.employee_id
                    WHERE es.shift_date >= CURDATE() 
                    AND es.shift_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                    AND (
                        (DAYOFWEEK(es.shift_date) = 2 AND ewh.monday = 1) OR
                        (DAYOFWEEK(es.shift_date) = 3 AND ewh.tuesday = 1) OR
                        (DAYOFWEEK(es.shift_date) = 4 AND ewh.wednesday = 1) OR
                        (DAYOFWEEK(es.shift_date) = 5 AND ewh.thursday = 1) OR
                        (DAYOFWEEK(es.shift_date) = 6 AND ewh.friday = 1) OR
                        (DAYOFWEEK(es.shift_date) = 7 AND ewh.saturday = 1) OR
                        (DAYOFWEEK(es.shift_date) = 1 AND ewh.sunday = 1)
                    )
                    AND ewh.company_id = ?
                ");
                $stmt->execute([$companyId]);
                $removedShifts = $stmt->rowCount();
                
                $dayNames = [
                    '1' => 'Pazartesi',
                    '2' => 'Salı', 
                    '3' => 'Çarşamba',
                    '4' => 'Perşembe',
                    '5' => 'Cuma',
                    '6' => 'Cumartesi',
                    '0' => 'Pazar'
                ];
                
                $selectedDayNames = array_map(function($day) use ($dayNames) {
                    return $dayNames[$day];
                }, $selectedDays);
                
                $message = "✅ Şirket tatil günleri başarıyla güncellendi!<br>" . 
                          "📅 Tatil günleri: " . implode(', ', $selectedDayNames) . "<br>" .
                          "👥 Güncellenen personel sayısı: $assignedCount<br>" .
                          "🗑️ Tatil günlerindeki vardiya atamaları silindi: $removedShifts";
                $messageType = "success";
                
            } catch (Exception $e) {
                $message = "❌ Tatil günleri güncellenirken hata oluştu: " . $e->getMessage();
                $messageType = "error";
            }
        }
        
        if ($action === 'regenerate_shifts') {
            try {
                // Ensure shift_templates table exists
                $checkTable = $conn->query("SHOW TABLES LIKE 'shift_templates'");
                if ($checkTable->rowCount() === 0) {
                    $conn->exec("
                        CREATE TABLE shift_templates (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            name VARCHAR(100) NOT NULL,
                            start_time TIME NOT NULL,
                            end_time TIME NOT NULL,
                            break_duration INT DEFAULT 60,
                            is_active BOOLEAN DEFAULT 1,
                            color_code VARCHAR(7) DEFAULT '#3B82F6',
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    
                    // Add default shift templates
                    $conn->exec("
                        INSERT INTO shift_templates (name, start_time, end_time, break_duration, color_code) VALUES
                        ('Sabah Vardiyası', '09:30:00', '19:30:00', 60, '#3B82F6'),
                        ('Gece Vardiyası', '22:00:00', '08:00:00', 60, '#7C3AED'),
                        ('Öğle Vardiyası', '13:00:00', '23:00:00', 60, '#059669')
                    ");
                }
                
                // Get 09:30-19:30 shift template
                $stmt = $conn->prepare("
                    SELECT id FROM shift_templates 
                    WHERE start_time = '09:30:00' AND end_time = '19:30:00' 
                    AND is_active = 1
                    LIMIT 1
                ");
                $stmt->execute();
                $template = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$template) {
                    throw new Exception("09:30-19:30 vardiya şablonu bulunamadı. Önce vardiya şablonu oluşturun.");
                }
                
                $templateId = $template['id'];
                
                // Get all employees with their holiday settings
                $stmt = $conn->prepare("
                    SELECT 
                        e.id as employee_id,
                        e.first_name,
                        e.last_name,
                        COALESCE(ewh.monday, 0) as monday_holiday,
                        COALESCE(ewh.tuesday, 0) as tuesday_holiday,
                        COALESCE(ewh.wednesday, 0) as wednesday_holiday,
                        COALESCE(ewh.thursday, 0) as thursday_holiday,
                        COALESCE(ewh.friday, 0) as friday_holiday,
                        COALESCE(ewh.saturday, 1) as saturday_holiday,
                        COALESCE(ewh.sunday, 1) as sunday_holiday
                    FROM employees e
                    LEFT JOIN employee_weekly_holidays ewh ON e.id = ewh.employee_id
                    WHERE e.company_id = ?
                    ORDER BY e.first_name
                ");
                $stmt->execute([$companyId]);
                $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // Clear existing future shifts
                $stmt = $conn->prepare("
                    DELETE FROM employee_shifts 
                    WHERE employee_id IN (SELECT id FROM employees WHERE company_id = ?)
                    AND shift_date >= CURDATE() 
                    AND shift_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                ");
                $stmt->execute([$companyId]);
                $deletedCount = $stmt->rowCount();
                
                $totalAssigned = 0;
                $employeeDetails = [];
                
                foreach ($employees as $employee) {
                    $employeeAssigned = 0;
                    
                    // Generate shifts for next 30 days
                    for ($i = 0; $i < 30; $i++) {
                        $date = date('Y-m-d', strtotime("+$i day"));
                        $dayOfWeek = date('N', strtotime($date)); // 1=Monday, 7=Sunday
                        
                        $isHoliday = false;
                        switch ($dayOfWeek) {
                            case 1: $isHoliday = (bool)$employee['monday_holiday']; break;
                            case 2: $isHoliday = (bool)$employee['tuesday_holiday']; break;
                            case 3: $isHoliday = (bool)$employee['wednesday_holiday']; break;
                            case 4: $isHoliday = (bool)$employee['thursday_holiday']; break;
                            case 5: $isHoliday = (bool)$employee['friday_holiday']; break;
                            case 6: $isHoliday = (bool)$employee['saturday_holiday']; break;
                            case 7: $isHoliday = (bool)$employee['sunday_holiday']; break;
                        }
                        
                        // Only assign shift if it's not a holiday
                        if (!$isHoliday) {
                            $stmt = $conn->prepare("
                                INSERT INTO employee_shifts 
                                (employee_id, shift_template_id, shift_date, status) 
                                VALUES (?, ?, ?, 'scheduled')
                            ");
                            $stmt->execute([$employee['employee_id'], $templateId, $date]);
                            $employeeAssigned++;
                            $totalAssigned++;
                        }
                    }
                    
                    $employeeDetails[] = $employee['first_name'] . " " . $employee['last_name'] . ": $employeeAssigned gün";
                }
                
                $message = "✅ Vardiyalar tatil ayarlarına göre yeniden oluşturuldu!<br>" .
                          "🗑️ Silinen eski vardiya: $deletedCount<br>" .
                          "📅 Yeni atanan vardiya: $totalAssigned<br>" .
                          "👥 Personel detayları:<br>" . implode('<br>', $employeeDetails);
                $messageType = "success";
                
            } catch (Exception $e) {
                $message = "❌ Vardiya yeniden oluşturma hatası: " . $e->getMessage();
                $messageType = "error";
            }
        }
    }
    
    // Get current holiday settings
    $stmt = $conn->prepare("
        SELECT 
            COUNT(CASE WHEN monday = 1 THEN 1 END) as monday_count,
            COUNT(CASE WHEN tuesday = 1 THEN 1 END) as tuesday_count,
            COUNT(CASE WHEN wednesday = 1 THEN 1 END) as wednesday_count,
            COUNT(CASE WHEN thursday = 1 THEN 1 END) as thursday_count,
            COUNT(CASE WHEN friday = 1 THEN 1 END) as friday_count,
            COUNT(CASE WHEN saturday = 1 THEN 1 END) as saturday_count,
            COUNT(CASE WHEN sunday = 1 THEN 1 END) as sunday_count,
            COUNT(*) as total_employees
        FROM employee_weekly_holidays ewh
        INNER JOIN employees e ON ewh.employee_id = e.id
        WHERE e.company_id = ?
    ");
    $stmt->execute([$companyId]);
    $currentSettings = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get total employees
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE company_id = ?");
    $stmt->execute([$companyId]);
    $totalEmployees = $stmt->fetch()['count'];
    
} catch (Exception $e) {
    $error = "Tatil yönetimi yüklenirken hata oluştu: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Tatil Yönetimi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .day-selector.selected {
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white;
            border-color: #1d4ed8;
            transform: scale(1.05);
        }
        
        .day-selector:hover {
            transform: translateY(-2px);
        }
        
        .day-selector {
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <h1 class="text-2xl font-bold text-gray-900">🏢 Şirket Tatil Yönetimi</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                        ← Admin Panel
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="max-w-6xl mx-auto py-8 px-4">
        <?php if (isset($error)): ?>
            <div class="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-800">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Current Status -->
        <?php if ($currentSettings && $currentSettings['total_employees'] > 0): ?>
            <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
                <h2 class="text-xl font-bold text-gray-900 mb-4">📊 Mevcut Tatil Durumu</h2>
                
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
                    <div class="text-center">
                        <div class="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center 
                                    <?php echo $currentSettings['monday_count'] > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'; ?>">
                            <span class="text-sm font-bold"><?php echo $currentSettings['monday_count']; ?></span>
                        </div>
                        <div class="text-sm font-medium">Pazartesi</div>
                        <div class="text-xs text-gray-500"><?php echo $currentSettings['monday_count']; ?>/<?php echo $totalEmployees; ?></div>
                    </div>
                    <div class="text-center">
                        <div class="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center 
                                    <?php echo $currentSettings['tuesday_count'] > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'; ?>">
                            <span class="text-sm font-bold"><?php echo $currentSettings['tuesday_count']; ?></span>
                        </div>
                        <div class="text-sm font-medium">Salı</div>
                        <div class="text-xs text-gray-500"><?php echo $currentSettings['tuesday_count']; ?>/<?php echo $totalEmployees; ?></div>
                    </div>
                    <div class="text-center">
                        <div class="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center 
                                    <?php echo $currentSettings['wednesday_count'] > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'; ?>">
                            <span class="text-sm font-bold"><?php echo $currentSettings['wednesday_count']; ?></span>
                        </div>
                        <div class="text-sm font-medium">Çarşamba</div>
                        <div class="text-xs text-gray-500"><?php echo $currentSettings['wednesday_count']; ?>/<?php echo $totalEmployees; ?></div>
                    </div>
                    <div class="text-center">
                        <div class="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center 
                                    <?php echo $currentSettings['thursday_count'] > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'; ?>">
                            <span class="text-sm font-bold"><?php echo $currentSettings['thursday_count']; ?></span>
                        </div>
                        <div class="text-sm font-medium">Perşembe</div>
                        <div class="text-xs text-gray-500"><?php echo $currentSettings['thursday_count']; ?>/<?php echo $totalEmployees; ?></div>
                    </div>
                    <div class="text-center">
                        <div class="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center 
                                    <?php echo $currentSettings['friday_count'] > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'; ?>">
                            <span class="text-sm font-bold"><?php echo $currentSettings['friday_count']; ?></span>
                        </div>
                        <div class="text-sm font-medium">Cuma</div>
                        <div class="text-xs text-gray-500"><?php echo $currentSettings['friday_count']; ?>/<?php echo $totalEmployees; ?></div>
                    </div>
                    <div class="text-center">
                        <div class="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center 
                                    <?php echo $currentSettings['saturday_count'] > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'; ?>">
                            <span class="text-sm font-bold"><?php echo $currentSettings['saturday_count']; ?></span>
                        </div>
                        <div class="text-sm font-medium">Cumartesi</div>
                        <div class="text-xs text-gray-500"><?php echo $currentSettings['saturday_count']; ?>/<?php echo $totalEmployees; ?></div>
                    </div>
                    <div class="text-center">
                        <div class="w-16 h-16 mx-auto mb-2 rounded-full flex items-center justify-center 
                                    <?php echo $currentSettings['sunday_count'] > 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'; ?>">
                            <span class="text-sm font-bold"><?php echo $currentSettings['sunday_count']; ?></span>
                        </div>
                        <div class="text-sm font-medium">Pazar</div>
                        <div class="text-xs text-gray-500"><?php echo $currentSettings['sunday_count']; ?>/<?php echo $totalEmployees; ?></div>
                    </div>
                </div>
                
                <div class="text-center text-sm text-gray-600">
                    <span class="inline-flex items-center space-x-2">
                        <span class="w-3 h-3 bg-red-100 rounded-full"></span>
                        <span>Tatil Günü</span>
                    </span>
                    <span class="mx-4">|</span>
                    <span class="inline-flex items-center space-x-2">
                        <span class="w-3 h-3 bg-green-100 rounded-full"></span>
                        <span>Çalışma Günü</span>
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Holiday Setting Form -->
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">🏖️ Şirket Tatil Günleri Belirleme</h2>
            <p class="text-gray-600 mb-8">Şirketiniz için haftalık tatil günlerini belirleyin. Bu ayar tüm personellerin vardiya programını etkileyecektir.</p>
            
            <form method="POST" id="holidayForm">
                <input type="hidden" name="action" value="set_company_holidays">
                
                <!-- Day Selection -->
                <div class="mb-8">
                    <label class="block text-lg font-medium text-gray-700 mb-4">Haftalık Tatil Günleri:</label>
                    
                    <div class="bg-blue-50 rounded-lg p-4 mb-6">
                        <div class="flex items-center mb-2">
                            <span class="text-blue-600 text-sm font-medium">ℹ️ Önemli Bilgi:</span>
                        </div>
                        <p class="text-blue-800 text-sm">Seçilen günler, tüm personeller için tatil günü olacaktır. Bu günlerde vardiya ataması yapılmayacak ve personeller çalışmayacaktır.</p>
                    </div>
                    
                    <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                        <label class="day-selector cursor-pointer border-2 rounded-xl p-4 text-center hover:shadow-md transition-all">
                            <input type="checkbox" name="holiday_days[]" value="1" class="hidden" onchange="toggleDaySelector(this)">
                            <div class="text-2xl mb-2">📅</div>
                            <div class="font-medium">Pazartesi</div>
                        </label>
                        
                        <label class="day-selector cursor-pointer border-2 rounded-xl p-4 text-center hover:shadow-md transition-all">
                            <input type="checkbox" name="holiday_days[]" value="2" class="hidden" onchange="toggleDaySelector(this)">
                            <div class="text-2xl mb-2">📅</div>
                            <div class="font-medium">Salı</div>
                        </label>
                        
                        <label class="day-selector cursor-pointer border-2 rounded-xl p-4 text-center hover:shadow-md transition-all">
                            <input type="checkbox" name="holiday_days[]" value="3" class="hidden" onchange="toggleDaySelector(this)">
                            <div class="text-2xl mb-2">📅</div>
                            <div class="font-medium">Çarşamba</div>
                        </label>
                        
                        <label class="day-selector cursor-pointer border-2 rounded-xl p-4 text-center hover:shadow-md transition-all">
                            <input type="checkbox" name="holiday_days[]" value="4" class="hidden" onchange="toggleDaySelector(this)">
                            <div class="text-2xl mb-2">📅</div>
                            <div class="font-medium">Perşembe</div>
                        </label>
                        
                        <label class="day-selector cursor-pointer border-2 rounded-xl p-4 text-center hover:shadow-md transition-all">
                            <input type="checkbox" name="holiday_days[]" value="5" class="hidden" onchange="toggleDaySelector(this)">
                            <div class="text-2xl mb-2">📅</div>
                            <div class="font-medium">Cuma</div>
                        </label>
                        
                        <label class="day-selector cursor-pointer border-2 rounded-xl p-4 text-center hover:shadow-md transition-all selected">
                            <input type="checkbox" name="holiday_days[]" value="6" class="hidden" checked onchange="toggleDaySelector(this)">
                            <div class="text-2xl mb-2">🏖️</div>
                            <div class="font-medium">Cumartesi</div>
                        </label>
                        
                        <label class="day-selector cursor-pointer border-2 rounded-xl p-4 text-center hover:shadow-md transition-all selected">
                            <input type="checkbox" name="holiday_days[]" value="0" class="hidden" checked onchange="toggleDaySelector(this)">
                            <div class="text-2xl mb-2">🏖️</div>
                            <div class="font-medium">Pazar</div>
                        </label>
                    </div>
                    
                    <div class="mt-6 text-center space-x-4">
                        <button type="button" onclick="selectWeekend()" class="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors">
                            Sadece Hafta Sonu
                        </button>
                        <button type="button" onclick="selectWorkDays()" class="px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors">
                            Hafta İçi Seç
                        </button>
                        <button type="button" onclick="clearAll()" class="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors">
                            Temizle
                        </button>
                    </div>
                </div>
                
                <div class="flex space-x-4">
                    <button type="submit" class="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                        🏢 Şirket Tatil Günlerini Kaydet
                    </button>
                </div>
            </form>
            
            <!-- Regenerate Shifts -->
            <div class="mt-8 p-4 border border-orange-200 bg-orange-50 rounded-lg">
                <h3 class="font-bold text-orange-900 mb-2">⚠️ Vardiya Yenileme</h3>
                <p class="text-orange-800 text-sm mb-4">Tatil günlerini güncelledikten sonra, mevcut vardiya programını yeniden oluşturmanız önerilir.</p>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="regenerate_shifts">
                    <button type="submit" class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors"
                            onclick="return confirm('Mevcut vardiya programı silinip yeniden oluşturulacak. Onaylıyor musunuz?')">
                        🔄 Vardiyaları Yeniden Oluştur
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function toggleDaySelector(checkbox) {
            const label = checkbox.closest('label');
            const emoji = label.querySelector('div:first-of-type');
            
            if (checkbox.checked) {
                label.classList.add('selected');
                emoji.textContent = '🏖️';
            } else {
                label.classList.remove('selected');
                emoji.textContent = '📅';
            }
        }
        
        function selectWeekend() {
            // Clear all first
            clearAll();
            // Select only Saturday (6) and Sunday (0)
            const checkboxes = document.querySelectorAll('input[name="holiday_days[]"]');
            checkboxes.forEach(cb => {
                if (cb.value === '6' || cb.value === '0') {
                    cb.checked = true;
                    toggleDaySelector(cb);
                }
            });
        }
        
        function selectWorkDays() {
            // Clear all first
            clearAll();
            // Select Monday to Friday (1-5)
            const checkboxes = document.querySelectorAll('input[name="holiday_days[]"]');
            checkboxes.forEach(cb => {
                if (['1', '2', '3', '4', '5'].includes(cb.value)) {
                    cb.checked = true;
                    toggleDaySelector(cb);
                }
            });
        }
        
        function clearAll() {
            const checkboxes = document.querySelectorAll('input[name="holiday_days[]"]');
            checkboxes.forEach(cb => {
                cb.checked = false;
                toggleDaySelector(cb);
            });
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('input[name="holiday_days[]"]');
            checkboxes.forEach(cb => {
                if (cb.checked) {
                    toggleDaySelector(cb);
                }
            });
        });
    </script>
</body>
</html>