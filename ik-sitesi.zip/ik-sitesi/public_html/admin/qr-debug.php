<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/attendance-helper.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$employeeId = $_GET['emp'] ?? 1; // Test için employee ID
$locationId = $_GET['loc'] ?? null;

echo "<h1>QR Debug - Employee ID: $employeeId</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get current attendance record
    $today = date('Y-m-d');
    $stmt = $conn->prepare("SELECT * FROM attendance_records WHERE employee_id = ? AND date = ?");
    $stmt->execute([$employeeId, $today]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h2>📋 Bugünkü Kayıtlar</h2>";
    if ($record) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Alan</th><th>Değer</th></tr>";
        foreach ($record as $key => $value) {
            echo "<tr><td>$key</td><td>" . ($value ?: 'NULL') . "</td></tr>";
        }
        echo "</table>";
        
        echo "<h3>Durum Özeti:</h3>";
        echo "<ul>";
        echo "<li>Giriş: " . ($record['check_in'] ? "✅ " . $record['check_in'] : "❌ Yok") . "</li>";
        echo "<li>Mola Başlangıç: " . ($record['break_start'] ? "✅ " . $record['break_start'] : "❌ Yok") . "</li>";
        echo "<li>Mola Bitiş: " . ($record['break_end'] ? "✅ " . $record['break_end'] : "❌ Yok") . "</li>";
        echo "<li>Çıkış: " . ($record['check_out'] ? "✅ " . $record['check_out'] : "❌ Yok") . "</li>";
        echo "</ul>";
    } else {
        echo "<p>❌ Bugün için kayıt bulunamadı.</p>";
    }
    
    // Get all QR locations
    echo "<h2>🏢 QR Lokasyonları ve Test Sonuçları</h2>";
    $stmt = $conn->prepare("SELECT * FROM qr_locations ORDER BY id");
    $stmt->execute();
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($locations as $location) {
        echo "<div style='border: 2px solid #333; margin: 10px; padding: 10px;'>";
        echo "<h3>📍 ID: {$location['id']} - {$location['name']}</h3>";
        echo "<p><strong>Tür:</strong> {$location['location_type']}</p>";
        echo "<p><strong>Davranış:</strong> {$location['gate_behavior']}</p>";
        
        // Test gate behavior
        try {
            $result = AttendanceHelper::determineActionByGateType(
                $conn, 
                $employeeId, 
                $today, 
                $location['location_type'], 
                $location['gate_behavior']
            );
            
            echo "<div style='background: #f0f8ff; padding: 10px; margin: 5px 0;'>";
            echo "<strong>🔍 Test Sonucu:</strong><br>";
            echo "Eylem: <strong>{$result['action']}</strong><br>";
            echo "Mesaj: <strong>{$result['message']}</strong><br>";
            echo "</div>";
            
        } catch (Exception $e) {
            echo "<div style='background: #ffe4e1; padding: 10px; margin: 5px 0;'>";
            echo "<strong>❌ Hata:</strong> " . $e->getMessage();
            echo "</div>";
        }
        
        // Test name detection
        $qrName = mb_strtolower(trim($location['name']), 'UTF-8');
        $qrName = str_replace(['İ', 'I'], 'i', $qrName);
        $qrName = str_replace(['Ğ'], 'ğ', $qrName);
        $qrName = str_replace(['Ü'], 'ü', $qrName);
        $qrName = str_replace(['Ş'], 'ş', $qrName);
        $qrName = str_replace(['Ö'], 'ö', $qrName);
        $qrName = str_replace(['Ç'], 'ç', $qrName);
        
        echo "<div style='background: #f5f5f5; padding: 10px; margin: 5px 0;'>";
        echo "<strong>🔤 İsim Tespiti:</strong><br>";
        echo "Original: '{$location['name']}' → Processed: '$qrName'<br>";
        
        if (stripos($qrName, 'giriş') !== false || stripos($qrName, 'giris') !== false || 
            stripos($qrName, 'entrance') !== false) {
            echo "✅ GIRIŞ kapısı olarak tespit edilir<br>";
        } elseif (stripos($qrName, 'çıkış') !== false || stripos($qrName, 'cikis') !== false || 
                  stripos($qrName, 'exit') !== false) {
            echo "✅ ÇIKIŞ kapısı olarak tespit edilir<br>";
        } elseif (stripos($qrName, 'mola') !== false || stripos($qrName, 'break') !== false) {
            echo "✅ MOLA kapısı olarak tespit edilir<br>";
        } else {
            echo "⚠️ Tespit edilemez, veritabanı ayarları kullanılır<br>";
        }
        echo "</div>";
        
        echo "<p><a href='qr-debug.php?emp=$employeeId&loc={$location['id']}' style='background: #007cba; color: white; padding: 5px 10px; text-decoration: none;'>Bu QR'ı Test Et</a></p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "Hata: " . $e->getMessage();
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
</style>