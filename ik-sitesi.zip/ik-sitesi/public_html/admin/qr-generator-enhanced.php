<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/google-maps-config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) CONCAT($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'add_location') {
            // Generate unique QR code
            $qrCode = 'QR_' . strtoupper(substr($_SESSION['company_code'] ?? 'LOC', 0, 3)) . '_' . 
                     str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT) . '_' . time();
            
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([
                $_SESSION['company_id'],
                $_POST['name'],
                $qrCode,
                $_POST['location_type'],
                $_POST['description'],
                $_POST['latitude'] ?: null,
                $_POST['longitude'] ?: null,
                $_POST['address'] ?: null
            ]);
            $success = "🎉 QR lokasyon başarıyla eklendi! Kod: " . $qrCode;
        }
        
        if ($action === 'delete_location') {
            $stmt = $conn->prepare("DELETE FROM qr_locations WHERE id = ? AND company_id = ?");
            $stmt->execute([$_POST['location_id'], $_SESSION['company_id']]);
            $success = "✅ QR lokasyon başarıyla silindi.";
        }
    }
    
    // Get QR locations
    $stmt = $conn->prepare("
        SELECT * FROM qr_locations 
        WHERE company_id = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Kod Üretici - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.1/build/qrcode.min.js"></script>
</head>
<body class="bg-gradient-to-br from-purple-50 to-blue-50 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-bold text-gray-900 flex items-center">
                    📱 QR Kod Üretici
                </h1>
                <p class="text-gray-600 mt-2"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'Demo Şirket'); ?></p>
            </div>
            <a href="../dashboard/company-dashboard.php" 
               class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition">
                ← Dashboard'a Dön
            </a>
        </div>

        <!-- Messages -->
        <?php if (isset($success)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- Add Location Form -->
        <div class="bg-white rounded-lg shadow-lg mb-8">
            <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
                <h2 class="text-xl font-semibold">🗺️ Yeni QR Lokasyon Ekle</h2>
                <p class="text-purple-100 mt-1">Google Maps üzerinden adres seçebilir veya manuel koordinat girebilirsiniz</p>
            </div>
            <div class="p-6">
                <form method="POST" id="locationForm" class="space-y-6">
                    <input type="hidden" name="action" value="add_location">
                    
                    <!-- Basic Info -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Lokasyon Adı *</label>
                            <input type="text" name="name" id="locationName" required placeholder="Ör: Ana Giriş Kapısı"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Lokasyon Türü *</label>
                            <select name="location_type" required 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                                <option value="">Seçin</option>
                                <option value="entrance">🚪 Giriş Kapısı</option>
                                <option value="exit">🚪 Çıkış Kapısı</option>
                                <option value="office">🏢 Ofis/Çalışma Alanı</option>
                                <option value="cafeteria">🍽️ Kafeterya/Yemekhane</option>
                                <option value="meeting_room">👥 Toplantı Odası</option>
                                <option value="break_area">☕ Mola Alanı</option>
                                <option value="warehouse">📦 Depo/Ambar</option>
                                <option value="parking">🚗 Otopark</option>
                                <option value="other">📍 Diğer</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Address Search -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">🔍 Adres Arama (Google Maps)</label>
                        <input type="text" id="addressSearch" placeholder="Adres yazmaya başladığınızda otomatik tamamlama görünecektir"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        <p class="text-xs text-gray-500 mt-1">Adres yazmaya başladığınızda otomatik tamamlama görünecektir</p>
                    </div>
                    
                    <!-- Map Container -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">📍 Harita Konumu</label>
                        <div id="map" class="w-full h-96 border-2 border-gray-300 rounded-lg bg-gray-100">
                            <div id="mapPlaceholder" class="flex items-center justify-center h-full text-gray-500">
                                <div class="text-center p-8">
                                    <div class="text-4xl mb-4">🗺️</div>
                                    <div class="font-semibold mb-2">Google Maps Yükleniyor...</div>
                                    <div class="text-sm">Harita yüklenirken manuel koordinat girişi de kullanabilirsiniz</div>
                                </div>
                            </div>
                        </div>
                        <p class="text-xs text-gray-500 mt-2">Haritaya tıklayarak konum seçebilirsiniz</p>
                    </div>
                    
                    <!-- Coordinates -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">📍 Enlem (Latitude)</label>
                            <input type="number" name="latitude" id="latitude" step="any" placeholder="41.0082"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">📍 Boylam (Longitude)</label>
                            <input type="number" name="longitude" id="longitude" step="any" placeholder="28.9784"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                    </div>
                    
                    <!-- Hidden Address Field -->
                    <input type="hidden" name="address" id="fullAddress">
                    
                    <!-- Description -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">📝 Açıklama</label>
                        <textarea name="description" rows="3" placeholder="Lokasyon hakkında detay bilgi, çalışma saatleri, özel talimatlar..."
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"></textarea>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex flex-col sm:flex-row gap-4">
                        <button type="button" onclick="getCurrentLocation()" 
                                class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition font-medium">
                            📱 Mevcut Konumu Al
                        </button>
                        <button type="button" onclick="useIstanbulCoords()" 
                                class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 transition font-medium">
                            🏙️ İstanbul Koordinatları
                        </button>
                        <button type="submit" 
                                class="bg-purple-600 text-white px-8 py-3 rounded-lg hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 transition font-medium">
                            ✅ QR Lokasyon Oluştur
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- QR Locations -->
        <div class="bg-white rounded-lg shadow-lg">
            <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-t-lg">
                <h2 class="text-xl font-semibold">
                    QR Lokasyonları (<?php echo count($locations); ?>)
                </h2>
            </div>
            <div class="p-6">
                <?php if (empty($locations)): ?>
                    <div class="text-center py-12 text-gray-500">
                        <div class="text-6xl mb-4">📍</div>
                        <h3 class="text-lg font-medium mb-2">Henüz QR lokasyon eklenmemiş</h3>
                        <p>Yukarıdaki formu doldurarak ilk QR lokasyonunuzu oluşturun</p>
                    </div>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php foreach ($locations as $location): ?>
                            <div class="border-2 border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow">
                                <div class="flex items-start justify-between mb-4">
                                    <div class="flex-1">
                                        <h3 class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($location['name']); ?></h3>
                                        <p class="text-sm text-blue-600 font-medium"><?php 
                                            $types = [
                                                'entrance' => '🚪 Giriş Kapısı',
                                                'exit' => '🚪 Çıkış Kapısı', 
                                                'office' => '🏢 Ofis/Çalışma Alanı',
                                                'cafeteria' => '🍽️ Kafeterya/Yemekhane',
                                                'meeting_room' => '👥 Toplantı Odası',
                                                'break_area' => '☕ Mola Alanı',
                                                'warehouse' => '📦 Depo/Ambar',
                                                'parking' => '🚗 Otopark',
                                                'other' => '📍 Diğer'
                                            ];
                                            echo $types[$location['location_type']] ?? htmlspecialchars($location['location_type']);
                                        ?></p>
                                        <p class="text-xs text-gray-500 mt-1 font-mono">QR Kod: <?php echo htmlspecialchars($location['qr_code'] ?? 'N/A'); ?></p>
                                        <?php if ($location['latitude'] && $location['longitude']): ?>
                                            <p class="text-xs text-gray-500">📍 <?php echo number_format($location['latitude'], 6); ?>, <?php echo number_format($location['longitude'], 6); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex flex-col items-end space-y-2">
                                        <span class="px-2 py-1 text-xs rounded-full <?php echo $location['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo $location['is_active'] ? '✅ Aktif' : '❌ Pasif'; ?>
                                        </span>
                                        <button onclick="deleteLocation(<?php echo $location['id']; ?>, '<?php echo addslashes($location['name']); ?>')" 
                                                class="text-red-600 hover:text-red-800 text-xs font-medium">
                                            🗑️ Sil
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- QR Code Canvas -->
                                <div class="text-center mb-4 p-4 bg-gray-50 rounded-lg">
                                    <canvas id="qr_<?php echo $location['id']; ?>" class="mx-auto border border-gray-300 rounded"></canvas>
                                    <p class="text-xs text-gray-600 mt-2">QR kod otomatik oluşturuldu</p>
                                </div>
                                
                                <!-- Action Buttons -->
                                <div class="flex flex-col space-y-2">
                                    <div class="flex space-x-2">
                                        <button onclick="downloadQR('qr_<?php echo $location['id']; ?>', '<?php echo addslashes($location['name']); ?>')" 
                                                class="flex-1 bg-green-600 text-white px-3 py-2 rounded text-sm hover:bg-green-700 transition">
                                            💾 İndir
                                        </button>
                                        <button onclick="printQR('qr_<?php echo $location['id']; ?>', '<?php echo addslashes($location['name']); ?>', '<?php echo $location['qr_code']; ?>')" 
                                                class="flex-1 bg-blue-600 text-white px-3 py-2 rounded text-sm hover:bg-blue-700 transition">
                                            🖨️ Yazdır
                                        </button>
                                    </div>
                                    
                                    <?php if ($location['latitude'] && $location['longitude']): ?>
                                        <a href="https://www.google.com/maps?q=<?php echo $location['latitude']; ?>,<?php echo $location['longitude']; ?>" 
                                           target="_blank" 
                                           class="text-center bg-indigo-600 text-white px-3 py-2 rounded text-sm hover:bg-indigo-700 transition">
                                            🗺️ Google Maps'te Görüntüle
                                        </a>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($location['description']): ?>
                                    <div class="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded text-xs text-gray-700">
                                        <strong>Not:</strong> <?php echo htmlspecialchars($location['description']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Google Maps API -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3oe53GlzTTfKupBeSdyaMW0vJoUTb4Po&libraries=places,geometry&callback=initMap" async defer></script>
    
    <script>
        let map;
        let marker;
        let autocomplete;
        let geocoder;
        
        // Initialize Google Maps
        function initMap() {
            console.log('🗺️ Google Maps initialized with API key');
            
            // Default location (Istanbul)
            const defaultLocation = { lat: 41.0082, lng: 28.9784 };
            
            map = new google.maps.Map(document.getElementById('map'), {
                center: defaultLocation,
                zoom: 13,
                mapTypeControl: 1,
                streetViewControl: 1,
                fullscreenControl: 1,
                styles: [
                    {
                        featureType: 'poi',
                        elementType: 'labels',
                        stylers: [{ visibility: 'on' }]
                    }
                ]
            });
            
            // Initialize geocoder
            geocoder = new google.maps.Geocoder();
            
            // Add click listener to map
            map.addListener('click', function(event) {
                placeMarker(event.latLng);
                updateCoordinates(event.latLng.lat(), event.latLng.lng());
                reverseGeocode(event.latLng);
            });
            
            // Initialize autocomplete for address search
            const addressInput = document.getElementById('addressSearch');
            if (addressInput) {
                autocomplete = new google.maps.places.Autocomplete(addressInput, {
                    componentRestrictions: { country: 'tr' },
                    fields: ['place_id', 'geometry', 'name', 'formatted_address']
                });
                
                autocomplete.addListener('place_changed', function() {
                    const place = autocomplete.getPlace();
                    if (place.geometry) {
                        const location = place.geometry.location;
                        map.setCenter(location);
                        map.setZoom(17);
                        placeMarker(location);
                        updateCoordinates(location.lat(), location.lng());
                        document.getElementById('fullAddress').value = place.formatted_address;
                    }
                });
            }
            
            // Hide placeholder
            const placeholder = document.getElementById('mapPlaceholder');
            if (placeholder) {
                placeholder.style.display = 'none';
            }
        }
        
        // Place marker on map
        function placeMarker(location) {
            if (marker) {
                marker.setMap(null);
            }
            
            marker = new google.maps.Marker({
                position: location,
                map: map,
                title: 'Seçilen Konum',
                animation: google.maps.Animation.DROP,
                icon: {
                    url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="#7C3AED">
                            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                        </svg>
                    `),
                    scaledSize: new google.maps.Size(40, 40),
                    anchor: new google.maps.Point(20, 40)
                }
            });
        }
        
        // Update coordinate inputs
        function updateCoordinates(lat, lng) {
            document.getElementById('latitude').value = lat.toFixed(8);
            document.getElementById('longitude').value = lng.toFixed(8);
        }
        
        // Reverse geocode to get address
        function reverseGeocode(latLng) {
            if (geocoder) {
                geocoder.geocode({ location: latLng }, function(results, status) {
                    if (status === 'OK' && results[0]) {
                        document.getElementById('addressSearch').value = results[0].formatted_address;
                        document.getElementById('fullAddress').value = results[0].formatted_address;
                    }
                });
            }
        }
        
        // Get current location
        function getCurrentLocation() {
            if ("geolocation" in navigator) {
                const button = event.target;
                const originalText = button.textContent;
                button.textContent = '📍 Konum alınıyor...';
                button.disabled = 1;
                
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        const lat = position.coords.latitude;
                        const lng = position.coords.longitude;
                        
                        document.getElementById('latitude').value = lat.toFixed(8);
                        document.getElementById('longitude').value = lng.toFixed(8);
                        
                        if (map) {
                            const newLocation = { lat: lat, lng: lng };
                            map.setCenter(newLocation);
                            map.setZoom(17);
                            placeMarker(newLocation);
                            reverseGeocode(newLocation);
                        }
                        
                        button.textContent = '✅ Konum Alındı';
                        button.style.backgroundColor = '#10B981';
                        setTimeout(() => {
                            button.textContent = originalText;
                            button.style.backgroundColor = '';
                            button.disabled = 0;
                        }, 2000);
                        
                        alert(`✅ Mevcut konum başarıyla alındı!\nEnlem: ${lat.toFixed(6)}\nBoylam: ${lng.toFixed(6)}`);
                    },
                    function(error) {
                        button.textContent = originalText;
                        button.disabled = 0;
                        
                        let errorMessage = 'Konum alınamadı: ';
                        switch(error.code) {
                            case error.PERMISSION_DENIED:
                                errorMessage += 'Konum izni reddedildi.';
                                break;
                            case error.POSITION_UNAVAILABLE:
                                errorMessage += 'Konum bilgisi mevcut değil.';
                                break;
                            case error.TIMEOUT:
                                errorMessage += 'Konum alma işlemi zaman aşımına uğradı.';
                                break;
                            default:
                                errorMessage += 'Bilinmeyen hata.';
                        }
                        alert('❌ ' + errorMessage);
                    },
                    {
                        enableHighAccuracy: 1,
                        timeout: 10000,
                        maximumAge: 0
                    }
                );
            } else {
                alert('❌ Tarayıcınız konum özelliğini desteklemiyor.');
            }
        }
        
        // Istanbul coordinates quick fill
        function useIstanbulCoords() {
            document.getElementById('latitude').value = '41.0082';
            document.getElementById('longitude').value = '28.9784';
            document.getElementById('addressSearch').value = 'İstanbul, Türkiye';
            document.getElementById('fullAddress').value = 'İstanbul, Türkiye';
            
            if (map) {
                const istanbulLocation = { lat: 41.0082, lng: 28.9784 };
                map.setCenter(istanbulLocation);
                map.setZoom(13);
                placeMarker(istanbulLocation);
            }
            
            alert('✅ İstanbul koordinatları eklendi!');
        }
        
        // Generate QR codes for existing locations
        document.addEventListener('DOMContentLoaded', function() {
            <?php foreach ($locations as $location): ?>
                <?php if (!empty($location['qr_code'])): ?>
                    const qrData_<?php echo $location['id']; ?> = {
                        id: <?php echo $location['id']; ?>,
                        name: "<?php echo addslashes($location['name']); ?>",
                        qr_code: "<?php echo $location['qr_code']; ?>",
                        location_type: "<?php echo $location['location_type']; ?>",
                        latitude: <?php echo $location['latitude'] ?? 'null'; ?>,
                        longitude: <?php echo $location['longitude'] ?? 'null'; ?>,
                        description: "<?php echo addslashes($location['description'] ?? ''); ?>"
                    };
                    
                    QRCode.toCanvas(
                        document.getElementById('qr_<?php echo $location['id']; ?>'),
                        JSON.stringify(qrData_<?php echo $location['id']; ?>),
                        {
                            width: 180,
                            height: 180,
                            colorDark: '#7C3AED',
                            colorLight: '#FFFFFF',
                            correctLevel: QRCode.CorrectLevel.H
                        }
                    );
                <?php endif; ?>
            <?php endforeach; ?>
        });
        
        // Download QR code
        function downloadQR(canvasId, locationName) {
            const canvas = document.getElementById(canvasId);
            if (canvas) {
                const link = document.createElement('a');
                link.download = `QR_${locationName.replace(/[^a-zA-Z0-9]/g, '_')}.png`;
                link.href = canvas.toDataURL('image/png', 1.0);
                link.click();
            }
        }
        
        // Print QR code
        function printQR(canvasId, locationName, qrCode) {
            const canvas = document.getElementById(canvasId);
            if (canvas) {
                const dataURL = canvas.toDataURL('image/png', 1.0);
                const printWindow = window.open('', '_blank', 'width=800,height=600');
                
                if (printWindow) {
                    printWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <title>QR Kod - ${locationName}</title>
                            <style>
                                body { font-family: Arial, sans-serif; text-align: center; padding: 20px; margin: 0; }
                                .qr-container { border: 3px solid #7C3AED; padding: 30px; display: inline-block; margin: 20px; border-radius: 10px; background: white; }
                                h1 { font-size: 28px; margin-bottom: 15px; color: #7C3AED; font-weight: bold; }
                                .code { font-size: 14px; color: #666; margin-top: 10px; font-family: monospace; }
                                .company { font-size: 16px; color: #333; margin-top: 15px; font-weight: bold; }
                                img { max-width: 200px; border: 1px solid #ddd; border-radius: 5px; }
                                .instructions { font-size: 12px; color: #888; margin-top: 20px; max-width: 300px; margin-left: auto; margin-right: auto; }
                                @media print { body { background: white; } .qr-container { border: 2px solid #000; page-break-inside: avoid; } }
                            </style>
                        </head>
                        <body>
                            <div class="qr-container">
                                <h1>${locationName}</h1>
                                <img src="${dataURL}" alt="QR Kod">
                                <div class="code">QR Kod: ${qrCode}</div>
                                <div class="company"><?php echo htmlspecialchars($_SESSION['company_name'] ?? 'SZB İK Takip'); ?></div>
                                <div class="instructions">Bu QR kodu tarayarak lokasyonunuza giriş/çıkış işlemlerinizi gerçekleştirebilirsiniz.</div>
                            </div>
                            <script>window.onload = function() { setTimeout(function() { window.print(); }, 500); };</script>
                        </body>
                        </html>
                    `);
                    printWindow.document.close();
                } else {
                    alert('❌ Yazdırma penceresi açılamadı. Pop-up engelleyici kontrol edin.');
                }
            }
        }
        
        // Delete location
        function deleteLocation(locationId, locationName) {
            if (confirm(`⚠️ Bu lokasyonu silmek istediğinizden emin misiniz?\n\nLokasyon: ${locationName}\n\nSilme işlemi geri alınamaz.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete_location">
                    <input type="hidden" name="location_id" value="${locationId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Handle Google Maps API errors
        window.gm_authFailure = function() {
            console.error('Google Maps API authentication failed');
            document.getElementById('map').innerHTML = `
                <div class="flex items-center justify-center h-full text-center p-8">
                    <div>
                        <div class="text-4xl mb-4">⚠️</div>
                        <div class="font-semibold text-red-600 mb-2">Google Maps API Hatası</div>
                        <div class="text-sm text-gray-600 mb-4">
                            API anahtarı geçersiz veya kotası aşılmış olabilir.<br>
                            Manuel koordinat girişi kullanabilirsiniz.
                        </div>
                        <div class="space-y-2">
                            <button onclick="useIstanbulCoords()" class="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700">
                                İstanbul Koordinatlarını Kullan
                            </button><br>
                            <button onclick="getCurrentLocation()" class="bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700">
                                📱 Mevcut Konumu Al
                            </button>
                        </div>
                    </div>
                </div>
            `;
        };
    </script>
</body>
</html>