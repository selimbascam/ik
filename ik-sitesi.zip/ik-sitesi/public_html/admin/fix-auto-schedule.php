<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as admin
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Schedule Kolon Düzeltme - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">🔧</span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Database Düzeltme</h1>
            <p class="text-gray-600 mt-2">Auto Schedule Kolon Düzeltme Scripti</p>
        </div>

        <div class="max-w-2xl mx-auto">
            <div class="bg-white rounded-lg shadow p-6">
                
<?php
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2 class='text-lg font-bold mb-4'>🔍 Veritabanı Kontrol Ediliyor...</h2>";
    echo "<div class='space-y-2 text-sm'>";
    
    // Check if work_settings table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'work_settings'");
    if ($stmt->rowCount() === 0) {
        echo "<div class='text-red-600'>❌ work_settings tablosu bulunamadı. Tablo oluşturuluyor...</div>";
        
        $conn->exec("
            CREATE TABLE work_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                monthly_hours INT DEFAULT 225,
                weekly_hours INT DEFAULT 45,
                daily_max_hours INT DEFAULT 11,
                hourly_rate DECIMAL(10,2) DEFAULT 50.00,
                overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
                holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
                weekly_holiday INT DEFAULT 1,
                auto_schedule TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_company (company_id)
            )
        ");
        echo "<div class='text-green-600'>✅ work_settings tablosu başarıyla oluşturuldu!</div>";
    } else {
        echo "<div class='text-green-600'>✅ work_settings tablosu mevcut</div>";
        
        // Check if auto_schedule column exists
        $stmt = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'auto_schedule'");
        if ($stmt->rowCount() === 0) {
            echo "<div class='text-red-600'>❌ auto_schedule kolonu bulunamadı. Kolon ekleniyor...</div>";
            
            $conn->exec("ALTER TABLE work_settings ADD COLUMN auto_schedule TINYINT(1) DEFAULT 1");
            echo "<div class='text-green-600'>✅ auto_schedule kolonu başarıyla eklendi!</div>";
        } else {
            echo "<div class='text-green-600'>✅ auto_schedule kolonu zaten mevcut</div>";
        }
    }
    
    // Show all columns
    echo "<br><h3 class='font-bold'>📋 Mevcut Kolonlar:</h3>";
    $stmt = $conn->query("SHOW COLUMNS FROM work_settings");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div class='bg-gray-100 p-3 rounded mt-2'>";
    foreach ($columns as $column) {
        $type = $column['Type'];
        $null = $column['Null'] === 'YES' ? 'NULL' : 'NOT NULL';
        $default = $column['Default'] !== null ? "DEFAULT '{$column['Default']}'" : '';
        echo "<div class='text-xs text-gray-700'>{$column['Field']} - {$type} {$null} {$default}</div>";
    }
    echo "</div>";
    
    echo "<br><div class='text-green-600 font-bold'>🎉 Tüm düzeltmeler tamamlandı!</div>";
    echo "<div class='text-gray-600 mt-2'>Artık work-settings.php sayfası düzgün çalışacaktır.</div>";
    
} catch (Exception $e) {
    echo "<div class='text-red-600'>❌ Hata: " . htmlspecialchars($e->getMessage()) . "</div>";
}
?>
                
                </div>
                
                <div class="mt-6 text-center">
                    <a href="work-settings.php" 
                       class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 inline-block">
                        🔙 Çalışma Ayarlarına Dön
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>