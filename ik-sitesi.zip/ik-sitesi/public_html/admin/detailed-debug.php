<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['company_id'])) {
    die("Oturum bulunamadı. Lütfen giriş yapın.");
}

require_once '../includes/database.php';

echo "<h1>QR Lokasyon Debug - Detaylı Analiz</h1>";
echo "<p><strong>Şirket ID:</strong> " . $_SESSION['company_id'] . "</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // 1. Önce mevcut durumu kontrol et
    echo "<h2>1. Mevcut Lokasyonların Detaylı Durumu</h2>";
    $stmt = $conn->prepare("SELECT id, name, location_type, LENGTH(location_type) as type_length, company_id FROM qr_locations WHERE company_id = ? AND id IN (94, 95, 96)");
    $stmt->execute([$_SESSION['company_id']]);
    $locations = $stmt->fetchAll();
    
    if (empty($locations)) {
        echo "<p style='color: red;'>Şirketinize ait kayıt bulunamadı!</p>";
    } else {
        echo "<table border='1' cellpadding='8'>";
        echo "<tr><th>ID</th><th>İsim</th><th>Tür</th><th>Tür Uzunluğu</th><th>Şirket ID</th><th>Boş mu?</th></tr>";
        
        foreach ($locations as $loc) {
            $is_empty = empty($loc['location_type']) ? 'EVET' : 'HAYIR';
            $color = empty($loc['location_type']) ? 'red' : 'green';
            
            echo "<tr>";
            echo "<td>{$loc['id']}</td>";
            echo "<td>" . htmlspecialchars($loc['name']) . "</td>";
            echo "<td style='color: $color;'>'" . htmlspecialchars($loc['location_type']) . "'</td>";
            echo "<td>{$loc['type_length']}</td>";
            echo "<td>{$loc['company_id']}</td>";
            echo "<td style='color: $color;'><strong>$is_empty</strong></td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // 2. Güncelleme testi - NULL ve boş string durumları için
    echo "<h2>2. Güncelleme Testleri</h2>";
    
    if ($_POST['test_update'] ?? false) {
        $test_id = intval($_POST['test_id']);
        $new_type = $_POST['new_type'];
        
        echo "<p><strong>Test Edilen:</strong> ID $test_id → '$new_type'</p>";
        
        // Önce mevcut değeri oku
        $check_stmt = $conn->prepare("SELECT location_type FROM qr_locations WHERE id = ? AND company_id = ?");
        $check_stmt->execute([$test_id, $_SESSION['company_id']]);
        $current_value = $check_stmt->fetchColumn();
        
        echo "<p><strong>Mevcut Değer:</strong> '" . htmlspecialchars($current_value) . "'</p>";
        
        // Güncellemeyi yap
        $update_stmt = $conn->prepare("UPDATE qr_locations SET location_type = ? WHERE id = ? AND company_id = ?");
        $update_result = $update_stmt->execute([$new_type, $test_id, $_SESSION['company_id']]);
        $affected_rows = $update_stmt->rowCount();
        
        echo "<p><strong>Güncelleme Sonucu:</strong> " . ($update_result ? 'BAŞARILI' : 'BAŞARISIZ') . "</p>";
        echo "<p><strong>Etkilenen Satırlar:</strong> $affected_rows</p>";
        
        if ($affected_rows === 0) {
            echo "<p style='color: orange;'><strong>NEDENLER:</strong></p>";
            echo "<ul>";
            echo "<li>Kayıt bulunamadı (ID veya Company ID hatalı)</li>";
            echo "<li>Yeni değer mevcut değerle aynı (güncelleme gerekmiyor)</li>";
            echo "<li>Veritabanı kısıtlamaları</li>";
            echo "</ul>";
        }
        
        // Güncelleme sonrası tekrar oku
        $check_stmt->execute([$test_id, $_SESSION['company_id']]);
        $new_value = $check_stmt->fetchColumn();
        echo "<p><strong>Güncelleme Sonrası Değer:</strong> '" . htmlspecialchars($new_value) . "'</p>";
    }
    
    // 3. Tüm boş/NULL location_type'ları düzeltme
    if ($_POST['fix_all'] ?? false) {
        echo "<h2>3. Tüm Boş/NULL Location Type'ları Düzelt</h2>";
        
        // Önce tespit et
        $empty_stmt = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE company_id = ? AND (location_type IS NULL OR location_type = '')");
        $empty_stmt->execute([$_SESSION['company_id']]);
        $empty_locations = $empty_stmt->fetchAll();
        
        if (empty($empty_locations)) {
            echo "<p>Düzeltilecek boş/NULL location_type bulunamadı.</p>";
        } else {
            echo "<p>Bulunan boş/NULL location_type'lar:</p>";
            echo "<ul>";
            foreach ($empty_locations as $loc) {
                echo "<li>ID {$loc['id']}: '{$loc['name']}' → '" . htmlspecialchars($loc['location_type']) . "'</li>";
            }
            echo "</ul>";
            
            // Otomatik tür belirleme fonksiyonu
            function detectLocationTypeFromName($name, $current_type) {
                $name_lower = strtolower(trim($name));
                
                if (strpos($name_lower, 'çıkış') !== false || strpos($name_lower, 'exit') !== false) {
                    return 'check_out';
                } elseif (strpos($name_lower, 'giriş') !== false || strpos($name_lower, 'entrance') !== false) {
                    return 'check_in';
                } elseif (strpos($name_lower, 'çay') !== false || strpos($name_lower, 'tea') !== false) {
                    return 'tea_break';
                } elseif (strpos($name_lower, 'yemek') !== false || strpos($name_lower, 'lunch') !== false) {
                    return 'lunch_break';
                } elseif (strpos($name_lower, 'sigara') !== false || strpos($name_lower, 'smoke') !== false) {
                    return 'smoke_break';
                } elseif (strpos($name_lower, 'mola') !== false || strpos($name_lower, 'break') !== false || 
                          strpos($name_lower, 'ara') !== false || strpos($name_lower, 'dinlenme') !== false) {
                    return 'tea_break';
                }
                
                return $current_type;
            }
            
            // Düzeltme işlemi
            $fixed_count = 0;
            foreach ($empty_locations as $loc) {
                $detected_type = detectLocationTypeFromName($loc['name'], 'general_gate');
                
                echo "<p>ID {$loc['id']}: '{$loc['name']}' → {$detected_type} işleniyor...</p>";
                
                $fix_stmt = $conn->prepare("UPDATE qr_locations SET location_type = ? WHERE id = ? AND company_id = ?");
                $fix_result = $fix_stmt->execute([$detected_type, $loc['id'], $_SESSION['company_id']]);
                $fix_affected = $fix_stmt->rowCount();
                
                echo "<p style='margin-left: 20px;'>Execute: " . ($fix_result ? 'SUCCESS' : 'FAILED') . ", Affected: {$fix_affected}</p>";
                
                if ($fix_result && $fix_affected > 0) {
                    echo "<p style='color: green; margin-left: 20px;'>✅ Başarılı!</p>";
                    $fixed_count++;
                } else {
                    echo "<p style='color: red; margin-left: 20px;'>❌ Düzeltilemedi</p>";
                }
            }
            
            echo "<p><strong>Toplam düzeltilen: $fixed_count</strong></p>";
        }
    }
    
    // Test formu
    echo "<h2>4. Test Araçları</h2>";
    
    echo "<form method='POST' style='margin-bottom: 20px;'>";
    echo "<h3>Tekil Güncelleme Testi</h3>";
    echo "<select name='test_id'>";
    echo "<option value='94'>ID 94 (giriş)</option>";
    echo "<option value='95'>ID 95 (çıkış)</option>";
    echo "<option value='96'>ID 96 (mola)</option>";
    echo "</select>";
    echo "<select name='new_type'>";
    echo "<option value='check_in'>check_in</option>";
    echo "<option value='check_out'>check_out</option>";
    echo "<option value='tea_break'>tea_break</option>";
    echo "<option value='general_gate'>general_gate</option>";
    echo "</select>";
    echo "<button type='submit' name='test_update' value='1'>Test Et</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<h3>Toplu Düzeltme</h3>";
    echo "<button type='submit' name='fix_all' value='1' style='background: #28a745; color: white; padding: 10px; font-size: 16px;'>🚀 Tüm Boş/NULL Location Type'ları Düzelt</button>";
    echo "</form>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Hata: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>