<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: ../auth/admin-login.php');
    exit;
}

$employeeId = (int)($_GET['id'] ?? 0);
$companyId = $_SESSION['company_id'];

if (!$employeeId) {
    header('Location: employee-attendance-list.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // First ensure employee_number column exists
    try {
        $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
        if ($columnCheck->rowCount() === 0) {
            // Column doesn't exist, add it
            $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
            
            // Generate employee numbers for existing employees
            $existingEmps = $conn->query("SELECT id FROM employees WHERE employee_number IS NULL OR employee_number = ''");
            foreach ($existingEmps->fetchAll(PDO::FETCH_ASSOC) as $emp) {
                $empNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
                $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
                $updateStmt->execute([$empNumber, $emp['id']]);
            }
        }
    } catch (Exception $e) {
        // If column creation fails, we'll handle it in the error catch below
    }
    
    // Get employee details
    $stmt = $conn->prepare("
        SELECT first_name, last_name, 
               COALESCE(employee_number, CONCAT('EMP', LPAD(id, 4, '0'))) as employee_number, 
               email, created_at
        FROM employees 
        WHERE id = ? AND company_id = ?
    ");
    $stmt->execute([$employeeId, $companyId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        throw new Exception("Personel bulunamadı.");
    }
    
    // Get date range for filtering
    $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days'));
    $dateTo = $_GET['date_to'] ?? date('Y-m-d');
    
    // Get attendance records with device info
    $stmt = $conn->prepare("
        SELECT ar.*, ql.name as location_name, ql.location_type
        FROM attendance_records ar
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ? 
        AND DATE(ar.created_at) BETWEEN ? AND ?
        ORDER BY ar.created_at DESC
    ");
    $stmt->execute([$employeeId, $dateFrom, $dateTo]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Group records by date
    $recordsByDate = [];
    foreach ($records as $record) {
        $date = date('Y-m-d', strtotime($record['created_at']));
        $recordsByDate[$date][] = $record;
    }
    
    // Calculate daily summaries
    $dailySummaries = [];
    foreach ($recordsByDate as $date => $dayRecords) {
        $firstIn = null;
        $lastOut = null;
        $totalBreakTime = 0;
        $breakStart = null;
        
        foreach ($dayRecords as $record) {
            switch ($record['activity_type']) {
                case 'check_in':
                    if (!$firstIn) $firstIn = $record['created_at'];
                    break;
                case 'check_out':
                    $lastOut = $record['created_at'];
                    break;
                case 'break_start':
                    $breakStart = strtotime($record['created_at']);
                    break;
                case 'break_end':
                    if ($breakStart) {
                        $totalBreakTime += strtotime($record['created_at']) - $breakStart;
                        $breakStart = null;
                    }
                    break;
            }
        }
        
        $workTime = 0;
        if ($firstIn && $lastOut) {
            $workTime = strtotime($lastOut) - strtotime($firstIn) - $totalBreakTime;
        }
        
        $dailySummaries[$date] = [
            'first_in' => $firstIn,
            'last_out' => $lastOut,
            'work_time' => $workTime,
            'break_time' => $totalBreakTime,
            'total_records' => count($dayRecords)
        ];
    }
    
} catch (Exception $e) {
    $error = "Veri çekme hatası: " . $e->getMessage();
    error_log("Employee attendance details error: " . $e->getMessage());
    
    // Add diagnostic links for different errors
    if (strpos($e->getMessage(), 'employee_number') !== false) {
        $error .= '<br><br><a href="../debug/fix-employee-number-column.php" class="inline-block mt-2 bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm">🔧 Employee Number Sütunu Düzeltme</a>';
    }
}

// Turkish activity messages
$activityMessages = [
    'check_in' => '🟢 Giriş',
    'break_start' => '🟡 Mola Başlangıcı',
    'break_end' => '🟢 Mola Bitişi', 
    'check_out' => '🔴 Çıkış'
];

function formatDuration($seconds) {
    if (!$seconds) return '--';
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    return sprintf('%02d:%02d', $hours, $minutes);
}

function parseDeviceInfo($deviceInfo) {
    if (empty($deviceInfo)) return [];
    $info = json_decode($deviceInfo, 1);
    return $info ?: [];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Devam Detayları - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .activity-icon {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .check-in { background-color: #10b981; }
        .break-start { background-color: #f59e0b; }
        .break-end { background-color: #10b981; }
        .check-out { background-color: #ef4444; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">📊 Personel Devam Detayları</h1>
                    <?php if (isset($employee)): ?>
                        <p class="text-gray-600">
                            <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                            (<?php echo htmlspecialchars($employee['employee_number']); ?>)
                        </p>
                    <?php endif; ?>
                </div>
                <div class="flex gap-3">
                    <a href="employee-attendance-list.php" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition">
                        ← Listeye Dön
                    </a>
                    <button onclick="window.print()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">
                        🖨️ Yazdır
                    </button>
                </div>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <?php echo strpos($error, '<a href=') !== false ? $error : htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- Date Filter -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <form method="GET" class="flex items-end gap-4">
                <input type="hidden" name="id" value="<?php echo $employeeId; ?>">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Başlangıç Tarihi</label>
                    <input type="date" name="date_from" value="<?php echo htmlspecialchars($dateFrom); ?>" 
                           class="border border-gray-300 rounded-md px-3 py-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Bitiş Tarihi</label>
                    <input type="date" name="date_to" value="<?php echo htmlspecialchars($dateTo); ?>" 
                           class="border border-gray-300 rounded-md px-3 py-2">
                </div>
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md transition">
                    🔍 Filtrele
                </button>
            </form>
        </div>

        <!-- Daily Summaries -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">📈 Günlük Özet</h2>
            
            <?php if (empty($dailySummaries)): ?>
                <div class="text-center py-8 text-gray-500">
                    <p>Seçilen tarih aralığında kayıt bulunmuyor.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="border-b">
                                <th class="text-left py-2">Tarih</th>
                                <th class="text-left py-2">İlk Giriş</th>
                                <th class="text-left py-2">Son Çıkış</th>
                                <th class="text-left py-2">Çalışma Süresi</th>
                                <th class="text-left py-2">Mola Süresi</th>
                                <th class="text-left py-2">Kayıt Sayısı</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dailySummaries as $date => $summary): ?>
                                <tr class="border-b border-gray-100">
                                    <td class="py-2 font-medium">
                                        <?php 
                                        $dayName = date('l', strtotime($date));
                                        $turkishDays = [
                                            'Monday' => 'Pazartesi',
                                            'Tuesday' => 'Salı',
                                            'Wednesday' => 'Çarşamba',
                                            'Thursday' => 'Perşembe',
                                            'Friday' => 'Cuma',
                                            'Saturday' => 'Cumartesi',
                                            'Sunday' => 'Pazar'
                                        ];
                                        echo $turkishDays[$dayName] ?? $dayName;
                                        echo '<br><span class="text-xs text-gray-500">' . date('d.m.Y', strtotime($date)) . '</span>';
                                        ?>
                                    </td>
                                    <td class="py-2">
                                        <?php echo $summary['first_in'] ? date('H:i', strtotime($summary['first_in'])) : '--'; ?>
                                    </td>
                                    <td class="py-2">
                                        <?php echo $summary['last_out'] ? date('H:i', strtotime($summary['last_out'])) : '--'; ?>
                                    </td>
                                    <td class="py-2 font-medium text-green-600">
                                        <?php echo formatDuration($summary['work_time']); ?>
                                    </td>
                                    <td class="py-2 text-yellow-600">
                                        <?php echo formatDuration($summary['break_time']); ?>
                                    </td>
                                    <td class="py-2">
                                        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                                            <?php echo $summary['total_records']; ?> kayıt
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Detailed Records -->
        <div class="bg-white rounded-lg shadow-sm p-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">🕒 Detaylı Kayıtlar</h2>
            
            <?php if (empty($records)): ?>
                <div class="text-center py-8 text-gray-500">
                    <p>Seçilen tarih aralığında detaylı kayıt bulunmuyor.</p>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php 
                    $currentDate = '';
                    foreach ($records as $record): 
                        $recordDate = date('Y-m-d', strtotime($record['created_at']));
                        if ($recordDate !== $currentDate):
                            $currentDate = $recordDate;
                            $dayName = date('l', strtotime($currentDate));
                            $turkishDays = [
                                'Monday' => 'Pazartesi', 'Tuesday' => 'Salı', 'Wednesday' => 'Çarşamba',
                                'Thursday' => 'Perşembe', 'Friday' => 'Cuma', 'Saturday' => 'Cumartesi', 'Sunday' => 'Pazar'
                            ];
                    ?>
                        <div class="border-t pt-4 mt-6 first:border-t-0 first:pt-0 first:mt-0">
                            <h3 class="font-medium text-gray-900 mb-3">
                                <?php echo $turkishDays[$dayName] ?? $dayName; ?> - <?php echo date('d.m.Y', strtotime($currentDate)); ?>
                            </h3>
                        </div>
                    <?php endif; ?>
                    
                    <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div class="flex items-center">
                            <span class="activity-icon <?php echo $record['activity_type']; ?>"></span>
                            <div>
                                <div class="font-medium">
                                    <?php echo $activityMessages[$record['activity_type']] ?? $record['activity_type']; ?>
                                </div>
                                <div class="text-sm text-gray-500">
                                    📍 <?php echo htmlspecialchars($record['location_name'] ?? 'Bilinmeyen Lokasyon'); ?>
                                </div>
                                
                                <?php 
                                $deviceInfo = parseDeviceInfo($record['device_info']);
                                if (!empty($deviceInfo)): 
                                ?>
                                <div class="text-xs text-gray-400 mt-1 space-y-1">
                                    <!-- IP Address Info -->
                                    <div>
                                        <?php if (!empty($deviceInfo['ip_address'])): ?>
                                            🌐 IP: <?php echo htmlspecialchars($deviceInfo['ip_address']); ?>
                                        <?php endif; ?>
                                        <?php if (!empty($deviceInfo['real_ip']) && $deviceInfo['real_ip'] !== $deviceInfo['ip_address']): ?>
                                            | Gerçek IP: <?php echo htmlspecialchars($deviceInfo['real_ip']); ?>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Device & Browser Info -->
                                    <div>
                                        <?php if (!empty($deviceInfo['device_type'])): ?>
                                            📱 <?php echo htmlspecialchars($deviceInfo['device_type']); ?>
                                        <?php endif; ?>
                                        <?php if (!empty($deviceInfo['browser_info'])): ?>
                                            | 🌐 <?php echo htmlspecialchars($deviceInfo['browser_info']); ?>
                                        <?php endif; ?>
                                        <?php if (!empty($deviceInfo['qr_format'])): ?>
                                            | 📋 QR: <?php echo htmlspecialchars($deviceInfo['qr_format']); ?>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Additional Technical Info -->
                                    <?php if (!empty($deviceInfo['session_id'])): ?>
                                    <div>
                                        🔑 Session: <?php echo htmlspecialchars(substr($deviceInfo['session_id'], 0, 8)); ?>...
                                        <?php if (!empty($deviceInfo['timestamp'])): ?>
                                            | ⏰ <?php echo htmlspecialchars($deviceInfo['timestamp']); ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <!-- Language & Referrer Info -->
                                    <?php if (!empty($deviceInfo['http_accept_language']) || !empty($deviceInfo['http_referer'])): ?>
                                    <div>
                                        <?php if (!empty($deviceInfo['http_accept_language'])): ?>
                                            🌍 Dil: <?php echo htmlspecialchars(substr($deviceInfo['http_accept_language'], 0, 10)); ?>...
                                        <?php endif; ?>
                                        <?php if (!empty($deviceInfo['http_referer'])): ?>
                                            | 🔗 Kaynak: <?php echo htmlspecialchars(parse_url($deviceInfo['http_referer'], PHP_URL_HOST) ?: 'Bilinmiyor'); ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="font-medium text-gray-900">
                                <?php echo date('H:i:s', strtotime($record['created_at'])); ?>
                            </div>
                            <div class="text-xs text-gray-500">
                                <?php echo date('d.m.Y', strtotime($record['created_at'])); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>