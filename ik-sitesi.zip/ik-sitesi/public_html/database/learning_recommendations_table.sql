-- Learning Recommendations Table for Adaptive Learning Engine
CREATE TABLE IF NOT EXISTS learning_recommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    employee_id INT NOT NULL,
    recommendation_type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    priority_score DECIMAL(5,2) DEFAULT 0.00,
    ai_confidence DECIMAL(3,2) DEFAULT 0.00,
    status ENUM('pending', 'in_progress', 'completed', 'dismissed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_company_employee (company_id, employee_id),
    INDEX idx_recommendation_type (recommendation_type),
    INDEX idx_priority_score (priority_score DESC),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at DESC),
    
    UNIQUE KEY unique_recommendation (company_id, employee_id, recommendation_type, title),
    
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Learning Analytics Table for tracking learning patterns
CREATE TABLE IF NOT EXISTS learning_analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    employee_id INT NOT NULL,
    metric_type VARCHAR(50) NOT NULL,
    metric_value DECIMAL(10,2),
    analysis_date DATE,
    data_source VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_company_employee (company_id, employee_id),
    INDEX idx_metric_type (metric_type),
    INDEX idx_analysis_date (analysis_date DESC),
    
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Skill Assessment Table for tracking employee skills
CREATE TABLE IF NOT EXISTS employee_skill_assessments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    employee_id INT NOT NULL,
    skill_category VARCHAR(100) NOT NULL,
    skill_name VARCHAR(255) NOT NULL,
    current_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'beginner',
    target_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
    assessment_score DECIMAL(5,2),
    assessed_by INT,
    assessment_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_company_employee (company_id, employee_id),
    INDEX idx_skill_category (skill_category),
    INDEX idx_current_level (current_level),
    INDEX idx_assessment_date (assessment_date DESC),
    
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Meeting Participations Table (if not exists)
CREATE TABLE IF NOT EXISTS meeting_participations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    employee_id INT NOT NULL,
    meeting_title VARCHAR(255),
    date DATE,
    duration_minutes INT DEFAULT 0,
    participation_type ENUM('organizer', 'required', 'optional', 'observer') DEFAULT 'required',
    attendance_status ENUM('present', 'absent', 'late') DEFAULT 'present',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_company_employee (company_id, employee_id),
    INDEX idx_date (date DESC),
    INDEX idx_attendance_status (attendance_status),
    
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data for demonstration
INSERT IGNORE INTO learning_recommendations (company_id, employee_id, recommendation_type, title, description, priority_score, ai_confidence) VALUES
(1, 1, 'time_management', 'Zaman Yönetimi Eğitimi', 'Geç kalma oranı yüksek. Zaman yönetimi becerilerini geliştirmek için özel eğitim önerilir.', 85.5, 0.92),
(1, 2, 'technical_skills', 'Siber Güvenlik Farkındalığı', 'IT departmanı için güncel siber güvenlik tehditleri ve koruma yöntemleri eğitimi.', 78.0, 0.88),
(1, 3, 'communication', 'İletişim Becerileri Geliştirme', 'Toplantı katılımı düşük. Etkili iletişim ve sunum becerileri eğitimi önerilir.', 65.3, 0.75);

INSERT IGNORE INTO learning_analytics (company_id, employee_id, metric_type, metric_value, analysis_date, data_source) VALUES
(1, 1, 'attendance_score', 87.5, CURDATE(), 'attendance_records'),
(1, 1, 'punctuality_score', 72.3, CURDATE(), 'attendance_records'),
(1, 2, 'training_completion_rate', 95.0, CURDATE(), 'employee_trainings'),
(1, 3, 'meeting_participation_rate', 45.5, CURDATE(), 'meeting_participations');

INSERT IGNORE INTO employee_skill_assessments (company_id, employee_id, skill_category, skill_name, current_level, target_level, assessment_score, assessment_date) VALUES
(1, 1, 'Soft Skills', 'Zaman Yönetimi', 'beginner', 'intermediate', 45.0, CURDATE()),
(1, 2, 'Technical Skills', 'Siber Güvenlik', 'intermediate', 'advanced', 75.5, CURDATE()),
(1, 3, 'Communication', 'Sunum Becerileri', 'beginner', 'intermediate', 38.0, CURDATE());