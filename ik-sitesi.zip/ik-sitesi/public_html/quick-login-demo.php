<?php
session_start();
require_once 'includes/database.php';

echo "<h2>🚀 Hızlı Login Demo</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 20px 0;'>";
    
    // Company Login Demo
    echo "<div style='background: #e7f3ff; padding: 20px; border-radius: 8px;'>";
    echo "<h3>🏢 Company Login Demo</h3>";
    
    // Simulate company login
    $stmt = $conn->prepare("SELECT * FROM companies WHERE email = 'info@szb.com.tr'");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company && $company['password'] === 'szb123') {
        // Set company session
        $_SESSION['company_id'] = $company['id'];
        $_SESSION['admin_email'] = $company['email'];
        $_SESSION['company_name'] = $company['name'];
        $_SESSION['user_type'] = 'company';
        
        echo "<p style='color: green;'>✅ Company login başarılı!</p>";
        echo "<p><strong>Company:</strong> {$company['name']}</p>";
        echo "<p><strong>Email:</strong> {$company['email']}</p>";
        echo "<p><a href='admin/dashboard.php' style='background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Admin Dashboard</a></p>";
    } else {
        echo "<p style='color: red;'>❌ Company login hatası</p>";
    }
    echo "</div>";
    
    // Employee Login Demo
    echo "<div style='background: #e8f5e8; padding: 20px; border-radius: 8px;'>";
    echo "<h3>👤 Employee Login Demo</h3>";
    
    // Simulate employee login
    $stmt = $conn->prepare("SELECT * FROM employees WHERE employee_number = 'EMP001' AND is_active = true");
    $stmt->execute();
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        // Set employee session
        $_SESSION['employee_id'] = $employee['id'];
        $_SESSION['company_id'] = $employee['company_id'];
        $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
        $_SESSION['user_type'] = 'employee';
        
        echo "<p style='color: green;'>✅ Employee login başarılı!</p>";
        echo "<p><strong>Employee:</strong> {$employee['first_name']} {$employee['last_name']}</p>";
        echo "<p><strong>Number:</strong> {$employee['employee_number']}</p>";
        echo "<p><a href='employee/dashboard.php' style='background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Employee Dashboard</a></p>";
    } else {
        echo "<p style='color: red;'>❌ Employee login hatası</p>";
    }
    echo "</div>";
    
    // Super Admin Demo
    echo "<div style='background: #ffe8e8; padding: 20px; border-radius: 8px;'>";
    echo "<h3>🛡️ Super Admin Demo</h3>";
    
    // Set super admin session
    $_SESSION['super_admin'] = 1;
    $_SESSION['user_email'] = 'super@admin.com';
    
    echo "<p style='color: green;'>✅ Super Admin aktif!</p>";
    echo "<p><strong>Password:</strong> SZB2025Admin!</p>";
    echo "<p><a href='super-admin/' style='background: #dc3545; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>Super Admin Panel</a></p>";
    echo "</div>";
    
    echo "</div>";
    
    // QR System Test
    echo "<div style='background: #fff8e1; padding: 25px; border-radius: 8px; margin: 20px 0; text-align: center;'>";
    echo "<h2>📱 QR Sistemi Testi</h2>";
    echo "<p>Employee login yaptıktan sonra QR sistemi test edebilirsiniz:</p>";
    echo "<div style='margin: 15px 0;'>";
    echo "<a href='employee/qr-unified.php' style='background: #ff9800; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 10px;'>🔍 QR Kod Okut</a>";
    echo "<a href='employee/attendance-records.php' style='background: #9c27b0; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 10px;'>📋 Devam Kayıtları</a>";
    echo "</div>";
    echo "</div>";
    
    echo "<h3>🎉 Sonuç</h3>";
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>✅ Tüm Login Sistemleri Çalışıyor!</h2>";
    echo "<p><strong>PostgreSQL Format:</strong> ✅ Uyumlu</p>";
    echo "<p><strong>Session Management:</strong> ✅ Aktif</p>";
    echo "<p><strong>QR Sistema:</strong> ✅ Hazır</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ Demo Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }
h2, h3 { color: #333; }
</style>