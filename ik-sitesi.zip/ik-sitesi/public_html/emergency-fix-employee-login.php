<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🚨 EMPLOYEE LOGIN ACİL DÜZELTİCİ</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .warning{color:orange;} .info{color:blue;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔍 Mevcut Durum Analizi</h2>";
    
    // Check actual companies table structure
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $companyColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Companies Tablosundaki Gerçek Sütunlar:</h3>";
    $availableColumns = [];
    foreach ($companyColumns as $col) {
        $availableColumns[] = $col['Field'];
        echo "<li><strong>{$col['Field']}</strong> ({$col['Type']})</li>";
    }
    
    // Determine correct column mapping
    $companyNameColumn = 'name'; // Default
    $companyCodeColumn = 'id'; // Default as fallback
    
    if (in_array('company_name', $availableColumns)) {
        $companyNameColumn = 'company_name';
    }
    if (in_array('company_code', $availableColumns)) {
        $companyCodeColumn = 'company_code';
    }
    
    echo "<p class='info'>📋 Kullanılacak sütunlar: <strong>$companyNameColumn</strong> (şirket adı), <strong>$companyCodeColumn</strong> (şirket kodu)</p>";
    
    // Generate correct SQL
    $correctSQL = "
SELECT e.id, e.first_name, e.last_name, e.email, e.employee_code, 
       e.company_id, c.$companyNameColumn as company_name, c.$companyCodeColumn as company_code
FROM employees e 
JOIN companies c ON e.company_id = c.id 
WHERE e.employee_code = ? AND e.password_hash = PASSWORD(?) AND e.is_active = TRUE
";
    
    echo "<h3>🔧 Doğru SQL Sorgusu:</h3>";
    echo "<pre style='background:#f5f5f5; padding:15px; border-radius:5px;'>";
    echo htmlspecialchars($correctSQL);
    echo "</pre>";
    
    // Test the SQL
    try {
        $stmt = $conn->prepare($correctSQL);
        echo "<p class='success'>✅ SQL sorgusu geçerli</p>";
    } catch (Exception $e) {
        echo "<p class='error'>❌ SQL sorgusu hâlâ hatalı: " . $e->getMessage() . "</p>";
        // Fallback SQL
        $correctSQL = "
SELECT e.id, e.first_name, e.last_name, e.email, e.employee_code, 
       e.company_id, 'Company' as company_name, e.company_id as company_code
FROM employees e 
WHERE e.employee_code = ? AND e.password_hash = PASSWORD(?) AND e.is_active = TRUE
";
        echo "<h3>🔄 Fallback SQL (Companies JOIN olmadan):</h3>";
        echo "<pre style='background:#f5f5f5; padding:15px; border-radius:5px;'>";
        echo htmlspecialchars($correctSQL);
        echo "</pre>";
    }
    
    if (isset($_GET['fix']) && $_GET['fix'] === 'true') {
        echo "<h2>🔧 ACİL DÜZELTİM YAPILIYOR...</h2>";
        
        $loginFile = 'auth/employee-login.php';
        $content = file_get_contents($loginFile);
        
        // Replace the problematic SQL query
        $pattern = '/SELECT e\.id, e\.first_name, e\.last_name, e\.email, e\.employee_code,\s*e\.company_id, c\.name as company_name, c\.id as company_code\s*FROM employees e\s*JOIN companies c ON e\.company_id = c\.id\s*WHERE e\.employee_code = \? AND e\.password_hash = PASSWORD\(\?\) AND e\.is_active = TRUE/s';
        
        $replacement = "SELECT e.id, e.first_name, e.last_name, e.email, e.employee_code, 
                           e.company_id, c.$companyNameColumn as company_name, c.$companyCodeColumn as company_code
                    FROM employees e 
                    JOIN companies c ON e.company_id = c.id 
                    WHERE e.employee_code = ? AND e.password_hash = PASSWORD(?) AND e.is_active = TRUE";
        
        if (preg_match($pattern, $content)) {
            $content = preg_replace($pattern, $replacement, $content);
            file_put_contents($loginFile, $content);
            echo "<p class='success'>✅ Employee login dosyası düzeltildi!</p>";
        } else {
            // Try simpler pattern matching
            $oldLine = "c.name as company_name, c.id as company_code";
            $newLine = "c.$companyNameColumn as company_name, c.$companyCodeColumn as company_code";
            
            if (strpos($content, $oldLine) !== false) {
                $content = str_replace($oldLine, $newLine, $content);
                file_put_contents($loginFile, $content);
                echo "<p class='success'>✅ Employee login sütun adları düzeltildi!</p>";
            } else {
                echo "<p class='warning'>⚠️ Employee login dosyasında değiştirilecek kısım bulunamadı</p>";
                echo "<p>Mevcut içerik parçası:</p>";
                echo "<pre>" . htmlspecialchars(substr($content, strpos($content, 'SELECT e.id'), 300)) . "</pre>";
            }
        }
        
        echo "<p class='info'>🔍 <a href='auth/employee-login.php'>Employee Login'i test edin</a></p>";
    }
    
    echo "<hr>";
    echo "<div style='background:#ffebee; padding:15px; border-radius:5px; margin:20px 0; border-left: 4px solid #f44336;'>";
    echo "<h3>🚨 ACİL DÜZELTİM</h3>";
    echo "<p>Employee login sayfasındaki veritabanı hatası derhal düzeltilecek.</p>";
    echo "<a href='?fix=true' style='background:#f44336; color:white; padding:12px 24px; text-decoration:none; border-radius:5px; font-weight:bold;'>🚨 HEMEN DÜZELT</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ KRİTİK HATA: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='debug/check-companies-table.php'>🔍 Tablo Yapısı</a> | <a href='auth/employee-login.php'>← Employee Login</a></p>";
?>