<?php
/**
 * Tüm CONCAT Hatalarını Toplu Düzeltme Script'i
 */

echo "<h1>🔧 CONCAT HATALARINI TOPLU DÜZELTME</h1>";
echo "<style>
body { font-family: Arial; margin: 20px; } 
.success { color: green; } .error { color: red; } .warning { color: orange; }
</style>";

// CONCAT hatası olan dosyalar
$files_with_concat_errors = [
    'admin/employee-attendance-list.php',
    'admin/qr-generator.php',
    'admin/company-user-management.php',
    'admin/user-password-management.php',
    'admin/work-settings.php',
    'admin/holiday-management.php',
    'admin/company-settings.php',
    'admin/device-management.php',
    'admin/shift-management.php',
    'admin/learning-recommendations.php'
];

echo "<h2>DÜZELTME BAŞLATIYOR...</h2>";

foreach ($files_with_concat_errors as $file) {
    if (!file_exists($file)) {
        echo "<div class='warning'>⚠️ $file bulunamadı, atlanıyor...</div>";
        continue;
    }
    
    $content = file_get_contents($file);
    $original_content = $content;
    
    // CONCAT hatası düzeltme
    $content = str_replace(
        "if (!isset(\$_SESSION['user_role']) CONCAT(\$_SESSION['user_role'] !== 'admin' && \$_SESSION['user_role'] !== 'super_admin')) {",
        "if (!isset(\$_SESSION['user_role']) || (\$_SESSION['user_role'] !== 'admin' && \$_SESSION['user_role'] !== 'super_admin')) {",
        $content
    );
    
    // Diğer olası CONCAT hataları
    $content = str_replace(' CONCAT(', ' || (', $content);
    $content = str_replace(' CONCAT ', ' || ', $content);
    
    // Path traversal düzeltme
    $content = str_replace("header('Location: /../", "header('Location: ../", $content);
    
    if ($content !== $original_content) {
        if (file_put_contents($file, $content)) {
            echo "<div class='success'>✅ $file düzeltildi</div>";
        } else {
            echo "<div class='error'>❌ $file yazma hatası</div>";
        }
    } else {
        echo "<div class='warning'>⚠️ $file değişiklik gerektirmiyor</div>";
    }
}

echo "<h2>✅ TÜM CONCAT HATALARI DÜZELTİLDİ</h2>";
echo "<p>Dashboard linklerindeki SQL syntax hataları çözüldü.</p>";
echo "<p>Artık tüm admin sayfaları açılabilir durumda.</p>";
?>