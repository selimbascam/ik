<?php
/**
 * SZB30912 şirketi için QR davranış düzeltici
 */
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    $conn->setAttribute(PDO::ATTR_AUTOCOMMIT, true);
    
    echo "<h2>🔧 SZB30912 QR Davranış Düzeltici</h2>";
    
    // SZB30912 şirketi ID'sini bul
    $stmt = $conn->prepare("SELECT id FROM companies WHERE company_code = 'SZB30912'");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        echo "<p style='color: red;'>❌ SZB30912 şirketi bulunamadı!</p>";
        exit;
    }
    
    $companyId = $company['id'];
    echo "<p>✅ SZB30912 şirketi bulundu (ID: $companyId)</p>";
    
    // gate_behavior kolonu kontrolü
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
    if ($stmt->rowCount() == 0) {
        $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(50) DEFAULT 'user_choice'");
        echo "<p>✅ gate_behavior kolonu eklendi</p>";
    }
    
    // Mevcut QR lokasyonları
    $stmt = $conn->prepare("SELECT id, name, gate_behavior FROM qr_locations WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($locations)) {
        echo "<p style='color: orange;'>⚠️ SZB30912 için QR lokasyonu bulunamadı!</p>";
        
        // Varsayılan lokasyonlar oluştur
        $defaultLocations = [
            ['name' => 'giriş', 'behavior' => 'work_start', 'desc' => 'Ana giriş kapısı'],
            ['name' => 'çıkış', 'behavior' => 'work_end', 'desc' => 'Ana çıkış kapısı'],
            ['name' => 'mola', 'behavior' => 'break_toggle', 'desc' => 'Mola alanı'],
            ['name' => 'mola giriş', 'behavior' => 'break_toggle', 'desc' => 'Mola giriş alanı']
        ];
        
        foreach ($defaultLocations as $loc) {
            $qrCode = 'QR_SZB30912_' . strtoupper($loc['name']);
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (company_id, name, qr_code, gate_behavior, description, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, 1, NOW())
            ");
            $stmt->execute([$companyId, $loc['name'], $qrCode, $loc['behavior'], $loc['desc']]);
            echo "<p>✅ '{$loc['name']}' lokasyonu oluşturuldu (davranış: {$loc['behavior']})</p>";
        }
        
    } else {
        echo "<h3>Mevcut QR Lokasyonları:</h3><ul>";
        
        // Davranış güncellemeleri
        $updates = [
            'giriş' => 'work_start',
            'çıkış' => 'work_end', 
            'mola' => 'break_toggle',
            'mola giriş' => 'break_toggle'
        ];
        
        foreach ($locations as $location) {
            $name = mb_strtolower(trim($location['name']), 'UTF-8');
            $currentBehavior = $location['gate_behavior'] ?: 'NULL';
            $newBehavior = 'user_choice';
            
            // İsim bazlı davranış belirleme
            foreach ($updates as $keyword => $behavior) {
                if (strpos($name, $keyword) !== false) {
                    $newBehavior = $behavior;
                    break;
                }
            }
            
            echo "<li>ID: {$location['id']}, İsim: '{$location['name']}', Mevcut: $currentBehavior";
            
            if ($currentBehavior !== $newBehavior) {
                $updateStmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE id = ?");
                $updateStmt->execute([$newBehavior, $location['id']]);
                echo " → <strong style='color: green;'>$newBehavior (DÜZELTİLDİ)</strong>";
            } else {
                echo " → <span style='color: blue;'>$newBehavior (DOĞRU)</span>";
            }
            
            echo "</li>";
        }
        echo "</ul>";
    }
    
    echo "<br><h3>🔍 Final Kontrol:</h3>";
    
    // Final kontrol
    $stmt = $conn->prepare("SELECT id, name, gate_behavior FROM qr_locations WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $finalLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($finalLocations as $loc) {
        $behavior = $loc['gate_behavior'] ?: 'NULL';
        $color = ($behavior === 'work_start' || $behavior === 'work_end' || $behavior === 'break_toggle') ? 'green' : 'red';
        echo "<p style='color: $color;'>✓ '{$loc['name']}' → <strong>$behavior</strong></p>";
    }
    
    echo "<br><p style='background: #e8f5e8; padding: 10px; border-radius: 5px;'>";
    echo "🎯 <strong>Test için:</strong> 'selim' kullanıcısıyla QR kod okutma testi yapabilirsiniz.<br>";
    echo "📱 QR okuyucu artık doğru davranışları kullanmalı.";
    echo "</p>";
    
    echo "<br><a href='super-admin/index.php' class='btn'>← Süper Admin Paneline Dön</a>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Hata: " . $e->getMessage() . "</p>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
.btn { background: #007cba; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
.btn:hover { background: #005a87; }
</style>