<?php
echo "<h2>🔧 Quick Test rowCount Method</h2>";

// Test if the classes are properly loaded
echo "<h3>📊 Testing MySQLi Wrapper Classes</h3>";

require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<p>✅ Database connection established</p>";
    echo "<p>Connection type: " . get_class($conn) . "</p>";
    
    // Test a simple query with rowCount
    $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'id'");
    echo "<p>✅ Query executed successfully</p>";
    echo "<p>Statement type: " . get_class($stmt) . "</p>";
    
    // Check if rowCount method exists
    if (method_exists($stmt, 'rowCount')) {
        $count = $stmt->rowCount();
        echo "<p>✅ rowCount() method exists and returned: $count</p>";
    } else {
        echo "<p>❌ rowCount() method does not exist in " . get_class($stmt) . "</p>";
        
        // List available methods
        echo "<p>Available methods:</p>";
        echo "<ul>";
        foreach (get_class_methods($stmt) as $method) {
            echo "<li>$method</li>";
        }
        echo "</ul>";
    }
    
    // Test QR locations table access
    echo "<h3>🔍 Testing QR Locations Table</h3>";
    try {
        $qrStmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
        if (method_exists($qrStmt, 'rowCount')) {
            $qrCount = $qrStmt->rowCount();
            echo "<p>✅ QR table query successful, rowCount: $qrCount</p>";
        } else {
            echo "<p>❌ rowCount() method still missing in QR query</p>";
        }
    } catch (Exception $e) {
        echo "<p>⚠️ QR table error: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>File: " . $e->getFile() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
}

echo "<h3>🔗 Test Links</h3>";
echo "<a href='admin/qr-generator.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>QR Generator</a>";
echo "<a href='admin/dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
ul { background: #f8f9fa; padding: 15px; border-radius: 5px; }
</style>