<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔧 QR Settings Table Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if qr_settings table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'qr_settings'");
    $tables = $stmt->fetchAll();
    
    if (count($tables) == 0) {
        echo "<p style='color: orange;'>⚠️ qr_settings table missing. Creating it now...</p>";
        
        // Create qr_settings table
        $createTableSQL = "
            CREATE TABLE qr_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                qr_type VARCHAR(50) DEFAULT 'location_based',
                location_tolerance INT DEFAULT 50,
                auto_checkout TINYINT(1) DEFAULT 0,
                checkout_timeout INT DEFAULT 480,
                allow_manual_time TINYINT(1) DEFAULT 0,
                require_location TINYINT(1) DEFAULT 1,
                enable_break_tracking TINYINT(1) DEFAULT 1,
                max_daily_hours INT DEFAULT 12,
                grace_period_minutes INT DEFAULT 15,
                notification_settings JSON DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_company (company_id),
                FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
                INDEX idx_company_id (company_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ";
        
        $conn->exec($createTableSQL);
        echo "<p style='color: green;'>✅ qr_settings table created successfully</p>";
        
        // Create default settings for existing companies
        $companiesStmt = $conn->query("SELECT id FROM companies");
        $companies = $companiesStmt->fetchAll();
        
        foreach ($companies as $company) {
            $insertStmt = $conn->prepare("
                INSERT IGNORE INTO qr_settings 
                (company_id, qr_type, location_tolerance, auto_checkout, checkout_timeout, 
                 allow_manual_time, require_location, enable_break_tracking, max_daily_hours, grace_period_minutes) 
                VALUES (?, 'location_based', 50, 0, 480, 0, 1, 1, 12, 15)
            ");
            $insertStmt->execute([$company['id']]);
        }
        
        echo "<p style='color: green;'>✅ Default QR settings created for " . count($companies) . " companies</p>";
        
    } else {
        echo "<p style='color: green;'>✅ qr_settings table already exists</p>";
        
        // Check table structure
        $structStmt = $conn->query("DESCRIBE qr_settings");
        $columns = $structStmt->fetchAll();
        
        echo "<h3>📊 Current Table Structure</h3>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background: #f0f0f0;'>";
        echo "<th style='padding: 8px;'>Field</th>";
        echo "<th style='padding: 8px;'>Type</th>";
        echo "<th style='padding: 8px;'>Default</th>";
        echo "</tr>";
        
        foreach ($columns as $column) {
            echo "<tr>";
            echo "<td style='padding: 8px;'><strong>{$column['Field']}</strong></td>";
            echo "<td style='padding: 8px;'>{$column['Type']}</td>";
            echo "<td style='padding: 8px;'>" . ($column['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Test QR settings query
    echo "<h3>🧪 Testing QR Settings Query</h3>";
    $testStmt = $conn->prepare("SELECT * FROM qr_settings WHERE company_id = ? LIMIT 1");
    $testStmt->execute([1]);
    $testResult = $testStmt->fetch();
    
    if ($testResult) {
        echo "<p style='color: green;'>✅ QR settings query successful</p>";
        echo "<p><strong>Sample settings for company 1:</strong></p>";
        echo "<ul>";
        echo "<li><strong>QR Type:</strong> {$testResult['qr_type']}</li>";
        echo "<li><strong>Location Tolerance:</strong> {$testResult['location_tolerance']} meters</li>";
        echo "<li><strong>Auto Checkout:</strong> " . ($testResult['auto_checkout'] ? 'Enabled' : 'Disabled') . "</li>";
        echo "<li><strong>Grace Period:</strong> {$testResult['grace_period_minutes']} minutes</li>";
        echo "</ul>";
    } else {
        echo "<p style='color: orange;'>⚠️ No QR settings found for company 1</p>";
        
        // Create default for company 1
        $defaultStmt = $conn->prepare("
            INSERT IGNORE INTO qr_settings 
            (company_id, qr_type, location_tolerance, auto_checkout, checkout_timeout, 
             allow_manual_time, require_location, enable_break_tracking, max_daily_hours, grace_period_minutes) 
            VALUES (1, 'location_based', 50, 0, 480, 0, 1, 1, 12, 15)
        ");
        $defaultStmt->execute();
        echo "<p style='color: green;'>✅ Created default QR settings for company 1</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
}

echo "<h3>🔗 Test Company Settings</h3>";
echo "<div>";
echo "<a href='admin/company-settings.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Company Settings</a>";
echo "<a href='admin/dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
table { width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
ul { background: #f8f9fa; padding: 15px; border-radius: 5px; }
</style>