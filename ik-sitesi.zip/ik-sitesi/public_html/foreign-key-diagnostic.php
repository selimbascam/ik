<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>Foreign Key Constraint Diagnostic</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;line-height:1.6;}h1,h2,h3{color:#333;}.success{color:#22c55e;font-weight:bold;}.error{color:#ef4444;font-weight:bold;}.warning{color:#f59e0b;font-weight:bold;}.info{color:#3b82f6;font-weight:bold;}.diagnostic{background:#f8f9fa;padding:15px;border:1px solid #dee2e6;border-radius:5px;margin:15px 0;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>1. Test Employee Check</h2>";
    $stmt = $conn->prepare("SELECT id, employee_number, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<div class='success'>✅ Employee found: ID {$employee['id']}, Company ID: {$employee['company_id']}</div>";
        
        echo "<h2>2. Company Existence Check</h2>";
        $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
        $stmt->execute([$employee['company_id']]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($company) {
            echo "<div class='success'>✅ Company exists: ID {$company['id']}, Name: {$company['company_name']}</div>";
        } else {
            echo "<div class='error'>❌ CRITICAL: Company ID {$employee['company_id']} NOT FOUND in companies table!</div>";
            
            // Auto-fix missing company
            echo "<div class='warning'>⚡ Auto-creating missing company...</div>";
            $stmt = $conn->prepare("INSERT INTO companies (id, company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $employee['company_id'],
                'SZB Test Company',
                'test@szb.com.tr',
                '555-0123',
                'Auto-created for FK fix'
            ]);
            echo "<div class='success'>✅ Company created successfully</div>";
        }
        
        echo "<h2>3. QR Locations Check</h2>";
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ?");
        $stmt->execute([$employee['company_id']]);
        $locationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($locationCount > 0) {
            echo "<div class='success'>✅ Found {$locationCount} QR locations for company</div>";
            
            $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? LIMIT 3");
            $stmt->execute([$employee['company_id']]);
            $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($locations as $loc) {
                echo "<div class='info'>📍 Location {$loc['id']}: {$loc['name']}</div>";
            }
        } else {
            echo "<div class='warning'>⚠️ No QR locations found, creating test location...</div>";
            $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $employee['company_id'],
                'Test Entrance',
                'Auto-created test QR location',
                '41.0082',
                '28.9784',
                'entrance',
                1
            ]);
            echo "<div class='success'>✅ Test QR location created</div>";
        }
        
        echo "<h2>4. Foreign Key Constraint Check</h2>";
        $stmt = $conn->query("
            SELECT 
                CONSTRAINT_NAME,
                TABLE_NAME,
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
            WHERE TABLE_NAME = 'attendance_records'
            AND CONSTRAINT_NAME LIKE '%fk%' OR CONSTRAINT_NAME LIKE '%ibfk%'
        ");
        $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($constraints) {
            echo "<div class='diagnostic'>";
            echo "<h3>Foreign Key Constraints:</h3>";
            foreach ($constraints as $fk) {
                echo "<p><strong>{$fk['CONSTRAINT_NAME']}:</strong> {$fk['COLUMN_NAME']} → {$fk['REFERENCED_TABLE_NAME']}.{$fk['REFERENCED_COLUMN_NAME']}</p>";
            }
            echo "</div>";
        }
        
        echo "<h2>5. Test Insert Attempt</h2>";
        try {
            // Get first available QR location
            $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = ? LIMIT 1");
            $stmt->execute([$employee['company_id']]);
            $location = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($location) {
                $testInsert = $conn->prepare("
                    INSERT INTO attendance_records 
                    (company_id, employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date) 
                    VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
                ");
                
                $testInsert->execute([
                    $employee['company_id'],
                    $employee['id'],
                    $location['id'],
                    'work_in',
                    'Diagnostic test insert'
                ]);
                
                echo "<div class='success'>✅ TEST INSERT SUCCESSFUL! Foreign key constraint satisfied.</div>";
                
                // Clean up test record
                $stmt = $conn->prepare("DELETE FROM attendance_records WHERE notes = 'Diagnostic test insert'");
                $stmt->execute();
                echo "<div class='info'>🧹 Test record cleaned up</div>";
                
            } else {
                echo "<div class='error'>❌ No QR location available for test</div>";
            }
            
        } catch (Exception $e) {
            echo "<div class='error'>❌ Test insert failed: " . $e->getMessage() . "</div>";
        }
        
    } else {
        echo "<div class='error'>❌ Test employee not found</div>";
    }
    
    echo "<h2>6. System Status Summary</h2>";
    echo "<div style='background:#e8f5e8;padding:20px;border-radius:8px;margin:20px 0;'>";
    echo "<h3 style='color:#2e7d32;'>Diagnostic Complete</h3>";
    echo "<p>If foreign key error persists after running this diagnostic, the issue is likely in:</p>";
    echo "<ul>";
    echo "<li>Session management (wrong employee_id)</li>";
    echo "<li>Data validation logic</li>";
    echo "<li>Database connection issues</li>";
    echo "</ul>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Diagnostic failed: " . $e->getMessage() . "</div>";
}
?>