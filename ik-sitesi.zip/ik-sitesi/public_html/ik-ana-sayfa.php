<?php
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - İK Ana Sayfası</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex items-center justify-center">
    <div class="text-center">
        <div class="w-24 h-24 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <span class="text-white text-4xl font-bold">S</span>
        </div>
        <h1 class="text-4xl font-bold text-gray-900 mb-4"><?php echo APP_NAME; ?></h1>
        <p class="text-xl text-gray-600 mb-8">İnsan Kaynakları Yönetim Sistemi</p>
        
        <div class="space-y-4">
            <a href="auth/employee-login.php" class="block w-full max-w-xs mx-auto bg-indigo-600 text-white py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors">
                👤 Personel Girişi
            </a>
            <a href="auth/company-login.php" class="block w-full max-w-xs mx-auto bg-white text-indigo-600 py-3 px-6 rounded-lg border border-indigo-600 hover:bg-indigo-50 transition-colors">
                🏢 Şirket Girişi
            </a>
            <a href="dashboard/super-admin.php" class="block w-full max-w-xs mx-auto bg-gray-800 text-white py-3 px-6 rounded-lg hover:bg-gray-900 transition-colors">
                👑 Süper Admin
            </a>
            <a href="qr/qr-reader.php" class="block w-full max-w-xs mx-auto bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors">
                📱 QR Kod Okut
            </a>
        </div>

        <div class="mt-8 pt-6 border-t border-gray-200">
            <p class="text-sm text-gray-500 mb-4">Hızlı Erişim</p>
            <div class="flex justify-center space-x-4">
                <a href="complete-system-overview.php" class="text-blue-600 hover:text-blue-800 text-sm">
                    🔍 Sistem Analizi
                </a>
                <a href="system-status-dashboard.php" class="text-green-600 hover:text-green-800 text-sm">
                    📊 Sistem Durumu
                </a>
                <a href="setup-work-settings.php" class="text-orange-600 hover:text-orange-800 text-sm">
                    ⚙️ Kurulum
                </a>
            </div>
        </div>
    </div>
</body>
</html>