<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Latitude/Longitude Kolon Düzeltmesi</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>1. Attendance_records Tablo Yapısını Kontrol Et</h3>";
    
    // Check current table structure
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $existingColumns = array_column($columns, 'Field');
    $hasLatitude = in_array('latitude', $existingColumns);
    $hasLongitude = in_array('longitude', $existingColumns);
    
    echo "<h4>Mevcut Kolonlar:</h4>";
    echo "<ul>";
    foreach ($existingColumns as $col) {
        echo "<li>$col</li>";
    }
    echo "</ul>";
    
    echo "<h4>GPS Kolon Durumu:</h4>";
    echo "<ul>";
    echo "<li>latitude: " . ($hasLatitude ? '✅ VAR' : '❌ YOK') . "</li>";
    echo "<li>longitude: " . ($hasLongitude ? '✅ VAR' : '❌ YOK') . "</li>";
    echo "</ul>";
    
    echo "<h3>2. Eksik Kolonları Ekle</h3>";
    
    $columnsAdded = 0;
    
    // Add latitude column if missing
    if (!$hasLatitude) {
        try {
            $conn->exec("ALTER TABLE attendance_records ADD COLUMN latitude DECIMAL(10, 8) DEFAULT NULL");
            echo "<p>✅ latitude kolonu eklendi</p>";
            $columnsAdded++;
        } catch (Exception $e) {
            echo "<p>❌ latitude kolonu eklenemedi: " . $e->getMessage() . "</p>";
        }
    }
    
    // Add longitude column if missing
    if (!$hasLongitude) {
        try {
            $conn->exec("ALTER TABLE attendance_records ADD COLUMN longitude DECIMAL(11, 8) DEFAULT NULL");
            echo "<p>✅ longitude kolonu eklendi</p>";
            $columnsAdded++;
        } catch (Exception $e) {
            echo "<p>❌ longitude kolonu eklenemedi: " . $e->getMessage() . "</p>";
        }
    }
    
    if ($columnsAdded === 0 && $hasLatitude && $hasLongitude) {
        echo "<p>✅ Tüm GPS kolonları zaten mevcut</p>";
    }
    
    echo "<h3>3. Güncellenmiş Tablo Yapısını Kontrol Et</h3>";
    
    // Re-check table structure
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $updatedColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>Güncellenmiş Kolon Listesi:</h4>";
    echo "<ul>";
    foreach ($updatedColumns as $col) {
        $colName = $col['Field'];
        $colType = $col['Type'];
        $isGPS = in_array($colName, ['latitude', 'longitude']);
        $marker = $isGPS ? '📍' : '';
        echo "<li>$marker $colName ($colType)</li>";
    }
    echo "</ul>";
    
    echo "<h3>4. Test Insert Query</h3>";
    
    // Test insert with GPS coordinates
    try {
        $testQuery = "
            INSERT INTO attendance_records 
            (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, 
             notes, created_at, date, check_date) 
            VALUES (?, ?, ?, NOW(), ?, ?, ?, NOW(), CURDATE(), CURDATE())
        ";
        
        $stmt = $conn->prepare($testQuery);
        // Don't actually execute, just prepare to test syntax
        echo "<p>✅ Test insert query hazırlandı - sözdizimi doğru</p>";
        echo "<p>Query: " . htmlspecialchars($testQuery) . "</p>";
        
    } catch (Exception $e) {
        echo "<p>❌ Test insert query hatası: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>5. QR Reader Dosyalarını Kontrol Et</h3>";
    
    // Check which files might need updates
    $qrFiles = [
        'qr/qr-reader.php',
        'employee/qr-attendance.php',
        'includes/qr-attendance-helper.php'
    ];
    
    foreach ($qrFiles as $file) {
        $fullPath = __DIR__ . '/' . $file;
        if (file_exists($fullPath)) {
            $content = file_get_contents($fullPath);
            $hasLatitudeRef = strpos($content, 'latitude') !== false;
            $hasLongitudeRef = strpos($content, 'longitude') !== false;
            
            echo "<p>📄 $file:</p>";
            echo "<ul>";
            echo "<li>latitude referansı: " . ($hasLatitudeRef ? '✅' : '❌') . "</li>";
            echo "<li>longitude referansı: " . ($hasLongitudeRef ? '✅' : '❌') . "</li>";
            echo "</ul>";
        } else {
            echo "<p>❌ $file bulunamadı</p>";
        }
    }
    
    echo "<h3>6. Final Durum</h3>";
    
    // Final verification
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records WHERE Field IN ('latitude', 'longitude')");
    $gpsColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $finalLatitude = false;
    $finalLongitude = false;
    
    foreach ($gpsColumns as $col) {
        if ($col['Field'] === 'latitude') $finalLatitude = true;
        if ($col['Field'] === 'longitude') $finalLongitude = true;
    }
    
    $systemReady = $finalLatitude && $finalLongitude;
    $bgColor = $systemReady ? '#d4edda' : '#f8d7da';
    
    echo "<div style='background: $bgColor; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>" . ($systemReady ? '✅ GPS Koordinat Sistemi Hazır' : '❌ GPS Koordinat Sistemi Eksik') . "</h4>";
    echo "<ul>";
    echo "<li>latitude kolonu: " . ($finalLatitude ? '✅' : '❌') . "</li>";
    echo "<li>longitude kolonu: " . ($finalLongitude ? '✅' : '❌') . "</li>";
    echo "<li>QR attendance insert: " . ($systemReady ? '✅ Çalışmalı' : '❌ Hata verecek') . "</li>";
    echo "</ul>";
    echo "</div>";
    
    if ($systemReady) {
        echo "<h3>🔗 Test QR Attendance</h3>";
        echo "<ul>";
        echo "<li><a href='employee/qr-attendance.php' style='color: #0056b3; font-weight: bold;'>Employee QR Attendance →</a></li>";
        echo "<li><a href='qr/qr-reader.php' style='color: #0056b3;'>QR Reader →</a></li>";
        echo "</ul>";
        
        echo "<h3>👤 Test Login</h3>";
        echo "<p>Employee Number: 30716129672</p>";
        echo "<p>Password: 123456</p>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Sistem Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "h3 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; }";
echo "</style>";
?>