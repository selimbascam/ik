<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Aktivite Türleri Tablosu Kurulumu</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Create activity_types table
    $createTable = "
        CREATE TABLE IF NOT EXISTS activity_types (
            id INT PRIMARY KEY AUTO_INCREMENT,
            company_id INT NOT NULL,
            activity_code VARCHAR(50) NOT NULL,
            activity_name VARCHAR(100) NOT NULL,
            category VARCHAR(20) DEFAULT 'other',
            icon VARCHAR(10) DEFAULT '📋',
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT NOW(),
            updated_at DATETIME NOT NULL DEFAULT NOW() ON UPDATE NOW(),
            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
            UNIQUE KEY unique_company_activity (company_id, activity_code)
        )
    ";
    
    $conn->exec($createTable);
    echo "<p>✅ activity_types tablosu oluşturuldu.</p>";
    
    // Add some default activity types for demo company
    $defaultActivities = [
        ['custom_break', 'Özel Mola', 'break', '⏰'],
        ['overtime_start', 'Mesai Başlangıcı', 'work', '🌙'],
        ['overtime_end', 'Mesai Bitişi', 'work', '🌙'],
        ['meeting_start', 'Toplantı Başlangıcı', 'work', '👥'],
        ['meeting_end', 'Toplantı Bitişi', 'work', '👥']
    ];
    
    foreach ($defaultActivities as $activity) {
        // Check if already exists
        $stmt = $conn->prepare("SELECT id FROM activity_types WHERE company_id = 1 AND activity_code = ?");
        $stmt->execute([$activity[0]]);
        
        if (!$stmt->fetch()) {
            $stmt = $conn->prepare("
                INSERT INTO activity_types (company_id, activity_code, activity_name, category, icon) 
                VALUES (1, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $activity[0], // code
                $activity[1], // name
                $activity[2], // category
                $activity[3]  // icon
            ]);
            echo "<p>✅ Eklendi: {$activity[1]} ({$activity[0]})</p>";
        } else {
            echo "<p>ℹ️ Mevcut: {$activity[1]} ({$activity[0]})</p>";
        }
    }
    
    echo "<h3>Tüm Aktivite Türleri:</h3>";
    $stmt = $conn->prepare("SELECT * FROM activity_types WHERE company_id = 1 ORDER BY category, activity_name");
    $stmt->execute();
    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<ul>";
    foreach ($activities as $act) {
        $status = $act['is_active'] ? 'Aktif' : 'Pasif';
        echo "<li><strong>{$act['icon']} {$act['activity_name']}</strong> - {$act['activity_code']} ({$act['category']}) - {$status}</li>";
    }
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Hata: " . $e->getMessage() . "</p>";
}
?>

<br><br>
<a href="admin/activity-types.php">← Aktivite Türleri Yönetimi</a> | 
<a href="qr/scanner.php">QR Scanner Test →</a>