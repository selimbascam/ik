<?php
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Maps API Kurulum Rehberi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="max-w-4xl mx-auto py-8 px-4">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-6">🗺️ Google Maps API Kurulum Rehberi</h1>
            
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
                <div class="flex items-start">
                    <div class="text-2xl mr-3">ℹ️</div>
                    <div>
                        <h3 class="font-semibold text-blue-900 mb-2">QR Kod Generator için Google Maps API gerekli</h3>
                        <p class="text-blue-800">
                            Adres arama, harita görüntüleme ve konum seçme özellikleri için Google Maps JavaScript API kullanılmaktadır.
                            Bu rehberi takip ederek ücretsiz API key alabilirsiniz.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Step by Step Instructions -->
            <div class="space-y-8">
                
                <!-- Step 1 -->
                <div class="border-l-4 border-purple-500 pl-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-3">1️⃣ Google Cloud Console'a Giriş</h2>
                    <div class="space-y-3">
                        <p class="text-gray-700">Google hesabınızla Google Cloud Console'a giriş yapın:</p>
                        <a href="https://console.cloud.google.com/" target="_blank" 
                           class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                            🌐 Google Cloud Console'a Git
                        </a>
                    </div>
                </div>

                <!-- Step 2 -->
                <div class="border-l-4 border-purple-500 pl-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-3">2️⃣ Yeni Proje Oluşturun</h2>
                    <div class="space-y-3">
                        <p class="text-gray-700">Eğer projeniz yoksa yeni bir proje oluşturun:</p>
                        <ol class="list-decimal list-inside space-y-2 text-gray-600">
                            <li>"Select a project" dropdown'una tıklayın</li>
                            <li>"New Project" seçeneğini tıklayın</li>
                            <li>Proje adı girin (örn: "SZB IK Takip Maps")</li>
                            <li>"Create" butonuna tıklayın</li>
                        </ol>
                    </div>
                </div>

                <!-- Step 3 -->
                <div class="border-l-4 border-purple-500 pl-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-3">3️⃣ Billing (Faturalandırma) Aktifleştirme</h2>
                    <div class="space-y-3">
                        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                            <div class="flex items-start">
                                <div class="text-xl mr-2">💳</div>
                                <div>
                                    <p class="font-semibold text-yellow-800 mb-1">Billing zorunludur ancak ücretsizdir!</p>
                                    <p class="text-yellow-700 text-sm">
                                        Google her ay $200 ücretsiz kredi verir. Normal kullanımda bu limiti aşmazsınız.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <ol class="list-decimal list-inside space-y-2 text-gray-600">
                            <li>Sol menüden "Billing" seçin</li>
                            <li>"Link a billing account" tıklayın</li>
                            <li>Kredi kartı bilgilerinizi girin (ücret kesilmeyecek)</li>
                            <li>Billing hesabını projeye bağlayın</li>
                        </ol>
                    </div>
                </div>

                <!-- Step 4 -->
                <div class="border-l-4 border-purple-500 pl-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-3">4️⃣ Gerekli API'leri Aktifleştirin</h2>
                    <div class="space-y-3">
                        <p class="text-gray-700">Aşağıdaki API'leri aktifleştirmeniz gerekir:</p>
                        <ol class="list-decimal list-inside space-y-2 text-gray-600">
                            <li>Sol menüden "APIs & Services" → "Library" seçin</li>
                            <li>Aşağıdaki API'leri arayın ve "Enable" yapın:</li>
                        </ol>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                            <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                                <h4 class="font-semibold text-green-800">Maps JavaScript API</h4>
                                <p class="text-green-600 text-sm">Harita görüntüleme için zorunlu</p>
                            </div>
                            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                <h4 class="font-semibold text-blue-800">Places API</h4>
                                <p class="text-blue-600 text-sm">Adres arama için gerekli</p>
                            </div>
                            <div class="bg-purple-50 border border-purple-200 rounded-lg p-4">
                                <h4 class="font-semibold text-purple-800">Geocoding API</h4>
                                <p class="text-purple-600 text-sm">Koordinat dönüşümü için</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Step 5 -->
                <div class="border-l-4 border-purple-500 pl-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-3">5️⃣ API Key Oluşturun</h2>
                    <div class="space-y-3">
                        <ol class="list-decimal list-inside space-y-2 text-gray-600">
                            <li>"APIs & Services" → "Credentials" seçin</li>
                            <li>"Create Credentials" → "API key" tıklayın</li>
                            <li>API key oluşturulacak, kopyalayın</li>
                        </ol>
                        <div class="bg-gray-50 border border-gray-200 rounded-lg p-4">
                            <p class="text-sm text-gray-600 mb-2">API Key format örneği:</p>
                            <code class="bg-gray-100 px-2 py-1 rounded text-sm font-mono">AIzaSyABC123...</code>
                        </div>
                    </div>
                </div>

                <!-- Step 6 -->
                <div class="border-l-4 border-purple-500 pl-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-3">6️⃣ API Key'i Güvenlik için Kısıtlayın</h2>
                    <div class="space-y-3">
                        <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                            <div class="flex items-start">
                                <div class="text-xl mr-2">🔒</div>
                                <div>
                                    <p class="font-semibold text-red-800 mb-1">Güvenlik için çok önemli!</p>
                                    <p class="text-red-700 text-sm">
                                        API key'inizi kısıtlamadan kullanmayın, kötüye kullanılabilir.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <ol class="list-decimal list-inside space-y-2 text-gray-600">
                            <li>Oluşturduğunuz API key'e tıklayın</li>
                            <li>"Application restrictions" kısmında "HTTP referrers" seçin</li>
                            <li>Domain'inizi ekleyin: <code class="bg-gray-100 px-1 rounded">szb.com.tr/*</code></li>
                            <li>"API restrictions" kısmında sadece gerekli API'leri seçin</li>
                            <li>"Save" butonuna tıklayın</li>
                        </ol>
                    </div>
                </div>

                <!-- Step 7 -->
                <div class="border-l-4 border-purple-500 pl-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-3">7️⃣ API Key'i Kodda Güncelleyin</h2>
                    <div class="space-y-3">
                        <p class="text-gray-700">API key'inizi aşağıdaki dosyada güncelleyin:</p>
                        <div class="bg-gray-900 text-gray-100 p-4 rounded-lg">
                            <p class="text-green-400 mb-2">admin/qr-generator.php dosyasında:</p>
                            <code class="text-sm">
                                &lt;script src="https://maps.googleapis.com/maps/api/js?key=<span class="text-yellow-400">BURAYA_API_KEY_YAZIN</span>&amp;libraries=places&amp;callback=initMap"&gt;&lt;/script&gt;
                            </code>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Cost Information -->
            <div class="mt-12 bg-green-50 border border-green-200 rounded-lg p-6">
                <h3 class="text-lg font-semibold text-green-800 mb-3">💰 Maliyet Bilgisi</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <h4 class="font-medium text-green-700 mb-2">Ücretsiz Limitler (Aylık)</h4>
                        <ul class="text-sm text-green-600 space-y-1">
                            <li>• 28,500 harita yüklemesi</li>
                            <li>• 40,000 geocoding isteği</li>
                            <li>• 17,000 adres arama isteği</li>
                            <li>• $200 ücretsiz kredi</li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-medium text-green-700 mb-2">Normal Kullanım</h4>
                        <ul class="text-sm text-green-600 space-y-1">
                            <li>• Küçük-orta işletmeler limiti aşmaz</li>
                            <li>• Günde 50-100 QR kod oluşturma güvenli</li>
                            <li>• Billing alarmı kurmanız önerilir</li>
                            <li>• İlk 3 ay ek $300 kredi</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="mt-8 text-center space-x-4">
                <a href="admin/qr-generator.php" 
                   class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors inline-block">
                    🔄 QR Generator'a Dön
                </a>
                <a href="https://console.cloud.google.com/" target="_blank"
                   class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-block">
                    🌐 Google Cloud Console
                </a>
            </div>
        </div>
    </div>
</body>
</html>