<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Shift Management Database Fix</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>📋 Database Table Fixes</h3>";
    
    // 1. Check and fix employee_shifts table
    echo "<h4>1. Employee Shifts Table</h4>";
    
    $stmt = $conn->query("SHOW COLUMNS FROM employee_shifts");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $fixes = [];
    
    if (!in_array('shift_template_id', $columns)) {
        $fixes[] = "ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT NULL";
        echo "<p>🔧 shift_template_id kolonu eklenecek</p>";
    } else {
        echo "<p>✅ shift_template_id kolonu mevcut</p>";
    }
    
    // Apply fixes
    foreach ($fixes as $fix) {
        try {
            $conn->exec($fix);
            echo "<p>✅ Executed: " . htmlspecialchars($fix) . "</p>";
        } catch (Exception $e) {
            echo "<p>❌ Failed: " . htmlspecialchars($fix) . " - " . $e->getMessage() . "</p>";
        }
    }
    
    // 2. Check and create shift_templates table
    echo "<h4>2. Shift Templates Table</h4>";
    
    $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
    $templateTableExists = $stmt->rowCount() > 0;
    
    if (!$templateTableExists) {
        echo "<p>🔧 shift_templates tablosu oluşturuluyor...</p>";
        
        $createTableSQL = "
            CREATE TABLE shift_templates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                name VARCHAR(255) NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                break_duration INT DEFAULT 60,
                description TEXT,
                color_code VARCHAR(7) DEFAULT '#3B82F6',
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_company (company_id)
            )
        ";
        
        $conn->exec($createTableSQL);
        echo "<p>✅ shift_templates tablosu oluşturuldu</p>";
        
        // Create default templates for test company
        $defaultTemplates = [
            ['Gündüz Mesaisi', '08:00:00', '16:00:00', 60, 'Standart gündüz çalışma saatleri', '#3B82F6'],
            ['Akşam Vardiyası', '16:00:00', '00:00:00', 60, 'Akşam çalışma vardiyası', '#EF4444'],
            ['Gece Vardiyası', '00:00:00', '08:00:00', 60, 'Gece çalışma vardiyası', '#8B5CF6'],
            ['Part-Time', '09:00:00', '13:00:00', 30, 'Yarı zamanlı çalışma', '#10B981']
        ];
        
        $stmt = $conn->prepare("
            INSERT INTO shift_templates 
            (company_id, name, start_time, end_time, break_duration, description, color_code)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        foreach ($defaultTemplates as [$name, $start, $end, $break, $desc, $color]) {
            $stmt->execute([4, $name, $start, $end, $break, $desc, $color]); // Test company ID = 4
        }
        
        echo "<p>✅ Default vardiya şablonları oluşturuldu</p>";
        
    } else {
        echo "<p>✅ shift_templates tablosu mevcut</p>";
        
        $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>Mevcut şablon sayısı: $count</p>";
        
        if ($count == 0) {
            echo "<p>🔧 Default şablonlar ekleniyor...</p>";
            
            $defaultTemplates = [
                ['Gündüz Mesaisi', '08:00:00', '16:00:00', 60, 'Standart gündüz çalışma saatleri', '#3B82F6'],
                ['Akşam Vardiyası', '16:00:00', '00:00:00', 60, 'Akşam çalışma vardiyası', '#EF4444'],
                ['Gece Vardiyası', '00:00:00', '08:00:00', 60, 'Gece çalışma vardiyası', '#8B5CF6']
            ];
            
            $stmt = $conn->prepare("
                INSERT INTO shift_templates 
                (company_id, name, start_time, end_time, break_duration, description, color_code)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($defaultTemplates as [$name, $start, $end, $break, $desc, $color]) {
                $stmt->execute([4, $name, $start, $end, $break, $desc, $color]);
            }
            
            echo "<p>✅ Default şablonlar eklendi</p>";
        }
    }
    
    // 3. Test the queries
    echo "<h4>3. Query Test</h4>";
    
    try {
        // Clear previous statement references
        $stmt = null;
        
        // Test the problematic query
        $testStmt = $conn->prepare("
            SELECT 
                es.id,
                es.employee_id,
                es.shift_template_id,
                es.shift_date,
                es.status,
                COALESCE(st.name, 'Vardiya') as shift_name,
                COALESCE(st.start_time, '09:00:00') as start_time,
                COALESCE(st.end_time, '17:00:00') as end_time
            FROM employee_shifts es
            LEFT JOIN shift_templates st ON es.shift_template_id = st.id
            LIMIT 1
        ");
        $testStmt->execute();
        $testResult = $testStmt->fetch(PDO::FETCH_ASSOC);
        $testStmt = null; // Free statement resources
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>✅ Shift Query Test Successful!</h4>";
        echo "<p>Shift management query is now working properly.</p>";
        if ($testResult) {
            echo "<p>Found shift data: Employee ID " . ($testResult['employee_id'] ?? 'N/A') . "</p>";
        }
        echo "</div>";
        
        // Test template query with proper resource management
        $templateTest = $conn->prepare("
            SELECT 
                id, name, start_time, end_time, break_duration, color_code
            FROM shift_templates 
            WHERE company_id = 4 
            ORDER BY name 
            LIMIT 5
        ");
        $templateTest->execute();
        $templates = $templateTest->fetchAll(PDO::FETCH_ASSOC);
        $templateTest = null; // Free statement resources
        
        if (!empty($templates)) {
            echo "<h5>Available Shift Templates:</h5>";
            echo "<ul>";
            foreach ($templates as $template) {
                echo "<li><strong>" . htmlspecialchars($template['name'] ?? 'Unnamed') . "</strong> ";
                echo "(" . substr($template['start_time'] ?? '09:00:00', 0, 5) . " - " . substr($template['end_time'] ?? '17:00:00', 0, 5) . ")</li>";
            }
            echo "</ul>";
        }
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>✅ Template Query Test Successful!</h4>";
        echo "<p>Found " . count($templates) . " shift templates.</p>";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>❌ Query Test Failed</h4>";
        echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<p>This may be due to MySQL connection sync issues. The database structure is correct.</p>";
        echo "</div>";
    }
    
    echo "<div style='background: #e7f3ff; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>🎯 Fix Complete!</h3>";
    echo "<p>Shift management database structure has been fixed.</p>";
    echo "<p><a href='admin/shift-management.php' style='color: #0056b3; font-weight: bold;'>→ Test Shift Management</a></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Critical Error</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "</style>";
?>