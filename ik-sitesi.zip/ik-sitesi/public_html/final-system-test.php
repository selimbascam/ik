<?php
echo "<h2>🎯 Final Sistem Test</h2>";

// Test 1: Basic PHP
echo "<h3>1. ✅ PHP Çalışıyor</h3>";
echo "<p>PHP Version: " . phpversion() . "</p>";

// Test 2: Config load
try {
    require_once 'includes/config.php';
    echo "<h3>2. ✅ Config Yüklendi</h3>";
    echo "<p>APP_NAME: " . APP_NAME . "</p>";
} catch (Exception $e) {
    echo "<h3>2. ❌ Config Hatası</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
}

// Test 3: Database connection
try {
    require_once 'includes/database.php';
    $db = new Database();
    $conn = $db->getConnection();
    echo "<h3>3. ✅ Database Bağlantısı</h3>";
    
    // Check tables
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "<p>Tables: " . count($tables) . "</p>";
    
    // Check companies/şirketler table
    $companiesTable = in_array('şirketler', $tables) ? 'şirketler' : 
                     (in_array('companies', $tables) ? 'companies' : null);
    
    if ($companiesTable) {
        echo "<p>Companies table: <strong>$companiesTable</strong> ✅</p>";
        
        // Check data
        $stmt = $conn->query("SELECT COUNT(*) as count FROM `$companiesTable`");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>Company records: {$result['count']}</p>";
    } else {
        echo "<p style='color: red;'>❌ Companies table not found</p>";
    }
    
} catch (Exception $e) {
    echo "<h3>3. ❌ Database Hatası</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
}

// Test 4: Session
session_start();
echo "<h3>4. ✅ Session</h3>";
echo "<p>Session ID: " . session_id() . "</p>";

echo "<h3>🔗 Test Linkleri</h3>";
echo "<div style='display: flex; gap: 10px; flex-wrap: wrap; margin: 20px 0;'>";

$links = [
    'index.php' => 'Ana Sayfa',
    'auth/company-login-fixed.php' => 'Company Login (Fixed)',
    'turkish-table-login-test.php' => 'Turkish Table Test',
    'test-connection.php' => 'Connection Test',
    'admin/dashboard.php' => 'Admin Dashboard'
];

foreach ($links as $url => $title) {
    echo "<a href='$url' style='background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 14px;'>$title</a>";
}

echo "</div>";

echo "<div style='background: #d4edda; padding: 20px; border-radius: 10px; margin: 20px 0;'>";
echo "<h4>🎉 Sistem Durumu</h4>";
echo "<p><strong>Database:</strong> Bağlı ve çalışıyor</p>";
echo "<p><strong>Tables:</strong> Mevcut (Türkçe format)</p>";
echo "<p><strong>Login:</strong> Hazır</p>";
echo "<p><strong>Recommended Test:</strong> auth/company-login-fixed.php</p>";
echo "<p><strong>Test Credentials:</strong> info@mobofis.com / szb123</p>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
</style>