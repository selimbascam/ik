<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔍 Personel QR Sistemi Veritabanı Analizi ve Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>1. Attendance Records Tablo Yapısı Analizi</h3>";
    
    // Check current attendance_records table structure
    $stmt = $conn->query("SHOW CREATE TABLE attendance_records");
    $createTable = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h4>Mevcut Tablo Yapısı:</h4>";
    echo "<pre style='background: #f8f9fa; padding: 15px; border-radius: 5px; overflow: auto; font-size: 12px;'>";
    echo htmlspecialchars($createTable['Create Table']);
    echo "</pre>";
    
    // Analyze columns
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>Kolon Analizi:</h4>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Kolon Adı</th><th>Veri Tipi</th><th>Null</th><th>Varsayılan</th><th>Durum</th></tr>";
    
    $requiredColumns = [
        'id' => 'AUTO_INCREMENT PRIMARY KEY',
        'employee_id' => 'Foreign Key - employees.id',
        'qr_location_id' => 'Foreign Key - qr_locations.id', 
        'activity_type' => 'ENUM veya VARCHAR - work_start, work_end, break_start, break_end',
        'check_in_time' => 'DATETIME - QR okutma zamanı',
        'latitude' => 'DECIMAL(10,8) - GPS enlem',
        'longitude' => 'DECIMAL(11,8) - GPS boylam',
        'notes' => 'TEXT - Ek notlar',
        'created_at' => 'DATETIME - Kayıt oluşturma zamanı',
        'date' => 'DATE - Tarih indexi',
        'check_date' => 'DATE - Çalışma tarihi'
    ];
    
    $existingColumns = array_column($columns, 'Field');
    
    foreach ($requiredColumns as $colName => $description) {
        $exists = in_array($colName, $existingColumns);
        $currentCol = null;
        
        if ($exists) {
            foreach ($columns as $col) {
                if ($col['Field'] === $colName) {
                    $currentCol = $col;
                    break;
                }
            }
        }
        
        echo "<tr>";
        echo "<td><strong>$colName</strong></td>";
        echo "<td>" . ($currentCol ? $currentCol['Type'] : 'YOK') . "</td>";
        echo "<td>" . ($currentCol ? $currentCol['Null'] : 'YOK') . "</td>";
        echo "<td>" . ($currentCol ? ($currentCol['Default'] ?? 'NULL') : 'YOK') . "</td>";
        echo "<td>" . ($exists ? '✅ VAR' : '❌ EKSİK') . "</td>";
        echo "</tr>";
        
        if ($exists) {
            echo "<tr><td colspan='5' style='font-size: 11px; color: #666;'>$description</td></tr>";
        }
    }
    echo "</table>";
    
    echo "<h3>2. Eksik Kolonları Ekleme</h3>";
    
    $alterQueries = [];
    
    // Check and add missing columns
    if (!in_array('qr_location_id', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN qr_location_id INT DEFAULT NULL, ADD INDEX idx_qr_location (qr_location_id)";
    }
    
    if (!in_array('activity_type', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN activity_type ENUM('work_start', 'work_end', 'break_start', 'break_end', 'check_in', 'check_out') DEFAULT 'work_start'";
    }
    
    if (!in_array('check_in_time', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN check_in_time DATETIME DEFAULT NULL";
    }
    
    if (!in_array('latitude', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN latitude DECIMAL(10, 8) DEFAULT NULL COMMENT 'GPS Enlem Koordinatı'";
    }
    
    if (!in_array('longitude', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN longitude DECIMAL(11, 8) DEFAULT NULL COMMENT 'GPS Boylam Koordinatı'";
    }
    
    if (!in_array('notes', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN notes TEXT DEFAULT NULL COMMENT 'QR okutma detayları'";
    }
    
    if (!in_array('created_at', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP";
    }
    
    if (!in_array('date', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN date DATE DEFAULT NULL, ADD INDEX idx_date (date)";
    }
    
    if (!in_array('check_date', $existingColumns)) {
        $alterQueries[] = "ALTER TABLE attendance_records ADD COLUMN check_date DATE DEFAULT NULL, ADD INDEX idx_check_date (check_date)";
    }
    
    foreach ($alterQueries as $query) {
        try {
            $conn->exec($query);
            echo "<p>✅ " . substr($query, 0, 80) . "...</p>";
        } catch (Exception $e) {
            echo "<p>⚠️ Hata: " . $e->getMessage() . "</p>";
        }
    }
    
    if (empty($alterQueries)) {
        echo "<p>✅ Tüm gerekli kolonlar mevcut</p>";
    }
    
    echo "<h3>3. QR Locations Tablo Kontrol</h3>";
    
    // Check qr_locations table
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM qr_locations");
        $qrColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>QR Locations Kolonları:</h4>";
        echo "<ul>";
        foreach ($qrColumns as $col) {
            echo "<li>" . $col['Field'] . " (" . $col['Type'] . ")</li>";
        }
        echo "</ul>";
        
        // Check if gate_behavior column exists
        $qrColumnNames = array_column($qrColumns, 'Field');
        if (!in_array('gate_behavior', $qrColumnNames)) {
            try {
                $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior ENUM('work_start', 'work_end', 'break_toggle', 'user_choice') DEFAULT 'user_choice'");
                echo "<p>✅ gate_behavior kolonu eklendi</p>";
            } catch (Exception $e) {
                echo "<p>⚠️ gate_behavior kolonu eklenemedi: " . $e->getMessage() . "</p>";
            }
        } else {
            echo "<p>✅ gate_behavior kolonu mevcut</p>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ QR Locations tablo hatası: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>4. Employees Tablo Kontrol</h3>";
    
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees");
        $empColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $empColumnNames = array_column($empColumns, 'Field');
        $employeeRequiredColumns = ['id', 'employee_number', 'password', 'first_name', 'last_name', 'company_id'];
        
        echo "<h4>Employee Kolonları Kontrol:</h4>";
        echo "<ul>";
        foreach ($employeeRequiredColumns as $col) {
            $exists = in_array($col, $empColumnNames);
            echo "<li>$col: " . ($exists ? '✅' : '❌') . "</li>";
        }
        echo "</ul>";
        
    } catch (Exception $e) {
        echo "<p>❌ Employees tablo hatası: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>5. Veri Tutarlılığı Kontrol</h3>";
    
    // Check data consistency
    $testEmployeeNumber = '30716129672';
    
    // Get test employee
    $stmt = $conn->prepare("SELECT * FROM employees WHERE employee_number = ?");
    $stmt->execute([$testEmployeeNumber]);
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testEmployee) {
        echo "<h4>Test Personeli: " . htmlspecialchars($testEmployee['first_name'] . ' ' . $testEmployee['last_name']) . "</h4>";
        
        // Check QR locations for this company
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ?");
        $stmt->execute([$testEmployee['company_id']]);
        $qrLocationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "<p>Şirket QR lokasyonları: $qrLocationCount adet</p>";
        
        // Check today's attendance records
        $today = date('Y-m-d');
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM attendance_records WHERE employee_id = ? AND date = ?");
        $stmt->execute([$testEmployee['id'], $today]);
        $todayRecordsCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "<p>Bugünkü devam kayıtları: $todayRecordsCount adet</p>";
        
        // Check latest attendance record structure
        $stmt = $conn->prepare("
            SELECT ar.*, ql.name as location_name 
            FROM attendance_records ar 
            LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
            WHERE ar.employee_id = ? 
            ORDER BY ar.check_in_time DESC 
            LIMIT 1
        ");
        $stmt->execute([$testEmployee['id']]);
        $latestRecord = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($latestRecord) {
            echo "<h4>Son Kayıt Örneği:</h4>";
            echo "<pre style='background: #e7f3ff; padding: 10px; border-radius: 5px;'>";
            foreach ($latestRecord as $key => $value) {
                echo "$key: " . ($value ?? 'NULL') . "\n";
            }
            echo "</pre>";
        }
        
    } else {
        echo "<p>❌ Test personeli bulunamadı</p>";
    }
    
    echo "<h3>6. QR Okutma Test Simülasyonu</h3>";
    
    if ($testEmployee) {
        // Simulate QR attendance record creation
        try {
            // Get a test QR location
            $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? AND is_active = 1 LIMIT 1");
            $stmt->execute([$testEmployee['company_id']]);
            $testLocation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($testLocation) {
                // Create test attendance record with proper structure
                $testTime = date('Y-m-d H:i:s');
                $testDate = date('Y-m-d');
                
                // Check columns again before insert
                $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
                $finalColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
                $hasGPS = in_array('latitude', $finalColumns) && in_array('longitude', $finalColumns);
                
                if ($hasGPS) {
                    $insertQuery = "
                        INSERT INTO attendance_records 
                        (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, 
                         notes, created_at, date, check_date) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)
                    ";
                    $params = [
                        $testEmployee['id'],
                        $testLocation['id'],
                        'work_start',
                        $testTime,
                        $testLocation['latitude'] ?? 41.0082,
                        $testLocation['longitude'] ?? 28.9784,
                        'Test QR okutma - Veritabanı kontrol',
                        $testDate,
                        $testDate
                    ];
                } else {
                    $insertQuery = "
                        INSERT INTO attendance_records 
                        (employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date, check_date) 
                        VALUES (?, ?, ?, ?, ?, NOW(), ?, ?)
                    ";
                    $params = [
                        $testEmployee['id'],
                        $testLocation['id'],
                        'work_start',
                        $testTime,
                        'Test QR okutma - Veritabanı kontrol (GPS yok)',
                        $testDate,
                        $testDate
                    ];
                }
                
                $stmt = $conn->prepare($insertQuery);
                $result = $stmt->execute($params);
                
                if ($result) {
                    $recordId = $conn->lastInsertId();
                    echo "<p>✅ Test QR kayıt oluşturuldu (ID: $recordId)</p>";
                    
                    // Verify the record
                    $stmt = $conn->prepare("SELECT * FROM attendance_records WHERE id = ?");
                    $stmt->execute([$recordId]);
                    $verifyRecord = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    echo "<h4>Oluşturulan Kayıt Doğrulama:</h4>";
                    echo "<pre style='background: #d4edda; padding: 10px; border-radius: 5px;'>";
                    foreach ($verifyRecord as $key => $value) {
                        echo "$key: " . ($value ?? 'NULL') . "\n";
                    }
                    echo "</pre>";
                    
                } else {
                    echo "<p>❌ Test QR kayıt oluşturulamadı</p>";
                }
                
            } else {
                echo "<p>❌ Test QR lokasyonu bulunamadı</p>";
            }
            
        } catch (Exception $e) {
            echo "<p>❌ QR test hatası: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<h3>7. Index ve Performans Optimizasyonu</h3>";
    
    // Add important indexes if missing
    $indexQueries = [
        "CREATE INDEX IF NOT EXISTS idx_employee_date ON attendance_records(employee_id, date)",
        "CREATE INDEX IF NOT EXISTS idx_employee_activity ON attendance_records(employee_id, activity_type)",
        "CREATE INDEX IF NOT EXISTS idx_check_in_time ON attendance_records(check_in_time)",
        "CREATE INDEX IF NOT EXISTS idx_qr_location_activity ON attendance_records(qr_location_id, activity_type)"
    ];
    
    foreach ($indexQueries as $indexQuery) {
        try {
            $conn->exec($indexQuery);
            echo "<p>✅ " . substr($indexQuery, 0, 60) . "...</p>";
        } catch (Exception $e) {
            // Index might already exist
            echo "<p>⚠️ Index zaten var veya eklenemedi</p>";
        }
    }
    
    echo "<h3>✅ Veritabanı Analizi Tamamlandı</h3>";
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>🎯 Veritabanı Durumu</h4>";
    echo "<ul>";
    echo "<li>✅ Attendance records tablosu optimize edildi</li>";
    echo "<li>✅ GPS koordinat desteği eklendi</li>";
    echo "<li>✅ Activity type sistemi kuruldu</li>";
    echo "<li>✅ QR location bağlantıları düzenlendi</li>";
    echo "<li>✅ Performans indexleri eklendi</li>";
    echo "<li>✅ Veri tutarlılığı kontrol edildi</li>";
    echo "</ul>";
    
    echo "<h4>Test Bilgileri:</h4>";
    echo "<p>Employee Number: $testEmployeeNumber</p>";
    echo "<p>Test URL: <a href='employee/qr-attendance.php'>employee/qr-attendance.php</a></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Veritabanı Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { margin: 10px 0; border-collapse: collapse; width: 100%; }";
echo "th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }";
echo "th { background-color: #f8f9fa; font-weight: bold; }";
echo "pre { font-size: 11px; max-height: 400px; overflow: auto; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "h3 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-top: 30px; }";
echo "</style>";
?>