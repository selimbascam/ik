-- SZB İK Takip - Complete Database Structure
-- MySQL 8.x Compatible Database Schema
-- Run this to ensure all tables have correct structure

-- Companies Table
CREATE TABLE IF NOT EXISTS companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    company_code VARCHAR(50) UNIQUE NOT NULL,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(20),
    address TEXT,
    tax_number VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Company Users Table (Admins, HR, Managers)
CREATE TABLE IF NOT EXISTS company_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    role ENUM('admin', 'hr', 'manager') DEFAULT 'admin',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_company_username (company_id, username),
    UNIQUE KEY unique_company_email (company_id, email),
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Employees Table
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    employee_number VARCHAR(50) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    hire_date DATE NOT NULL,
    birth_date DATE,
    national_id VARCHAR(50),
    address TEXT,
    department_id INT DEFAULT 0,
    position VARCHAR(100),
    salary DECIMAL(10,2) DEFAULT 0.00,
    password_hash VARCHAR(255),
    status ENUM('active', 'inactive', 'terminated') DEFAULT 'active',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_company_employee_number (company_id, employee_number),
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Work Settings Table
CREATE TABLE IF NOT EXISTS work_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    monthly_hours INT DEFAULT 225,
    weekly_hours INT DEFAULT 45,
    daily_hours INT DEFAULT 8,
    hourly_rate DECIMAL(10,2) DEFAULT 0.00,
    overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
    holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
    auto_schedule TINYINT(1) DEFAULT 0,
    break_duration INT DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_company_settings (company_id),
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Shift Templates Table
CREATE TABLE IF NOT EXISTS shift_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_duration INT DEFAULT 60,
    description TEXT,
    color_code VARCHAR(7) DEFAULT '#3B82F6',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Legacy Shifts Table (for fallback compatibility)
CREATE TABLE IF NOT EXISTS shifts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_duration INT DEFAULT 60,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Employee Shifts Assignment Table
CREATE TABLE IF NOT EXISTS employee_shifts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    shift_template_id INT NOT NULL,
    shift_date DATE NOT NULL,
    status ENUM('scheduled', 'completed', 'absent', 'late', 'early_leave') DEFAULT 'scheduled',
    late_reason TEXT,
    early_leave_reason TEXT,
    absence_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_date (employee_id, shift_date),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
);

-- QR Locations Table
CREATE TABLE IF NOT EXISTS qr_locations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    location_name VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    qr_code VARCHAR(500) NOT NULL,
    tolerance_meters INT DEFAULT 100,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Attendance Records Table
CREATE TABLE IF NOT EXISTS attendance_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    check_in TIMESTAMP NULL,
    check_out TIMESTAMP NULL,
    break_start TIMESTAMP NULL,
    break_end TIMESTAMP NULL,
    total_break_time INT DEFAULT 0,
    location_name VARCHAR(255),
    qr_location_id INT,
    ip_address VARCHAR(45),
    device_info TEXT,
    check_in_latitude DECIMAL(10, 8),
    check_in_longitude DECIMAL(11, 8),
    check_out_latitude DECIMAL(10, 8),
    check_out_longitude DECIMAL(11, 8),
    activity_status ENUM('checked_in', 'on_break', 'checked_out') DEFAULT 'checked_in',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (qr_location_id) REFERENCES qr_locations(id) ON DELETE SET NULL
);

-- Employee Devices Table
CREATE TABLE IF NOT EXISTS employee_devices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    device_fingerprint VARCHAR(500) NOT NULL,
    device_name VARCHAR(255),
    user_agent TEXT,
    ip_address VARCHAR(45),
    screen_resolution VARCHAR(20),
    timezone VARCHAR(50),
    language VARCHAR(10),
    is_trusted TINYINT(1) DEFAULT 0,
    is_blocked TINYINT(1) DEFAULT 0,
    last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_device (employee_id, device_fingerprint),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Leave Types Table
CREATE TABLE IF NOT EXISTS leave_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    days_per_year INT DEFAULT 14,
    requires_approval TINYINT(1) DEFAULT 1,
    is_paid TINYINT(1) DEFAULT 1,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Leave Requests Table
CREATE TABLE IF NOT EXISTS leave_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_days INT NOT NULL,
    reason TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    rejection_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES company_users(id) ON DELETE SET NULL
);

-- Public Holidays Table
CREATE TABLE IF NOT EXISTS public_holidays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    holiday_date DATE NOT NULL,
    holiday_name VARCHAR(255) NOT NULL,
    holiday_type ENUM('national', 'religious', 'company') DEFAULT 'national',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_company_date (company_id, holiday_date),
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Sessions Table (for PHP session storage)
CREATE TABLE IF NOT EXISTS sessions (
    sid VARCHAR(128) PRIMARY KEY,
    sess JSON NOT NULL,
    expire TIMESTAMP NOT NULL,
    INDEX IDX_session_expire (expire)
);

-- Super Admin Users Table
CREATE TABLE IF NOT EXISTS super_admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(200),
    is_active TINYINT(1) DEFAULT 1,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default super admin (password: admin123)
INSERT IGNORE INTO super_admin_users (username, password_hash, email, full_name) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@szb.com.tr', 'System Administrator');

-- Add missing columns to existing tables (MySQL safe column additions)

-- Add missing columns to employees table
ALTER TABLE employees 
ADD COLUMN IF NOT EXISTS is_active TINYINT(1) DEFAULT 1,
ADD COLUMN IF NOT EXISTS status ENUM('active', 'inactive', 'terminated') DEFAULT 'active';

-- Add missing columns to employee_devices table  
ALTER TABLE employee_devices 
ADD COLUMN IF NOT EXISTS is_blocked TINYINT(1) DEFAULT 0;

-- Add missing columns to work_settings table
ALTER TABLE work_settings 
ADD COLUMN IF NOT EXISTS hourly_rate DECIMAL(10,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS monthly_hours INT DEFAULT 225;

-- Add missing columns to shift_templates table
ALTER TABLE shift_templates 
ADD COLUMN IF NOT EXISTS description TEXT,
ADD COLUMN IF NOT EXISTS color_code VARCHAR(7) DEFAULT '#3B82F6',
ADD COLUMN IF NOT EXISTS is_active TINYINT(1) DEFAULT 1;

-- Ensure employee_shifts has the correct column name
ALTER TABLE employee_shifts 
ADD COLUMN IF NOT EXISTS shift_template_id INT,
ADD INDEX IF NOT EXISTS idx_shift_template (shift_template_id);

-- Update existing employee_shifts records to use shift_template_id if they use shift_id
UPDATE employee_shifts SET shift_template_id = shift_id WHERE shift_template_id IS NULL AND shift_id IS NOT NULL;

-- Create views for reporting (optional but helpful)
CREATE OR REPLACE VIEW employee_attendance_summary AS
SELECT 
    e.id as employee_id,
    e.first_name,
    e.last_name,
    e.employee_number,
    c.company_name,
    COUNT(DISTINCT DATE(ar.check_in)) as days_worked_this_month,
    SUM(TIMESTAMPDIFF(MINUTE, ar.check_in, IFNULL(ar.check_out, NOW()))) / 60 as total_hours_this_month
FROM employees e
LEFT JOIN companies c ON e.company_id = c.id
LEFT JOIN attendance_records ar ON e.id = ar.employee_id 
    AND MONTH(ar.check_in) = MONTH(CURRENT_DATE())
    AND YEAR(ar.check_in) = YEAR(CURRENT_DATE())
WHERE e.is_active = 1
GROUP BY e.id, e.first_name, e.last_name, e.employee_number, c.company_name;

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_attendance_employee_date ON attendance_records(employee_id, DATE(check_in));
CREATE INDEX IF NOT EXISTS idx_employee_shifts_date ON employee_shifts(employee_id, shift_date);
CREATE INDEX IF NOT EXISTS idx_leave_requests_employee ON leave_requests(employee_id, status);
CREATE INDEX IF NOT EXISTS idx_holidays_company_date ON public_holidays(company_id, holiday_date);

-- Database maintenance
OPTIMIZE TABLE companies;
OPTIMIZE TABLE employees;
OPTIMIZE TABLE attendance_records;
OPTIMIZE TABLE employee_shifts;
OPTIMIZE TABLE shift_templates;