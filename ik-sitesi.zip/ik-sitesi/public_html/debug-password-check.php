<?php
// Şifre kontrol debug sistemi
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>Personel Şifre Kontrol Sistemi</h2>";
    
    $employee_id = '30716129672';
    $test_password = 'Abc123456';
    
    // Personel bilgilerini al
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, employee_number, tc_no, password, company_id 
        FROM employees 
        WHERE employee_number = ? OR tc_no = ?
    ");
    $stmt->execute([$employee_id, $employee_id]);
    $employee = $stmt->fetch();
    
    if ($employee) {
        echo "<h3>Personel Bulundu:</h3>";
        echo "ID: " . $employee['id'] . "<br>";
        echo "Ad Soyad: " . $employee['first_name'] . " " . $employee['last_name'] . "<br>";
        echo "Personel No: " . $employee['employee_number'] . "<br>";
        echo "Şirket ID: " . $employee['company_id'] . "<br>";
        echo "Şifre Değeri: " . ($employee['password'] ? "MEVCUT" : "BOŞ") . "<br>";
        
        if ($employee['password']) {
            echo "Şifre Hash: " . substr($employee['password'], 0, 50) . "...<br>";
            echo "Şifre Uzunluğu: " . strlen($employee['password']) . " karakter<br><br>";
            
            // Şifre test sonuçları
            echo "<h3>Şifre Test Sonuçları (Test Şifre: '{$test_password}'):</h3>";
            
            // 1. Direct comparison
            $direct = ($employee['password'] === $test_password);
            echo "1. Doğrudan Karşılaştırma: " . ($direct ? '✅ EŞLEŞİYOR' : '❌ EŞLEŞMİYOR') . "<br>";
            
            // 2. password_verify (modern hash)
            $verify = password_verify($test_password, $employee['password']);
            echo "2. Password Verify (Hash): " . ($verify ? '✅ EŞLEŞİYOR' : '❌ EŞLEŞMİYOR') . "<br>";
            
            // 3. MD5 check
            $md5 = (md5($test_password) === $employee['password']);
            echo "3. MD5 Hash: " . ($md5 ? '✅ EŞLEŞİYOR' : '❌ EŞLEŞMİYOR') . "<br>";
            
            // 4. SHA256 check
            $sha256 = (hash('sha256', $test_password) === $employee['password']);
            echo "4. SHA256 Hash: " . ($sha256 ? '✅ EŞLEŞİYOR' : '❌ EŞLEŞMİYOR') . "<br>";
            
            // 5. MySQL PASSWORD() check
            try {
                $stmt = $conn->prepare("SELECT PASSWORD(?) as mysql_hash");
                $stmt->execute([$test_password]);
                $mysqlHash = $stmt->fetch()['mysql_hash'];
                $mysql = ($mysqlHash === $employee['password']);
                echo "5. MySQL PASSWORD(): " . ($mysql ? '✅ EŞLEŞİYOR' : '❌ EŞLEŞMİYOR') . "<br>";
                echo "   MySQL Hash Sonuç: " . substr($mysqlHash, 0, 50) . "...<br>";
            } catch (Exception $e) {
                echo "5. MySQL PASSWORD(): ❌ HATA - " . $e->getMessage() . "<br>";
            }
            
            // 6. Bcrypt check
            if (substr($employee['password'], 0, 4) === '$2y$' || substr($employee['password'], 0, 4) === '$2a$') {
                echo "6. Bcrypt Tespit Edildi: ✅ Format Doğru<br>";
            } else {
                echo "6. Bcrypt Format: ❌ Değil<br>";
            }
            
            // Test different passwords
            echo "<br><h3>Farklı Şifreler ile Test:</h3>";
            $test_passwords = ['12345', '123456', 'test', 'password', 'Abc123456', '', 'abc123456'];
            
            foreach ($test_passwords as $test) {
                $results = [];
                
                if ($employee['password'] === $test) $results[] = 'DİREKT';
                if (password_verify($test, $employee['password'])) $results[] = 'HASH';
                if (md5($test) === $employee['password']) $results[] = 'MD5';
                if (hash('sha256', $test) === $employee['password']) $results[] = 'SHA256';
                
                $result = empty($results) ? '❌' : '✅ ' . implode(', ', $results);
                echo "Şifre '{$test}': {$result}<br>";
            }
        } else {
            echo "<br><strong style='color: red;'>ŞİFRE BOŞ - Bu durumda herhangi bir şifre ile giriş yapabilir!</strong><br>";
        }
        
    } else {
        echo "<h3 style='color: red;'>Personel Bulunamadı!</h3>";
        echo "Aranan ID: {$employee_id}<br>";
        
        // Tüm personelleri listele
        $stmt = $conn->query("SELECT id, first_name, last_name, employee_number, tc_no FROM employees");
        $all = $stmt->fetchAll();
        
        echo "<h4>Sistemdeki Tüm Personeller:</h4>";
        foreach ($all as $emp) {
            echo "ID: {$emp['id']}, Ad: {$emp['first_name']} {$emp['last_name']}, No: {$emp['employee_number']}, TC: {$emp['tc_no']}<br>";
        }
    }
    
} catch (Exception $e) {
    echo "<h2 style='color: red;'>Hata: " . $e->getMessage() . "</h2>";
}
?>

<p><a href="auth/employee-login.php">← Personel Giriş Sayfasına Dön</a></p>