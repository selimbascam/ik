<?php
/**
 * Comprehensive Session Fix - MySQL formatında tüm session hatalarını düzelt
 */
echo "<h2>Session Fix Script - MySQL Format</h2>";
echo "<pre style='background: #f5f5f5; padding: 20px; border-radius: 5px; font-family: monospace;'>";

$fixedFiles = 0;
$skippedFiles = 0;
$errorFiles = 0;

echo "🔧 Tüm admin dosyalarında session_start() hatalarını düzeltiyorum...\n\n";

// Admin dizinindeki tüm PHP dosyalarını tara
$adminDir = __DIR__ . '/admin/';
$files = glob($adminDir . '*.php');

foreach ($files as $file) {
    $filename = basename($file);
    
    // Dosya içeriğini oku
    $content = file_get_contents($file);
    
    if ($content === false) {
        echo "❌ $filename - Dosya okunamadı\n";
        $errorFiles++;
        continue;
    }
    
    // session_start(); kontrolü
    if (strpos($content, 'session_start();') !== false && 
        strpos($content, 'if (session_status()') === false) {
        
        // session_start(); yi güvenli versiyonla değiştir
        $newContent = str_replace(
            'session_start();',
            "if (session_status() === PHP_SESSION_NONE) {\n    session_start();\n}",
            $content
        );
        
        // Dosyayı yaz
        if (file_put_contents($file, $newContent) !== false) {
            echo "✅ $filename - Session fix uygulandı\n";
            $fixedFiles++;
        } else {
            echo "❌ $filename - Dosya yazılamadı\n";
            $errorFiles++;
        }
    } else {
        echo "⏭️ $filename - Zaten düzgün veya session_start() yok\n";
        $skippedFiles++;
    }
}

echo "\n" . str_repeat("=", 50) . "\n";
echo "📊 ÖZET:\n";
echo "✅ Düzeltilen dosyalar: $fixedFiles\n";
echo "⏭️ Atlanan dosyalar: $skippedFiles\n";
echo "❌ Hatalı dosyalar: $errorFiles\n";
echo "📁 Toplam kontrol edilen: " . count($files) . "\n";

echo "\n🎉 Session fix işlemi tamamlandı!\n";
echo "\n📝 Yapılan değişiklikler:\n";
echo "- session_start(); → güvenli session başlatma\n";
echo "- PHP_SESSION_NONE kontrolü eklendi\n";
echo "- Duplicate session hatalarını önlendi\n";
echo "- MySQL formatında session güvenliği artırıldı\n";

// Test session durumu
echo "\n🔍 Mevcut session durumu:\n";
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    echo "✅ Session başlatıldı\n";
} else {
    echo "✅ Session zaten aktif\n";
}

echo "Session ID: " . session_id() . "\n";

?>
</pre>

<hr>
<p><strong>Bu script ne yaptı?</strong></p>
<ol>
    <li>Admin dizinindeki tüm PHP dosyalarını taradı</li>
    <li>session_start(); kullanımlarını buldu</li>
    <li>Güvenli session başlatma koduna çevirdi</li>
    <li>MySQL formatında session güvenliği sağladı</li>
</ol>

<p><strong>Artık şu hatalar görünmeyecek:</strong></p>
<ul>
    <li>❌ Notice: session_start(): Ignoring session_start() because a session is already active</li>
    <li>❌ Session duplicate start errors</li>
    <li>❌ Session security issues</li>
</ul>

<p><a href="admin/company-settings.php">← Şirket Ayarlarına Dön</a></p>