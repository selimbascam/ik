<?php
/**
 * DEMO001 şirketi "selim" kullanıcısı için QR davranış debug aracı
 */
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🔍 DEMO001 - Selim QR Debug Raporu</h1>";
    echo "<p>Tarih: " . date('d.m.Y H:i:s') . "</p><br>";
    
    // 1. DEMO001 şirket ID'sini bul
    $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE company_code = 'DEMO001'");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        echo "<p style='color:red;'>❌ DEMO001 şirketi bulunamadı!</p>";
        exit;
    }
    
    $companyId = $company['id'];
    echo "<h2>🏢 Şirket Bilgisi</h2>";
    echo "<p>ID: {$companyId}, İsim: {$company['company_name']}</p><br>";
    
    // 2. Selim kullanıcısını bul
    $stmt = $conn->prepare("SELECT id, first_name, last_name FROM employees WHERE company_id = ? AND (first_name LIKE '%selim%' OR last_name LIKE '%selim%')");
    $stmt->execute([$companyId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "<p style='color:red;'>❌ Selim kullanıcısı DEMO001 şirketinde bulunamadı!</p>";
        
        // Tüm çalışanları listele
        echo "<h3>DEMO001 şirketindeki tüm çalışanlar:</h3>";
        $stmt = $conn->prepare("SELECT id, first_name, last_name FROM employees WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($employees as $emp) {
            echo "<p>ID: {$emp['id']}, İsim: {$emp['first_name']} {$emp['last_name']}</p>";
        }
        exit;
    }
    
    $employeeId = $employee['id'];
    echo "<h2>👤 Çalışan Bilgisi</h2>";
    echo "<p>ID: {$employeeId}, İsim: {$employee['first_name']} {$employee['last_name']}</p><br>";
    
    // 3. QR lokasyonlarını kontrol et
    echo "<h2>🎯 QR Lokasyonları Analizi</h2>";
    
    // gate_behavior kolonu var mı kontrol et
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
    $hasBehaviorColumn = $stmt->rowCount() > 0;
    echo "<p>Gate Behavior Kolonu: " . ($hasBehaviorColumn ? "✅ VAR" : "❌ YOK") . "</p>";
    
    if ($hasBehaviorColumn) {
        $stmt = $conn->prepare("SELECT id, name, location_type, gate_behavior FROM qr_locations WHERE company_id = ? ORDER BY name");
    } else {
        $stmt = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE company_id = ? ORDER BY name");
    }
    $stmt->execute([$companyId]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($locations)) {
        echo "<p style='color:red;'>❌ DEMO001 şirketinde QR lokasyonu bulunamadı!</p>";
        exit;
    }
    
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>İsim</th><th>Location Type</th><th>Gate Behavior</th><th>Analiz</th></tr>";
    
    foreach ($locations as $location) {
        $name = mb_strtolower(trim($location['name']), 'UTF-8');
        
        // Türkçe karakter temizliği
        $cleanName = str_replace(['İ', 'I'], 'i', $name);
        $cleanName = str_replace(['Ğ'], 'ğ', $cleanName);
        $cleanName = str_replace(['Ü'], 'ü', $cleanName);
        $cleanName = str_replace(['Ş'], 'ş', $cleanName);
        $cleanName = str_replace(['Ö'], 'ö', $cleanName);
        $cleanName = str_replace(['Ç'], 'ç', $cleanName);
        
        // Ne olması gerektiğini belirle
        $shouldBe = 'user_choice';
        $analysis = 'Belirsiz';
        
        if (strpos($cleanName, 'mola') !== false) {
            $shouldBe = 'break_toggle';
            $analysis = "'mola' kelimesi bulundu";
        } elseif (strpos($cleanName, 'giriş') !== false || strpos($cleanName, 'giris') !== false) {
            $shouldBe = 'work_start';
            $analysis = "'giriş' kelimesi bulundu";
        } elseif (strpos($cleanName, 'çıkış') !== false || strpos($cleanName, 'cikis') !== false) {
            $shouldBe = 'work_end';
            $analysis = "'çıkış' kelimesi bulundu";
        }
        
        $currentBehavior = $hasBehaviorColumn ? ($location['gate_behavior'] ?? 'NULL') : 'KOLON YOK';
        $isCorrect = ($currentBehavior === $shouldBe);
        
        $bgColor = $isCorrect ? '#e8f5e8' : '#ffe8e8';
        
        echo "<tr style='background-color: {$bgColor};'>";
        echo "<td>{$location['id']}</td>";
        echo "<td>{$location['name']}<br><small style='color:gray;'>Temiz: {$cleanName}</small></td>";
        echo "<td>" . ($location['location_type'] ?? 'NULL') . "</td>";
        echo "<td style='font-weight:bold;'>{$currentBehavior}</td>";
        echo "<td>{$analysis}<br><strong>Olması gereken: {$shouldBe}</strong>" . ($isCorrect ? " ✅" : " ❌") . "</td>";
        echo "</tr>";
    }
    echo "</table><br>";
    
    // 4. QR okuyucu simülasyonu - gerçek QR okuyucudaki mantığı test et
    echo "<h2>🧪 QR Okuyucu Simülasyonu</h2>";
    
    foreach ($locations as $location) {
        echo "<h3>📍 Lokasyon: {$location['name']}</h3>";
        
        // QR reader'daki aynı mantığı uygula
        $qrName = mb_strtolower(trim($location['name']), 'UTF-8');
        
        // Türkçe karakter temizliği
        $qrName = str_replace(['İ', 'I'], 'i', $qrName);
        $qrName = str_replace(['Ğ'], 'ğ', $qrName);
        $qrName = str_replace(['Ü'], 'ü', $qrName);
        $qrName = str_replace(['Ş'], 'ş', $qrName);
        $qrName = str_replace(['Ö'], 'ö', $qrName);
        $qrName = str_replace(['Ç'], 'ç', $qrName);
        
        $debugInfo = "Debug: '{$location['name']}' → '$qrName'<br>";
        
        // QR reader'daki mantık
        if ($hasBehaviorColumn && !empty($location['gate_behavior']) && $location['gate_behavior'] !== 'user_choice') {
            $gateBehavior = $location['gate_behavior'];
            $debugInfo .= "✅ VERİTABANI KULLANILDI: {$gateBehavior}<br>";
        } else {
            // İsim analizi
            if (strpos($qrName, 'mola') !== false || strpos($qrName, 'break') !== false) {
                $gateBehavior = 'break_toggle';
                $debugInfo .= "✅ İSİM ANALİZİ: MOLA (break_toggle) - 'mola' bulundu<br>";
            }
            elseif (strpos($qrName, 'giriş') !== false || strpos($qrName, 'giris') !== false) {
                $gateBehavior = 'work_start';
                $debugInfo .= "✅ İSİM ANALİZİ: GIRIŞ (work_start) - 'giriş' bulundu<br>";
            }
            elseif (strpos($qrName, 'çıkış') !== false || strpos($qrName, 'cikis') !== false) {
                $gateBehavior = 'work_end';
                $debugInfo .= "✅ İSİM ANALİZİ: ÇIKIŞ (work_end) - 'çıkış' bulundu<br>";
            }
            else {
                $gateBehavior = 'user_choice';
                $debugInfo .= "⚠️ VARSAYILAN: user_choice kullanıldı<br>";
            }
        }
        
        echo "<div style='background: #f0f0f0; padding: 10px; margin: 10px 0;'>";
        echo $debugInfo;
        echo "<strong>SONUÇ GATE BEHAVIOR: {$gateBehavior}</strong>";
        echo "</div>";
    }
    
    // 5. Son kontrol - veritabanından direkt QR behavior'ları çek
    echo "<h2>📊 Veritabanı Son Durum</h2>";
    if ($hasBehaviorColumn) {
        $stmt = $conn->prepare("SELECT name, gate_behavior FROM qr_locations WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $finalCheck = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<ul>";
        foreach ($finalCheck as $qr) {
            echo "<li><strong>{$qr['name']}</strong>: {$qr['gate_behavior']}</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color:red;'>gate_behavior kolonu mevcut değil!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red;'>HATA: " . $e->getMessage() . "</p>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h1, h2, h3 { color: #333; }
table { margin: 20px 0; }
th { background-color: #f0f0f0; }
</style>