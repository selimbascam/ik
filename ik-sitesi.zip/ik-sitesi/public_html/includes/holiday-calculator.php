<?php
/**
 * Turkish Holiday Calculator
 * Automatically calculates Turkish national and religious holidays for any given year
 */

class TurkishHolidayCalculator {
    
    /**
     * Get all Turkish holidays for a given year
     */
    public static function getHolidaysForYear($year) {
        $holidays = [];
        
        // Fixed national holidays
        $nationalHolidays = self::getNationalHolidays($year);
        $holidays = array_merge($holidays, $nationalHolidays);
        
        // Religious holidays (calculated based on Islamic calendar)
        $religiousHolidays = self::getReligiousHolidays($year);
        $holidays = array_merge($holidays, $religiousHolidays);
        
        // Sort by date
        usort($holidays, function($a, $b) {
            return strtotime($a['date']) - strtotime($b['date']);
        });
        
        return $holidays;
    }
    
    /**
     * Fixed national holidays
     */
    private static function getNationalHolidays($year) {
        return [
            [
                'date' => "$year-01-01",
                'name' => 'Yılbaşı',
                'type' => 'national',
                'description' => 'Yeni yıl kutlaması'
            ],
            [
                'date' => "$year-04-23",
                'name' => 'Ulusal Egemenlik ve Çocuk Bayramı',
                'type' => 'national',
                'description' => 'TBMM\'nin açılışı ve çocuk bayramı'
            ],
            [
                'date' => "$year-05-01",
                'name' => 'İşçi Bayramı',
                'type' => 'national',
                'description' => 'Emek ve Dayanışma Günü'
            ],
            [
                'date' => "$year-05-19",
                'name' => 'Atatürk\'ü Anma Gençlik ve Spor Bayramı',
                'type' => 'national',
                'description' => 'Atatürk\'ün Samsun\'a çıkışı'
            ],
            [
                'date' => "$year-07-15",
                'name' => 'Demokrasi ve Milli Birlik Günü',
                'type' => 'national',
                'description' => '15 Temmuz darbe girişiminin püskürtülmesi'
            ],
            [
                'date' => "$year-08-30",
                'name' => 'Zafer Bayramı',
                'type' => 'national',
                'description' => 'Büyük Taarruz\'un başlangıcı'
            ],
            [
                'date' => "$year-10-29",
                'name' => 'Cumhuriyet Bayramı',
                'type' => 'national',
                'description' => 'Türkiye Cumhuriyeti\'nin ilanı'
            ]
        ];
    }
    
    /**
     * Religious holidays (calculated dynamically)
     * Note: These are approximate calculations based on astronomical calculations
     */
    private static function getReligiousHolidays($year) {
        $holidays = [];
        
        // Ramazan Bayramı (Eid al-Fitr) - 3 days
        $ramadanEid = self::calculateRamadanEid($year);
        if ($ramadanEid) {
            for ($i = 0; $i < 3; $i++) {
                $date = date('Y-m-d', strtotime($ramadanEid . " +$i days"));
                $holidays[] = [
                    'date' => $date,
                    'name' => 'Ramazan Bayramı ' . ($i + 1) . '. Gün',
                    'type' => 'religious',
                    'description' => 'Ramazan orucunun sona ermesi'
                ];
            }
        }
        
        // Kurban Bayramı (Eid al-Adha) - 4 days
        $sacrificeEid = self::calculateSacrificeEid($year);
        if ($sacrificeEid) {
            for ($i = 0; $i < 4; $i++) {
                $date = date('Y-m-d', strtotime($sacrificeEid . " +$i days"));
                $holidays[] = [
                    'date' => $date,
                    'name' => 'Kurban Bayramı ' . ($i + 1) . '. Gün',
                    'type' => 'religious',
                    'description' => 'Hac ibadeti ve kurban kesimi'
                ];
            }
        }
        
        return $holidays;
    }
    
    /**
     * Calculate Ramazan Bayramı (Eid al-Fitr) for given year
     * Based on Islamic calendar calculations
     */
    private static function calculateRamadanEid($year) {
        // Pre-calculated dates for accuracy (these should be updated from official sources)
        $knownDates = [
            2024 => '2024-04-10',
            2025 => '2025-03-31',
            2026 => '2026-03-20',
            2027 => '2027-03-10',
            2028 => '2028-02-27',
            2029 => '2029-02-15',
            2030 => '2030-02-05'
        ];
        
        if (isset($knownDates[$year])) {
            return $knownDates[$year];
        }
        
        // Fallback calculation (approximately 11 days earlier each year)
        $baseYear = 2025;
        $baseDate = '2025-03-31';
        $yearDiff = $year - $baseYear;
        
        if ($yearDiff != 0) {
            // Islamic year is approximately 354 days (11 days shorter than solar year)
            $daysDiff = $yearDiff * -11;
            return date('Y-m-d', strtotime($baseDate . " $daysDiff days"));
        }
        
        return $baseDate;
    }
    
    /**
     * Calculate Kurban Bayramı (Eid al-Adha) for given year
     * Based on Islamic calendar calculations
     */
    private static function calculateSacrificeEid($year) {
        // Pre-calculated dates for accuracy
        $knownDates = [
            2024 => '2024-06-16',
            2025 => '2025-06-07',
            2026 => '2026-05-27',
            2027 => '2027-05-16',
            2028 => '2028-05-05',
            2029 => '2029-04-24',
            2030 => '2030-04-13'
        ];
        
        if (isset($knownDates[$year])) {
            return $knownDates[$year];
        }
        
        // Fallback calculation (approximately 11 days earlier each year)
        $baseYear = 2025;
        $baseDate = '2025-06-07';
        $yearDiff = $year - $baseYear;
        
        if ($yearDiff != 0) {
            $daysDiff = $yearDiff * -11;
            return date('Y-m-d', strtotime($baseDate . " $daysDiff days"));
        }
        
        return $baseDate;
    }
    
    /**
     * Check if a given date is a holiday
     */
    public static function isHoliday($date, $companyId, $conn) {
        $year = date('Y', strtotime($date));
        
        // First check database
        $stmt = $conn->prepare("
            SELECT * FROM public_holidays 
            WHERE company_id = ? AND holiday_date = ?
        ");
        $stmt->execute([$companyId, $date]);
        $holiday = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($holiday) {
            return $holiday;
        }
        
        // If not found, check calculated holidays
        $holidays = self::getHolidaysForYear($year);
        foreach ($holidays as $holiday) {
            if ($holiday['date'] === $date) {
                // Auto-insert into database for future reference
                try {
                    $stmt = $conn->prepare("
                        INSERT IGNORE INTO public_holidays 
                        (company_id, holiday_date, holiday_name, holiday_type, description) 
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $companyId,
                        $holiday['date'],
                        $holiday['name'],
                        $holiday['type'],
                        $holiday['description']
                    ]);
                } catch (Exception $e) {
                    // Ignore insertion errors
                }
                
                return [
                    'holiday_date' => $holiday['date'],
                    'holiday_name' => $holiday['name'],
                    'holiday_type' => $holiday['type'],
                    'description' => $holiday['description']
                ];
            }
        }
        
        return false;
    }
    
    /**
     * Auto-populate holidays for a company and year
     */
    public static function populateHolidaysForYear($companyId, $year, $conn) {
        $holidays = self::getHolidaysForYear($year);
        $inserted = 0;
        
        foreach ($holidays as $holiday) {
            try {
                $stmt = $conn->prepare("
                    INSERT IGNORE INTO public_holidays 
                    (company_id, holiday_date, holiday_name, holiday_type, description) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                
                $result = $stmt->execute([
                    $companyId,
                    $holiday['date'],
                    $holiday['name'],
                    $holiday['type'],
                    $holiday['description']
                ]);
                
                // For INSERT IGNORE, check if execution was successful
                if ($result) {
                    $inserted++;
                }
            } catch (Exception $e) {
                // Continue with next holiday
                continue;
            }
        }
        
        return $inserted;
    }
}
?>