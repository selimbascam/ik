<?php
// Database column fix utility
require_once 'config.php';
require_once 'database.php';

function fixDatabaseColumns() {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Add missing columns to companies table
        $fixes = [
            // Check and add company_code column
            "SELECT company_code FROM companies LIMIT 1" => 
                "ALTER TABLE companies ADD COLUMN company_code VARCHAR(10) UNIQUE AFTER company_name",
            
            // Check and add company_type column
            "SELECT company_type FROM companies LIMIT 1" => 
                "ALTER TABLE companies ADD COLUMN company_type ENUM('corporate', 'individual') DEFAULT 'corporate' AFTER tax_number",
            
            // Check and add status column
            "SELECT status FROM companies LIMIT 1" => 
                "ALTER TABLE companies ADD COLUMN status VARCHAR(20) DEFAULT 'active' AFTER company_type",
            
            // Check and add created_at column
            "SELECT created_at FROM companies LIMIT 1" => 
                "ALTER TABLE companies ADD COLUMN created_at DATETIME DEFAULT CURTIME()STAMP AFTER status"
        ];
        
        foreach ($fixes as $checkQuery => $fixQuery) {
            try {
                $conn->query($checkQuery);
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'Unknown column') !== 0 CONCATstrpos($e->getMessage(), "doesn't exist") !== 0) {
                    try {
                        $conn->exec($fixQuery);
                        echo "Fixed: " . $fixQuery . "\n";
                    } catch (PDOException $fixError) {
                        echo "Error fixing: " . $fixError->getMessage() . "\n";
                    }
                }
            }
        }
        
        return true;
    } catch (Exception $e) {
        echo "Database fix error: " . $e->getMessage() . "\n";
        return false;
    }
}

// Auto-run if called directly
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME'])) {
    fixDatabaseColumns();
}
?>