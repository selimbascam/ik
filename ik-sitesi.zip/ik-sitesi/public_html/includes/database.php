<?php
/**
 * Simple Hostinger Database Connection
 * Prioritizes MySQLi for maximum compatibility
 */
class Database {
    private $connection;
    private $host = 'localhost';
    private $database = 'u978874874_ik';
    private $username = 'u978874874_ik';
    private $password = 'Szb2013@+-!';
    
    public function __construct() {
        $this->connect();
    }
    
    private function connect() {
        // Try MySQLi first (most common on shared hosting)
        if (extension_loaded('mysqli')) {
            $this->connection = new mysqli($this->host, $this->username, $this->password, $this->database);
            if ($this->connection->connect_error) {
                throw new Exception("Database connection failed: " . $this->connection->connect_error);
            }
            $this->connection->set_charset("utf8mb4");
            return;
        }
        
        // Try PDO MySQL as fallback
        if (extension_loaded('pdo') && extension_loaded('pdo_mysql')) {
            try {
                $dsn = "mysql:host={$this->host};dbname={$this->database};charset=utf8mb4";
                $pdo = new PDO($dsn, $this->username, $this->password, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]);
                $this->connection = new PDOWrapper($pdo);
                return;
            } catch (PDOException $e) {
                throw new Exception("PDO connection failed: " . $e->getMessage());
            }
        }
        
        throw new Exception("No MySQL drivers available. Please enable MySQLi or PDO MySQL extension.");
    }
    
    public function getConnection() {
        if ($this->connection instanceof mysqli) {
            return new MySQLiWrapper($this->connection);
        }
        return $this->connection;
    }
}

/**
 * MySQLi Wrapper to provide PDO-like interface
 */
class MySQLiWrapper {
    private $mysqli;
    
    public function __construct($mysqli) {
        $this->mysqli = $mysqli;
    }
    
    public function query($sql) {
        $result = $this->mysqli->query($sql);
        if ($result === false) {
            throw new Exception("Query failed: " . $this->mysqli->error);
        }
        return new MySQLiResult($result);
    }
    
    public function prepare($sql) {
        $stmt = $this->mysqli->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Prepare failed: " . $this->mysqli->error);
        }
        return new MySQLiStatement($stmt);
    }
    
    public function exec($sql) {
        return $this->mysqli->query($sql);
    }
    
    public function lastInsertId() {
        return $this->mysqli->insert_id;
    }
    
    public function beginTransaction() {
        return $this->mysqli->begin_transaction();
    }
    
    public function commit() {
        return $this->mysqli->commit();
    }
    
    public function rollback() {
        return $this->mysqli->rollback();
    }
    
    public function inTransaction() {
        // MySQLi doesn't have a direct inTransaction method
        // We'll check if autocommit is currently disabled
        // Note: When in transaction, autocommit is disabled
        $result = $this->mysqli->query("SELECT @@autocommit");
        $row = $result->fetch_row();
        return $row[0] == 0; // autocommit = 0 means in transaction
    }
}

/**
 * MySQLi Result Wrapper
 */
class MySQLiResult {
    private $result;
    
    public function __construct($result) {
        $this->result = $result;
    }
    
    public function fetchAll($mode = null) {
        $rows = [];
        if ($mode === 7) { // PDO::FETCH_COLUMN equivalent
            while ($row = $this->result->fetch_row()) {
                $rows[] = $row[0];
            }
        } else {
            while ($row = $this->result->fetch_assoc()) {
                $rows[] = $row;
            }
        }
        return $rows;
    }
    
    public function fetch($mode = null) {
        return $this->result->fetch_assoc();
    }
    
    public function fetchColumn($column = 0) {
        $row = $this->result->fetch_row();
        return $row ? $row[$column] : false;
    }
    
    public function rowCount() {
        return $this->result->num_rows;
    }
}

/**
 * MySQLi Statement Wrapper
 */
class MySQLiStatement {
    private $stmt;
    
    public function __construct($stmt) {
        $this->stmt = $stmt;
    }
    
    public function execute($params = []) {
        if (!empty($params)) {
            $types = str_repeat('s', count($params));
            $this->stmt->bind_param($types, ...$params);
        }
        
        $result = $this->stmt->execute();
        if ($result === false) {
            throw new Exception("Execute failed: " . $this->stmt->error);
        }
        return $result;
    }
    
    public function fetch($mode = null) {
        $result = $this->stmt->get_result();
        return $result ? $result->fetch_assoc() : false;
    }
    
    public function fetch_assoc() {
        $result = $this->stmt->get_result();
        return $result ? $result->fetch_assoc() : false;
    }
    
    public function fetchAll($mode = null) {
        $result = $this->stmt->get_result();
        $rows = [];
        if ($result) {
            if ($mode === 7) { // PDO::FETCH_COLUMN equivalent
                while ($row = $result->fetch_row()) {
                    $rows[] = $row[0];
                }
            } else {
                while ($row = $result->fetch_assoc()) {
                    $rows[] = $row;
                }
            }
        }
        return $rows;
    }
    
    public function fetchColumn($column = 0) {
        $result = $this->stmt->get_result();
        if ($result) {
            $row = $result->fetch_row();
            return $row ? $row[$column] : false;
        }
        return false;
    }
    
    public function rowCount() {
        // For INSERT/UPDATE/DELETE operations, use affected_rows
        // For SELECT operations, get result and check num_rows
        if ($this->stmt->affected_rows !== -1) {
            return $this->stmt->affected_rows;
        }
        
        $result = $this->stmt->get_result();
        return $result ? $result->num_rows : 0;
    }
}

/**
 * PDO Wrapper for consistency
 */
class PDOWrapper {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function query($sql) {
        return $this->pdo->query($sql);
    }
    
    public function prepare($sql) {
        return $this->pdo->prepare($sql);
    }
    
    public function exec($sql) {
        return $this->pdo->exec($sql);
    }
    
    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }
    
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }
    
    public function commit() {
        return $this->pdo->commit();
    }
    
    public function rollback() {
        return $this->pdo->rollback();
    }
    
    public function inTransaction() {
        return $this->pdo->inTransaction();
    }
}

// Define PDO constants for compatibility
if (!defined('PDO::FETCH_ASSOC')) {
    define('PDO::FETCH_ASSOC', 2);
}
if (!defined('PDO::FETCH_COLUMN')) {
    define('PDO::FETCH_COLUMN', 7);
}

?>