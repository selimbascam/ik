<?php
/**
 * SZB İK Takip - Helper Functions
 * Merkezi yardımcı fonksiyonlar ve tekrar eden kodların birleştirilmesi
 * Dördüncü Deeposeek analizi önerisi uygulanarak oluşturuldu
 */

/**
 * Format work time from minutes to HH:MM format
 */
function formatWorkTime($minutes) {
    if (!is_numeric($minutes) || $minutes < 0) {
        return '00:00';
    }
    
    $hours = floor($minutes / 60);
    $remainingMinutes = $minutes % 60;
    return sprintf('%02d:%02d', $hours, $remainingMinutes);
}

/**
 * Format minutes to readable time format
 */
function formatMinutes($minutes) {
    if (!is_numeric($minutes) || $minutes < 0) {
        return '0 dakika';
    }
    
    $hours = floor($minutes / 60);
    $remainingMinutes = $minutes % 60;
    
    if ($hours > 0) {
        if ($remainingMinutes > 0) {
            return $hours . ' saat ' . $remainingMinutes . ' dakika';
        } else {
            return $hours . ' saat';
        }
    } else {
        return $minutes . ' dakika';
    }
}

/**
 * Convert time string to minutes
 */
function timeToMinutes($time) {
    if (empty($time)) return 0;
    
    $parts = explode(':', $time);
    if (count($parts) >= 2) {
        return intval($parts[0]) * 60 + intval($parts[1]);
    }
    
    return 0;
}

/**
 * Calculate time difference in minutes
 */
function calculateTimeDifference($startTime, $endTime) {
    if (empty($startTime) || empty($endTime)) {
        return 0;
    }
    
    $start = new DateTime($startTime);
    $end = new DateTime($endTime);
    
    if ($end < $start) {
        return 0; // Invalid time range
    }
    
    $interval = $start->diff($end);
    return ($interval->h * 60) + $interval->i;
}

/**
 * Turkish day names array
 */
function getTurkishDayNames() {
    return [
        'Monday' => 'Pazartesi',
        'Tuesday' => 'Salı', 
        'Wednesday' => 'Çarşamba',
        'Thursday' => 'Perşembe',
        'Friday' => 'Cuma',
        'Saturday' => 'Cumartesi',
        'Sunday' => 'Pazar'
    ];
}

/**
 * Turkish month names array
 */
function getTurkishMonthNames() {
    return [
        1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
        5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
        9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık'
    ];
}

/**
 * Format Turkish date
 */
function formatTurkishDate($date, $includeDay = false) {
    if (empty($date)) return '';
    
    $timestamp = is_string($date) ? strtotime($date) : $date;
    if (!$timestamp) return '';
    
    $day = date('j', $timestamp);
    $month = getTurkishMonthNames()[intval(date('n', $timestamp))];
    $year = date('Y', $timestamp);
    
    $formatted = "$day $month $year";
    
    if ($includeDay) {
        $englishDay = date('l', $timestamp);
        $turkishDay = getTurkishDayNames()[$englishDay] ?? $englishDay;
        $formatted = "$turkishDay, $formatted";
    }
    
    return $formatted;
}

/**
 * Activity type configurations for consistency
 */
function getActivityTypeConfig() {
    return [
        'work_start' => [
            'icon' => '🟢',
            'text' => 'İşe Başladı',
            'color_class' => 'bg-green-100 text-green-800',
            'description' => 'Çalışmaya başlama kaydı'
        ],
        'work_end' => [
            'icon' => '🔴',
            'text' => 'İşten Çıktı',
            'color_class' => 'bg-red-100 text-red-800',
            'description' => 'Çalışmayı bitirme kaydı'
        ],
        'break_start' => [
            'icon' => '🟡',
            'text' => 'Mola Başladı',
            'color_class' => 'bg-yellow-100 text-yellow-800',
            'description' => 'Mola başlangıç kaydı'
        ],
        'break_end' => [
            'icon' => '🟢',
            'text' => 'Moladan Döndü',
            'color_class' => 'bg-green-100 text-green-800',
            'description' => 'Mola bitiş kaydı'
        ]
    ];
}

/**
 * Get activity type display info
 */
function getActivityTypeInfo($activityType) {
    $config = getActivityTypeConfig();
    return $config[$activityType] ?? [
        'icon' => '⚪',
        'text' => ucfirst(str_replace('_', ' ', $activityType)),
        'color_class' => 'bg-gray-100 text-gray-800',
        'description' => 'Bilinmeyen aktivite'
    ];
}

/**
 * Calculate work status based on last activity
 */
function calculateWorkStatus($lastActivity) {
    if (!$lastActivity) {
        return [
            'status' => 'İşe Başlamamış',
            'color' => 'bg-gray-100 text-gray-700',
            'icon' => '⚪',
            'time' => null
        ];
    }
    
    $activityInfo = getActivityTypeInfo($lastActivity['activity_type']);
    $timeOnly = date('H:i', strtotime($lastActivity['check_in_time']));
    
    $statusMap = [
        'work_start' => [
            'status' => "Çalışıyor (Giriş: $timeOnly)",
            'color' => 'bg-green-100 text-green-700',
            'icon' => '🟢'
        ],
        'work_end' => [
            'status' => "İş Bitirdi (Çıkış: $timeOnly)",
            'color' => 'bg-blue-100 text-blue-700',
            'icon' => '🔵'
        ],
        'break_start' => [
            'status' => "Molada (Başlama: $timeOnly)",
            'color' => 'bg-yellow-100 text-yellow-700',
            'icon' => '🟡'
        ],
        'break_end' => [
            'status' => "Moladan Döndü ($timeOnly)",
            'color' => 'bg-green-100 text-green-700',
            'icon' => '🟢'
        ]
    ];
    
    $result = $statusMap[$lastActivity['activity_type']] ?? [
        'status' => 'Bilinmeyen Durum',
        'color' => 'bg-gray-100 text-gray-700',
        'icon' => '❓'
    ];
    
    $result['time'] = $timeOnly;
    return $result;
}

/**
 * Generate attendance summary for display
 */
function generateAttendanceSummary($records) {
    $summary = [
        'total_records' => count($records),
        'work_starts' => 0,
        'work_ends' => 0,
        'breaks' => 0,
        'first_checkin' => null,
        'last_checkout' => null,
        'total_work_minutes' => 0
    ];
    
    foreach ($records as $record) {
        switch ($record['activity_type']) {
            case 'work_start':
                $summary['work_starts']++;
                if (!$summary['first_checkin']) {
                    $summary['first_checkin'] = $record['check_in_time'];
                }
                break;
            case 'work_end':
                $summary['work_ends']++;
                $summary['last_checkout'] = $record['check_in_time'];
                break;
            case 'break_start':
            case 'break_end':
                $summary['breaks']++;
                break;
        }
    }
    
    return $summary;
}

/**
 * Validate and sanitize employee number
 */
function sanitizeEmployeeNumber($employeeNumber) {
    // Remove non-numeric characters
    $clean = preg_replace('/[^0-9]/', '', $employeeNumber);
    
    // Ensure minimum length
    if (strlen($clean) < 5) {
        return null;
    }
    
    return $clean;
}

/**
 * Format Turkish phone number
 */
function formatTurkishPhone($phone) {
    if (empty($phone)) return '';
    
    // Remove non-numeric characters
    $clean = preg_replace('/[^0-9]/', '', $phone);
    
    // Handle different Turkish phone formats
    if (strlen($clean) === 11 && substr($clean, 0, 1) === '0') {
        // 0532 123 4567 format
        return substr($clean, 0, 4) . ' ' . substr($clean, 4, 3) . ' ' . substr($clean, 7);
    } elseif (strlen($clean) === 10) {
        // 532 123 4567 format  
        return '0' . substr($clean, 0, 3) . ' ' . substr($clean, 3, 3) . ' ' . substr($clean, 6);
    }
    
    return $phone; // Return original if can't format
}

/**
 * Generate QR code data for location
 */
function generateQRData($locationId, $locationName, $companyId) {
    $data = [
        'location_id' => intval($locationId),
        'location_name' => $locationName,
        'company_id' => intval($companyId),
        'timestamp' => time(),
        'version' => '2.0'
    ];
    
    return base64_encode(json_encode($data));
}

/**
 * Parse QR code data
 */
function parseQRData($qrData) {
    try {
        $decoded = base64_decode($qrData);
        $data = json_decode($decoded, true);
        
        if (!$data || !isset($data['location_id'], $data['company_id'])) {
            return null;
        }
        
        return $data;
    } catch (Exception $e) {
        error_log("QR Parse Error: " . $e->getMessage());
        return null;
    }
}

/**
 * Calculate distance between two GPS coordinates
 */
function calculateDistance($lat1, $lon1, $lat2, $lon2) {
    if (empty($lat1) || empty($lon1) || empty($lat2) || empty($lon2)) {
        return null;
    }
    
    $earthRadius = 6371000; // meters
    
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    
    $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) * sin($dLon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    
    return $earthRadius * $c;
}

/**
 * Check if location is within allowed range
 */
function isLocationValid($userLat, $userLon, $allowedLat, $allowedLon, $radiusMeters = 100) {
    $distance = calculateDistance($userLat, $userLon, $allowedLat, $allowedLon);
    
    if ($distance === null) {
        return false;
    }
    
    return $distance <= $radiusMeters;
}

/**
 * Generate progress bar HTML
 */
function generateProgressBar($current, $target, $label = '', $showPercentage = true) {
    $percentage = $target > 0 ? min(100, ($current / $target) * 100) : 0;
    $colorClass = $percentage >= 100 ? 'bg-green-500' : ($percentage >= 75 ? 'bg-blue-500' : 'bg-yellow-500');
    
    $html = '<div class="w-full bg-gray-200 rounded-full h-4 mb-2">';
    $html .= '<div class="' . $colorClass . ' h-4 rounded-full transition-all duration-300" style="width: ' . $percentage . '%"></div>';
    $html .= '</div>';
    
    if ($label || $showPercentage) {
        $html .= '<div class="flex justify-between text-sm text-gray-600">';
        if ($label) {
            $html .= '<span>' . safe_html($label) . '</span>';
        }
        if ($showPercentage) {
            $html .= '<span>' . number_format($percentage, 1) . '%</span>';
        }
        $html .= '</div>';
    }
    
    return $html;
}

/**
 * Get system statistics for dashboards
 */
function getSystemStats($conn) {
    try {
        $stats = [];
        
        // Total active employees
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employees WHERE is_active = 1");
        $stats['total_employees'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Today's attendance records
        $stmt = $conn->query("SELECT COUNT(*) as count FROM attendance_records WHERE date = CURDATE()");
        $stats['today_records'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Active companies
        $stmt = $conn->query("SELECT COUNT(*) as count FROM companies WHERE is_active = 1");
        $stats['total_companies'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        // Active QR locations
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations WHERE is_active = 1");
        $stats['qr_locations'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        return $stats;
    } catch (Exception $e) {
        error_log("System stats error: " . $e->getMessage());
        return [
            'total_employees' => 0,
            'today_records' => 0,
            'total_companies' => 0,
            'qr_locations' => 0
        ];
    }
}

/**
 * Generate notification message HTML
 */
function generateNotification($message, $type = 'info', $dismissible = true) {
    $typeClasses = [
        'success' => 'bg-green-100 border-green-500 text-green-700',
        'error' => 'bg-red-100 border-red-500 text-red-700',
        'warning' => 'bg-yellow-100 border-yellow-500 text-yellow-700',
        'info' => 'bg-blue-100 border-blue-500 text-blue-700'
    ];
    
    $typeIcons = [
        'success' => '✅',
        'error' => '❌', 
        'warning' => '⚠️',
        'info' => 'ℹ️'
    ];
    
    $classes = $typeClasses[$type] ?? $typeClasses['info'];
    $icon = $typeIcons[$type] ?? $typeIcons['info'];
    
    $html = '<div class="border-l-4 p-4 ' . $classes . '">';
    $html .= '<div class="flex">';
    $html .= '<div class="flex-shrink-0"><span class="text-lg">' . $icon . '</span></div>';
    $html .= '<div class="ml-3"><p class="text-sm">' . safe_html($message) . '</p></div>';
    
    if ($dismissible) {
        $html .= '<div class="ml-auto pl-3"><button onclick="this.parentElement.parentElement.parentElement.remove()" class="text-lg hover:opacity-75">&times;</button></div>';
    }
    
    $html .= '</div></div>';
    
    return $html;
}

/**
 * Check if current time is within business hours
 */
function isWithinBusinessHours($startTime = '08:00', $endTime = '18:00') {
    $current = date('H:i');
    return $current >= $startTime && $current <= $endTime;
}

/**
 * Get Turkish business day holidays for current year
 */
function getTurkishHolidays($year = null) {
    $year = $year ?? date('Y');
    
    // Fixed holidays
    $holidays = [
        "$year-01-01" => "Yılbaşı",
        "$year-04-23" => "Ulusal Egemenlik ve Çocuk Bayramı",
        "$year-05-01" => "İşçi Bayramı",
        "$year-05-19" => "Atatürk'ü Anma, Gençlik ve Spor Bayramı",
        "$year-08-30" => "Zafer Bayramı",
        "$year-10-29" => "Cumhuriyet Bayramı"
    ];
    
    // Note: Religious holidays would need dynamic calculation
    // This is a simplified version
    
    return $holidays;
}
?>