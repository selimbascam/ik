<?php
/**
 * QR Attendance System - Fixed Version
 * Handles all QR code attendance operations with proper column mapping
 */

class QRAttendanceHelper {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Get flexible column mapping for attendance_records table
     */
    public static function getColumnMapping($conn) {
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        return [
            'check_in' => in_array('check_in', $columns) ? 'check_in' : 
                         (in_array('check_in_time', $columns) ? 'check_in_time' : 
                         (in_array('clock_in', $columns) ? 'clock_in' : 'check_in_time')),
                         
            'check_out' => in_array('check_out', $columns) ? 'check_out' : 
                          (in_array('check_out_time', $columns) ? 'check_out_time' : 
                          (in_array('clock_out', $columns) ? 'clock_out' : 'check_out_time')),
                          
            'break_start' => in_array('break_start', $columns) ? 'break_start' : 
                            (in_array('break_start_time', $columns) ? 'break_start_time' : 'break_start_time'),
                            
            'break_end' => in_array('break_end', $columns) ? 'break_end' : 
                          (in_array('break_end_time', $columns) ? 'break_end_time' : 'break_end_time'),
                          
            'date' => in_array('date', $columns) ? 'date' : 
                     (in_array('check_date', $columns) ? 'check_date' : 
                     (in_array('attendance_date', $columns) ? 'attendance_date' : 
                     (in_array('work_date', $columns) ? 'work_date' : 'created_at')))
        ];
    }
    
    /**
     * Main gate action determination method
     */
    public static function determineGateAction($conn, $employeeId, $companyId, $locationId, $gateBehavior, $date = null) {
        if ($date === null) {
            $date = date('Y-m-d');
        }
        
        $colMap = self::getColumnMapping($conn);
        
        try {
            // Check if date column exists and handle properly
            $dateCondition = '';
            $params = [$employeeId];
            
            if ($colMap['date'] === 'created_at') {
                // Use DATE() function for datetime columns
                $dateCondition = "DATE(created_at) = ?";
                $params[] = $date;
            } else {
                $dateCondition = "{$colMap['date']} = ?";
                $params[] = $date;
            }
            
            // Get current attendance record
            $stmt = $conn->prepare("
                SELECT 
                    {$colMap['check_in']} as check_in,
                    {$colMap['check_out']} as check_out,
                    {$colMap['break_start']} as break_start,
                    {$colMap['break_end']} as break_end
                FROM attendance_records 
                WHERE employee_id = ? AND $dateCondition
                ORDER BY id DESC
                LIMIT 1
            ");
            $stmt->execute($params);
            $record = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Determine action based on gate behavior and current state
            switch ($gateBehavior) {
                case 'work_start':
                    return 'work_start';
                    
                case 'work_end':
                    return 'work_end';
                    
                case 'break_toggle':
                    if (!$record) {
                        return 'break_start'; // No record, start break
                    }
                    
                    if ($record['break_start'] && !$record['break_end']) {
                        return 'break_end'; // Currently on break, end it
                    } else {
                        return 'break_start'; // Not on break, start one
                    }
                    
                case 'user_choice':
                    if (!$record) {
                        return 'work_start'; // No record today, start work
                    }
                    
                    if ($record['check_in'] && !$record['check_out']) {
                        return 'work_end'; // Checked in but not out, end work
                    } else {
                        return 'work_start'; // Not currently working, start work
                    }
                    
                default:
                    return 'work_start'; // Default fallback
            }
            
        } catch (Exception $e) {
            error_log("Gate action determination error: " . $e->getMessage());
            return 'work_start'; // Safe fallback
        }
    }
    
    /**
     * Process QR attendance - Main method
     */
    public function processQRAttendance($qr_data, $employee_id, $company_id) {
        try {
            // Step 1: Find QR location
            $location_stmt = $this->pdo->prepare("
                SELECT id, location_name, gate_behavior, latitude, longitude, location_tolerance
                FROM qr_locations 
                WHERE qr_code_data = ? AND company_id = ? AND is_active = 1
            ");
            $location_stmt->execute([$qr_data, $company_id]);
            $qr_location = $location_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$qr_location) {
                return [
                    'success' => false,
                    'message' => 'QR kod geçersiz veya lokasyon bulunamadı.',
                    'debug' => ['qr_data' => $qr_data, 'company_id' => $company_id]
                ];
            }
            
            // Step 2: Determine gate action based on behavior
            $gate_action = self::determineGateAction(
                $this->pdo, 
                $employee_id, 
                $company_id, 
                $qr_location['id'], 
                $qr_location['gate_behavior']
            );
            
            // Step 3: Find activity ID
            $activity_stmt = $this->pdo->prepare("
                SELECT id, activity_name 
                FROM attendance_activities 
                WHERE activity_name = ?
            ");
            $activity_stmt->execute([$gate_action]);
            $activity = $activity_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$activity) {
                return [
                    'success' => false,
                    'message' => "Aktivite bulunamadı: $gate_action",
                    'debug' => ['gate_action' => $gate_action, 'gate_behavior' => $qr_location['gate_behavior']]
                ];
            }
            
            // Step 4: Create attendance record
            $insert_stmt = $this->pdo->prepare("
                INSERT INTO attendance_records 
                (employee_id, qr_location_id, activity_id, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            
            $insert_result = $insert_stmt->execute([
                $employee_id,
                $qr_location['id'],
                $activity['id']
            ]);
            
            if ($insert_result) {
                return [
                    'success' => true,
                    'message' => "Başarılı: {$activity['activity_name']} kaydı oluşturuldu.",
                    'activity_details' => [
                        'activity' => $activity['activity_name'],
                        'location' => $qr_location['location_name'],
                        'time' => date('H:i:s'),
                        'gate_behavior' => $qr_location['gate_behavior']
                    ]
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Veritabanı kayıt hatası.',
                    'debug' => ['sql_error' => $this->pdo->errorInfo()]
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'İşlem sırasında hata: ' . $e->getMessage(),
                'debug' => ['exception' => $e->getMessage()]
            ];
        }
    }
    
    /**
     * Update attendance record in database
     */
    public static function updateAttendanceRecord($conn, $employeeId, $companyId, $activityType, $locationName, $locationId, $date) {
        try {
            $currentTime = date('H:i:s');
            $currentDateTime = date('Y-m-d H:i:s');
            
            // Insert new attendance record
            $stmt = $conn->prepare("
                INSERT INTO attendance_records (
                    employee_id, qr_location_id, activity_type, 
                    check_in_time, latitude, longitude, 
                    notes, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $employeeId,
                $locationId,
                $activityType,
                $currentTime,
                null, // latitude - could be added later
                null, // longitude - could be added later
                "QR kod ile kayıt: " . $locationName,
                $currentDateTime
            ]);
            
            if ($result) {
                // Also update employee_shifts table if exists
                try {
                    $shiftStmt = $conn->prepare("
                        UPDATE employee_shifts 
                        SET status = ?, check_in_time = COALESCE(check_in_time, ?), updated_at = NOW()
                        WHERE employee_id = ? AND shift_date = ?
                    ");
                    $shiftStmt->execute([
                        $activityType === 'work_in' ? 'checked_in' : 'checked_out',
                        $currentTime,
                        $employeeId,
                        $date
                    ]);
                } catch (Exception $e) {
                    // Employee shifts update is optional
                    error_log("Shift update failed: " . $e->getMessage());
                }
            }
            
            return $result;
            
        } catch (Exception $e) {
            error_log("updateAttendanceRecord error: " . $e->getMessage());
            return false;
        }
    }
}
?>