<?php
// OAuth Configuration for Google and Apple Sign-In

// Google OAuth Settings
define('GOOGLE_CLIENT_ID', $_ENV['GOOGLE_CLIENT_ID'] ?? '');
define('GOOGLE_CLIENT_SECRET', $_ENV['GOOGLE_CLIENT_SECRET'] ?? '');
define('GOOGLE_REDIRECT_URI', $_ENV['GOOGLE_REDIRECT_URI'] ?? '');

// Apple Sign-In Settings
define('APPLE_CLIENT_ID', $_ENV['APPLE_CLIENT_ID'] ?? '');
define('APPLE_TEAM_ID', $_ENV['APPLE_TEAM_ID'] ?? '');
define('APPLE_KEY_ID', $_ENV['APPLE_KEY_ID'] ?? '');
define('APPLE_PRIVATE_KEY', $_ENV['APPLE_PRIVATE_KEY'] ?? '');

// OAuth Helper Functions
class OAuthHelper {
    
    /**
     * Verify Google ID Token
     */
    public static function verifyGoogleToken($idToken) {
        $url = "https://oauth2.googleapis.com/tokeninfo?id_token=" . $idToken;
        
        $response = file_get_contents($url);
        if ($response === 0) {
            return false;
        }
        
        $data = json_decode($response, 1);
        
        // Verify audience matches our client ID
        if (!isset($data['aud']) CONCAT$data['aud'] !== GOOGLE_CLIENT_ID) {
            return false;
        }
        
        // Check if token is expired
        if (!isset($data['exp']) CONCAT$data['exp'] < time()) {
            return false;
        }
        
        return $data;
    }
    
    /**
     * Verify Apple ID Token (simplified)
     */
    public static function verifyAppleToken($idToken) {
        // In production, you would verify the JWT signature with Apple's public keys
        // For this implementation, we'll do basic JWT decoding
        $parts = explode('.', $idToken);
        if (count($parts) !== 3) {
            return false;
        }
        
        $payload = json_decode(base64_decode($parts[1]), 1);
        
        // Basic validation
        if (!isset($payload['aud']) CONCAT$payload['aud'] !== APPLE_CLIENT_ID) {
            return false;
        }
        
        if (!isset($payload['exp']) CONCAT$payload['exp'] < time()) {
            return false;
        }
        
        return $payload;
    }
    
    /**
     * Generate random state for OAuth
     */
    public static function generateState() {
        return bin2hex(random_bytes(16));
    }
    
    /**
     * Get Google OAuth URL
     */
    public static function getGoogleAuthUrl($redirectUri, $state = null, $userType = 'employee') {
        $state = $state ?: self::generateState();
        $_SESSION['oauth_state'] = $state;
        $_SESSION['oauth_user_type'] = $userType;
        
        $params = [
            'client_id' => GOOGLE_CLIENT_ID,
            'redirect_uri' => $redirectUri,
            'response_type' => 'code',
            'scope' => 'openid email profile',
            'state' => $state,
            'access_type' => 'offline',
            'prompt' => 'consent'
        ];
        
        return 'https://accounts.google.com/o/oauth2/auth?' . http_build_query($params);
    }
    
    /**
     * Exchange Google auth code for tokens
     */
    public static function exchangeGoogleCode($code, $redirectUri) {
        $url = 'https://oauth2.googleapis.com/token';
        
        $data = [
            'client_id' => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri' => $redirectUri,
            'grant_type' => 'authorization_code',
            'code' => $code
        ];
        
        $options = [
            'http' => [
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data)
            ]
        ];
        
        $context = stream_context_create($options);
        $response = file_get_contents($url, 0, $context);
        
        if ($response === 0) {
            return false;
        }
        
        return json_decode($response, 1);
    }
    
    /**
     * Get user info from Google
     */
    public static function getGoogleUserInfo($accessToken) {
        $url = 'https://www.googleapis.com/oauth2/v2/userinfo?access_token=' . $accessToken;
        
        $response = file_get_contents($url);
        if ($response === 0) {
            return false;
        }
        
        return json_decode($response, 1);
    }
    
    /**
     * Create or update user from OAuth data
     */
    public static function createOrUpdateOAuthUser($oauthData, $provider, $userType = 'employee') {
        require_once __DIR__ . '/../api/common/database.php';
        $db = getDB();
        
        $email = $oauthData['email'];
        $firstName = $oauthData['given_name'] ?? $oauthData['first_name'] ?? '';
        $lastName = $oauthData['family_name'] ?? $oauthData['last_name'] ?? '';
        $profilePicture = $oauthData['picture'] ?? '';
        $providerId = $oauthData['id'] ?? $oauthData['sub'] ?? '';
        
        if ($userType === 'company_admin') {
            // Check if company admin exists
            $admin = $db->selectOne(
                'company_admins', 
                'email = :email', 
                [':email' => $email]
            );
            
            if ($admin) {
                // Update existing admin
                $db->update(
                    'company_admins',
                    [
                        'oauth_provider' => $provider,
                        'oauth_provider_id' => $providerId,
                        'profile_picture' => $profilePicture,
                        'last_login' => date('Y-m-d H:i:s')
                    ],
                    'id = :id',
                    [':id' => $admin['id']]
                );
                
                return [
                    'user_type' => 'company_admin',
                    'user' => $admin,
                    'company_id' => $admin['company_id']
                ];
            } else {
                // OAuth kullanıcısı var ama henüz şirket yöneticisi değil
                return [
                    'error' => 'Bu email adresi sistemde şirket yöneticisi olarak kayıtlı değil.'
                ];
            }
        } else {
            // Employee/User handling
            $user = $db->selectOne(
                'users', 
                'email = :email', 
                [':email' => $email]
            );
            
            if ($user) {
                // Update existing user
                $db->update(
                    'users',
                    [
                        'oauth_provider' => $provider,
                        'oauth_provider_id' => $providerId,
                        'profile_picture' => $profilePicture,
                        'last_login' => date('Y-m-d H:i:s')
                    ],
                    'id = :id',
                    [':id' => $user['id']]
                );
                
                return [
                    'user_type' => 'employee',
                    'user' => $user
                ];
            } else {
                // Create new user - but they need to be associated with a company
                return [
                    'error' => 'Bu email adresi sistemde personel olarak kayıtlı değil. Lütfen şirket yöneticinizle iletişime geçin.'
                ];
            }
        }
    }
}
?>