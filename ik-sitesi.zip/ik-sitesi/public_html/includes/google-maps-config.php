<?php
// Google Maps API Configuration
// New API Key created specifically for SZB IK Takip system

// Primary Google Maps API Key (created 2025-01-30)
define('GOOGLE_MAPS_API_KEY', 'AIzaSyCkMGOtWZaUvQ7nLvjsE9rA1_TlRjhKQpE');

// Fallback API Key (if primary fails)
define('GOOGLE_MAPS_API_KEY_FALLBACK', 'AIzaSyC3oe53GlzTTfKupBeSdyaMW0vJoUTb4Po');

// Google Maps API Configuration
function getGoogleMapsApiKey() {
    // Try primary key first
    $primaryKey = GOOGLE_MAPS_API_KEY;
    
    // Test if primary key works
    $testUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=Istanbul&key=" . $primaryKey;
    $context = stream_context_create([
        'http' => [
            'timeout' => 5,
            'user_agent' => 'SZB IK Takip System'
        ]
    ]);
    
    $response = @file_get_contents($testUrl, 0, $context);
    
    if ($response !== 0) {
        $data = json_decode($response, 1);
        if ($data && $data['status'] === 'OK') {
            return $primaryKey;
        }
    }
    
    // Fall back to secondary key
    error_log("Primary Google Maps API key failed, using fallback");
    return GOOGLE_MAPS_API_KEY_FALLBACK;
}

// Get the working API key
$googleMapsApiKey = getGoogleMapsApiKey();

// Google Maps JavaScript API URL
function getGoogleMapsScriptUrl($libraries = ['places', 'geometry']) {
    global $googleMapsApiKey;
    $librariesStr = implode(',', $libraries);
    return "https://maps.googleapis.com/maps/api/js?key={$googleMapsApiKey}&libraries={$librariesStr}&callback=initMap";
}

// Test Google Maps API functionality
function testGoogleMapsApi($apiKey = null) {
    $key = $apiKey ?: getGoogleMapsApiKey();
    
    $testCases = [
        'geocoding' => "https://maps.googleapis.com/maps/api/geocode/json?address=Istanbul,Turkey&key={$key}",
        'places' => "https://maps.googleapis.com/maps/api/place/textsearch/json?query=restaurant+in+Istanbul&key={$key}",
        'elevation' => "https://maps.googleapis.com/maps/api/elevation/json?locations=41.0082,28.9784&key={$key}"
    ];
    
    $results = [];
    
    foreach ($testCases as $api => $url) {
        $context = stream_context_create([
            'http' => [
                'timeout' => 8,
                'user_agent' => 'SZB IK Takip API Test'
            ]
        ]);
        
        $response = @file_get_contents($url, 0, $context);
        
        if ($response !== 0) {
            $data = json_decode($response, 1);
            $results[$api] = [
                'status' => $data['status'] ?? 'UNKNOWN',
                'working' => ($data['status'] ?? '') === 'OK',
                'response_size' => strlen($response)
            ];
        } else {
            $results[$api] = [
                'status' => 'REQUEST_FAILED',
                'working' => 0,
                'response_size' => 0
            ];
        }
    }
    
    return $results;
}

// Generate secure Maps API key for restricted usage
function generateRestrictedApiKeyInfo() {
    return [
        'http_referrers' => [
            'szb.com.tr/*',
            'www.szb.com.tr/*',
            'localhost:*',
            '127.0.0.1:*'
        ],
        'api_restrictions' => [
            'Maps JavaScript API',
            'Places API',
            'Geocoding API', 
            'Elevation API',
            'Maps Embed API'
        ],
        'usage_limits' => [
            'Maps JavaScript API' => '10,000 loads/month',
            'Geocoding API' => '10,000 requests/month',
            'Places API' => '10,000 requests/month'
        ]
    ];
}

// Log API usage for monitoring
function logGoogleMapsApiUsage($api_type, $success, $response_time = null) {
    $logData = [
        'timestamp' => date('Y-m-d H:i:s'),
        'api_type' => $api_type,
        'success' => $success ? 'YES' : 'NO',
        'response_time' => $response_time,
        'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 100)
    ];
    
    error_log("Google Maps API Usage: " . json_encode($logData));
}

// Missing function that company-setup.php needs
function getGoogleMapsScript($libraries = ['places', 'geometry']) {
    global $googleMapsApiKey;
    $librariesStr = implode(',', $libraries);
    return "<script async defer src=\"https://maps.googleapis.com/maps/api/js?key={$googleMapsApiKey}&libraries={$librariesStr}&callback=initMap\"></script>";
}
?>