<?php

class AttendanceHelper {
    
    /**
     * Türkiye İş Hukuku uyumlu mola hesaplaması
     */
    public static function calculateRequiredBreak($workHours) {
        if ($workHours >= 8 && $workHours < 11) {
            return 30; // 30 dakika zorunlu mola
        } elseif ($workHours >= 11) {
            return 60; // 60 dakika zorunlu mola
        }
        return 0; // 8 saatten az çalışmada zorunlu mola yok
    }
    
    /**
     * Maaş hesaplaması için net çalışma saati
     */
    public static function calculatePayableHours($totalMinutes) {
        $totalHours = $totalMinutes / 60;
        $requiredBreakMinutes = self::calculateRequiredBreak($totalHours);
        
        // Zorunlu molayı düş
        $netMinutes = $totalMinutes - $requiredBreakMinutes;
        return round($netMinutes / 60, 2);
    }
    
    /**
     * Fazla mesai hesaplama (günlük 8 saat üstü)
     */
    public static function calculateOvertime($payableHours) {
        if ($payableHours > 8) {
            return round($payableHours - 8, 2);
        }
        return 0;
    }
    
    /**
     * Vardiya bilgisini al - Shift tablosu yoksa basit çalışma saati varsayımı
     */
    public static function getEmployeeShift($conn, $employeeId, $date) {
        try {
            $dayOfWeek = date('w', strtotime($date)); // 0=Sunday, 1=Monday, etc.
            
            // Önce shifts tablosunun var olup olmadığını kontrol et
            $stmt = $conn->prepare("SHOW TABLES LIKE 'shifts'");
            $stmt->execute();
            $shiftsTableExists = $stmt->rowCount() > 0;
            
            if (!$shiftsTableExists) {
                // Shifts tablosu yoksa varsayılan çalışma saati döndür
                return [
                    'start_time' => '09:00:00',
                    'end_time' => '18:00:00',
                    'break_duration' => 60,
                    'day_of_week' => $dayOfWeek
                ];
            }
            
            $stmt = $conn->prepare("
                SELECT s.*, s.start_time, s.end_time, s.break_duration
                FROM shifts s
                JOIN employee_shifts es ON s.id = es.shift_id
                WHERE es.employee_id = ? 
                AND (s.day_of_week = ? OR s.day_of_week IS NULL)
                AND s.is_active = 1
                ORDER BY s.day_of_week DESC
                LIMIT 1
            ");
            $stmt->execute([$employeeId, $dayOfWeek]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            // Hata durumunda varsayılan değer döndür
            error_log("getEmployeeShift error: " . $e->getMessage());
            return [
                'start_time' => '09:00:00',
                'end_time' => '18:00:00', 
                'break_duration' => 60,
                'day_of_week' => date('w', strtotime($date))
            ];
        }
    }
    
    /**
     * Kapı türüne göre eylem belirle - Yeni sistem
     */
    public static function determineActionByGateType($conn, $employeeId, $date, $gateType, $gateBehavior = null) {
        // Kapı davranışını belirle
        if (!$gateBehavior) {
            $behaviorMap = [
                'entrance_gate' => 'work_start',
                'exit_gate' => 'work_end',
                'break_gate' => 'break_toggle',
                'general_gate' => 'user_choice'
            ];
            $gateBehavior = $behaviorMap[$gateType] ?? 'user_choice';
        }
        
        // Mevcut durumu kontrol et - schema uyumlu sütun kontrol
        try {
            // Check which columns exist in attendance_records table
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Map alternative column names - Updated for actual schema
            $checkInCol = in_array('check_in', $columns) ? 'check_in' : 
                         (in_array('check_in_time', $columns) ? 'check_in_time' : 
                         (in_array('clock_in', $columns) ? 'clock_in' : 
                         (in_array('start_time', $columns) ? 'start_time' : 'check_in')));
                         
            $checkOutCol = in_array('check_out', $columns) ? 'check_out' : 
                          (in_array('check_out_time', $columns) ? 'check_out_time' : 
                          (in_array('clock_out', $columns) ? 'clock_out' : 
                          (in_array('end_time', $columns) ? 'end_time' : 'check_out')));
                          
            $breakStartCol = in_array('break_start', $columns) ? 'break_start' : 
                            (in_array('break_start_time', $columns) ? 'break_start_time' : 'break_start');
            $breakEndCol = in_array('break_end', $columns) ? 'break_end' : 
                          (in_array('break_end_time', $columns) ? 'break_end_time' : 'break_end');
            
            // Map date column
            $dateCol = in_array('date', $columns) ? 'date' : 
                      (in_array('check_date', $columns) ? 'check_date' : 'date');
            
            $stmt = $conn->prepare("
                SELECT 
                    $checkInCol as check_in, 
                    $breakStartCol as break_start, 
                    $breakEndCol as break_end, 
                    $checkOutCol as check_out,
                    TIMESTAMPDIFF(MINUTE, $checkInCol, NOW()) as minutes_since_checkin
                FROM attendance_records 
                WHERE employee_id = ? AND $dateCol = ?
            ");
        } catch (Exception $e) {
            // Fallback to basic query if column check fails
            $stmt = $conn->prepare("
                SELECT 
                    NULL as check_in, NULL as break_start, NULL as break_end, NULL as check_out,
                    0 as minutes_since_checkin
                FROM attendance_records 
                WHERE employee_id = ? AND $dateCol = ? LIMIT 1
            ");
        }
        $stmt->execute([$employeeId, $date]);
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
        
        switch ($gateBehavior) {
            case 'work_start':
                // Giriş kapısı - sadece işe başlama
                if (!$record || !$record['check_in']) {
                    return ['action' => 'check_in', 'message' => '🟢 İşe giriş yapıldı'];
                } elseif ($record['check_out']) {
                    // Çıkış yapılmışsa yeni gün başlat - bugünkü kaydı sil ve yeni giriş yap
                    $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
                    $stmt->execute([$employeeId, $date]);
                    return ['action' => 'check_in', 'message' => '🟢 Yeni gün - İşe giriş yapıldı'];
                } else {
                    // Zaten giriş yapılmış ama çıkış yapılmamış - yeni giriş yapılabilir (vardiya değişimi)
                    return ['action' => 'check_in', 'message' => '🟢 Yeni vardiya - İşe giriş yapıldı'];
                }
                
            case 'work_end':
                // Çıkış kapısı - sadece işten çıkış
                if ($record && $record['check_in'] && !$record['check_out']) {
                    return ['action' => 'check_out', 'message' => '🔴 İşten çıkış yapıldı'];
                } elseif ($record && $record['check_out']) {
                    return ['action' => 'error', 'message' => '❌ Bugün zaten çıkış yaptınız! Yeni gün için giriş kapısını kullanın.'];
                } else {
                    return ['action' => 'error', 'message' => '❌ Bu çıkış kapısı! Önce giriş kapısından işe başlamalısınız.'];
                }
                
            case 'break_toggle':
                // Mola kapısı - akıllı mola yönetimi
                if (!$record || !$record['check_in']) {
                    return ['action' => 'error', 'message' => '❌ Mola için önce işe başlamalısınız!'];
                }
                
                if ($record['check_out']) {
                    return ['action' => 'error', 'message' => '❌ İş günü tamamlanmış, mola yapılamaz!'];
                }
                
                if ($record['break_start'] && !$record['break_end']) {
                    return ['action' => 'break_end', 'message' => '🟢 Mola bitirildi'];
                } else {
                    // Mola başlatılacak (ilk mola veya yeni mola)
                    return ['action' => 'break_start', 'message' => '🟡 Mola başlatıldı'];
                }
                
            case 'user_choice':
            default:
                // Genel kapı - kullanıcı seçimi (eski akıllı sistem)
                return self::determineNextAction($conn, $employeeId, $date);
        }
    }

    /**
     * Personelin günlük durumunu belirle (giriş, mola, çıkış) - Eski sistem
     */
    public static function determineNextAction($conn, $employeeId, $date) {
        // Bugünkü son aktiviteyi bul - schema uyumlu
        try {
            // Check column existence for flexible mapping
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $checkInCol = in_array('check_in', $columns) ? 'check_in' : 
                         (in_array('clock_in', $columns) ? 'clock_in' : 
                         (in_array('start_time', $columns) ? 'start_time' : 'check_in'));
                         
            $checkOutCol = in_array('check_out', $columns) ? 'check_out' : 
                          (in_array('clock_out', $columns) ? 'clock_out' : 
                          (in_array('end_time', $columns) ? 'end_time' : 'check_out'));
                          
            $breakStartCol = in_array('break_start', $columns) ? 'break_start' : 'break_start';
            $breakEndCol = in_array('break_end', $columns) ? 'break_end' : 'break_end';
            
            $stmt = $conn->prepare("
                SELECT 
                    $checkInCol as check_in, 
                    $breakStartCol as break_start, 
                    $breakEndCol as break_end, 
                    $checkOutCol as check_out,
                    TIMESTAMPDIFF(MINUTE, $checkInCol, NOW()) as minutes_since_checkin,
                    TIMESTAMPDIFF(MINUTE, $breakEndCol, NOW()) as minutes_since_break_end
                FROM attendance_records 
                WHERE employee_id = ? AND date = ?
            ");
            $stmt->execute([$employeeId, $date]);
            $record = $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            // Fallback for schema issues
            $record = null;
            error_log("determineNextAction: Column mapping failed - " . $e->getMessage());
        }
        
        if (!$record || !$record['check_in']) {
            return ['action' => 'check_in', 'message' => '🟢 İşe giriş yapılacak'];
        }
        
        if (!$record['check_out']) {
            // Çalışma süresini kontrol et
            $workMinutes = $record['minutes_since_checkin'] ?: 0;
            $workHours = $workMinutes / 60;
            
            // Zorunlu mola kontrolü
            $requiredBreakMinutes = self::calculateRequiredBreak($workHours);
            
            if (!$record['break_start'] && $workMinutes >= 360 && $requiredBreakMinutes > 0) {
                return ['action' => 'break_start', 'message' => '🟡 Zorunlu mola zamanı! (6+ saat çalıştınız)'];
            }
            
            if ($record['break_start'] && !$record['break_end']) {
                return ['action' => 'break_end', 'message' => '🟢 Mola bitiriliyor'];
            }
            
            if (!$record['break_start'] && $workMinutes >= 240) { // 4 saat sonra mola seçeneği
                return ['action' => 'break_start', 'message' => '🟡 Mola başlatılacak'];
            }
            
            // Vardiya bitim saatine yakınsa çıkış öner
            $shift = self::getEmployeeShift($conn, $employeeId, $date);
            if ($shift && $workMinutes >= 420) { // 7+ saat çalıştı
                return ['action' => 'check_out', 'message' => '🔴 İşten çıkış yapılacak'];
            }
            
            return ['action' => 'break_start', 'message' => '🟡 Mola başlatılacak'];
        }
        
        // Gün tamamlandı, yeni gün başlasın
        return ['action' => 'check_in', 'message' => '🟢 Yeni gün - İşe giriş yapılacak'];
    }
    
    /**
     * Attendance kaydını güncelle - Sınırsız mola desteği ile
     */
    public static function updateAttendanceRecord($conn, $employeeId, $companyId, $action, $locationName, $qrLocationId) {
        $today = date('Y-m-d');
        $now = date('Y-m-d H:i:s');
        
        // Mevcut kaydı kontrol et - schema uyumlu
        try {
            // Check column existence
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Map column names
            $checkInCol = in_array('check_in', $columns) ? 'check_in' : 
                         (in_array('clock_in', $columns) ? 'clock_in' : 
                         (in_array('start_time', $columns) ? 'start_time' : 'check_in'));
                         
            $checkOutCol = in_array('check_out', $columns) ? 'check_out' : 
                          (in_array('clock_out', $columns) ? 'clock_out' : 
                          (in_array('end_time', $columns) ? 'end_time' : 'check_out'));
                          
            $breakStartCol = in_array('break_start', $columns) ? 'break_start' : 'break_start';
            $breakEndCol = in_array('break_end', $columns) ? 'break_end' : 'break_end';
            
            $stmt = $conn->prepare("
                SELECT id, 
                       $checkInCol as check_in, 
                       $breakStartCol as break_start, 
                       $breakEndCol as break_end, 
                       $checkOutCol as check_out 
                FROM attendance_records 
                WHERE employee_id = ? AND date = ?
            ");
            $stmt->execute([$employeeId, $today]);
            $existingRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            // Fallback for schema issues
            $existingRecord = null;
            error_log("updateAttendanceRecord: Column mapping failed - " . $e->getMessage());
        }
        
        if ($existingRecord) {
            // Mevcut kaydı güncelle
            $updateField = '';
            switch ($action) {
                case 'check_in':
                    // Yeni giriş - önceki kaydı sil ve yeni başlat
                    $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
                    $stmt->execute([$employeeId, $today]);
                    $updateField = null; // Yeni kayıt oluşturulacak
                    break;
                    
                case 'break_start':
                    $updateField = $breakStartCol . ' = ?';
                    break;
                    
                case 'break_end':
                    $updateField = $breakEndCol . ' = ?';
                    break;
                    
                case 'check_out':
                    // Molada ise önce molayı bitir
                    if ($existingRecord['break_start'] && !$existingRecord['break_end']) {
                        $stmt = $conn->prepare("UPDATE attendance_records SET $breakEndCol = ? WHERE id = ?");
                        $stmt->execute([$now, $existingRecord['id']]);
                    }
                    
                    // Çalışma süresi hesapla ve kaydet
                    $workMinutes = self::calculateWorkTime($existingRecord['check_in'], $now, $existingRecord['break_start'], $existingRecord['break_end'] ?? $now);
                    $updateField = $checkOutCol . ' = ?, work_minutes = ?';
                    break;
            }
            
            if ($updateField) {
                if ($action === 'check_out') {
                    $stmt = $conn->prepare("
                        UPDATE attendance_records 
                        SET $updateField, location = ?, qr_location_id = ?, device_user_agent = ?, updated_at = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$now, $workMinutes, $locationName, $qrLocationId, $_SERVER['HTTP_USER_AGENT'] ?? '', $now, $existingRecord['id']]);
                } else {
                    $stmt = $conn->prepare("
                        UPDATE attendance_records 
                        SET $updateField, location = ?, qr_location_id = ?, device_user_agent = ?, updated_at = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([$now, $locationName, $qrLocationId, $_SERVER['HTTP_USER_AGENT'] ?? '', $now, $existingRecord['id']]);
                }
            } elseif ($action === 'check_in') {
                // Yeni giriş kaydı oluştur - flexible column mapping
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (employee_id, company_id, date, $checkInCol, location, qr_location_id, device_user_agent, created_at, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $employeeId, $companyId, $today, $now, $locationName, 
                    $qrLocationId, $_SERVER['HTTP_USER_AGENT'] ?? '', $now, $now
                ]);
            }
        } else {
            // Yeni kayıt oluştur - sadece giriş için - flexible column mapping
            if ($action === 'check_in') {
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (employee_id, company_id, date, $checkInCol, location, qr_location_id, device_user_agent, created_at, updated_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $employeeId, $companyId, $today, $now, $locationName, 
                    $qrLocationId, $_SERVER['HTTP_USER_AGENT'] ?? '', $now, $now
                ]);
            }
        }
        
        return true;
    }
    
    /**
     * Çalışma süresini hesapla (mola süresi dahil değil)
     */
    public static function calculateWorkTime($checkIn, $checkOut, $breakStart = null, $breakEnd = null) {
        if (!$checkIn || !$checkOut) return 0;
        
        $start = new DateTime($checkIn);
        $end = new DateTime($checkOut);
        
        // Toplam süre (dakika)
        $totalMinutes = $start->diff($end)->days * 24 * 60 + $start->diff($end)->h * 60 + $start->diff($end)->i;
        
        // Mola süresi çıkar
        $breakMinutes = 0;
        if ($breakStart && $breakEnd) {
            $breakStartTime = new DateTime($breakStart);
            $breakEndTime = new DateTime($breakEnd);
            $breakMinutes = $breakStartTime->diff($breakEndTime)->days * 24 * 60 + $breakStartTime->diff($breakEndTime)->h * 60 + $breakStartTime->diff($breakEndTime)->i;
        }
        
        return max(0, $totalMinutes - $breakMinutes);
    }
    
    /**
     * Günlük özet hesaplama
     */
    public static function calculateDailySummary($record) {
        if (!$record) {
            return [
                'total_minutes' => 0,
                'break_minutes' => 0,
                'work_minutes' => 0,
                'payable_hours' => 0,
                'overtime_hours' => 0,
                'status' => 'Çalışmıyor'
            ];
        }
        
        // Support multiple column naming conventions
        $checkIn = $record['check_in'] ?? $record['check_in_time'] ?? null;
        $checkOut = $record['check_out'] ?? $record['check_out_time'] ?? null;
        $breakStart = $record['break_start'] ?? $record['break_start_time'] ?? null;
        $breakEnd = $record['break_end'] ?? $record['break_end_time'] ?? null;
        
        if (!$checkIn) {
            return [
                'total_minutes' => 0,
                'break_minutes' => 0,
                'work_minutes' => 0,
                'payable_hours' => 0,
                'overtime_hours' => 0,
                'status' => 'Giriş yapılmadı'
            ];
        }
        
        try {
            $checkInTime = new DateTime($checkIn);
            $checkOutTime = $checkOut ? new DateTime($checkOut) : new DateTime();
            
            // Toplam süre hesaplama
            $interval = $checkInTime->diff($checkOutTime);
            $totalMinutes = ($interval->h * 60) + $interval->i;
            
            // Mola süresi hesaplama
            $breakMinutes = 0;
            if ($breakStart && $breakEnd) {
                $breakStartTime = new DateTime($breakStart);
                $breakEndTime = new DateTime($breakEnd);
                $breakInterval = $breakStartTime->diff($breakEndTime);
                $breakMinutes = ($breakInterval->h * 60) + $breakInterval->i;
            }
            
            // Net çalışma süresi
            $workMinutes = max(0, $totalMinutes - $breakMinutes);
            $payableHours = $workMinutes / 60;
            $overtimeHours = max(0, $payableHours - 8);
            
            // Durum belirleme
            $status = 'Çalışıyor';
            if ($checkOut) {
                $status = 'Çıkış yaptı';
            } elseif ($breakStart && !$breakEnd) {
                $status = 'Molada';
            }
            
            return [
                'total_minutes' => $totalMinutes,
                'break_minutes' => $breakMinutes,
                'work_minutes' => $workMinutes,
                'payable_hours' => round($payableHours, 2),
                'overtime_hours' => round($overtimeHours, 2),
                'status' => $status
            ];
            
        } catch (Exception $e) {
            // Hata durumunda güvenli değerler döndür
            return [
                'total_minutes' => 0,
                'break_minutes' => 0,
                'work_minutes' => 0,
                'payable_hours' => 0,
                'overtime_hours' => 0,
                'status' => 'Hata: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Aylık çalışma özeti (225 saat hedefi)
     */
    public static function calculateMonthlySummary($conn, $employeeId, $month) {
        try {
            $monthStart = $month . '-01';
            $monthEnd = date('Y-m-t', strtotime($monthStart));
            
            // Check which date column exists
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $dateCol = in_array('date', $columns) ? 'date' : 'created_at';
            
            // Use compatible column names for check_in/check_out
            $checkInCol = in_array('check_in', $columns) ? 'check_in' : 'check_in_time';
            $checkOutCol = in_array('check_out', $columns) ? 'check_out' : 'check_out_time';
            
            if ($dateCol === 'created_at') {
                // Use DATE() function for created_at timestamp
                $stmt = $conn->prepare("
                    SELECT 
                        COUNT(DISTINCT DATE(created_at)) as days_worked,
                        SUM(CASE 
                            WHEN activity_type = 'work_out' AND check_in_time IS NOT NULL 
                            THEN TIMESTAMPDIFF(MINUTE, 
                                (SELECT check_in_time FROM attendance_records ar2 
                                 WHERE ar2.employee_id = attendance_records.employee_id 
                                 AND DATE(ar2.created_at) = DATE(attendance_records.created_at) 
                                 AND ar2.activity_type = 'work_in' LIMIT 1), 
                                check_in_time)
                            ELSE 0
                        END) as total_minutes
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) BETWEEN ? AND ?
                ");
            } else {
                $stmt = $conn->prepare("
                    SELECT 
                        COUNT(*) as days_worked,
                        SUM(CASE 
                            WHEN $checkInCol IS NOT NULL AND $checkOutCol IS NOT NULL 
                            THEN TIMESTAMPDIFF(MINUTE, $checkInCol, $checkOutCol)
                            ELSE 0
                        END) as total_minutes
                    FROM attendance_records 
                    WHERE employee_id = ? AND $dateCol BETWEEN ? AND ?
                ");
            }
            
            $stmt->execute([$employeeId, $monthStart, $monthEnd]);
            $summary = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $totalMinutes = $summary['total_minutes'] ?? 0;
            $totalHours = round($totalMinutes / 60, 2);
            $targetHours = 225; // Aylık hedef
            $remainingHours = max(0, $targetHours - $totalHours);
            
            return [
                'days_worked' => $summary['days_worked'] ?? 0,
                'total_hours' => $totalHours,
                'target_hours' => $targetHours,
                'remaining_hours' => $remainingHours,
                'completion_percentage' => round(($totalHours / $targetHours) * 100, 1)
            ];
            
        } catch (Exception $e) {
            // Return safe defaults on error
            return [
                'days_worked' => 0,
                'total_hours' => 0,
                'target_hours' => 225,
                'remaining_hours' => 225,
                'completion_percentage' => 0
            ];
        }
    }
}