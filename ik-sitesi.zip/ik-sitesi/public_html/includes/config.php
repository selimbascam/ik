<?php
// APP_NAME tanımla
define('APP_NAME', 'SZB İK Takip');

// Security layer
require_once __DIR__ . '/security.php';

// Session güvenliği security.php tarafından yapılandırılır

// Timezone configuration
date_default_timezone_set('Europe/Istanbul');

// Error reporting (development mode)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database constants (fallback - not used with new Database class)
define('DB_HOST', 'localhost');
define('DB_NAME', 'u978874874_ik');
define('DB_USER', 'u978874874_ik');
define('DB_PASS', 'Szb2013@+-!');

// Function to check if user is authenticated
function isAuthenticated($userType = null) {
    if (!isset($_SESSION['user_id']) && !isset($_SESSION['employee_id']) && !isset($_SESSION['company_id'])) {
        return false;
    }
    
    if ($userType && isset($_SESSION['user_type'])) {
        return $_SESSION['user_type'] === $userType;
    }
    
    return true;
}

// Function to redirect if not authenticated
function requireAuth($userType = null, $redirectTo = '/login.php') {
    if (!isAuthenticated($userType)) {
        header("Location: $redirectTo");
        exit;
    }
}

// Function to get current user ID
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? $_SESSION['employee_id'] ?? null;
}

// Function to get current user type
function getUserType() {
    return $_SESSION['user_type'] ?? 'unknown';
}

// Function to get current company ID
function getCompanyId() {
    return $_SESSION['company_id'] ?? null;
}

// Function to format Turkish date
function formatTurkishDate($date, $format = 'd/m/Y H:i') {
    if (!$date) return '-';
    
    $timestamp = is_string($date) ? strtotime($date) : $date;
    return date($format, $timestamp);
}

// Function to calculate work duration
function calculateWorkDuration($start, $end) {
    if (!$start || !$end) return '00:00';
    
    $startTime = is_string($start) ? strtotime($start) : $start;
    $endTime = is_string($end) ? strtotime($end) : $end;
    
    $duration = $endTime - $startTime;
    $hours = floor($duration / 3600);
    $minutes = floor(($duration % 3600) / 60);
    
    return sprintf('%02d:%02d', $hours, $minutes);
}

// CORS headers for API endpoints
function setCorsHeaders() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Content-Type: application/json; charset=utf-8');
}

// Function to return JSON response
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    setCorsHeaders();
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Function to handle OPTIONS requests
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    setCorsHeaders();
    exit;
}

// QR Code validation function
function isValidQRCode($code) {
    if (empty($code)) return false;
    
    // Check if it's a JSON string
    if (is_string($code) && (strpos($code, '{') === 0 || strpos($code, '[') === 0)) {
        $decoded = json_decode($code, true);
        return json_last_error() === JSON_ERROR_NONE;
    }
    
    // Check if it's a simple location ID
    return is_numeric($code) && $code > 0;
}
?>