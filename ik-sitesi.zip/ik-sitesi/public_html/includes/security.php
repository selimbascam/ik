<?php
/**
 * Security Helper Functions
 * SZB İK Takip - Güvenlik Katmanı
 * 
 * Bu dosya tüm güvenlik fonksiyonlarını içerir
 */

if (!defined('SECURITY_LOADED')) {
    define('SECURITY_LOADED', true);
}

/**
 * Input sanitization - Giriş verilerini temizleme
 */
function sanitize_input($input, $type = 'string') {
    if ($input === null) return '';
    
    switch ($type) {
        case 'int':
            return (int) $input;
        case 'float':
            return (float) $input;
        case 'email':
            return filter_var($input, FILTER_SANITIZE_EMAIL);
        case 'html':
            return htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        case 'employee_number':
            return preg_replace('/[^0-9A-Za-z]/', '', $input);
        case 'phone':
            return preg_replace('/[^0-9+\-\s\(\)]/', '', $input);
        default:
            return trim(strip_tags($input));
    }
}

/**
 * Safe HTML output - HTML çıktısı için güvenli fonksiyon
 */
function safe_html($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * CSRF Token Generation - CSRF token üretimi
 */
function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF Token Validation - CSRF token doğrulama
 */
function validate_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || !$token) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * CSRF Token HTML Input - CSRF token HTML input field
 */
function csrf_token_input() {
    $token = generate_csrf_token();
    return "<input type='hidden' name='csrf_token' value='" . safe_html($token) . "'>";
}

/**
 * Secure Password Verification - Timing attack korumalı şifre doğrulama
 */
function secure_password_verify($password, $hash) {
    // Prevent timing attacks
    $start = microtime(true);
    $result = password_verify($password, $hash);
    $end = microtime(true);
    
    // Add minimum delay to prevent timing analysis
    $minTime = 0.5; // 500ms minimum
    $elapsed = $end - $start;
    if ($elapsed < $minTime) {
        usleep(($minTime - $elapsed) * 1000000);
    }
    
    return $result;
}

/**
 * Strong Password Hash - Güçlü şifre hash'leme
 */
function create_secure_password_hash($password) {
    // Use Argon2ID for maximum security
    return password_hash($password, PASSWORD_ARGON2ID, [
        'memory_cost' => 65536, // 64 MB
        'time_cost' => 4,       // 4 iterations
        'threads' => 3          // 3 threads
    ]);
}

/**
 * Session Security - Session güvenlik ayarları
 */
function configure_secure_session() {
    if (session_status() === PHP_SESSION_NONE) {
        // Secure session configuration
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
        ini_set('session.cookie_samesite', 'Strict');
        ini_set('session.gc_maxlifetime', 3600); // 1 hour
        ini_set('session.cookie_lifetime', 3600);
        
        // Start session
        session_start();
        
        // Regenerate session ID periodically
        if (!isset($_SESSION['last_regeneration'])) {
            $_SESSION['last_regeneration'] = time();
        } elseif (time() - $_SESSION['last_regeneration'] > 300) { // 5 minutes
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
}

/**
 * IP Address Validation - IP adresi doğrulama
 */
function validate_user_ip() {
    $current_ip = $_SERVER['REMOTE_ADDR'] ?? '';
    
    if (isset($_SESSION['user_ip'])) {
        if ($_SESSION['user_ip'] !== $current_ip) {
            // IP changed - potential session hijacking
            session_destroy();
            return false;
        }
    } else {
        $_SESSION['user_ip'] = $current_ip;
    }
    
    return true;
}

/**
 * Rate Limiting - Hız sınırlama
 */
function check_rate_limit($action, $max_attempts = 5, $window = 300) {
    $key = $action . '_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    
    if (!isset($_SESSION['rate_limits'])) {
        $_SESSION['rate_limits'] = [];
    }
    
    $now = time();
    
    // Clean old entries
    $_SESSION['rate_limits'] = array_filter(
        $_SESSION['rate_limits'],
        function($timestamp) use ($now, $window) {
            return ($now - $timestamp) < $window;
        }
    );
    
    // Check current attempts
    $attempts = array_filter(
        $_SESSION['rate_limits'],
        function($timestamp) use ($key, $now, $window) {
            return strpos($timestamp, $key) === 0 && ($now - (int)substr($timestamp, strlen($key) + 1)) < $window;
        }
    );
    
    if (count($attempts) >= $max_attempts) {
        return false;
    }
    
    // Record this attempt
    $_SESSION['rate_limits'][$key . '_' . $now] = $now;
    
    return true;
}

/**
 * Input Validation - Girdi doğrulama
 */
function validate_employee_number($employee_number) {
    if (!$employee_number) return false;
    
    // Turkish employee numbers: 11 digits or EMP prefix + numbers
    if (preg_match('/^EMP\d{4,6}$/', $employee_number)) return true;
    if (preg_match('/^\d{11}$/', $employee_number)) return true;
    if (preg_match('/^\d{4,12}$/', $employee_number)) return true;
    
    return false;
}

function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validate_phone($phone) {
    // Turkish phone format: +90 or 0 followed by 10 digits
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    return preg_match('/^(\+90|0)?[1-9]\d{9}$/', $phone);
}

/**
 * Security Headers - Güvenlik başlıkları
 */
function set_security_headers() {
    // Prevent XSS
    header('X-XSS-Protection: 1; mode=block');
    
    // Prevent content type sniffing
    header('X-Content-Type-Options: nosniff');
    
    // Prevent clickjacking
    header('X-Frame-Options: SAMEORIGIN');
    
    // CSRF protection
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // Content Security Policy
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' https:");
}

/**
 * Database Query Security - Veritabanı sorgu güvenliği
 */
function execute_safe_query($conn, $query, $params = []) {
    try {
        $stmt = $conn->prepare($query);
        return $stmt->execute($params) ? $stmt : false;
    } catch (PDOException $e) {
        // Log error but don't expose to user
        error_log("Database query error: " . $e->getMessage());
        return false;
    }
}

/**
 * File Upload Security - Dosya yükleme güvenliği
 */
function validate_file_upload($file) {
    $errors = [];
    
    // Check file size (max 5MB)
    if ($file['size'] > 5242880) {
        $errors[] = 'Dosya boyutu 5MB\'dan büyük olamaz';
    }
    
    // Check file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
    if (!in_array($file['type'], $allowed_types)) {
        $errors[] = 'Sadece JPEG, PNG, GIF ve PDF dosyaları yüklenebilir';
    }
    
    // Check file extension
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'pdf'];
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_extensions)) {
        $errors[] = 'Geçersiz dosya uzantısı';
    }
    
    // Generate safe filename
    $safe_filename = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $file['name']);
    
    return [
        'valid' => empty($errors),
        'errors' => $errors,
        'safe_filename' => $safe_filename
    ];
}

/**
 * Activity Logging - Aktivite loglama
 */
function log_security_event($event_type, $details = [], $user_id = null) {
    $log_entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'event_type' => $event_type,
        'user_id' => $user_id ?? $_SESSION['user_id'] ?? null,
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'details' => $details
    ];
    
    // Log to file (in production, consider database logging)
    $log_file = __DIR__ . '/../logs/security.log';
    if (!file_exists(dirname($log_file))) {
        mkdir(dirname($log_file), 0755, true);
    }
    
    file_put_contents($log_file, json_encode($log_entry) . "\n", FILE_APPEND | LOCK_EX);
}

/**
 * Clean old sessions and temporary data
 */
function cleanup_security_data() {
    // Clean rate limit data older than 1 hour
    if (isset($_SESSION['rate_limits'])) {
        $now = time();
        $_SESSION['rate_limits'] = array_filter(
            $_SESSION['rate_limits'],
            function($timestamp) use ($now) {
                return ($now - $timestamp) < 3600;
            }
        );
    }
}

// Initialize security on include
if (session_status() === PHP_SESSION_NONE) {
    configure_secure_session();
}

// Set security headers
set_security_headers();

// Validate IP address
validate_user_ip();

// Clean old security data
cleanup_security_data();
?>