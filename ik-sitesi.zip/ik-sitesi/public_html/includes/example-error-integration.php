<?php
/**
 * SZB İK Takip - Hata Kayıt Sistemi Entegrasyon Örnekleri
 * Mevcut sistemde hata yakalama nasıl implement edilir
 */

// Database işlemleri için örnek
function exampleDatabaseOperation() {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
        
        // Örnek sorgu
        $stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
        $stmt->execute([123]);
        $result = $stmt->fetch();
        
        if (!$result) {
            // Manuel hata kaydı
            logError("Employee not found", ['employee_id' => 123], 'medium');
        }
        
        return $result;
        
    } catch (PDOException $e) {
        // Database hatasını kaydet
        logDatabaseError(
            $e->getMessage(), 
            "SELECT * FROM employees WHERE id = ?", 
            [123]
        );
        return false;
    }
}

// QR kod işlemleri için örnek
function exampleQRProcess($qrData) {
    try {
        if (empty($qrData)) {
            logQRError("Empty QR data received", $qrData, ['function' => 'exampleQRProcess']);
            return false;
        }
        
        // QR kod işlemleri...
        $location = findQRLocation($qrData);
        
        if (!$location) {
            logQRError("QR location not found", $qrData, [
                'function' => 'exampleQRProcess',
                'user_id' => $_SESSION['user_id'] ?? 'unknown'
            ]);
            return false;
        }
        
        return $location;
        
    } catch (Exception $e) {
        logQRError($e->getMessage(), $qrData, [
            'function' => 'exampleQRProcess',
            'trace' => $e->getTraceAsString()
        ]);
        return false;
    }
}

// Oturum işlemleri için örnek
function exampleSessionCheck() {
    if (!isset($_SESSION['user_id'])) {
        logSessionError("User session not found", [
            'page' => $_SERVER['REQUEST_URI'] ?? '',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ]);
        return false;
    }
    
    if ($_SESSION['last_activity'] < (time() - SESSION_TIMEOUT)) {
        logSessionError("Session expired", [
            'user_id' => $_SESSION['user_id'],
            'last_activity' => $_SESSION['last_activity'],
            'timeout' => SESSION_TIMEOUT
        ]);
        return false;
    }
    
    return true;
}

// Kullanıcı giriş işlemleri için örnek
function exampleLogin($email, $password) {
    try {
        if (empty($email) || empty($password)) {
            logLoginError("Empty credentials", $email, ['ip' => $_SERVER['REMOTE_ADDR'] ?? '']);
            return false;
        }
        
        // Kullanıcı doğrulaması...
        $user = authenticateUser($email, $password);
        
        if (!$user) {
            logLoginError("Invalid credentials", $email, [
                'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);
            return false;
        }
        
        return $user;
        
    } catch (Exception $e) {
        logLoginError("Login system error: " . $e->getMessage(), $email, [
            'trace' => $e->getTraceAsString()
        ]);
        return false;
    }
}

// Genel hata yakalama örneği
function exampleGeneralError() {
    try {
        // Risky operation
        $result = riskyOperation();
        return $result;
        
    } catch (Exception $e) {
        // Genel hata kaydı
        logError(
            "General operation failed: " . $e->getMessage(),
            [
                'function' => 'exampleGeneralError',
                'file' => __FILE__,
                'line' => __LINE__,
                'trace' => $e->getTraceAsString()
            ],
            'high'
        );
        return false;
    }
}

// Mevcut sayfalara entegrasyon örneği
function integrateErrorLoggingToExistingPage() {
    /*
    Mevcut bir PHP sayfasında hata yakalama nasıl eklenir:
    
    1. Sayfanın başına config.php include edilmiş olması gerekir
    2. Try-catch blokları ekleyin
    3. Uygun logError fonksiyonlarını kullanın
    
    Örnek:
    */
    
    // QR okuyucu sayfası için
    if (isset($_POST['qr_data'])) {
        try {
            $qrData = $_POST['qr_data'];
            $result = processQRData($qrData);
            
            if (!$result) {
                logQRError("QR processing failed", $qrData, [
                    'user_id' => $_SESSION['user_id'] ?? null,
                    'company_id' => $_SESSION['company_id'] ?? null
                ]);
            }
        } catch (Exception $e) {
            logQRError("QR processing exception: " . $e->getMessage(), $qrData);
        }
    }
    
    // Employee management sayfası için
    if (isset($_POST['action']) && $_POST['action'] === 'add_employee') {
        try {
            $employeeData = [
                'name' => $_POST['name'] ?? '',
                'email' => $_POST['email'] ?? ''
            ];
            
            if (empty($employeeData['name'])) {
                logError("Employee name is required", $employeeData, 'medium');
                throw new Exception("İsim alanı zorunludur");
            }
            
            $result = addEmployee($employeeData);
            
        } catch (Exception $e) {
            logError("Employee addition failed: " . $e->getMessage(), $employeeData, 'high');
        }
    }
}

?>