<?php
/**
 * Session Manager - Güvenli session başlatma ve yönetimi
 * MySQL formatında session yönetimi
 */

class SessionManager {
    
    /**
     * Güvenli session başlatma
     */
    public static function startSession() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    /**
     * Session durumunu kontrol et
     */
    public static function isSessionActive() {
        return session_status() === PHP_SESSION_ACTIVE;
    }
    
    /**
     * Session değişkenini güvenli şekilde al
     */
    public static function get($key, $default = null) {
        self::startSession();
        return $_SESSION[$key] ?? $default;
    }
    
    /**
     * Session değişkenini güvenli şekilde set et
     */
    public static function set($key, $value) {
        self::startSession();
        $_SESSION[$key] = $value;
    }
    
    /**
     * Admin yetkisini kontrol et
     */
    public static function requireAdmin() {
        self::startSession();
        $userRole = self::get('user_role');
        
        if (!$userRole || ($userRole !== 'admin' && $userRole !== 'super_admin')) {
            header('Location: ../auth/company-login.php');
            exit;
        }
    }
    
    /**
     * Personel yetkisini kontrol et
     */
    public static function requireEmployee() {
        self::startSession();
        
        if (!self::get('employee_id')) {
            header('Location: ../auth/employee-login.php');
            exit;
        }
    }
    
    /**
     * Company ID'yi güvenli şekilde al
     */
    public static function getCompanyId() {
        return self::get('company_id');
    }
    
    /**
     * User ID'yi güvenli şekilde al
     */
    public static function getUserId() {
        return self::get('user_id');
    }
    
    /**
     * Employee ID'yi güvenli şekilde al
     */
    public static function getEmployeeId() {
        return self::get('employee_id');
    }
    
    /**
     * Session'ı temizle ve logout yap
     */
    public static function destroy() {
        self::startSession();
        session_destroy();
        session_unset();
    }
}
?>