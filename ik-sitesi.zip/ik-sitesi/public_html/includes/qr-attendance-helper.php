<?php

class QRAttendanceHelper {
    
    /**
     * Get column mapping for attendance_records table compatibility
     * Fixes "Unknown column 'date'" errors by mapping to correct columns
     */
    public static function getColumnMapping($conn) {
        static $columnMap = null;
        
        if ($columnMap === null) {
            // Check what columns exist in attendance_records table
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $columnMap = [
                'date' => 'created_at', // Default to created_at since 'date' column often missing
                'check_in' => 'check_in_time',
                'check_out' => 'check_out_time', 
                'break_start' => 'break_start_time',
                'break_end' => 'break_end_time'
            ];
            
            // Map to actual existing columns
            if (in_array('date', $columns)) {
                $columnMap['date'] = 'date';
            } elseif (in_array('created_at', $columns)) {
                $columnMap['date'] = 'created_at';
            } elseif (in_array('check_in_time', $columns)) {
                $columnMap['date'] = 'check_in_time';
            }
            
            // Map check-in column
            if (in_array('check_in_time', $columns)) {
                $columnMap['check_in'] = 'check_in_time';
            } elseif (in_array('check_in', $columns)) {
                $columnMap['check_in'] = 'check_in';
            } elseif (in_array('clock_in', $columns)) {
                $columnMap['check_in'] = 'clock_in';
            }
            
            // Map check-out column
            if (in_array('check_out_time', $columns)) {
                $columnMap['check_out'] = 'check_out_time';
            } elseif (in_array('check_out', $columns)) {
                $columnMap['check_out'] = 'check_out';
            } elseif (in_array('clock_out', $columns)) {
                $columnMap['check_out'] = 'clock_out';
            }
            
            // Map break columns
            if (in_array('break_start_time', $columns)) {
                $columnMap['break_start'] = 'break_start_time';
            } elseif (in_array('break_start', $columns)) {
                $columnMap['break_start'] = 'break_start';
            }
            
            if (in_array('break_end_time', $columns)) {
                $columnMap['break_end'] = 'break_end_time';
            } elseif (in_array('break_end', $columns)) {
                $columnMap['break_end'] = 'break_end';
            }
        }
        
        return $columnMap;
    }
    
    /**
     * Get today's attendance safely with column compatibility
     */
    public static function getTodayAttendance($conn, $employeeId) {
        $colMap = self::getColumnMapping($conn);
        $today = date('Y-m-d');
        
        try {
            if ($colMap['date'] === 'created_at') {
                // Use DATE(created_at) when date column doesn't exist
                $stmt = $conn->prepare("
                    SELECT * FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = ?
                    ORDER BY id DESC LIMIT 1
                ");
            } else {
                // Use direct date column if it exists
                $stmt = $conn->prepare("
                    SELECT * FROM attendance_records 
                    WHERE employee_id = ? AND date = ?
                    ORDER BY id DESC LIMIT 1
                ");
            }
            
            $stmt->execute([$employeeId, $today]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (Exception $e) {
            error_log("QR Attendance Helper Error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Insert attendance record safely
     */
    public static function insertAttendanceRecord($conn, $data) {
        try {
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (employee_id, qr_location_id, activity_id, check_in_time, latitude, longitude, 
                 distance_meters, notes, device_mac_address, device_ip_address, 
                 device_user_agent, device_fingerprint, device_platform, device_browser, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            return $stmt->execute([
                $data['employee_id'],
                $data['qr_location_id'] ?? null,
                $data['activity_id'] ?? null,
                $data['check_in_time'] ?? date('Y-m-d H:i:s'),
                $data['latitude'] ?? null,
                $data['longitude'] ?? null,
                $data['distance_meters'] ?? null,
                $data['notes'] ?? '',
                $data['device_mac_address'] ?? null,
                $data['device_ip_address'] ?? null,
                $data['device_user_agent'] ?? null,
                $data['device_fingerprint'] ?? null,
                $data['device_platform'] ?? null,
                $data['device_browser'] ?? null
            ]);
            
        } catch (Exception $e) {
            error_log("QR Attendance Insert Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Determine current attendance status
     */
    public static function getCurrentStatus($conn, $employeeId) {
        $todayRecord = self::getTodayAttendance($conn, $employeeId);
        
        if (!$todayRecord) {
            return 'not_started'; // Henüz giriş yapmamış
        }
        
        // Check various time fields to determine status
        $hasCheckedIn = !empty($todayRecord['check_in_time']) || !empty($todayRecord['check_in']);
        $hasCheckedOut = !empty($todayRecord['check_out_time']) || !empty($todayRecord['check_out']);
        $onBreak = !empty($todayRecord['break_start_time']) && empty($todayRecord['break_end_time']);
        
        if ($hasCheckedOut) {
            return 'checked_out'; // İş çıkışı yapılmış
        } elseif ($onBreak) {
            return 'on_break'; // Mola'da
        } elseif ($hasCheckedIn) {
            return 'checked_in'; // İş başında
        } else {
            return 'not_started'; // Henüz başlamadı
        }
    }
    
    /**
     * Get available activities based on current status
     */
    public static function getAvailableActivities($conn, $employeeId) {
        $status = self::getCurrentStatus($conn, $employeeId);
        
        $activities = [];
        
        switch ($status) {
            case 'not_started':
                $activities[] = ['type' => 'work_in', 'label' => 'İş Giriş', 'icon' => '🏢'];
                break;
                
            case 'checked_in':
                $activities[] = ['type' => 'break_start', 'label' => 'Mola Başlat', 'icon' => '☕'];
                $activities[] = ['type' => 'work_out', 'label' => 'İş Çıkış', 'icon' => '🚪'];
                break;
                
            case 'on_break':
                $activities[] = ['type' => 'break_end', 'label' => 'Mola Bitir', 'icon' => '⚡'];
                break;
                
            case 'checked_out':
                $activities[] = ['type' => 'work_in', 'label' => 'Tekrar Giriş', 'icon' => '🔄'];
                break;
        }
        
        return $activities;
    }
}
?>