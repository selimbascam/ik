<?php
/**
 * Hostinger Optimized Database Connection
 * Handles multiple database connection methods for maximum compatibility
 */
class Database {
    private $connection;
    private $host = 'localhost';
    private $database = 'u978874874_ik';
    private $username = 'u978874874_ik';
    private $password = 'Szb2013@+-!';

    public function __construct() {
        $this->connect();
    }
    
    private function connect() {
        // Method 1: Try PDO MySQL
        if (extension_loaded('pdo') && extension_loaded('pdo_mysql')) {
            try {
                $dsn = "mysql:host={$this->host};dbname={$this->database};charset=utf8mb4";
                $this->connection = new PDO($dsn, $this->username, $this->password, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
                return;
            } catch (PDOException $e) {
                // Continue to next method
            }
        }
        
        // Method 2: Try MySQLi
        if (extension_loaded('mysqli')) {
            try {
                $this->connection = new mysqli($this->host, $this->username, $this->password, $this->database);
                if ($this->connection->connect_error) {
                    throw new Exception("MySQLi connection failed: " . $this->connection->connect_error);
                }
                $this->connection->set_charset("utf8mb4");
                return;
            } catch (Exception $e) {
                // Continue to next method
            }
        }
        
        throw new Exception("Veritabanı bağlantısı kurulamadı. PDO MySQL veya MySQLi extension gerekli.");
    }

    public function getConnection() {
        if ($this->conn !== null) {
            return $this->conn;
        }

        try {
            // Hostinger detection
            $is_hostinger = isset($_SERVER['HTTP_HOST']) && (
                strpos($_SERVER['HTTP_HOST'], '.hostinger.') !== false ||
                strpos($_SERVER['HTTP_HOST'], '.hostingerpro.') !== false ||
                strpos($_SERVER['HTTP_HOST'], '.000webhost.') !== false
            );
            
            if ($is_hostinger) {
                // MySQL DSN for Hostinger
                $dsn = "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=utf8mb4";
                
                $this->conn = new PDO($dsn, $this->username, $this->password, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                ]);
                
                // MySQL için timezone ayarla
                $this->conn->exec("SET time_zone = '+03:00'");
                
            } else {
                // PostgreSQL DSN for development
                $dsn = "pgsql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";sslmode=require";
                
                $this->conn = new PDO($dsn, $this->username, $this->password, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_TIMEOUT => 30
                ]);
                
                // PostgreSQL için UTC timezone ayarla
                $this->conn->exec("SET timezone = 'UTC'");
            }
            
        } catch(PDOException $exception) {
            error_log("Veritabanı bağlantı hatası: " . $exception->getMessage());
            throw new Exception("Veritabanı bağlantısı kurulamadı: " . $exception->getMessage());
        }

        return $this->conn;
    }
    
    // MySQL -> PostgreSQL uyumluluk fonksiyonları
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }
    
    // SHOW TABLES benzeri fonksiyon
    public function showTables() {
        $stmt = $this->conn->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    // SHOW COLUMNS benzeri fonksiyon  
    public function showColumns($tableName) {
        $stmt = $this->conn->prepare("
            SELECT column_name as Field, data_type as Type, 
                   is_nullable as \"Null\", column_default as \"Default\"
            FROM information_schema.columns 
            WHERE table_name = ? 
            ORDER BY ordinal_position
        ");
        $stmt->execute([$tableName]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function testConnection() {
        try {
            $conn = $this->getConnection();
            $stmt = $conn->query("SELECT 1");
            return ['success' => 1, 'message' => 'PostgreSQL bağlantısı başarılı'];
        } catch (Exception $e) {
            return ['success' => 0, 'message' => $e->getMessage()];
        }
    }
}
?>