<?php
// E-posta konfigürasyon ayarları

// Temel e-posta ayarları
define('EMAIL_FROM', 'noreply@szbiktakip.com'); // Kendi domain'inizle değiştirin
define('EMAIL_FROM_NAME', 'SZB İK Takip');
define('EMAIL_REPLY_TO', 'info@szbiktakip.com');

// SMTP ayarları (opsiyonel - PHP mail() yerine SMTP kullanmak için)
define('SMTP_ENABLED', 0); // true yapın SMTP kullanmak için
define('SMTP_HOST', 'mail.yourdomain.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'noreply@yourdomain.com');
define('SMTP_PASSWORD', 'your_email_password');
define('SMTP_ENCRYPTION', 'tls'); // 'tls' veya 'ssl'

// E-posta şablonları
function getEmailTemplate($title, $content) {
    return "
    <!DOCTYPE html>
    <html lang='tr'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>$title</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #4F46E5; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background-color: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
            .credentials { background-color: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #4F46E5; }
            .button { display: inline-block; background-color: #4F46E5; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 15px 0; }
            .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='header'>
            <h1>SZB İK Takip</h1>
            <p>İnsan Kaynakları Yönetim Sistemi</p>
        </div>
        <div class='content'>
            $content
        </div>
        <div class='footer'>
            <p>Bu e-posta otomatik olarak gönderilmiştir. Lütfen yanıtlamayın.</p>
            <p>&copy; " . date('Y') . " SZB İK Takip. Tüm hakları saklıdır.</p>
        </div>
    </body>
    </html>";
}

// Gelişmiş e-posta gönderme fonksiyonu
function sendAdvancedEmail($to, $subject, $htmlContent) {
    if (SMTP_ENABLED) {
        return sendSMTPEmail($to, $subject, $htmlContent);
    } else {
        return sendPHPMail($to, $subject, $htmlContent);
    }
}

// PHP mail() ile gönderme
function sendPHPMail($to, $subject, $htmlContent) {
    $headers = [
        "MIME-Version: 1.0",
        "Content-Type: text/html; charset=UTF-8",
        "From: " . EMAIL_FROM_NAME . " <" . EMAIL_FROM . ">",
        "Reply-To: " . EMAIL_REPLY_TO,
        "X-Mailer: PHP/" . phpversion(),
        "X-Priority: 3"
    ];
    
    try {
        $success = mail($to, $subject, $htmlContent, implode("\r\n", $headers));
        
        if ($success) {
            error_log("Email sent successfully to: $to");
            return true;
        } else {
            error_log("Failed to send email to: $to using PHP mail()");
            return false;
        }
    } catch (Exception $e) {
        error_log("Email sending error: " . $e->getMessage());
        return false;
    }
}

// SMTP ile gönderme (gelişmiş)
function sendSMTPEmail($to, $subject, $htmlContent) {
    try {
        $socket = fsockopen(SMTP_HOST, SMTP_PORT, $errno, $errstr, 30);
        if (!$socket) {
            error_log("SMTP connection failed: $errstr ($errno)");
            return false;
        }
        
        // SMTP sohbet başlat
        $response = fgets($socket, 515);
        if (substr($response, 0, 3) != '220') {
            error_log("SMTP Error: $response");
            fclose($socket);
            return false;
        }
        
        // EHLO komutu
        fputs($socket, "EHLO " . $_SERVER['SERVER_NAME'] . "\r\n");
        $response = fgets($socket, 515);
        
        // STARTTLS (eğer TLS kullanılıyorsa)
        if (SMTP_ENCRYPTION === 'tls') {
            fputs($socket, "STARTTLS\r\n");
            $response = fgets($socket, 515);
            stream_socket_enable_crypto($socket, 1, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            
            fputs($socket, "EHLO " . $_SERVER['SERVER_NAME'] . "\r\n");
            $response = fgets($socket, 515);
        }
        
        // Kimlik doğrulama
        fputs($socket, "AUTH LOGIN\r\n");
        $response = fgets($socket, 515);
        
        fputs($socket, base64_encode(SMTP_USERNAME) . "\r\n");
        $response = fgets($socket, 515);
        
        fputs($socket, base64_encode(SMTP_PASSWORD) . "\r\n");
        $response = fgets($socket, 515);
        
        // E-posta gönder
        fputs($socket, "MAIL FROM: <" . EMAIL_FROM . ">\r\n");
        $response = fgets($socket, 515);
        
        fputs($socket, "RCPT TO: <$to>\r\n");
        $response = fgets($socket, 515);
        
        fputs($socket, "DATA\r\n");
        $response = fgets($socket, 515);
        
        $emailData = "Subject: $subject\r\n";
        $emailData .= "From: " . EMAIL_FROM_NAME . " <" . EMAIL_FROM . ">\r\n";
        $emailData .= "To: $to\r\n";
        $emailData .= "MIME-Version: 1.0\r\n";
        $emailData .= "Content-Type: text/html; charset=UTF-8\r\n";
        $emailData .= "\r\n";
        $emailData .= $htmlContent . "\r\n";
        $emailData .= ".\r\n";
        
        fputs($socket, $emailData);
        $response = fgets($socket, 515);
        
        fputs($socket, "QUIT\r\n");
        fclose($socket);
        
        error_log("SMTP email sent successfully to: $to");
        return true;
        
    } catch (Exception $e) {
        error_log("SMTP Error: " . $e->getMessage());
        return false;
    }
}
?>