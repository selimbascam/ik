<?php
/**
 * SZB İK Takip - Otomatik Hata Kayıt Sistemi
 * Tüm sistem hatalarını otomatik olarak kaydeder ve çözüm takibi yapar
 * 
 * Kullanım:
 * ErrorLogger::logError($message, $context, $severity);
 * ErrorLogger::markAsSolved($errorId, $solution);
 * ErrorLogger::generateReport();
 */

class ErrorLogger {
    
    private static $db = null;
    
    /**
     * Veritabanı bağlantısını al
     */
    private static function getDatabase() {
        if (self::$db === null) {
            require_once 'config.php';
            try {
                self::$db = new PDO(
                    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                    DB_USER,
                    DB_PASS,
                    [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                    ]
                );
            } catch (PDOException $e) {
                // Veritabanı bağlantısı yoksa dosyaya yaz
                self::logToFile("Database connection failed: " . $e->getMessage());
                return null;
            }
        }
        return self::$db;
    }
    
    /**
     * Hata kayıt tablosunu oluştur (ilk çalıştırmada)
     */
    public static function createErrorTable() {
        $db = self::getDatabase();
        if (!$db) return false;
        
        try {
            $sql = "
                CREATE TABLE IF NOT EXISTS system_error_log (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    error_code VARCHAR(50),
                    error_message TEXT NOT NULL,
                    error_context JSON,
                    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
                    user_id VARCHAR(50),
                    company_id INT,
                    page_url VARCHAR(500),
                    user_agent TEXT,
                    ip_address VARCHAR(45),
                    stack_trace TEXT,
                    status ENUM('unsolved', 'investigating', 'solved', 'ignored') DEFAULT 'unsolved',
                    solution_notes TEXT,
                    solved_by VARCHAR(100),
                    solved_at TIMESTAMP NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_status (status),
                    INDEX idx_severity (severity),
                    INDEX idx_company (company_id),
                    INDEX idx_created (created_at)
                )
            ";
            
            $db->exec($sql);
            return true;
        } catch (PDOException $e) {
            self::logToFile("Error table creation failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Hatayı otomatik kaydet
     */
    public static function logError($message, $context = [], $severity = 'medium') {
        // Önce tablo var mı kontrol et
        self::createErrorTable();
        
        $db = self::getDatabase();
        
        // Context'i güvenli şekilde encode et
        $safeContext = self::safeJsonEncode($context);
        
        // Hata detaylarını topla
        $errorData = [
            'error_code' => self::generateErrorCode(),
            'error_message' => (string)$message,
            'error_context' => $safeContext,
            'severity' => (string)$severity,
            'user_id' => isset($_SESSION['user_id']) ? (string)$_SESSION['user_id'] : null,
            'company_id' => isset($_SESSION['company_id']) ? (string)$_SESSION['company_id'] : null,
            'page_url' => isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? (string)$_SERVER['HTTP_USER_AGENT'] : '',
            'ip_address' => self::getUserIP(),
            'stack_trace' => self::getStackTrace()
        ];
        
        if ($db) {
            try {
                $sql = "INSERT INTO system_error_log (
                    error_code, error_message, error_context, severity, 
                    user_id, company_id, page_url, user_agent, ip_address, stack_trace
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                $stmt = $db->prepare($sql);
                $stmt->execute([
                    $errorData['error_code'],
                    $errorData['error_message'],
                    $errorData['error_context'],
                    $errorData['severity'],
                    $errorData['user_id'],
                    $errorData['company_id'],
                    $errorData['page_url'],
                    $errorData['user_agent'],
                    $errorData['ip_address'],
                    $errorData['stack_trace']
                ]);
                
                return $db->lastInsertId();
            } catch (PDOException $e) {
                self::logToFile("Error logging failed: " . $e->getMessage());
            }
        }
        
        // Veritabanı yoksa dosyaya yaz
        self::logToFile(json_encode($errorData, JSON_PRETTY_PRINT));
        return null;
    }
    
    /**
     * Hatayı çözüldü olarak işaretle
     */
    public static function markAsSolved($errorId, $solution, $solvedBy = 'System Admin') {
        $db = self::getDatabase();
        if (!$db) return false;
        
        try {
            $sql = "UPDATE system_error_log 
                   SET status = 'solved', 
                       solution_notes = ?, 
                       solved_by = ?, 
                       solved_at = NOW() 
                   WHERE id = ?";
            
            $stmt = $db->prepare($sql);
            return $stmt->execute([$solution, $solvedBy, $errorId]);
        } catch (PDOException $e) {
            self::logError("Failed to mark error as solved: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Hata durumunu güncelle
     */
    public static function updateStatus($errorId, $status, $notes = '') {
        $db = self::getDatabase();
        if (!$db) return false;
        
        $validStatuses = ['unsolved', 'investigating', 'solved', 'ignored'];
        if (!in_array($status, $validStatuses)) return false;
        
        try {
            $sql = "UPDATE system_error_log 
                   SET status = ?, solution_notes = ?, updated_at = NOW() 
                   WHERE id = ?";
            
            $stmt = $db->prepare($sql);
            return $stmt->execute([$status, $notes, $errorId]);
        } catch (PDOException $e) {
            self::logError("Failed to update error status: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Hata listesini al
     */
    public static function getErrors($filters = []) {
        $db = self::getDatabase();
        if (!$db) return [];
        
        try {
            $where = [];
            $params = [];
            
            if (isset($filters['status'])) {
                $where[] = "status = ?";
                $params[] = $filters['status'];
            }
            
            if (isset($filters['severity'])) {
                $where[] = "severity = ?";
                $params[] = $filters['severity'];
            }
            
            if (isset($filters['company_id'])) {
                $where[] = "company_id = ?";
                $params[] = $filters['company_id'];
            }
            
            if (isset($filters['date_from'])) {
                $where[] = "created_at >= ?";
                $params[] = $filters['date_from'];
            }
            
            $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';
            
            $sql = "SELECT * FROM system_error_log 
                   $whereClause 
                   ORDER BY created_at DESC 
                   LIMIT " . ($filters['limit'] ?? 100);
            
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            self::logError("Failed to retrieve errors: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Hata istatistiklerini al
     */
    public static function getErrorStats() {
        $db = self::getDatabase();
        if (!$db) return [];
        
        try {
            $sql = "SELECT 
                       COUNT(*) as total_errors,
                       SUM(CASE WHEN status = 'unsolved' THEN 1 ELSE 0 END) as unsolved,
                       SUM(CASE WHEN status = 'investigating' THEN 1 ELSE 0 END) as investigating,
                       SUM(CASE WHEN status = 'solved' THEN 1 ELSE 0 END) as solved,
                       SUM(CASE WHEN status = 'ignored' THEN 1 ELSE 0 END) as ignored,
                       SUM(CASE WHEN severity = 'critical' THEN 1 ELSE 0 END) as critical,
                       SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high,
                       SUM(CASE WHEN severity = 'medium' THEN 1 ELSE 0 END) as medium,
                       SUM(CASE WHEN severity = 'low' THEN 1 ELSE 0 END) as low
                   FROM system_error_log";
            
            $stmt = $db->query($sql);
            return $stmt->fetch();
        } catch (PDOException $e) {
            return [];
        }
    }
    
    /**
     * JSON formatında rapor oluştur (yüklenebilir)
     */
    public static function generateReport($filters = []) {
        $errors = self::getErrors($filters);
        $stats = self::getErrorStats();
        
        $report = [
            'system_info' => [
                'system_name' => 'SZB İK Takip',
                'report_generated_at' => date('Y-m-d H:i:s'),
                'server_info' => [
                    'php_version' => phpversion(),
                    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                    'memory_usage' => memory_get_usage(true),
                    'memory_limit' => ini_get('memory_limit')
                ]
            ],
            'statistics' => $stats,
            'errors' => $errors
        ];
        
        return $report;
    }
    
    /**
     * Raporu dosyaya kaydet
     */
    public static function exportReport($filename = null, $filters = []) {
        if (!$filename) {
            $filename = 'szb-ik-error-report-' . date('Y-m-d-H-i-s') . '.json';
        }
        
        $report = self::generateReport($filters);
        $jsonData = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        
        // Uploads klasörüne kaydet
        $uploadPath = __DIR__ . '/../uploads/error-reports/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }
        
        $fullPath = $uploadPath . $filename;
        file_put_contents($fullPath, $jsonData);
        
        return $fullPath;
    }
    
    /**
     * Benzersiz hata kodu oluştur
     */
    private static function generateErrorCode() {
        return 'ERR_' . date('Ymd') . '_' . substr(uniqid(), -6);
    }
    
    /**
     * Kullanıcının IP adresini al
     */
    private static function getUserIP() {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_X_REAL_IP'])) {
            return $_SERVER['HTTP_X_REAL_IP'];
        } else {
            return $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        }
    }
    
    /**
     * Stack trace al
     */
    private static function getStackTrace() {
        ob_start();
        debug_print_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
        $trace = ob_get_clean();
        return (string)$trace;
    }
    
    /**
     * Güvenli JSON encode işlemi - Array to string conversion hatalarını önler
     */
    private static function safeJsonEncode($data) {
        if (is_string($data)) {
            return $data;
        }
        
        if (is_array($data) || is_object($data)) {
            // Recursive reference'ları önlemek için depth limit koy
            $json = @json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR, 5);
            
            // JSON encode başarısızsa, güvenli string conversion
            if ($json === false || $json === null) {
                try {
                    // Array to string conversion hatası önlemek için
                    ob_start();
                    var_export($data);
                    $result = ob_get_clean();
                    return $result ?: 'Complex data structure (serialization failed)';
                } catch (Exception $e) {
                    return 'Data structure (conversion error: ' . $e->getMessage() . ')';
                }
            }
            
            return $json;
        }
        
        // Null ve diğer veri tiplerini güvenli şekilde string'e çevir
        if ($data === null) {
            return 'null';
        }
        
        return @(string)$data ?: 'unknown';
    }
    
    /**
     * Dosyaya kaydet (veritabanı yoksa)
     */
    private static function logToFile($data) {
        $logFile = __DIR__ . '/../logs/error-log-' . date('Y-m-d') . '.txt';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[$timestamp] $data" . PHP_EOL . str_repeat('-', 80) . PHP_EOL;
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
}

/**
 * Global hata yakalayıcıları
 */

// PHP hatalarını yakala - Array to string conversion uyarılarını engelle
set_error_handler(function($severity, $message, $file, $line) {
    // Array to string conversion uyarılarını filtrele
    if (strpos($message, 'Array to string conversion') !== false) {
        return true; // Uyarıyı sessizce geç
    }
    
    $severityMap = [
        E_ERROR => 'critical',
        E_WARNING => 'high',
        E_NOTICE => 'medium',
        E_USER_ERROR => 'critical',
        E_USER_WARNING => 'high',
        E_USER_NOTICE => 'medium'
    ];
    
    $errorSeverity = $severityMap[$severity] ?? 'medium';
    
    ErrorLogger::logError(
        "PHP Error: $message", 
        [
            'file' => $file,
            'line' => $line,
            'severity_code' => $severity
        ], 
        $errorSeverity
    );
    
    // Orijinal hata işleyicisine devam et
    return false;
});

// Fatal hataları yakala
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        ErrorLogger::logError(
            "Fatal Error: " . $error['message'], 
            [
                'file' => $error['file'],
                'line' => $error['line'],
                'type' => $error['type']
            ], 
            'critical'
        );
    }
});

// Exception yakalayıcı
set_exception_handler(function($exception) {
    ErrorLogger::logError(
        "Uncaught Exception: " . $exception->getMessage(), 
        [
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'trace' => $exception->getTraceAsString()
        ], 
        'critical'
    );
});

?>