<?php
/**
 * Hata kayıt sistemini başlat
 * Bu dosya tüm sayfalarda include edilmeli
 */

// Error logger'ı dahil et
require_once __DIR__ . '/error-logger.php';

// Hata tablosunu oluştur (ilk çalıştırmada)
ErrorLogger::createErrorTable();

// Manuel hata kaydetme fonksiyonu (kolay kullanım için)
function logError($message, $context = [], $severity = 'medium') {
    return ErrorLogger::logError($message, $context, $severity);
}

// Database hatalarını yakala
function logDatabaseError($message, $query = '', $params = []) {
    return ErrorLogger::logError(
        "Database Error: $message",
        [
            'query' => $query,
            'parameters' => $params,
            'type' => 'database'
        ],
        'high'
    );
}

// QR kod hatalarını yakala
function logQRError($message, $qrData = '', $context = []) {
    return ErrorLogger::logError(
        "QR System Error: $message",
        array_merge($context, [
            'qr_data' => $qrData,
            'type' => 'qr_system'
        ]),
        'medium'
    );
}

// Oturum hatalarını yakala
function logSessionError($message, $context = []) {
    return ErrorLogger::logError(
        "Session Error: $message",
        array_merge($context, [
            'type' => 'session'
        ]),
        'medium'
    );
}

// Kullanıcı giriş hatalarını yakala
function logLoginError($message, $email = '', $context = []) {
    return ErrorLogger::logError(
        "Login Error: $message",
        array_merge($context, [
            'email' => $email,
            'type' => 'authentication'
        ]),
        'medium'
    );
}

?>