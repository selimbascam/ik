<?php
/**
 * ACİL SİSTEM KONTROL DOSYASI
 * Site erişim sorunlarını tespit etmek için
 */

echo "<h1>🚨 ACİL SİSTEM DURUM KONTROLÜ</h1>";
echo "<style>body { font-family: Arial; margin: 20px; } .success { color: green; } .error { color: red; } .warning { color: orange; }</style>";

// 1. PHP Version Check
echo "<h2>1. PHP VERSİYON KONTROLÜ</h2>";
echo "<div class='success'>✅ PHP Version: " . phpversion() . "</div>";

// 2. Include Files Check
echo "<h2>2. INCLUDE DOSYALARI KONTROLÜ</h2>";
$files_to_check = [
    'includes/config.php',
    'includes/database.php',
    'includes/session-manager.php'
];

foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        echo "<div class='success'>✅ $file - Mevcut</div>";
    } else {
        echo "<div class='error'>❌ $file - Eksik!</div>";
    }
}

// 3. Config File Test
echo "<h2>3. CONFIG DOSYASI TEST</h2>";
try {
    require_once 'includes/config.php';
    echo "<div class='success'>✅ Config dosyası başarıyla yüklendi</div>";
    echo "<div class='success'>✅ APP_NAME: " . (defined('APP_NAME') ? APP_NAME : 'Tanımsız') . "</div>";
    echo "<div class='success'>✅ DB_HOST: " . (defined('DB_HOST') ? DB_HOST : 'Tanımsız') . "</div>";
    echo "<div class='success'>✅ DB_NAME: " . (defined('DB_NAME') ? DB_NAME : 'Tanımsız') . "</div>";
} catch (Exception $e) {
    echo "<div class='error'>❌ Config dosyası hatası: " . $e->getMessage() . "</div>";
}

// 4. Database Connection Test  
echo "<h2>4. VERİTABANI BAĞLANTI TEST</h2>";
try {
    require_once 'includes/database.php';
    $db = new Database();
    $result = $db->testConnection();
    
    if ($result['success']) {
        echo "<div class='success'>✅ Veritabanı bağlantısı başarılı</div>";
        
        // Test basic queries
        $conn = $db->getConnection();
        
        // Check companies table
        $stmt = $conn->query("SELECT COUNT(*) as count FROM companies");
        $count = $stmt->fetch()['count'];
        echo "<div class='success'>✅ Şirket sayısı: $count</div>";
        
        // Check employees table
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employees");
        $count = $stmt->fetch()['count'];
        echo "<div class='success'>✅ Personel sayısı: $count</div>";
        
        // Check attendance_records table
        $stmt = $conn->query("SELECT COUNT(*) as count FROM attendance_records");
        $count = $stmt->fetch()['count'];
        echo "<div class='success'>✅ Devam kayıtları: $count</div>";
        
    } else {
        echo "<div class='error'>❌ Veritabanı bağlantı hatası: " . $result['message'] . "</div>";
    }
} catch (Exception $e) {
    echo "<div class='error'>❌ Veritabanı hatası: " . $e->getMessage() . "</div>";
}

// 5. Session Test
echo "<h2>5. SESSION KONTROLÜ</h2>";
if (session_status() === PHP_SESSION_ACTIVE) {
    echo "<div class='success'>✅ Session aktif</div>";
    echo "<div class='success'>✅ Session ID: " . session_id() . "</div>";
} else {
    echo "<div class='warning'>⚠️ Session aktif değil</div>";
}

// 6. File Permissions
echo "<h2>6. DOSYA İZİNLERİ KONTROLÜ</h2>";
$permission_files = [
    '.',
    'includes',
    'admin',
    'super-admin',
    'dashboard'
];

foreach ($permission_files as $file) {
    if (file_exists($file)) {
        $perms = fileperms($file);
        $perms_octal = sprintf('%o', $perms & 0777);
        echo "<div class='success'>✅ $file - İzinler: $perms_octal</div>";
    } else {
        echo "<div class='error'>❌ $file - Bulunamadı!</div>";
    }
}

// 7. Error Log Check
echo "<h2>7. HATA LOGLARI KONTROLÜ</h2>";
$error_log = ini_get('error_log');
if ($error_log && file_exists($error_log)) {
    $log_content = file_get_contents($error_log);
    $recent_errors = array_slice(explode("\n", $log_content), -10);
    
    echo "<div class='warning'>⚠️ Son 10 hata:</div>";
    echo "<pre style='background: #f0f0f0; padding: 10px; border-radius: 5px; font-size: 12px;'>";
    foreach ($recent_errors as $error) {
        if (trim($error)) {
            echo htmlspecialchars($error) . "\n";
        }
    }
    echo "</pre>";
} else {
    echo "<div class='success'>✅ Error log bulunamadı veya erişilemedi</div>";
}

// 8. Critical Pages Test
echo "<h2>8. ÖNEMLİ SAYFALAR KONTROLÜ</h2>";
$critical_pages = [
    'index.php',
    'admin/index.php',
    'super-admin/index.php',
    'dashboard/company-dashboard.php',
    'qr-scanner.php'
];

foreach ($critical_pages as $page) {
    if (file_exists($page)) {
        echo "<div class='success'>✅ $page - Mevcut</div>";
    } else {
        echo "<div class='error'>❌ $page - Eksik!</div>";
    }
}

// 9. Server Variables
echo "<h2>9. SERVER DEĞİŞKENLERİ</h2>";
echo "<div class='success'>✅ Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "</div>";
echo "<div class='success'>✅ HTTP Host: " . ($_SERVER['HTTP_HOST'] ?? 'Tanımsız') . "</div>";
echo "<div class='success'>✅ Request URI: " . ($_SERVER['REQUEST_URI'] ?? 'Tanımsız') . "</div>";
echo "<div class='success'>✅ Server Software: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Tanımsız') . "</div>";

// 10. Memory Usage
echo "<h2>10. BELLEK KULLANIMI</h2>";
$memory_usage = memory_get_usage(true);
$memory_peak = memory_get_peak_usage(true);
echo "<div class='success'>✅ Mevcut bellek: " . round($memory_usage / 1024 / 1024, 2) . " MB</div>";
echo "<div class='success'>✅ Peak bellek: " . round($memory_peak / 1024 / 1024, 2) . " MB</div>";

echo "<hr>";
echo "<h2>🎯 SUPER ADMIN ERİŞİM TEST</h2>";
echo "<p><a href='super-admin/' style='background: red; color: white; padding: 10px; text-decoration: none; border-radius: 5px;'>Super Admin Panel'e Git</a></p>";
echo "<p><strong>Super Admin Şifresi:</strong> SZB2025Admin!</p>";

echo "<hr>";
echo "<p><strong>Test tamamlandı:</strong> " . date('Y-m-d H:i:s') . "</p>";
?>