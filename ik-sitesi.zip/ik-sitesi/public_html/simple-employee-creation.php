<?php
// Simple employee creation using direct MySQL connection
echo "<h2>Simple Employee Creation for 30716129672</h2>";

// Database connection
$host = 'localhost';
$database = 'u978874874_ik';
$username = 'u978874874_ik';
$password = 'Szb2013@+-!';

try {
    $conn = new mysqli($host, $username, $password, $database);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8mb4");
    
    echo "<p style='color: green;'>✅ Database connected successfully</p>";
    
    // Check current employees
    echo "<h3>Current Employees:</h3>";
    $result = $conn->query("SELECT employee_number, first_name, last_name FROM employees ORDER BY id");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>• {$row['employee_number']} - {$row['first_name']} {$row['last_name']}</p>";
        }
    } else {
        echo "<p>No employees found</p>";
    }
    
    // Check if target employee exists
    $check = $conn->prepare("SELECT id FROM employees WHERE employee_number = ?");
    $check->bind_param("s", $target_number);
    $target_number = '30716129672';
    $check->execute();
    $exists = $check->get_result()->fetch_assoc();
    
    if ($exists) {
        echo "<p style='color: orange;'>⚠️ Employee 30716129672 already exists</p>";
        
        // Update password for existing employee
        $hashedPassword = password_hash('123456', PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE employees SET password = ? WHERE employee_number = ?");
        $update->bind_param("ss", $hashedPassword, $target_number);
        if ($update->execute()) {
            echo "<p style='color: green;'>✅ Password updated for existing employee</p>";
        }
        
    } else {
        echo "<h3>Creating Employee 30716129672:</h3>";
        
        // Create new employee
        $hashedPassword = password_hash('123456', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("
            INSERT INTO employees (employee_number, first_name, last_name, password, company_id, status, is_active) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $first_name = 'Test';
        $last_name = 'Personel';
        $company_id = 1;
        $status = 'active';
        $is_active = 1;
        
        $stmt->bind_param("ssssssi", $target_number, $first_name, $last_name, $hashedPassword, $company_id, $status, $is_active);
        
        if ($stmt->execute()) {
            echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px;'>";
            echo "<h4>🎉 SUCCESS! Employee Created</h4>";
            echo "<p><strong>Login Credentials:</strong></p>";
            echo "<ul>";
            echo "<li><strong>Employee Number:</strong> 30716129672</li>";
            echo "<li><strong>Password:</strong> 123456</li>";
            echo "<li><strong>Name:</strong> Test Personel</li>";
            echo "</ul>";
            echo "</div>";
            
            // Verify creation
            $verify = $conn->prepare("SELECT id, first_name, last_name, employee_number FROM employees WHERE employee_number = ?");
            $verify->bind_param("s", $target_number);
            $verify->execute();
            $created = $verify->get_result()->fetch_assoc();
            
            if ($created) {
                echo "<p style='color: green;'>✅ Verification: Employee exists in database</p>";
                echo "<p><strong>Employee Details:</strong></p>";
                echo "<ul>";
                echo "<li>ID: {$created['id']}</li>";
                echo "<li>Name: {$created['first_name']} {$created['last_name']}</li>";
                echo "<li>Number: {$created['employee_number']}</li>";
                echo "</ul>";
            }
            
        } else {
            echo "<p style='color: red;'>❌ Failed to create employee: " . $stmt->error . "</p>";
        }
    }
    
    // Final employee list
    echo "<h3>Final Employee List:</h3>";
    $final = $conn->query("SELECT employee_number, first_name, last_name FROM employees ORDER BY id");
    if ($final && $final->num_rows > 0) {
        while ($row = $final->fetch_assoc()) {
            $highlight = ($row['employee_number'] == '30716129672') ? 'style="color: green; font-weight: bold;"' : '';
            echo "<p {$highlight}>• {$row['employee_number']} - {$row['first_name']} {$row['last_name']}</p>";
        }
    }
    
    echo "<div style='background: #e3f2fd; border: 1px solid #90caf9; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h4>📋 Next Steps:</h4>";
    echo "<ol>";
    echo "<li>Employee 30716129672 is now ready for login</li>";
    echo "<li>Use password: <strong>123456</strong></li>";
    echo "<li>Test login at: <a href='auth/employee-login.php' target='_blank'>Employee Login Page</a></li>";
    echo "</ol>";
    echo "</div>";
    
    $conn->close();
    
} catch (Exception $e) {
    echo "<p style='color: red; font-weight: bold;'>❌ ERROR: " . $e->getMessage() . "</p>";
    
    // Show some debugging info
    echo "<h4>Debug Information:</h4>";
    echo "<ul>";
    echo "<li>MySQL extension loaded: " . (extension_loaded('mysqli') ? 'Yes' : 'No') . "</li>";
    echo "<li>PDO extension loaded: " . (extension_loaded('pdo') ? 'Yes' : 'No') . "</li>";
    echo "<li>Current directory: " . getcwd() . "</li>";
    echo "</ul>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
ul { margin: 10px 0; padding-left: 20px; }
</style>