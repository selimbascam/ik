<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔧 QR Devam Takip Sistemi Düzeltmesi</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();

    // Step 1: Standardize session usage
    echo "<h3>🔐 Session Standardizasyonu</h3>";
    
    // Update qr-attendance.php to use employee_id instead of user_id
    $qrAttendanceFile = '../employee/qr-attendance.php';
    if (file_exists($qrAttendanceFile)) {
        $content = file_get_contents($qrAttendanceFile);
        
        // Replace session checks
        $content = str_replace(
            "!isset(\$_SESSION['user_id']) || \$_SESSION['user_role'] !== 'employee'",
            "!isset(\$_SESSION['employee_id'])",
            $content
        );
        
        $content = str_replace(
            "\$_SESSION['user_id']",
            "\$_SESSION['employee_id']",
            $content
        );
        
        if (file_put_contents($qrAttendanceFile, $content)) {
            echo "<p>✅ qr-attendance.php session standardı düzeltildi</p>";
        }
    }

    // Step 2: Create unified QR reader
    echo "<h3>📱 Birleştirilmiş QR Okuyucu</h3>";
    
    $unifiedQRContent = '<?php
require_once "../includes/config.php";
require_once "../includes/database.php";
require_once "../includes/qr-attendance-fixed.php";

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if employee is logged in
if (!isset($_SESSION["employee_id"])) {
    header("Location: ../auth/employee-login.php");
    exit;
}

$message = "";
$messageType = "";

// Handle QR code scanning
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $qrCode = trim($_POST["qr_code"] ?? "");
    
    if (!empty($qrCode)) {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Get employee info
            $employeeId = $_SESSION["employee_id"];
            $stmt = $conn->prepare("SELECT company_id, first_name, last_name FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$employee) {
                throw new Exception("Personel bilgisi bulunamadı");
            }
            
            $companyId = $employee["company_id"];
            
            // Parse QR code data
            $locationId = null;
            $qrData = json_decode($qrCode, true);
            
            if ($qrData && isset($qrData["location_id"])) {
                $locationId = intval($qrData["location_id"]);
            } elseif (is_numeric($qrCode)) {
                $locationId = intval($qrCode);
            } else {
                // Get first available location
                $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE is_active = 1 LIMIT 1");
                $stmt->execute();
                $defaultLocation = $stmt->fetch(PDO::FETCH_ASSOC);
                $locationId = $defaultLocation ? $defaultLocation["id"] : 1;
            }
            
            // Get location info
            $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE id = ? AND is_active = 1");
            $stmt->execute([$locationId]);
            $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$qrLocation) {
                throw new Exception("Geçersiz QR lokasyonu");
            }
            
            // Check today\s attendance status
            $today = date("Y-m-d");
            $stmt = $conn->prepare("
                SELECT *, 
                       CASE 
                           WHEN check_out IS NULL OR check_out = \"\" THEN \"active\"
                           ELSE \"completed\"
                       END as session_status
                FROM attendance_records 
                WHERE employee_id = ? AND DATE(created_at) = ?
                ORDER BY created_at DESC 
                LIMIT 1
            ");
            $stmt->execute([$employeeId, $today]);
            $currentRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Determine action based on current status
            $currentTime = date("Y-m-d H:i:s");
            $currentTimeOnly = date("H:i:s");
            
            if (!$currentRecord) {
                // First check-in of the day
                $activityType = "work_in";
                $actionMessage = "İşe giriş yapıldı";
                
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $employeeId,
                    $locationId,
                    $activityType,
                    $currentTimeOnly,
                    $qrLocation["latitude"] ?? null,
                    $qrLocation["longitude"] ?? null,
                    "QR kod ile giriş - " . $qrLocation["name"],
                    $currentTime
                ]);
                
            } elseif ($currentRecord["session_status"] === "active") {
                // Employee has an active session, do check-out
                $activityType = "work_out";
                $actionMessage = "İşten çıkış yapıldı";
                
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (employee_id, qr_location_id, activity_type, check_out_time, latitude, longitude, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $employeeId,
                    $locationId,
                    $activityType,
                    $currentTimeOnly,
                    $qrLocation["latitude"] ?? null,
                    $qrLocation["longitude"] ?? null,
                    "QR kod ile çıkış - " . $qrLocation["name"],
                    $currentTime
                ]);
                
                // Calculate work duration
                $workStart = strtotime($currentRecord["created_at"]);
                $workEnd = strtotime($currentTime);
                $workMinutes = ($workEnd - $workStart) / 60;
                $workHours = floor($workMinutes / 60);
                $workMins = $workMinutes % 60;
                $actionMessage .= " (Çalışma süresi: {$workHours}s {$workMins}dk)";
                
            } else {
                // Employee already checked out, this is a new check-in
                $activityType = "work_in";
                $actionMessage = "Yeniden işe giriş yapıldı";
                
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $employeeId,
                    $locationId,
                    $activityType,
                    $currentTimeOnly,
                    $qrLocation["latitude"] ?? null,
                    $qrLocation["longitude"] ?? null,
                    "QR kod ile yeniden giriş - " . $qrLocation["name"],
                    $currentTime
                ]);
            }
            
            $message = "✅ {$actionMessage}<br>📍 Lokasyon: {$qrLocation[\"name\"]}<br>🕒 Zaman: " . date("H:i");
            $messageType = "success";
            
        } catch (Exception $e) {
            $message = "❌ QR kod işleme hatası: " . $e->getMessage();
            $messageType = "error";
        }
    }
}

// Get today\s records for display
try {
    $stmt = $conn->prepare("
        SELECT ar.*, ql.name as location_name
        FROM attendance_records ar
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ? AND DATE(ar.created_at) = ?
        ORDER BY ar.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$_SESSION["employee_id"], date("Y-m-d")]);
    $todayRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $todayRecords = [];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Devam Takibi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/jsqr@1.4.0/dist/jsQR.js"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6 max-w-md">
        <!-- Header -->
        <div class="text-center mb-6">
            <h1 class="text-2xl font-bold text-gray-900">QR Devam Takibi</h1>
            <p class="text-gray-600 mt-2">QR kod okutarak giriş/çıkış yapın</p>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === \"success\" ? \"bg-green-100 text-green-800\" : \"bg-red-100 text-red-800\"; 
            ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <!-- Camera Scanner -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="font-semibold text-gray-900 mb-4">📷 QR Kod Okut</h3>
            
            <!-- Camera preview -->
            <div class="relative mb-4">
                <video id="video" class="w-full h-64 bg-black rounded-lg" style="display: none;"></video>
                <canvas id="canvas" style="display: none;"></canvas>
                
                <!-- Camera placeholder -->
                <div id="placeholder" class="w-full h-64 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-200">
                    <div class="text-center">
                        <div class="text-4xl mb-2">📷</div>
                        <p class="text-gray-600">Kamera başlatmak için tıklayın</p>
                    </div>
                </div>
            </div>

            <!-- Camera controls -->
            <div class="flex gap-3">
                <button id="startBtn" class="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700">
                    📷 Kamerayı Başlat
                </button>
                <button id="stopBtn" class="flex-1 bg-red-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-red-700" style="display: none;">
                    ⏹️ Durdur
                </button>
            </div>

            <!-- Status -->
            <div id="status" class="mt-4 text-center text-gray-600"></div>
        </div>

        <!-- Today\s Records -->
        <?php if (!empty($todayRecords)): ?>
            <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
                <h3 class="font-semibold text-gray-900 mb-4">📅 Bugünkü Kayıtlar</h3>
                <div class="space-y-3">
                    <?php foreach ($todayRecords as $record): ?>
                        <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                                <div class="font-medium">
                                    <?php 
                                    $activityNames = [
                                        \"work_in\" => \"🟢 Giriş\",
                                        \"work_out\" => \"🔴 Çıkış\",
                                        \"break_start\" => \"🟡 Mola Başlangıç\",
                                        \"break_end\" => \"🟢 Mola Bitiş\"
                                    ];
                                    echo $activityNames[$record[\"activity_type\"]] ?? $record[\"activity_type\"];
                                    ?>
                                </div>
                                <div class="text-sm text-gray-600">
                                    <?php echo $record[\"location_name\"] ?? \"Bilinmeyen lokasyon\"; ?>
                                </div>
                            </div>
                            <div class="text-sm text-gray-500">
                                <?php echo date(\"H:i\", strtotime($record[\"created_at\"])); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Hidden form -->
        <form method="POST" id="qrForm" style="display: none;">
            <input type="hidden" id="qrCode" name="qr_code">
        </form>

        <!-- Navigation -->
        <div class="text-center space-y-3">
            <a href="dashboard.php" class="block bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700">
                ← Dashboard\'a Dön
            </a>
        </div>
    </div>

    <script>
        let stream = null;
        let scanning = false;
        
        const video = document.getElementById(\"video\");
        const canvas = document.getElementById(\"canvas\");
        const ctx = canvas.getContext(\"2d\");
        const placeholder = document.getElementById(\"placeholder\");
        const startBtn = document.getElementById(\"startBtn\");
        const stopBtn = document.getElementById(\"stopBtn\");
        const status = document.getElementById(\"status\");
        
        // Start camera
        async function startCamera() {
            try {
                status.textContent = \"📷 Kamera başlatılıyor...\";
                
                stream = await navigator.mediaDevices.getUserMedia({
                    video: { facingMode: \"environment\" }
                });
                
                video.srcObject = stream;
                video.play();
                
                placeholder.style.display = \"none\";
                video.style.display = \"block\";
                startBtn.style.display = \"none\";
                stopBtn.style.display = \"block\";
                status.textContent = \"📷 QR kod aranıyor...\";
                
                video.onloadedmetadata = () => {
                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                    scanning = true;
                    scan();
                };
                
            } catch (err) {
                status.textContent = \"❌ Kamera erişimi başarısız: \" + err.message;
                console.error(\"Kamera hatası:\", err);
            }
        }
        
        // Stop camera
        function stopCamera() {
            scanning = false;
            
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            
            video.style.display = \"none\";
            placeholder.style.display = \"flex\";
            startBtn.style.display = \"block\";
            stopBtn.style.display = \"none\";
            status.textContent = \"\";
        }
        
        // Scan for QR codes
        function scan() {
            if (!scanning || !video.videoWidth) {
                if (scanning) requestAnimationFrame(scan);
                return;
            }
            
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height);
            
            if (code) {
                console.log(\"QR kod bulundu:\", code.data);
                document.getElementById(\"qrCode\").value = code.data;
                document.getElementById(\"qrForm\").submit();
                return;
            }
            
            if (scanning) {
                requestAnimationFrame(scan);
            }
        }
        
        // Event listeners
        startBtn.addEventListener(\"click\", startCamera);
        stopBtn.addEventListener(\"click\", stopCamera);
        placeholder.addEventListener(\"click\", startCamera);
    </script>
</body>
</html>';

    // Write the unified QR reader
    if (file_put_contents('../employee/qr-unified.php', $unifiedQRContent)) {
        echo "<p>✅ Birleştirilmiş QR okuyucu oluşturuldu: employee/qr-unified.php</p>";
    }

    // Step 3: Update navigation links
    echo "<h3>🔗 Navigasyon Güncellemeleri</h3>";
    
    $filesToUpdate = [
        '../employee/dashboard.php',
        '../employee/attendance-summary.php',
        '../employee/attendance-tracking.php',
        '../employee/attendance-records.php'
    ];
    
    foreach ($filesToUpdate as $file) {
        if (file_exists($file)) {
            $content = file_get_contents($file);
            
            // Replace old QR links with new unified link
            $content = str_replace(
                'href="../qr/qr-reader.php"',
                'href="qr-unified.php"',
                $content
            );
            $content = str_replace(
                'href="qr-attendance.php"',
                'href="qr-unified.php"',
                $content
            );
            
            if (file_put_contents($file, $content)) {
                echo "<p>✅ " . basename($file) . " güncellerek unified QR'a yönlendirildi</p>";
            }
        }
    }

    // Step 4: Check and fix attendance_records table
    echo "<h3>🗄️ Veritabanı Standardizasyonu</h3>";
    
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredColumns = [
        'employee_id' => 'INT(11) NOT NULL',
        'qr_location_id' => 'INT(11) NULL',
        'activity_type' => 'VARCHAR(50) NOT NULL',
        'check_in_time' => 'TIME NULL',
        'check_out_time' => 'TIME NULL',
        'latitude' => 'DECIMAL(10,8) NULL',
        'longitude' => 'DECIMAL(11,8) NULL',
        'notes' => 'TEXT NULL',
        'created_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'
    ];
    
    $missingColumns = [];
    foreach ($requiredColumns as $colName => $colDef) {
        if (!in_array($colName, $columns)) {
            $missingColumns[] = $colName;
        }
    }
    
    if (!empty($missingColumns)) {
        echo "<p>⚠️ Eksik sütunlar tespit edildi: " . implode(', ', $missingColumns) . "</p>";
        
        foreach ($missingColumns as $col) {
            try {
                $colDef = $requiredColumns[$col];
                $stmt = $conn->exec("ALTER TABLE attendance_records ADD COLUMN $col $colDef");
                echo "<p>✅ $col sütunu eklendi</p>";
            } catch (Exception $e) {
                echo "<p>❌ $col sütunu eklenemedi: " . $e->getMessage() . "</p>";
            }
        }
    } else {
        echo "<p>✅ Tüm gerekli sütunlar mevcut</p>";
    }

    // Final summary
    echo "<h3>📊 Düzeltme Özeti</h3>";
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>🎉 QR Sistem Düzeltmeleri Tamamlandı!</h2>";
    echo "<ul style='text-align: left; margin: 20px 0;'>";
    echo "<li>✅ Session standardizasyonu yapıldı (employee_id)</li>";
    echo "<li>✅ Birleştirilmiş QR okuyucu oluşturuldu</li>";
    echo "<li>✅ Navigasyon bağlantıları güncellendi</li>";
    echo "<li>✅ Veritabanı sütunları kontrol edildi</li>";
    echo "</ul>";
    echo "<p><strong>Artık tek 'QR Kod Okut' sistemi kullanın:</strong></p>";
    echo "<p><code>employee/qr-unified.php</code></p>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ Düzeltme Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>