<?php
// Test attendance table schema for QR debugging
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/qr-attendance-fixed.php';

// Super admin check
if (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1) {
    die('Bu sayfa sadece Super Admin tarafından erişilebilir.');
}

$db = new Database();
$conn = $db->getConnection();

echo "<h2>🔍 Attendance Table Schema Debug</h2>";

// Show attendance_records table structure
echo "<h3>📋 Attendance Records Table Structure:</h3>";
try {
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>{$column['Field']}</td>";
        echo "<td>{$column['Type']}</td>";
        echo "<td>{$column['Null']}</td>";
        echo "<td>{$column['Key']}</td>";
        echo "<td>{$column['Default']}</td>";
        echo "<td>{$column['Extra']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    $columnNames = array_column($columns, 'Field');
    echo "<p><strong>Available columns:</strong> " . implode(', ', $columnNames) . "</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

// Test QRAttendanceHelper column mapping
echo "<h3>🔧 QRAttendanceHelper Column Mapping:</h3>";
try {
    $colMap = QRAttendanceHelper::getColumnMapping($conn);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Purpose</th><th>Mapped Column</th></tr>";
    foreach ($colMap as $purpose => $column) {
        echo "<tr><td>$purpose</td><td>$column</td></tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Column mapping error: " . $e->getMessage() . "</p>";
}

// Test sample attendance query
echo "<h3>📊 Sample Attendance Query Test:</h3>";
try {
    $sampleEmployeeId = 1; // Use a sample employee ID
    $today = date('Y-m-d');
    
    $colMap = QRAttendanceHelper::getColumnMapping($conn);
    
    if ($colMap['date'] === 'created_at') {
        $sql = "SELECT 
                    {$colMap['check_in']} as check_in, 
                    {$colMap['check_out']} as check_out, 
                    {$colMap['break_start']} as break_start, 
                    {$colMap['break_end']} as break_end 
                FROM attendance_records 
                WHERE employee_id = ? AND DATE(created_at) = ?
                ORDER BY id DESC
                LIMIT 1";
    } else {
        $sql = "SELECT 
                    {$colMap['check_in']} as check_in, 
                    {$colMap['check_out']} as check_out, 
                    {$colMap['break_start']} as break_start, 
                    {$colMap['break_end']} as break_end 
                FROM attendance_records 
                WHERE employee_id = ? AND {$colMap['date']} = ?
                ORDER BY id DESC
                LIMIT 1";
    }
    
    echo "<p><strong>Generated SQL:</strong><br><code>$sql</code></p>";
    echo "<p><strong>Parameters:</strong> employee_id=$sampleEmployeeId, date=$today</p>";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([$sampleEmployeeId, $today]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        echo "<p>✅ Query successful! Found record:</p>";
        echo "<pre>" . print_r($result, true) . "</pre>";
    } else {
        echo "<p>✅ Query successful! No records found for today.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Query error: " . $e->getMessage() . "</p>";
    echo "<p>This indicates the schema issue that needs to be fixed.</p>";
}

// Test QR gate action determination
echo "<h3>🚪 QR Gate Action Test:</h3>";
try {
    $testEmployeeId = 1;
    $testCompanyId = 4; // SZB company
    $testLocationId = 1;
    $testGateBehavior = 'work_start';
    
    $action = QRAttendanceHelper::determineGateAction($conn, $testEmployeeId, $testCompanyId, $testLocationId, $testGateBehavior);
    
    echo "<p>✅ Gate action determination successful:</p>";
    echo "<pre>" . print_r($action, true) . "</pre>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Gate action error: " . $e->getMessage() . "</p>";
}

// Show recent attendance records
echo "<h3>📝 Recent Attendance Records (Last 5):</h3>";
try {
    $stmt = $conn->query("SELECT * FROM attendance_records ORDER BY id DESC LIMIT 5");
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($records) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
        echo "<tr>";
        foreach (array_keys($records[0]) as $key) {
            echo "<th>$key</th>";
        }
        echo "</tr>";
        
        foreach ($records as $record) {
            echo "<tr>";
            foreach ($record as $value) {
                echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No attendance records found.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Records error: " . $e->getMessage() . "</p>";
}

echo "<br><a href='../super-admin/index.php' style='padding: 10px 20px; background: #007cba; color: white; text-decoration: none; border-radius: 5px;'>← Super Admin Panel</a>";
?>