<?php
require_once '../includes/config.php';

echo "<h2>🇹🇷 Türkçe Dil Düzeltme Aracı</h2>";

// İngilizce - Türkçe çeviri tablosu
$translations = [
    // API Messages
    'Missing required fields' => 'Gerekli alanlar eksik',
    'Unauthorized' => 'Yetkisiz erişim',
    'User not found' => 'Kullanıcı bulunamadı',
    'Login successful' => 'Giriş başarılı',
    'Logged out' => 'Çıkış yapıldı',
    'Endpoint not found' => 'Hizmet bulunamadı',
    'Invalid credentials' => 'Geçersiz kimlik bilgileri',
    'Password required' => 'Şifre gerekli',
    'Email required' => 'E-posta gerekli',
    'Company code required' => 'Şirket kodu gerekli',
    'Success' => 'Başarılı',
    'Failed' => 'Başarısız',
    'Error' => 'Hata',
    'Warning' => 'Uyarı',
    'Information' => 'Bilgi',
    
    // Form Labels
    'Email' => 'E-posta',
    'Password' => 'Şifre',
    'Login' => 'Giriş',
    'Logout' => 'Çıkış',
    'Company Code' => 'Şirket Kodu',
    'Employee ID' => 'Personel ID',
    'First Name' => 'Ad',
    'Last Name' => 'Soyad',
    'Phone' => 'Telefon',
    'Address' => 'Adres',
    'Department' => 'Departman',
    'Position' => 'Pozisyon',
    'Start Date' => 'Başlangıç Tarihi',
    'End Date' => 'Bitiş Tarihi',
    'Status' => 'Durum',
    'Active' => 'Aktif',
    'Inactive' => 'Pasif',
    'Submit' => 'Gönder',
    'Cancel' => 'İptal',
    'Save' => 'Kaydet',
    'Delete' => 'Sil',
    'Edit' => 'Düzenle',
    'Add' => 'Ekle',
    'Update' => 'Güncelle',
    'Search' => 'Ara',
    'Filter' => 'Filtrele',
    'Reset' => 'Sıfırla',
    'Back' => 'Geri',
    'Next' => 'İleri',
    'Previous' => 'Önceki',
    'Close' => 'Kapat',
    'Open' => 'Aç',
    'View' => 'Görüntüle',
    'Print' => 'Yazdır',
    'Export' => 'Dışa Aktar',
    'Import' => 'İçe Aktar',
    
    // QR System
    'QR Code' => 'QR Kod',
    'Scan QR Code' => 'QR Kod Tara',
    'QR Reader' => 'QR Kod Okuyucu',
    'Camera' => 'Kamera',
    'Location' => 'Konum',
    'Coordinates' => 'Koordinatlar',
    'Latitude' => 'Enlem',
    'Longitude' => 'Boylam',
    'Tolerance' => 'Tolerans',
    'Distance' => 'Mesafe',
    'GPS' => 'GPS',
    
    // Attendance System
    'Attendance' => 'Devam',
    'Check In' => 'Giriş',
    'Check Out' => 'Çıkış',
    'Break Start' => 'Mola Başlangıcı',
    'Break End' => 'Mola Bitişi',
    'Work Hours' => 'Çalışma Saatleri',
    'Overtime' => 'Mesai',
    'Late' => 'Geç',
    'Early' => 'Erken',
    'Absent' => 'Gelmedi',
    'Present' => 'Geldi',
    'Holiday' => 'Tatil',
    'Leave' => 'İzin',
    'Sick Leave' => 'Hastalık İzni',
    'Annual Leave' => 'Yıllık İzin',
    'Shift' => 'Vardiya',
    'Schedule' => 'Program',
    'Report' => 'Rapor',
    'Summary' => 'Özet',
    'Details' => 'Detaylar',
    'Records' => 'Kayıtlar',
    'History' => 'Geçmiş',
    'Daily' => 'Günlük',
    'Weekly' => 'Haftalık',
    'Monthly' => 'Aylık',
    'Yearly' => 'Yıllık',
    
    // Device Management
    'Device' => 'Cihaz',
    'Device Records' => 'Cihaz Kayıtları',
    'Device Management' => 'Cihaz Yönetimi',
    'Trusted' => 'Güvenilir',
    'Blocked' => 'Engellenmiş',
    'Unknown Device' => 'Bilinmeyen Cihaz',
    'Fingerprint' => 'Parmak İzi',
    'Browser' => 'Tarayıcı',
    'Platform' => 'Platform',
    'IP Address' => 'IP Adresi',
    'User Agent' => 'Kullanıcı Aracısı',
    'Last Seen' => 'Son Görülme',
    'Security' => 'Güvenlik',
    
    // System Messages
    'Database connection failed' => 'Veritabanı bağlantısı başarısız',
    'Table not found' => 'Tablo bulunamadı',
    'Column not found' => 'Sütun bulunamadı',
    'Record not found' => 'Kayıt bulunamadı',
    'Permission denied' => 'İzin reddedildi',
    'Access denied' => 'Erişim reddedildi',
    'Session expired' => 'Oturum süresi doldu',
    'Invalid request' => 'Geçersiz istek',
    'Operation successful' => 'İşlem başarılı',
    'Operation failed' => 'İşlem başarısız',
    'Data saved successfully' => 'Veri başarıyla kaydedildi',
    'Data deleted successfully' => 'Veri başarıyla silindi',
    'Data updated successfully' => 'Veri başarıyla güncellendi',
    'Validation error' => 'Doğrulama hatası',
    'Required field' => 'Zorunlu alan',
    'Optional field' => 'İsteğe bağlı alan',
    'Invalid format' => 'Geçersiz format',
    'File upload failed' => 'Dosya yüklemesi başarısız',
    'File not found' => 'Dosya bulunamadı',
    'Configuration error' => 'Yapılandırma hatası',
    
    // Technical Terms
    'System' => 'Sistem',
    'Database' => 'Veritabanı',
    'Server' => 'Sunucu',
    'Client' => 'İstemci',
    'Request' => 'İstek',
    'Response' => 'Yanıt',
    'Connection' => 'Bağlantı',
    'Query' => 'Sorgu',
    'Result' => 'Sonuç',
    'Configuration' => 'Yapılandırma',
    'Settings' => 'Ayarlar',
    'Options' => 'Seçenekler',
    'Parameters' => 'Parametreler',
    'Function' => 'Fonksiyon',
    'Method' => 'Metod',
    'Class' => 'Sınıf',
    'Object' => 'Nesne',
    'Variable' => 'Değişken',
    'Constant' => 'Sabit',
    'Array' => 'Dizi',
    'String' => 'Metin',
    'Integer' => 'Tam Sayı',
    'Boolean' => 'Mantıksal',
    'Date' => 'Tarih',
    'Time' => 'Saat',
    'Timestamp' => 'Zaman Damgası',
    'ID' => 'Kimlik',
    'URL' => 'Adres',
    'Link' => 'Bağlantı',
    'Page' => 'Sayfa',
    'Form' => 'Form',
    'Field' => 'Alan',
    'Input' => 'Giriş',
    'Output' => 'Çıkış',
    'Content' => 'İçerik',
    'Text' => 'Metin',
    'Message' => 'Mesaj',
    'Alert' => 'Uyarı',
    'Notification' => 'Bildirim',
    'Modal' => 'Modal',
    'Dialog' => 'Diyalog',
    'Window' => 'Pencere',
    'Tab' => 'Sekme',
    'Menu' => 'Menü',
    'Button' => 'Buton',
    'Link' => 'Bağlantı',
    'Image' => 'Resim',
    'File' => 'Dosya',
    'Folder' => 'Klasör',
    'Directory' => 'Dizin',
    'Path' => 'Yol',
    'Size' => 'Boyut',
    'Type' => 'Tip',
    'Format' => 'Format',
    'Extension' => 'Uzantı',
    'Version' => 'Sürüm',
    'Build' => 'Yapı',
    'Release' => 'Sürüm',
    'Update' => 'Güncelleme',
    'Upgrade' => 'Yükseltme',
    'Download' => 'İndir',
    'Upload' => 'Yükle',
    'Install' => 'Kur',
    'Uninstall' => 'Kaldır',
    'Enable' => 'Etkinleştir',
    'Disable' => 'Devre Dışı Bırak',
    'Start' => 'Başla',
    'Stop' => 'Dur',
    'Pause' => 'Duraklat',
    'Resume' => 'Devam Et',
    'Restart' => 'Yeniden Başlat',
    'Refresh' => 'Yenile',
    'Reload' => 'Yeniden Yükle',
    'Clear' => 'Temizle',
    'Empty' => 'Boş',
    'Full' => 'Dolu',
    'Available' => 'Mevcut',
    'Unavailable' => 'Mevcut Değil',
    'Online' => 'Çevrimiçi',
    'Offline' => 'Çevrimdışı',
    'Connected' => 'Bağlı',
    'Disconnected' => 'Bağlı Değil',
    'Loading' => 'Yükleniyor',
    'Processing' => 'İşleniyor',
    'Completed' => 'Tamamlandı',
    'Pending' => 'Beklemede',
    'Progress' => 'İlerleme',
    'Percentage' => 'Yüzde',
    'Count' => 'Sayım',
    'Total' => 'Toplam',
    'Maximum' => 'Maksimum',
    'Minimum' => 'Minimum',
    'Average' => 'Ortalama',
    'Sum' => 'Toplam',
    'Calculate' => 'Hesapla',
    'Generate' => 'Oluştur',
    'Create' => 'Oluştur',
    'Build' => 'İnşa Et',
    'Develop' => 'Geliştir',
    'Design' => 'Tasarla',
    'Test' => 'Test',
    'Debug' => 'Hata Ayıkla',
    'Fix' => 'Düzelt',
    'Repair' => 'Onar',
    'Optimize' => 'Optimize Et',
    'Improve' => 'Geliştir',
    'Enhance' => 'İyileştir',
    'Customize' => 'Özelleştir',
    'Configure' => 'Yapılandır',
    'Setup' => 'Kurulum',
    'Initialize' => 'Başlat',
    'Validate' => 'Doğrula',
    'Verify' => 'Doğrula',
    'Confirm' => 'Onayla',
    'Approve' => 'Onayla',
    'Reject' => 'Reddet',
    'Accept' => 'Kabul Et',
    'Decline' => 'Reddet',
    'Allow' => 'İzin Ver',
    'Block' => 'Engelle',
    'Grant' => 'Ver',
    'Revoke' => 'Geri Al',
    'Assign' => 'Ata',
    'Unassign' => 'Atamayı Geri Al',
    'Move' => 'Taşı',
    'Copy' => 'Kopyala',
    'Cut' => 'Kes',
    'Paste' => 'Yapıştır',
    'Duplicate' => 'Çoğalt',
    'Clone' => 'Klonla',
    'Merge' => 'Birleştir',
    'Split' => 'Böl',
    'Join' => 'Birleştir',
    'Separate' => 'Ayır',
    'Group' => 'Grupla',
    'Ungroup' => 'Grup Dağıt',
    'Sort' => 'Sırala',
    'Order' => 'Sipariş',
    'Rank' => 'Sırala',
    'Priority' => 'Öncelik',
    'Important' => 'Önemli',
    'Critical' => 'Kritik',
    'Normal' => 'Normal',
    'Low' => 'Düşük',
    'High' => 'Yüksek',
    'Medium' => 'Orta',
    'None' => 'Hiçbiri',
    'All' => 'Tümü',
    'Any' => 'Herhangi',
    'Some' => 'Bazı',
    'Few' => 'Az',
    'Many' => 'Çok',
    'Most' => 'Çoğu',
    'Every' => 'Her',
    'Each' => 'Her Bir',
    'Other' => 'Diğer',
    'Another' => 'Başka',
    'Same' => 'Aynı',
    'Different' => 'Farklı',
    'Similar' => 'Benzer',
    'Equal' => 'Eşit',
    'Not Equal' => 'Eşit Değil',
    'Greater Than' => 'Büyük',
    'Less Than' => 'Küçük',
    'Greater Than or Equal' => 'Büyük Eşit',
    'Less Than or Equal' => 'Küçük Eşit',
    'Between' => 'Arasında',
    'Outside' => 'Dışında',
    'Inside' => 'İçinde',
    'Contains' => 'İçerir',
    'Does Not Contain' => 'İçermez',
    'Starts With' => 'İle Başlar',
    'Ends With' => 'İle Biter',
    'Matches' => 'Eşleşir',
    'Does Not Match' => 'Eşleşmez',
    'Is Empty' => 'Boş',
    'Is Not Empty' => 'Boş Değil',
    'Is Null' => 'Null',
    'Is Not Null' => 'Null Değil',
    'True' => 'Doğru',
    'False' => 'Yanlış',
    'Yes' => 'Evet',
    'No' => 'Hayır',
    'OK' => 'Tamam',
    'Cancel' => 'İptal',
    'Continue' => 'Devam',
    'Finish' => 'Bitir',
    'Done' => 'Bitti',
    'Complete' => 'Tamamla',
    'Incomplete' => 'Tamamlanmamış',
    'Ready' => 'Hazır',
    'Not Ready' => 'Hazır Değil',
    'Valid' => 'Geçerli',
    'Invalid' => 'Geçersiz',
    'Correct' => 'Doğru',
    'Incorrect' => 'Yanlış',
    'Right' => 'Sağ',
    'Wrong' => 'Yanlış',
    'Left' => 'Sol',
    'Top' => 'Üst',
    'Bottom' => 'Alt',
    'Center' => 'Merkez',
    'Middle' => 'Orta',
    'Side' => 'Yan',
    'Corner' => 'Köşe',
    'Edge' => 'Kenar',
    'Border' => 'Sınır',
    'Margin' => 'Kenar Boşluğu',
    'Padding' => 'İç Boşluk',
    'Width' => 'Genişlik',
    'Height' => 'Yükseklik',
    'Length' => 'Uzunluk',
    'Depth' => 'Derinlik',
    'Thickness' => 'Kalınlık',
    'Weight' => 'Ağırlık',
    'Mass' => 'Kütle',
    'Volume' => 'Hacim',
    'Area' => 'Alan',
    'Perimeter' => 'Çevre',
    'Radius' => 'Yarıçap',
    'Diameter' => 'Çap',
    'Angle' => 'Açı',
    'Degree' => 'Derece',
    'Radian' => 'Radyan',
    'Coordinate' => 'Koordinat',
    'Position' => 'Konum',
    'Location' => 'Lokasyon',
    'Place' => 'Yer',
    'Destination' => 'Hedef',
    'Source' => 'Kaynak',
    'Origin' => 'Başlangıç',
    'Target' => 'Hedef',
    'Goal' => 'Amaç',
    'Objective' => 'Hedef',
    'Purpose' => 'Amaç',
    'Reason' => 'Sebep',
    'Cause' => 'Neden',
    'Effect' => 'Etki',
    'Result' => 'Sonuç',
    'Outcome' => 'Çıktı',
    'Output' => 'Çıktı',
    'Input' => 'Girdi',
    'Data' => 'Veri',
    'Information' => 'Bilgi',
    'Knowledge' => 'Bilgi',
    'Detail' => 'Detay',
    'Specification' => 'Özellik',
    'Description' => 'Açıklama',
    'Explanation' => 'Açıklama',
    'Definition' => 'Tanım',
    'Meaning' => 'Anlam',
    'Sense' => 'Anlam',
    'Context' => 'Bağlam',
    'Background' => 'Arkaplan',
    'Foreground' => 'Önplan',
    'Front' => 'Ön',
    'Back' => 'Arka',
    'Forward' => 'İleri',
    'Backward' => 'Geri',
    'Up' => 'Yukarı',
    'Down' => 'Aşağı',
    'Over' => 'Üzerinde',
    'Under' => 'Altında',
    'Above' => 'Yukarısında',
    'Below' => 'Aşağısında',
    'Before' => 'Önce',
    'After' => 'Sonra',
    'During' => 'Sırasında',
    'While' => 'İken',
    'When' => 'Ne Zaman',
    'Where' => 'Nerede',
    'What' => 'Ne',
    'Who' => 'Kim',
    'Why' => 'Neden',
    'How' => 'Nasıl',
    'Which' => 'Hangi',
    'Whose' => 'Kimin',
    'Whom' => 'Kimi',
    'Whatever' => 'Her Ne',
    'Wherever' => 'Her Nerede',
    'Whenever' => 'Her Ne Zaman',
    'However' => 'Ancak',
    'Therefore' => 'Bu Nedenle',
    'Because' => 'Çünkü',
    'Since' => 'Dan Beri',
    'Until' => 'Kadar',
    'Unless' => 'Olmadıkça',
    'If' => 'Eğer',
    'Else' => 'Aksi Takdirde',
    'Then' => 'O Zaman',
    'Now' => 'Şimdi',
    'Today' => 'Bugün',
    'Tomorrow' => 'Yarın',
    'Yesterday' => 'Dün',
    'Week' => 'Hafta',
    'Month' => 'Ay',
    'Year' => 'Yıl',
    'Day' => 'Gün',
    'Hour' => 'Saat',
    'Minute' => 'Dakika',
    'Second' => 'Saniye',
    'Millisecond' => 'Milisaniye',
    'Microsecond' => 'Mikrosaniye',
    'Nanosecond' => 'Nanosaniye',
    'Century' => 'Yüzyıl',
    'Decade' => 'On Yıl',
    'Semester' => 'Dönem',
    'Quarter' => 'Çeyrek',
    'Season' => 'Mevsim',
    'Spring' => 'İlkbahar',
    'Summer' => 'Yaz',
    'Autumn' => 'Sonbahar',
    'Winter' => 'Kış',
    'Monday' => 'Pazartesi',
    'Tuesday' => 'Salı',
    'Wednesday' => 'Çarşamba',
    'Thursday' => 'Perşembe',
    'Friday' => 'Cuma',
    'Saturday' => 'Cumartesi',
    'Sunday' => 'Pazar',
    'January' => 'Ocak',
    'February' => 'Şubat',
    'March' => 'Mart',
    'April' => 'Nisan',
    'May' => 'Mayıs',
    'June' => 'Haziran',
    'July' => 'Temmuz',
    'August' => 'Ağustos',
    'September' => 'Eylül',
    'October' => 'Ekim',
    'November' => 'Kasım',
    'December' => 'Aralık'
];

echo "<h3>📋 Çeviri Tablosu Hazırlandı</h3>";
echo "<p><strong>Toplam çeviri sayısı:</strong> " . count($translations) . "</p>";

// En kritik dosyaları seç
$criticalFiles = [
    '../api/auth.php',
    '../api/qr-locations.php',
    '../auth/employee-login.php',
    '../auth/company-login.php',
    '../qr/qr-reader.php',
    '../qr/activity-selection.php',
    '../admin/employee-management.php',
    '../admin/shift-management.php',
    '../employee/attendance-summary.php',
    '../employee/dashboard.php'
];

echo "<h3>🔧 Kritik Dosyalar Düzeltiliyor</h3>";

$fixedFiles = 0;
$totalChanges = 0;

foreach ($criticalFiles as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        $originalContent = $content;
        $fileChanges = 0;
        
        echo "<h4>📝 " . basename($file) . "</h4>";
        
        // Her çeviri için dosyayı kontrol et
        foreach ($translations as $english => $turkish) {
            // Farklı formatları kontrol et
            $patterns = [
                "/'{$english}'/", // Single quotes
                "/\"{$english}\"/", // Double quotes
                "/>{$english}</", // HTML content
                "/echo\s+['\"]?{$english}['\"]?/", // Echo statements
                "/alert\s*\(\s*['\"]?{$english}['\"]?\s*\)/" // JavaScript alerts
            ];
            
            foreach ($patterns as $pattern) {
                $escapedEnglish = preg_quote($english, '/');
                $actualPattern = str_replace($english, $escapedEnglish, $pattern);
                
                if (preg_match($actualPattern, $content)) {
                    $replacement = str_replace($english, $turkish, $pattern);
                    $replacement = str_replace("/{$escapedEnglish}/", "/{$turkish}/", $replacement);
                    
                    $newContent = preg_replace($actualPattern, $replacement, $content);
                    if ($newContent !== $content) {
                        $content = $newContent;
                        $fileChanges++;
                        echo "<span style='color: green; font-size: 12px;'>✓ '{$english}' → '{$turkish}'</span><br>";
                    }
                }
            }
        }
        
        // Dosyayı kaydet
        if ($content !== $originalContent) {
            if (file_put_contents($file, $content)) {
                $fixedFiles++;
                $totalChanges += $fileChanges;
                echo "<p style='color: green;'>✅ {$fileChanges} değişiklik yapıldı ve kaydedildi</p>";
            } else {
                echo "<p style='color: red;'>❌ Dosya kaydedilemedi</p>";
            }
        } else {
            echo "<p style='color: blue;'>ℹ️ Değişiklik gerekmedi</p>";
        }
    } else {
        echo "<h4>📝 " . basename($file) . "</h4>";
        echo "<p style='color: orange;'>⚠️ Dosya bulunamadı</p>";
    }
}

echo "<h3>📊 Düzeltme Özeti</h3>";
echo "<div style='background: #e9ecef; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<ul>";
echo "<li><strong>Düzeltilen dosya sayısı:</strong> {$fixedFiles}</li>";
echo "<li><strong>Toplam değişiklik sayısı:</strong> {$totalChanges}</li>";
echo "<li><strong>Çeviri sözlüğü boyutu:</strong> " . count($translations) . " kelime</li>";
echo "</ul>";
echo "</div>";

if ($totalChanges > 0) {
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>🇹🇷 Türkçe Dil Düzeltmeleri Tamamlandı!</h2>";
    echo "<p>Sistem artık tamamen Türkçe arayüze sahip.</p>";
    echo "</div>";
}

// Manuel düzeltme gerekebilecek dosyalar için rapor
echo "<h3>🔍 Manuel Kontrol Önerileri</h3>";
echo "<ol>";
echo "<li><strong>JavaScript dosyaları:</strong> alert() ve console.log() mesajları</li>";
echo "<li><strong>CSS yorumları:</strong> İngilizce açıklamalar</li>";
echo "<li><strong>HTML title ve meta:</strong> Sayfa başlıkları</li>";
echo "<li><strong>Database içeriği:</strong> Tablo ve sütun açıklamaları</li>";
echo "<li><strong>Log mesajları:</strong> error_log() ve debug çıktıları</li>";
echo "</ol>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>