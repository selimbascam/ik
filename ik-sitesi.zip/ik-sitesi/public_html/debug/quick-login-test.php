<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=utf-8');

// Test the exact login process
$testEmail = 'zeynep@szb.com.tr';
$testPassword = 'Abc123456';

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Quick Login Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { background: #d1fae5; color: #065f46; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { background: #dbeafe; color: #1e40af; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { background: #fef3c7; color: #92400e; padding: 10px; border-radius: 5px; margin: 10px 0; }
        pre { background: #f3f4f6; padding: 10px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>🔍 Quick Login Test</h1>
    
    <?php
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        echo "<div class='info'>Testing credentials:<br>";
        echo "<strong>Email:</strong> " . htmlspecialchars($testEmail) . "<br>";
        echo "<strong>Password:</strong> " . htmlspecialchars($testPassword) . "</div>";
        
        // Check companies table structure
        $stmt = $conn->query("SHOW COLUMNS FROM companies");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "<div class='info'><strong>Companies table columns:</strong><br>";
        echo implode(', ', $columns) . "</div>";
        
        // Check if email exists
        $emailCol = in_array('admin_email', $columns) ? 'admin_email' : 'email';
        $stmt = $conn->prepare("SELECT * FROM companies WHERE $emailCol = ?");
        $stmt->execute([$testEmail]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$company) {
            echo "<div class='error'>❌ No company found with email: $testEmail</div>";
            
            // Show all companies
            $stmt = $conn->query("SELECT id, company_name, $emailCol as email FROM companies LIMIT 5");
            $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo "<div class='warning'><strong>Available companies:</strong><br>";
            foreach ($companies as $comp) {
                echo "ID: {$comp['id']}, Name: {$comp['company_name']}, Email: {$comp['email']}<br>";
            }
            echo "</div>";
        } else {
            echo "<div class='success'>✅ Company found!</div>";
            echo "<pre>" . print_r($company, true) . "</pre>";
            
            // Test password authentication
            if (!isset($company['password']) || empty($company['password'])) {
                echo "<div class='warning'>⚠️ Password column is empty or null</div>";
                
                // Try to set a default password
                $stmt = $conn->prepare("UPDATE companies SET password = MD5(?) WHERE id = ?");
                $stmt->execute([$testPassword, $company['id']]);
                echo "<div class='info'>🔧 Set password to MD5 hash</div>";
            }
            
            // Test MD5 authentication
            $stmt = $conn->prepare("SELECT * FROM companies WHERE $emailCol = ? AND password = MD5(?)");
            $stmt->execute([$testEmail, $testPassword]);
            $authResult = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($authResult) {
                echo "<div class='success'>✅ MD5 Authentication successful!</div>";
            } else {
                echo "<div class='error'>❌ MD5 Authentication failed</div>";
                
                // Try plain text
                $stmt = $conn->prepare("SELECT * FROM companies WHERE $emailCol = ? AND password = ?");
                $stmt->execute([$testEmail, $testPassword]);
                $plainResult = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($plainResult) {
                    echo "<div class='success'>✅ Plain text authentication successful!</div>";
                } else {
                    echo "<div class='error'>❌ Plain text authentication failed</div>";
                    echo "<div class='info'>Current password hash: " . htmlspecialchars($company['password'] ?? 'NULL') . "</div>";
                }
            }
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
    ?>
    
    <div style="margin-top: 20px;">
        <a href="../auth/company-login.php" style="background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🔙 Back to Login</a>
        <a href="../debug/test-company-login-credentials.php" style="background: #6b7280; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🔧 Full Debug</a>
    </div>
</body>
</html>