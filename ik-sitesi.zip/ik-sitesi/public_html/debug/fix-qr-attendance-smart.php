<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🤖 Akıllı QR Devam Takibi Test Aracı</h2>";
    
    if ($_POST['action'] ?? '' === 'test_smart_system') {
        echo "<h3>✅ Akıllı Sistem Testi</h3>";
        
        $employeeId = (int)($_POST['employee_id'] ?? 0);
        $companyId = (int)($_POST['company_id'] ?? 0);
        
        if ($employeeId && $companyId) {
            // Get today's shift for this employee
            $today = date('Y-m-d');
            $stmt = $conn->prepare("
                SELECT 
                    es.*,
                    st.name as shift_name,
                    st.start_time,
                    st.end_time,
                    st.break_duration,
                    e.first_name,
                    e.last_name
                FROM employee_shifts es
                JOIN shift_templates st ON es.shift_template_id = st.id
                JOIN employees e ON es.employee_id = e.id
                WHERE es.employee_id = ? AND es.shift_date = ? AND e.company_id = ?
            ");
            $stmt->execute([$employeeId, $today, $companyId]);
            $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($todayShift) {
                echo "<h4>📋 Personel ve Vardiya Bilgileri</h4>";
                echo "<p><strong>Personel:</strong> " . htmlspecialchars($todayShift['first_name'] . ' ' . $todayShift['last_name']) . "</p>";
                echo "<p><strong>Vardiya:</strong> " . htmlspecialchars($todayShift['shift_name']) . "</p>";
                echo "<p><strong>Saatler:</strong> " . $todayShift['start_time'] . " - " . $todayShift['end_time'] . "</p>";
                echo "<p><strong>Mola:</strong> " . $todayShift['break_duration'] . " dakika</p>";
                
                // Get current attendance records
                $stmt = $conn->prepare("
                    SELECT 
                        activity_type,
                        check_in_time,
                        created_at,
                        notes
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = ? 
                    ORDER BY created_at ASC
                ");
                $stmt->execute([$employeeId, $today]);
                $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo "<h4>📊 Bugünkü Kayıtlar</h4>";
                if (empty($records)) {
                    echo "<p>Henüz kayıt yok.</p>";
                } else {
                    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
                    echo "<tr><th>Saat</th><th>Aktivite</th><th>Notlar</th></tr>";
                    foreach ($records as $record) {
                        $activityNames = [
                            'work_in' => '🟢 İşe Giriş',
                            'work_out' => '🔴 İşten Çıkış',
                            'break_start' => '🟡 Mola Başlangıcı',
                            'break_end' => '🟢 Mola Bitişi'
                        ];
                        echo "<tr>";
                        echo "<td>" . date('H:i:s', strtotime($record['created_at'])) . "</td>";
                        echo "<td>" . ($activityNames[$record['activity_type']] ?? $record['activity_type']) . "</td>";
                        echo "<td>" . htmlspecialchars($record['notes'] ?? '') . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                }
                
                // Test smart detection for different times
                echo "<h4>🤖 Akıllı Tespit Simülasyonu</h4>";
                $testTimes = [
                    '08:45' => 'Vardiya başlangıcından 15 dk önce',
                    '09:00' => 'Vardiya başlangıcı',
                    '09:20' => 'Vardiya başlangıcından 20 dk sonra (geç)',
                    '12:30' => 'Öğle molası zamanı',
                    '13:00' => 'Mola dönüşü',
                    '17:45' => 'Vardiya bitişinden 15 dk önce',
                    '18:00' => 'Vardiya bitiş saati',
                    '18:30' => 'Vardiya bitişinden 30 dk sonra'
                ];
                
                echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
                echo "<tr><th>Saat</th><th>Senaryo</th><th>Önerilen Aktivite</th><th>Açıklama</th></tr>";
                
                foreach ($testTimes as $time => $scenario) {
                    $suggestedActivity = simulateSmartDetection($todayShift, $time, $records);
                    $activityNames = [
                        'work_in' => '🟢 İşe Giriş',
                        'work_out' => '🔴 İşten Çıkış',
                        'break_start' => '🟡 Mola Başlangıcı',
                        'break_end' => '🟢 Mola Bitişi'
                    ];
                    
                    echo "<tr>";
                    echo "<td><strong>$time</strong></td>";
                    echo "<td>$scenario</td>";
                    echo "<td>" . ($activityNames[$suggestedActivity['activity']] ?? $suggestedActivity['activity']) . "</td>";
                    echo "<td>" . htmlspecialchars($suggestedActivity['reason']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
                
            } else {
                echo "<p style='color: red;'>Bu personel için bugün vardiya bulunamadı.</p>";
            }
        } else {
            echo "<p style='color: red;'>Geçersiz personel veya şirket ID'si.</p>";
        }
    }
    
    // Get companies and employees for testing
    echo "<h3>🧪 Test Parametreleri</h3>";
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='test_smart_system'>";
    
    // Company selection
    echo "<label><strong>Şirket:</strong></label><br>";
    $companies = $conn->query("SELECT id, company_name FROM companies ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    echo "<select name='company_id' required>";
    echo "<option value=''>Şirket Seçin</option>";
    foreach ($companies as $company) {
        echo "<option value='{$company['id']}'>" . htmlspecialchars($company['company_name']) . " (ID: {$company['id']})</option>";
    }
    echo "</select><br><br>";
    
    // Employee selection
    echo "<label><strong>Personel ID:</strong></label><br>";
    echo "<input type='number' name='employee_id' placeholder='Personel ID' required><br><br>";
    
    echo "<button type='submit' style='background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px;'>";
    echo "🤖 Akıllı Sistem Testi";
    echo "</button>";
    echo "</form>";
    
    echo "<hr>";
    echo "<h3>💡 Sistem Açıklaması</h3>";
    echo "<ul>";
    echo "<li><strong>Otomatik Tespit:</strong> Vardiya saatleri ve mevcut duruma göre aktiviteyi belirler</li>";
    echo "<li><strong>Zaman Toleransı:</strong> 15-30 dakikalık tolerans ile geç/erken durumları tespit eder</li>";
    echo "<li><strong>Mola Yönetimi:</strong> Öğle saatlerinde ve 4 saat sonra mola önerir</li>";
    echo "<li><strong>Durum Takibi:</strong> Son yapılan işleme göre bir sonraki adımı belirler</li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Hata Oluştu</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

function simulateSmartDetection($shift, $testTime, $existingRecords) {
    $shiftStart = $shift['start_time'];
    $shiftEnd = $shift['end_time'];
    
    // Convert times to minutes for easier comparison
    $currentMinutes = timeToMinutes($testTime . ':00');
    $startMinutes = timeToMinutes($shiftStart);
    $endMinutes = timeToMinutes($shiftEnd);
    
    // Check existing records for the context
    $hasCheckedIn = false;
    $hasBreakStarted = false;
    $hasBreakEnded = false;
    $hasCheckedOut = false;
    
    foreach ($existingRecords as $record) {
        switch ($record['activity_type']) {
            case 'work_in':
                $hasCheckedIn = true;
                break;
            case 'break_start':
                $hasBreakStarted = true;
                break;
            case 'break_end':
                $hasBreakEnded = true;
                break;
            case 'work_out':
                $hasCheckedOut = true;
                break;
        }
    }
    
    // Logic for activity detection
    if (!$hasCheckedIn) {
        if ($currentMinutes <= ($startMinutes + 15)) {
            return ['activity' => 'work_in', 'reason' => 'Vardiya başlangıcı - zamanında giriş'];
        } else {
            return ['activity' => 'work_in', 'reason' => 'Vardiya başlangıcı - geç giriş'];
        }
    }
    
    if ($hasCheckedIn && !$hasBreakStarted) {
        // Around lunch time
        if ($currentMinutes >= 750 && $currentMinutes <= 810) { // 12:30-13:30
            return ['activity' => 'break_start', 'reason' => 'Öğle molası zamanı'];
        }
        
        // Near end of shift
        if ($currentMinutes >= ($endMinutes - 30)) {
            return ['activity' => 'work_out', 'reason' => 'Vardiya bitiş saati yaklaştı'];
        }
        
        // After 4 hours of work
        if (($currentMinutes - $startMinutes) >= 240) {
            return ['activity' => 'break_start', 'reason' => '4 saat çalışma sonrası mola önerisi'];
        }
    }
    
    if ($hasBreakStarted && !$hasBreakEnded) {
        return ['activity' => 'break_end', 'reason' => 'Mola bitirme zamanı'];
    }
    
    if ($hasBreakEnded && !$hasCheckedOut) {
        if ($currentMinutes >= ($endMinutes - 15)) {
            return ['activity' => 'work_out', 'reason' => 'Vardiya bitiş saati'];
        }
    }
    
    if ($currentMinutes >= $endMinutes) {
        return ['activity' => 'work_out', 'reason' => 'Vardiya saati geçti - çıkış'];
    }
    
    return ['activity' => 'work_in', 'reason' => 'Varsayılan - giriş'];
}

function timeToMinutes($time) {
    $parts = explode(':', $time);
    return (int)$parts[0] * 60 + (int)$parts[1];
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
form { background: #f9f9f9; padding: 20px; border-radius: 5px; margin: 20px 0; }
</style>