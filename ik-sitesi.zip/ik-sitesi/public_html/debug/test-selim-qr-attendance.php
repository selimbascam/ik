<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🧪 Selim Personeli QR Devam Testi</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Find Selim's employee record
    echo "<h3>👤 Selim Personeli Arama</h3>";
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, employee_code, COALESCE(tc_no, '') as tc_identity 
        FROM employees 
        WHERE (first_name LIKE '%Selim%' OR last_name LIKE '%Selim%' OR 
               first_name LIKE '%selim%' OR last_name LIKE '%selim%')
        LIMIT 5
    ");
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($employees)) {
        echo "<p style='color: red;'>❌ Selim adlı personel bulunamadı</p>";
        
        // Show first few employees instead
        $stmt = $conn->query("SELECT id, first_name, last_name, employee_code FROM employees LIMIT 5");
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<h4>📋 Mevcut Personeller</h4>";
        foreach ($employees as $emp) {
            echo "<p>ID: {$emp['id']}, Ad: {$emp['first_name']} {$emp['last_name']}, Kod: {$emp['employee_code']}</p>";
        }
        exit;
    }
    
    $selim = $employees[0]; // Use first match
    $selimId = $selim['id'];
    
    echo "<p>✅ Selim bulundu: {$selim['first_name']} {$selim['last_name']} (ID: {$selimId})</p>";
    
    // Check Selim's shift for today
    echo "<h3>📅 Bugünkü Vardiya Kontrolü</h3>";
    $today = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT 
            es.*,
            st.name as shift_name,
            st.start_time,
            st.end_time
        FROM employee_shifts es
        JOIN shift_templates st ON es.shift_template_id = st.id
        WHERE es.employee_id = ? AND es.shift_date = ?
    ");
    $stmt->execute([$selimId, $today]);
    $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$todayShift) {
        echo "<p style='color: orange;'>⚠️ Bugün için vardiya bulunamadı, varsayılan vardiya oluşturuluyor...</p>";
        
        // Create default shift template if not exists
        $stmt = $conn->prepare("SELECT id FROM shift_templates WHERE name = 'Varsayılan Vardiya' LIMIT 1");
        $stmt->execute();
        $defaultTemplate = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$defaultTemplate) {
            $stmt = $conn->prepare("
                INSERT INTO shift_templates (name, start_time, end_time, break_duration, created_at)
                VALUES ('Varsayılan Vardiya', '09:00:00', '18:00:00', 60, NOW())
            ");
            $stmt->execute();
            $templateId = $conn->lastInsertId();
        } else {
            $templateId = $defaultTemplate['id'];
        }
        
        // Create today's shift for Selim
        $stmt = $conn->prepare("
            INSERT INTO employee_shifts (employee_id, shift_template_id, shift_date, status, created_at)
            VALUES (?, ?, ?, 'scheduled', NOW())
        ");
        $stmt->execute([$selimId, $templateId, $today]);
        
        // Fetch the created shift
        $stmt = $conn->prepare("
            SELECT 
                es.*,
                st.name as shift_name,
                st.start_time,
                st.end_time
            FROM employee_shifts es
            JOIN shift_templates st ON es.shift_template_id = st.id
            WHERE es.employee_id = ? AND es.shift_date = ?
        ");
        $stmt->execute([$selimId, $today]);
        $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<p>✅ Varsayılan vardiya oluşturuldu</p>";
    }
    
    echo "<div style='background: #e9ecef; padding: 15px; border-radius: 8px;'>";
    echo "<strong>Vardiya Bilgileri:</strong><br>";
    echo "Ad: {$todayShift['shift_name']}<br>";
    echo "Başlangıç: {$todayShift['start_time']}<br>";
    echo "Bitiş: {$todayShift['end_time']}<br>";
    echo "Durum: {$todayShift['status']}<br>";
    echo "</div>";
    
    // Check existing attendance records for today
    echo "<h3>📊 Bugünkü Devam Kayıtları</h3>";
    $stmt = $conn->prepare("
        SELECT * FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$selimId, $today]);
    $todayRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($todayRecords)) {
        echo "<p>❌ Bugün için devam kaydı bulunamadı</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Saat</th><th>Aktivite</th><th>QR Lokasyon</th><th>Notlar</th></tr>";
        foreach ($todayRecords as $record) {
            echo "<tr>";
            echo "<td>" . date('H:i:s', strtotime($record['check_in_time'])) . "</td>";
            echo "<td>" . $record['activity_type'] . "</td>";
            echo "<td>" . ($record['qr_location_id'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($record['notes'] ?? '') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Test QR attendance insert
    echo "<h3>🧪 Test QR Giriş Kaydı</h3>";
    
    $currentTime = date('H:i:s');
    $currentDateTime = date('Y-m-d H:i:s');
    
    echo "<p><strong>Test Parametreleri:</strong></p>";
    echo "<ul>";
    echo "<li>Personel ID: {$selimId}</li>";
    echo "<li>Aktivite: work_in (işe giriş)</li>";
    echo "<li>Zaman: {$currentTime}</li>";
    echo "<li>QR Lokasyon: Test Lokasyon</li>";
    echo "</ul>";
    
    try {
        // Test insertion
        $stmt = $conn->prepare("
            INSERT INTO attendance_records (
                employee_id, qr_location_id, activity_type, 
                check_in_time, latitude, longitude, 
                notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            $selimId,
            1, // Test location ID
            'work_in',
            $currentTime,
            41.0082, // Ankara coordinates
            28.9784,
            'Debug test kayıt - ' . date('Y-m-d H:i:s'),
            $currentDateTime
        ]);
        
        if ($result) {
            $insertId = $conn->lastInsertId();
            echo "<p style='color: green;'>✅ Test QR giriş kaydı başarıyla eklendi (ID: {$insertId})</p>";
            
            // Update shift status
            $stmt = $conn->prepare("
                UPDATE employee_shifts 
                SET status = 'checked_in', check_in_time = ? 
                WHERE id = ?
            ");
            $stmt->execute([$currentTime, $todayShift['id']]);
            
            echo "<p style='color: green;'>✅ Vardiya durumu güncellendi</p>";
            
            // Verify the record was saved
            $stmt = $conn->prepare("
                SELECT * FROM attendance_records 
                WHERE id = ?
            ");
            $stmt->execute([$insertId]);
            $newRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($newRecord) {
                echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
                echo "<strong>✅ Kaydedilen Veri Doğrulandı:</strong><br>";
                echo "ID: {$newRecord['id']}<br>";
                echo "Personel ID: {$newRecord['employee_id']}<br>";
                echo "Aktivite: {$newRecord['activity_type']}<br>";
                echo "Saat: {$newRecord['check_in_time']}<br>";
                echo "Oluşturma: {$newRecord['created_at']}<br>";
                echo "</div>";
            }
            
        } else {
            echo "<p style='color: red;'>❌ Test kayıt ekleme başarısız</p>";
            $errorInfo = $stmt->errorInfo();
            echo "<p>Hata: " . $errorInfo[2] . "</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Test kayıt hatası: " . $e->getMessage() . "</p>";
    }
    
    // Show final status
    echo "<h3>📈 Güncel Durum</h3>";
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) = ?
    ");
    $stmt->execute([$selimId, $today]);
    $totalRecords = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<p><strong>Selim'in bugünkü toplam kayıt sayısı: {$totalRecords}</strong></p>";
    
    // Database table structure check
    echo "<h3>🔍 Veritabanı Yapısı Kontrolü</h3>";
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<details><summary>📋 attendance_records Tablo Sütunları</summary>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
    echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table></details>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Test Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
details { margin: 10px 0; }
summary { cursor: pointer; background: #f8f9fa; padding: 10px; border-radius: 5px; }
</style>