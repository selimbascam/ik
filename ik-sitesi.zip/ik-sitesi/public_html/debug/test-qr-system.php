<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/qr-attendance-fixed.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>QR Sistem Testi</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { background: #d1fae5; color: #065f46; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { background: #dbeafe; color: #1e40af; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { background: #fef3c7; color: #92400e; padding: 10px; border-radius: 5px; margin: 10px 0; }
        pre { background: #f3f4f6; padding: 10px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>🔍 QR Sistem Testi</h1>
    
    <?php
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        echo "<div class='info'>✅ Veritabanı bağlantısı başarılı</div>";
        
        // Test QRAttendanceHelper class
        echo "<div class='info'><strong>QRAttendanceHelper sınıfı test ediliyor...</strong></div>";
        
        // Test column mapping
        $colMapping = QRAttendanceHelper::getColumnMapping($conn);
        echo "<div class='success'>✅ Column mapping başarılı:</div>";
        echo "<pre>" . print_r($colMapping, true) . "</pre>";
        
        // Check attendance_records table
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='info'><strong>Attendance_records tablosu sütunları:</strong><br>";
        echo implode(', ', $columns) . "</div>";
        
        // Check qr_locations table
        $stmt = $conn->query("SHOW COLUMNS FROM qr_locations");
        $qrColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='info'><strong>QR_locations tablosu sütunları:</strong><br>";
        echo implode(', ', $qrColumns) . "</div>";
        
        // Test gate action determination
        $testEmployeeId = 1;
        $testCompanyId = 1;
        $testLocationId = 1;
        $testGateBehavior = 'work_start';
        
        echo "<div class='warning'><strong>Test parametreleri:</strong><br>";
        echo "Employee ID: $testEmployeeId<br>";
        echo "Company ID: $testCompanyId<br>";
        echo "Location ID: $testLocationId<br>";
        echo "Gate Behavior: $testGateBehavior</div>";
        
        $gateAction = QRAttendanceHelper::determineGateAction($conn, $testEmployeeId, $testCompanyId, $testLocationId, $testGateBehavior);
        echo "<div class='success'>✅ Gate action determination başarılı:</div>";
        echo "<pre>" . print_r($gateAction, true) . "</pre>";
        
        // Check if employees exist
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employees");
        $empCount = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='info'><strong>Toplam personel sayısı:</strong> " . $empCount['count'] . "</div>";
        
        // Check if qr_locations exist
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations");
        $locCount = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='info'><strong>Toplam QR lokasyon sayısı:</strong> " . $locCount['count'] . "</div>";
        
        if ($locCount['count'] == 0) {
            echo "<div class='warning'>⚠️ QR lokasyonu bulunamadı. Test lokasyonu oluşturuluyor...</div>";
            
            $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, location_type, gate_behavior, created_at) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([1, 'Test Giriş Kapısı', 'entrance_gate', 'work_start', date('Y-m-d H:i:s')]);
            echo "<div class='success'>✅ Test lokasyonu oluşturuldu</div>";
        }
        
        echo "<div class='success'>🎉 Tüm testler başarılı! QR sistemi çalışmaya hazır.</div>";
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Hata: " . htmlspecialchars($e->getMessage()) . "</div>";
        echo "<div class='error'>Stack trace: <pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre></div>";
    }
    ?>
    
    <div style="margin-top: 20px;">
        <a href="../qr/qr-reader.php" style="background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🔙 QR Okuyucuya Git</a>
        <a href="../employee/dashboard.php" style="background: #6b7280; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">👤 Personel Paneli</a>
    </div>
</body>
</html>