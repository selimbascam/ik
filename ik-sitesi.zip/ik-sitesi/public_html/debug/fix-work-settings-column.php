<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <title>Work Settings Column Fix</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100 p-8'>
    <div class='max-w-3xl mx-auto bg-white rounded-lg shadow-lg p-6'>
        <h1 class='text-2xl font-bold text-gray-900 mb-4'>🔧 Work Settings Column Hatası Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-4'>";
    
    // 1. Check current table structure
    echo "<div class='bg-blue-50 p-4 rounded'>
            <h3 class='font-semibold text-blue-800'>1. Current Table Structure:</h3>";
    
    try {
        $stmt = $conn->query("DESCRIBE work_settings");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table class='w-full mt-2 text-sm'>
                <tr class='bg-gray-100'>
                    <th class='p-2 text-left'>Column</th>
                    <th class='p-2 text-left'>Type</th>
                    <th class='p-2 text-left'>Default</th>
                </tr>";
        
        $hasDaily = false;
        foreach ($columns as $column) {
            echo "<tr>
                    <td class='p-2 border'>{$column['Field']}</td>
                    <td class='p-2 border'>{$column['Type']}</td>
                    <td class='p-2 border'>{$column['Default']}</td>
                  </tr>";
            if ($column['Field'] === 'daily_work_hours') {
                $hasDaily = true;
            }
        }
        echo "</table>";
        
        if ($hasDaily) {
            echo "<p class='text-green-600 mt-2'>✅ daily_work_hours column exists</p>";
        } else {
            echo "<p class='text-red-600 mt-2'>❌ daily_work_hours column missing</p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Table doesn't exist or error: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    echo "</div>";
    
    // 2. Auto-fix missing columns
    echo "<div class='bg-green-50 p-4 rounded'>
            <h3 class='font-semibold text-green-800'>2. Auto-Fix Missing Columns:</h3>";
    
    try {
        // First ensure table exists with correct structure
        $conn->exec("CREATE TABLE IF NOT EXISTS work_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            daily_work_hours INT DEFAULT 8,
            weekly_work_hours INT DEFAULT 45,
            monthly_work_hours INT DEFAULT 225,
            overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
            holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
            weekend_multiplier DECIMAL(3,2) DEFAULT 1.50,
            grace_period_minutes INT DEFAULT 15,
            late_penalty_amount DECIMAL(10,2) DEFAULT 0,
            min_break_duration INT DEFAULT 30,
            max_break_duration INT DEFAULT 60,
            hourly_rate DECIMAL(10,2) DEFAULT 50.00,
            weekly_holiday INT DEFAULT 1,
            auto_schedule TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_company (company_id)
        )");
        echo "<p class='text-green-600'>✅ Table created/verified with correct structure</p>";
        
        // Check if daily_work_hours column exists
        $stmt = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'daily_work_hours'");
        if ($stmt->rowCount() === 0) {
            // Add missing daily_work_hours column
            $conn->exec("ALTER TABLE work_settings ADD COLUMN daily_work_hours INT DEFAULT 8 AFTER company_id");
            echo "<p class='text-green-600'>✅ Added missing daily_work_hours column</p>";
        } else {
            echo "<p class='text-green-600'>✅ daily_work_hours column already exists</p>";
        }
        
        // Ensure all required columns exist
        $requiredColumns = [
            'weekly_work_hours' => 'INT DEFAULT 45',
            'monthly_work_hours' => 'INT DEFAULT 225',
            'overtime_multiplier' => 'DECIMAL(3,2) DEFAULT 1.50',
            'holiday_multiplier' => 'DECIMAL(3,2) DEFAULT 2.00',
            'weekend_multiplier' => 'DECIMAL(3,2) DEFAULT 1.50',
            'grace_period_minutes' => 'INT DEFAULT 15',
            'late_penalty_amount' => 'DECIMAL(10,2) DEFAULT 0',
            'min_break_duration' => 'INT DEFAULT 30',
            'max_break_duration' => 'INT DEFAULT 60',
            'hourly_rate' => 'DECIMAL(10,2) DEFAULT 50.00',
            'weekly_holiday' => 'INT DEFAULT 1',
            'auto_schedule' => 'TINYINT(1) DEFAULT 1'
        ];
        
        foreach ($requiredColumns as $column => $definition) {
            $stmt = $conn->query("SHOW COLUMNS FROM work_settings LIKE '$column'");
            if ($stmt->rowCount() === 0) {
                $conn->exec("ALTER TABLE work_settings ADD COLUMN $column $definition");
                echo "<p class='text-green-600'>✅ Added missing $column column</p>";
            }
        }
        
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Error fixing columns: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    echo "</div>";
    
    // 3. Test INSERT statement
    echo "<div class='bg-purple-50 p-4 rounded'>
            <h3 class='font-semibold text-purple-800'>3. Test INSERT Statement:</h3>";
    
    try {
        // Test the exact INSERT statement that was failing
        $testCompanyId = 4; // Use Company ID 4 as test
        
        $stmt = $conn->prepare("
            INSERT INTO work_settings 
            (company_id, daily_work_hours, weekly_work_hours, monthly_work_hours, overtime_multiplier, holiday_multiplier, weekend_multiplier, grace_period_minutes, late_penalty_amount, min_break_duration, max_break_duration, hourly_rate, weekly_holiday, auto_schedule, updated_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE
            daily_work_hours = VALUES(daily_work_hours),
            weekly_work_hours = VALUES(weekly_work_hours),
            monthly_work_hours = VALUES(monthly_work_hours),
            overtime_multiplier = VALUES(overtime_multiplier),
            holiday_multiplier = VALUES(holiday_multiplier),
            weekend_multiplier = VALUES(weekend_multiplier),
            grace_period_minutes = VALUES(grace_period_minutes),
            late_penalty_amount = VALUES(late_penalty_amount),
            min_break_duration = VALUES(min_break_duration),
            max_break_duration = VALUES(max_break_duration),
            hourly_rate = VALUES(hourly_rate),
            weekly_holiday = VALUES(weekly_holiday),
            auto_schedule = VALUES(auto_schedule),
            updated_at = NOW()
        ");
        
        $params = [
            $testCompanyId, 8, 45, 225, 1.50, 2.00, 1.50, 15, 0, 30, 60, 50.00, 1, 1
        ];
        
        $stmt->execute($params);
        echo "<p class='text-green-600'>✅ INSERT statement test successful</p>";
        
        // Verify the inserted data
        $stmt = $conn->prepare("SELECT * FROM work_settings WHERE company_id = ?");
        $stmt->execute([$testCompanyId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            echo "<p class='text-green-600'>✅ Data verification successful</p>";
            echo "<p class='text-sm text-gray-600'>Daily hours: {$result['daily_work_hours']}, Weekly hours: {$result['weekly_work_hours']}</p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ INSERT test failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    echo "</div>";
    
    // 4. Final table structure verification
    echo "<div class='bg-gray-50 p-4 rounded'>
            <h3 class='font-semibold text-gray-800'>4. Final Table Structure Verification:</h3>";
    
    try {
        $stmt = $conn->query("DESCRIBE work_settings");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $expectedColumns = ['daily_work_hours', 'weekly_work_hours', 'monthly_work_hours', 'overtime_multiplier', 'holiday_multiplier'];
        $foundColumns = array_column($columns, 'Field');
        
        foreach ($expectedColumns as $expected) {
            if (in_array($expected, $foundColumns)) {
                echo "<p class='text-green-600'>✅ $expected column verified</p>";
            } else {
                echo "<p class='text-red-600'>❌ $expected column missing</p>";
            }
        }
        
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Verification error: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    echo "</div>";
    
    echo "</div>";
    
    echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mt-6'>
            <h3 class='font-bold'>🎉 Work Settings Column Fix Complete!</h3>
            <p>The daily_work_hours column issue has been resolved. You can now:</p>
            <ul class='list-disc list-inside mt-2'>
                <li>Access Work Settings without column errors</li>
                <li>Save work configuration properly</li>
                <li>Use all work hours settings</li>
            </ul>
          </div>";
    
    echo "<div class='mt-6 flex gap-3'>
            <a href='../admin/work-settings.php' class='bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded'>
                ⚙️ Go to Work Settings
            </a>
            <a href='../dashboard/company-dashboard.php' class='bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded'>
                🏠 Back to Dashboard
            </a>
          </div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>
            <strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "
          </div>";
}

echo "    </div>
</body>
</html>";
?>