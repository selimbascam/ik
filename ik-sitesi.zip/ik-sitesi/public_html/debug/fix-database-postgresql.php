<?php
echo "<h2>🔧 PostgreSQL Bağlantısı Düzeltmesi</h2>";

// Veritabanı türünü kontrol et
echo "<h3>🗄️ Sistem Kontrolü</h3>";
echo "<p><strong>Sistem:</strong> PostgreSQL veritabanı kullanıyor (Node.js/Express projesi)</p>";
echo "<p><strong>Problem:</strong> PHP kodları MySQL için yazılmış</p>";
echo "<p><strong>Çözüm:</strong> PHP kodlarını PostgreSQL ile uyumlu hale getir</p>";

echo "<h3>🔧 PHP Database Class Güncellemesi</h3>";

// PostgreSQL bağlantısı için yeni database.php
$newDatabaseContent = '<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    public $conn;

    public function __construct() {
        // PostgreSQL bağlantı bilgilerini environment\'tan al
        $database_url = getenv("DATABASE_URL");
        
        if ($database_url) {
            // DATABASE_URL parse et
            $url = parse_url($database_url);
            $this->host = $url["host"];
            $this->port = $url["port"] ?? 5432;
            $this->db_name = ltrim($url["path"], "/");
            $this->username = $url["user"];
            $this->password = $url["pass"];
        } else {
            // Fallback değerler
            $this->host = getenv("PGHOST") ?: "localhost";
            $this->port = getenv("PGPORT") ?: 5432;
            $this->db_name = getenv("PGDATABASE") ?: "postgres";
            $this->username = getenv("PGUSER") ?: "postgres";
            $this->password = getenv("PGPASSWORD") ?: "";
        }
    }

    public function getConnection() {
        $this->conn = null;

        try {
            // PostgreSQL DSN
            $dsn = "pgsql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name;
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // PostgreSQL için UTC timezone ayarla
            $this->conn->exec("SET timezone = \'UTC\'");
            
        } catch(PDOException $exception) {
            error_log("PostgreSQL bağlantı hatası: " . $exception->getMessage());
            throw new Exception("Veritabanı bağlantısı kurulamadı: " . $exception->getMessage());
        }

        return $this->conn;
    }
    
    // MySQL -> PostgreSQL uyumluluk fonksiyonları
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }
    
    // SHOW TABLES benzeri fonksiyon
    public function showTables() {
        $stmt = $this->conn->query("SELECT table_name FROM information_schema.tables WHERE table_schema = \'public\'");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    // SHOW COLUMNS benzeri fonksiyon  
    public function showColumns($tableName) {
        $stmt = $this->conn->prepare("
            SELECT column_name as Field, data_type as Type, 
                   is_nullable as \"Null\", column_default as \"Default\"
            FROM information_schema.columns 
            WHERE table_name = ? 
            ORDER BY ordinal_position
        ");
        $stmt->execute([$tableName]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>';

// Database.php dosyasını güncelle
$databaseFile = '../includes/database.php';
if (file_put_contents($databaseFile, $newDatabaseContent)) {
    echo "<p style='color: green;'>✅ database.php PostgreSQL uyumlu hale getirildi</p>";
} else {
    echo "<p style='color: red;'>❌ database.php güncellenemedi</p>";
}

echo "<h3>🔧 QR Unified PostgreSQL Uyumluluğu</h3>";

// QR-unified.php dosyasını PostgreSQL uyumlu hale getir
$qrUnifiedFile = '../employee/qr-unified.php';
if (file_exists($qrUnifiedFile)) {
    $content = file_get_contents($qrUnifiedFile);
    
    // MySQL specific queries to PostgreSQL
    $content = str_replace(
        "SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'",
        "SELECT column_name FROM information_schema.columns WHERE table_name = 'qr_locations' AND column_name = 'gate_behavior'",
        $content
    );
    
    // DATE() function to PostgreSQL DATE()
    $content = str_replace(
        "DATE(created_at)",
        "DATE(created_at)",
        $content
    );
    
    // NOW() to CURRENT_TIMESTAMP
    $content = str_replace(
        "NOW()",
        "CURRENT_TIMESTAMP",
        $content
    );
    
    if (file_put_contents($qrUnifiedFile, $content)) {
        echo "<p style='color: green;'>✅ qr-unified.php PostgreSQL uyumlu hale getirildi</p>";
    }
}

echo "<h3>🧪 Bağlantı Testi</h3>";

try {
    // Test the new database connection
    require_once '../includes/database.php';
    
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<p style='color: green;'>✅ PostgreSQL bağlantısı başarılı!</p>";
    
    // Test qr_locations query
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE is_active = true");
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p style='color: green;'>✅ QR lokasyonları erişilebilir: {$result['count']} aktif lokasyon</p>";
    
    // Test attendance_records structure
    $stmt = $conn->query("SELECT column_name FROM information_schema.columns WHERE table_name = 'attendance_records' AND column_name IN ('latitude', 'longitude', 'qr_location_id')");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (count($columns) >= 3) {
        echo "<p style='color: green;'>✅ attendance_records tablosu QR sistemi için hazır</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ attendance_records eksik sütunlar: " . implode(', ', array_diff(['latitude', 'longitude', 'qr_location_id'], $columns)) . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Test hatası: " . $e->getMessage() . "</p>";
}

echo "<h3>📋 QR Sistemi Test Bilgileri</h3>";
echo "<div style='background: #e9ecef; padding: 15px; border-radius: 5px;'>";
echo "<ul>";
echo "<li><strong>QR Test URL:</strong> <a href='../employee/qr-unified.php' target='_blank'>employee/qr-unified.php</a></li>";
echo "<li><strong>Veritabanı:</strong> PostgreSQL</li>";
echo "<li><strong>Bağlantı:</strong> Environment variables (DATABASE_URL)</li>";
echo "<li><strong>Test QR Kodu:</strong> Herhangi bir sayı veya JSON format</li>";
echo "</ul>";
echo "</div>";

echo "<h3>🎉 Düzeltme Tamamlandı</h3>";
echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
echo "<h2>✅ PostgreSQL Uyumluluğu Sağlandı!</h2>";
echo "<p>PHP kodları artık PostgreSQL veritabanı ile çalışıyor.</p>";
echo "<p>QR kod okutma hatası düzeltildi.</p>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>