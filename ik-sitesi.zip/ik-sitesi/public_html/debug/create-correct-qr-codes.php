<?php
require_once '../includes/config.php';

// Doğru QR kodları oluştur
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doğru QR Kodları Oluştur</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-2xl font-bold mb-6">📱 Doğru QR Kodları</h1>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Giriş QR Kodu -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-lg font-bold text-green-600 mb-4">🚪 İŞE GİRİŞ</h2>
                <div class="text-center mb-4">
                    <canvas id="qr-entry" class="mx-auto border"></canvas>
                </div>
                <div class="text-sm text-gray-600">
                    <strong>QR İçeriği:</strong> 1<br>
                    <strong>Location:</strong> Ana Giriş Kapısı<br>
                    <strong>Aktivite:</strong> work_start
                </div>
            </div>
            
            <!-- Çıkış QR Kodu -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-lg font-bold text-red-600 mb-4">🚪 İŞTEN ÇIKIŞ</h2>
                <div class="text-center mb-4">
                    <canvas id="qr-exit" class="mx-auto border"></canvas>
                </div>
                <div class="text-sm text-gray-600">
                    <strong>QR İçeriği:</strong> 2<br>
                    <strong>Location:</strong> Ana Çıkış Kapısı<br>
                    <strong>Aktivite:</strong> work_end
                </div>
            </div>
            
            <!-- Mola QR Kodu -->
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-lg font-bold text-blue-600 mb-4">☕ MOLA</h2>
                <div class="text-center mb-4">
                    <canvas id="qr-break" class="mx-auto border"></canvas>
                </div>
                <div class="text-sm text-gray-600">
                    <strong>QR İçeriği:</strong> 3<br>
                    <strong>Location:</strong> Çay Ocağı<br>
                    <strong>Aktivite:</strong> break_start/end
                </div>
            </div>
        </div>
        
        <div class="mt-8 bg-yellow-50 p-4 rounded border-l-4 border-yellow-400">
            <h3 class="font-bold text-yellow-800">⚠️ ÖNEMLİ NOTLAR:</h3>
            <ul class="mt-2 text-yellow-700 text-sm">
                <li>• Bu QR kodlarını yazdırıp kullanın</li>
                <li>• Eski QR kodlarınız (74, 75, 76) çalışmaz</li>
                <li>• Her QR kodu farklı aktivite türü tetikler</li>
                <li>• Giriş → Çıkış → Mola sırasıyla kullanın</li>
            </ul>
        </div>
        
        <div class="mt-4 text-center">
            <a href="qr-real-debug.php" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                🔍 Debug Ekranına Dön
            </a>
        </div>
    </div>

    <script>
        // Mevcut location ID'lere göre QR kodları oluştur
        const locationData = [
            { id: 1, name: 'Ana Giriş Kapısı', type: 'check_in', activity: 'work_start', color: '#22c55e' },
            { id: 2, name: 'Ana Çıkış Kapısı', type: 'check_out', activity: 'work_end', color: '#ef4444' },
            { id: 3, name: 'Çay Ocağı', type: 'tea_break', activity: 'break_toggle', color: '#3b82f6' },
            { id: 4, name: 'Yemekhane', type: 'lunch_break', activity: 'break_toggle', color: '#f59e0b' },
            { id: 5, name: 'Sigara İçme Alanı', type: 'smoke_break', activity: 'break_toggle', color: '#8b5cf6' },
            { id: 8, name: 'Ana Giriş', type: 'entrance', activity: 'work_start', color: '#10b981' }
        ];

        // QR kodlarını oluştur
        function generateQRCodes() {
            // Sadece temel 3 QR kodu göster (giriş, çıkış, mola)
            // Giriş QR Kodu (ID: 1)
            QRCode.toCanvas(document.getElementById('qr-entry'), '1', {
                width: 200,
                height: 200,
                margin: 1,
                color: {
                    dark: '#22c55e',
                    light: '#ffffff'
                }
            });
            
            // Çıkış QR Kodu (ID: 2) 
            QRCode.toCanvas(document.getElementById('qr-exit'), '2', {
                width: 200,
                height: 200,
                margin: 1,
                color: {
                    dark: '#ef4444',
                    light: '#ffffff'
                }
            });
            
            // Mola QR Kodu (ID: 3)
            QRCode.toCanvas(document.getElementById('qr-break'), '3', {
                width: 200,
                height: 200,
                margin: 1,
                color: {
                    dark: '#3b82f6',
                    light: '#ffffff'
                }
            });
        }
        
        // Sayfa yüklenince QR kodlarını oluştur
        window.addEventListener('DOMContentLoaded', generateQRCodes);
    </script>
</body>
</html>