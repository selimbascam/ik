<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🧪 Employee Login Test (30716129672)</h2>";

$employee_number = '30716129672';
$password = 'Abc123456';

echo "<div style='background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
echo "Testing login with:<br>";
echo "Employee Number: <strong>$employee_number</strong><br>";
echo "Password: <strong>$password</strong><br>";
echo "</div>";

// Simulate login process
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Step 1: Find employee
    echo "<h3>Step 1: Employee Lookup</h3>";
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, employee_number, password, company_id 
        FROM employees 
        WHERE employee_number = ? OR tc_no = ? OR employee_code = ?
    ");
    $stmt->execute([$employee_number, $employee_number, $employee_number]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "❌ Employee not found<br>";
        exit;
    }
    
    echo "✅ Employee found: {$employee['first_name']} {$employee['last_name']} (ID: {$employee['id']})<br>";
    
    // Step 2: Password verification
    echo "<h3>Step 2: Password Verification</h3>";
    $passwordValid = false;
    
    if (!isset($employee['password']) || empty($employee['password'])) {
        echo "⚠️ No password set - would allow login<br>";
        $passwordValid = true;
    } elseif (password_verify($password, $employee['password'])) {
        echo "✅ Argon2ID password verified successfully<br>";
        $passwordValid = true;
    } elseif ($employee['password'] === $password) {
        echo "✅ Plain text password match<br>";
        $passwordValid = true;
    } elseif (md5($password) === $employee['password']) {
        echo "✅ MD5 password match<br>";
        $passwordValid = true;
    } else {
        echo "❌ Password verification failed<br>";
        echo "Hash: " . substr($employee['password'], 0, 30) . "...<br>";
    }
    
    // Step 3: Company verification
    echo "<h3>Step 3: Company Verification</h3>";
    $compStmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
    $compStmt->execute([$employee['company_id']]);
    $company = $compStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        echo "✅ Company found: {$company['company_name']} (ID: {$company['id']})<br>";
    } else {
        echo "⚠️ Company not found for ID: {$employee['company_id']}<br>";
    }
    
    // Step 4: Login result
    echo "<h3>Step 4: Login Result</h3>";
    if ($passwordValid) {
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "🎉 <strong>LOGIN WOULD SUCCEED</strong><br>";
        echo "Session would be created with:<br>";
        echo "- employee_id: {$employee['id']}<br>";
        echo "- company_id: {$employee['company_id']}<br>";
        echo "- employee_name: {$employee['first_name']} {$employee['last_name']}<br>";
        echo "- employee_code: {$employee['employee_number']}<br>";
        echo "</div>";
        
        echo "<a href='../auth/employee-login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0;'>🚀 Go to Real Login Page</a>";
    } else {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ <strong>LOGIN WOULD FAIL</strong><br>";
        echo "Password verification failed";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ <strong>Error:</strong> " . $e->getMessage();
    echo "</div>";
}

echo "<hr style='margin: 20px 0;'>";
echo "<h3>🔗 Quick Links</h3>";
echo "<a href='check-employee-password.php'>🔍 Check Password Hash</a> | ";
echo "<a href='../auth/employee-login.php'>🔐 Employee Login</a> | ";
echo "<a href='../employee/dashboard.php'>📊 Dashboard</a>";
?>