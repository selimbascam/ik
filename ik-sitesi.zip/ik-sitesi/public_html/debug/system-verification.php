<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// System Verification Tool
echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>SZB İK Takip - Sistem Doğruluk Kontrolü</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo ".container { max-width: 1200px; margin: 0 auto; }";
echo ".section { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".table { width: 100%; border-collapse: collapse; margin: 20px 0; }";
echo ".table th, .table td { border: 1px solid #ddd; padding: 12px; text-align: left; }";
echo ".table th { background: #f8f9fa; font-weight: bold; }";
echo ".header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; text-align: center; }";
echo "</style>";
echo "</head>";
echo "<body>";

echo "<div class='container'>";
echo "<div class='header'>";
echo "<h1>🔍 SZB İK Takip Sistem Doğruluk Kontrolü</h1>";
echo "<p>Tüm sistem bileşenlerinin kapsamlı kontrolü</p>";
echo "</div>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $results = [];
    $totalTests = 0;
    $passedTests = 0;
    
    // 1. Database Connection Test
    echo "<div class='section'>";
    echo "<h2>📊 Veritabanı Bağlantısı</h2>";
    
    try {
        $stmt = $conn->query("SELECT 1");
        if ($stmt) {
            echo "<div class='success'>✅ Veritabanı bağlantısı başarılı</div>";
            $passedTests++;
        }
        $totalTests++;
    } catch (Exception $e) {
        echo "<div class='error'>❌ Veritabanı bağlantısı başarısız: " . $e->getMessage() . "</div>";
        $totalTests++;
    }
    echo "</div>";
    
    // 2. Core Tables Check
    echo "<div class='section'>";
    echo "<h2>🗃️ Temel Tablolar</h2>";
    
    $requiredTables = [
        'companies' => 'Şirketler',
        'employees' => 'Personeller', 
        'attendance_records' => 'Devam Kayıtları',
        'employee_shifts' => 'Personel Vardiyaları',
        'shift_templates' => 'Vardiya Şablonları',
        'qr_locations' => 'QR Lokasyonları',
        'employee_weekly_holidays' => 'Haftalık Tatiller'
    ];
    
    echo "<table class='table'>";
    echo "<tr><th>Tablo</th><th>Açıklama</th><th>Durum</th><th>Kayıt Sayısı</th></tr>";
    
    foreach ($requiredTables as $table => $description) {
        $totalTests++;
        try {
            $stmt = $conn->query("SHOW TABLES LIKE '$table'");
            if ($stmt->rowCount() > 0) {
                // Count records
                $countStmt = $conn->query("SELECT COUNT(*) as count FROM $table");
                $count = $countStmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                echo "<tr>";
                echo "<td><strong>$table</strong></td>";
                echo "<td>$description</td>";
                echo "<td><span style='color: green;'>✅ Mevcut</span></td>";
                echo "<td>$count</td>";
                echo "</tr>";
                $passedTests++;
            } else {
                echo "<tr>";
                echo "<td><strong>$table</strong></td>";
                echo "<td>$description</td>";
                echo "<td><span style='color: red;'>❌ Bulunamadı</span></td>";
                echo "<td>-</td>";
                echo "</tr>";
            }
        } catch (Exception $e) {
            echo "<tr>";
            echo "<td><strong>$table</strong></td>";
            echo "<td>$description</td>";
            echo "<td><span style='color: red;'>❌ Hata</span></td>";
            echo "<td>-</td>";
            echo "</tr>";
        }
    }
    
    echo "</table>";
    echo "</div>";
    
    // 3. Company Authentication Test
    echo "<div class='section'>";
    echo "<h2>🏢 Şirket Girişleri</h2>";
    
    try {
        $stmt = $conn->query("SELECT id, email, company_name FROM companies WHERE email IS NOT NULL AND email != '' ORDER BY id");
        $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table class='table'>";
        echo "<tr><th>ID</th><th>Şirket Adı</th><th>Email</th><th>Personel Sayısı</th></tr>";
        
        foreach ($companies as $company) {
            $totalTests++;
            
            // Count employees
            $empStmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE company_id = ?");
            $empStmt->execute([$company['id']]);
            $empCount = $empStmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            echo "<tr>";
            echo "<td>" . $company['id'] . "</td>";
            echo "<td>" . htmlspecialchars($company['company_name']) . "</td>";
            echo "<td>" . htmlspecialchars($company['email']) . "</td>";
            echo "<td>$empCount</td>";
            echo "</tr>";
            
            $passedTests++;
        }
        
        echo "</table>";
        
        if (count($companies) > 0) {
            echo "<div class='success'>✅ " . count($companies) . " aktif şirket bulundu</div>";
        } else {
            echo "<div class='warning'>⚠️ Hiç şirket kaydı bulunamadı</div>";
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Şirket verisi alınamadı: " . $e->getMessage() . "</div>";
        $totalTests++;
    }
    echo "</div>";
    
    // 4. Employee Data Verification
    echo "<div class='section'>";
    echo "<h2>👥 Personel Verileri</h2>";
    
    try {
        $stmt = $conn->query("
            SELECT 
                e.id,
                e.first_name,
                e.last_name,
                e.employee_number,
                c.company_name,
                (SELECT COUNT(*) FROM attendance_records ar WHERE ar.employee_id = e.id AND DATE(ar.check_in) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)) as recent_attendance
            FROM employees e
            LEFT JOIN companies c ON e.company_id = c.id
            ORDER BY c.company_name, e.first_name
            LIMIT 10
        ");
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table class='table'>";
        echo "<tr><th>Personel</th><th>Personel No</th><th>Şirket</th><th>Son 7 Gün Devam</th></tr>";
        
        foreach ($employees as $emp) {
            $totalTests++;
            
            $fullName = $emp['first_name'] . ' ' . $emp['last_name'];
            $employeeNumber = $emp['employee_number'] ?: 'Atanmamış';
            $companyName = $emp['company_name'] ?: 'Bilinmeyen';
            $recentAttendance = $emp['recent_attendance'];
            
            echo "<tr>";
            echo "<td>" . htmlspecialchars($fullName) . "</td>";
            echo "<td>" . htmlspecialchars($employeeNumber) . "</td>";
            echo "<td>" . htmlspecialchars($companyName) . "</td>";
            echo "<td>$recentAttendance</td>";
            echo "</tr>";
            
            $passedTests++;
        }
        
        echo "</table>";
        
        if (count($employees) > 0) {
            echo "<div class='success'>✅ Personel verileri doğru görüntüleniyor</div>";
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Personel verileri alınamadı: " . $e->getMessage() . "</div>";
        $totalTests++;
    }
    echo "</div>";
    
    // 5. QR System Verification
    echo "<div class='section'>";
    echo "<h2>📱 QR Kod Sistemi</h2>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations");
        $qrLocationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $stmt = $conn->query("
            SELECT COUNT(*) as count 
            FROM attendance_records 
            WHERE check_in_method = 'qr_code' 
            AND DATE(check_in) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        ");
        $recentQrAttendance = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "<div class='success'>✅ QR Lokasyonları: $qrLocationCount</div>";
        echo "<div class='success'>✅ Son 7 gün QR devam kaydı: $recentQrAttendance</div>";
        
        $totalTests += 2;
        $passedTests += 2;
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ QR sistem verileri alınamadı: " . $e->getMessage() . "</div>";
        $totalTests++;
    }
    echo "</div>";
    
    // 6. Shift System Verification
    echo "<div class='section'>";
    echo "<h2>⏰ Vardiya Sistemi</h2>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
        $shiftTemplateCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $stmt = $conn->query("
            SELECT COUNT(*) as count 
            FROM employee_shifts 
            WHERE shift_date >= CURDATE() 
            AND shift_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
        ");
        $upcomingShifts = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "<div class='success'>✅ Vardiya Şablonları: $shiftTemplateCount</div>";
        echo "<div class='success'>✅ Gelecek 7 gün vardiyaları: $upcomingShifts</div>";
        
        $totalTests += 2;
        $passedTests += 2;
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Vardiya sistem verileri alınamadı: " . $e->getMessage() . "</div>";
        $totalTests++;
    }
    echo "</div>";
    
    // 7. Holiday System Check
    echo "<div class='section'>";
    echo "<h2>🏖️ Tatil Sistemi</h2>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_weekly_holidays");
        $holidayCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $stmt = $conn->query("
            SELECT 
                SUM(monday + tuesday + wednesday + thursday + friday + saturday + sunday) as total_holidays,
                COUNT(*) as total_employees
            FROM employee_weekly_holidays
        ");
        $holidayStats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<div class='success'>✅ Tatil tanımlı personel sayısı: $holidayCount</div>";
        if ($holidayStats['total_employees'] > 0) {
            $avgHolidays = round($holidayStats['total_holidays'] / $holidayStats['total_employees'], 1);
            echo "<div class='success'>✅ Ortalama haftalık tatil: $avgHolidays gün</div>";
        }
        
        $totalTests += 2;
        $passedTests += 2;
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Tatil sistem verileri alınamadı: " . $e->getMessage() . "</div>";
        $totalTests++;
    }
    echo "</div>";
    
    // Final Summary
    echo "<div class='section'>";
    echo "<h2>📋 Genel Sonuç</h2>";
    
    $successRate = $totalTests > 0 ? round(($passedTests / $totalTests) * 100, 1) : 0;
    
    if ($successRate >= 90) {
        echo "<div class='success'>";
        echo "<h3>🎉 SİSTEM TAM ÇALIŞIR DURUMDA</h3>";
        echo "<p><strong>Başarı Oranı:</strong> $successRate% ($passedTests/$totalTests)</p>";
        echo "<p>Tüm temel sistem bileşenleri doğru çalışıyor.</p>";
        echo "</div>";
    } elseif ($successRate >= 70) {
        echo "<div class='warning'>";
        echo "<h3>⚠️ SİSTEM BÜYÜK ÖLÇÜDE ÇALIŞIYOR</h3>";
        echo "<p><strong>Başarı Oranı:</strong> $successRate% ($passedTests/$totalTests)</p>";
        echo "<p>Bazı küçük sorunlar var ama genel işlevsellik sağlam.</p>";
        echo "</div>";
    } else {
        echo "<div class='error'>";
        echo "<h3>❌ SİSTEMDE CİDDİ SORUNLAR VAR</h3>";
        echo "<p><strong>Başarı Oranı:</strong> $successRate% ($passedTests/$totalTests)</p>";
        echo "<p>Önemli sistem bileşenlerinde sorunlar mevcut.</p>";
        echo "</div>";
    }
    echo "</div>";
    
    // Action Links
    echo "<div class='section'>";
    echo "<h2>🔧 Hızlı Eylemler</h2>";
    echo "<div style='display: flex; gap: 10px; flex-wrap: wrap;'>";
    echo "<a href='../admin/index.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Admin Panel</a>";
    echo "<a href='../employee/dashboard.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Personel Panel</a>";
    echo "<a href='../admin/company-holiday-management.php' style='background: #ffc107; color: black; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Tatil Yönetimi</a>";
    echo "<a href='../qr/qr-scanner.php' style='background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>QR Tarayıcı</a>";
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Sistem Kontrolü Hatası</h2>";
    echo "<p>Kontrol sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>