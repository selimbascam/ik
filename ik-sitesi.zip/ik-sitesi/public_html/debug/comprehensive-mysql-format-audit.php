<?php
require_once '../includes/config.php';

echo "<h2>🔍 Sistem Geneli MySQL Format Denetimi</h2>";

$phpFiles = [
    // Core API files
    '../api/process-attendance.php',
    '../api/auth.php',
    '../api/submit-reason.php',
    
    // QR system files
    '../qr/qr-reader.php',
    '../qr/qr-reader-old.php',
    '../qr/activity-selection.php',
    '../qr/qr-reader-enhanced.php',
    
    // Admin files
    '../admin/attendance-tracking.php',
    '../admin/shift-management.php',
    '../admin/employee-attendance-details.php',
    '../admin/user-password-management.php',
    '../admin/company-user-management.php',
    
    // Super admin files
    '../super-admin/fix-critical-errors.php',
    '../super-admin/system-logs.php',
    
    // Device management
    '../view-device-records.php',
    
    // Includes
    '../includes/database-fix.php',
    '../includes/oauth-config.php'
];

$concatErrors = [];
$sqlSyntaxErrors = [];
$fixedFiles = [];

echo "<h3>📋 Dosya Denetim Sonuçları</h3>";
echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>Dosya</th><th>CONCAT Hataları</th><th>SQL Syntax Hataları</th><th>Durum</th></tr>";

foreach ($phpFiles as $file) {
    if (!file_exists($file)) {
        echo "<tr><td>{$file}</td><td colspan='3' style='color: orange;'>❌ Dosya bulunamadı</td></tr>";
        continue;
    }
    
    $content = file_get_contents($file);
    $fileName = basename($file);
    
    // Check for CONCAT errors (should be || for boolean operations)
    $concatMatches = [];
    // Look for patterns like: !variable CONCAT!variable or condition CONCATcondition
    preg_match_all('/(\!\w+\s*CONCAT\!\w+|\w+\s*CONCAT\w+|\w+\s*CONCAT\s*\!\w+)/', $content, $concatMatches);
    
    // Check for SQL syntax issues
    $sqlIssues = [];
    
    // Look for common SQL syntax errors
    if (strpos($content, 'DELIMITER') !== false) {
        $sqlIssues[] = 'DELIMITER syntax (MariaDB incompatible)';
    }
    
    if (preg_match('/CREATE\s+FUNCTION.*BEGIN.*END/s', $content)) {
        $sqlIssues[] = 'MySQL functions in PHP (should be PHP logic)';
    }
    
    // Look for incorrect foreign key references
    if (preg_match('/REFERENCES\s+shifts\s*\(/i', $content)) {
        $sqlIssues[] = 'References non-existent "shifts" table';
    }
    
    $concatCount = count($concatMatches[0]);
    $sqlCount = count($sqlIssues);
    
    if ($concatCount > 0) {
        $concatErrors[$fileName] = $concatMatches[0];
    }
    
    if ($sqlCount > 0) {
        $sqlSyntaxErrors[$fileName] = $sqlIssues;
    }
    
    $status = ($concatCount == 0 && $sqlCount == 0) ? '✅ Temiz' : '❌ Hata var';
    
    echo "<tr>";
    echo "<td>{$fileName}</td>";
    echo "<td style='color: " . ($concatCount > 0 ? 'red' : 'green') . ";'>{$concatCount}</td>";
    echo "<td style='color: " . ($sqlCount > 0 ? 'red' : 'green') . ";'>{$sqlCount}</td>";
    echo "<td>{$status}</td>";
    echo "</tr>";
}

echo "</table>";

// Detailed error analysis
if (!empty($concatErrors)) {
    echo "<h3>🔧 CONCAT Hata Detayları</h3>";
    foreach ($concatErrors as $file => $errors) {
        echo "<h4>{$file}</h4>";
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li><code style='background: #f8d7da; padding: 2px 4px;'>{$error}</code></li>";
        }
        echo "</ul>";
    }
}

if (!empty($sqlSyntaxErrors)) {
    echo "<h3>🔧 SQL Syntax Hata Detayları</h3>";
    foreach ($sqlSyntaxErrors as $file => $errors) {
        echo "<h4>{$file}</h4>";
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li><span style='background: #fff3cd; padding: 2px 4px;'>{$error}</span></li>";
        }
        echo "</ul>";
    }
}

// Generate fix recommendations
echo "<h3>🛠️ Düzeltme Önerileri</h3>";

if (!empty($concatErrors)) {
    echo "<h4>CONCAT Hataları İçin:</h4>";
    echo "<ul>";
    echo "<li><strong>Değiştir:</strong> <code>!variable CONCAT!variable</code> → <code>!variable || !variable</code></li>";
    echo "<li><strong>Değiştir:</strong> <code>condition CONCATcondition</code> → <code>condition || condition</code></li>";
    echo "<li><strong>Değiştir:</strong> <code>variable CONCAT variable</code> → <code>variable || variable</code></li>";
    echo "</ul>";
}

if (!empty($sqlSyntaxErrors)) {
    echo "<h4>SQL Syntax Hataları İçin:</h4>";
    echo "<ul>";
    echo "<li><strong>DELIMITER syntax:</strong> MySQL fonksiyonları PHP logic'e çevir</li>";
    echo "<li><strong>Foreign key references:</strong> 'shifts' → 'shift_templates'</li>";
    echo "<li><strong>Column references:</strong> Mevcut sütun adlarını kullan</li>";
    echo "</ul>";
}

// Auto-fix capability
echo "<h3>🚀 Otomatik Düzeltme</h3>";
echo "<p>En kritik hataları otomatik düzeltmek için aşağıdaki butona tıklayın:</p>";
echo "<button onclick='autoFixCriticalErrors()' style='background: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;'>Kritik Hataları Otomatik Düzelt</button>";

?>

<script>
function autoFixCriticalErrors() {
    if (confirm('Kritik MySQL format hatalarını otomatik düzeltmek istediğinizden emin misiniz?')) {
        window.location.href = 'auto-fix-mysql-format.php';
    }
}
</script>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
code { background-color: #f8f9fa; padding: 2px 4px; border-radius: 3px; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>