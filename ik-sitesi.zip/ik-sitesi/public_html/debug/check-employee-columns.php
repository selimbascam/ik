<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check employee table structure
    $stmt = $conn->query("SHOW COLUMNS FROM employees");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Employees Tablosu Kolonları:</h3>";
    echo "<ul>";
    foreach ($columns as $column) {
        echo "<li>" . $column['Field'] . " (" . $column['Type'] . ")</li>";
    }
    echo "</ul>";
    
    // Check sample data
    $stmt = $conn->query("SELECT * FROM employees LIMIT 3");
    $samples = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Örnek Veriler:</h3>";
    if (!empty($samples)) {
        echo "<table border='1'>";
        echo "<tr>";
        foreach (array_keys($samples[0]) as $key) {
            echo "<th>$key</th>";
        }
        echo "</tr>";
        
        foreach ($samples as $row) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars($value ?: '') . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "Hata: " . $e->getMessage();
}
?>