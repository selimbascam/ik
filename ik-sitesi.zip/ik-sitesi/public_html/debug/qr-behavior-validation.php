<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/qr-attendance-fixed.php';

// Allow super admin access
if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    // Set session for testing
    $_SESSION['company_id'] = 4; // SZB company
    $_SESSION['employee_id'] = 1; // Default employee
}

$company_id = $_SESSION['company_id'] ?? 4;
$employee_id = $_SESSION['employee_id'] ?? 1;

$validation_results = [];

// Get actual QR locations from the system
try {
    $locations_stmt = $pdo->prepare("
        SELECT id, location_name, gate_behavior, qr_code_data, is_active, created_at
        FROM qr_locations 
        WHERE company_id = ? 
        ORDER BY gate_behavior, location_name
    ");
    $locations_stmt->execute([$company_id]);
    $locations = $locations_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $validation_results['locations_found'] = count($locations);
    $validation_results['locations'] = $locations;
    
} catch (Exception $e) {
    $validation_results['locations_error'] = $e->getMessage();
    $locations = [];
}

// Get attendance activities
try {
    $activities_stmt = $pdo->prepare("SELECT id, activity_name FROM attendance_activities ORDER BY activity_name");
    $activities_stmt->execute();
    $activities = $activities_stmt->fetchAll(PDO::FETCH_ASSOC);
    $validation_results['activities'] = $activities;
    
} catch (Exception $e) {
    $validation_results['activities_error'] = $e->getMessage();
}

// Test each gate behavior systematically
$behavior_tests = [];

foreach (['work_start', 'work_end', 'break_toggle', 'user_choice'] as $behavior) {
    $behavior_locations = array_filter($locations, function($loc) use ($behavior) {
        return $loc['gate_behavior'] === $behavior;
    });
    
    if (empty($behavior_locations)) {
        $behavior_tests[$behavior] = [
            'status' => 'no_locations',
            'message' => "No QR locations found with $behavior behavior"
        ];
        continue;
    }
    
    // Test with first location of this behavior
    $test_location = array_values($behavior_locations)[0];
    
    try {
        $helper = new QRAttendanceHelper($pdo);
        
        // Test gate action determination
        $gate_action = QRAttendanceHelper::determineGateAction(
            $pdo, 
            $employee_id, 
            $company_id, 
            $test_location['id'], 
            $behavior
        );
        
        // Validate expected vs actual
        $expected = '';
        $is_correct = false;
        
        switch ($behavior) {
            case 'work_start':
                $expected = 'work_start';
                $is_correct = ($gate_action === 'work_start');
                break;
                
            case 'work_end':
                $expected = 'work_end';
                $is_correct = ($gate_action === 'work_end');
                break;
                
            case 'break_toggle':
                $expected = 'break_start or break_end (context dependent)';
                $is_correct = in_array($gate_action, ['break_start', 'break_end']);
                break;
                
            case 'user_choice':
                $expected = 'context dependent (work_start, work_end, break_start, break_end)';
                $is_correct = in_array($gate_action, ['work_start', 'work_end', 'break_start', 'break_end']);
                break;
        }
        
        $behavior_tests[$behavior] = [
            'status' => $is_correct ? 'pass' : 'fail',
            'location_tested' => $test_location['location_name'],
            'expected' => $expected,
            'actual' => $gate_action,
            'is_correct' => $is_correct,
            'total_locations' => count($behavior_locations)
        ];
        
    } catch (Exception $e) {
        $behavior_tests[$behavior] = [
            'status' => 'error',
            'error' => $e->getMessage(),
            'location_tested' => $test_location['location_name']
        ];
    }
}

// Get today's attendance records to show current state
try {
    $today = date('Y-m-d');
    $today_records_stmt = $pdo->prepare("
        SELECT ar.*, aa.activity_name, ql.location_name as qr_location_name
        FROM attendance_records ar
        LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ? AND DATE(ar.created_at) = ?
        ORDER BY ar.created_at ASC
    ");
    $today_records_stmt->execute([$employee_id, $today]);
    $today_records = $today_records_stmt->fetchAll(PDO::FETCH_ASSOC);
    $validation_results['todays_records'] = $today_records;
    
} catch (Exception $e) {
    $validation_results['todays_records_error'] = $e->getMessage();
}

// Summary
$total_behaviors = 4;
$passing_behaviors = count(array_filter($behavior_tests, function($test) {
    return $test['status'] === 'pass';
}));

$validation_results['summary'] = [
    'total_behaviors' => $total_behaviors,
    'passing_behaviors' => $passing_behaviors,
    'success_rate' => round(($passing_behaviors / $total_behaviors) * 100, 1),
    'timestamp' => date('Y-m-d H:i:s')
];

// JSON output for API
if (isset($_GET['format']) && $_GET['format'] === 'json') {
    header('Content-Type: application/json');
    echo json_encode([
        'validation_results' => $validation_results,
        'behavior_tests' => $behavior_tests
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Behavior Validation</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen py-8">
    <div class="container mx-auto px-4">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h1 class="text-2xl font-bold text-gray-900 mb-2">✅ QR Behavior Validation</h1>
            <p class="text-gray-600">
                Gate behavior fix doğrulaması - Company ID: <?= $company_id ?>, Employee ID: <?= $employee_id ?>
            </p>
            <div class="mt-2 text-sm text-gray-500">
                Test Zamanı: <?= $validation_results['summary']['timestamp'] ?>
            </div>
        </div>

        <!-- Summary -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📊 Özet</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="p-4 bg-blue-50 rounded-lg text-center">
                    <div class="text-2xl font-bold text-blue-900"><?= $validation_results['summary']['passing_behaviors'] ?>/<?= $validation_results['summary']['total_behaviors'] ?></div>
                    <div class="text-sm text-blue-700">Geçen Behavior</div>
                </div>
                
                <div class="p-4 bg-green-50 rounded-lg text-center">
                    <div class="text-2xl font-bold text-green-900"><?= $validation_results['summary']['success_rate'] ?>%</div>
                    <div class="text-sm text-green-700">Başarı Oranı</div>
                </div>
                
                <div class="p-4 bg-yellow-50 rounded-lg text-center">
                    <div class="text-2xl font-bold text-yellow-900"><?= $validation_results['locations_found'] ?></div>
                    <div class="text-sm text-yellow-700">QR Lokasyonu</div>
                </div>
                
                <div class="p-4 bg-purple-50 rounded-lg text-center">
                    <div class="text-2xl font-bold text-purple-900"><?= count($validation_results['todays_records'] ?? []) ?></div>
                    <div class="text-sm text-purple-700">Bugünkü Kayıt</div>
                </div>
            </div>
        </div>

        <!-- Behavior Tests -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">🧪 Gate Behavior Test Sonuçları</h3>
            
            <div class="space-y-4">
                <?php foreach ($behavior_tests as $behavior => $test): ?>
                <div class="p-4 border rounded-lg <?= 
                    $test['status'] === 'pass' ? 'border-green-300 bg-green-50' : 
                    ($test['status'] === 'fail' ? 'border-red-300 bg-red-50' : 
                    ($test['status'] === 'error' ? 'border-red-300 bg-red-50' : 'border-yellow-300 bg-yellow-50'))
                ?>">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h4 class="font-semibold text-gray-900">
                                <?= htmlspecialchars($behavior) ?>
                                <?php if ($test['status'] === 'pass'): ?>
                                    <span class="text-green-600">✅</span>
                                <?php elseif ($test['status'] === 'fail'): ?>
                                    <span class="text-red-600">❌</span>
                                <?php elseif ($test['status'] === 'error'): ?>
                                    <span class="text-red-600">⚠️</span>
                                <?php else: ?>
                                    <span class="text-yellow-600">➖</span>
                                <?php endif; ?>
                            </h4>
                            
                            <?php if (isset($test['location_tested'])): ?>
                            <div class="text-sm text-gray-600">
                                Test Lokasyonu: <?= htmlspecialchars($test['location_tested']) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="text-xs text-gray-500">
                            <?= $test['total_locations'] ?? 0 ?> lokasyon
                        </div>
                    </div>
                    
                    <?php if ($test['status'] === 'pass' || $test['status'] === 'fail'): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                            <strong>Beklenen:</strong> <?= htmlspecialchars($test['expected']) ?>
                        </div>
                        <div>
                            <strong>Sonuç:</strong> 
                            <code class="bg-gray-100 px-1 rounded"><?= htmlspecialchars($test['actual']) ?></code>
                        </div>
                    </div>
                    <?php elseif ($test['status'] === 'error'): ?>
                    <div class="text-sm text-red-700">
                        <strong>Hata:</strong> <?= htmlspecialchars($test['error']) ?>
                    </div>
                    <?php elseif ($test['status'] === 'no_locations'): ?>
                    <div class="text-sm text-yellow-700">
                        <?= htmlspecialchars($test['message']) ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- QR Locations -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📍 Sistem QR Lokasyonları</h3>
            
            <?php if (!empty($validation_results['locations'])): ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left">Lokasyon</th>
                            <th class="px-4 py-2 text-left">Gate Behavior</th>
                            <th class="px-4 py-2 text-left">Durum</th>
                            <th class="px-4 py-2 text-left">Oluşturulma</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($validation_results['locations'] as $location): ?>
                        <tr>
                            <td class="px-4 py-2 font-medium"><?= htmlspecialchars($location['location_name']) ?></td>
                            <td class="px-4 py-2">
                                <code class="bg-gray-100 px-2 py-1 rounded text-xs">
                                    <?= htmlspecialchars($location['gate_behavior']) ?>
                                </code>
                            </td>
                            <td class="px-4 py-2">
                                <?= $location['is_active'] ? '✅ Aktif' : '❌ Pasif' ?>
                            </td>
                            <td class="px-4 py-2 text-gray-600">
                                <?= date('d.m.Y H:i', strtotime($location['created_at'])) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="text-center py-8 text-gray-500">
                QR lokasyonu bulunamadı
            </div>
            <?php endif; ?>
        </div>

        <!-- Today's Records -->
        <?php if (!empty($validation_results['todays_records'])): ?>
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📅 Bugünkü Kayıtlar</h3>
            
            <div class="space-y-2">
                <?php foreach ($validation_results['todays_records'] as $record): ?>
                <div class="p-3 bg-gray-50 rounded flex justify-between items-center">
                    <div>
                        <div class="font-medium"><?= htmlspecialchars($record['activity_name']) ?></div>
                        <div class="text-sm text-gray-600">
                            <?= htmlspecialchars($record['qr_location_name']) ?>
                        </div>
                    </div>
                    <div class="text-sm text-gray-500">
                        <?= date('H:i:s', strtotime($record['created_at'])) ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Actions -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">🔧 Aksiyonlar</h3>
            
            <div class="flex flex-wrap gap-3">
                <button onclick="window.location.reload()" 
                        class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    🔄 Yenile
                </button>
                
                <a href="?format=json" target="_blank"
                   class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 inline-block">
                    📄 JSON Rapor
                </a>
                
                <a href="test-gate-behaviors-direct.php"
                   class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 inline-block">
                    🧪 Direkt Test
                </a>
                
                <a href="../super-admin/system-tools/comprehensive-analysis.php"
                   class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 inline-block">
                    📊 Tam Analiz
                </a>
            </div>
        </div>
    </div>
</body>
</html>