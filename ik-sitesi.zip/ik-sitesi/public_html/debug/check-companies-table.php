<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔍 Companies Tablo Yapısı</h1>";
echo "<style>body{font-family:Arial;margin:20px;} table{border-collapse:collapse;} th,td{border:1px solid #ccc;padding:8px;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📊 Companies Tablo Sütunları</h2>";
    $stmt = $conn->query("DESCRIBE companies");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table>";
    echo "<tr><th>Sütun Adı</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td style='font-weight:bold;'>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Key']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h2>📋 Sample Data</h2>";
    $stmt = $conn->query("SELECT * FROM companies LIMIT 3");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($companies) {
        echo "<table>";
        echo "<tr>";
        foreach (array_keys($companies[0]) as $key) {
            echo "<th>$key</th>";
        }
        echo "</tr>";
        foreach ($companies as $company) {
            echo "<tr>";
            foreach ($company as $value) {
                echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Hiç şirket verisi bulunamadı.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red;'>Hata: " . $e->getMessage() . "</p>";
}
?>