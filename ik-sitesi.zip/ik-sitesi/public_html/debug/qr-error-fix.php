<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>QR Hata Düzeltme</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .success { background: #d1fae5; color: #065f46; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { background: #dbeafe; color: #1e40af; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .warning { background: #fef3c7; color: #92400e; padding: 10px; border-radius: 5px; margin: 10px 0; }
        pre { background: #f3f4f6; padding: 10px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>🔧 QR Hata Düzeltme Aracı</h1>
    
    <?php
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        echo "<div class='info'>✅ Veritabanı bağlantısı başarılı</div>";
        
        // 1. Check if attendance_records table exists and has proper structure
        echo "<h2>1️⃣ Attendance Records Tablosu Kontrolü</h2>";
        
        $stmt = $conn->query("SHOW TABLES LIKE 'attendance_records'");
        if ($stmt->rowCount() == 0) {
            echo "<div class='error'>❌ attendance_records tablosu bulunamadı. Oluşturuluyor...</div>";
            
            $createTable = "
                CREATE TABLE attendance_records (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    employee_id INT NOT NULL,
                    company_id INT NOT NULL,
                    check_date DATE NOT NULL,
                    check_in_time DATETIME NULL,
                    check_out_time DATETIME NULL,
                    break_start_time DATETIME NULL,
                    break_end_time DATETIME NULL,
                    location VARCHAR(255) NULL,
                    location_id INT NULL,
                    work_minutes INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_employee_date (employee_id, check_date),
                    INDEX idx_company (company_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ";
            
            $conn->exec($createTable);
            echo "<div class='success'>✅ attendance_records tablosu oluşturuldu</div>";
        } else {
            echo "<div class='success'>✅ attendance_records tablosu mevcut</div>";
        }
        
        // Check columns
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='info'><strong>Mevcut sütunlar:</strong> " . implode(', ', $columns) . "</div>";
        
        // 2. Check if qr_locations table exists
        echo "<h2>2️⃣ QR Locations Tablosu Kontrolü</h2>";
        
        $stmt = $conn->query("SHOW TABLES LIKE 'qr_locations'");
        if ($stmt->rowCount() == 0) {
            echo "<div class='error'>❌ qr_locations tablosu bulunamadı. Oluşturuluyor...</div>";
            
            $createQRTable = "
                CREATE TABLE qr_locations (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    name VARCHAR(255) NOT NULL,
                    location_type VARCHAR(50) DEFAULT 'general_gate',
                    gate_behavior VARCHAR(50) DEFAULT 'user_choice',
                    latitude DECIMAL(10, 8) NULL,
                    longitude DECIMAL(11, 8) NULL,
                    radius INT DEFAULT 100,
                    is_active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_company (company_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ";
            
            $conn->exec($createQRTable);
            echo "<div class='success'>✅ qr_locations tablosu oluşturuldu</div>";
            
            // Insert sample data
            $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, location_type, gate_behavior) VALUES (?, ?, ?, ?)");
            $stmt->execute([1, 'Ana Giriş Kapısı', 'entrance_gate', 'work_start']);
            $stmt->execute([1, 'Mola Alanı', 'break_gate', 'break_toggle']);
            $stmt->execute([1, 'Çıkış Kapısı', 'exit_gate', 'work_end']);
            
            echo "<div class='success'>✅ Örnek QR lokasyonları eklendi</div>";
        } else {
            echo "<div class='success'>✅ qr_locations tablosu mevcut</div>";
        }
        
        // Check QR locations
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations");
        $qrCount = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='info'><strong>QR lokasyon sayısı:</strong> " . $qrCount['count'] . "</div>";
        
        // 3. Check if employees table exists
        echo "<h2>3️⃣ Employees Tablosu Kontrolü</h2>";
        
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employees");
        $empCount = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<div class='info'><strong>Personel sayısı:</strong> " . $empCount['count'] . "</div>";
        
        if ($empCount['count'] == 0) {
            echo "<div class='warning'>⚠️ Test personeli oluşturuluyor...</div>";
            
            $stmt = $conn->prepare("
                INSERT INTO employees (company_id, employee_code, first_name, last_name, email, password_hash, is_active) 
                VALUES (?, ?, ?, ?, ?, PASSWORD(?), ?)
            ");
            $stmt->execute([1, 'TEST001', 'Test', 'Personel', 'test@test.com', '123456', 1]);
            
            echo "<div class='success'>✅ Test personeli oluşturuldu (Kod: TEST001, Şifre: 123456)</div>";
        }
        
        // 4. Test QR session setup
        echo "<h2>4️⃣ QR Session Test</h2>";
        
        $_SESSION['employee_id'] = 1;
        $_SESSION['company_id'] = 1;
        $_SESSION['user_role'] = 'employee';
        
        echo "<div class='success'>✅ Test session oluşturuldu</div>";
        
        echo "<div class='success'>🎉 Tüm düzeltmeler tamamlandı! QR sistemi çalışmaya hazır.</div>";
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Hata: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
    ?>
    
    <div style="margin-top: 20px;">
        <a href="../test-employee-qr.php" style="background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🔙 QR Test Sayfası</a>
        <a href="../qr/qr-reader.php" style="background: #10b981; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">📱 QR Okuyucu</a>
    </div>
</body>
</html>