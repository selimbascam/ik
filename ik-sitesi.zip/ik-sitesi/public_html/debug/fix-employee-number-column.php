<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔧 Employee Number Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check current table structure
    echo "<h3>📊 Current Table Structure</h3>";
    $result = $conn->query("DESCRIBE employees");
    $columns = [];
    while ($column = $result->fetch()) {
        $columns[$column['Field']] = $column;
    }
    
    $hasEmployeeNumber = isset($columns['employee_number']);
    
    if ($hasEmployeeNumber) {
        echo "<p style='color: green;'>✅ employee_number column already exists</p>";
    } else {
        echo "<p style='color: red;'>❌ employee_number column missing - adding now...</p>";
        
        // Add employee_number column
        $conn->query("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
        echo "<p style='color: green;'>✅ Added employee_number column</p>";
        
        // Generate employee numbers for existing employees
        $stmt = $conn->prepare("SELECT id FROM employees ORDER BY id");
        $stmt->execute();
        $employees = $stmt->fetchAll();
        
        $count = 0;
        foreach ($employees as $employee) {
            $employeeNumber = 'EMP' . str_pad($employee['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            if ($updateStmt->execute([$employeeNumber, $employee['id']])) {
                $count++;
            }
        }
        
        echo "<p style='color: green;'>✅ Generated employee numbers for $count employees</p>";
    }
    
    // Also add other commonly needed columns
    $neededColumns = [
        'employee_code' => "VARCHAR(20) AFTER employee_number",
        'is_active' => "TINYINT(1) DEFAULT 1 AFTER status"
    ];
    
    foreach ($neededColumns as $colName => $colDef) {
        if (!isset($columns[$colName])) {
            try {
                $conn->query("ALTER TABLE employees ADD COLUMN $colName $colDef");
                echo "<p style='color: green;'>✅ Added $colName column</p>";
            } catch (Exception $e) {
                echo "<p style='color: orange;'>⚠️ Could not add $colName: " . $e->getMessage() . "</p>";
            }
        }
    }
    
    // Test the fix with actual queries from problem pages
    echo "<h3>🧪 Testing Problem Queries</h3>";
    
    // Test employee attendance list query
    try {
        $testQuery = "SELECT 
                        e.id,
                        e.first_name,
                        e.last_name,
                        e.employee_number,
                        d.name as department_name
                      FROM employees e
                      LEFT JOIN departments d ON e.department_id = d.id
                      WHERE e.company_id = ?
                      LIMIT 1";
        
        $stmt = $conn->prepare($testQuery);
        $stmt->execute([1]);
        $testResult = $stmt->fetch();
        
        if ($testResult) {
            echo "<p style='color: green;'>✅ Employee attendance list query works</p>";
            echo "<p>Sample: {$testResult['employee_number']} - {$testResult['first_name']} {$testResult['last_name']}</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ No employees found for testing</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Test query failed: " . $e->getMessage() . "</p>";
    }
    
    // Test shift management query
    try {
        $testQuery2 = "SELECT 
                         id, 
                         COALESCE(first_name, '') as first_name, 
                         COALESCE(last_name, '') as last_name, 
                         COALESCE(employee_number, CONCAT('EMP', LPAD(id, 4, '0'))) as employee_number
                       FROM employees 
                       WHERE company_id = ? 
                       LIMIT 1";
        
        $stmt2 = $conn->prepare($testQuery2);
        $stmt2->execute([1]);
        $testResult2 = $stmt2->fetch();
        
        if ($testResult2) {
            echo "<p style='color: green;'>✅ Shift management query works</p>";
            echo "<p>Sample: {$testResult2['employee_number']} - {$testResult2['first_name']} {$testResult2['last_name']}</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Shift management test failed: " . $e->getMessage() . "</p>";
    }
    
    // Create sample employees if none exist
    $stmt = $conn->prepare("SELECT COUNT(*) FROM employees WHERE company_id = ?");
    $stmt->execute([1]);
    $employeeCount = $stmt->fetchColumn();
    
    if ($employeeCount == 0) {
        echo "<h3>👤 Creating Sample Employees</h3>";
        
        // Create sample employees
        $sampleEmployees = [
            ['Ahmet', 'Yılmaz', 'ahmet.yilmaz@demo.com'],
            ['Elif', 'Kaya', 'elif.kaya@demo.com'],
            ['Mehmet', 'Demir', 'mehmet.demir@demo.com']
        ];
        
        foreach ($sampleEmployees as $i => $emp) {
            $empNumber = 'EMP' . str_pad($i + 1, 4, '0', STR_PAD_LEFT);
            $insertStmt = $conn->prepare("
                INSERT INTO employees (company_id, first_name, last_name, email, employee_number, is_active, status) 
                VALUES (?, ?, ?, ?, ?, 1, 'active')
            ");
            $insertStmt->execute([1, $emp[0], $emp[1], $emp[2], $empNumber]);
        }
        
        echo "<p style='color: green;'>✅ Created 3 sample employees</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Critical Error: " . $e->getMessage() . "</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<h3>✅ Fix Complete</h3>";
echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>What was fixed:</h4>";
echo "<ul>";
echo "<li>✅ Added employee_number column to employees table</li>";
echo "<li>✅ Generated unique employee numbers (EMP0001, EMP0002, etc.)</li>";
echo "<li>✅ Added supporting columns (employee_code, is_active)</li>";
echo "<li>✅ Tested problematic queries</li>";
echo "<li>✅ Created sample employees if needed</li>";
echo "</ul>";
echo "</div>";

echo "<h3>🔗 Test Fixed Pages</h3>";
echo "<div>";
echo "<a href='../admin/employee-attendance-list.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Employee Attendance List</a>";
echo "<a href='../admin/shift-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Shift Management</a>";
echo "<a href='../admin/employee-management.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Employee Management</a>";
echo "<a href='../admin/dashboard.php' style='background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
pre { background: #f8f9fa; padding: 10px; border-radius: 5px; overflow-x: auto; }
</style>