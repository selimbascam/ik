<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

session_start();

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Device Records Tanı ve Düzeltme</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100'>
    <div class='container mx-auto px-4 py-8 max-w-4xl'>
        <div class='bg-white rounded-lg shadow-lg p-6'>
            <h1 class='text-2xl font-bold text-gray-900 mb-6'>📱 Cihaz Kayıtları Tanı ve Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-6'>";
    
    // 1. Check device_records table
    echo "<div class='border-l-4 border-blue-500 bg-blue-50 p-4'>
            <h2 class='text-lg font-semibold text-blue-800'>1. Cihaz Kayıtları Tablo Kontrol</h2>";
    
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'device_records'");
        if ($stmt->rowCount() > 0) {
            echo "<p class='text-green-600'>✅ device_records tablosu mevcut</p>";
            
            // Check table structure
            $stmt = $conn->query("DESCRIBE device_records");
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo "<p class='text-sm text-gray-600 mb-2'>Tablo yapısı:</p>
                  <ul class='list-disc list-inside ml-4 text-xs space-y-1'>";
            foreach ($columns as $column) {
                echo "<li><strong>{$column['Field']}</strong>: {$column['Type']}" . 
                     ($column['Null'] == 'NO' ? ' (Zorunlu)' : ' (İsteğe Bağlı)') . "</li>";
            }
            echo "</ul>";
            
            // Check record count
            $stmt = $conn->query("SELECT COUNT(*) as count FROM device_records");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p class='text-sm mt-2'>Toplam kayıt: <span class='font-medium'>$count</span></p>";
            
        } else {
            echo "<p class='text-red-600'>❌ device_records tablosu bulunamadı</p>";
            echo "<p class='text-orange-600 text-sm mt-2'>Bu tabloyu oluşturmak için aşağıdaki düzeltme butonunu kullanın.</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Tablo kontrol hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 2. Check employee_devices table
    echo "<div class='border-l-4 border-green-500 bg-green-50 p-4'>
            <h2 class='text-lg font-semibold text-green-800'>2. Employee Devices Tablo Kontrol</h2>";
    
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'employee_devices'");
        if ($stmt->rowCount() > 0) {
            echo "<p class='text-green-600'>✅ employee_devices tablosu mevcut</p>";
            
            $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_devices");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p class='text-sm'>Kayıtlı cihaz sayısı: <span class='font-medium'>$count</span></p>";
        } else {
            echo "<p class='text-red-600'>❌ employee_devices tablosu bulunamadı</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Employee devices kontrol hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 3. Check device_security_logs table
    echo "<div class='border-l-4 border-purple-500 bg-purple-50 p-4'>
            <h2 class='text-lg font-semibold text-purple-800'>3. Device Security Logs Tablo Kontrol</h2>";
    
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'device_security_logs'");
        if ($stmt->rowCount() > 0) {
            echo "<p class='text-green-600'>✅ device_security_logs tablosu mevcut</p>";
            
            $stmt = $conn->query("SELECT COUNT(*) as count FROM device_security_logs");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p class='text-sm'>Güvenlik log sayısı: <span class='font-medium'>$count</span></p>";
        } else {
            echo "<p class='text-red-600'>❌ device_security_logs tablosu bulunamadı</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Security logs kontrol hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 4. Check related tables (companies, employees, qr_locations)
    echo "<div class='border-l-4 border-indigo-500 bg-indigo-50 p-4'>
            <h2 class='text-lg font-semibold text-indigo-800'>4. İlgili Tabolar Kontrol</h2>";
    
    $relatedTables = ['companies', 'employees', 'qr_locations'];
    foreach ($relatedTables as $table) {
        try {
            $stmt = $conn->query("SHOW TABLES LIKE '$table'");
            if ($stmt->rowCount() > 0) {
                $stmt = $conn->query("SELECT COUNT(*) as count FROM $table");
                $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                echo "<p class='text-green-600'>✅ $table tablosu mevcut ($count kayıt)</p>";
            } else {
                echo "<p class='text-red-600'>❌ $table tablosu bulunamadı</p>";
            }
        } catch (Exception $e) {
            echo "<p class='text-red-600'>❌ $table kontrol hatası: " . $e->getMessage() . "</p>";
        }
    }
    echo "</div>";
    
    // 5. Test device tracking API
    echo "<div class='border-l-4 border-orange-500 bg-orange-50 p-4'>
            <h2 class='text-lg font-semibold text-orange-800'>5. Device Tracking API Test</h2>";
    
    $apiPath = '../api/record-device-info.php';
    if (file_exists($apiPath)) {
        echo "<p class='text-green-600'>✅ Device tracking API dosyası mevcut</p>";
        
        // Check PHP syntax
        $output = shell_exec("php -l $apiPath 2>&1");
        if (strpos($output, 'No syntax errors') !== false) {
            echo "<p class='text-green-600'>✅ API syntax kontrol: OK</p>";
        } else {
            echo "<p class='text-red-600'>❌ API syntax hatası: $output</p>";
        }
    } else {
        echo "<p class='text-red-600'>❌ Device tracking API dosyası bulunamadı</p>";
    }
    echo "</div>";
    
    // 6. Auto-fix actions
    echo "<div class='border-l-4 border-red-500 bg-red-50 p-4'>
            <h2 class='text-lg font-semibold text-red-800'>6. Otomatik Düzeltme İşlemleri</h2>";
    
    if (isset($_POST['fix_action'])) {
        $action = $_POST['fix_action'];
        
        if ($action === 'create_device_tables') {
            try {
                // Create device_records table
                $conn->exec("CREATE TABLE IF NOT EXISTS device_records (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    employee_id INT,
                    session_id VARCHAR(100),
                    device_fingerprint VARCHAR(255),
                    ip_address VARCHAR(45),
                    mac_address VARCHAR(17),
                    user_agent TEXT,
                    device_type VARCHAR(50),
                    browser_name VARCHAR(50),
                    operating_system VARCHAR(50),
                    screen_resolution VARCHAR(20),
                    timezone_offset INT,
                    latitude DECIMAL(10, 8),
                    longitude DECIMAL(11, 8),
                    location_accuracy DECIMAL(10, 2),
                    location_timestamp TIMESTAMP,
                    qr_location_id INT,
                    action_type ENUM('checkin', 'checkout', 'break_start', 'break_end') NOT NULL,
                    success BOOLEAN DEFAULT TRUE,
                    error_message TEXT,
                    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_employee_date (employee_id, created_at),
                    INDEX idx_ip_address (ip_address),
                    INDEX idx_device_fingerprint (device_fingerprint)
                )");
                
                echo "<p class='text-green-600'>✅ device_records tablosu oluşturuldu</p>";
                
                // Create employee_devices table
                $conn->exec("CREATE TABLE IF NOT EXISTS employee_devices (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    employee_id INT NOT NULL,
                    device_fingerprint VARCHAR(255) NOT NULL,
                    device_name VARCHAR(100),
                    device_type VARCHAR(50),
                    first_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    is_trusted BOOLEAN DEFAULT FALSE,
                    is_blocked BOOLEAN DEFAULT FALSE,
                    usage_count INT DEFAULT 1,
                    notes TEXT,
                    trust_granted_by INT,
                    trust_granted_at TIMESTAMP NULL,
                    UNIQUE KEY unique_device_employee (employee_id, device_fingerprint),
                    INDEX idx_device_fingerprint (device_fingerprint),
                    INDEX idx_company_employee (company_id, employee_id)
                )");
                
                echo "<p class='text-green-600'>✅ employee_devices tablosu oluşturuldu</p>";
                
                // Create device_security_logs table
                $conn->exec("CREATE TABLE IF NOT EXISTS device_security_logs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    employee_id INT,
                    device_fingerprint VARCHAR(255),
                    ip_address VARCHAR(45),
                    event_type ENUM('new_device', 'suspicious_location', 'multiple_devices', 'blocked_device', 'trusted_device', 'trust_granted', 'blocked_attempt') NOT NULL,
                    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
                    description TEXT,
                    metadata JSON,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_severity_date (severity, created_at),
                    INDEX idx_employee_event (employee_id, event_type)
                )");
                
                echo "<p class='text-green-600'>✅ device_security_logs tablosu oluşturuldu</p>";
                
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Tablo oluşturma hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        if ($action === 'create_sample_data') {
            try {
                // Add some sample device records
                $companyId = $_SESSION['company_id'] ?? 4; // Fallback to company ID 4
                
                $stmt = $conn->prepare("
                    INSERT IGNORE INTO device_records 
                    (company_id, employee_id, session_id, device_fingerprint, ip_address, user_agent, device_type, browser_name, operating_system, screen_resolution, action_type, success) 
                    VALUES 
                    (?, 1, 'sample_session_1', 'fp_12345abc', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'desktop', 'Chrome', 'Windows', '1920x1080', 'checkin', 1),
                    (?, 1, 'sample_session_2', 'fp_67890def', '192.168.1.101', 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X)', 'mobile', 'Safari', 'iOS', '390x844', 'checkout', 1),
                    (?, 2, 'sample_session_3', 'fp_abcde123', '192.168.1.102', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36', 'desktop', 'Chrome', 'Linux', '1366x768', 'break_start', 1)
                ");
                $stmt->execute([$companyId, $companyId, $companyId]);
                
                echo "<p class='text-green-600'>✅ Örnek device records oluşturuldu</p>";
                
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Örnek veri oluşturma hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        if ($action === 'fix_missing_columns') {
            try {
                // Add recorded_at column if it doesn't exist (some queries use this instead of created_at)
                $stmt = $conn->query("SHOW COLUMNS FROM device_records LIKE 'recorded_at'");
                if ($stmt->rowCount() === 0) {
                    $conn->exec("ALTER TABLE device_records ADD COLUMN recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
                    echo "<p class='text-green-600'>✅ recorded_at sütunu eklendi</p>";
                }
                
                // Ensure all required indexes exist
                $conn->exec("ALTER TABLE device_records ADD INDEX IF NOT EXISTS idx_company_date (company_id, created_at)");
                $conn->exec("ALTER TABLE device_records ADD INDEX IF NOT EXISTS idx_action_type (action_type)");
                
                echo "<p class='text-green-600'>✅ Eksik sütunlar ve indexler düzeltildi</p>";
                
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Sütun düzeltme hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        echo "<script>setTimeout(() => window.location.reload(), 3000);</script>";
    }
    
    echo "<div class='mt-4 grid grid-cols-1 md:grid-cols-3 gap-4'>
            <form method='POST'>
                <button type='submit' name='fix_action' value='create_device_tables' 
                        class='w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🗂️ Device Tablolarını Oluştur
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='create_sample_data' 
                        class='w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm'>
                    📱 Örnek Device Records
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='fix_missing_columns' 
                        class='w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🔧 Eksik Sütunları Düzelt
                </button>
            </form>
          </div>";
    
    echo "</div>";
    
    // 7. Quick Test
    echo "<div class='border-l-4 border-cyan-500 bg-cyan-50 p-4'>
            <h2 class='text-lg font-semibold text-cyan-800'>7. Hızlı Test</h2>";
    
    try {
        // Test if we can query device_records
        $stmt = $conn->query("SELECT COUNT(*) as count FROM device_records WHERE DATE(created_at) = CURDATE()");
        $todayCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p class='text-green-600'>✅ Device records sorgusu başarılı</p>";
        echo "<p class='text-sm'>Bugünkü kayıt sayısı: <span class='font-medium'>$todayCount</span></p>";
        
        // Test recent records
        $stmt = $conn->query("SELECT * FROM device_records ORDER BY created_at DESC LIMIT 3");
        $recentRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($recentRecords) {
            echo "<p class='text-sm text-gray-600 mt-2 mb-1'>Son 3 kayıt:</p>";
            echo "<div class='text-xs bg-gray-50 p-2 rounded'>";
            foreach ($recentRecords as $record) {
                $time = date('H:i:s', strtotime($record['created_at']));
                echo "<div>• {$record['action_type']} - {$record['device_type']} - $time</div>";
            }
            echo "</div>";
        }
        
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Test sorgusu başarısız: " . $e->getMessage() . "</p>";
        echo "<p class='text-orange-600 text-sm'>Tabloları oluşturmak için yukarıdaki düzeltme butonlarını kullanın.</p>";
    }
    echo "</div>";
    
    // 8. Navigation Links
    echo "<div class='border-t pt-4 mt-6'>
            <h3 class='text-lg font-medium text-gray-900 mb-3'>İlgili Sayfalar</h3>
            <div class='flex flex-wrap gap-3'>
                <a href='../view-device-records.php' class='bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm'>
                    📱 Cihaz Kayıtlarını Görüntüle
                </a>
                <a href='../admin/device-management.php' class='bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm'>
                    ⚙️ Cihaz Yönetimi
                </a>
                <a href='../create-device-tracking-table.php' class='bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🗂️ Orijinal Tablo Oluşturucu
                </a>
                <a href='../super-admin/fix-critical-errors.php' class='bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🚨 Kritik Hata Düzeltme
                </a>
            </div>
          </div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>
            <strong>Kritik Hata:</strong> " . $e->getMessage() . "
          </div>";
}

echo "        </div>
    </div>
</body>
</html>";
?>