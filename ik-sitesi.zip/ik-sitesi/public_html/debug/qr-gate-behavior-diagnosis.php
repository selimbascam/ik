<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check authentication
if (!isset($_SESSION['company_id'])) {
    header('Location: ../index.php');
    exit;
}

$company_id = $_SESSION['company_id'];
$employee_id = $_SESSION['employee_id'] ?? null;

$diagnosis_data = [];
$test_results = [];

// Get all QR locations for this company
try {
    $locations_stmt = $pdo->prepare("
        SELECT id, location_name, gate_behavior, qr_code_data, latitude, longitude, 
               location_tolerance, is_active, created_at
        FROM qr_locations 
        WHERE company_id = ? 
        ORDER BY gate_behavior, location_name
    ");
    $locations_stmt->execute([$company_id]);
    $locations = $locations_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $diagnosis_data['locations'] = $locations;
    $diagnosis_data['location_count'] = count($locations);
    
    // Group by gate behavior
    $behavior_groups = [];
    foreach ($locations as $location) {
        $behavior = $location['gate_behavior'];
        if (!isset($behavior_groups[$behavior])) {
            $behavior_groups[$behavior] = [];
        }
        $behavior_groups[$behavior][] = $location;
    }
    $diagnosis_data['behavior_groups'] = $behavior_groups;
    
} catch (Exception $e) {
    $diagnosis_data['error'] = $e->getMessage();
}

// Test QR processing logic
if ($_POST && isset($_POST['test_qr']) && isset($_POST['qr_data'])) {
    $qr_data = trim($_POST['qr_data']);
    
    try {
        require_once '../includes/qr-attendance-fixed.php';
        
        // Create test instance
        $helper = new QRAttendanceHelper($pdo);
        
        // Test each step of QR processing
        $test_results['input_qr_data'] = $qr_data;
        
        // Step 1: Find QR location
        $location_stmt = $pdo->prepare("
            SELECT id, location_name, gate_behavior, latitude, longitude, location_tolerance
            FROM qr_locations 
            WHERE qr_code_data = ? AND company_id = ? AND is_active = 1
        ");
        $location_stmt->execute([$qr_data, $company_id]);
        $qr_location = $location_stmt->fetch(PDO::FETCH_ASSOC);
        
        $test_results['step_1_location_lookup'] = $qr_location;
        
        if ($qr_location) {
            $test_results['detected_gate_behavior'] = $qr_location['gate_behavior'];
            
            // Step 2: Check employee's today's records
            $today = date('Y-m-d');
            $today_records_stmt = $pdo->prepare("
                SELECT ar.*, aa.activity_name, ql.location_name
                FROM attendance_records ar
                LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id
                LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
                WHERE ar.employee_id = ? 
                AND DATE(ar.created_at) = ?
                ORDER BY ar.created_at ASC
            ");
            $today_records_stmt->execute([$employee_id, $today]);
            $today_records = $today_records_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $test_results['step_2_today_records'] = $today_records;
            $test_results['today_records_count'] = count($today_records);
            
            // Step 3: Determine activity based on gate behavior
            $gate_behavior = $qr_location['gate_behavior'];
            $activity_logic = [];
            
            switch ($gate_behavior) {
                case 'work_start':
                    $activity_logic = [
                        'behavior' => 'work_start',
                        'expected_activity' => 'work_start',
                        'description' => 'Her zaman işe giriş yapar'
                    ];
                    break;
                    
                case 'work_end':
                    $activity_logic = [
                        'behavior' => 'work_end',
                        'expected_activity' => 'work_end',
                        'description' => 'Her zaman işten çıkış yapar'
                    ];
                    break;
                    
                case 'break_toggle':
                    // Check if currently on break
                    $last_activity = end($today_records);
                    if ($last_activity && in_array($last_activity['activity_name'], ['break_start', 'mola_start'])) {
                        $activity_logic = [
                            'behavior' => 'break_toggle',
                            'expected_activity' => 'break_end',
                            'description' => 'Moladan dönüş (şu an molada)'
                        ];
                    } else {
                        $activity_logic = [
                            'behavior' => 'break_toggle',
                            'expected_activity' => 'break_start',
                            'description' => 'Mola başlatır (şu an çalışıyor)'
                        ];
                    }
                    break;
                    
                case 'user_choice':
                    // Auto-detect based on current state
                    if (empty($today_records)) {
                        $activity_logic = [
                            'behavior' => 'user_choice',
                            'expected_activity' => 'work_start',
                            'description' => 'Bugün ilk kayıt - otomatik giriş'
                        ];
                    } else {
                        $last_activity = end($today_records);
                        if (in_array($last_activity['activity_name'], ['work_start', 'break_end'])) {
                            $activity_logic = [
                                'behavior' => 'user_choice',
                                'expected_activity' => 'work_end',
                                'description' => 'Çıkış yapması mantıklı (son kayıt: giriş/mola bitiş)'
                            ];
                        } else {
                            $activity_logic = [
                                'behavior' => 'user_choice',
                                'expected_activity' => 'work_start',
                                'description' => 'Giriş yapması mantıklı (son kayıt: çıkış/mola başlangıç)'
                            ];
                        }
                    }
                    break;
                    
                default:
                    $activity_logic = [
                        'behavior' => $gate_behavior,
                        'expected_activity' => 'UNKNOWN',
                        'description' => 'Tanınmayan gate behavior'
                    ];
            }
            
            $test_results['step_3_activity_logic'] = $activity_logic;
            
            // Step 4: Get activity ID
            $activity_stmt = $pdo->prepare("
                SELECT id, activity_name 
                FROM attendance_activities 
                WHERE activity_name = ?
            ");
            $activity_stmt->execute([$activity_logic['expected_activity']]);
            $activity = $activity_stmt->fetch(PDO::FETCH_ASSOC);
            
            $test_results['step_4_activity_lookup'] = $activity;
            
            // Step 5: Simulate the actual processing
            if (isset($_POST['execute_test']) && $employee_id) {
                $result = $helper->processQRAttendance($qr_data, $employee_id, $company_id);
                $test_results['step_5_actual_result'] = $result;
            }
        } else {
            $test_results['error'] = 'QR lokasyonu bulunamadı';
        }
        
    } catch (Exception $e) {
        $test_results['exception'] = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Gate Behavior Tanı Sistemi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen py-8">
    <div class="container mx-auto px-4">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h1 class="text-2xl font-bold text-gray-900 mb-2">🔬 QR Gate Behavior Tanı Sistemi</h1>
            <p class="text-gray-600">
                Bu sayfa QR kod okuma ve gate behavior işlemlerini adım adım test eder.
            </p>
        </div>

        <!-- QR Locations Overview -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📍 QR Lokasyonları Genel Bakış</h3>
            
            <?php if (isset($diagnosis_data['behavior_groups'])): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <?php foreach ($diagnosis_data['behavior_groups'] as $behavior => $locations): ?>
                <div class="p-4 bg-blue-50 rounded-lg">
                    <div class="font-semibold text-blue-900"><?= htmlspecialchars($behavior) ?></div>
                    <div class="text-blue-700"><?= count($locations) ?> lokasyon</div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="space-y-2">
                <?php foreach ($diagnosis_data['locations'] as $location): ?>
                <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                        <div class="font-medium"><?= htmlspecialchars($location['location_name']) ?></div>
                        <div class="text-sm text-gray-600">
                            Gate: <code><?= htmlspecialchars($location['gate_behavior']) ?></code>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-xs font-mono bg-gray-200 px-2 py-1 rounded">
                            <?= htmlspecialchars(substr($location['qr_code_data'], 0, 20)) ?>...
                        </div>
                        <div class="text-xs text-gray-500 mt-1">
                            <?= $location['is_active'] ? '✅ Aktif' : '❌ Pasif' ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8 text-gray-500">QR lokasyonu bilgisi alınamadı</div>
            <?php endif; ?>
        </div>

        <!-- QR Test Form -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">🧪 QR Kod Test Sistemi</h3>
            
            <form method="POST" class="space-y-4">
                <div>
                    <label for="qr_data" class="block text-sm font-medium text-gray-700 mb-2">
                        QR Kod Verisi
                    </label>
                    <input type="text" 
                           id="qr_data" 
                           name="qr_data" 
                           value="<?= htmlspecialchars($_POST['qr_data'] ?? '') ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" 
                           placeholder="QR kod verisini buraya yapıştırın..." required>
                </div>
                
                <div class="flex gap-3">
                    <button type="submit" name="test_qr" value="1" 
                            class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        🔍 Tanıla (Sadece Test)
                    </button>
                    
                    <?php if ($employee_id): ?>
                    <button type="submit" name="execute_test" value="1" 
                            class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                        ⚡ Çalıştır (Gerçek İşlem)
                    </button>
                    <?php endif; ?>
                </div>
                
                <input type="hidden" name="test_qr" value="1">
            </form>
        </div>

        <!-- Test Results -->
        <?php if (!empty($test_results)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📋 Test Sonuçları</h3>
            
            <div class="space-y-6">
                <!-- Step 1: Location Lookup -->
                <div class="border-l-4 border-blue-500 pl-4">
                    <h4 class="font-semibold text-blue-900">Adım 1: QR Lokasyon Arama</h4>
                    <?php if ($test_results['step_1_location_lookup']): ?>
                        <div class="mt-2 p-3 bg-green-50 rounded">
                            <div class="text-green-800">✅ Lokasyon bulundu</div>
                            <div class="text-sm mt-1">
                                <strong>Lokasyon:</strong> <?= htmlspecialchars($test_results['step_1_location_lookup']['location_name']) ?><br>
                                <strong>Gate Behavior:</strong> <code><?= htmlspecialchars($test_results['step_1_location_lookup']['gate_behavior']) ?></code>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mt-2 p-3 bg-red-50 rounded">
                            <div class="text-red-800">❌ Lokasyon bulunamadı</div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Step 2: Today's Records -->
                <?php if (isset($test_results['step_2_today_records'])): ?>
                <div class="border-l-4 border-green-500 pl-4">
                    <h4 class="font-semibold text-green-900">Adım 2: Bugünkü Kayıtlar</h4>
                    <div class="mt-2">
                        <div class="text-sm text-gray-600">Bugün <?= $test_results['today_records_count'] ?> kayıt bulundu</div>
                        <?php if ($test_results['today_records_count'] > 0): ?>
                        <div class="mt-2 space-y-1">
                            <?php foreach ($test_results['step_2_today_records'] as $record): ?>
                            <div class="text-xs bg-gray-100 p-2 rounded">
                                <?= date('H:i', strtotime($record['created_at'])) ?> - 
                                <?= htmlspecialchars($record['activity_name']) ?> @ 
                                <?= htmlspecialchars($record['location_name']) ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Step 3: Activity Logic -->
                <?php if (isset($test_results['step_3_activity_logic'])): ?>
                <div class="border-l-4 border-yellow-500 pl-4">
                    <h4 class="font-semibold text-yellow-900">Adım 3: Aktivite Mantığı</h4>
                    <div class="mt-2 p-3 bg-yellow-50 rounded">
                        <div><strong>Gate Behavior:</strong> <?= htmlspecialchars($test_results['step_3_activity_logic']['behavior']) ?></div>
                        <div><strong>Beklenen Aktivite:</strong> <?= htmlspecialchars($test_results['step_3_activity_logic']['expected_activity']) ?></div>
                        <div><strong>Açıklama:</strong> <?= htmlspecialchars($test_results['step_3_activity_logic']['description']) ?></div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Step 4: Activity Lookup -->
                <?php if (isset($test_results['step_4_activity_lookup'])): ?>
                <div class="border-l-4 border-purple-500 pl-4">
                    <h4 class="font-semibold text-purple-900">Adım 4: Aktivite ID Arama</h4>
                    <?php if ($test_results['step_4_activity_lookup']): ?>
                        <div class="mt-2 p-3 bg-purple-50 rounded">
                            <div class="text-purple-800">✅ Aktivite bulundu</div>
                            <div class="text-sm">
                                ID: <?= $test_results['step_4_activity_lookup']['id'] ?> - 
                                <?= htmlspecialchars($test_results['step_4_activity_lookup']['activity_name']) ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mt-2 p-3 bg-red-50 rounded">
                            <div class="text-red-800">❌ Aktivite bulunamadı</div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Step 5: Actual Result -->
                <?php if (isset($test_results['step_5_actual_result'])): ?>
                <div class="border-l-4 border-indigo-500 pl-4">
                    <h4 class="font-semibold text-indigo-900">Adım 5: Gerçek Sonuç</h4>
                    <div class="mt-2 p-3 <?= $test_results['step_5_actual_result']['success'] ? 'bg-green-50' : 'bg-red-50' ?> rounded">
                        <div class="<?= $test_results['step_5_actual_result']['success'] ? 'text-green-800' : 'text-red-800' ?>">
                            <?= $test_results['step_5_actual_result']['success'] ? '✅' : '❌' ?> 
                            <?= htmlspecialchars($test_results['step_5_actual_result']['message']) ?>
                        </div>
                        <?php if (isset($test_results['step_5_actual_result']['debug'])): ?>
                        <div class="text-xs mt-2">
                            <strong>Debug:</strong> <?= implode(', ', $test_results['step_5_actual_result']['debug']) ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Quick Test Buttons -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">🚀 Hızlı Test</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                <?php if (isset($diagnosis_data['locations'])): ?>
                    <?php foreach ($diagnosis_data['locations'] as $location): ?>
                    <button onclick="testLocation('<?= htmlspecialchars($location['qr_code_data']) ?>')" 
                            class="p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors text-left">
                        <div class="font-medium text-blue-900"><?= htmlspecialchars($location['location_name']) ?></div>
                        <div class="text-xs text-blue-700"><?= htmlspecialchars($location['gate_behavior']) ?></div>
                    </button>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function testLocation(qrData) {
            document.getElementById('qr_data').value = qrData;
        }
    </script>
</body>
</html>