<?php
// Fix QR Gate Behaviors - Setup proper gate behaviors for SZB Mühendislik
require_once '../includes/config.php';
require_once '../includes/database.php';

// Simple authentication check
if (!isset($_SESSION['employee_id']) && !isset($_SESSION['super_admin'])) {
    echo "Authentication required";
    exit;
}

date_default_timezone_set('Europe/Istanbul');
echo "<h2>🔧 QR Gate Behavior Düzeltme Aracı</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if gate_behavior column exists
    $stmt = $conn->query("DESCRIBE qr_locations");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $hasGateBehavior = false;
    
    foreach ($columns as $column) {
        if ($column['Field'] === 'gate_behavior') {
            $hasGateBehavior = true;
            break;
        }
    }
    
    echo "<h3>1. Veritabanı Yapısı Kontrolü:</h3>";
    if (!$hasGateBehavior) {
        echo "<p style='color:red;'>❌ gate_behavior sütunu eksik. Ekleniyor...</p>";
        try {
            $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(20) DEFAULT 'user_choice'");
            echo "<p style='color:green;'>✅ gate_behavior sütunu eklendi.</p>";
            $hasGateBehavior = true;
        } catch (Exception $e) {
            echo "<p style='color:red;'>❌ Sütun eklenirken hata: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color:green;'>✅ gate_behavior sütunu mevcut.</p>";
    }
    
    if ($hasGateBehavior) {
        echo "<h3>2. SZB Mühendislik Lokasyonları:</h3>";
        
        // Get SZB Mühendislik company ID
        $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE company_name LIKE '%SZB%' OR company_name LIKE '%Mühendislik%'");
        $stmt->execute();
        $szbCompany = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$szbCompany) {
            echo "<p style='color:red;'>❌ SZB Mühendislik şirketi bulunamadı.</p>";
        } else {
            echo "<p style='color:green;'>✅ SZB Mühendislik bulundu: " . $szbCompany['company_name'] . " (ID: " . $szbCompany['id'] . ")</p>";
            
            // Get existing QR locations for SZB
            $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ?");
            $stmt->execute([$szbCompany['id']]);
            $existingLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<h4>Mevcut Lokasyonlar:</h4>";
            if (empty($existingLocations)) {
                echo "<p>❌ Hiç QR lokasyonu yok. Örnek lokasyonlar oluşturuluyor...</p>";
                
                // Create example locations with different gate behaviors
                $exampleLocations = [
                    ['name' => 'Ana Giriş Kapısı', 'gate_behavior' => 'work_start', 'location_type' => 'entrance_gate'],
                    ['name' => 'Ana Çıkış Kapısı', 'gate_behavior' => 'work_end', 'location_type' => 'exit_gate'],
                    ['name' => 'Mola Alanı', 'gate_behavior' => 'break_toggle', 'location_type' => 'break_gate'],
                    ['name' => 'Genel Kapı', 'gate_behavior' => 'user_choice', 'location_type' => 'general_gate']
                ];
                
                foreach ($exampleLocations as $location) {
                    try {
                        $stmt = $conn->prepare("
                            INSERT INTO qr_locations (company_id, name, location_type, gate_behavior) 
                            VALUES (?, ?, ?, ?)
                        ");
                        $stmt->execute([
                            $szbCompany['id'], 
                            $location['name'], 
                            $location['location_type'], 
                            $location['gate_behavior']
                        ]);
                        echo "<p style='color:green;'>✅ " . $location['name'] . " (" . $location['gate_behavior'] . ") oluşturuldu.</p>";
                    } catch (Exception $e) {
                        echo "<p style='color:red;'>❌ " . $location['name'] . " oluşturulamadı: " . $e->getMessage() . "</p>";
                    }
                }
            } else {
                echo "<table border='1' style='border-collapse:collapse; width:100%; margin:10px 0;'>";
                echo "<tr style='background:#f0f0f0;'>";
                echo "<th style='padding:8px;'>ID</th><th style='padding:8px;'>Lokasyon</th><th style='padding:8px;'>Gate Behavior</th><th style='padding:8px;'>İşlem</th>";
                echo "</tr>";
                
                foreach ($existingLocations as $location) {
                    $currentBehavior = $location['gate_behavior'] ?: 'NULL';
                    echo "<tr>";
                    echo "<td style='padding:8px;'>" . $location['id'] . "</td>";
                    echo "<td style='padding:8px;'>" . htmlspecialchars($location['name']) . "</td>";
                    echo "<td style='padding:8px;'><code>" . $currentBehavior . "</code></td>";
                    echo "<td style='padding:8px;'>";
                    
                    if (isset($_POST['fix_location_' . $location['id']])) {
                        // Fix this location's gate behavior based on name
                        $newBehavior = 'user_choice'; // default
                        $locationName = strtolower($location['name']);
                        
                        if (strpos($locationName, 'giriş') !== false || strpos($locationName, 'entrance') !== false) {
                            $newBehavior = 'work_start';
                        } elseif (strpos($locationName, 'çıkış') !== false || strpos($locationName, 'exit') !== false) {
                            $newBehavior = 'work_end';
                        } elseif (strpos($locationName, 'mola') !== false || strpos($locationName, 'break') !== false) {
                            $newBehavior = 'break_toggle';
                        }
                        
                        try {
                            $stmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE id = ?");
                            $stmt->execute([$newBehavior, $location['id']]);
                            echo "<span style='color:green;'>✅ " . $newBehavior . " olarak güncellendi</span>";
                        } catch (Exception $e) {
                            echo "<span style='color:red;'>❌ Güncelleme hatası: " . $e->getMessage() . "</span>";
                        }
                    } else {
                        echo "<form method='POST' style='display:inline;'>";
                        echo "<button type='submit' name='fix_location_" . $location['id'] . "' style='background:#007cba; color:white; padding:4px 8px; border:none; border-radius:4px; cursor:pointer;'>Düzelt</button>";
                        echo "</form>";
                    }
                    
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        }
        
        echo "<h3>3. QR Gate Behavior Test:</h3>";
        echo "<p>Her gate behavior türü için test:</p>";
        
        $behaviors = ['work_start', 'work_end', 'break_toggle', 'user_choice'];
        foreach ($behaviors as $behavior) {
            echo "<div style='border:1px solid #ddd; padding:10px; margin:5px 0; border-radius:5px;'>";
            echo "<strong>" . strtoupper($behavior) . "</strong><br>";
            
            switch ($behavior) {
                case 'work_start':
                    echo "🚪 İş başlangıcı - sadece giriş yapar<br>";
                    echo "Bugün kayıt yok → İlk giriş ✅<br>";
                    echo "Zaten giriş var → Hata ❌";
                    break;
                case 'work_end':
                    echo "🚪 İş bitişi - sadece çıkış yapar<br>";
                    echo "Bugün kayıt yok → Hata ❌ (önce giriş gerekli)<br>";
                    echo "Giriş var, çıkış yok → Çıkış ✅";
                    break;
                case 'break_toggle':
                    echo "☕ Mola kontrolü - akıllı mola yönetimi<br>";
                    echo "Bugün kayıt yok → Hata ❌ (önce giriş gerekli)<br>";
                    echo "Giriş var, mola yok → Mola başlat ✅<br>";
                    echo "Mola var, bitiş yok → Mola bitir ✅";
                    break;
                case 'user_choice':
                    echo "🔄 Otomatik tespit - duruma göre karar verir<br>";
                    echo "Bugün kayıt yok → Otomatik giriş ✅<br>";
                    echo "Giriş var → Duruma göre mola/çıkış";
                    break;
            }
            
            echo "<br><a href='../test-qr-scan.php?test_behavior=" . $behavior . "' style='background:#28a745; color:white; padding:4px 8px; text-decoration:none; border-radius:4px; margin-top:5px; display:inline-block;'>Test Et</a>";
            echo "</div>";
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Hata: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>🔧 Test Araçları:</h3>";
echo "<p>";
echo "<a href='check-qr-gate-behaviors.php' style='background:#007cba; color:white; padding:8px 16px; text-decoration:none; border-radius:4px; margin-right:10px;'>📋 QR Lokasyon Kontrol</a>";
echo "<a href='test-qr-gate-behavior.php' style='background:#28a745; color:white; padding:8px 16px; text-decoration:none; border-radius:4px; margin-right:10px;'>🧪 Gate Behavior Test</a>";
echo "<a href='../test-qr-scan.php' style='background:#6f42c1; color:white; padding:8px 16px; text-decoration:none; border-radius:4px; margin-right:10px;'>📱 QR Tarama Test</a>";
echo "</p>";
?>