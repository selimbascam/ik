<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
// Simple diagnostic logging function
function addDiagnostic($type, $title, $message) {
    // Simple logging - could be enhanced
    error_log("DIAGNOSTIC [$type] $title: $message");
}

function markErrorAsResolved($errorType) {
    // Simple error marking - could be enhanced
    error_log("RESOLVED: $errorType");
}

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'test_shift_queries':
                try {
                    echo "<div class='bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4'>";
                    echo "<h3 class='font-bold text-blue-900 mb-2'>🔍 Vardiya Sorgu Testleri</h3>";
                    
                    // Test 1: Check if tables exist
                    echo "<h4 class='font-semibold mt-4 mb-2'>Tablo Varlık Kontrolü:</h4>";
                    $tables = ['employee_shifts', 'shift_templates', 'employees'];
                    foreach ($tables as $table) {
                        $stmt = $conn->query("SHOW TABLES LIKE '$table'");
                        if ($stmt->rowCount() > 0) {
                            echo "✅ $table tablosu mevcut<br>";
                        } else {
                            echo "❌ $table tablosu bulunamadı<br>";
                        }
                    }
                    
                    // Test 2: Check employee_shifts records
                    echo "<h4 class='font-semibold mt-4 mb-2'>Employee Shifts Kayıtları:</h4>";
                    $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_shifts");
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo "📊 Toplam employee_shifts kaydı: " . $result['count'] . "<br>";
                    
                    if ($result['count'] > 0) {
                        $stmt = $conn->query("SELECT * FROM employee_shifts LIMIT 5");
                        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        echo "<table class='w-full mt-2 text-sm'>";
                        echo "<tr class='bg-gray-100'><th>ID</th><th>Employee ID</th><th>Shift Date</th><th>Status</th></tr>";
                        foreach ($records as $record) {
                            echo "<tr>";
                            echo "<td>" . ($record['id'] ?? 'N/A') . "</td>";
                            echo "<td>" . ($record['employee_id'] ?? 'N/A') . "</td>";
                            echo "<td>" . ($record['shift_date'] ?? 'N/A') . "</td>";
                            echo "<td>" . ($record['status'] ?? 'N/A') . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    }
                    
                    // Test 3: Check shift_templates records
                    echo "<h4 class='font-semibold mt-4 mb-2'>Shift Templates Kayıtları:</h4>";
                    $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo "📊 Toplam shift_templates kaydı: " . $result['count'] . "<br>";
                    
                    if ($result['count'] > 0) {
                        $stmt = $conn->query("SELECT * FROM shift_templates LIMIT 5");
                        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        echo "<table class='w-full mt-2 text-sm'>";
                        echo "<tr class='bg-gray-100'><th>ID</th><th>Name</th><th>Start Time</th><th>End Time</th></tr>";
                        foreach ($records as $record) {
                            echo "<tr>";
                            echo "<td>" . ($record['id'] ?? 'N/A') . "</td>";
                            echo "<td>" . ($record['name'] ?? 'N/A') . "</td>";
                            echo "<td>" . ($record['start_time'] ?? 'N/A') . "</td>";
                            echo "<td>" . ($record['end_time'] ?? 'N/A') . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    }
                    
                    // Test 4: Test dashboard query
                    echo "<h4 class='font-semibold mt-4 mb-2'>Dashboard Sorgu Testi:</h4>";
                    try {
                        $stmt = $conn->prepare("
                            SELECT 
                                DATE_FORMAT(es.shift_date, '%Y-%m-%d') as shift_date,
                                COALESCE(es.status, 'scheduled') as status,
                                COALESCE(st.name, 'Vardiya') as shift_name,
                                COALESCE(TIME_FORMAT(st.start_time, '%H:%i:%s'), '09:00:00') as start_time,
                                COALESCE(TIME_FORMAT(st.end_time, '%H:%i:%s'), '17:00:00') as end_time,
                                COALESCE(st.break_duration, 60) as break_duration,
                                COALESCE(st.color_code, '#3B82F6') as color_code,
                                COALESCE(st.description, '') as description
                            FROM employee_shifts es
                            LEFT JOIN shift_templates st ON es.shift_template_id = st.id AND COALESCE(st.is_active, 1) = 1
                            WHERE es.employee_id = 1 AND DATE(es.shift_date) = CURDATE()
                            ORDER BY es.created_at DESC
                            LIMIT 1
                        ");
                        $stmt->execute();
                        $result = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($result) {
                            echo "✅ Dashboard sorgusu çalışıyor - Bugünkü vardiya bulundu<br>";
                            echo "📝 Vardiya: " . $result['shift_name'] . " (" . $result['start_time'] . " - " . $result['end_time'] . ")<br>";
                        } else {
                            echo "⚠️ Dashboard sorgusu çalışıyor ancak bugün için vardiya bulunamadı<br>";
                        }
                    } catch (Exception $e) {
                        echo "❌ Dashboard sorgu hatası: " . $e->getMessage() . "<br>";
                    }
                    
                    echo "</div>";
                    addDiagnostic('info', 'Shift Query Tests', 'Completed shift query tests');
                } catch (Exception $e) {
                    $message = "❌ Test hatası: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Shift Query Test Failed', $e->getMessage());
                }
                break;
                
            case 'create_sample_shifts':
                try {
                    // Get first employee and first shift template
                    $empStmt = $conn->query("SELECT id FROM employees LIMIT 1");
                    $employee = $empStmt->fetch(PDO::FETCH_ASSOC);
                    
                    $templateStmt = $conn->query("SELECT id FROM shift_templates LIMIT 1");
                    $template = $templateStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($employee && $template) {
                        $employeeId = $employee['id'];
                        $templateId = $template['id'];
                        
                        // Create shifts for today, tomorrow, and next few days
                        $dates = [
                            date('Y-m-d'), // Today
                            date('Y-m-d', strtotime('+1 day')), // Tomorrow
                            date('Y-m-d', strtotime('+2 day')), // Day after
                            date('Y-m-d', strtotime('+3 day')), // 3 days ahead
                            date('Y-m-d', strtotime('+4 day'))  // 4 days ahead
                        ];
                        
                        $insertCount = 0;
                        foreach ($dates as $date) {
                            $stmt = $conn->prepare("
                                INSERT IGNORE INTO employee_shifts 
                                (employee_id, shift_template_id, shift_date, status) 
                                VALUES (?, ?, ?, 'scheduled')
                            ");
                            $stmt->execute([$employeeId, $templateId, $date]);
                            if ($stmt->rowCount() > 0) {
                                $insertCount++;
                            }
                        }
                        
                        $message = "✅ $insertCount vardiya kaydı oluşturuldu (Employee ID: $employeeId)";
                        $messageType = "success";
                        addDiagnostic('success', 'Sample Shifts Created', "$insertCount shifts created for employee $employeeId");
                    } else {
                        $message = "❌ Personel veya vardiya şablonu bulunamadı";
                        $messageType = "error";
                        addDiagnostic('error', 'Sample Shifts Failed', 'No employees or shift templates found');
                    }
                } catch (Exception $e) {
                    $message = "❌ Örnek vardiya oluşturma hatası: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Sample Shifts Creation Failed', $e->getMessage());
                }
                break;
                
            case 'assign_shifts_to_all':
                try {
                    // Get all employees and first shift template
                    $empStmt = $conn->query("SELECT id, first_name, last_name FROM employees");
                    $employees = $empStmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    $templateStmt = $conn->query("SELECT id FROM shift_templates LIMIT 1");
                    $template = $templateStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($employees && $template) {
                        $templateId = $template['id'];
                        $totalInserted = 0;
                        
                        // Create shifts for next 7 days
                        $dates = [];
                        for ($i = 0; $i < 7; $i++) {
                            $dates[] = date('Y-m-d', strtotime("+$i day"));
                        }
                        
                        foreach ($employees as $employee) {
                            $employeeId = $employee['id'];
                            $insertCount = 0;
                            
                            foreach ($dates as $date) {
                                $stmt = $conn->prepare("
                                    INSERT IGNORE INTO employee_shifts 
                                    (employee_id, shift_template_id, shift_date, status) 
                                    VALUES (?, ?, ?, 'scheduled')
                                ");
                                $stmt->execute([$employeeId, $templateId, $date]);
                                if ($stmt->rowCount() > 0) {
                                    $insertCount++;
                                    $totalInserted++;
                                }
                            }
                        }
                        
                        $employeeCount = count($employees);
                        $message = "✅ $totalInserted vardiya kaydı oluşturuldu ($employeeCount personel için 7 gün)";
                        $messageType = "success";
                        addDiagnostic('success', 'All Employees Shifts Created', "$totalInserted shifts created for $employeeCount employees");
                    } else {
                        $message = "❌ Personel veya vardiya şablonu bulunamadı";
                        $messageType = "error";
                        addDiagnostic('error', 'All Employee Shifts Failed', 'No employees or shift templates found');
                    }
                } catch (Exception $e) {
                    $message = "❌ Tüm personele vardiya atama hatası: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'All Employee Shifts Assignment Failed', $e->getMessage());
                }
                break;
        }
        
    } catch (Exception $e) {
        $message = "❌ Genel hata: " . $e->getMessage();
        $messageType = "error";
        addDiagnostic('error', 'General Error in Employee Shifts Fix', $e->getMessage());
    }
}

// Mark as resolved when successful operation
if (isset($_POST['mark_resolved']) && $_POST['mark_resolved'] === '1') {
    markErrorAsResolved('employee_shifts_display');
    $message .= " ✅ Hata işaretlendi: çözüldü";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Vardiya Düzeltme Aracı - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 p-6">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-xl shadow-lg p-8">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">🔧 Personel Vardiya Düzeltme Aracı</h1>
                    <p class="text-gray-600 mt-2">Personel panelinde vardiya gösterilmemesi sorunu için kapsamlı çözüm aracı</p>
                </div>
                <a href="../super-admin/fix-critical-errors.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                    ← Geri Dön
                </a>
            </div>

            <?php if ($message): ?>
                <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Test Section -->
                <div class="bg-blue-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-blue-900 mb-4">🔍 Test İşlemleri</h2>
                    
                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="action" value="test_shift_queries">
                        <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Vardiya Sorgu Testleri Çalıştır
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-blue-700">
                        <p><strong>Bu test şunları kontrol eder:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>employee_shifts ve shift_templates tablolarının varlığı</li>
                            <li>Vardiya kayıtlarının sayısı ve örnekleri</li>
                            <li>Dashboard sorgularının çalışma durumu</li>
                            <li>Bugünkü vardiya bilgilerinin çekilebilirliği</li>
                        </ul>
                    </div>
                </div>

                <!-- Fix Section -->
                <div class="bg-green-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-green-900 mb-4">🔧 Düzeltme İşlemleri</h2>
                    
                    <div class="space-y-3">
                        <form method="POST">
                            <input type="hidden" name="action" value="create_sample_shifts">
                            <button type="submit" class="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                                İlk Personele Örnek Vardiyalar Oluştur
                            </button>
                        </form>
                        
                        <form method="POST">
                            <input type="hidden" name="action" value="assign_shifts_to_all">
                            <input type="hidden" name="mark_resolved" value="1">
                            <button type="submit" class="w-full bg-green-700 text-white px-4 py-2 rounded-lg hover:bg-green-800 transition-colors">
                                Tüm Personele 7 Günlük Vardiya Ata
                            </button>
                        </form>
                    </div>
                    
                    <div class="mt-4 text-sm text-green-700">
                        <p><strong>Bu işlemler:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>Mevcut personellere vardiya şablonları atar</li>
                            <li>Bugünden başlayarak 7 günlük program oluşturur</li>
                            <li>Personel panelinde vardiyaların görünmesini sağlar</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h3 class="font-bold text-yellow-900 mb-2">⚠️ Önemli Notlar:</h3>
                <ul class="list-disc pl-5 text-sm text-yellow-800">
                    <li>Bu işlemler mevcut vardiya kayıtlarını değiştirmez, yalnızca yeni kayıtlar ekler</li>
                    <li>Vardiya atamadan önce shift_templates tablosunda şablonların olduğundan emin olun</li>
                    <li>İlk test işlemini çalıştırarak mevcut durumu kontrol edin</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>