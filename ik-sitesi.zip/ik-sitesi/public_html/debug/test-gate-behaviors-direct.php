<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Allow super admin or employee access
if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../index.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 4; // Default to SZB for super admin
$employee_id = $_SESSION['employee_id'] ?? 1; // Default employee for testing

$test_results = [];

// Get available QR locations
$locations_stmt = $pdo->prepare("
    SELECT id, location_name, gate_behavior, qr_code_data 
    FROM qr_locations 
    WHERE company_id = ? AND is_active = 1
    ORDER BY gate_behavior
");
$locations_stmt->execute([$company_id]);
$locations = $locations_stmt->fetchAll(PDO::FETCH_ASSOC);

// Test specific QR code if provided
if ($_POST && isset($_POST['test_qr_code'])) {
    $qr_data = trim($_POST['test_qr_code']);
    
    require_once '../includes/qr-attendance-fixed.php';
    
    try {
        $helper = new QRAttendanceHelper($pdo);
        $result = $helper->processQRAttendance($qr_data, $employee_id, $company_id);
        
        $test_results['direct_test'] = [
            'qr_data' => $qr_data,
            'result' => $result,
            'employee_id' => $employee_id,
            'company_id' => $company_id,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
    } catch (Exception $e) {
        $test_results['direct_test'] = [
            'qr_data' => $qr_data,
            'error' => $e->getMessage(),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    }
}

// Test all gate behaviors automatically
if ($_POST && isset($_POST['test_all_behaviors'])) {
    foreach ($locations as $location) {
        try {
            require_once '../includes/qr-attendance-fixed.php';
            
            $helper = new QRAttendanceHelper($pdo);
            
            // Test gate action determination
            $gate_action = QRAttendanceHelper::determineGateAction(
                $pdo, 
                $employee_id, 
                $company_id, 
                $location['id'], 
                $location['gate_behavior']
            );
            
            $test_results['behavior_tests'][$location['gate_behavior']][] = [
                'location_name' => $location['location_name'],
                'gate_behavior' => $location['gate_behavior'],
                'determined_action' => $gate_action,
                'qr_code_data' => $location['qr_code_data']
            ];
            
        } catch (Exception $e) {
            $test_results['behavior_tests'][$location['gate_behavior']][] = [
                'location_name' => $location['location_name'],
                'error' => $e->getMessage()
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Direkt Gate Behavior Test</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen py-8">
    <div class="container mx-auto px-4">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h1 class="text-2xl font-bold text-gray-900 mb-2">🧪 Direkt Gate Behavior Test</h1>
            <p class="text-gray-600">
                QR gate behavior mantığını direkt olarak test eder. 
                Company ID: <?= $company_id ?>, Employee ID: <?= $employee_id ?>
            </p>
        </div>

        <!-- Available Locations -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📍 Mevcut QR Lokasyonları</h3>
            
            <?php if (!empty($locations)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php foreach ($locations as $location): ?>
                <div class="p-4 border border-gray-200 rounded-lg">
                    <div class="font-medium text-gray-900"><?= htmlspecialchars($location['location_name']) ?></div>
                    <div class="text-sm text-gray-600 mb-2">
                        Gate Behavior: <code class="bg-gray-100 px-1 rounded"><?= htmlspecialchars($location['gate_behavior']) ?></code>
                    </div>
                    <div class="text-xs font-mono text-gray-500 bg-gray-50 p-2 rounded">
                        <?= htmlspecialchars($location['qr_code_data']) ?>
                    </div>
                    <button onclick="testSpecificQR('<?= htmlspecialchars($location['qr_code_data']) ?>')" 
                            class="mt-2 bg-blue-600 text-white px-3 py-1 text-sm rounded hover:bg-blue-700">
                        Bu QR'ı Test Et
                    </button>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8 text-gray-500">
                Bu şirket için aktif QR lokasyonu bulunamadı.
            </div>
            <?php endif; ?>
        </div>

        <!-- Test Forms -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            
            <!-- Manual QR Test -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">🎯 Manuel QR Test</h3>
                <form method="POST">
                    <div class="mb-4">
                        <label for="test_qr_code" class="block text-sm font-medium text-gray-700 mb-2">
                            QR Kod Verisi
                        </label>
                        <input type="text" 
                               id="test_qr_code" 
                               name="test_qr_code" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" 
                               placeholder="QR kod verisini yapıştırın..." required>
                    </div>
                    <button type="submit" 
                            class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700">
                        🧪 QR Kodu Test Et
                    </button>
                </form>
            </div>

            <!-- Behavior Test -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">🔬 Tüm Behavior Test</h3>
                <p class="text-gray-600 mb-4 text-sm">
                    Tüm gate behavior türlerini test eder ve hangi aktiviteyi seçtiklerini gösterir.
                </p>
                <form method="POST">
                    <button type="submit" name="test_all_behaviors" value="1"
                            class="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700">
                        🚀 Tüm Behavior'ları Test Et
                    </button>
                </form>
            </div>
        </div>

        <!-- Test Results -->
        <?php if (!empty($test_results)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📋 Test Sonuçları</h3>
            
            <!-- Direct Test Result -->
            <?php if (isset($test_results['direct_test'])): ?>
            <div class="mb-6 p-4 border border-blue-200 rounded-lg">
                <h4 class="font-semibold text-blue-900 mb-3">Direkt QR Test Sonucu</h4>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <div class="text-sm text-gray-600">QR Kod Verisi:</div>
                        <div class="font-mono text-xs bg-gray-100 p-2 rounded">
                            <?= htmlspecialchars($test_results['direct_test']['qr_data']) ?>
                        </div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-600">Test Zamanı:</div>
                        <div class="text-sm"><?= $test_results['direct_test']['timestamp'] ?></div>
                    </div>
                </div>
                
                <?php if (isset($test_results['direct_test']['result'])): ?>
                    <?php $result = $test_results['direct_test']['result']; ?>
                    <div class="mt-4 p-3 <?= $result['success'] ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200' ?> rounded">
                        <div class="<?= $result['success'] ? 'text-green-800' : 'text-red-800' ?>">
                            <strong><?= $result['success'] ? '✅ Başarılı' : '❌ Hata' ?>:</strong> 
                            <?= htmlspecialchars($result['message']) ?>
                        </div>
                        
                        <?php if (isset($result['activity_details'])): ?>
                        <div class="mt-2 text-sm text-green-700">
                            <strong>Aktivite Detayları:</strong><br>
                            • Aktivite: <?= htmlspecialchars($result['activity_details']['activity']) ?><br>
                            • Lokasyon: <?= htmlspecialchars($result['activity_details']['location']) ?><br>
                            • Gate Behavior: <?= htmlspecialchars($result['activity_details']['gate_behavior']) ?><br>
                            • Zaman: <?= htmlspecialchars($result['activity_details']['time']) ?>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (isset($result['debug'])): ?>
                        <details class="mt-2">
                            <summary class="text-xs text-gray-600 cursor-pointer">Debug Bilgileri</summary>
                            <pre class="text-xs bg-gray-100 p-2 rounded mt-1"><?= json_encode($result['debug'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) ?></pre>
                        </details>
                        <?php endif; ?>
                    </div>
                <?php elseif (isset($test_results['direct_test']['error'])): ?>
                    <div class="mt-4 p-3 bg-red-50 border border-red-200 rounded">
                        <div class="text-red-800">
                            <strong>❌ Hata:</strong> <?= htmlspecialchars($test_results['direct_test']['error']) ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Behavior Tests Results -->
            <?php if (isset($test_results['behavior_tests'])): ?>
            <div class="space-y-4">
                <h4 class="font-semibold text-gray-900">Behavior Test Sonuçları</h4>
                
                <?php foreach ($test_results['behavior_tests'] as $behavior => $tests): ?>
                <div class="p-4 border border-gray-200 rounded-lg">
                    <h5 class="font-medium text-gray-900 mb-3">
                        Gate Behavior: <code class="bg-gray-100 px-2 py-1 rounded"><?= htmlspecialchars($behavior) ?></code>
                    </h5>
                    
                    <div class="space-y-2">
                        <?php foreach ($tests as $test): ?>
                        <div class="p-3 bg-gray-50 rounded">
                            <div class="flex justify-between items-start">
                                <div>
                                    <div class="font-medium"><?= htmlspecialchars($test['location_name']) ?></div>
                                    <?php if (isset($test['determined_action'])): ?>
                                        <div class="text-sm text-green-600">
                                            ✅ Belirlenen Aktivite: <strong><?= htmlspecialchars($test['determined_action']) ?></strong>
                                        </div>
                                    <?php elseif (isset($test['error'])): ?>
                                        <div class="text-sm text-red-600">
                                            ❌ Hata: <?= htmlspecialchars($test['error']) ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="text-xs text-gray-500">
                                    <?= htmlspecialchars($behavior) ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Expected Behaviors -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📚 Beklenen Davranışlar</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div class="font-semibold text-green-900">work_start</div>
                    <div class="text-sm text-green-800">Her zaman "work_start" aktivitesi</div>
                </div>
                <div class="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <div class="font-semibold text-red-900">work_end</div>
                    <div class="text-sm text-red-800">Her zaman "work_end" aktivitesi</div>
                </div>
                <div class="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div class="font-semibold text-yellow-900">break_toggle</div>
                    <div class="text-sm text-yellow-800">Duruma göre "break_start" veya "break_end"</div>
                </div>
                <div class="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div class="font-semibold text-blue-900">user_choice</div>
                    <div class="text-sm text-blue-800">Akıllı tespit: çalışma durumuna göre</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function testSpecificQR(qrData) {
            document.getElementById('test_qr_code').value = qrData;
            document.querySelector('form').submit();
        }
    </script>
</body>
</html>