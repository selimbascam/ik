<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access - try multiple session variables for compatibility
$hasAccess = false;
$userRole = '';
$companyId = '';

// Check different possible session structures
if (isset($_SESSION['user_role']) && ($_SESSION['user_role'] === 'admin' || $_SESSION['user_role'] === 'super_admin')) {
    $hasAccess = true;
    $userRole = $_SESSION['user_role'];
    $companyId = $_SESSION['company_id'] ?? '';
} elseif (isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'super_admin')) {
    $hasAccess = true;
    $userRole = $_SESSION['role'];
    $companyId = $_SESSION['company_id'] ?? '';
} elseif (isset($_SESSION['super_admin']) && $_SESSION['super_admin']) {
    $hasAccess = true;
    $userRole = 'super_admin';
    $companyId = $_SESSION['company_id'] ?? '1';
} elseif (isset($_SESSION['admin']) && $_SESSION['admin']) {
    $hasAccess = true;
    $userRole = 'admin';
    $companyId = $_SESSION['company_id'] ?? '';
}

if (!$hasAccess) {
    // Show simple login check instead of redirect
    echo "<h2>🔐 Erişim Kontrolü</h2>";
    echo "<p>Bu sayfaya erişim için admin yetkisi gerekiyor.</p>";
    echo "<p>Session bilgileri:</p>";
    echo "<ul>";
    foreach ($_SESSION as $key => $value) {
        if (is_string($value) || is_numeric($value)) {
            echo "<li>$key: " . htmlspecialchars($value) . "</li>";
        }
    }
    echo "</ul>";
    echo "<p><a href='../auth/company-login.php'>Giriş Yap</a></p>";
    exit;
}

// Set global session values for the rest of the script
$_SESSION['user_role'] = $userRole;
if ($companyId) {
    $_SESSION['company_id'] = $companyId;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔧 Personel Numarası Tutarlılık Düzeltme Aracı</h2>";
    echo "<p><strong>Kullanıcı:</strong> " . ($userRole ?: 'Bilinmiyor') . " | <strong>Şirket ID:</strong> " . ($companyId ?: 'Bilinmiyor') . "</p>";
    
    // If no company ID, try to get it from user table or show error
    if (!$companyId) {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
        echo "<h4>⚠️ Şirket ID Bulunamadı</h4>";
        echo "<p>Bu aracı kullanmak için şirket ID'si gerekiyor.</p>";
        echo "</div>";
        exit;
    }
    
    if ($_POST['action'] ?? '' === 'sync_employee_numbers') {
        echo "<h3>✅ Personel Numaraları Eşitleme İşlemi</h3>";
        
        // Step 1: Sync tc_identity to employee_code where tc_identity exists
        $stmt = $conn->prepare("
            UPDATE employees 
            SET employee_code = tc_no 
            WHERE company_id = ?
            AND tc_no IS NOT NULL 
            AND tc_no != '' 
        ");
        $stmt->execute([$_SESSION['company_id']]);
        $affectedRows = $stmt->rowCount();
        
        echo "<p>✅ $affectedRows personelin employee_code alanı tc_no ile eşitlendi.</p>";
        
        // Step 2: Sync tc_no to employee_number field for backward compatibility
        $stmt2 = $conn->prepare("
            UPDATE employees 
            SET employee_number = tc_no 
            WHERE company_id = ?
            AND tc_no IS NOT NULL 
            AND tc_no != '' 
        ");
        $stmt2->execute([$_SESSION['company_id']]);
        $affectedRows2 = $stmt2->rowCount();
        
        echo "<p>✅ $affectedRows2 personelin employee_number alanı tc_no ile eşitlendi.</p>";
        
        // Step 3: For records where tc_no is empty but employee_code exists, sync employee_code to other fields
        $stmt3 = $conn->prepare("
            UPDATE employees 
            SET tc_no = employee_code, employee_number = employee_code 
            WHERE company_id = ?
            AND (tc_no IS NULL OR tc_no = '') 
            AND employee_code IS NOT NULL 
            AND employee_code != ''
        ");
        $stmt3->execute([$_SESSION['company_id']]);
        $affectedRows3 = $stmt3->rowCount();
        
        echo "<p>✅ $affectedRows3 personelin tc_no ve employee_number alanları employee_code ile eşitlendi.</p>";
        
        // Step 4: For records where all are empty, generate consistent values
        $stmt4 = $conn->prepare("
            UPDATE employees 
            SET employee_code = CONCAT('EMP', id), 
                employee_number = CONCAT('EMP', id),
                tc_no = CONCAT('EMP', id)
            WHERE company_id = ?
            AND (tc_no IS NULL OR tc_no = '') 
            AND (employee_code IS NULL OR employee_code = '') 
            AND (employee_number IS NULL OR employee_number = '')
        ");
        $stmt4->execute([$_SESSION['company_id']]);
        $affectedRows4 = $stmt4->rowCount();
        
        echo "<p>✅ $affectedRows4 personelin tüm alanları EMP formatında eşitlendi.</p>";
        
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "<strong>✅ İşlem Tamamlandı!</strong><br>";
        echo "Artık tüm personel listelerinde tutarlı numaralar görünecek.";
        echo "</div>";
    }
    
    // Show current status
    echo "<h3>📊 Mevcut Durum Analizi</h3>";
    
    $stmt = $conn->prepare("
        SELECT 
            id,
            first_name,
            last_name,
            employee_code,
            employee_number,
            COALESCE(tc_no, '') as tc_identity,
            CASE 
                WHEN tc_no IS NOT NULL AND tc_no != '' THEN tc_no
                WHEN employee_code IS NOT NULL AND employee_code != '' THEN employee_code  
                WHEN employee_number IS NOT NULL AND employee_number != '' THEN employee_number
                ELSE CONCAT('EMP', id)
            END as display_number,
            CASE 
                WHEN tc_no = employee_code AND tc_no = employee_number THEN 'Tutarlı'
                WHEN tc_no IS NOT NULL AND (tc_no != employee_code OR tc_no != employee_number) THEN 'Tutarsız'
                ELSE 'Eksik Veri'
            END as status
        FROM employees 
        WHERE company_id = ?
        ORDER BY id
    ");
    $stmt->execute([$_SESSION['company_id']]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th>ID</th><th>Ad Soyad</th><th>employee_code</th><th>employee_number</th><th>tc_identity</th><th>Görünecek No</th><th>Durum</th>";
    echo "</tr>";
    
    $inconsistentCount = 0;
    foreach ($employees as $emp) {
        $statusColor = '';
        if ($emp['status'] === 'Tutarsız') {
            $statusColor = 'background: #f8d7da;';
            $inconsistentCount++;
        } elseif ($emp['status'] === 'Tutarlı') {
            $statusColor = 'background: #d4edda;';
        } else {
            $statusColor = 'background: #fff3cd;';
        }
        
        echo "<tr style='$statusColor'>";
        echo "<td>" . $emp['id'] . "</td>";
        echo "<td>" . htmlspecialchars(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) . "</td>";
        echo "<td>" . htmlspecialchars($emp['employee_code'] ?: 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($emp['employee_number'] ?: 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($emp['tc_identity'] ?: 'NULL') . "</td>";
        echo "<td><strong>" . htmlspecialchars($emp['display_number']) . "</strong></td>";
        echo "<td>" . $emp['status'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    if ($inconsistentCount > 0) {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
        echo "<h4>⚠️ $inconsistentCount Personelde Tutarsızlık Tespit Edildi</h4>";
        echo "<p>Personel yönetiminde görünen numaralar ile vardiya atama listesinde görünen numaralar farklı.</p>";
        echo "<form method='POST'>";
        echo "<input type='hidden' name='action' value='sync_employee_numbers'>";
        echo "<button type='submit' style='background: #dc3545; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;'>🔧 Personel Numaralarını Eşitle</button>";
        echo "</form>";
        echo "<p><small>Bu işlem tc_no değerlerini employee_code ve employee_number alanlarına kopyalayacak.</small></p>";
        echo "</div>";
    } else {
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
        echo "<h4>✅ Tüm Personel Numaraları Tutarlı</h4>";
        echo "<p>Personel yönetimi ve vardiya atama listelerinde aynı numaralar görünüyor.</p>";
        echo "</div>";
    }
    
    echo "<hr>";
    echo "<p><a href='../admin/shift-management.php'>← Vardiya Yönetimine Dön</a></p>";
    echo "<p><a href='../admin/employee-management.php'>← Personel Yönetimine Dön</a></p>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Hata Oluştu</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>