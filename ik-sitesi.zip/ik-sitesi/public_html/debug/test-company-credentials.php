<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔍 Company Login Credentials Test</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;} table{border-collapse:collapse;margin:10px 0;} th,td{border:1px solid #ccc;padding:8px;}</style>";

$testEmail = "zeynep@szb.com.tr";
$testPassword = "Abc123456";
$testCode = "SZB38211";

echo "<h2>📋 Testing Credentials:</h2>";
echo "<ul>";
echo "<li><strong>Email:</strong> $testEmail</li>";
echo "<li><strong>Password:</strong> $testPassword</li>";
echo "<li><strong>Company Code:</strong> $testCode</li>";
echo "</ul>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔍 Companies Table Analysis</h2>";
    
    // Check companies table structure
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $companyColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>📊 Table Structure:</h3>";
    echo "<table>";
    echo "<tr><th>Column</th><th>Type</th><th>Null</th><th>Default</th></tr>";
    
    $columnNames = [];
    foreach ($companyColumns as $col) {
        $columnNames[] = $col['Field'];
        echo "<tr>";
        echo "<td><strong>{$col['Field']}</strong></td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check all companies
    echo "<h3>📋 All Companies in Database:</h3>";
    $stmt = $conn->query("SELECT * FROM companies LIMIT 10");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($companies) {
        echo "<table>";
        echo "<tr>";
        foreach ($columnNames as $col) {
            echo "<th>$col</th>";
        }
        echo "</tr>";
        
        foreach ($companies as $company) {
            echo "<tr>";
            foreach ($columnNames as $col) {
                $value = $company[$col] ?? 'NULL';
                if ($col === 'password') {
                    $value = str_repeat('*', strlen($value));
                }
                echo "<td>$value</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='error'>❌ No companies found in database</p>";
    }
    
    // Test specific company lookup
    echo "<h3>🎯 Testing Company Lookup:</h3>";
    
    // Map column names for compatibility
    $emailCol = in_array('email', $columnNames) ? 'email' : 
               (in_array('admin_email', $columnNames) ? 'admin_email' : 'email');
               
    $codeCol = in_array('company_code', $columnNames) ? 'company_code' : 
              (in_array('code', $columnNames) ? 'code' : 'company_code');
              
    $nameCol = in_array('company_name', $columnNames) ? 'company_name' : 
              (in_array('name', $columnNames) ? 'name' : 'company_name');
              
    $activeCol = in_array('is_active', $columnNames) ? 'is_active' : 
                (in_array('status', $columnNames) ? 'status' : 'is_active');
    
    echo "<p><strong>Column Mapping:</strong></p>";
    echo "<ul>";
    echo "<li>Email: <code>$emailCol</code></li>";
    echo "<li>Code: <code>$codeCol</code></li>";
    echo "<li>Name: <code>$nameCol</code></li>";
    echo "<li>Active: <code>$activeCol</code></li>";
    echo "</ul>";
    
    // Search by email
    echo "<h4>🔍 Search by Email:</h4>";
    $stmt = $conn->prepare("SELECT * FROM companies WHERE $emailCol = ?");
    $stmt->execute([$testEmail]);
    $companyByEmail = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($companyByEmail) {
        echo "<p class='success'>✅ Company found by email</p>";
        echo "<pre>" . print_r($companyByEmail, true) . "</pre>";
    } else {
        echo "<p class='error'>❌ No company found with email: $testEmail</p>";
        
        // Try to find similar emails
        $stmt = $conn->prepare("SELECT $emailCol FROM companies WHERE $emailCol LIKE ?");
        $stmt->execute(['%' . substr($testEmail, 0, 5) . '%']);
        $similarEmails = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if ($similarEmails) {
            echo "<p class='info'>ℹ️ Similar emails found:</p>";
            echo "<ul>";
            foreach ($similarEmails as $email) {
                echo "<li>$email</li>";
            }
            echo "</ul>";
        }
    }
    
    // Search by company code
    echo "<h4>🔍 Search by Company Code:</h4>";
    $stmt = $conn->prepare("SELECT * FROM companies WHERE $codeCol = ?");
    $stmt->execute([$testCode]);
    $companyByCode = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($companyByCode) {
        echo "<p class='success'>✅ Company found by code</p>";
        echo "<pre>" . print_r($companyByCode, true) . "</pre>";
    } else {
        echo "<p class='error'>❌ No company found with code: $testCode</p>";
        
        // Try to find similar codes
        $stmt = $conn->prepare("SELECT $codeCol FROM companies WHERE $codeCol LIKE ?");
        $stmt->execute(['%' . substr($testCode, 0, 3) . '%']);
        $similarCodes = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if ($similarCodes) {
            echo "<p class='info'>ℹ️ Similar codes found:</p>";
            echo "<ul>";
            foreach ($similarCodes as $code) {
                echo "<li>$code</li>";
            }
            echo "</ul>";
        }
    }
    
    // Test password verification
    echo "<h4>🔐 Password Verification Test:</h4>";
    if ($companyByEmail || $companyByCode) {
        $company = $companyByEmail ?: $companyByCode;
        $storedPassword = $company['password'];
        
        echo "<p><strong>Stored password format:</strong> " . substr($storedPassword, 0, 20) . "...</p>";
        
        // Test different password verification methods
        $methods = [
            'MD5' => md5($testPassword),
            'SHA1' => sha1($testPassword),
            'Plain' => $testPassword,
            'MySQL PASSWORD()' => 'Will test with query'
        ];
        
        foreach ($methods as $method => $hash) {
            if ($method === 'MySQL PASSWORD()') {
                try {
                    $stmt = $conn->prepare("SELECT PASSWORD(?) as pwd_hash");
                    $stmt->execute([$testPassword]);
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    $hash = $result['pwd_hash'];
                    echo "<p><strong>$method:</strong> $hash ";
                    if ($hash === $storedPassword) {
                        echo "<span class='success'>✅ MATCH!</span></p>";
                    } else {
                        echo "<span class='error'>❌ No match</span></p>";
                    }
                } catch (Exception $e) {
                    echo "<p><strong>$method:</strong> <span class='error'>❌ Error: " . $e->getMessage() . "</span></p>";
                }
            } else {
                echo "<p><strong>$method:</strong> $hash ";
                if ($hash === $storedPassword) {
                    echo "<span class='success'>✅ MATCH!</span></p>";
                } else {
                    echo "<span class='error'>❌ No match</span></p>";
                }
            }
        }
    }
    
    echo "<div style='background:#f0f8ff;padding:15px;margin:20px 0;border-left:4px solid #007acc;'>";
    echo "<h3>🎯 Fix Recommendations</h3>";
    echo "<p>Based on the analysis above:</p>";
    echo "<ol>";
    echo "<li>Check if the email/company code exists in database</li>";
    echo "<li>Verify password encoding method matches stored format</li>";
    echo "<li>Ensure is_active/status field is properly set</li>";
    echo "<li>Update login logic to use correct column names</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Database error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='../auth/company-login.php'>🔙 Back to Company Login</a></p>";
?>