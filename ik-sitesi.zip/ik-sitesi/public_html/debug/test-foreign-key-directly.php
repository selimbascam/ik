<?php
// Direct foreign key test without config dependencies
$servername = "localhost";
$username = "u978874874_ik";
$password = "Szb2013@+-!";
$dbname = "u978874874_ik";

echo "<h2>🔧 Direct Foreign Key Test</h2>";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get test employee
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "❌ Employee not found<br>";
        exit;
    }
    
    echo "✅ Employee: {$employee['first_name']} {$employee['last_name']}<br>";
    echo "Company ID: " . ($employee['company_id'] ?? 'NULL') . "<br>";
    
    // Fix company if needed
    if (!$employee['company_id']) {
        $stmt = $pdo->prepare("SELECT id FROM companies ORDER BY id LIMIT 1");
        $stmt->execute();
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($company) {
            $stmt = $pdo->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
            $stmt->execute([$company['id'], $employee['id']]);
            $employee['company_id'] = $company['id'];
            echo "✅ Fixed company_id: {$company['id']}<br>";
        }
    }
    
    // Get QR location
    $stmt = $pdo->prepare("SELECT id FROM qr_locations WHERE company_id = ? LIMIT 1");
    $stmt->execute([$employee['company_id']]);
    $location = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$location) {
        $stmt = $pdo->prepare("INSERT INTO qr_locations (company_id, name, location_type, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$employee['company_id'], 'Test Location', 'entrance', 'active']);
        $location_id = $pdo->lastInsertId();
        echo "✅ Created QR location: $location_id<br>";
    } else {
        $location_id = $location['id'];
        echo "✅ Found QR location: $location_id<br>";
    }
    
    // Test foreign key
    $pdo->beginTransaction();
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO attendance_records 
            (company_id, employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date) 
            VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
        ");
        
        $result = $stmt->execute([
            $employee['company_id'],
            $employee['id'],
            $location_id,
            'work_start',
            'Direct FK test'
        ]);
        
        if ($result) {
            $recordId = $pdo->lastInsertId();
            echo "✅ SUCCESS! Record inserted: $recordId<br>";
            
            // Clean up
            $stmt = $pdo->prepare("DELETE FROM attendance_records WHERE id = ?");
            $stmt->execute([$recordId]);
            echo "🧹 Cleaned up<br>";
        }
        
        $pdo->commit();
        
    } catch (Exception $e) {
        $pdo->rollback();
        echo "❌ FK Error: " . $e->getMessage() . "<br>";
    }
    
    echo "<div style='background: #d4edda; padding: 10px; margin-top: 20px;'>";
    echo "Test completed - Employee: {$employee['id']}, Company: {$employee['company_id']}, Location: $location_id";
    echo "</div>";
    
} catch (Exception $e) {
    echo "❌ Connection error: " . $e->getMessage();
}
?>