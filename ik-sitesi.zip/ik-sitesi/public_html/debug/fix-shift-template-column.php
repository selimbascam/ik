<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔧 Shift Template Column Fix</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>📋 Employee Shifts Table Kontrolü</h3>";
    
    // Check employee_shifts table structure
    $stmt = $conn->query("SHOW COLUMNS FROM employee_shifts");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th>";
    echo "</tr>";
    
    $hasShiftTemplateId = false;
    $hasTemplateId = false;
    
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($col['Field'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Type'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Null'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Key'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Default'] ?? '') . "</td>";
        echo "</tr>";
        
        if ($col['Field'] === 'shift_template_id') {
            $hasShiftTemplateId = true;
        }
        if ($col['Field'] === 'template_id') {
            $hasTemplateId = true;
        }
    }
    echo "</table>";
    
    echo "<h4>🔍 Kolon Durumu</h4>";
    echo "<ul>";
    echo "<li>shift_template_id: " . ($hasShiftTemplateId ? '✅ Var' : '❌ Eksik') . "</li>";
    echo "<li>template_id: " . ($hasTemplateId ? '✅ Var' : '❌ Eksik') . "</li>";
    echo "</ul>";
    
    // Add missing columns
    if (!$hasShiftTemplateId && !$hasTemplateId) {
        echo "<h4>🔧 shift_template_id Kolonu Ekleniyor</h4>";
        
        try {
            $conn->exec("
                ALTER TABLE employee_shifts 
                ADD COLUMN shift_template_id INT NULL,
                ADD INDEX idx_shift_template (shift_template_id)
            ");
            echo "<p>✅ shift_template_id kolonu eklendi</p>";
            
        } catch (Exception $e) {
            echo "<p>❌ Kolon eklenemedi: " . $e->getMessage() . "</p>";
            
            // Try without index
            try {
                $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT NULL");
                echo "<p>✅ shift_template_id kolonu eklendi (index olmadan)</p>";
            } catch (Exception $e2) {
                echo "<p>❌ Kolon yine eklenemedi: " . $e2->getMessage() . "</p>";
            }
        }
        
    } elseif (!$hasShiftTemplateId && $hasTemplateId) {
        echo "<h4>🔧 template_id → shift_template_id Dönüşümü</h4>";
        
        try {
            // Copy data from template_id to new shift_template_id column
            $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT NULL");
            $conn->exec("UPDATE employee_shifts SET shift_template_id = template_id WHERE template_id IS NOT NULL");
            echo "<p>✅ template_id verisi shift_template_id'ye kopyalandı</p>";
            
        } catch (Exception $e) {
            echo "<p>❌ Dönüşüm hatası: " . $e->getMessage() . "</p>";
        }
    }
    
    // Check shift_templates table
    echo "<h3>📊 Shift Templates Table</h3>";
    
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
        $templateTableExists = $stmt->rowCount() > 0;
        
        if (!$templateTableExists) {
            echo "<p>❌ shift_templates tablosu bulunamadı - oluşturuluyor...</p>";
            
            $createTableSQL = "
                CREATE TABLE shift_templates (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    name VARCHAR(255) NOT NULL,
                    start_time TIME NOT NULL,
                    end_time TIME NOT NULL,
                    break_duration INT DEFAULT 60,
                    description TEXT,
                    color_code VARCHAR(7) DEFAULT '#3B82F6',
                    is_active TINYINT(1) DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX idx_company (company_id)
                )
            ";
            
            $conn->exec($createTableSQL);
            echo "<p>✅ shift_templates tablosu oluşturuldu</p>";
            
            // Create default shift templates
            $defaultTemplates = [
                ['Gündüz Vardiyası', '08:00:00', '16:00:00', 60, 'Standart gündüz mesaisi', '#3B82F6'],
                ['Akşam Vardiyası', '16:00:00', '00:00:00', 60, 'Akşam mesaisi', '#EF4444'],
                ['Gece Vardiyası', '00:00:00', '08:00:00', 60, 'Gece mesaisi', '#8B5CF6']
            ];
            
            foreach ($defaultTemplates as [$name, $start, $end, $break, $desc, $color]) {
                $stmt = $conn->prepare("
                    INSERT INTO shift_templates 
                    (company_id, name, start_time, end_time, break_duration, description, color_code)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([4, $name, $start, $end, $break, $desc, $color]); // company_id = 4 for test
            }
            
            echo "<p>✅ Default vardiya şablonları oluşturuldu</p>";
            
        } else {
            echo "<p>✅ shift_templates tablosu mevcut</p>";
            
            // Check existing templates
            $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p>Mevcut şablon sayısı: $count</p>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ Shift templates kontrolü başarısız: " . $e->getMessage() . "</p>";
    }
    
    // Test the fix
    echo "<h4>🧪 Sorgu Testi</h4>";
    
    try {
        $testStmt = $conn->prepare("
            SELECT 
                es.id,
                es.employee_id,
                es.shift_template_id,
                es.shift_date,
                es.status,
                COALESCE(st.name, 'Vardiya') as shift_name
            FROM employee_shifts es
            LEFT JOIN shift_templates st ON es.shift_template_id = st.id
            LIMIT 1
        ");
        $testStmt->execute();
        $testResult = $testStmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
        echo "<h4>✅ Sorgu Testi Başarılı!</h4>";
        echo "<p>Vardiya yönetimi artık çalışacak.</p>";
        if ($testResult) {
            echo "<p>Test verisi bulundu: " . json_encode($testResult) . "</p>";
        } else {
            echo "<p>Henüz vardiya ataması yok, ancak sorgu çalışıyor.</p>";
        }
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
        echo "<h4>❌ Sorgu Testi Başarısız</h4>";
        echo "<p>Hata: " . $e->getMessage() . "</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Genel Hata</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { border-collapse: collapse; width: 100%; margin: 10px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "</style>";

echo "<hr>";
echo "<p><a href='../admin/shift-management.php'>← Vardiya Yönetimi'ne Dön</a></p>";
?>