<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

session_start();

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Work Settings Tanı ve Düzeltme</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100'>
    <div class='container mx-auto px-4 py-8 max-w-4xl'>
        <div class='bg-white rounded-lg shadow-lg p-6'>
            <h1 class='text-2xl font-bold text-gray-900 mb-6'>⚙️ Work Settings Tanı ve Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-6'>";
    
    // 1. Check if work-settings.php file exists and is readable
    echo "<div class='border-l-4 border-blue-500 bg-blue-50 p-4'>
            <h2 class='text-lg font-semibold text-blue-800'>1. Dosya Kontrol</h2>";
    
    $workSettingsPath = '../admin/work-settings.php';
    if (file_exists($workSettingsPath)) {
        if (is_readable($workSettingsPath)) {
            echo "<p class='text-green-600'>✅ work-settings.php dosyası mevcut ve okunabilir</p>";
            
            // Check PHP syntax
            $output = shell_exec("php -l $workSettingsPath 2>&1");
            if (strpos($output, 'No syntax errors') !== false) {
                echo "<p class='text-green-600'>✅ PHP syntax kontrol: OK</p>";
            } else {
                echo "<p class='text-red-600'>❌ PHP syntax hatası: $output</p>";
            }
        } else {
            echo "<p class='text-red-600'>❌ work-settings.php dosyası okunamıyor (izin sorunu)</p>";
        }
    } else {
        echo "<p class='text-red-600'>❌ work-settings.php dosyası bulunamadı</p>";
    }
    echo "</div>";
    
    // 2. Database connection test
    echo "<div class='border-l-4 border-green-500 bg-green-50 p-4'>
            <h2 class='text-lg font-semibold text-green-800'>2. Database Bağlantı Testi</h2>";
    
    try {
        $testResult = $db->testConnection();
        if ($testResult['success']) {
            echo "<p class='text-green-600'>✅ Database bağlantısı başarılı</p>";
        } else {
            echo "<p class='text-red-600'>❌ Database bağlantı hatası: " . $testResult['message'] . "</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Database test hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 3. Session check
    echo "<div class='border-l-4 border-purple-500 bg-purple-50 p-4'>
            <h2 class='text-lg font-semibold text-purple-800'>3. Session Kontrol</h2>";
    
    if (session_status() === PHP_SESSION_ACTIVE) {
        echo "<p class='text-green-600'>✅ Session aktif</p>";
        
        if (isset($_SESSION['user_role'])) {
            $role = $_SESSION['user_role'];
            echo "<p class='text-sm'>Kullanıcı rolü: <span class='font-medium'>$role</span></p>";
            
            if (in_array($role, ['admin', 'super_admin'])) {
                echo "<p class='text-green-600'>✅ Work settings erişim yetkisi var</p>";
            } else {
                echo "<p class='text-red-600'>❌ Work settings erişim yetkisi yok (admin/super_admin gerekli)</p>";
            }
        } else {
            echo "<p class='text-red-600'>❌ Kullanıcı rolü session'da bulunamadı</p>";
        }
        
        if (isset($_SESSION['company_id'])) {
            $companyId = $_SESSION['company_id'];
            echo "<p class='text-sm'>Company ID: <span class='font-medium'>$companyId</span></p>";
        } else {
            echo "<p class='text-orange-600'>⚠️ Company ID session'da bulunamadı</p>";
        }
    } else {
        echo "<p class='text-red-600'>❌ Session aktif değil</p>";
    }
    echo "</div>";
    
    // 4. Work settings table check
    echo "<div class='border-l-4 border-indigo-500 bg-indigo-50 p-4'>
            <h2 class='text-lg font-semibold text-indigo-800'>4. Work Settings Tablo Kontrol</h2>";
    
    try {
        // Check if table exists
        $stmt = $conn->query("SHOW TABLES LIKE 'work_settings'");
        if ($stmt->rowCount() > 0) {
            echo "<p class='text-green-600'>✅ work_settings tablosu mevcut</p>";
            
            // Check table structure
            $stmt = $conn->query("SHOW COLUMNS FROM work_settings");
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<p class='text-sm text-gray-600 mb-2'>Tablo sütunları:</p>
                  <ul class='list-disc list-inside ml-4 text-xs'>";
            foreach ($columns as $column) {
                echo "<li>{$column['Field']} - {$column['Type']}</li>";
            }
            echo "</ul>";
            
            // Check for records
            $stmt = $conn->query("SELECT COUNT(*) as count FROM work_settings");
            $recordCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p class='text-sm mt-2'>Toplam kayıt sayısı: <span class='font-medium'>$recordCount</span></p>";
            
        } else {
            echo "<p class='text-orange-600'>⚠️ work_settings tablosu bulunamadı</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Tablo kontrol hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 5. Test work-settings access
    echo "<div class='border-l-4 border-orange-500 bg-orange-50 p-4'>
            <h2 class='text-lg font-semibold text-orange-800'>5. Work Settings Sayfa Test</h2>";
    
    // Simulate accessing work-settings.php
    if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'super_admin'])) {
        echo "<p class='text-green-600'>✅ Yetki kontrolü geçti</p>";
        
        if (isset($_SESSION['company_id'])) {
            $companyId = $_SESSION['company_id'];
            
            try {
                // Test the exact query from work-settings.php
                $stmt = $conn->prepare("SELECT * FROM work_settings WHERE company_id = ?");
                $stmt->execute([$companyId]);
                $workSettings = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($workSettings) {
                    echo "<p class='text-green-600'>✅ Company $companyId için work settings bulundu</p>";
                    echo "<div class='mt-2 text-xs'>
                            <p><strong>Mevcut ayarlar:</strong></p>
                            <ul class='list-disc list-inside ml-4'>";
                    foreach (['daily_work_hours', 'weekly_work_hours', 'overtime_multiplier', 'hourly_rate'] as $key) {
                        if (isset($workSettings[$key])) {
                            echo "<li>$key: {$workSettings[$key]}</li>";
                        }
                    }
                    echo "</ul></div>";
                } else {
                    echo "<p class='text-orange-600'>⚠️ Company $companyId için work settings bulunamadı (varsayılan değerler kullanılacak)</p>";
                }
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Work settings sorgu hatası: " . $e->getMessage() . "</p>";
            }
        } else {
            echo "<p class='text-red-600'>❌ Company ID bulunamadı</p>";
        }
    } else {
        echo "<p class='text-red-600'>❌ Yetki kontrolü başarısız</p>";
    }
    echo "</div>";
    
    // 6. Auto-fix actions
    echo "<div class='border-l-4 border-red-500 bg-red-50 p-4'>
            <h2 class='text-lg font-semibold text-red-800'>6. Otomatik Düzeltme İşlemleri</h2>";
    
    if (isset($_POST['fix_action'])) {
        $action = $_POST['fix_action'];
        
        if ($action === 'create_work_settings_table') {
            try {
                $conn->exec("
                    CREATE TABLE IF NOT EXISTS work_settings (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        company_id INT NOT NULL,
                        daily_work_hours INT DEFAULT 8,
                        weekly_work_hours INT DEFAULT 45,
                        monthly_work_hours INT DEFAULT 225,
                        overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
                        holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
                        weekend_multiplier DECIMAL(3,2) DEFAULT 1.50,
                        grace_period_minutes INT DEFAULT 15,
                        late_penalty_amount DECIMAL(10,2) DEFAULT 0,
                        min_break_duration INT DEFAULT 30,
                        max_break_duration INT DEFAULT 60,
                        hourly_rate DECIMAL(10,2) DEFAULT 50.00,
                        weekly_holiday INT DEFAULT 1,
                        auto_schedule TINYINT(1) DEFAULT 1,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        UNIQUE KEY unique_company (company_id)
                    )
                ");
                echo "<p class='text-green-600'>✅ work_settings tablosu başarıyla oluşturuldu</p>";
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Tablo oluşturma hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        if ($action === 'create_default_settings') {
            try {
                $companyId = $_SESSION['company_id'] ?? 4; // Fallback to company ID 4
                
                $stmt = $conn->prepare("
                    INSERT IGNORE INTO work_settings 
                    (company_id, daily_work_hours, weekly_work_hours, monthly_work_hours, overtime_multiplier, holiday_multiplier, weekend_multiplier, grace_period_minutes, late_penalty_amount, min_break_duration, max_break_duration, hourly_rate, weekly_holiday, auto_schedule) 
                    VALUES (?, 8, 45, 225, 1.50, 2.00, 1.50, 15, 0, 30, 60, 50.00, 1, 1)
                ");
                $stmt->execute([$companyId]);
                
                echo "<p class='text-green-600'>✅ Company $companyId için varsayılan work settings oluşturuldu</p>";
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Varsayılan ayar oluşturma hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        if ($action === 'fix_session_auth') {
            // Set basic admin session for testing
            $_SESSION['user_role'] = 'admin';
            $_SESSION['company_id'] = $_SESSION['company_id'] ?? 4;
            $_SESSION['user_name'] = 'Test Admin';
            
            echo "<p class='text-green-600'>✅ Test admin session ayarlandı</p>";
        }
        
        echo "<script>setTimeout(() => window.location.reload(), 2000);</script>";
    }
    
    echo "<div class='mt-4 grid grid-cols-1 md:grid-cols-3 gap-4'>
            <form method='POST'>
                <button type='submit' name='fix_action' value='create_work_settings_table' 
                        class='w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🗂️ Work Settings Tablosu Oluştur
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='create_default_settings' 
                        class='w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm'>
                    ⚙️ Varsayılan Ayarlar Oluştur
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='fix_session_auth' 
                        class='w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🔐 Test Admin Session
                </button>
            </form>
          </div>";
    
    echo "</div>";
    
    // 7. Navigation Links
    echo "<div class='border-t pt-4 mt-6'>
            <h3 class='text-lg font-medium text-gray-900 mb-3'>İlgili Sayfalar</h3>
            <div class='flex flex-wrap gap-3'>
                <a href='../admin/work-settings.php' class='bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm'>
                    ⚙️ Work Settings Sayfasına Dön
                </a>
                <a href='../super-admin/fix-critical-errors.php' class='bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🚨 Kritik Hata Düzeltme
                </a>
                <a href='../dashboard/company-dashboard.php' class='bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🏠 Dashboard
                </a>
            </div>
          </div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>
            <strong>Kritik Hata:</strong> " . $e->getMessage() . "
          </div>";
}

echo "        </div>
    </div>
</body>
</html>";
?>