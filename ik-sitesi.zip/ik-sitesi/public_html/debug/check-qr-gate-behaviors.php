<?php
// Check QR Gate Behaviors - Debug Tool
require_once '../includes/config.php';
require_once '../includes/database.php';

// Simple authentication check
if (!isset($_SESSION['employee_id']) && !isset($_SESSION['super_admin'])) {
    echo "Authentication required";
    exit;
}

date_default_timezone_set('Europe/Istanbul');

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>QR Lokasyon ve Gate Behavior Kontrolü</h2>";
    echo "<p><strong>Tarih:</strong> " . date('d/m/Y H:i:s') . "</p>";
    
    // Check if gate_behavior column exists
    $stmt = $conn->query("DESCRIBE qr_locations");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $hasGateBehavior = false;
    
    foreach ($columns as $column) {
        if ($column['Field'] === 'gate_behavior') {
            $hasGateBehavior = true;
            break;
        }
    }
    
    echo "<h3>Veritabanı Yapısı:</h3>";
    echo "<p>gate_behavior sütunu: " . ($hasGateBehavior ? "✅ Mevcut" : "❌ Eksik") . "</p>";
    
    if ($hasGateBehavior) {
        // Get all QR locations with gate behaviors
        $stmt = $conn->query("SELECT id, name, company_id, location_type, gate_behavior FROM qr_locations ORDER BY company_id, id");
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($locations)) {
            echo "<p>❌ Hiç QR lokasyonu bulunamadı.</p>";
        } else {
            echo "<h3>QR Lokasyonları (" . count($locations) . " adet):</h3>";
            echo "<table border='1' style='border-collapse:collapse; width:100%; margin:10px 0;'>";
            echo "<tr style='background:#f0f0f0;'>";
            echo "<th style='padding:8px;'>ID</th>";
            echo "<th style='padding:8px;'>Lokasyon Adı</th>";
            echo "<th style='padding:8px;'>Şirket ID</th>";
            echo "<th style='padding:8px;'>Lokasyon Türü</th>";
            echo "<th style='padding:8px;'>Gate Behavior</th>";
            echo "<th style='padding:8px;'>Beklenen Fonksiyon</th>";
            echo "<th style='padding:8px;'>Test</th>";
            echo "</tr>";
            
            foreach ($locations as $location) {
                $expectedFunction = '';
                $rowColor = '';
                
                switch ($location['gate_behavior']) {
                    case 'work_start':
                        $expectedFunction = '🚪 İş başlangıcı - sadece giriş';
                        $rowColor = 'background:#e6f3ff;';
                        break;
                    case 'work_end':
                        $expectedFunction = '🚪 İş bitişi - sadece çıkış';
                        $rowColor = 'background:#ffe6e6;';
                        break;
                    case 'break_toggle':
                        $expectedFunction = '☕ Mola kontrolü - mola başlat/bitir';
                        $rowColor = 'background:#fff3e0;';
                        break;
                    case 'user_choice':
                        $expectedFunction = '🔄 Otomatik tespit - duruma göre';
                        $rowColor = 'background:#f0f8e6;';
                        break;
                    default:
                        $expectedFunction = '❓ Tanımsız davranış';
                        $rowColor = 'background:#ffeeee;';
                }
                
                echo "<tr style='$rowColor'>";
                echo "<td style='padding:8px; text-align:center;'>" . $location['id'] . "</td>";
                echo "<td style='padding:8px;'><strong>" . htmlspecialchars($location['name']) . "</strong></td>";
                echo "<td style='padding:8px; text-align:center;'>" . $location['company_id'] . "</td>";
                echo "<td style='padding:8px;'>" . $location['location_type'] . "</td>";
                echo "<td style='padding:8px;'><code>" . ($location['gate_behavior'] ?: 'NULL') . "</code></td>";
                echo "<td style='padding:8px;'>" . $expectedFunction . "</td>";
                echo "<td style='padding:8px;'><a href='../test-qr-scan.php?location_id=" . $location['id'] . "&test_behavior=" . $location['gate_behavior'] . "' target='_blank'>Test Et</a></td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
        // Check for SZB Mühendislik company specifically
        echo "<h3>SZB Mühendislik Lokasyonları:</h3>";
        $stmt = $conn->prepare("
            SELECT ql.*, c.company_name 
            FROM qr_locations ql 
            JOIN companies c ON ql.company_id = c.id 
            WHERE c.company_name LIKE '%SZB%' OR c.company_name LIKE '%Mühendislik%'
            ORDER BY ql.id
        ");
        $stmt->execute();
        $szbLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($szbLocations)) {
            echo "<p>❌ SZB Mühendislik için QR lokasyonu bulunamadı.</p>";
        } else {
            foreach ($szbLocations as $loc) {
                echo "<div style='border:1px solid #ddd; padding:10px; margin:5px 0; border-radius:5px;'>";
                echo "<strong>" . htmlspecialchars($loc['name']) . "</strong> (ID: " . $loc['id'] . ")<br>";
                echo "Şirket: " . htmlspecialchars($loc['company_name']) . "<br>";
                echo "Gate Behavior: <code>" . ($loc['gate_behavior'] ?: 'NULL') . "</code><br>";
                echo "Location Type: " . $loc['location_type'] . "<br>";
                echo "<a href='test-qr-behavior.php?location_id=" . $loc['id'] . "'>🧪 Test Et</a>";
                echo "</div>";
            }
        }
        
    } else {
        echo "<p>❌ gate_behavior sütunu eksik. Sütunu eklemek için:</p>";
        echo "<code>ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(20) DEFAULT 'user_choice';</code>";
    }
    
    // Test QR scanning logic
    echo "<h3>🧪 QR Tarama Mantığı Testi:</h3>";
    echo "<p>Her QR kodu için beklenen davranış:</p>";
    echo "<ul>";
    echo "<li><strong>work_start:</strong> Sadece iş başlangıcı kaydı yapabilir</li>";
    echo "<li><strong>work_end:</strong> Sadece iş bitişi kaydı yapabilir</li>";
    echo "<li><strong>break_toggle:</strong> Mola başlat/bitir geçişi yapar</li>";
    echo "<li><strong>user_choice:</strong> Duruma göre otomatik karar verir</li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Hata: " . $e->getMessage() . "</p>";
}
?>

<h3>🔧 Sorun Giderme Araçları:</h3>
<p>
<a href="test-qr-gate-behavior.php" style="background:#007cba; color:white; padding:8px 16px; text-decoration:none; border-radius:4px;">🚪 Gate Behavior Test</a>
<a href="../test-qr-scan.php" style="background:#28a745; color:white; padding:8px 16px; text-decoration:none; border-radius:4px; margin-left:10px;">📱 QR Tarama Test</a>
<a href="../super-admin/system-tools/comprehensive-analysis.php" style="background:#6c757d; color:white; padding:8px 16px; text-decoration:none; border-radius:4px; margin-left:10px;">📊 Sistem Analizi</a>
</p>