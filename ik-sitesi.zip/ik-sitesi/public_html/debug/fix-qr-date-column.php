<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔧 QR Date Column Fix</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>📋 Attendance Records Table Structure Check</h3>";
    
    // Check attendance_records table structure
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th>";
    echo "</tr>";
    
    $hasDateColumn = false;
    $hasCreatedAtColumn = false;
    $hasCheckInTimeColumn = false;
    
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($col['Field'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Type'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Null'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Key'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Default'] ?? '') . "</td>";
        echo "</tr>";
        
        if ($col['Field'] === 'date') {
            $hasDateColumn = true;
        }
        if ($col['Field'] === 'created_at') {
            $hasCreatedAtColumn = true;
        }
        if ($col['Field'] === 'check_in_time') {
            $hasCheckInTimeColumn = true;
        }
    }
    echo "</table>";
    
    echo "<h4>🔍 Column Analysis</h4>";
    echo "<ul>";
    echo "<li>date column: " . ($hasDateColumn ? '✅ EXISTS' : '❌ MISSING') . "</li>";
    echo "<li>created_at column: " . ($hasCreatedAtColumn ? '✅ EXISTS' : '❌ MISSING') . "</li>";
    echo "<li>check_in_time column: " . ($hasCheckInTimeColumn ? '✅ EXISTS' : '❌ MISSING') . "</li>";
    echo "</ul>";
    
    // Fix missing date column if needed
    if (!$hasDateColumn && $hasCreatedAtColumn) {
        echo "<h4>🔧 Adding missing 'date' column</h4>";
        
        try {
            $conn->exec("
                ALTER TABLE attendance_records 
                ADD COLUMN date DATE GENERATED ALWAYS AS (DATE(created_at)) STORED,
                ADD INDEX idx_date (date)
            ");
            echo "<p>✅ Virtual 'date' column added based on created_at</p>";
            
        } catch (Exception $e) {
            // Try simpler approach without generated column
            try {
                $conn->exec("ALTER TABLE attendance_records ADD COLUMN date DATE NULL");
                $conn->exec("UPDATE attendance_records SET date = DATE(created_at) WHERE created_at IS NOT NULL");
                $conn->exec("ALTER TABLE attendance_records ADD INDEX idx_date (date)");
                echo "<p>✅ Physical 'date' column added and populated</p>";
                
            } catch (Exception $e2) {
                echo "<p>❌ Failed to add date column: " . $e2->getMessage() . "</p>";
            }
        }
    } elseif (!$hasDateColumn && $hasCheckInTimeColumn) {
        echo "<h4>🔧 Adding 'date' column based on check_in_time</h4>";
        
        try {
            $conn->exec("ALTER TABLE attendance_records ADD COLUMN date DATE NULL");
            $conn->exec("UPDATE attendance_records SET date = DATE(check_in_time) WHERE check_in_time IS NOT NULL");
            $conn->exec("ALTER TABLE attendance_records ADD INDEX idx_date (date)");
            echo "<p>✅ 'date' column added and populated from check_in_time</p>";
            
        } catch (Exception $e) {
            echo "<p>❌ Failed to add date column: " . $e->getMessage() . "</p>";
        }
    }
    
    // Test problematic queries
    echo "<h4>🧪 Testing Common QR Attendance Queries</h4>";
    
    // Test 1: Today's attendance query with date column
    try {
        $testStmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM attendance_records 
            WHERE employee_id = ? AND date = CURDATE()
        ");
        $testStmt->execute([1]); // Test with employee ID 1
        $result = $testStmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>✅ Date-based query test PASSED (found " . ($result['count'] ?? 0) . " records today)</p>";
        
    } catch (Exception $e) {
        echo "<p>❌ Date-based query FAILED: " . $e->getMessage() . "</p>";
        
        // Fallback test with DATE(created_at)
        try {
            $testStmt = $conn->prepare("
                SELECT COUNT(*) as count 
                FROM attendance_records 
                WHERE employee_id = ? AND DATE(created_at) = CURDATE()
            ");
            $testStmt->execute([1]);
            $result = $testStmt->fetch(PDO::FETCH_ASSOC);
            echo "<p>✅ DATE(created_at) fallback query PASSED (found " . ($result['count'] ?? 0) . " records today)</p>";
            
        } catch (Exception $e2) {
            echo "<p>❌ Fallback query also FAILED: " . $e2->getMessage() . "</p>";
        }
    }
    
    // Test 2: Check QR locations table
    echo "<h4>📍 QR Locations Table Check</h4>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations");
        $qrCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>QR Locations available: $qrCount</p>";
        
        if ($qrCount > 0) {
            // Check QR locations table structure first
            $stmt = $conn->query("SHOW COLUMNS FROM qr_locations");
            $qrColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $nameCol = in_array('location_name', $qrColumns) ? 'location_name' : 
                      (in_array('name', $qrColumns) ? 'name' : 
                      (in_array('location', $qrColumns) ? 'location' : 'id'));
            
            $stmt = $conn->query("SELECT id, $nameCol as name, latitude, longitude FROM qr_locations LIMIT 3");
            $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<ul>";
            foreach ($locations as $loc) {
                echo "<li>ID: " . ($loc['id'] ?? 'N/A') . " - " . htmlspecialchars($loc['name'] ?? 'Unnamed Location') . "</li>";
            }
            echo "</ul>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ QR Locations check failed: " . $e->getMessage() . "</p>";
    }
    
    // Generate corrected QR attendance queries
    echo "<h4>📝 Recommended Query Updates</h4>";
    
    if ($hasDateColumn) {
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
        echo "<h5>✅ Use 'date' column queries:</h5>";
        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 3px;'>";
        echo "-- Today's attendance\n";
        echo "SELECT * FROM attendance_records \n";
        echo "WHERE employee_id = ? AND date = CURDATE()\n\n";
        echo "-- Date range attendance\n";
        echo "SELECT * FROM attendance_records \n";
        echo "WHERE employee_id = ? AND date BETWEEN ? AND ?";
        echo "</pre>";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
        echo "<h5>⚠️ Use DATE(created_at) queries:</h5>";
        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 3px;'>";
        echo "-- Today's attendance\n";
        echo "SELECT * FROM attendance_records \n";
        echo "WHERE employee_id = ? AND DATE(created_at) = CURDATE()\n\n";
        echo "-- Date range attendance\n";
        echo "SELECT * FROM attendance_records \n";
        echo "WHERE employee_id = ? AND DATE(created_at) BETWEEN ? AND ?";
        echo "</pre>";
        echo "</div>";
    }
    
    echo "<h3>🔗 Next Steps</h3>";
    echo "<p><a href='../employee/qr-attendance.php' style='color: #0056b3; font-weight: bold;'>Test QR Attendance</a></p>";
    echo "<p><a href='../qr/activity-selection.php' style='color: #0056b3;'>Test QR Activity Selection</a></p>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Database Error</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { border-collapse: collapse; width: 100%; margin: 10px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "pre { overflow-x: auto; }";
echo "</style>";
?>