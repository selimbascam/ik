<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🎯 Complete Login System Test</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;} .test{background:#f9f9f9;padding:15px;margin:10px 0;border-left:3px solid #007acc;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='test'>";
    echo "<h2>🔧 Auto-Fix: Add Password Column</h2>";
    
    // Check and add password column
    $stmt = $conn->query("SHOW COLUMNS FROM companies LIKE 'password'");
    $passwordExists = $stmt->fetch();
    
    if (!$passwordExists) {
        $conn->exec("ALTER TABLE companies ADD COLUMN password VARCHAR(255) DEFAULT NULL");
        echo "<p class='success'>✅ Password column added to companies table</p>";
    } else {
        echo "<p class='info'>ℹ️ Password column already exists</p>";
    }
    echo "</div>";
    
    echo "<div class='test'>";
    echo "<h2>🔐 Auto-Fix: Set Password for Test Company</h2>";
    
    $email = 'zeynep@szb.com.tr';
    $password = 'Abc123456';
    $companyCode = 'SZB38211';
    $hashedPassword = md5($password);
    
    // Check if company exists
    $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ? AND company_code = ?");
    $stmt->execute([$email, $companyCode]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        // Update password
        $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE email = ? AND company_code = ?");
        $stmt->execute([$hashedPassword, $email, $companyCode]);
        echo "<p class='success'>✅ Password updated for {$company['company_name']}</p>";
        
        echo "<table border='1' style='border-collapse:collapse;margin:10px 0;'>";
        echo "<tr><th style='padding:8px;background:#f5f5f5;'>Login Credentials</th><th style='padding:8px;background:#f5f5f5;'>Value</th></tr>";
        echo "<tr><td style='padding:8px;'>Email</td><td style='padding:8px;'><strong>$email</strong></td></tr>";
        echo "<tr><td style='padding:8px;'>Password</td><td style='padding:8px;'><strong>$password</strong></td></tr>";
        echo "<tr><td style='padding:8px;'>Company Code</td><td style='padding:8px;'><strong>$companyCode</strong></td></tr>";
        echo "<tr><td style='padding:8px;'>Company Name</td><td style='padding:8px;'>{$company['company_name']}</td></tr>";
        echo "</table>";
    } else {
        echo "<p class='error'>❌ Company not found with email: $email and code: $companyCode</p>";
    }
    echo "</div>";
    
    echo "<div class='test'>";
    echo "<h2>🧪 Test Login Authentication</h2>";
    
    // Test the exact login logic from company-login.php
    $stmt = $conn->prepare("
        SELECT * FROM companies 
        WHERE email = ? AND password = MD5(?) AND company_code = ?
    ");
    $stmt->execute([$email, $password, $companyCode]);
    $loginTest = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($loginTest) {
        echo "<p class='success'>✅ LOGIN TEST SUCCESSFUL!</p>";
        echo "<p><strong>Authentication Method:</strong> MD5 Hash</p>";
        echo "<p><strong>Company Status:</strong> {$loginTest['status']}</p>";
        
        // Test company status check
        $isActive = ($loginTest['status'] === 'active' || $loginTest['status'] == 1);
        if ($isActive) {
            echo "<p class='success'>✅ Company is active - login will proceed</p>";
        } else {
            echo "<p class='error'>❌ Company is not active - login will be blocked</p>";
        }
    } else {
        echo "<p class='error'>❌ Login test failed</p>";
        
        // Debug alternative methods
        echo "<h3>🔍 Testing Alternative Methods:</h3>";
        
        // Try plain text
        $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ? AND password = ? AND company_code = ?");
        $stmt->execute([$email, $password, $companyCode]);
        $plainTest = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($plainTest) {
            echo "<p class='info'>ℹ️ Plain text password works</p>";
        } else {
            echo "<p class='error'>❌ Plain text password failed</p>";
        }
        
        // Check stored password
        $stmt = $conn->prepare("SELECT password FROM companies WHERE email = ? AND company_code = ?");
        $stmt->execute([$email, $companyCode]);
        $storedPwd = $stmt->fetchColumn();
        
        echo "<p><strong>Stored password hash:</strong> " . ($storedPwd ?: 'NULL') . "</p>";
        echo "<p><strong>Expected MD5 hash:</strong> " . md5($password) . "</p>";
        echo "<p><strong>Match:</strong> " . (($storedPwd === md5($password)) ? 'YES' : 'NO') . "</p>";
    }
    echo "</div>";
    
    echo "<div style='background:#d1ecf1;border:1px solid #bee5eb;padding:20px;margin:20px 0;'>";
    echo "<h2>🎯 Final Status</h2>";
    
    if ($loginTest && $loginTest['status'] === 'active') {
        echo "<p class='success'><strong>✅ LOGIN SYSTEM IS FULLY FUNCTIONAL</strong></p>";
        echo "<p>You can now successfully log in with the credentials above.</p>";
        echo "<p><a href='../auth/company-login.php' style='background:#28a745;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;'>🚀 Try Login Now</a></p>";
    } else {
        echo "<p class='error'><strong>❌ Login system needs manual intervention</strong></p>";
        echo "<p>Please check the debug information above and contact support.</p>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Test failed: " . $e->getMessage() . "</p>";
}
?>