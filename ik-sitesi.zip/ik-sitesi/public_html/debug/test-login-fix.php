<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔐 Company Login Fix Test</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;} .test{background:#f9f9f9;padding:10px;margin:10px 0;border-left:3px solid #007acc;}</style>";

// Test credentials from the screenshot
$testEmail = "zeynep@szb.com.tr";
$testPassword = "Abc123456";
$testCode = "SZB38211";

echo "<div class='test'>";
echo "<h2>🧪 Testing Login Credentials</h2>";
echo "<p><strong>Email:</strong> $testEmail</p>";
echo "<p><strong>Password:</strong> $testPassword</p>";
echo "<p><strong>Company Code:</strong> $testCode</p>";
echo "</div>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Test the new login logic
    echo "<h2>🔍 Step 1: Check Companies Table Structure</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $companyColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<p><strong>Available columns:</strong> " . implode(', ', $companyColumns) . "</p>";
    
    // Map column names
    $emailCol = in_array('email', $companyColumns) ? 'email' : 
               (in_array('admin_email', $companyColumns) ? 'admin_email' : 'email');
               
    $codeCol = in_array('company_code', $companyColumns) ? 'company_code' : 
              (in_array('code', $companyColumns) ? 'code' : 'company_code');
              
    $nameCol = in_array('company_name', $companyColumns) ? 'company_name' : 
              (in_array('name', $companyColumns) ? 'name' : 'company_name');
              
    $activeCol = in_array('is_active', $companyColumns) ? 'is_active' : 
                (in_array('status', $companyColumns) ? 'status' : 'is_active');
    
    echo "<div class='test'>";
    echo "<h3>📋 Column Mapping:</h3>";
    echo "<ul>";
    echo "<li>Email Column: <strong>$emailCol</strong></li>";
    echo "<li>Code Column: <strong>$codeCol</strong></li>";
    echo "<li>Name Column: <strong>$nameCol</strong></li>";
    echo "<li>Active Column: <strong>$activeCol</strong></li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<h2>🔍 Step 2: Search for Company by Email</h2>";
    $stmt = $conn->prepare("SELECT * FROM companies WHERE $emailCol = ?");
    $stmt->execute([$testEmail]);
    $companyByEmail = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($companyByEmail) {
        echo "<p class='success'>✅ Company found by email!</p>";
        echo "<table border='1' style='border-collapse:collapse;'>";
        echo "<tr><th>Field</th><th>Value</th></tr>";
        foreach ($companyByEmail as $key => $value) {
            if ($key === 'password') {
                $value = str_repeat('*', strlen($value ?? ''));
            }
            echo "<tr><td>$key</td><td>$value</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='error'>❌ No company found with email: $testEmail</p>";
    }
    
    echo "<h2>🔍 Step 3: Search by Company Code</h2>";
    $stmt = $conn->prepare("SELECT * FROM companies WHERE $codeCol = ?");
    $stmt->execute([$testCode]);
    $companyByCode = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($companyByCode) {
        echo "<p class='success'>✅ Company found by code!</p>";
        echo "<table border='1' style='border-collapse:collapse;'>";
        echo "<tr><th>Field</th><th>Value</th></tr>";
        foreach ($companyByCode as $key => $value) {
            if ($key === 'password') {
                $value = str_repeat('*', strlen($value ?? ''));
            }
            echo "<tr><td>$key</td><td>$value</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='error'>❌ No company found with code: $testCode</p>";
    }
    
    echo "<h2>🔐 Step 4: Test Password Authentication</h2>";
    $company = $companyByEmail ?: $companyByCode;
    
    if ($company) {
        $storedPassword = $company['password'];
        echo "<p><strong>Stored password format:</strong> " . substr($storedPassword, 0, 20) . "... (length: " . strlen($storedPassword) . ")</p>";
        
        // Test different password methods
        $authMethods = [
            'MySQL PASSWORD()' => null,
            'Plain text' => $testPassword,
            'MD5' => md5($testPassword),
            'SHA1' => sha1($testPassword),
        ];
        
        echo "<div class='test'>";
        echo "<h3>🧪 Password Authentication Tests:</h3>";
        
        foreach ($authMethods as $method => $hash) {
            if ($method === 'MySQL PASSWORD()') {
                try {
                    $stmt = $conn->prepare("SELECT PASSWORD(?) as pwd_hash");
                    $stmt->execute([$testPassword]);
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    $hash = $result['pwd_hash'];
                    
                    echo "<p><strong>$method:</strong> $hash ";
                    if ($hash === $storedPassword) {
                        echo "<span class='success'>✅ MATCH! This method works.</span></p>";
                    } else {
                        echo "<span class='error'>❌ No match</span></p>";
                    }
                } catch (Exception $e) {
                    echo "<p><strong>$method:</strong> <span class='error'>❌ Error: " . $e->getMessage() . "</span></p>";
                }
            } else {
                echo "<p><strong>$method:</strong> $hash ";
                if ($hash === $storedPassword) {
                    echo "<span class='success'>✅ MATCH! This method works.</span></p>";
                } else {
                    echo "<span class='error'>❌ No match</span></p>";
                }
            }
        }
        echo "</div>";
        
        echo "<h2>🧪 Step 5: Test Full Login Logic</h2>";
        
        // Test the actual login query
        try {
            $loginStmt = $conn->prepare("
                SELECT * FROM companies 
                WHERE $emailCol = ? AND password = PASSWORD(?) AND $codeCol = ?
            ");
            $loginStmt->execute([$testEmail, $testPassword, $testCode]);
            $loginResult = $loginStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($loginResult) {
                echo "<p class='success'>✅ LOGIN SUCCESS with MySQL PASSWORD()!</p>";
            } else {
                echo "<p class='info'>ℹ️ MySQL PASSWORD() failed, trying plain text...</p>";
                
                $loginStmt = $conn->prepare("
                    SELECT * FROM companies 
                    WHERE $emailCol = ? AND password = ? AND $codeCol = ?
                ");
                $loginStmt->execute([$testEmail, $testPassword, $testCode]);
                $loginResult = $loginStmt->fetch(PDO::FETCH_ASSOC);
                
                if ($loginResult) {
                    echo "<p class='success'>✅ LOGIN SUCCESS with plain text password!</p>";
                } else {
                    echo "<p class='info'>ℹ️ Plain text failed, trying MD5...</p>";
                    
                    $loginStmt = $conn->prepare("
                        SELECT * FROM companies 
                        WHERE $emailCol = ? AND password = MD5(?) AND $codeCol = ?
                    ");
                    $loginStmt->execute([$testEmail, $testPassword, $testCode]);
                    $loginResult = $loginStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($loginResult) {
                        echo "<p class='success'>✅ LOGIN SUCCESS with MD5 hash!</p>";
                    } else {
                        echo "<p class='error'>❌ All authentication methods failed</p>";
                    }
                }
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>❌ Login test error: " . $e->getMessage() . "</p>";
        }
        
    } else {
        echo "<p class='error'>❌ No company found to test password authentication</p>";
    }
    
    echo "<div style='background:#e8f5e8;padding:15px;margin:20px 0;border-left:4px solid #28a745;'>";
    echo "<h3>✅ Login Fix Summary</h3>";
    echo "<p><strong>What was fixed:</strong></p>";
    echo "<ul>";
    echo "<li>Changed from users table to companies table authentication</li>";
    echo "<li>Added flexible column mapping for different database schemas</li>";
    echo "<li>Added multiple password authentication methods (PASSWORD(), plain text, MD5)</li>";
    echo "<li>Added proper company status checking</li>";
    echo "</ul>";
    echo "<p><strong>Result:</strong> Company login should now work with your credentials!</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Test failed: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='../auth/company-login.php'>🔙 Try Company Login Again</a></p>";
?>