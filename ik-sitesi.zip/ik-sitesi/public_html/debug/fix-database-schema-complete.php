<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=UTF-8');

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Database Schema Tamamen Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }";
echo ".container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo "table { border-collapse: collapse; width: 100%; margin: 20px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }";
echo "button:hover { background: #0056b3; }";
echo ".danger { background: #dc3545; }";
echo ".danger:hover { background: #c82333; }";
echo ".step { background: #e9ecef; padding: 15px; margin: 10px 0; border-left: 4px solid #007bff; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";

echo "<h1>🔧 Database Schema Tamamen Düzeltme</h1>";
echo "<p><strong>Problem:</strong> Karışık foreign key constraints ve duplicate kolonlar</p>";
echo "<p><strong>Çözüm:</strong> Adım adım temizlik ve yeniden oluşturma</p>";
echo "<hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'step1_disable_checks') {
            echo "<div class='step'>";
            echo "<h3>🔧 Adım 1: Foreign Key Checks Devre Dışı</h3>";
            
            try {
                $conn->exec("SET FOREIGN_KEY_CHECKS = 0");
                echo "<div class='success'>✅ Foreign key checks devre dışı bırakıldı</div>";
                
                $conn->exec("SET sql_mode = ''");
                echo "<div class='success'>✅ SQL mode esnetildi</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Adım 1 hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
        
        if ($action === 'step2_backup_data') {
            echo "<div class='step'>";
            echo "<h3>💾 Adım 2: Mevcut Vardiya Verileri Yedekleme</h3>";
            
            try {
                // Create backup table
                $conn->exec("DROP TABLE IF EXISTS employee_shifts_backup");
                $conn->exec("CREATE TABLE employee_shifts_backup AS SELECT * FROM employee_shifts");
                
                $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_shifts_backup");
                $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                echo "<div class='success'>✅ $count vardiya kaydı yedeklendi</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Adım 2 hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
        
        if ($action === 'step3_drop_table') {
            echo "<div class='step'>";
            echo "<h3>🗑️ Adım 3: Employee Shifts Tablosunu Sil</h3>";
            
            try {
                $conn->exec("DROP TABLE IF EXISTS employee_shifts");
                echo "<div class='success'>✅ employee_shifts tablosu silindi</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Adım 3 hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
        
        if ($action === 'step4_recreate_table') {
            echo "<div class='step'>";
            echo "<h3>🏗️ Adım 4: Employee Shifts Tablosunu Yeniden Oluştur</h3>";
            
            try {
                $conn->exec("
                    CREATE TABLE employee_shifts (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        employee_id INT NOT NULL,
                        shift_template_id INT NOT NULL,
                        shift_date DATE NOT NULL,
                        status VARCHAR(20) DEFAULT 'scheduled',
                        notes TEXT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        INDEX idx_employee_date (employee_id, shift_date),
                        INDEX idx_template (shift_template_id),
                        INDEX idx_date (shift_date),
                        UNIQUE KEY unique_employee_date (employee_id, shift_date)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                ");
                echo "<div class='success'>✅ employee_shifts tablosu yeniden oluşturuldu</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Adım 4 hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
        
        if ($action === 'step5_add_foreign_keys') {
            echo "<div class='step'>";
            echo "<h3>🔗 Adım 5: Foreign Key Constraints Ekle</h3>";
            
            try {
                // Add foreign key to employees
                $conn->exec("
                    ALTER TABLE employee_shifts 
                    ADD CONSTRAINT fk_es_employee 
                    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
                ");
                echo "<div class='success'>✅ Employee foreign key eklendi</div>";
                
                // Add foreign key to shift_templates
                $conn->exec("
                    ALTER TABLE employee_shifts 
                    ADD CONSTRAINT fk_es_shift_template 
                    FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
                ");
                echo "<div class='success'>✅ Shift template foreign key eklendi</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Adım 5 hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
        
        if ($action === 'step6_restore_data') {
            echo "<div class='step'>";
            echo "<h3>📥 Adım 6: Yedek Verileri Geri Yükle</h3>";
            
            try {
                // Check if backup exists
                $stmt = $conn->query("SHOW TABLES LIKE 'employee_shifts_backup'");
                if ($stmt->rowCount() > 0) {
                    
                    // Get column mapping
                    $stmt = $conn->query("SHOW COLUMNS FROM employee_shifts_backup");
                    $backupColumns = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'Field');
                    
                    // Determine correct column for shift template
                    $shiftColumn = in_array('shift_template_id', $backupColumns) ? 'shift_template_id' : 'shift_id';
                    
                    $stmt = $conn->prepare("
                        INSERT INTO employee_shifts 
                        (employee_id, shift_template_id, shift_date, status, created_at) 
                        SELECT 
                            employee_id, 
                            $shiftColumn, 
                            shift_date, 
                            COALESCE(status, 'scheduled'),
                            COALESCE(created_at, NOW())
                        FROM employee_shifts_backup
                        WHERE employee_id IS NOT NULL 
                        AND $shiftColumn IS NOT NULL 
                        AND shift_date IS NOT NULL
                    ");
                    $stmt->execute();
                    
                    $restored = $stmt->rowCount();
                    echo "<div class='success'>✅ $restored vardiya kaydı geri yüklendi</div>";
                    
                } else {
                    echo "<div class='info'>ℹ️ Yedek tablo bulunamadı</div>";
                }
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Adım 6 hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
        
        if ($action === 'step7_enable_checks') {
            echo "<div class='step'>";
            echo "<h3>✅ Adım 7: Foreign Key Checks Etkinleştir</h3>";
            
            try {
                $conn->exec("SET FOREIGN_KEY_CHECKS = 1");
                echo "<div class='success'>✅ Foreign key checks etkinleştirildi</div>";
                
                // Test foreign key constraints
                $stmt = $conn->query("
                    SELECT 
                        CONSTRAINT_NAME,
                        COLUMN_NAME,
                        REFERENCED_TABLE_NAME
                    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
                    WHERE TABLE_SCHEMA = DATABASE() 
                    AND TABLE_NAME = 'employee_shifts'
                    AND REFERENCED_TABLE_NAME IS NOT NULL
                ");
                $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo "<div class='info'>";
                echo "<h4>🔗 Oluşturulan Foreign Keys:</h4>";
                foreach ($constraints as $constraint) {
                    echo "<p>✅ " . $constraint['CONSTRAINT_NAME'] . ": " . 
                         $constraint['COLUMN_NAME'] . " → " . 
                         $constraint['REFERENCED_TABLE_NAME'] . "</p>";
                }
                echo "</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Adım 7 hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
        
        if ($action === 'test_final') {
            echo "<div class='step'>";
            echo "<h3>🧪 Final Test: Vardiya Atama</h3>";
            
            try {
                // Get test data
                $stmt = $conn->query("SELECT id FROM employees LIMIT 1");
                $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $stmt = $conn->query("SELECT id FROM shift_templates LIMIT 1");
                $template = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($employee && $template) {
                    $testDate = date('Y-m-d', strtotime('+1 day'));
                    
                    // Test insert
                    $stmt = $conn->prepare("
                        INSERT INTO employee_shifts 
                        (employee_id, shift_template_id, shift_date, status) 
                        VALUES (?, ?, ?, 'scheduled')
                    ");
                    $stmt->execute([$employee['id'], $template['id'], $testDate]);
                    
                    $insertedId = $conn->lastInsertId();
                    echo "<div class='success'>✅ Test vardiyası oluşturuldu (ID: $insertedId)</div>";
                    
                    // Test query
                    $stmt = $conn->prepare("
                        SELECT 
                            es.id,
                            es.shift_date,
                            e.first_name,
                            e.last_name,
                            st.name as shift_name
                        FROM employee_shifts es
                        INNER JOIN employees e ON es.employee_id = e.id
                        LEFT JOIN shift_templates st ON es.shift_template_id = st.id
                        WHERE es.id = ?
                    ");
                    $stmt->execute([$insertedId]);
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($result) {
                        echo "<div class='success'>✅ Join query başarılı: " . 
                             $result['first_name'] . " " . $result['last_name'] . 
                             " - " . $result['shift_name'] . " (" . $result['shift_date'] . ")</div>";
                    }
                    
                    // Clean up
                    $conn->exec("DELETE FROM employee_shifts WHERE id = $insertedId");
                    echo "<div class='info'>ℹ️ Test verisi temizlendi</div>";
                    
                } else {
                    echo "<div class='warning'>⚠️ Test için gerekli veriler bulunamadı</div>";
                }
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Test hatası: " . $e->getMessage() . "</div>";
            }
            echo "</div>";
        }
    }
    
    echo "<div class='info'>";
    echo "<h3>🔍 Mevcut Durum</h3>";
    
    // Check table existence
    $stmt = $conn->query("SHOW TABLES LIKE 'employee_shifts'");
    $tableExists = $stmt->rowCount() > 0;
    echo "<p><strong>employee_shifts tablosu:</strong> " . ($tableExists ? "✅ Mevcut" : "❌ Yok") . "</p>";
    
    if ($tableExists) {
        // Check columns
        $stmt = $conn->query("SHOW COLUMNS FROM employee_shifts");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<h4>📋 Kolonlar:</h4>";
        echo "<table>";
        echo "<tr><th>Kolon</th><th>Tip</th><th>Null</th><th>Key</th></tr>";
        foreach ($columns as $column) {
            echo "<tr>";
            echo "<td>" . $column['Field'] . "</td>";
            echo "<td>" . $column['Type'] . "</td>";
            echo "<td>" . $column['Null'] . "</td>";
            echo "<td>" . $column['Key'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Check foreign keys
        $stmt = $conn->query("
            SELECT CONSTRAINT_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'employee_shifts'
            AND REFERENCED_TABLE_NAME IS NOT NULL
        ");
        $fks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>🔗 Foreign Keys:</h4>";
        if (count($fks) > 0) {
            foreach ($fks as $fk) {
                echo "<p>✅ " . $fk['CONSTRAINT_NAME'] . ": " . $fk['COLUMN_NAME'] . " → " . $fk['REFERENCED_TABLE_NAME'] . "</p>";
            }
        } else {
            echo "<p>❌ Foreign key yok</p>";
        }
        
        // Check data count
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_shifts");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p><strong>Kayıt sayısı:</strong> $count</p>";
    }
    
    // Check backup
    $stmt = $conn->query("SHOW TABLES LIKE 'employee_shifts_backup'");
    $backupExists = $stmt->rowCount() > 0;
    echo "<p><strong>Yedek tablo:</strong> " . ($backupExists ? "✅ Mevcut" : "❌ Yok") . "</p>";
    
    if ($backupExists) {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_shifts_backup");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p><strong>Yedek kayıt sayısı:</strong> $count</p>";
    }
    
    echo "</div>";
    
    echo "<hr>";
    echo "<h3>🛠️ Adım Adım Düzeltme</h3>";
    echo "<p><strong>Uyarı:</strong> Bu işlemler sırayla yapılmalıdır!</p>";
    
    echo "<div style='display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 20px 0;'>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='step1_disable_checks'>";
    echo "<button type='submit'>1️⃣ FK Checks Kapat</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='step2_backup_data'>";
    echo "<button type='submit'>2️⃣ Veri Yedekle</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='step3_drop_table'>";
    echo "<button type='submit' class='danger' onclick='return confirm(\"Tablo silinecek! Onaylıyor musunuz?\")'>3️⃣ Tabloyu Sil</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='step4_recreate_table'>";
    echo "<button type='submit'>4️⃣ Tabloyu Oluştur</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='step5_add_foreign_keys'>";
    echo "<button type='submit'>5️⃣ FK Ekle</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='step6_restore_data'>";
    echo "<button type='submit'>6️⃣ Veri Geri Yükle</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='step7_enable_checks'>";
    echo "<button type='submit'>7️⃣ FK Checks Aç</button>";
    echo "</form>";
    
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='test_final'>";
    echo "<button type='submit'>🧪 Final Test</button>";
    echo "</form>";
    
    echo "</div>";
    
    echo "<div style='margin-top: 30px;'>";
    echo "<h4>🔗 Test Bağlantıları</h4>";
    echo "<div style='display: flex; gap: 10px;'>";
    echo "<a href='fix-shift-management-display.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Display Test</a>";
    echo "<a href='../admin/shift-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Yönetimi</a>";
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>