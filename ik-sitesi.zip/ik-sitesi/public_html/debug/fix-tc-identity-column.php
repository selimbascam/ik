<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=UTF-8');

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>TC Kimlik Kolonu Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }";
echo ".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo "table { border-collapse: collapse; width: 100%; margin: 20px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }";
echo "button:hover { background: #0056b3; }";
echo ".danger { background: #dc3545; }";
echo ".danger:hover { background: #c82333; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";

echo "<h1>🔧 TC No Kolonu Düzeltme</h1>";
echo "<p><strong>Problem:</strong> employees tablosunda tc_no kolonu bulunamadı.</p>";
echo "<p><strong>Çözüm:</strong> tc_no kolonunu ekleyip mevcut verileri employee_number'dan migrate edeceğiz.</p>";
echo "<hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'add_tc_no_column') {
            echo "<h3>🔧 TC No Kolonu Ekleniyor...</h3>";
            
            try {
                $conn->exec("
                    ALTER TABLE employees 
                    ADD COLUMN tc_no VARCHAR(11) DEFAULT NULL
                ");
                echo "<div class='success'>✅ tc_no kolonu başarıyla eklendi</div>";
                
                // Add index for performance
                $conn->exec("CREATE INDEX idx_tc_no ON employees(tc_no)");
                echo "<div class='success'>✅ tc_no indexi oluşturuldu</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Kolon ekleme hatası: " . $e->getMessage() . "</div>";
            }
        }
        
        if ($action === 'migrate_employee_numbers') {
            echo "<h3>📋 Personel Numaraları Migrate Ediliyor...</h3>";
            
            try {
                // Migrate numeric employee numbers to tc_no
                $result = $conn->exec("
                    UPDATE employees 
                    SET tc_no = employee_number 
                    WHERE employee_number REGEXP '^[0-9]{10,11}$' 
                    AND (tc_no IS NULL OR tc_no = '')
                ");
                echo "<div class='success'>✅ $result personelin TC numarası migrate edildi</div>";
                
                // Update remaining ones with placeholder pattern
                $stmt = $conn->prepare("
                    SELECT id, first_name, last_name, employee_number 
                    FROM employees 
                    WHERE (tc_no IS NULL OR tc_no = '') 
                    AND company_id = ?
                ");
                $stmt->execute([$_SESSION['company_id'] ?? 1]);
                $empWithoutTC = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $counter = 0;
                foreach ($empWithoutTC as $emp) {
                    $fakeTC = '30000000' . str_pad($emp['id'], 3, '0', STR_PAD_LEFT);
                    $updateStmt = $conn->prepare("UPDATE employees SET tc_no = ? WHERE id = ?");
                    $updateStmt->execute([$fakeTC, $emp['id']]);
                    $counter++;
                }
                
                echo "<div class='info'>ℹ️ $counter personel için geçici TC numarası oluşturuldu</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Migration hatası: " . $e->getMessage() . "</div>";
            }
        }
        
        if ($action === 'update_shift_queries') {
            echo "<h3>🔄 Vardiya Sorgularını Güncelleniyor...</h3>";
            
            // Update shift-management.php to use fallback
            $shiftMgmtPath = '../admin/shift-management.php';
            if (file_exists($shiftMgmtPath)) {
                $content = file_get_contents($shiftMgmtPath);
                
                // Replace tc_identity usage with fallback
                $content = str_replace(
                    'COALESCE(e.tc_identity, COALESCE(e.employee_number, \'\')) as employee_number',
                    'COALESCE(e.employee_number, CONCAT(\'EMP\', e.id)) as employee_number',
                    $content
                );
                
                $content = str_replace(
                    'COALESCE(tc_identity, COALESCE(employee_number, CONCAT(\'EMP\', id))) as employee_number',
                    'COALESCE(employee_number, CONCAT(\'EMP\', id)) as employee_number',
                    $content
                );
                
                file_put_contents($shiftMgmtPath, $content);
                echo "<div class='success'>✅ shift-management.php güncellendi</div>";
            }
            
            // Update shift-schedule.php
            $shiftSchedulePath = '../employee/shift-schedule.php';
            if (file_exists($shiftSchedulePath)) {
                $content = file_get_contents($shiftSchedulePath);
                
                $content = str_replace(
                    'htmlspecialchars($employee[\'tc_identity\'] ?? $employee[\'employee_number\'] ?? \'Personel No: \' . $employee[\'id\'])',
                    'htmlspecialchars($employee[\'employee_number\'] ?? \'Personel No: \' . $employee[\'id\'])',
                    $content
                );
                
                file_put_contents($shiftSchedulePath, $content);
                echo "<div class='success'>✅ shift-schedule.php güncellendi</div>";
            }
            
            echo "<div class='info'>ℹ️ Vardiya sorgularında tc_identity fallback'i kaldırıldı</div>";
        }
    }
    
    echo "<div class='info'>";
    echo "<h3>🔍 Mevcut Durum</h3>";
    
    // Check if tc_identity column exists
    $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'tc_identity'");
    $tcColumnExists = $stmt->rowCount() > 0;
    
    echo "<h4>📋 Employees Tablosu Analizi:</h4>";
    echo "<p><strong>tc_identity kolonu:</strong> " . ($tcColumnExists ? "✅ Mevcut" : "❌ Yok") . "</p>";
    
    if ($tcColumnExists) {
        // Count employees with tc_identity
        $stmt = $conn->query("
            SELECT 
                COUNT(*) as total,
                COUNT(CASE WHEN tc_identity IS NOT NULL AND tc_identity != '' THEN 1 END) as with_tc,
                COUNT(CASE WHEN employee_number REGEXP '^[0-9]{10,11}$' THEN 1 END) as numeric_emp_num
            FROM employees
        ");
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<ul>";
        echo "<li>Toplam personel: <strong>" . $stats['total'] . "</strong></li>";
        echo "<li>TC kimlik olan: <strong>" . $stats['with_tc'] . "</strong></li>";
        echo "<li>Numerik employee_number: <strong>" . $stats['numeric_emp_num'] . "</strong></li>";
        echo "</ul>";
        
        // Show sample data
        $stmt = $conn->query("
            SELECT id, first_name, last_name, employee_number, tc_identity 
            FROM employees 
            LIMIT 5
        ");
        $samples = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>📊 Örnek Veriler:</h4>";
        echo "<table>";
        echo "<tr><th>ID</th><th>Ad Soyad</th><th>Employee Number</th><th>TC Identity</th></tr>";
        foreach ($samples as $sample) {
            echo "<tr>";
            echo "<td>" . $sample['id'] . "</td>";
            echo "<td>" . $sample['first_name'] . " " . $sample['last_name'] . "</td>";
            echo "<td>" . ($sample['employee_number'] ?: '-') . "</td>";
            echo "<td>" . ($sample['tc_identity'] ?: '-') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    echo "</div>";
    
    echo "<hr>";
    echo "<h3>🛠️ Düzeltme İşlemleri</h3>";
    
    echo "<div style='display: flex; flex-wrap: wrap; gap: 10px; margin: 20px 0;'>";
    
    if (!$tcColumnExists) {
        echo "<form method='POST' style='display: inline;'>";
        echo "<input type='hidden' name='action' value='add_tc_identity_column'>";
        echo "<button type='submit' onclick='return confirm(\"tc_identity kolonu eklenecek. Onaylıyor musunuz?\")'>🔧 TC Kimlik Kolonu Ekle</button>";
        echo "</form>";
    } else {
        echo "<form method='POST' style='display: inline;'>";
        echo "<input type='hidden' name='action' value='migrate_employee_numbers'>";
        echo "<button type='submit' onclick='return confirm(\"Personel numaraları TC kimliğe migrate edilecek. Onaylıyor musunuz?\")'>📋 Veri Migration</button>";
        echo "</form>";
    }
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='update_shift_queries'>";
    echo "<button type='submit' class='danger' onclick='return confirm(\"Vardiya sorgularında tc_identity kullanımı kaldırılacak. Onaylıyor musunuz?\")'>🔄 Sorgu Güncelle</button>";
    echo "</form>";
    
    echo "</div>";
    
    echo "<div style='margin-top: 30px;'>";
    echo "<h4>🔗 Test Bağlantıları</h4>";
    echo "<div style='display: flex; gap: 10px;'>";
    echo "<a href='fix-shift-management-display.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Display Test</a>";
    echo "<a href='../admin/shift-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Yönetimi</a>";
    echo "<a href='../employee/shift-schedule.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Çalışma Programı</a>";
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>