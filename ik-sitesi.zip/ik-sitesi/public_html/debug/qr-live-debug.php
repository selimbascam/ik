<?php
session_start();
require_once '../includes/config.php';

// QR Debug Log Görüntüleyici
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Kod Debug Logları - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .log-entry {
            font-family: 'Courier New', monospace;
            font-size: 12px;
        }
        .debug-qr { color: #3b82f6; }
        .error-log { color: #ef4444; }
        .master-qr { color: #10b981; }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <div class="bg-white rounded-lg shadow p-6">
            <h1 class="text-2xl font-bold mb-4">🔍 QR Kod Debug Logları (Canlı)</h1>
            
            <div class="mb-4 flex gap-2">
                <button id="startBtn" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    ▶️ Canlı İzlemeyi Başlat
                </button>
                <button id="stopBtn" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700" disabled>
                    ⏹️ Durdur
                </button>
                <button id="clearBtn" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    🗑️ Temizle
                </button>
            </div>

            <div id="status" class="mb-4 p-3 bg-gray-50 rounded">
                Hazır - QR kod okutmak için canlı izlemeyi başlatın
            </div>

            <div id="logContainer" class="bg-black text-green-400 p-4 rounded h-96 overflow-y-auto log-entry">
                <div class="text-gray-500">Log mesajları burada görünecek...</div>
            </div>
        </div>

        <div class="mt-4 text-center">
            <a href="../employee/qr-attendance-master.php" target="_blank" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                🔗 QR Okuyucuyu Aç (Yeni Sekme)
            </a>
        </div>
    </div>

    <script>
        let isMonitoring = false;
        let monitorInterval;
        let lastLogSize = 0;

        const startBtn = document.getElementById('startBtn');
        const stopBtn = document.getElementById('stopBtn');
        const clearBtn = document.getElementById('clearBtn');
        const status = document.getElementById('status');
        const logContainer = document.getElementById('logContainer');

        // Canlı izlemeyi başlat
        function startMonitoring() {
            isMonitoring = true;
            startBtn.disabled = true;
            stopBtn.disabled = false;
            status.innerHTML = '<span class="text-green-600">🟢 Canlı İzleme Aktif - QR kod okutun!</span>';
            
            // Her saniye log kontrol et
            monitorInterval = setInterval(checkLogs, 1000);
            
            // İlk kontrol
            checkLogs();
        }

        // İzlemeyi durdur
        function stopMonitoring() {
            isMonitoring = false;
            startBtn.disabled = false;
            stopBtn.disabled = true;
            status.innerHTML = '<span class="text-gray-600">⏸️ İzleme Durduruldu</span>';
            
            if (monitorInterval) {
                clearInterval(monitorInterval);
            }
        }

        // Logları kontrol et
        async function checkLogs() {
            if (!isMonitoring) return;

            try {
                const response = await fetch('qr-debug-api.php?action=get_logs&last_size=' + lastLogSize);
                const data = await response.json();
                
                if (data.success) {
                    // Debug bilgisini göster (ilk seferinde)
                    if (lastLogSize === 0 && data.debug_info) {
                        addLogEntry('=== DEBUG BİLGİLERİ ===');
                        addLogEntry('PHP Error Log: ' + (data.debug_info.php_error_log_setting || 'Ayarlanmamış'));
                        addLogEntry('Mevcut Kullanıcı: ' + data.debug_info.current_user);
                        addLogEntry('Bulunan Log Dosyaları: ' + data.debug_info.log_files_found.length);
                        
                        data.debug_info.log_files_found.forEach(file => {
                            addLogEntry('  - ' + file.path + ' (Okunabilir: ' + file.readable + ', Boyut: ' + file.size + ')');
                        });
                        addLogEntry('=== QR KOD OKUTUN ===');
                    }
                    
                    if (data.new_logs && data.new_logs.length > 0) {
                        // Yeni logları ekle
                        data.new_logs.forEach(log => {
                            addLogEntry(log);
                        });
                        lastLogSize = data.current_size;
                    }
                } else {
                    addLogEntry('HATA: ' + (data.error || 'Bilinmeyen hata'));
                }
            } catch (error) {
                console.error('Log kontrol hatası:', error);
                addLogEntry('FETCH HATASI: ' + error.message);
            }
        }

        // Log girişi ekle
        function addLogEntry(logText) {
            const logDiv = document.createElement('div');
            logDiv.className = 'mb-1';
            
            const timestamp = new Date().toLocaleTimeString();
            
            // Log türüne göre renklendirme
            let className = '';
            if (logText.includes('Master QR DEBUG')) {
                className = 'debug-qr';
            } else if (logText.includes('Master QR ERROR')) {
                className = 'error-log';
            } else if (logText.includes('Master QR:')) {
                className = 'master-qr';
            }
            
            logDiv.innerHTML = `<span class="text-gray-400">[${timestamp}]</span> <span class="${className}">${escapeHtml(logText)}</span>`;
            
            logContainer.appendChild(logDiv);
            
            // En alta kaydır
            logContainer.scrollTop = logContainer.scrollHeight;
            
            // Çok fazla log varsa eski olanları sil
            if (logContainer.children.length > 100) {
                logContainer.removeChild(logContainer.firstChild);
            }
        }

        // HTML escape
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Logları temizle
        function clearLogs() {
            logContainer.innerHTML = '<div class="text-gray-500">Loglar temizlendi...</div>';
            lastLogSize = 0;
        }

        // Event listeners
        startBtn.addEventListener('click', startMonitoring);
        stopBtn.addEventListener('click', stopMonitoring);
        clearBtn.addEventListener('click', clearLogs);

        // Sayfa kapanınca izlemeyi durdur
        window.addEventListener('beforeunload', stopMonitoring);
    </script>
</body>
</html>