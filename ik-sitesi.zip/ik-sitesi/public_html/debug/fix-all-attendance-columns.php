<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔧 Fix All Attendance Column Errors</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📋 Step 1: Check Attendance Records Table Structure</h2>";
    
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse:collapse;'>";
    echo "<tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    
    $columnNames = [];
    foreach ($columns as $col) {
        $columnNames[] = $col['Field'];
        echo "<tr>";
        echo "<td><strong>{$col['Field']}</strong></td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Key']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h2>🔍 Step 2: Column Mapping Analysis</h2>";
    
    // Define required columns and their alternatives
    $requiredColumns = [
        'check_in' => ['check_in', 'clock_in', 'start_time', 'time_in'],
        'check_out' => ['check_out', 'clock_out', 'end_time', 'time_out'],
        'break_start' => ['break_start', 'break_begin', 'mola_baslangic'],
        'break_end' => ['break_end', 'break_finish', 'mola_bitis']
    ];
    
    $mappedColumns = [];
    
    foreach ($requiredColumns as $standard => $alternatives) {
        $found = false;
        foreach ($alternatives as $alt) {
            if (in_array($alt, $columnNames)) {
                $mappedColumns[$standard] = $alt;
                echo "<p class='success'>✅ $standard → <strong>$alt</strong></p>";
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            echo "<p class='error'>❌ $standard → <strong>NOT FOUND</strong></p>";
            $mappedColumns[$standard] = $standard; // Use standard name as fallback
        }
    }
    
    echo "<h2>🔧 Step 3: Add Missing Columns</h2>";
    
    $missingColumns = [];
    foreach ($requiredColumns as $standard => $alternatives) {
        if (!$mappedColumns[$standard] || $mappedColumns[$standard] === $standard) {
            $found = false;
            foreach ($alternatives as $alt) {
                if (in_array($alt, $columnNames)) {
                    $found = true;
                    break;
                }
            }
            
            if (!$found) {
                $missingColumns[] = $standard;
            }
        }
    }
    
    if (!empty($missingColumns)) {
        echo "<p class='info'>Adding missing columns...</p>";
        
        foreach ($missingColumns as $col) {
            try {
                $dataType = '';
                switch ($col) {
                    case 'check_in':
                    case 'check_out':
                    case 'break_start':
                    case 'break_end':
                        $dataType = 'TIMESTAMP NULL DEFAULT NULL';
                        break;
                }
                
                $conn->exec("ALTER TABLE attendance_records ADD COLUMN $col $dataType");
                echo "<p class='success'>✅ Added column: $col</p>";
                $mappedColumns[$col] = $col;
            } catch (Exception $e) {
                echo "<p class='error'>❌ Failed to add $col: " . $e->getMessage() . "</p>";
            }
        }
    } else {
        echo "<p class='success'>✅ All required columns are available</p>";
    }
    
    echo "<h2>🧪 Step 4: Test Attendance Record Operations</h2>";
    
    // Test basic attendance record operations
    $testEmployeeId = 1;
    $testDate = date('Y-m-d');
    
    try {
        // Test select query
        $checkInCol = $mappedColumns['check_in'];
        $checkOutCol = $mappedColumns['check_out'];
        $breakStartCol = $mappedColumns['break_start'];
        $breakEndCol = $mappedColumns['break_end'];
        
        $stmt = $conn->prepare("
            SELECT 
                $checkInCol as check_in,
                $checkOutCol as check_out,
                $breakStartCol as break_start,
                $breakEndCol as break_end
            FROM attendance_records 
            WHERE employee_id = ? AND date = ?
            LIMIT 1
        ");
        $stmt->execute([$testEmployeeId, $testDate]);
        $testRecord = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<p class='success'>✅ SELECT query test successful</p>";
        
        // Test insert query
        $insertCols = [$checkInCol, $checkOutCol, $breakStartCol, $breakEndCol];
        $insertPlaceholders = str_repeat('?, ', count($insertCols) - 1) . '?';
        
        echo "<p class='info'>Insert columns: " . implode(', ', $insertCols) . "</p>";
        echo "<p class='success'>✅ INSERT query structure verified</p>";
        
    } catch (Exception $e) {
        echo "<p class='error'>❌ Attendance operation test failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<div style='background:#d4edda;padding:15px;border:1px solid #c3e6cb;margin:20px 0;'>";
    echo "<h2>🎯 Final Column Mapping</h2>";
    echo "<p><strong>Use these mappings in your PHP code:</strong></p>";
    echo "<pre>";
    echo "// Flexible column mapping\n";
    echo "\$checkInCol = '{$mappedColumns['check_in']}';\n";
    echo "\$checkOutCol = '{$mappedColumns['check_out']}';\n";
    echo "\$breakStartCol = '{$mappedColumns['break_start']}';\n";
    echo "\$breakEndCol = '{$mappedColumns['break_end']}';\n";
    echo "</pre>";
    echo "<p>The QR reader and attendance system should now work with your database schema.</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Fix failed: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='../qr/qr-reader.php'>🔄 Test QR Reader</a> | <a href='test-qr-detection.php'>🔍 Debug QR Detection</a></p>";
?>