<?php
// Test QR gate behavior logic
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/qr-attendance-fixed.php';

// Super admin check
if (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1) {
    die('Bu sayfa sadece Super Admin tarafından erişilebilir.');
}

$db = new Database();
$conn = $db->getConnection();

echo "<h2>🚪 QR Gate Behavior Test</h2>";

// Test parameters
$testEmployeeId = 1;
$testCompanyId = 4; // SZB company
$testLocationId = 1;
$today = date('Y-m-d');

echo "<h3>📋 Test Parametreleri:</h3>";
echo "<p><strong>Employee ID:</strong> $testEmployeeId</p>";
echo "<p><strong>Company ID:</strong> $testCompanyId</p>";
echo "<p><strong>Location ID:</strong> $testLocationId</p>";
echo "<p><strong>Tarih:</strong> $today</p>";

// Test all gate behaviors
$gateBehaviors = ['work_start', 'work_end', 'break_toggle', 'user_choice'];

echo "<h3>🎯 Gate Behavior Test Sonuçları:</h3>";

foreach ($gateBehaviors as $behavior) {
    echo "<div style='border: 1px solid #ccc; margin: 10px 0; padding: 15px; border-radius: 5px;'>";
    echo "<h4>🚪 Gate Behavior: <strong>" . strtoupper($behavior) . "</strong></h4>";
    
    try {
        $result = QRAttendanceHelper::determineGateAction($conn, $testEmployeeId, $testCompanyId, $testLocationId, $behavior, $today);
        
        echo "<p><strong>Sonuç:</strong></p>";
        echo "<ul>";
        echo "<li><strong>Action:</strong> " . $result['action'] . "</li>";
        echo "<li><strong>Message:</strong> " . $result['message'] . "</li>";
        if (isset($result['reset_day'])) {
            echo "<li><strong>Reset Day:</strong> " . ($result['reset_day'] ? 'true' : 'false') . "</li>";
        }
        echo "</ul>";
        
        // Show what would happen with this behavior
        switch ($behavior) {
            case 'work_start':
                echo "<p><em>✅ VERİTABANI: WORK_START kapısı - work_start<br>";
                echo "📋 Bugün kayıt yok - İlk giriş<br>";
                echo "🎯 KULLANILACAK GATE BEHAVIOR: work_start</em></p>";
                break;
            case 'work_end':
                echo "<p><em>✅ VERİTABANI: WORK_END kapısı - work_end<br>";
                echo "📋 Bugün kayıt yok - İlk Çıkış<br>";
                echo "🎯 KULLANILACAK GATE BEHAVIOR: work_end</em></p>";
                break;
            case 'break_toggle':
                echo "<p><em>✅ VERİTABANI: break_toggle kapısı - break_toggle<br>";
                echo "📋 Bugün kayıt yok - mola<br>";
                echo "🎯 KULLANILACAK GATE BEHAVIOR: break_toggle</em></p>";
                break;
            case 'user_choice':
                echo "<p><em>✅ VERİTABANI: user_choice kapısı - user_choice<br>";
                echo "📋 Bugün kayıt yok - Genel kapı - otomatik tespit<br>";
                echo "🎯 KULLANILACAK GATE BEHAVIOR: user_choice</em></p>";
                break;
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'><strong>❌ Hata:</strong> " . $e->getMessage() . "</p>";
    }
    
    echo "</div>";
}

// Show current attendance status
echo "<h3>📊 Mevcut Attendance Durumu:</h3>";
try {
    $colMap = QRAttendanceHelper::getColumnMapping($conn);
    
    if ($colMap['date'] === 'created_at') {
        $stmt = $conn->prepare("
            SELECT 
                {$colMap['check_in']} as check_in, 
                {$colMap['check_out']} as check_out, 
                {$colMap['break_start']} as break_start, 
                {$colMap['break_end']} as break_end 
            FROM attendance_records 
            WHERE employee_id = ? AND DATE(created_at) = ?
            ORDER BY id DESC
            LIMIT 1
        ");
    } else {
        $stmt = $conn->prepare("
            SELECT 
                {$colMap['check_in']} as check_in, 
                {$colMap['check_out']} as check_out, 
                {$colMap['break_start']} as break_start, 
                {$colMap['break_end']} as break_end 
            FROM attendance_records 
            WHERE employee_id = ? AND {$colMap['date']} = ?
            ORDER BY id DESC
            LIMIT 1
        ");
    }
    
    $stmt->execute([$testEmployeeId, $today]);
    $currentRecord = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($currentRecord) {
        echo "<p><strong>Bugünkü kayıt bulundu:</strong></p>";
        echo "<ul>";
        echo "<li>Giriş: " . ($currentRecord['check_in'] ? '✅ ' . $currentRecord['check_in'] : '❌ Yok') . "</li>";
        echo "<li>Mola Başlangıç: " . ($currentRecord['break_start'] ? '✅ ' . $currentRecord['break_start'] : '❌ Yok') . "</li>";
        echo "<li>Mola Bitiş: " . ($currentRecord['break_end'] ? '✅ ' . $currentRecord['break_end'] : '❌ Yok') . "</li>";
        echo "<li>Çıkış: " . ($currentRecord['check_out'] ? '✅ ' . $currentRecord['check_out'] : '❌ Yok') . "</li>";
        echo "</ul>";
    } else {
        echo "<p><strong>📋 Bugün kayıt yok</strong></p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Attendance sorgu hatası: " . $e->getMessage() . "</p>";
}

// Test simulation buttons
echo "<h3>🧪 Test Simülasyonu:</h3>";
echo "<p>Bu butonlar QR tarama simülasyonu yapar:</p>";

foreach ($gateBehaviors as $behavior) {
    $buttonColor = '';
    switch ($behavior) {
        case 'work_start': $buttonColor = 'background: #28a745; color: white;'; break;
        case 'work_end': $buttonColor = 'background: #dc3545; color: white;'; break;
        case 'break_toggle': $buttonColor = 'background: #ffc107; color: black;'; break;
        case 'user_choice': $buttonColor = 'background: #007bff; color: white;'; break;
    }
    
    echo "<a href='../qr/qr-reader.php?qr_code=test_location&test_behavior=$behavior' target='_blank' ";
    echo "style='display: inline-block; padding: 10px 20px; margin: 5px; text-decoration: none; border-radius: 5px; $buttonColor'>";
    echo "🔸 Test " . strtoupper($behavior) . "</a>";
}

echo "<br><br><a href='../super-admin/index.php' style='padding: 10px 20px; background: #007cba; color: white; text-decoration: none; border-radius: 5px;'>← Super Admin Panel</a>";
?>