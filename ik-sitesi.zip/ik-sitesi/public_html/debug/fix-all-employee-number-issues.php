<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <title>Comprehensive Employee Number Column Fix</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100 p-8'>
    <div class='max-w-6xl mx-auto bg-white rounded-lg shadow-lg p-6'>
        <h1 class='text-3xl font-bold text-gray-900 mb-6'>🔧 Kapsamlı Employee Number Sütunu Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-8'>";
    
    // 1. Check and fix employees table structure
    echo "<div class='bg-blue-50 p-6 rounded-lg'>
            <h2 class='text-xl font-semibold text-blue-800 mb-4'>📋 1. Employees Tablo Yapısı Kontrolü</h2>";
    
    try {
        $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
        if ($columnCheck->rowCount() === 0) {
            echo "<p class='text-red-600 mb-4'>❌ employee_number sütunu eksik - ekleniyor...</p>";
            
            $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
            echo "<p class='text-green-600 mb-4'>✅ employee_number sütunu başarıyla eklendi</p>";
        } else {
            echo "<p class='text-green-600 mb-4'>✅ employee_number sütunu mevcut</p>";
        }
        
        // Generate employee numbers for existing employees without them
        $empStmt = $conn->query("SELECT id FROM employees WHERE employee_number IS NULL OR employee_number = ''");
        $empsToUpdate = $empStmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($empsToUpdate) > 0) {
            echo "<p class='text-orange-600 mb-2'>⚠️ " . count($empsToUpdate) . " personelin employee_number'ı eksik - güncelleniyor...</p>";
            
            foreach ($empsToUpdate as $emp) {
                $empNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
                $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
                $updateStmt->execute([$empNumber, $emp['id']]);
            }
            echo "<p class='text-green-600'>✅ Tüm personel employee_number'ları güncellendi</p>";
        } else {
            echo "<p class='text-green-600'>✅ Tüm personellerin employee_number'ı mevcut</p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Tablo yapısı hatası: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    
    echo "</div>";
    
    // 2. Test critical queries with employee_number
    echo "<div class='bg-green-50 p-6 rounded-lg'>
            <h2 class='text-xl font-semibold text-green-800 mb-4'>🧪 2. Kritik Sorgular Testi</h2>";
    
    $testQueries = [
        'Attendance Tracking' => "
            SELECT 
                e.id,
                COALESCE(e.employee_number, CONCAT('EMP', LPAD(e.id, 4, '0'))) as employee_number,
                e.first_name,
                e.last_name
            FROM employees e
            WHERE e.company_id = 1
            LIMIT 5
        ",
        'Employee Details' => "
            SELECT first_name, last_name, 
                   COALESCE(employee_number, CONCAT('EMP', LPAD(id, 4, '0'))) as employee_number, 
                   email, created_at
            FROM employees 
            WHERE id = 1
        ",
        'Reports Query' => "
            SELECT 
                e.id,
                e.first_name,
                e.last_name,
                COALESCE(e.employee_number, CONCAT('EMP', LPAD(e.id, 4, '0'))) as employee_number,
                d.name as department_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.company_id = 1
            LIMIT 3
        "
    ];
    
    foreach ($testQueries as $name => $query) {
        try {
            $testStmt = $conn->query($query);
            $results = $testStmt->fetchAll(PDO::FETCH_ASSOC);
            echo "<div class='mb-4'>
                    <h3 class='font-semibold text-green-700'>{$name}</h3>
                    <p class='text-green-600'>✅ Sorgu başarılı (" . count($results) . " sonuç)</p>";
            
            if (!empty($results)) {
                echo "<div class='mt-2 text-xs bg-gray-100 p-2 rounded'>
                        <strong>Örnek:</strong> " . 
                        htmlspecialchars(json_encode(array_slice($results[0], 0, 3), JSON_UNESCAPED_UNICODE)) . 
                      "</div>";
            }
            echo "</div>";
            
        } catch (Exception $e) {
            echo "<div class='mb-4'>
                    <h3 class='font-semibold text-red-700'>{$name}</h3>
                    <p class='text-red-600'>❌ Sorgu hatası: " . htmlspecialchars($e->getMessage()) . "</p>
                  </div>";
        }
    }
    
    echo "</div>";
    
    // 3. Check files that use employee_number directly
    echo "<div class='bg-yellow-50 p-6 rounded-lg'>
            <h2 class='text-xl font-semibold text-yellow-800 mb-4'>📁 3. Dosya Kontrol Sonuçları</h2>";
    
    $problematicFiles = [
        'attendance-tracking.php' => 'Günlük devam takibi',
        'employee-attendance-details.php' => 'Personel devam detayları',
        'reports.php' => 'Raporlar',
        'shift-management.php' => 'Vardiya yönetimi'
    ];
    
    foreach ($problematicFiles as $file => $description) {
        $filePath = "../admin/{$file}";
        if (file_exists($filePath)) {
            $fileContent = file_get_contents($filePath);
            $hasCoalesce = strpos($fileContent, 'COALESCE') !== false;
            $hasEmployeeNumber = strpos($fileContent, 'employee_number') !== false;
            
            if ($hasEmployeeNumber && $hasCoalesce) {
                echo "<p class='text-green-600'>✅ {$description} ({$file}) - COALESCE pattern mevcut</p>";
            } elseif ($hasEmployeeNumber) {
                echo "<p class='text-yellow-600'>⚠️ {$description} ({$file}) - employee_number kullanıyor ama COALESCE pattern yok</p>";
            } else {
                echo "<p class='text-gray-600'>ℹ️ {$description} ({$file}) - employee_number kullanmıyor</p>";
            }
        } else {
            echo "<p class='text-red-600'>❌ {$description} ({$file}) - Dosya bulunamadı</p>";
        }
    }
    
    echo "</div>";
    
    // 4. System Health Summary
    echo "<div class='bg-indigo-50 p-6 rounded-lg'>
            <h2 class='text-xl font-semibold text-indigo-800 mb-4'>🏥 4. Sistem Sağlığı Özeti</h2>";
    
    try {
        // Count total employees with employee_numbers
        $totalEmp = $conn->query("SELECT COUNT(*) FROM employees")->fetchColumn();
        $empWithNumbers = $conn->query("SELECT COUNT(*) FROM employees WHERE employee_number IS NOT NULL AND employee_number != ''")->fetchColumn();
        
        echo "<div class='grid grid-cols-2 gap-4 text-sm'>
                <div class='bg-white p-3 rounded border'>
                    <div class='font-semibold'>Toplam Personel</div>
                    <div class='text-2xl text-blue-600'>{$totalEmp}</div>
                </div>
                <div class='bg-white p-3 rounded border'>
                    <div class='font-semibold'>Employee Number Sahip</div>
                    <div class='text-2xl text-green-600'>{$empWithNumbers}</div>
                </div>
              </div>";
        
        if ($totalEmp == $empWithNumbers) {
            echo "<div class='mt-4 p-4 bg-green-100 border border-green-400 rounded'>
                    <p class='text-green-800 font-semibold'>🎉 Tüm employee_number sorunları çözülmüş!</p>
                    <p class='text-green-700 text-sm'>Artık sistemdeki tüm dosyalar sorunsuz çalışmalı.</p>
                  </div>";
        } else {
            echo "<div class='mt-4 p-4 bg-yellow-100 border border-yellow-400 rounded'>
                    <p class='text-yellow-800 font-semibold'>⚠️ Bazı personellerin employee_number'ı eksik</p>
                    <p class='text-yellow-700 text-sm'>Sistem otomatik düzeltme yapmaya çalışıyor...</p>
                  </div>";
        }
        
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Sistem sağlığı kontrolü hatası: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    
    echo "</div>";
    
    echo "</div>"; // Close main space-y div
    
    // 5. Quick Action Buttons
    echo "<div class='mt-8 flex gap-4'>
            <a href='../admin/attendance-tracking.php' class='bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded'>
                📊 Attendance Tracking Test
            </a>
            <a href='../admin/reports.php' class='bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded'>
                📈 Reports Test  
            </a>
            <a href='../super-admin/fix-critical-errors.php' class='bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded'>
                🔧 Super Admin Panel
            </a>
            <a href='fix-employee-number-column.php' class='bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded'>
                🔍 Detailed Diagnosis
            </a>
          </div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>
            <h3 class='font-bold'>Kritik Hata:</h3>
            <p>" . htmlspecialchars($e->getMessage()) . "</p>
            <p class='mt-2 text-sm'>Bu hatayı çözmek için database bağlantısını kontrol edin.</p>
          </div>";
}

echo "    </div>
</body>
</html>";
?>