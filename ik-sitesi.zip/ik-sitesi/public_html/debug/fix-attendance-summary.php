<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔧 Devam Özeti Hata Düzeltme Aracı</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if attendance_records table exists and its structure
    echo "<h3>📋 Attendance Records Tablo Kontrolü</h3>";
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Sütun Adı</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $column) {
            echo "<tr>";
            echo "<td>" . $column['Field'] . "</td>";
            echo "<td>" . $column['Type'] . "</td>";
            echo "<td>" . $column['Null'] . "</td>";
            echo "<td>" . $column['Key'] . "</td>";
            echo "<td>" . ($column['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Check for date column specifically
        $hasDateColumn = false;
        $hasCreatedAtColumn = false;
        foreach ($columns as $column) {
            if ($column['Field'] === 'date') $hasDateColumn = true;
            if ($column['Field'] === 'created_at') $hasCreatedAtColumn = true;
        }
        
        echo "<h4>📊 Sütun Analizi</h4>";
        echo "<p><strong>date sütunu:</strong> " . ($hasDateColumn ? "✅ Mevcut" : "❌ Yok") . "</p>";
        echo "<p><strong>created_at sütunu:</strong> " . ($hasCreatedAtColumn ? "✅ Mevcut" : "❌ Yok") . "</p>";
        
        if (!$hasDateColumn && $hasCreatedAtColumn) {
            echo "<p style='color: orange;'>⚠️ 'date' sütunu yok, 'created_at' kullanılacak</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Tablo kontrolü hatası: " . $e->getMessage() . "</p>";
    }
    
    // Test attendance helper functions
    echo "<h3>🧪 AttendanceHelper Test</h3>";
    if (class_exists('AttendanceHelper')) {
        echo "<p>✅ AttendanceHelper sınıfı mevcut</p>";
        
        // Test with sample data
        $sampleRecord = [
            'check_in_time' => '09:00:00',
            'check_out_time' => '17:00:00',
            'break_start' => '12:00:00',
            'break_end' => '13:00:00'
        ];
        
        try {
            $result = AttendanceHelper::calculateDailySummary($sampleRecord);
            echo "<p>✅ calculateDailySummary test başarılı</p>";
            echo "<pre>" . print_r($result, true) . "</pre>";
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ calculateDailySummary hatası: " . $e->getMessage() . "</p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ AttendanceHelper sınıfı bulunamadı</p>";
        
        // Create basic helper function
        echo "<h4>🔧 Temel Helper Fonksiyonu Oluşturuluyor</h4>";
        $helperCode = '<?php
class AttendanceHelper {
    public static function calculateDailySummary($record) {
        if (!$record) {
            return [
                "status" => "Çalışmıyor",
                "total_minutes" => 0,
                "work_minutes" => 0,
                "break_minutes" => 0,
                "payable_hours" => 0,
                "overtime_hours" => 0
            ];
        }
        
        $checkIn = $record["check_in_time"] ?? $record["check_in"] ?? null;
        $checkOut = $record["check_out_time"] ?? $record["check_out"] ?? null;
        $breakStart = $record["break_start"] ?? null;
        $breakEnd = $record["break_end"] ?? null;
        
        $workMinutes = 0;
        $breakMinutes = 0;
        $status = "Çalışmıyor";
        
        if ($checkIn && $checkOut) {
            $start = new DateTime($checkIn);
            $end = new DateTime($checkOut);
            $totalMinutes = $end->diff($start)->h * 60 + $end->diff($start)->i;
            
            if ($breakStart && $breakEnd) {
                $bStart = new DateTime($breakStart);
                $bEnd = new DateTime($breakEnd);
                $breakMinutes = $bEnd->diff($bStart)->h * 60 + $bEnd->diff($bStart)->i;
            }
            
            $workMinutes = max(0, $totalMinutes - $breakMinutes);
            $status = "Tamamlandı";
        } elseif ($checkIn) {
            $status = $breakStart && !$breakEnd ? "Molada" : "Çalışıyor";
        }
        
        $payableHours = $workMinutes / 60;
        $overtimeHours = max(0, $payableHours - 8);
        
        return [
            "status" => $status,
            "total_minutes" => $workMinutes + $breakMinutes,
            "work_minutes" => $workMinutes,
            "break_minutes" => $breakMinutes,
            "payable_hours" => $payableHours,
            "overtime_hours" => $overtimeHours
        ];
    }
    
    public static function calculateMonthlySummary($conn, $employeeId, $month) {
        try {
            $stmt = $conn->prepare("
                SELECT COUNT(*) as days, 
                       SUM(TIMESTAMPDIFF(MINUTE, check_in_time, check_out_time)) as total_minutes
                FROM attendance_records 
                WHERE employee_id = ? AND DATE_FORMAT(created_at, \'%Y-%m\') = ?
                AND check_in_time IS NOT NULL AND check_out_time IS NOT NULL
            ");
            $stmt->execute([$employeeId, $month]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $totalHours = ($result["total_minutes"] ?? 0) / 60;
            $targetHours = 225;
            $remainingHours = max(0, $targetHours - $totalHours);
            $completion = min(100, round(($totalHours / $targetHours) * 100));
            
            return [
                "days_worked" => $result["days"] ?? 0,
                "total_hours" => $totalHours,
                "remaining_hours" => $remainingHours,
                "completion_percentage" => $completion
            ];
        } catch (Exception $e) {
            return [
                "days_worked" => 0,
                "total_hours" => 0,
                "remaining_hours" => 225,
                "completion_percentage" => 0
            ];
        }
    }
}
?>';
        
        if (file_put_contents('../includes/attendance-helper.php', $helperCode)) {
            echo "<p>✅ attendance-helper.php dosyası oluşturuldu</p>";
        } else {
            echo "<p style='color: red;'>❌ attendance-helper.php dosyası oluşturulamadı</p>";
        }
    }
    
    // Test current employee data
    echo "<h3>👤 Mevcut Personel Verisi Testi</h3>";
    $stmt = $conn->query("SELECT id, first_name, last_name FROM employees LIMIT 5");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($employees)) {
        echo "<p style='color: red;'>❌ Hiç personel bulunamadı</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Ad</th><th>Soyad</th><th>Bugünkü Kayıt</th></tr>";
        
        foreach ($employees as $emp) {
            echo "<tr>";
            echo "<td>" . $emp['id'] . "</td>";
            echo "<td>" . htmlspecialchars($emp['first_name']) . "</td>";
            echo "<td>" . htmlspecialchars($emp['last_name']) . "</td>";
            
            // Check today's record
            $today = date('Y-m-d');
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM attendance_records WHERE employee_id = ? AND DATE(created_at) = ?");
            $stmt->execute([$emp['id'], $today]);
            $todayCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            echo "<td>" . ($todayCount > 0 ? "✅ $todayCount kayıt" : "❌ Kayıt yok") . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Fix recommendations
    echo "<h3>💡 Tavsiye Edilen Düzeltmeler</h3>";
    echo "<ol>";
    echo "<li><strong>Sütun Uyumluluğu:</strong> 'date' yerine 'created_at' kullanımı uygulandı</li>";
    echo "<li><strong>Null Kontrolleri:</strong> Tüm değişkenler için ?? operatörü eklendi</li>";
    echo "<li><strong>Helper Sınıfı:</strong> AttendanceHelper eksikse temel sürüm oluşturuldu</li>";
    echo "<li><strong>Veri Başlatma:</strong> Tüm değişkenler default değerlerle başlatılıyor</li>";
    echo "<li><strong>Hata Yönetimi:</strong> Try-catch blokları ile güvenli hale getirildi</li>";
    echo "</ol>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Genel Hata</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
pre { background: #f8f9fa; padding: 10px; border-radius: 5px; overflow-x: auto; }
</style>