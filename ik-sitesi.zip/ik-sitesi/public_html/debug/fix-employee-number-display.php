<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=UTF-8');

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Personel Numarası Görünüm Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }";
echo ".container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo "table { border-collapse: collapse; width: 100%; margin: 20px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo ".form-group { margin: 15px 0; }";
echo "input, select { padding: 8px; width: 200px; border: 1px solid #ddd; border-radius: 4px; }";
echo "button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }";
echo "button:hover { background: #0056b3; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";

echo "<h1>🔧 Personel Numarası Görünüm Düzeltme</h1>";
echo "<p><strong>Problem:</strong> Günlük devam çizelgesinde EMP formatı, personel yönetiminde TC kimlik numarası gösteriliyor</p>";
echo "<p><strong>Çözüm:</strong> Tüm sistemde gerçek TC kimlik numaralarını kullan</p>";
echo "<hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get company ID
    $companyId = $_SESSION['company_id'] ?? 1;
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'update_employee_number') {
            $employeeId = $_POST['employee_id'];
            $newNumber = $_POST['new_number'];
            
            // Update both employee_number and employee_code fields
            $stmt = $conn->prepare("
                UPDATE employees 
                SET employee_number = ?, employee_code = ? 
                WHERE id = ? AND company_id = ?
            ");
            $stmt->execute([$newNumber, $newNumber, $employeeId, $companyId]);
            
            echo "<div class='success'>✅ Personel numarası güncellendi: $newNumber</div>";
        }
        
        if ($action === 'auto_fix_all') {
            // Auto-fix all employees: use tc_identity as employee_number and employee_code
            $stmt = $conn->prepare("
                UPDATE employees 
                SET 
                    employee_number = COALESCE(tc_identity, CONCAT('EMP', LPAD(id, 4, '0'))),
                    employee_code = COALESCE(tc_identity, CONCAT('EMP', LPAD(id, 4, '0')))
                WHERE company_id = ?
            ");
            $stmt->execute([$companyId]);
            $affected = $stmt->rowCount();
            
            echo "<div class='success'>✅ Tüm personel numaraları TC kimlik numaralarıyla güncellendi ($affected kayıt)</div>";
        }
        
        if ($action === 'sync_fields') {
            // Sync employee_number and employee_code fields
            $stmt = $conn->prepare("
                UPDATE employees 
                SET employee_code = employee_number
                WHERE company_id = ? AND (employee_code IS NULL OR employee_code = '' OR employee_code != employee_number)
            ");
            $stmt->execute([$companyId]);
            $affected = $stmt->rowCount();
            
            echo "<div class='success'>✅ Personel alanları senkronize edildi ($affected kayıt)</div>";
        }
    }
    
    echo "<div class='info'>";
    echo "<h3>🔍 Mevcut Durum Analizi</h3>";
    
    // Check table structure
    $stmt = $conn->query("DESCRIBE employees");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasEmployeeNumber = false;
    $hasEmployeeCode = false;
    $hasTcIdentity = false;
    
    foreach ($columns as $col) {
        if ($col['Field'] === 'employee_number') $hasEmployeeNumber = true;
        if ($col['Field'] === 'employee_code') $hasEmployeeCode = true;
        if ($col['Field'] === 'tc_identity') $hasTcIdentity = true;
    }
    
    echo "<p><strong>Veritabanı Alanları:</strong></p>";
    echo "<ul>";
    echo "<li>employee_number: " . ($hasEmployeeNumber ? "✅ VAR" : "❌ YOK") . "</li>";
    echo "<li>employee_code: " . ($hasEmployeeCode ? "✅ VAR" : "❌ YOK") . "</li>";
    echo "<li>tc_identity: " . ($hasTcIdentity ? "✅ VAR" : "❌ YOK") . "</li>";
    echo "</ul>";
    echo "</div>";
    
    // Get current employees data
    $stmt = $conn->prepare("
        SELECT 
            id, 
            first_name, 
            last_name, 
            employee_number,
            employee_code,
            tc_identity,
            CASE 
                WHEN employee_number LIKE 'EMP%' THEN '⚠️ EMP Format'
                WHEN employee_number = tc_identity THEN '✅ TC Kimlik'
                WHEN employee_number IS NULL THEN '❌ Boş'
                ELSE '🔍 Diğer'
            END as number_status,
            CASE 
                WHEN employee_code LIKE 'EMP%' THEN '⚠️ EMP Format'
                WHEN employee_code = tc_identity THEN '✅ TC Kimlik'
                WHEN employee_code IS NULL THEN '❌ Boş'
                ELSE '🔍 Diğer'
            END as code_status
        FROM employees 
        WHERE company_id = ?
        ORDER BY first_name, last_name
    ");
    $stmt->execute([$companyId]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>📋 Personel Listesi ve Durum</h3>";
    if (count($employees) > 0) {
        echo "<table>";
        echo "<tr>";
        echo "<th>Ad Soyad</th>";
        echo "<th>employee_number</th>";
        echo "<th>employee_code</th>";
        echo "<th>TC Kimlik</th>";
        echo "<th>Durum</th>";
        echo "<th>İşlem</th>";
        echo "</tr>";
        
        foreach ($employees as $employee) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . "</td>";
            echo "<td>" . htmlspecialchars($employee['employee_number'] ?? 'YOK') . "</td>";
            echo "<td>" . htmlspecialchars($employee['employee_code'] ?? 'YOK') . "</td>";
            echo "<td>" . htmlspecialchars($employee['tc_identity'] ?? 'YOK') . "</td>";
            echo "<td>" . $employee['number_status'] . " / " . $employee['code_status'] . "</td>";
            echo "<td>";
            if ($employee['tc_identity']) {
                echo "<form method='POST' style='display: inline;'>";
                echo "<input type='hidden' name='action' value='update_employee_number'>";
                echo "<input type='hidden' name='employee_id' value='" . $employee['id'] . "'>";
                echo "<input type='hidden' name='new_number' value='" . htmlspecialchars($employee['tc_identity']) . "'>";
                echo "<button type='submit'>TC Kimlik Kullan</button>";
                echo "</form>";
            } else {
                echo "<span style='color: #999;'>TC Kimlik Yok</span>";
            }
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Personel bulunamadı.</p>";
    }
    
    echo "<hr>";
    echo "<h3>🚀 Toplu İşlemler</h3>";
    
    echo "<div style='display: flex; gap: 10px; margin: 20px 0;'>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='auto_fix_all'>";
    echo "<button type='submit' onclick='return confirm(\"Tüm personel numaraları TC kimlik numaralarıyla değiştirilecek. Onaylıyor musunuz?\")'>Tümünü TC Kimlik Yap</button>";
    echo "</form>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='sync_fields'>";
    echo "<button type='submit'>Alanları Senkronize Et</button>";
    echo "</form>";
    
    echo "</div>";
    
    echo "<hr>";
    echo "<h3>📊 İstatistikler</h3>";
    
    // Statistics
    $empFormatCount = 0;
    $tcIdentityCount = 0;
    $emptyCount = 0;
    $mismatchCount = 0;
    
    foreach ($employees as $emp) {
        if (strpos($emp['employee_number'] ?? '', 'EMP') === 0) $empFormatCount++;
        if ($emp['employee_number'] === $emp['tc_identity'] && $emp['tc_identity']) $tcIdentityCount++;
        if (empty($emp['employee_number'])) $emptyCount++;
        if ($emp['employee_number'] !== $emp['employee_code']) $mismatchCount++;
    }
    
    echo "<div style='display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;'>";
    
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>";
    echo "<h4>📈 Numara Durumları</h4>";
    echo "<ul>";
    echo "<li>EMP formatında: <strong>$empFormatCount</strong></li>";
    echo "<li>TC kimlik kullanan: <strong>$tcIdentityCount</strong></li>";
    echo "<li>Boş olan: <strong>$emptyCount</strong></li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
    echo "<h4>⚠️ Uyumsuzluklar</h4>";
    echo "<ul>";
    echo "<li>employee_number ≠ employee_code: <strong>$mismatchCount</strong></li>";
    echo "</ul>";
    echo "</div>";
    
    echo "</div>";
    
    echo "<hr>";
    echo "<h3>🎯 Tavsiye Edilen İşlem</h3>";
    
    if ($empFormatCount > 0 || $mismatchCount > 0) {
        echo "<div class='warning'>";
        echo "<h4>⚠️ Düzeltme Gerekli</h4>";
        echo "<ol>";
        echo "<li><strong>Tümünü TC Kimlik Yap</strong> butonuna tıklayın</li>";
        echo "<li>Sonrasında <strong>Alanları Senkronize Et</strong> butonuna tıklayın</li>";
        echo "<li>Günlük devam çizelgesi ve personel yönetimini kontrol edin</li>";
        echo "</ol>";
        echo "</div>";
    } else {
        echo "<div class='success'>";
        echo "<h4>✅ Sistem Hazır</h4>";
        echo "<p>Tüm personel numaraları doğru formatta. Ek işlem gerekmiyor.</p>";
        echo "</div>";
    }
    
    echo "<div style='margin-top: 30px;'>";
    echo "<h4>🔗 Kontrol Bağlantıları</h4>";
    echo "<div style='display: flex; gap: 10px;'>";
    echo "<a href='../admin/attendance-tracking.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Günlük Devam Çizelgesi</a>";
    echo "<a href='../admin/employee-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Personel Yönetimi</a>";
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>