<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=UTF-8');

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Foreign Key Constraints Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }";
echo ".container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo "table { border-collapse: collapse; width: 100%; margin: 20px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }";
echo "button:hover { background: #0056b3; }";
echo ".danger { background: #dc3545; }";
echo ".danger:hover { background: #c82333; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";

echo "<h1>🔧 Foreign Key Constraints Düzeltme</h1>";
echo "<p><strong>Problemler:</strong></p>";
echo "<ul>";
echo "<li>SQLSTATE[42000]: Foreign key silme hatası</li>";
echo "<li>SQLSTATE[42S21]: Duplicate column 'shift_template_id'</li>";
echo "<li>SQLSTATE[HY000]: Table creation conflict</li>";
echo "</ul>";
echo "<hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'clean_all_constraints') {
            echo "<h3>🧹 Tüm Foreign Key Constraints Temizleniyor...</h3>";
            
            // Get all foreign keys for employee_shifts table
            $stmt = $conn->query("
                SELECT CONSTRAINT_NAME 
                FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = 'employee_shifts'
                AND REFERENCED_TABLE_NAME IS NOT NULL
            ");
            $constraints = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($constraints as $constraint) {
                try {
                    $conn->exec("ALTER TABLE employee_shifts DROP FOREIGN KEY `$constraint`");
                    echo "<div class='success'>✅ Constraint '$constraint' silindi</div>";
                } catch (Exception $e) {
                    echo "<div class='warning'>⚠️ Constraint '$constraint' silinirken hata: " . $e->getMessage() . "</div>";
                }
            }
            
            if (empty($constraints)) {
                echo "<div class='info'>ℹ️ Silinecek foreign key constraint bulunamadı</div>";
            }
        }
        
        if ($action === 'fix_column_structure') {
            echo "<h3>🔧 Kolon Yapısı Düzeltiliyor...</h3>";
            
            // Check current columns
            $stmt = $conn->query("SHOW COLUMNS FROM employee_shifts");
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $columnNames = array_column($columns, 'Field');
            
            echo "<div class='info'>";
            echo "<h4>📋 Mevcut Kolonlar:</h4>";
            echo "<p>" . implode(', ', $columnNames) . "</p>";
            echo "</div>";
            
            // Fix shift_template_id column if needed
            if (in_array('shift_id', $columnNames) && !in_array('shift_template_id', $columnNames)) {
                try {
                    $conn->exec("ALTER TABLE employee_shifts CHANGE shift_id shift_template_id INT");
                    echo "<div class='success'>✅ shift_id → shift_template_id olarak değiştirildi</div>";
                } catch (Exception $e) {
                    echo "<div class='error'>❌ Kolon değiştirme hatası: " . $e->getMessage() . "</div>";
                }
            }
            
            // Add missing columns if needed
            $requiredColumns = [
                'id' => 'INT AUTO_INCREMENT PRIMARY KEY',
                'employee_id' => 'INT NOT NULL',
                'shift_template_id' => 'INT NOT NULL',
                'shift_date' => 'DATE NOT NULL',
                'status' => 'VARCHAR(20) DEFAULT "scheduled"',
                'created_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP',
                'updated_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
            ];
            
            foreach ($requiredColumns as $column => $definition) {
                if (!in_array($column, $columnNames)) {
                    try {
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN $column $definition");
                        echo "<div class='success'>✅ Kolon '$column' eklendi</div>";
                    } catch (Exception $e) {
                        echo "<div class='warning'>⚠️ Kolon '$column' eklerken hata: " . $e->getMessage() . "</div>";
                    }
                }
            }
        }
        
        if ($action === 'recreate_constraints') {
            echo "<h3>🔄 Foreign Key Constraints Yeniden Oluşturuluyor...</h3>";
            
            // Add proper foreign keys
            $foreignKeys = [
                'fk_employee_shifts_employee' => 'FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE',
                'fk_employee_shifts_template' => 'FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE'
            ];
            
            foreach ($foreignKeys as $name => $definition) {
                try {
                    $conn->exec("ALTER TABLE employee_shifts ADD CONSTRAINT $name $definition");
                    echo "<div class='success'>✅ Constraint '$name' oluşturuldu</div>";
                } catch (Exception $e) {
                    echo "<div class='warning'>⚠️ Constraint '$name' oluşturulurken hata: " . $e->getMessage() . "</div>";
                }
            }
        }
        
        if ($action === 'ensure_shift_templates') {
            echo "<h3>📋 Shift Templates Tablosu Kontrol Ediliyor...</h3>";
            
            // Check if shift_templates exists
            $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
            if ($stmt->rowCount() === 0) {
                try {
                    $conn->exec("
                        CREATE TABLE shift_templates (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            name VARCHAR(100) NOT NULL,
                            start_time TIME NOT NULL,
                            end_time TIME NOT NULL,
                            break_duration INT DEFAULT 60,
                            description TEXT,
                            color_code VARCHAR(7) DEFAULT '#3B82F6',
                            is_active BOOLEAN DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            INDEX idx_company (company_id),
                            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    echo "<div class='success'>✅ shift_templates tablosu oluşturuldu</div>";
                    
                    // Add default templates
                    $conn->exec("
                        INSERT INTO shift_templates (company_id, name, start_time, end_time, break_duration, color_code) VALUES
                        (1, 'Sabah Vardiyası', '09:30:00', '19:30:00', 60, '#3B82F6'),
                        (1, 'Gece Vardiyası', '22:00:00', '08:00:00', 60, '#7C3AED'),
                        (1, 'Öğle Vardiyası', '13:00:00', '23:00:00', 60, '#059669')
                    ");
                    echo "<div class='success'>✅ Varsayılan vardiya şablonları eklendi</div>";
                    
                } catch (Exception $e) {
                    echo "<div class='error'>❌ shift_templates oluşturma hatası: " . $e->getMessage() . "</div>";
                }
            } else {
                echo "<div class='info'>ℹ️ shift_templates tablosu zaten mevcut</div>";
                
                // Check template count
                $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
                $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                echo "<div class='info'>📊 Mevcut şablon sayısı: $count</div>";
            }
        }
        
        if ($action === 'test_shift_assignment') {
            echo "<h3>🧪 Vardiya Atama Test Ediliyor...</h3>";
            
            try {
                // Get test data
                $stmt = $conn->query("SELECT id FROM employees LIMIT 1");
                $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $stmt = $conn->query("SELECT id FROM shift_templates LIMIT 1");
                $template = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($employee && $template) {
                    $testDate = date('Y-m-d', strtotime('+1 day'));
                    
                    // Test insert
                    $stmt = $conn->prepare("
                        INSERT INTO employee_shifts 
                        (employee_id, shift_template_id, shift_date, status) 
                        VALUES (?, ?, ?, 'scheduled')
                    ");
                    $stmt->execute([$employee['id'], $template['id'], $testDate]);
                    
                    $insertedId = $conn->lastInsertId();
                    echo "<div class='success'>✅ Test vardiyası oluşturuldu (ID: $insertedId)</div>";
                    
                    // Clean up
                    $conn->exec("DELETE FROM employee_shifts WHERE id = $insertedId");
                    echo "<div class='info'>ℹ️ Test verisi temizlendi</div>";
                    
                } else {
                    echo "<div class='warning'>⚠️ Test için gerekli veriler bulunamadı</div>";
                }
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Test hatası: " . $e->getMessage() . "</div>";
            }
        }
    }
    
    echo "<div class='info'>";
    echo "<h3>🔍 Mevcut Durum Analizi</h3>";
    
    // Check foreign key constraints
    $stmt = $conn->query("
        SELECT 
            CONSTRAINT_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'employee_shifts'
        AND REFERENCED_TABLE_NAME IS NOT NULL
    ");
    $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>🔗 Foreign Key Constraints:</h4>";
    if (count($constraints) > 0) {
        echo "<table>";
        echo "<tr><th>Constraint</th><th>Kolon</th><th>Referans</th><th>Durum</th></tr>";
        foreach ($constraints as $constraint) {
            $status = "✅ OK";
            if ($constraint['REFERENCED_TABLE_NAME'] === 'shifts') {
                $status = "❌ HATALI";
            }
            echo "<tr>";
            echo "<td>" . $constraint['CONSTRAINT_NAME'] . "</td>";
            echo "<td>" . $constraint['COLUMN_NAME'] . "</td>";
            echo "<td>" . $constraint['REFERENCED_TABLE_NAME'] . "." . $constraint['REFERENCED_COLUMN_NAME'] . "</td>";
            echo "<td>$status</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>❌ Hiç foreign key constraint bulunamadı.</p>";
    }
    
    // Check table structure
    $stmt = $conn->query("SHOW COLUMNS FROM employee_shifts");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>📋 Employee Shifts Tablo Yapısı:</h4>";
    echo "<table>";
    echo "<tr><th>Kolon</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . $column['Field'] . "</td>";
        echo "<td>" . $column['Type'] . "</td>";
        echo "<td>" . $column['Null'] . "</td>";
        echo "<td>" . $column['Key'] . "</td>";
        echo "<td>" . ($column['Default'] ?: '-') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check shift_templates table
    $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
    $templatesExists = $stmt->rowCount() > 0;
    echo "<h4>📊 Shift Templates:</h4>";
    echo "<p><strong>Tablo durumu:</strong> " . ($templatesExists ? "✅ Mevcut" : "❌ Yok") . "</p>";
    
    if ($templatesExists) {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p><strong>Şablon sayısı:</strong> $count</p>";
    }
    
    echo "</div>";
    
    echo "<hr>";
    echo "<h3>🛠️ Düzeltme İşlemleri</h3>";
    
    echo "<div style='display: flex; flex-wrap: wrap; gap: 10px; margin: 20px 0;'>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='clean_all_constraints'>";
    echo "<button type='submit' class='danger' onclick='return confirm(\"Tüm foreign key constraints silinecek. Onaylıyor musunuz?\")'>🧹 FK Temizle</button>";
    echo "</form>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='fix_column_structure'>";
    echo "<button type='submit' onclick='return confirm(\"Kolon yapısı düzeltilecek. Onaylıyor musunuz?\")'>🔧 Kolon Düzelt</button>";
    echo "</form>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='ensure_shift_templates'>";
    echo "<button type='submit'>📋 Templates Kontrol</button>";
    echo "</form>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='recreate_constraints'>";
    echo "<button type='submit' onclick='return confirm(\"Foreign key constraints yeniden oluşturulacak. Onaylıyor musunuz?\")'>🔄 FK Yenile</button>";
    echo "</form>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='test_shift_assignment'>";
    echo "<button type='submit'>🧪 Test Et</button>";
    echo "</form>";
    
    echo "</div>";
    
    echo "<div style='margin-top: 30px;'>";
    echo "<h4>🔗 Test Bağlantıları</h4>";
    echo "<div style='display: flex; gap: 10px;'>";
    echo "<a href='fix-shift-management-display.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Display Test</a>";
    echo "<a href='../admin/shift-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Yönetimi</a>";
    echo "<a href='fix-tc-identity-column.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>TC Kimlik Fix</a>";
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>