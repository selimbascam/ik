<?php
echo "<h2>🔍 PHP PostgreSQL Bağlantı Debug</h2>";

// Step 1: Check PHP PDO drivers
echo "<h3>📋 PHP PDO Drivers</h3>";
$drivers = PDO::getAvailableDrivers();
echo "<p><strong>Mevcut drivers:</strong> " . implode(', ', $drivers) . "</p>";

if (in_array('pgsql', $drivers)) {
    echo "<p style='color: green;'>✅ PostgreSQL PDO driver mevcut</p>";
} else {
    echo "<p style='color: red;'>❌ PostgreSQL PDO driver eksik!</p>";
    exit;
}

// Step 2: Environment variables
echo "<h3>🔧 Environment Variables</h3>";
$database_url = getenv("DATABASE_URL");
echo "<p><strong>DATABASE_URL:</strong> " . ($database_url ? "Set" : "NOT SET") . "</p>";

if ($database_url) {
    $url = parse_url($database_url);
    echo "<ul>";
    echo "<li><strong>Host:</strong> " . ($url["host"] ?? "NOT SET") . "</li>";
    echo "<li><strong>Port:</strong> " . ($url["port"] ?? "NOT SET") . "</li>";
    echo "<li><strong>Database:</strong> " . ltrim($url["path"] ?? "", "/") . "</li>";
    echo "<li><strong>Username:</strong> " . ($url["user"] ?? "NOT SET") . "</li>";
    echo "<li><strong>Password:</strong> " . ($url["pass"] ? "SET" : "NOT SET") . "</li>";
    echo "<li><strong>Query:</strong> " . ($url["query"] ?? "NOT SET") . "</li>";
    echo "</ul>";
    
    // Step 3: Test different DSN formats
    echo "<h3>🧪 DSN Test</h3>";
    
    $host = $url["host"];
    $port = $url["port"] ?? 5432;
    $dbname = ltrim($url["path"], "/");
    $username = $url["user"];
    $password = $url["pass"];
    
    // Test 1: Basic DSN
    echo "<h4>Test 1: Basic DSN</h4>";
    $dsn1 = "pgsql:host=$host;port=$port;dbname=$dbname";
    echo "<p><strong>DSN:</strong> $dsn1</p>";
    
    try {
        $pdo1 = new PDO($dsn1, $username, $password);
        echo "<p style='color: green;'>✅ Basic DSN çalışıyor</p>";
        $pdo1 = null;
    } catch (PDOException $e) {
        echo "<p style='color: red;'>❌ Basic DSN hatası: " . $e->getMessage() . "</p>";
    }
    
    // Test 2: DSN with SSL
    echo "<h4>Test 2: DSN with SSL</h4>";
    $dsn2 = "pgsql:host=$host;port=$port;dbname=$dbname;sslmode=require";
    echo "<p><strong>DSN:</strong> $dsn2</p>";
    
    try {
        $pdo2 = new PDO($dsn2, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_SSL_CA => false,
            PDO::ATTR_SSL_VERIFY_SERVER_CERT => false
        ]);
        echo "<p style='color: green;'>✅ SSL DSN çalışıyor</p>";
        
        // Test query
        $stmt = $pdo2->query("SELECT 1 as test");
        $result = $stmt->fetch();
        echo "<p style='color: green;'>✅ Test query başarılı: " . $result['test'] . "</p>";
        
        $pdo2 = null;
    } catch (PDOException $e) {
        echo "<p style='color: red;'>❌ SSL DSN hatası: " . $e->getMessage() . "</p>";
    }
    
    // Test 3: DSN with all options
    echo "<h4>Test 3: DSN with all SSL options</h4>";
    $dsn3 = "pgsql:host=$host;port=$port;dbname=$dbname;sslmode=require";
    
    try {
        $pdo3 = new PDO($dsn3, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 30
        ]);
        
        echo "<p style='color: green;'>✅ Full SSL DSN çalışıyor</p>";
        
        // Test actual database query
        $stmt = $pdo3->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' LIMIT 3");
        $tables = $stmt->fetchAll();
        
        echo "<p style='color: green;'>✅ Database query başarılı. Tablolar:</p>";
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li>" . $table['table_name'] . "</li>";
        }
        echo "</ul>";
        
        $pdo3 = null;
        
        // Success - update the main database.php
        echo "<h3>🎉 Başarılı Bağlantı!</h3>";
        echo "<p style='color: green;'>PostgreSQL bağlantısı çalışıyor. database.php güncelleniyor...</p>";
        
        // Update database.php with working configuration
        $newDatabaseCode = '<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    public $conn;

    public function __construct() {
        $database_url = getenv("DATABASE_URL");
        
        if ($database_url) {
            $url = parse_url($database_url);
            $this->host = $url["host"];
            $this->port = $url["port"] ?? 5432;
            $this->db_name = ltrim($url["path"], "/");
            $this->username = $url["user"];
            $this->password = $url["pass"];
        } else {
            throw new Exception("DATABASE_URL environment variable not set");
        }
    }

    public function getConnection() {
        if ($this->conn !== null) {
            return $this->conn;
        }

        try {
            $dsn = "pgsql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";sslmode=require";
            
            $this->conn = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => 30
            ]);
            
            $this->conn->exec("SET timezone = \'UTC\'");
            
        } catch(PDOException $exception) {
            error_log("PostgreSQL bağlantı hatası: " . $exception->getMessage());
            throw new Exception("Veritabanı bağlantısı kurulamadı: " . $exception->getMessage());
        }

        return $this->conn;
    }
    
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }
    
    public function showTables() {
        $stmt = $this->conn->query("SELECT table_name FROM information_schema.tables WHERE table_schema = \'public\'");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    public function showColumns($tableName) {
        $stmt = $this->conn->prepare("
            SELECT column_name as Field, data_type as Type, 
                   is_nullable as \"Null\", column_default as \"Default\"
            FROM information_schema.columns 
            WHERE table_name = ? 
            ORDER BY ordinal_position
        ");
        $stmt->execute([$tableName]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function testConnection() {
        try {
            $conn = $this->getConnection();
            $stmt = $conn->query("SELECT 1");
            return [\'success\' => 1, \'message\' => \'PostgreSQL bağlantısı başarılı\'];
        } catch (Exception $e) {
            return [\'success\' => 0, \'message\' => $e->getMessage()];
        }
    }
}
?>';
        
        if (file_put_contents('../includes/database.php', $newDatabaseCode)) {
            echo "<p style='color: green;'>✅ database.php başarıyla güncellendi!</p>";
        } else {
            echo "<p style='color: red;'>❌ database.php güncellenemedi</p>";
        }
        
    } catch (PDOException $e) {
        echo "<p style='color: red;'>❌ Full SSL DSN hatası: " . $e->getMessage() . "</p>";
    }
    
} else {
    echo "<p style='color: red;'>❌ DATABASE_URL environment variable bulunamadı</p>";
}

echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>";
?>