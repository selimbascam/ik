<?php
// Quick Foreign Key Fix için komut listesi
// MySQL bağlantısı olmadığında manuel çalıştırılacak

$commands = [
    "-- 1. Hatalı foreign key constraint'i sil",
    "ALTER TABLE employee_shifts DROP FOREIGN KEY employee_shifts_ibfk_3;",
    "",
    "-- 2. shift_id kolonunu shift_template_id olarak değiştir",
    "ALTER TABLE employee_shifts CHANGE shift_id shift_template_id INT;",
    "",
    "-- 3. Doğru foreign key constraint ekle", 
    "ALTER TABLE employee_shifts ADD CONSTRAINT fk_employee_shifts_template FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE;",
    "",
    "-- 4. Test sorgusu",
    "INSERT INTO employee_shifts (employee_id, shift_template_id, shift_date, status) VALUES (1, 1, '2025-08-15', 'scheduled');",
    "DELETE FROM employee_shifts WHERE shift_date = '2025-08-15' AND employee_id = 1;",
    "",
    "-- 5. Doğrulama",
    "DESCRIBE employee_shifts;",
    "SELECT CONSTRAINT_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = 'employee_shifts' AND REFERENCED_TABLE_NAME IS NOT NULL;"
];

echo "<!DOCTYPE html>";
echo "<html><head><title>Foreign Key Quick Fix</title></head><body>";
echo "<h1>Employee Shifts Foreign Key Quick Fix</h1>";
echo "<p><strong>Problem:</strong> employee_shifts tablosu mevcut olmayan 'shifts' tablosuna referans veriyor</p>";
echo "<p><strong>Çözüm:</strong> Aşağıdaki SQL komutlarını sırayla çalıştırın</p>";
echo "<hr>";
echo "<pre style='background: #f5f5f5; padding: 20px; border: 1px solid #ddd;'>";
foreach ($commands as $cmd) {
    echo $cmd . "\n";
}
echo "</pre>";
echo "<hr>";
echo "<p><strong>Not:</strong> Bu komutlar MySQL/MariaDB sunucusunda çalıştırılmalıdır.</p>";
echo "</body></html>";
?>