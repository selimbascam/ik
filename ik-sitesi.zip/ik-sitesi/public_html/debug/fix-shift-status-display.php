<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'analyze_shift_status':
                try {
                    echo "<div class='bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4'>";
                    echo "<h3 class='font-bold text-blue-900 mb-2'>🔍 Vardiya Durum Analizi</h3>";
                    
                    // Get today's date info
                    $today = date('Y-m-d');
                    $dayName = date('l');
                    $dayNameTurkish = [
                        'Monday' => 'Pazartesi',
                        'Tuesday' => 'Salı', 
                        'Wednesday' => 'Çarşamba',
                        'Thursday' => 'Perşembe',
                        'Friday' => 'Cuma',
                        'Saturday' => 'Cumartesi',
                        'Sunday' => 'Pazar'
                    ];
                    
                    echo "<h4 class='font-semibold mt-4 mb-2'>Bugünkü Tarih Bilgisi:</h4>";
                    echo "📅 Bugün: $today (" . $dayNameTurkish[$dayName] . ")<br>";
                    
                    // Check all employees
                    echo "<h4 class='font-semibold mt-4 mb-2'>Personel Vardiya Durumu:</h4>";
                    $stmt = $conn->query("SELECT id, first_name, last_name, employee_number FROM employees ORDER BY first_name");
                    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    echo "<table class='w-full mt-2 text-sm border'>";
                    echo "<tr class='bg-gray-100'>";
                    echo "<th class='border p-2'>Personel</th>";
                    echo "<th class='border p-2'>Bugünkü Vardiya</th>";
                    echo "<th class='border p-2'>Status</th>";
                    echo "<th class='border p-2'>Vardiya Şablonu</th>";
                    echo "</tr>";
                    
                    foreach ($employees as $employee) {
                        echo "<tr>";
                        echo "<td class='border p-2'>" . $employee['first_name'] . " " . $employee['last_name'] . "</td>";
                        
                        // Check today's shift for this employee
                        $stmt = $conn->prepare("
                            SELECT 
                                es.status,
                                es.shift_date,
                                st.name as shift_name,
                                st.start_time,
                                st.end_time
                            FROM employee_shifts es
                            LEFT JOIN shift_templates st ON es.shift_template_id = st.id
                            WHERE es.employee_id = ? AND DATE(es.shift_date) = ?
                        ");
                        $stmt->execute([$employee['id'], $today]);
                        $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($todayShift) {
                            echo "<td class='border p-2'>" . 
                                 ($todayShift['shift_name'] ?: 'Tanımsız') . " " .
                                 date('H:i', strtotime($todayShift['start_time'])) . "-" .
                                 date('H:i', strtotime($todayShift['end_time'])) . 
                                 "</td>";
                            echo "<td class='border p-2 " . 
                                 ($todayShift['status'] === 'scheduled' ? 'text-green-600' : 'text-yellow-600') . 
                                 "'>" . ($todayShift['status'] ?: 'Planlanmış') . "</td>";
                            echo "<td class='border p-2'>✅ Atanmış</td>";
                        } else {
                            echo "<td class='border p-2 text-red-600'>Vardiya Yok</td>";
                            echo "<td class='border p-2 text-red-600'>İzinli/Atanmamış</td>";
                            echo "<td class='border p-2'>❌ Atanmamış</td>";
                        }
                        
                        echo "</tr>";
                    }
                    echo "</table>";
                    
                    // Check available shift templates
                    echo "<h4 class='font-semibold mt-4 mb-2'>Mevcut Vardiya Şablonları:</h4>";
                    $stmt = $conn->query("
                        SELECT id, name, start_time, end_time, is_active 
                        FROM shift_templates 
                        ORDER BY name
                    ");
                    $templates = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if ($templates) {
                        echo "<table class='w-full mt-2 text-sm border'>";
                        echo "<tr class='bg-gray-100'>";
                        echo "<th class='border p-2'>ID</th>";
                        echo "<th class='border p-2'>Şablon Adı</th>";
                        echo "<th class='border p-2'>Saatler</th>";
                        echo "<th class='border p-2'>Aktif</th>";
                        echo "</tr>";
                        
                        foreach ($templates as $template) {
                            echo "<tr>";
                            echo "<td class='border p-2'>" . $template['id'] . "</td>";
                            echo "<td class='border p-2'>" . $template['name'] . "</td>";
                            echo "<td class='border p-2'>" . 
                                 date('H:i', strtotime($template['start_time'])) . " - " .
                                 date('H:i', strtotime($template['end_time'])) . "</td>";
                            echo "<td class='border p-2 " . 
                                 ($template['is_active'] ? 'text-green-600' : 'text-red-600') . 
                                 "'>" . ($template['is_active'] ? 'Aktif' : 'Pasif') . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p class='text-red-600'>❌ Hiç vardiya şablonu bulunamadı!</p>";
                    }
                    
                    echo "</div>";
                } catch (Exception $e) {
                    $message = "❌ Analiz hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
                
            case 'assign_weekday_shifts':
                try {
                    // Get the 09:30-19:30 shift template (or create it)
                    $stmt = $conn->prepare("
                        SELECT id FROM shift_templates 
                        WHERE start_time = '09:30:00' AND end_time = '19:30:00' 
                        LIMIT 1
                    ");
                    $stmt->execute();
                    $template = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$template) {
                        // Create the shift template first
                        $stmt = $conn->prepare("
                            INSERT INTO shift_templates (company_id, name, start_time, end_time, break_duration, is_active) 
                            VALUES (1, 'Hafta İçi Vardiya (09:30-19:30)', '09:30:00', '19:30:00', 60, 1)
                        ");
                        $stmt->execute();
                        $templateId = $conn->lastInsertId();
                        echo "<p class='text-green-600'>✅ Yeni vardiya şablonu oluşturuldu (09:30-19:30)</p>";
                    } else {
                        $templateId = $template['id'];
                        echo "<p class='text-blue-600'>ℹ️ Mevcut vardiya şablonu kullanılıyor (ID: $templateId)</p>";
                    }
                    
                    // Get all employees
                    $stmt = $conn->query("SELECT id, first_name, last_name FROM employees");
                    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    $totalAssigned = 0;
                    $dates = [];
                    
                    // Create dates for next 30 days (weekdays only)
                    for ($i = 0; $i < 30; $i++) {
                        $date = date('Y-m-d', strtotime("+$i day"));
                        $dayOfWeek = date('N', strtotime($date)); // 1=Monday, 7=Sunday
                        
                        // Only Monday to Friday (1-5)
                        if ($dayOfWeek >= 1 && $dayOfWeek <= 5) {
                            $dates[] = $date;
                        }
                    }
                    
                    foreach ($employees as $employee) {
                        $employeeAssigned = 0;
                        foreach ($dates as $date) {
                            $stmt = $conn->prepare("
                                INSERT IGNORE INTO employee_shifts 
                                (employee_id, shift_template_id, shift_date, status) 
                                VALUES (?, ?, ?, 'scheduled')
                            ");
                            $stmt->execute([$employee['id'], $templateId, $date]);
                            if ($stmt->rowCount() > 0) {
                                $employeeAssigned++;
                                $totalAssigned++;
                            }
                        }
                        echo "<p class='text-green-600'>✅ " . $employee['first_name'] . " " . $employee['last_name'] . ": $employeeAssigned hafta içi vardiya atandı</p>";
                    }
                    
                    $message = "✅ Toplam $totalAssigned hafta içi vardiya ataması yapıldı (09:30-19:30, Pazartesi-Cuma)";
                    $messageType = "success";
                } catch (Exception $e) {
                    $message = "❌ Vardiya atama hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
                
            case 'fix_today_shifts':
                try {
                    $today = date('Y-m-d');
                    $dayOfWeek = date('N'); // 1=Monday, 7=Sunday
                    
                    if ($dayOfWeek >= 1 && $dayOfWeek <= 5) { // Weekday
                        // Get 09:30-19:30 template
                        $stmt = $conn->prepare("
                            SELECT id FROM shift_templates 
                            WHERE start_time = '09:30:00' AND end_time = '19:30:00' 
                            LIMIT 1
                        ");
                        $stmt->execute();
                        $template = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($template) {
                            $templateId = $template['id'];
                            
                            // Get all employees without today's shift
                            $stmt = $conn->prepare("
                                SELECT e.id, e.first_name, e.last_name 
                                FROM employees e
                                LEFT JOIN employee_shifts es ON e.id = es.employee_id AND DATE(es.shift_date) = ?
                                WHERE es.id IS NULL
                            ");
                            $stmt->execute([$today]);
                            $employeesWithoutShift = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            $assigned = 0;
                            foreach ($employeesWithoutShift as $employee) {
                                $stmt = $conn->prepare("
                                    INSERT INTO employee_shifts 
                                    (employee_id, shift_template_id, shift_date, status) 
                                    VALUES (?, ?, ?, 'scheduled')
                                ");
                                $stmt->execute([$employee['id'], $templateId, $today]);
                                $assigned++;
                                echo "<p class='text-green-600'>✅ " . $employee['first_name'] . " " . $employee['last_name'] . ": Bugünkü vardiya atandı</p>";
                            }
                            
                            $message = "✅ $assigned personele bugünkü vardiya atandı";
                            $messageType = "success";
                        } else {
                            $message = "❌ 09:30-19:30 vardiya şablonu bulunamadı";
                            $messageType = "error";
                        }
                    } else {
                        $message = "ℹ️ Bugün hafta sonu, vardiya ataması yapılmadı";
                        $messageType = "info";
                    }
                } catch (Exception $e) {
                    $message = "❌ Bugünkü vardiya atama hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
        }
        
    } catch (Exception $e) {
        $message = "❌ Genel hata: " . $e->getMessage();
        $messageType = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vardiya Durum Düzeltme - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 p-6">
    <div class="max-w-5xl mx-auto">
        <div class="bg-white rounded-xl shadow-lg p-8">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">🔧 Vardiya Durum Düzeltme</h1>
                    <p class="text-gray-600 mt-2">"İzinli" gösterilen personellerin vardiya durumunu düzeltme aracı</p>
                </div>
                <a href="../super-admin/fix-critical-errors.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                    ← Geri Dön
                </a>
            </div>

            <?php if ($message): ?>
                <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : ($messageType === 'info' ? 'bg-blue-50 border border-blue-200 text-blue-800' : 'bg-red-50 border border-red-200 text-red-800'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Analysis Section -->
                <div class="bg-blue-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-blue-900 mb-4">🔍 Analiz</h2>
                    
                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="action" value="analyze_shift_status">
                        <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Vardiya Durumunu Analiz Et
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-blue-700">
                        <p><strong>Bu analiz:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>Bugün için her personelin vardiya durumunu kontrol eder</li>
                            <li>Mevcut vardiya şablonlarını listeler</li>
                            <li>"İzinli" gösterilme nedenini tespit eder</li>
                        </ul>
                    </div>
                </div>

                <!-- Quick Fix Section -->
                <div class="bg-green-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-green-900 mb-4">⚡ Hızlı Düzeltme</h2>
                    
                    <form method="POST" class="space-y-3">
                        <input type="hidden" name="action" value="fix_today_shifts">
                        <button type="submit" class="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                            Bugünkü Vardiyaları Düzelt
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-green-700">
                        <p><strong>Bu işlem:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>Bugün vardiyası olmayan personelleri tespit eder</li>
                            <li>09:30-19:30 vardiyasını atar (hafta içi ise)</li>
                            <li>"İzinli" durumunu düzeltir</li>
                        </ul>
                    </div>
                </div>

                <!-- Complete Setup Section -->
                <div class="bg-purple-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-purple-900 mb-4">📅 Tam Kurulum</h2>
                    
                    <form method="POST" class="space-y-3">
                        <input type="hidden" name="action" value="assign_weekday_shifts">
                        <button type="submit" class="w-full bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                            Hafta İçi Vardiyaları Kur (30 Gün)
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-purple-700">
                        <p><strong>Bu işlem:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>09:30-19:30 vardiya şablonu oluşturur</li>
                            <li>Tüm personele 30 gün hafta içi vardiya atar</li>
                            <li>Pazartesi-Cuma çalışma düzenini kurar</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="mt-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h3 class="font-bold text-yellow-900 mb-2">⚠️ Önemli Bilgiler:</h3>
                <ul class="list-disc pl-5 text-sm text-yellow-800">
                    <li><strong>İzinli Gösterilme Nedeni:</strong> Personellere o gün için atanmış vardiya bulunmamaktadır</li>
                    <li><strong>Çözüm:</strong> Vardiya şablonu oluşturup personellere atama yapılmalıdır</li>
                    <li><strong>Hafta İçi Çalışma:</strong> Sistem Pazartesi-Cuma çalışma düzenini destekler</li>
                    <li><strong>Otomatik Atama:</strong> Gelecekteki vardiyalar otomatik olarak "scheduled" durumunda atanır</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>