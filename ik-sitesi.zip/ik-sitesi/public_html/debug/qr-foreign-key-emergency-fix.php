<?php
// Emergency Foreign Key Fix for All QR Systems
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🚨 Emergency Foreign Key Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Test employee
    $employee_number = '30716129672';
    
    echo "<h3>1. Employee Lookup & Fix</h3>";
    $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute([$employee_number]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "❌ Employee $employee_number not found<br>";
        exit;
    }
    
    echo "✅ Employee: {$employee['first_name']} {$employee['last_name']}<br>";
    echo "Current company_id: " . ($employee['company_id'] ?? 'NULL') . "<br>";
    
    // Fix company_id if needed
    if (!$employee['company_id']) {
        echo "<strong>🔧 Fixing NULL company_id...</strong><br>";
        
        $stmt = $conn->prepare("SELECT id, company_name FROM companies ORDER BY id LIMIT 1");
        $stmt->execute();
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$company) {
            // Create emergency company
            $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute(['Emergency Company', 'admin@emergency.com', '555-0000', 'Emergency Address', 'active']);
            $company = ['id' => $conn->lastInsertId(), 'company_name' => 'Emergency Company'];
            echo "🆕 Created emergency company: {$company['id']}<br>";
        }
        
        $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
        $stmt->execute([$company['id'], $employee['id']]);
        $employee['company_id'] = $company['id'];
        echo "✅ Updated employee company_id to {$company['id']}<br>";
    }
    
    // Verify company exists
    echo "<h3>2. Company Verification</h3>";
    $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
    $stmt->execute([$employee['company_id']]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        echo "✅ Company exists: {$company['company_name']} (ID: {$company['id']})<br>";
    } else {
        echo "❌ CRITICAL: Company {$employee['company_id']} does not exist!<br>";
        exit;
    }
    
    // Check/create QR location
    echo "<h3>3. QR Location Check</h3>";
    $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$employee['company_id']]);
    $location = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$location) {
        echo "🔧 Creating default QR location...<br>";
        $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, location_type, status, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$employee['company_id'], 'Default QR Location', 'entrance', 'active']);
        $location = ['id' => $conn->lastInsertId(), 'name' => 'Default QR Location'];
        echo "✅ Created QR location: {$location['id']}<br>";
    } else {
        echo "✅ QR location found: {$location['name']} (ID: {$location['id']})<br>";
    }
    
    // Test foreign key constraint with real insert
    echo "<h3>4. Foreign Key Constraint Test</h3>";
    
    // Check for GPS columns
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $hasGPS = in_array('latitude', $columns) && in_array('longitude', $columns);
    
    echo "GPS columns exist: " . ($hasGPS ? 'YES' : 'NO') . "<br>";
    
    try {
        $conn->beginTransaction();
        
        if ($hasGPS) {
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, 
                 latitude, longitude, notes, created_at, date) 
                VALUES (?, ?, ?, ?, NOW(), ?, ?, ?, NOW(), CURDATE())
            ");
            
            $result = $stmt->execute([
                $employee['company_id'],
                $employee['id'],
                $location['id'],
                'work_start',
                null, // latitude
                null, // longitude
                'Emergency FK test - ' . date('Y-m-d H:i:s')
            ]);
        } else {
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, 
                 notes, created_at, date) 
                VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
            ");
            
            $result = $stmt->execute([
                $employee['company_id'],
                $employee['id'],
                $location['id'],
                'work_start',
                'Emergency FK test - ' . date('Y-m-d H:i:s')
            ]);
        }
        
        if ($result) {
            $recordId = $conn->lastInsertId();
            echo "✅ SUCCESS! Test record inserted (ID: $recordId)<br>";
            
            // Clean up
            $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
            $stmt->execute([$recordId]);
            echo "🧹 Test record cleaned up<br>";
            
            $conn->commit();
        } else {
            echo "❌ Insert failed (unknown reason)<br>";
            $conn->rollback();
        }
        
    } catch (Exception $e) {
        $conn->rollback();
        echo "❌ FOREIGN KEY ERROR: " . $e->getMessage() . "<br>";
        
        // Debug foreign key relationships
        echo "<h4>Foreign Key Debug:</h4>";
        echo "Employee ID: {$employee['id']} (exists: YES)<br>";
        echo "Company ID: {$employee['company_id']} (exists: " . ($company ? 'YES' : 'NO') . ")<br>";
        echo "QR Location ID: {$location['id']} (exists: YES)<br>";
        
        // Check constraints
        $stmt = $conn->query("
            SELECT 
                CONSTRAINT_NAME, 
                COLUMN_NAME, 
                REFERENCED_TABLE_NAME, 
                REFERENCED_COLUMN_NAME 
            FROM information_schema.KEY_COLUMN_USAGE 
            WHERE TABLE_NAME = 'attendance_records' 
            AND CONSTRAINT_NAME LIKE '%fk%'
        ");
        $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "Foreign key constraints:<br>";
        foreach ($constraints as $constraint) {
            echo "- {$constraint['CONSTRAINT_NAME']}: {$constraint['COLUMN_NAME']} -> {$constraint['REFERENCED_TABLE_NAME']}.{$constraint['REFERENCED_COLUMN_NAME']}<br>";
        }
    }
    
    echo "<h3>5. Final Status</h3>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin-top: 20px;'>";
    echo "<strong>Foreign Key Components:</strong><br>";
    echo "✅ Employee ID: {$employee['id']}<br>";
    echo "✅ Company ID: {$employee['company_id']}<br>";
    echo "✅ QR Location ID: {$location['id']}<br>";
    echo "<br><strong>Next Steps:</strong><br>";
    echo "1. Use qr-attendance-master.php for QR scanning<br>";
    echo "2. All emergency fixes applied to master system<br>";
    echo "3. Foreign key should now work properly<br>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "❌ Critical Error: " . $e->getMessage();
}
?>