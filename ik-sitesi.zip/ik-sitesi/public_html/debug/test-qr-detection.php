<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/attendance-helper.php';

echo "<h1>🔍 QR Code Detection System Test</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;} .test{background:#f9f9f9;padding:15px;margin:10px 0;border-left:3px solid #007acc;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='test'>";
    echo "<h2>🔧 Database Schema Check</h2>";
    
    // Check attendance_records table
    echo "<h3>📋 Attendance Records Table</h3>";
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $attendanceColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse:collapse;margin:10px 0;'>";
    echo "<tr><th>Column</th><th>Type</th><th>Available</th></tr>";
    
    $requiredCols = ['check_in', 'check_out', 'break_start', 'break_end'];
    $alternatives = [
        'check_in' => ['check_in', 'clock_in', 'start_time'],
        'check_out' => ['check_out', 'clock_out', 'end_time'],
        'break_start' => ['break_start'],
        'break_end' => ['break_end']
    ];
    
    $columnNames = array_column($attendanceColumns, 'Field');
    $columnMapping = [];
    
    foreach ($requiredCols as $required) {
        $found = false;
        $mappedCol = $required;
        
        foreach ($alternatives[$required] as $alt) {
            if (in_array($alt, $columnNames)) {
                $mappedCol = $alt;
                $found = true;
                break;
            }
        }
        
        $columnMapping[$required] = $mappedCol;
        $status = $found ? "✅ $mappedCol" : "❌ MISSING";
        echo "<tr><td>$required</td><td>TIMESTAMP</td><td>$status</td></tr>";
    }
    echo "</table>";
    echo "</div>";
    
    echo "<div class='test'>";
    echo "<h2>🧪 Test QR Location Detection</h2>";
    
    // Check QR locations
    $stmt = $conn->query("SELECT id, name, location_type, gate_behavior FROM qr_locations LIMIT 5");
    $qrLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($qrLocations)) {
        echo "<p class='error'>❌ No QR locations found in database</p>";
        echo "<p>Creating test QR location...</p>";
        
        // Create a test location
        $stmt = $conn->prepare("
            INSERT INTO qr_locations (company_id, name, location_type, gate_behavior, latitude, longitude, radius, is_active) 
            VALUES (1, 'Test Entrance Gate', 'entrance', 'work_start', 41.0082, 28.9784, 100, 1)
        ");
        $stmt->execute();
        
        echo "<p class='success'>✅ Test QR location created</p>";
        
        // Re-fetch locations
        $stmt = $conn->query("SELECT id, name, location_type, gate_behavior FROM qr_locations LIMIT 5");
        $qrLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo "<table border='1' style='border-collapse:collapse;margin:10px 0;'>";
    echo "<tr><th>ID</th><th>Name</th><th>Type</th><th>Gate Behavior</th></tr>";
    foreach ($qrLocations as $loc) {
        echo "<tr>";
        echo "<td>{$loc['id']}</td>";
        echo "<td>{$loc['name']}</td>";
        echo "<td>{$loc['location_type']}</td>";
        echo "<td><strong>{$loc['gate_behavior']}</strong></td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    
    echo "<div class='test'>";
    echo "<h2>🎯 Test Gate Behavior Detection</h2>";
    
    // Test the gate behavior detection logic from QR reader
    if (!empty($qrLocations)) {
        $testLocation = $qrLocations[0];
        $locationId = $testLocation['id'];
        $testEmployeeId = 1;
        $testCompanyId = 1;
        
        echo "<p><strong>Testing Location:</strong> {$testLocation['name']} (ID: $locationId)</p>";
        echo "<p><strong>Gate Behavior:</strong> {$testLocation['gate_behavior']}</p>";
        
        try {
            // Test the gate behavior detection
            require_once '../includes/qr-attendance-fixed.php';
            $result = QRAttendanceHelper::determineGateAction($conn, $testEmployeeId, $testCompanyId, $locationId, $testLocation['gate_behavior']);
            
            echo "<p class='success'>✅ Gate behavior detection successful!</p>";
            echo "<p><strong>Recommended Action:</strong> {$result['action']}</p>";
            echo "<p><strong>Message:</strong> {$result['message']}</p>";
            
        } catch (Exception $e) {
            echo "<p class='error'>❌ Gate behavior detection failed: " . $e->getMessage() . "</p>";
            
            // Show specific error details
            if (strpos($e->getMessage(), 'check_in') !== false) {
                echo "<p class='info'>🔍 This appears to be a column mapping issue. Checking...</p>";
                
                // Test column mapping
                echo "<p><strong>Column Mapping:</strong></p>";
                echo "<ul>";
                foreach ($columnMapping as $standard => $mapped) {
                    echo "<li>$standard → $mapped</li>";
                }
                echo "</ul>";
            }
        }
    }
    echo "</div>";
    
    echo "<div class='test'>";
    echo "<h2>🚀 Test Manual QR Code Processing</h2>";
    
    // Simulate a QR code scan
    $testQRCode = json_encode(['location_id' => $qrLocations[0]['id'] ?? 1]);
    echo "<p><strong>Test QR Code:</strong> $testQRCode</p>";
    
    try {
        // Parse QR code like the QR reader does
        $qrData = json_decode($testQRCode, true);
        $locationId = $qrData['location_id'] ?? 1;
        
        // Get location info
        $stmt = $conn->prepare("SELECT id, name, location_type, gate_behavior FROM qr_locations WHERE id = ?");
        $stmt->execute([$locationId]);
        $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($qrLocation) {
            echo "<p class='success'>✅ QR location found: {$qrLocation['name']}</p>";
            echo "<p><strong>Gate Behavior:</strong> {$qrLocation['gate_behavior']}</p>";
            
            // Test with fixed QR attendance helper
            $result = QRAttendanceHelper::determineGateAction($conn, 1, 1, $locationId, $qrLocation['gate_behavior']);
            echo "<p class='success'>✅ QR processing successful!</p>";
            echo "<p><strong>Action:</strong> {$result['action']}</p>";
            echo "<p><strong>Message:</strong> {$result['message']}</p>";
        } else {
            echo "<p class='error'>❌ QR location not found</p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='error'>❌ QR processing failed: " . $e->getMessage() . "</p>";
        
        if (strpos($e->getMessage(), 'SQLSTATE[42S22]') !== false) {
            echo "<div style='background:#fff3cd;padding:10px;border:1px solid #ffeaa7;margin:10px 0;'>";
            echo "<h4>🛠️ Column Error Detected</h4>";
            echo "<p>The system is still trying to access non-existent columns. This suggests that some parts of the code are not using the flexible column mapping.</p>";
            echo "<p><strong>Solution:</strong> The attendance helper needs to be updated to consistently use the column mapping throughout all functions.</p>";
            echo "</div>";
        }
    }
    echo "</div>";
    
    echo "<div style='background:#d1ecf1;border:1px solid #bee5eb;padding:20px;margin:20px 0;'>";
    echo "<h2>📋 System Status Summary</h2>";
    
    $hasAllColumns = true;
    foreach ($columnMapping as $standard => $mapped) {
        if (!in_array($mapped, $columnNames)) {
            $hasAllColumns = false;
            break;
        }
    }
    
    if ($hasAllColumns && !empty($qrLocations)) {
        echo "<p class='success'><strong>✅ QR SYSTEM LOOKS READY</strong></p>";
        echo "<p>All required columns are available and QR locations exist.</p>";
        echo "<p><a href='../qr/qr-reader.php' style='background:#28a745;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;'>🚀 Try QR Reader</a></p>";
    } else {
        echo "<p class='error'><strong>❌ QR system needs attention</strong></p>";
        echo "<p>Some components are missing or need configuration.</p>";
        echo "<p><a href='fix-all-attendance-columns.php' style='background:#ffc107;color:black;padding:10px 20px;text-decoration:none;border-radius:5px;'>🔧 Run Column Fix</a></p>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Test failed: " . $e->getMessage() . "</p>";
}
?>