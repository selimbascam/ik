<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/error-logger.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$message = '';
$messageType = '';
$diagnostics = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Diagnostics function
    function addDiagnostic($type, $title, $details) {
        global $diagnostics;
        $diagnostics[] = [
            'type' => $type,
            'title' => $title,
            'details' => $details
        ];
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix_action'])) {
        switch ($_POST['fix_action']) {
            case 'add_salary_column':
                // Check if salary column exists in employees table
                $columnExists = false;
                try {
                    $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'salary'");
                    $columnExists = $columnCheck->rowCount() > 0;
                } catch (Exception $e) {
                    addDiagnostic('error', 'Table Check Failed', $e->getMessage());
                }
                
                if (!$columnExists) {
                    try {
                        // Add salary column
                        $conn->exec("ALTER TABLE employees ADD COLUMN salary DECIMAL(10,2) DEFAULT NULL COMMENT 'Aylık maaş'");
                        addDiagnostic('success', 'Salary Column Added', 'salary column added to employees table');
                        
                        $message = "✅ salary column successfully added to employees table";
                        $messageType = "success";
                    } catch (Exception $e) {
                        $message = "❌ Failed to add salary column: " . $e->getMessage();
                        $messageType = "error";
                        addDiagnostic('error', 'Column Add Failed', $e->getMessage());
                    }
                } else {
                    $message = "ℹ️ salary column already exists";
                    $messageType = "info";
                }
                break;
                
            case 'comprehensive_fix':
                $steps = [];
                
                // Step 1: Add salary column
                try {
                    $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'salary'");
                    if ($columnCheck->rowCount() === 0) {
                        $conn->exec("ALTER TABLE employees ADD COLUMN salary DECIMAL(10,2) DEFAULT NULL COMMENT 'Aylık maaş'");
                        $steps[] = "✅ salary column added to employees table";
                    } else {
                        $steps[] = "ℹ️ salary column already exists";
                    }
                } catch (Exception $e) {
                    $steps[] = "❌ Salary column add failed: " . $e->getMessage();
                }
                
                // Step 2: Add hourly_rate column
                try {
                    $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'hourly_rate'");
                    if ($columnCheck->rowCount() === 0) {
                        $conn->exec("ALTER TABLE employees ADD COLUMN hourly_rate DECIMAL(8,2) DEFAULT NULL COMMENT 'Saatlik ücret'");
                        $steps[] = "✅ hourly_rate column added to employees table";
                    } else {
                        $steps[] = "ℹ️ hourly_rate column already exists";
                    }
                } catch (Exception $e) {
                    $steps[] = "❌ Hourly rate column add failed: " . $e->getMessage();
                }
                
                // Step 3: Mark errors as solved
                try {
                    $stmt = $conn->prepare("
                        UPDATE system_error_log 
                        SET status = 'solved', 
                            solution_notes = 'Salary column errors fixed - missing salary column added to employees table',
                            solved_by = 'Salary Column Fix Tool',
                            solved_at = NOW()
                        WHERE (error_message LIKE '%salary%' 
                        OR error_message LIKE '%Unknown column%e.salary%')
                        AND status = 'unsolved'
                    ");
                    $stmt->execute();
                    $fixedErrorCount = $stmt->rowCount();
                    $steps[] = "✅ " . $fixedErrorCount . " related errors marked as solved";
                } catch (Exception $e) {
                    $steps[] = "⚠️ Error marking: " . $e->getMessage();
                }
                
                $message = "🔧 Comprehensive Salary Fix Completed:<br>" . implode('<br>', $steps);
                $messageType = "success";
                break;
                
            case 'test_salary_query':
                // Test a basic salary query
                try {
                    $stmt = $conn->query("SELECT e.id, e.first_name, e.last_name, COALESCE(e.salary, 0) as salary FROM employees e LIMIT 3");
                    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    $message = "✅ Salary query test successful. Retrieved " . count($results) . " records.";
                    $messageType = "success";
                    addDiagnostic('success', 'Query Test', 'Salary SELECT query works correctly');
                } catch (Exception $e) {
                    $message = "❌ Salary query test failed: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Query Test Failed', $e->getMessage());
                }
                break;
        }
    }
    
    // Diagnostic checks
    addDiagnostic('info', 'Database Connection', 'Connected successfully');
    
    // Check employees table structure
    try {
        $columns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        
        $salaryColumns = ['salary', 'hourly_rate'];
        $existingColumns = array_intersect($salaryColumns, $columnNames);
        $missingColumns = array_diff($salaryColumns, $columnNames);
        
        if (!empty($existingColumns)) {
            addDiagnostic('success', 'Existing Salary Columns', implode(', ', $existingColumns));
        }
        if (!empty($missingColumns)) {
            addDiagnostic('error', 'Missing Salary Columns', implode(', ', $missingColumns));
        }
        
    } catch (Exception $e) {
        addDiagnostic('error', 'Table Structure Check', $e->getMessage());
    }

} catch (Exception $e) {
    $message = "Database connection failed: " . $e->getMessage();
    $messageType = "error";
    addDiagnostic('error', 'Critical Error', $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Column Fix - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">💰 Salary Column Fix</h1>
                        <p class="text-gray-600 mt-1">Maaş sütunu hatalarını düzeltin</p>
                    </div>
                    <a href="../super-admin/fix-critical-errors.php" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
                        ← Critical Errors
                    </a>
                </div>
            </div>

            <!-- Message -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg border <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border-green-200' : ($messageType === 'error' ? 'bg-red-100 text-red-800 border-red-200' : 'bg-blue-100 text-blue-800 border-blue-200'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Quick Fixes -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Quick Fixes</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <!-- Add Salary Column -->
                    <div class="border border-red-200 rounded-lg p-4 bg-red-50">
                        <h3 class="font-bold text-red-800 mb-2">💰 Salary Column</h3>
                        <p class="text-sm text-red-600 mb-3">
                            employees tablosuna eksik salary sütununu ekle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="add_salary_column" 
                                    class="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm">
                                💰 Salary Column Ekle
                            </button>
                        </form>
                    </div>

                    <!-- Test Salary Query -->
                    <div class="border border-blue-200 rounded-lg p-4 bg-blue-50">
                        <h3 class="font-bold text-blue-800 mb-2">🧪 Test Salary Query</h3>
                        <p class="text-sm text-blue-600 mb-3">
                            Maaş sorgularının çalışıp çalışmadığını test et.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="test_salary_query" 
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                                🧪 Test Query
                            </button>
                        </form>
                    </div>

                    <!-- Comprehensive Fix -->
                    <div class="border border-green-200 rounded-lg p-4 bg-green-50 md:col-span-2">
                        <h3 class="font-bold text-green-800 mb-2">🔧 Comprehensive Fix</h3>
                        <p class="text-sm text-green-600 mb-3">
                            Tüm maaş sütunlarını ekle ve hataları işaretle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="comprehensive_fix" 
                                    class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm">
                                🔧 Complete Fix
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Diagnostics -->
            <?php if (!empty($diagnostics)): ?>
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🔍 System Diagnostics</h2>
                
                <div class="space-y-3">
                    <?php foreach ($diagnostics as $diagnostic): ?>
                        <div class="border-l-4 p-3 <?php echo $diagnostic['type'] === 'success' ? 'border-green-500 bg-green-50' : ($diagnostic['type'] === 'error' ? 'border-red-500 bg-red-50' : ($diagnostic['type'] === 'warning' ? 'border-yellow-500 bg-yellow-50' : 'border-blue-500 bg-blue-50')); ?>">
                            <h4 class="font-bold <?php echo $diagnostic['type'] === 'success' ? 'text-green-800' : ($diagnostic['type'] === 'error' ? 'text-red-800' : ($diagnostic['type'] === 'warning' ? 'text-yellow-800' : 'text-blue-800')); ?>">
                                <?php 
                                $icon = $diagnostic['type'] === 'success' ? '✅' : ($diagnostic['type'] === 'error' ? '❌' : ($diagnostic['type'] === 'warning' ? '⚠️' : 'ℹ️'));
                                echo $icon . ' ' . $diagnostic['title']; 
                                ?>
                            </h4>
                            <p class="text-sm <?php echo $diagnostic['type'] === 'success' ? 'text-green-600' : ($diagnostic['type'] === 'error' ? 'text-red-600' : ($diagnostic['type'] === 'warning' ? 'text-yellow-600' : 'text-blue-600')); ?> mt-1">
                                <?php echo $diagnostic['details']; ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</body>
</html>