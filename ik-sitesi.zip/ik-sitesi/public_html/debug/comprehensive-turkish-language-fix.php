<?php
require_once '../includes/config.php';

echo "<h2>🇹🇷 Kapsamlı Türkçe Dil Düzeltmesi</h2>";

// Sistem genelinde İngilizce tespit ve düzeltme
$englishPatterns = [
    // Common English words that should be Turkish
    '/\b(Error|Success|Failed|Invalid|Missing|Required|Optional|Warning|Information)\b/i' => [
        'Error' => 'Hata',
        'Success' => 'Başarılı', 
        'Failed' => 'Başarısız',
        'Invalid' => 'Geçersiz',
        'Missing' => 'Eksik',
        'Required' => 'Zorunlu',
        'Optional' => 'İsteğe Bağlı',
        'Warning' => 'Uyarı',
        'Information' => 'Bilgi'
    ],
    
    '/\b(Login|Logout|Password|Email|Submit|Cancel|Save|Delete|Edit|Add|Update|Search|Filter|Reset)\b/i' => [
        'Login' => 'Giriş',
        'Logout' => 'Çıkış', 
        'Password' => 'Şifre',
        'Email' => 'E-posta',
        'Submit' => 'Gönder',
        'Cancel' => 'İptal',
        'Save' => 'Kaydet',
        'Delete' => 'Sil',
        'Edit' => 'Düzenle',
        'Add' => 'Ekle',
        'Update' => 'Güncelle',
        'Search' => 'Ara',
        'Filter' => 'Filtrele',
        'Reset' => 'Sıfırla'
    ],
    
    '/\b(Loading|Processing|Completed|Pending|Active|Inactive|Enabled|Disabled)\b/i' => [
        'Loading' => 'Yükleniyor',
        'Processing' => 'İşleniyor',
        'Completed' => 'Tamamlandı',
        'Pending' => 'Beklemede',
        'Active' => 'Aktif',
        'Inactive' => 'Pasif',
        'Enabled' => 'Etkinleştirilmiş',
        'Disabled' => 'Devre Dışı'
    ],
    
    '/\b(Camera|Scanner|QR Code|Location|Coordinates|GPS|Device|Browser|Platform)\b/i' => [
        'Camera' => 'Kamera',
        'Scanner' => 'Tarayıcı',
        'QR Code' => 'QR Kod',
        'Location' => 'Konum',
        'Coordinates' => 'Koordinatlar',
        'GPS' => 'GPS',
        'Device' => 'Cihaz',
        'Browser' => 'Tarayıcı',
        'Platform' => 'Platform'
    ],
    
    '/\b(Attendance|Check In|Check Out|Break Start|Break End|Work Hours|Overtime|Holiday|Leave)\b/i' => [
        'Attendance' => 'Devam',
        'Check In' => 'Giriş',
        'Check Out' => 'Çıkış',
        'Break Start' => 'Mola Başlangıcı',
        'Break End' => 'Mola Bitişi',
        'Work Hours' => 'Çalışma Saatleri',
        'Overtime' => 'Mesai',
        'Holiday' => 'Tatil',
        'Leave' => 'İzin'
    ]
];

$fixedFiles = [];
$totalReplacements = 0;

// Kritik dosya yolları
$criticalDirectories = [
    '../api/',
    '../auth/',
    '../qr/',
    '../admin/',
    '../employee/',
    '../super-admin/',
    '../debug/'
];

echo "<h3>📁 Dosya Tarama ve Düzeltme</h3>";

foreach ($criticalDirectories as $dir) {
    if (!is_dir($dir)) continue;
    
    $files = glob($dir . '*.php');
    
    foreach ($files as $file) {
        $content = file_get_contents($file);
        $originalContent = $content;
        $fileReplacements = 0;
        
        // Her pattern grubu için kontrol et
        foreach ($englishPatterns as $pattern => $replacements) {
            foreach ($replacements as $english => $turkish) {
                
                // HTML content içinde
                $content = preg_replace("/>{$english}</i", ">{$turkish}<", $content);
                $content = preg_replace("/'{$english}'/i", "'{$turkish}'", $content);
                $content = preg_replace("/\"{$english}\"/i", "\"{$turkish}\"", $content);
                
                // JavaScript alert/console içinde
                $content = preg_replace("/alert\s*\(\s*['\"]?{$english}['\"]?\s*\)/i", "alert('{$turkish}')", $content);
                $content = preg_replace("/console\.(log|error|warn|info)\s*\(\s*['\"]?{$english}['\"]?/i", "console.$1('{$turkish}'", $content);
                
                // PHP echo/print içinde
                $content = preg_replace("/echo\s+['\"]?{$english}['\"]?/i", "echo '{$turkish}'", $content);
                $content = preg_replace("/print\s+['\"]?{$english}['\"]?/i", "print '{$turkish}'", $content);
                
                // JSON message içinde
                $content = preg_replace("/['\"]message['\"]?\s*=>\s*['\"]?{$english}['\"]?/i", "'message' => '{$turkish}'", $content);
                $content = preg_replace("/['\"]message['\"]?\s*:\s*['\"]?{$english}['\"]?/i", "'message': '{$turkish}'", $content);
                
                // HTML title/placeholder içinde
                $content = preg_replace("/title\s*=\s*['\"]?{$english}['\"]?/i", "title='{$turkish}'", $content);
                $content = preg_replace("/placeholder\s*=\s*['\"]?{$english}['\"]?/i", "placeholder='{$turkish}'", $content);
                
                // HTML text content
                $content = preg_replace("/>[^<]*{$english}[^<]*</i", function($matches) use ($english, $turkish) {
                    return str_ireplace($english, $turkish, $matches[0]);
                }, $content);
                
                if ($content !== $originalContent) {
                    $fileReplacements++;
                }
            }
        }
        
        // Özel durumlar için manual fixes
        $specialFixes = [
            // Database/Table related
            'Table not found' => 'Tablo bulunamadı',
            'Column not found' => 'Sütun bulunamadı',
            'Record not found' => 'Kayıt bulunamadı',
            'Database connection failed' => 'Veritabanı bağlantısı başarısız',
            'Query failed' => 'Sorgu başarısız',
            'Insert failed' => 'Ekleme başarısız',
            'Update failed' => 'Güncelleme başarısız',
            'Delete failed' => 'Silme başarısız',
            
            // UI Elements
            'Back' => 'Geri',
            'Next' => 'İleri',
            'Previous' => 'Önceki',
            'Close' => 'Kapat',
            'Open' => 'Aç',
            'View' => 'Görüntüle',
            'Print' => 'Yazdır',
            'Export' => 'Dışa Aktar',
            'Import' => 'İçe Aktar',
            'Download' => 'İndir',
            'Upload' => 'Yükle',
            
            // Status Messages
            'Permission denied' => 'İzin reddedildi',
            'Access denied' => 'Erişim reddedildi',
            'Session expired' => 'Oturum süresi doldu',
            'Invalid request' => 'Geçersiz istek',
            'Operation successful' => 'İşlem başarılı',
            'Operation failed' => 'İşlem başarısız',
            'Data saved successfully' => 'Veri başarıyla kaydedildi',
            'Data deleted successfully' => 'Veri başarıyla silindi',
            'Data updated successfully' => 'Veri başarıyla güncellendi',
            'Validation error' => 'Doğrulama hatası',
            'File upload failed' => 'Dosya yüklemesi başarısız',
            'File not found' => 'Dosya bulunamadı',
            'Configuration error' => 'Yapılandırma hatası',
            
            // Time/Date
            'Today' => 'Bugün',
            'Tomorrow' => 'Yarın', 
            'Yesterday' => 'Dün',
            'Week' => 'Hafta',
            'Month' => 'Ay',
            'Year' => 'Yıl',
            'Day' => 'Gün',
            'Hour' => 'Saat',
            'Minute' => 'Dakika',
            'Second' => 'Saniye',
            
            // Days
            'Monday' => 'Pazartesi',
            'Tuesday' => 'Salı',
            'Wednesday' => 'Çarşamba',
            'Thursday' => 'Perşembe',
            'Friday' => 'Cuma',
            'Saturday' => 'Cumartesi',
            'Sunday' => 'Pazar',
            
            // Months
            'January' => 'Ocak',
            'February' => 'Şubat',
            'March' => 'Mart',
            'April' => 'Nisan',
            'May' => 'Mayıs',
            'June' => 'Haziran',
            'July' => 'Temmuz',
            'August' => 'Ağustos',
            'September' => 'Eylül',
            'October' => 'Ekim',
            'November' => 'Kasım',
            'December' => 'Aralık'
        ];
        
        foreach ($specialFixes as $english => $turkish) {
            $newContent = str_ireplace($english, $turkish, $content);
            if ($newContent !== $content) {
                $content = $newContent;
                $fileReplacements++;
            }
        }
        
        // Dosyayı kaydet
        if ($content !== $originalContent) {
            if (file_put_contents($file, $content)) {
                $fixedFiles[] = [
                    'file' => basename($file),
                    'path' => $file,
                    'replacements' => $fileReplacements
                ];
                $totalReplacements += $fileReplacements;
                echo "<p>✅ " . basename($file) . " - {$fileReplacements} değişiklik</p>";
            } else {
                echo "<p>❌ " . basename($file) . " - Kaydedilemedi</p>";
            }
        }
    }
}

echo "<h3>📊 Türkçeleştirme Raporu</h3>";
echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<ul>";
echo "<li><strong>Düzeltilen dosya sayısı:</strong> " . count($fixedFiles) . "</li>";
echo "<li><strong>Toplam değişiklik sayısı:</strong> {$totalReplacements}</li>";
echo "<li><strong>Kontrol edilen dizin sayısı:</strong> " . count($criticalDirectories) . "</li>";
echo "</ul>";
echo "</div>";

if (count($fixedFiles) > 0) {
    echo "<h4>🔧 Düzeltilen Dosyalar:</h4>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
    echo "<tr><th>Dosya</th><th>Değişiklik Sayısı</th><th>Yol</th></tr>";
    
    foreach ($fixedFiles as $fileInfo) {
        echo "<tr>";
        echo "<td>{$fileInfo['file']}</td>";
        echo "<td>{$fileInfo['replacements']}</td>";
        echo "<td style='font-size: 10px;'>{$fileInfo['path']}</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Manuel kontrol önerileri
echo "<h3>🔍 Manuel Kontrol Gereken Alanlar</h3>";
echo "<ol>";
echo "<li><strong>HTML title etiketleri:</strong> Sayfa başlıkları Türkçe olmalı</li>";
echo "<li><strong>JavaScript alert mesajları:</strong> Kullanıcı uyarıları Türkçe olmalı</li>";
echo "<li><strong>CSS yorumları:</strong> Kod yorumları Türkçe olabilir</li>";
echo "<li><strong>Database içeriği:</strong> Tablo ve sütun isimleri kontrol edilmeli</li>";
echo "<li><strong>Log mesajları:</strong> error_log() çıktıları Türkçe olabilir</li>";
echo "<li><strong>HTML meta açıklamaları:</strong> SEO için önemli</li>";
echo "</ol>";

// Son kontrol için pattern testi
echo "<h3>🎯 Son Kontrol - Kalan İngilizce Kelimeler</h3>";

$testFiles = [
    '../api/auth.php',
    '../qr/qr-reader.php', 
    '../auth/employee-login.php',
    '../admin/employee-management.php'
];

$remainingEnglish = [];

foreach ($testFiles as $testFile) {
    if (file_exists($testFile)) {
        $content = file_get_contents($testFile);
        
        // Common English words search
        $commonEnglishWords = [
            'Error', 'Success', 'Failed', 'Invalid', 'Missing', 'Required',
            'Login', 'Password', 'Email', 'Submit', 'Cancel', 'Save',
            'Loading', 'Processing', 'Camera', 'Scanner', 'Location'
        ];
        
        foreach ($commonEnglishWords as $word) {
            if (preg_match("/\b{$word}\b/i", $content)) {
                $remainingEnglish[] = [
                    'file' => basename($testFile),
                    'word' => $word
                ];
            }
        }
    }
}

if (count($remainingEnglish) > 0) {
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h4>⚠️ Hala İngilizce Kelimeler Tespit Edildi:</h4>";
    echo "<ul>";
    foreach ($remainingEnglish as $item) {
        echo "<li><strong>{$item['file']}</strong>: {$item['word']}</li>";
    }
    echo "</ul>";
    echo "</div>";
} else {
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>🇹🇷 Tüm Sistem Türkçe!</h2>";
    echo "<p>Ana dosyalarda İngilizce kelime tespit edilmedi.</p>";
    echo "<p>Sistem artık tamamen Türkçe dil desteğine sahip.</p>";
    echo "</div>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>