<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/qr-attendance-fixed.php';

echo "<h2>🔬 Selim QR Devam Takibi - Kapsamlı Test</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Step 1: Find Selim
    echo "<h3>👤 Selim Personeli Bulma</h3>";
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, employee_code, COALESCE(tc_no, '') as tc_identity, company_id
        FROM employees 
        WHERE (first_name LIKE '%Selim%' OR last_name LIKE '%Selim%')
        LIMIT 1
    ");
    $stmt->execute();
    $selim = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$selim) {
        // Use any employee if Selim not found
        $stmt = $conn->query("SELECT id, first_name, last_name, employee_code, COALESCE(tc_no, '') as tc_identity, company_id FROM employees LIMIT 1");
        $selim = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$selim) {
            throw new Exception("Test için personel bulunamadı");
        }
        echo "<p>⚠️ Selim bulunamadı, test personeli: {$selim['first_name']} {$selim['last_name']}</p>";
    } else {
        echo "<p>✅ Selim bulundu: {$selim['first_name']} {$selim['last_name']}</p>";
    }
    
    $selimId = $selim['id'];
    $companyId = $selim['company_id'];
    
    // Step 2: Create/Find QR Location
    echo "<h3>📍 QR Lokasyon Kontrolü</h3>";
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE is_active = 1 LIMIT 1");
    $stmt->execute();
    $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$qrLocation) {
        echo "<p>🔧 QR lokasyon oluşturuluyor...</p>";
        $stmt = $conn->prepare("
            INSERT INTO qr_locations (name, address, latitude, longitude, tolerance_meters, is_active, created_at)
            VALUES ('Test Ofis - Selim', 'Merkez Lokasyon', 41.0082, 28.9784, 100, 1, NOW())
        ");
        $stmt->execute();
        $locationId = $conn->lastInsertId();
        
        $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE id = ?");
        $stmt->execute([$locationId]);
        $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<p>✅ QR lokasyon oluşturuldu</p>";
    }
    
    $locationId = $qrLocation['id'];
    echo "<p>📍 Kullanılacak QR Lokasyon: {$qrLocation['name']} (ID: {$locationId})</p>";
    
    // Step 3: Check today's existing records
    echo "<h3>📊 Mevcut Kayıt Durumu</h3>";
    $today = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count 
        FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) = ?
    ");
    $stmt->execute([$selimId, $today]);
    $existingCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<p>📋 Selim'in bugünkü mevcut kayıt sayısı: {$existingCount}</p>";
    
    // Step 4: Simulate session and QR scan
    echo "<h3>🎭 QR Tarama Simülasyonu</h3>";
    session_start();
    $_SESSION['employee_id'] = $selimId;
    $_SESSION['company_id'] = $companyId;
    $_SESSION['employee_name'] = $selim['first_name'] . ' ' . $selim['last_name'];
    
    echo "<p>✅ Session simüle edildi</p>";
    
    // Create QR data as it would come from real scan
    $qrData = [
        'location_id' => $locationId,
        'name' => $qrLocation['name'],
        'latitude' => $qrLocation['latitude'],
        'longitude' => $qrLocation['longitude'],
        'tolerance' => $qrLocation['tolerance_meters']
    ];
    
    echo "<p>✅ QR data hazırlandı</p>";
    
    // Step 5: Test the complete QR attendance flow
    echo "<h3>🔄 QR Attendance Helper Testi</h3>";
    
    try {
        $helper = new QRAttendanceHelper($conn);
        $result = $helper->processQRAttendance($qrData, $selimId, $companyId);
        
        if ($result['success']) {
            echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
            echo "<p><strong>✅ QR Attendance Helper Başarılı!</strong></p>";
            echo "<p>Mesaj: {$result['message']}</p>";
            if (isset($result['activity_details'])) {
                echo "<p>Aktivite: {$result['activity_details']['activity']}</p>";
                echo "<p>Lokasyon: {$result['activity_details']['location']}</p>";
                echo "<p>Zaman: {$result['activity_details']['time']}</p>";
            }
            echo "</div>";
        } else {
            echo "<div style='background: #f8d7da; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
            echo "<p><strong>❌ QR Attendance Helper Başarısız</strong></p>";
            echo "<p>Hata: {$result['message']}</p>";
            echo "</div>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ QR Attendance Helper hatası: " . $e->getMessage() . "</p>";
        
        // Fallback: Direct SQL insert test
        echo "<h4>🔧 Direct SQL Insert Testi</h4>";
        
        $currentTime = date('H:i:s');
        $currentDateTime = date('Y-m-d H:i:s');
        
        try {
            $stmt = $conn->prepare("
                INSERT INTO attendance_records (
                    employee_id, qr_location_id, activity_type, 
                    check_in_time, latitude, longitude, 
                    notes, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $selimId,
                $locationId,
                'work_in',
                $currentTime,
                $qrData['latitude'],
                $qrData['longitude'],
                'Direct SQL test - ' . date('Y-m-d H:i:s'),
                $currentDateTime
            ]);
            
            if ($result) {
                $insertId = $conn->lastInsertId();
                echo "<p>✅ Direct SQL insert başarılı (ID: {$insertId})</p>";
            } else {
                echo "<p>❌ Direct SQL insert başarısız</p>";
            }
            
        } catch (Exception $e2) {
            echo "<p>❌ Direct SQL insert hatası: " . $e2->getMessage() . "</p>";
        }
    }
    
    // Step 6: Verify final record count
    echo "<h3>🔍 Sonuç Doğrulaması</h3>";
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count 
        FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) = ?
    ");
    $stmt->execute([$selimId, $today]);
    $finalCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<p><strong>Selim'in final kayıt sayısı: {$finalCount}</strong></p>";
    
    if ($finalCount > $existingCount) {
        echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
        echo "<h2>🎉 TESTİ BAŞARILI!</h2>";
        echo "<p>Selim'in QR kod okutma sistemi çalışıyor!</p>";
        echo "<p>Yeni kayıt oluşturuldu ve veritabanına kaydedildi.</p>";
        echo "<p><strong>Önceki kayıt sayısı:</strong> {$existingCount}</p>";
        echo "<p><strong>Sonraki kayıt sayısı:</strong> {$finalCount}</p>";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
        echo "<h2>⚠️ Test Sonucu Belirsiz</h2>";
        echo "<p>Kayıt sayısında artış görülmedi.</p>";
        echo "<p>Bu duplicate record kontrolü veya başka bir neden olabilir.</p>";
        echo "</div>";
    }
    
    // Step 7: Show recent records
    echo "<h3>📄 Son Kayıtlar</h3>";
    $stmt = $conn->prepare("
        SELECT 
            ar.*,
            ql.name as location_name 
        FROM attendance_records ar
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ? 
        ORDER BY ar.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$selimId]);
    $recentRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($recentRecords)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
        echo "<tr><th>ID</th><th>Aktivite</th><th>Saat</th><th>Lokasyon</th><th>Tarih</th><th>Notlar</th></tr>";
        
        foreach ($recentRecords as $record) {
            echo "<tr>";
            echo "<td>{$record['id']}</td>";
            echo "<td>{$record['activity_type']}</td>";
            echo "<td>{$record['check_in_time']}</td>";
            echo "<td>" . ($record['location_name'] ?? 'N/A') . "</td>";
            echo "<td>" . date('d.m.Y H:i', strtotime($record['created_at'])) . "</td>";
            echo "<td>" . htmlspecialchars($record['notes'] ?? '') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>❌ Hiç kayıt bulunamadı</p>";
    }
    
    // Final recommendations
    echo "<h3>🎯 Sonraki Adımlar</h3>";
    echo "<ol>";
    echo "<li><strong>Gerçek Test:</strong> Selim ile gerçek QR kod okutma testi yapın</li>";
    echo "<li><strong>Attendance Summary:</strong> ../employee/attendance-summary.php sayfasını kontrol edin</li>";
    echo "<li><strong>QR Reader:</strong> ../qr/qr-reader.php ile canlı test yapın</li>";
    echo "<li><strong>Smart Attendance:</strong> ../qr/smart-attendance.php'yi test edin</li>";
    echo "</ol>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Test Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>