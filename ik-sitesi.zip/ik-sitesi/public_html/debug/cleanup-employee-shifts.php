<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🧹 Employee Shifts Temizleme ve Düzeltme</h2>";
    echo "<hr>";
    
    // 1. Remove problematic foreign key constraints
    echo "<h3>🔧 Foreign Key Constraint'leri Temizle</h3>";
    
    try {
        // Drop problematic constraints if they exist
        $constraints = [
            'employee_shifts_ibfk_3',
            'employee_shifts_ibfk_2', 
            'fk_employee_shifts_shift'
        ];
        
        foreach ($constraints as $constraint) {
            try {
                $conn->exec("ALTER TABLE employee_shifts DROP FOREIGN KEY $constraint");
                echo "<p>✅ $constraint constraint silindi</p>";
            } catch (Exception $e) {
                echo "<p>ℹ️ $constraint constraint zaten mevcut değil</p>";
            }
        }
        
    } catch (Exception $e) {
        echo "<p>❌ Constraint silme hatası: " . $e->getMessage() . "</p>";
    }
    
    // 2. Check and fix table structure
    echo "<h3>📊 Tablo Yapısını Kontrol Et</h3>";
    
    // Check employee_shifts structure
    $result = $conn->query("DESCRIBE employee_shifts");
    $columns = [];
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $columns[] = $row['Field'];
    }
    
    echo "<p>Mevcut sütunlar: " . implode(', ', $columns) . "</p>";
    
    // Remove shift_id column if it exists
    if (in_array('shift_id', $columns)) {
        try {
            $conn->exec("ALTER TABLE employee_shifts DROP COLUMN shift_id");
            echo "<p>✅ shift_id sütunu silindi</p>";
        } catch (Exception $e) {
            echo "<p>❌ shift_id silme hatası: " . $e->getMessage() . "</p>";
        }
    }
    
    // Add shift_template_id if it doesn't exist
    if (!in_array('shift_template_id', $columns)) {
        try {
            $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT");
            echo "<p>✅ shift_template_id sütunu eklendi</p>";
        } catch (Exception $e) {
            echo "<p>❌ shift_template_id ekleme hatası: " . $e->getMessage() . "</p>";
        }
    }
    
    // 3. Ensure shift_templates table exists
    echo "<h3>📋 Shift Templates Tablosunu Kontrol Et</h3>";
    
    $checkTable = $conn->query("SHOW TABLES LIKE 'shift_templates'");
    if ($checkTable->rowCount() === 0) {
        $conn->exec("
            CREATE TABLE shift_templates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                break_duration INT DEFAULT 60,
                is_active BOOLEAN DEFAULT 1,
                color_code VARCHAR(7) DEFAULT '#3B82F6',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<p>✅ shift_templates tablosu oluşturuldu</p>";
        
        // Add default templates
        $conn->exec("
            INSERT INTO shift_templates (name, start_time, end_time, break_duration, color_code) VALUES
            ('Sabah Vardiyası', '09:30:00', '19:30:00', 60, '#3B82F6'),
            ('Gece Vardiyası', '22:00:00', '08:00:00', 60, '#7C3AED'),
            ('Öğle Vardiyası', '13:00:00', '23:00:00', 60, '#059669')
        ");
        echo "<p>✅ Varsayılan vardiya şablonları eklendi</p>";
    } else {
        echo "<p>ℹ️ shift_templates tablosu zaten mevcut</p>";
    }
    
    // 4. Update existing employee_shifts records
    echo "<h3>🔄 Mevcut Kayıtları Güncelle</h3>";
    
    // Get default template ID
    $stmt = $conn->query("SELECT id FROM shift_templates WHERE start_time = '09:30:00' AND end_time = '19:30:00' LIMIT 1");
    $template = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($template) {
        $defaultTemplateId = $template['id'];
        
        // Update records with null shift_template_id
        $stmt = $conn->prepare("UPDATE employee_shifts SET shift_template_id = ? WHERE shift_template_id IS NULL OR shift_template_id = 0");
        $stmt->execute([$defaultTemplateId]);
        $updatedCount = $stmt->rowCount();
        echo "<p>✅ $updatedCount kayıt varsayılan şablonla güncellendi</p>";
    }
    
    // 5. Add proper foreign key constraint
    echo "<h3>🔗 Doğru Foreign Key Constraint Ekle</h3>";
    
    try {
        $conn->exec("
            ALTER TABLE employee_shifts 
            ADD CONSTRAINT fk_employee_shifts_template 
            FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
        ");
        echo "<p>✅ Doğru foreign key constraint eklendi</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Foreign key constraint zaten mevcut veya ekleme hatası: " . $e->getMessage() . "</p>";
    }
    
    // 6. Clean up orphaned records
    echo "<h3>🧹 Yetim Kayıtları Temizle</h3>";
    
    // Remove shifts with invalid employee references
    $stmt = $conn->query("
        DELETE es FROM employee_shifts es 
        LEFT JOIN employees e ON es.employee_id = e.id 
        WHERE e.id IS NULL
    ");
    $orphanedCount = $stmt->rowCount();
    echo "<p>✅ $orphanedCount geçersiz employee referansına sahip kayıt silindi</p>";
    
    // 7. Verification
    echo "<h3>✅ Doğrulama</h3>";
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_shifts");
    $totalShifts = $stmt->fetch()['count'];
    echo "<p>Toplam vardiya kaydı: $totalShifts</p>";
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_shifts WHERE shift_template_id IS NOT NULL");
    $validShifts = $stmt->fetch()['count'];
    echo "<p>Geçerli şablon referansına sahip: $validShifts</p>";
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
    $totalTemplates = $stmt->fetch()['count'];
    echo "<p>Toplam vardiya şablonu: $totalTemplates</p>";
    
    echo "<hr>";
    echo "<h3>🎉 Temizleme Tamamlandı!</h3>";
    echo "<p><strong>Yapılan işlemler:</strong></p>";
    echo "<ul>";
    echo "<li>Problemli foreign key constraint'ler silindi</li>";
    echo "<li>shift_id sütunu kaldırıldı</li>";
    echo "<li>shift_template_id sütunu eklendi/kontrol edildi</li>";
    echo "<li>shift_templates tablosu oluşturuldu</li>";
    echo "<li>Mevcut kayıtlar güncellendi</li>";
    echo "<li>Doğru foreign key constraint eklendi</li>";
    echo "<li>Yetim kayıtlar temizlendi</li>";
    echo "</ul>";
    
    echo "<p>Artık vardiya sistemi düzgün çalışacak!</p>";
    
    echo "<p><a href='../admin/company-holiday-management.php' style='background: #3B82F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Tatil Yönetimi</a>";
    echo "<a href='../admin/index.php' style='background: #6B7280; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Admin Panel</a></p>";
    
} catch (Exception $e) {
    echo "<h2>❌ Hata</h2>";
    echo "<p>Temizleme işlemi sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "<p><strong>Hata detayları:</strong> " . $e->getTraceAsString() . "</p>";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Shifts Temizleme - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        h2, h3 { color: #333; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .info { color: #17a2b8; }
        ul { margin: 10px 0; padding-left: 30px; }
        li { margin: 5px 0; }
        a { margin: 5px; }
    </style>
</head>
<body>
</body>
</html>