<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔧 Personel Numarası Düzeltme</h2>";
    echo "<hr>";
    
    // Get company ID
    $companyId = $_SESSION['company_id'] ?? 1;
    
    // Handle form submission for manual correction
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'update_employee_number') {
            $employeeId = $_POST['employee_id'];
            $newNumber = $_POST['new_number'];
            
            $stmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ? AND company_id = ?");
            $stmt->execute([$newNumber, $employeeId, $companyId]);
            
            echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ Personel numarası güncellendi: $newNumber";
            echo "</div>";
        }
        
        if ($action === 'auto_fix_selim') {
            // Update Selim Başçam's employee number specifically
            $stmt = $conn->prepare("UPDATE employees SET employee_number = '30716129672' WHERE (first_name LIKE '%Selim%' OR first_name LIKE '%selim%') AND (last_name LIKE '%Başçam%' OR last_name LIKE '%başçam%' OR last_name LIKE '%BAŞÇAM%') AND company_id = ?");
            $stmt->execute([$companyId]);
            $affected = $stmt->rowCount();
            
            echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ Selim Başçam'ın personel numarası 30716129672 olarak güncellendi ($affected kayıt)";
            echo "</div>";
        }
    }
    
    // Get all employees with their current numbers
    $stmt = $conn->prepare("
        SELECT 
            id, 
            first_name, 
            last_name, 
            employee_number,
            COALESCE(tc_no, '') as tc_identity,
            email,
            phone,
            created_at
        FROM employees 
        WHERE company_id = ?
        ORDER BY first_name, last_name
    ");
    $stmt->execute([$companyId]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>📋 Mevcut Personel Listesi</h3>";
    
    if (empty($employees)) {
        echo "<p>❌ Personel bulunamadı</p>";
    } else {
        echo "<table border='1' style='width: 100%; border-collapse: collapse; margin: 20px 0;'>";
        echo "<tr style='background: #f8f9fa;'>";
        echo "<th style='padding: 10px;'>Ad Soyad</th>";
        echo "<th style='padding: 10px;'>Mevcut Personel No</th>";
        echo "<th style='padding: 10px;'>TC Kimlik</th>";
        echo "<th style='padding: 10px;'>Email</th>";
        echo "<th style='padding: 10px;'>Telefon</th>";
        echo "<th style='padding: 10px;'>İşlemler</th>";
        echo "</tr>";
        
        foreach ($employees as $employee) {
            $fullName = $employee['first_name'] . ' ' . $employee['last_name'];
            $currentNumber = $employee['employee_number'] ?: 'Yok';
            $tcIdentity = $employee['tc_identity'] ?: 'Yok';
            
            echo "<tr>";
            echo "<td style='padding: 8px;'>" . htmlspecialchars($fullName) . "</td>";
            echo "<td style='padding: 8px; font-family: monospace;'>" . htmlspecialchars($currentNumber) . "</td>";
            echo "<td style='padding: 8px; font-family: monospace;'>" . htmlspecialchars($tcIdentity) . "</td>";
            echo "<td style='padding: 8px;'>" . htmlspecialchars($employee['email'] ?: '-') . "</td>";
            echo "<td style='padding: 8px;'>" . htmlspecialchars($employee['phone'] ?: '-') . "</td>";
            echo "<td style='padding: 8px;'>";
            
            // Manual update form
            echo "<form method='POST' style='display: inline;'>";
            echo "<input type='hidden' name='action' value='update_employee_number'>";
            echo "<input type='hidden' name='employee_id' value='" . $employee['id'] . "'>";
            echo "<input type='text' name='new_number' placeholder='Yeni numara' style='width: 120px; padding: 2px;'>";
            echo "<button type='submit' style='background: #007bff; color: white; border: none; padding: 4px 8px; border-radius: 3px; cursor: pointer; margin-left: 5px;'>Güncelle</button>";
            echo "</form>";
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    echo "<hr>";
    echo "<h3>🛠️ Hızlı Düzeltme İşlemleri</h3>";
    
    // Quick fix for Selim Başçam
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h4>Selim Başçam Düzeltme</h4>";
    echo "<p>Selim Başçam'ın personel numarasını 30716129672 olarak ayarla</p>";
    echo "<form method='POST'>";
    echo "<input type='hidden' name='action' value='auto_fix_selim'>";
    echo "<button type='submit' style='background: #28a745; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;'>Selim Başçam'ı Düzelt</button>";
    echo "</form>";
    echo "</div>";
    
    // Check if employee_number column exists and is properly formatted
    echo "<h3>🔍 Veritabanı Yapısı Kontrolü</h3>";
    
    $result = $conn->query("DESCRIBE employees");
    $columns = [];
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        if ($row['Field'] === 'employee_number') {
            echo "<p>✅ employee_number sütunu mevcut</p>";
            echo "<p>Tip: " . $row['Type'] . "</p>";
            echo "<p>Null: " . $row['Null'] . "</p>";
            echo "<p>Default: " . ($row['Default'] ?: 'Yok') . "</p>";
            break;
        }
    }
    
    // Check for auto-generated EMPxxxx numbers
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE employee_number LIKE 'EMP%' AND company_id = ?");
    $stmt->execute([$companyId]);
    $empCount = $stmt->fetch()['count'];
    
    if ($empCount > 0) {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>⚠️ Otomatik Oluşturulan Numara Bulundu</h4>";
        echo "<p>$empCount personelde EMPxxxx formatında otomatik numara bulundu. Bu numaraları gerçek TC kimlik numaraları ile değiştirmeniz önerilir.</p>";
        echo "</div>";
    }
    
    echo "<p><a href='../admin/employee-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Personel Yönetimi</a>";
    echo "<a href='../admin/index.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Admin Panel</a></p>";
    
} catch (Exception $e) {
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Numarası Düzeltme - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        h2, h3, h4 { color: #333; }
        .success { color: #28a745; background: #d4edda; }
        .warning { color: #856404; background: #fff3cd; }
        .error { color: #721c24; background: #f8d7da; }
    </style>
</head>
<body>
</body>
</html>