<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔧 Company Login Debug Tool</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;} pre{background:#f5f5f5;padding:10px;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📊 Companies Table Structure Analysis</h2>";
    
    // Check companies table columns
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $companyColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse:collapse; margin:10px 0;'>";
    echo "<tr><th>Column Name</th><th>Type</th><th>Null</th><th>Default</th></tr>";
    
    $availableColumns = [];
    foreach ($companyColumns as $col) {
        $availableColumns[] = $col['Field'];
        echo "<tr>";
        echo "<td><strong>{$col['Field']}</strong></td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>🎯 Column Analysis:</h3>";
    echo "<ul>";
    echo "<li><strong>Company Name:</strong> ";
    if (in_array('company_name', $availableColumns)) {
        echo "<span class='success'>✅ company_name column found</span>";
    } elseif (in_array('name', $availableColumns)) {
        echo "<span class='success'>✅ name column found</span>";
    } else {
        echo "<span class='error'>❌ No name column found</span>";
    }
    echo "</li>";
    
    echo "<li><strong>Company Code:</strong> ";
    if (in_array('company_code', $availableColumns)) {
        echo "<span class='success'>✅ company_code column found</span>";
    } elseif (in_array('code', $availableColumns)) {
        echo "<span class='success'>✅ code column found</span>";
    } else {
        echo "<span class='info'>ℹ️ Will use id as company code</span>";
    }
    echo "</li>";
    
    echo "<li><strong>Status Field:</strong> ";
    if (in_array('is_active', $availableColumns)) {
        echo "<span class='success'>✅ is_active column found</span>";
    } elseif (in_array('status', $availableColumns)) {
        echo "<span class='success'>✅ status column found</span>";
    } else {
        echo "<span class='info'>ℹ️ No status column found</span>";
    }
    echo "</li>";
    echo "</ul>";
    
    // Test sample companies
    echo "<h2>🏢 Sample Companies</h2>";
    $stmt = $conn->query("SELECT * FROM companies LIMIT 3");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($companies) {
        echo "<table border='1' style='border-collapse:collapse; margin:10px 0;'>";
        echo "<tr>";
        foreach ($companies[0] as $key => $value) {
            echo "<th>$key</th>";
        }
        echo "</tr>";
        
        foreach ($companies as $company) {
            echo "<tr>";
            foreach ($company as $value) {
                echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='info'>ℹ️ No companies found in database</p>";
    }
    
    // Test users table
    echo "<h2>👥 Users Table Analysis</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM users");
    $userColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $userColumnNames = [];
    foreach ($userColumns as $col) {
        $userColumnNames[] = $col['Field'];
    }
    
    echo "<p><strong>User columns:</strong> " . implode(', ', $userColumnNames) . "</p>";
    
    // Sample users
    $stmt = $conn->query("SELECT id, email, company_id, is_active FROM users LIMIT 3");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($users) {
        echo "<table border='1' style='border-collapse:collapse; margin:10px 0;'>";
        echo "<tr><th>ID</th><th>Email</th><th>Company ID</th><th>Active</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>{$user['id']}</td>";
            echo "<td>{$user['email']}</td>";
            echo "<td>{$user['company_id']}</td>";
            echo "<td>" . ($user['is_active'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<div style='background:#f0f8ff;padding:15px;margin:20px 0;border-left:4px solid #007acc;'>";
    echo "<h3>🔧 Recommended Fix Applied</h3>";
    echo "<p>✅ Company login now uses separate queries to avoid column conflicts</p>";
    echo "<p>✅ Flexible field mapping supports different schema versions</p>";
    echo "<p>✅ Safe fallback values for missing columns</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Debug failed: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='../auth/company-login.php'>🏢 Test Company Login</a></p>";
?>