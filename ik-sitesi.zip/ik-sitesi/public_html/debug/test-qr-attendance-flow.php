<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🧪 QR Devam Takibi Akış Testi</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Find Selim or any employee
    echo "<h3>👤 Personel Arama</h3>";
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, employee_code 
        FROM employees 
        WHERE (first_name LIKE '%Selim%' OR last_name LIKE '%Selim%')
        LIMIT 1
    ");
    $stmt->execute();
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        // Use first available employee
        $stmt = $conn->query("SELECT id, first_name, last_name, employee_code FROM employees LIMIT 1");
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    if (!$employee) {
        throw new Exception("Test için personel bulunamadı");
    }
    
    $employeeId = $employee['id'];
    echo "<p>✅ Test personeli: {$employee['first_name']} {$employee['last_name']} (ID: {$employeeId})</p>";
    
    // Simulate login session
    session_start();
    $_SESSION['employee_id'] = $employeeId;
    $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
    
    echo "<p>✅ Session simüle edildi</p>";
    
    // Test the full QR attendance flow
    echo "<h3>🔄 QR Okuma Akışı Testi</h3>";
    
    // Step 1: Check QR locations
    $stmt = $conn->query("SELECT * FROM qr_locations WHERE is_active = 1 LIMIT 1");
    $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$qrLocation) {
        echo "<p style='color: orange;'>⚠️ QR lokasyon bulunamadı, oluşturuluyor...</p>";
        
        $stmt = $conn->prepare("
            INSERT INTO qr_locations (name, address, latitude, longitude, tolerance_meters, is_active, created_at)
            VALUES ('Test Ofis', 'Test Adres', 41.0082, 28.9784, 100, 1, NOW())
        ");
        $stmt->execute();
        $qrLocationId = $conn->lastInsertId();
        
        $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE id = ?");
        $stmt->execute([$qrLocationId]);
        $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<p>✅ Test QR lokasyon oluşturuldu</p>";
    }
    
    echo "<p>📍 QR Lokasyon: {$qrLocation['name']} (ID: {$qrLocation['id']})</p>";
    
    // Step 2: Simulate QR scan data
    $qrData = json_encode([
        'location_id' => $qrLocation['id'],
        'name' => $qrLocation['name'],
        'latitude' => $qrLocation['latitude'],
        'longitude' => $qrLocation['longitude'],
        'tolerance' => $qrLocation['tolerance_meters']
    ]);
    
    $_SESSION['qr_scan_data'] = $qrData;
    echo "<p>✅ QR scan data simüle edildi</p>";
    
    // Step 3: Test attendance record creation
    echo "<h4>💾 Devam Kaydı Oluşturma Testi</h4>";
    
    $currentTime = date('H:i:s');
    $currentDateTime = date('Y-m-d H:i:s');
    $today = date('Y-m-d');
    
    // Check current attendance records
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) = ?
    ");
    $stmt->execute([$employeeId, $today]);
    $existingCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<p>📊 Mevcut kayıt sayısı: {$existingCount}</p>";
    
    // Create test attendance record using direct SQL
    try {
        $stmt = $conn->prepare("
            INSERT INTO attendance_records (
                employee_id, qr_location_id, activity_type, 
                check_in_time, latitude, longitude, 
                notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            $employeeId,
            $qrLocation['id'],
            'work_in',
            $currentTime,
            $qrLocation['latitude'],
            $qrLocation['longitude'],
            'QR test kayıt - ' . date('Y-m-d H:i:s'),
            $currentDateTime
        ]);
        
        if ($result) {
            $insertId = $conn->lastInsertId();
            echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
            echo "<p><strong>✅ Attendance Record Başarıyla Oluşturuldu!</strong></p>";
            echo "<p>Kayıt ID: {$insertId}</p>";
            echo "<p>Personel ID: {$employeeId}</p>";
            echo "<p>Aktivite: work_in</p>";
            echo "<p>Zaman: {$currentTime}</p>";
            echo "<p>QR Lokasyon: {$qrLocation['name']}</p>";
            echo "</div>";
            
            // Verify the record
            $stmt = $conn->prepare("
                SELECT ar.*, ql.name as location_name 
                FROM attendance_records ar
                LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
                WHERE ar.id = ?
            ");
            $stmt->execute([$insertId]);
            $newRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($newRecord) {
                echo "<h4>🔍 Kaydedilen Veri Doğrulaması</h4>";
                echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
                echo "<tr><th>Alan</th><th>Değer</th></tr>";
                foreach ($newRecord as $field => $value) {
                    echo "<tr><td>{$field}</td><td>" . htmlspecialchars($value ?? 'NULL') . "</td></tr>";
                }
                echo "</table>";
            }
            
        } else {
            echo "<p style='color: red;'>❌ Attendance record oluşturulamadı</p>";
            $errorInfo = $stmt->errorInfo();
            echo "<p>SQL Hatası: " . $errorInfo[2] . "</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Attendance record hatası: " . $e->getMessage() . "</p>";
    }
    
    // Step 4: Test shift record update
    echo "<h4>📋 Vardiya Kaydı Güncelleme Testi</h4>";
    
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count FROM employee_shifts 
        WHERE employee_id = ? AND shift_date = ?
    ");
    $stmt->execute([$employeeId, $today]);
    $shiftCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($shiftCount == 0) {
        echo "<p style='color: orange;'>⚠️ Bugün için vardiya bulunamadı, oluşturuluyor...</p>";
        
        // Create default shift template if not exists
        $stmt = $conn->prepare("SELECT id FROM shift_templates WHERE name = 'Test Vardiya' LIMIT 1");
        $stmt->execute();
        $template = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$template) {
            $stmt = $conn->prepare("
                INSERT INTO shift_templates (name, start_time, end_time, break_duration, created_at)
                VALUES ('Test Vardiya', '09:00:00', '18:00:00', 60, NOW())
            ");
            $stmt->execute();
            $templateId = $conn->lastInsertId();
        } else {
            $templateId = $template['id'];
        }
        
        // Create employee shift
        $stmt = $conn->prepare("
            INSERT INTO employee_shifts (employee_id, shift_template_id, shift_date, status, created_at)
            VALUES (?, ?, ?, 'scheduled', NOW())
        ");
        $stmt->execute([$employeeId, $templateId, $today]);
        $shiftId = $conn->lastInsertId();
        
        echo "<p>✅ Test vardiya oluşturuldu (ID: {$shiftId})</p>";
    } else {
        echo "<p>✅ Mevcut vardiya bulundu</p>";
    }
    
    // Final status check
    echo "<h3>📈 Final Durum Kontrolü</h3>";
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) = ?
    ");
    $stmt->execute([$employeeId, $today]);
    $finalCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<p><strong>Bugünkü toplam devam kayıt sayısı: {$finalCount}</strong></p>";
    
    if ($finalCount > $existingCount) {
        echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center;'>";
        echo "<h2>🎉 TEST BAŞARILI!</h2>";
        echo "<p>QR devam takibi sistemi çalışıyor.</p>";
        echo "<p>Selim'in QR kod okutma işlemi artık kayıt oluşturacak.</p>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 20px; border-radius: 8px; text-align: center;'>";
        echo "<h2>❌ TEST BAŞARISIZ</h2>";
        echo "<p>Yeni kayıt oluşturulamadı.</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Test Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; font-size: 12px; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
</style>