<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$testResults = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🧪 Device Management Tests</h1>";
    
    // Test 1: Check if employee_devices table exists
    echo "<h2>Test 1: employee_devices Table Check</h2>";
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'employee_devices'");
        if ($stmt->rowCount() > 0) {
            echo "✅ employee_devices table exists<br>";
            $testResults[] = "PASS: employee_devices table exists";
            
            // Check columns
            $columns = $conn->query("SHOW COLUMNS FROM employee_devices")->fetchAll(PDO::FETCH_ASSOC);
            $columnNames = array_column($columns, 'Field');
            
            $requiredColumns = ['id', 'employee_id', 'device_fingerprint', 'last_seen_at'];
            $missingColumns = array_diff($requiredColumns, $columnNames);
            
            if (empty($missingColumns)) {
                echo "✅ All required columns exist: " . implode(', ', $columnNames) . "<br>";
                $testResults[] = "PASS: Required columns exist";
            } else {
                echo "❌ Missing columns: " . implode(', ', $missingColumns) . "<br>";
                $testResults[] = "FAIL: Missing columns - " . implode(', ', $missingColumns);
            }
        } else {
            echo "❌ employee_devices table does not exist<br>";
            $testResults[] = "FAIL: employee_devices table missing";
        }
    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: " . $e->getMessage();
    }
    
    // Test 2: Test main device query
    echo "<h2>Test 2: Main Device Query</h2>";
    try {
        $stmt = $conn->prepare("
            SELECT 
                ed.*,
                e.first_name,
                e.last_name,
                COALESCE(e.employee_number, CONCAT('EMP', LPAD(e.id, 4, '0'))) as employee_number,
                COALESCE(ed.last_seen_at, ed.created_at) as display_date
            FROM employee_devices ed
            JOIN employees e ON ed.employee_id = e.id
            WHERE e.company_id = 1
            ORDER BY COALESCE(ed.last_seen_at, ed.created_at) DESC
            LIMIT 3
        ");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "✅ Main device query works - got " . count($results) . " results<br>";
        foreach ($results as $row) {
            echo "- Device: {$row['device_fingerprint']}, Employee: {$row['first_name']} {$row['last_name']}<br>";
        }
        $testResults[] = "PASS: Main device query works";
    } catch (Exception $e) {
        echo "❌ Main device query failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Main device query - " . $e->getMessage();
    }
    
    // Test 3: Test statistics query
    echo "<h2>Test 3: Device Statistics Query</h2>";
    try {
        $stmt = $conn->prepare("
            SELECT 
                COUNT(*) as total_devices,
                COUNT(CASE WHEN ed.is_trusted = 1 THEN 1 END) as trusted_devices,
                COUNT(CASE WHEN COALESCE(ed.is_blocked, 0) = 1 THEN 1 END) as blocked_devices,
                COUNT(CASE WHEN COALESCE(ed.last_seen_at, ed.created_at) >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as active_24h
            FROM employee_devices ed
            JOIN employees e ON ed.employee_id = e.id
            WHERE e.company_id = 1
        ");
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "✅ Statistics query works<br>";
        echo "- Total Devices: {$stats['total_devices']}<br>";
        echo "- Trusted Devices: {$stats['trusted_devices']}<br>";
        echo "- Blocked Devices: {$stats['blocked_devices']}<br>";
        echo "- Active 24h: {$stats['active_24h']}<br>";
        $testResults[] = "PASS: Statistics query works";
    } catch (Exception $e) {
        echo "❌ Statistics query failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Statistics query - " . $e->getMessage();
    }
    
    // Test 4: Test device_records table compatibility
    echo "<h2>Test 4: Device Records Compatibility</h2>";
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'device_records'");
        if ($stmt->rowCount() > 0) {
            echo "✅ device_records table exists<br>";
            
            // Test compatibility query
            $stmt = $conn->prepare("
                SELECT 
                    COUNT(*) as total_records,
                    MAX(recorded_at) as latest_record
                FROM device_records 
                WHERE device_fingerprint IN (
                    SELECT DISTINCT device_fingerprint 
                    FROM employee_devices ed
                    JOIN employees e ON ed.employee_id = e.id
                    WHERE e.company_id = 1
                )
            ");
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo "✅ Device records compatibility works<br>";
            echo "- Total Records: {$result['total_records']}<br>";
            echo "- Latest Record: {$result['latest_record']}<br>";
            $testResults[] = "PASS: Device records compatibility";
        } else {
            echo "⚠️ device_records table doesn't exist<br>";
            $testResults[] = "WARNING: device_records table missing";
        }
    } catch (Exception $e) {
        echo "❌ Device records compatibility failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Device records - " . $e->getMessage();
    }
    
    echo "<h2>📋 Test Summary</h2>";
    foreach ($testResults as $result) {
        $status = substr($result, 0, 4);
        if ($status === 'PASS') {
            $color = 'green';
        } elseif ($status === 'FAIL') {
            $color = 'red';
        } else {
            $color = 'orange';
        }
        echo "<div style='color: $color;'>$result</div>";
    }
    
    $passCount = count(array_filter($testResults, fn($r) => substr($r, 0, 4) === 'PASS'));
    $totalCount = count($testResults);
    
    echo "<h3>Results: $passCount/$totalCount tests passed</h3>";
    
    if ($passCount === $totalCount) {
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "🎉 All tests passed! Device Management is working correctly.";
        echo "</div>";
    }

} catch (Exception $e) {
    echo "<h2>❌ Critical Error</h2>";
    echo "<p>Database connection failed: " . $e->getMessage() . "</p>";
}
?>

<div style="margin-top: 20px;">
    <a href="../super-admin/fix-critical-errors.php" style="background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px;">
        ← Back to Critical Errors
    </a>
    <a href="fix-device-columns.php" style="background: #6f42c1; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        📱 Device Column Fix
    </a>
    <a href="../admin/device-management.php" style="background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        🛡️ Device Management
    </a>
</div>