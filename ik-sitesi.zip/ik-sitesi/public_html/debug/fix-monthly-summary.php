<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/error-logger.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$message = '';
$messageType = '';
$diagnostics = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Diagnostics function
    function addDiagnostic($type, $title, $details) {
        global $diagnostics;
        $diagnostics[] = [
            'type' => $type,
            'title' => $title,
            'details' => $details
        ];
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix_action'])) {
        switch ($_POST['fix_action']) {
            case 'fix_monthly_summary_tables':
                $steps = [];
                
                // Step 1: Create shift_templates table
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS shift_templates (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            name VARCHAR(100) NOT NULL,
                            start_time TIME NOT NULL,
                            end_time TIME NOT NULL,
                            break_duration INT DEFAULT 0,
                            description TEXT,
                            is_active BOOLEAN DEFAULT TRUE,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
                        )
                    ");
                    $steps[] = "✅ shift_templates table created";
                    addDiagnostic('success', 'Table Created', 'shift_templates table created successfully');
                } catch (Exception $e) {
                    $steps[] = "⚠️ shift_templates table: " . $e->getMessage();
                    addDiagnostic('error', 'Table Creation Failed', $e->getMessage());
                }
                
                // Step 2: Check and add shift_template_id column to employee_shifts
                try {
                    $columnCheck = $conn->query("SHOW COLUMNS FROM employee_shifts LIKE 'shift_template_id'");
                    if ($columnCheck->rowCount() === 0) {
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT DEFAULT NULL");
                        $steps[] = "✅ shift_template_id column added to employee_shifts";
                        addDiagnostic('success', 'Column Added', 'shift_template_id column added to employee_shifts table');
                    } else {
                        $steps[] = "ℹ️ shift_template_id column already exists";
                        addDiagnostic('info', 'Column Exists', 'shift_template_id column already exists');
                    }
                } catch (Exception $e) {
                    $steps[] = "❌ Column add failed: " . $e->getMessage();
                    addDiagnostic('error', 'Column Addition Failed', $e->getMessage());
                }
                
                // Step 3: Create monthly_work_summary table if missing
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS monthly_work_summary (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            employee_id INT NOT NULL,
                            year INT NOT NULL,
                            month INT NOT NULL,
                            total_scheduled_hours DECIMAL(8,2) DEFAULT 0,
                            total_worked_hours DECIMAL(8,2) DEFAULT 0,
                            total_overtime_hours DECIMAL(8,2) DEFAULT 0,
                            total_break_hours DECIMAL(8,2) DEFAULT 0,
                            total_late_minutes INT DEFAULT 0,
                            total_early_leave_minutes INT DEFAULT 0,
                            days_present INT DEFAULT 0,
                            days_absent INT DEFAULT 0,
                            days_late INT DEFAULT 0,
                            days_early_leave INT DEFAULT 0,
                            calculated_salary DECIMAL(10,2) DEFAULT 0,
                            overtime_pay DECIMAL(10,2) DEFAULT 0,
                            penalty_amount DECIMAL(10,2) DEFAULT 0,
                            final_salary DECIMAL(10,2) DEFAULT 0,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            UNIQUE KEY unique_employee_month (employee_id, year, month),
                            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
                        )
                    ");
                    $steps[] = "✅ monthly_work_summary table created";
                    addDiagnostic('success', 'Summary Table', 'monthly_work_summary table created successfully');
                } catch (Exception $e) {
                    $steps[] = "⚠️ monthly_work_summary table: " . $e->getMessage();
                    addDiagnostic('error', 'Summary Table Failed', $e->getMessage());
                }
                
                // Step 4: Mark related errors as solved
                try {
                    $stmt = $conn->prepare("
                        UPDATE system_error_log 
                        SET status = 'solved', 
                            solution_notes = 'Monthly summary and shift management errors fixed - missing tables created',
                            solved_by = 'Monthly Summary Fix Tool',
                            solved_at = NOW()
                        WHERE (error_message LIKE '%shift_templates%' 
                        OR error_message LIKE '%monthly_work_summary%'
                        OR error_message LIKE '%Table%doesn\\'t exist%')
                        AND status = 'unsolved'
                    ");
                    $stmt->execute();
                    $fixedErrorCount = $stmt->rowCount();
                    $steps[] = "✅ " . $fixedErrorCount . " related errors marked as solved";
                    addDiagnostic('success', 'Error Resolution', $fixedErrorCount . ' errors marked as solved');
                } catch (Exception $e) {
                    $steps[] = "⚠️ Error marking: " . $e->getMessage();
                    addDiagnostic('warning', 'Error Marking Failed', $e->getMessage());
                }
                
                $message = "🔧 Monthly Summary Fix Completed:<br>" . implode('<br>', $steps);
                $messageType = "success";
                break;
                
            case 'test_monthly_summary':
                try {
                    // Test the monthly summary API
                    $currentMonth = date('n');
                    $currentYear = date('Y');
                    
                    // Check if we can access the API without errors
                    ob_start();
                    include '../api/calculate-monthly-summary.php';
                    $output = ob_get_clean();
                    
                    if (strpos($output, 'SQLSTATE') === false && strpos($output, 'Table') === false) {
                        $message = "✅ Monthly summary API test successful - no table errors detected";
                        $messageType = "success";
                        addDiagnostic('success', 'API Test', 'Monthly summary API working without table errors');
                    } else {
                        $message = "❌ Monthly summary API still has table errors";
                        $messageType = "error";
                        addDiagnostic('error', 'API Test Failed', 'Table errors still present in monthly summary');
                    }
                } catch (Exception $e) {
                    $message = "❌ Monthly summary test failed: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Test Failed', $e->getMessage());
                }
                break;
        }
    }
    
    // Diagnostic checks
    addDiagnostic('info', 'Database Connection', 'Connected successfully');
    
    // Check shift_templates table
    try {
        $tableCheck = $conn->query("SHOW TABLES LIKE 'shift_templates'");
        if ($tableCheck->rowCount() > 0) {
            addDiagnostic('success', 'shift_templates Table', 'Table exists');
            
            // Check row count
            $countStmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
            $count = $countStmt->fetch(PDO::FETCH_ASSOC)['count'];
            addDiagnostic('info', 'Shift Templates Count', $count . ' templates found');
        } else {
            addDiagnostic('error', 'shift_templates Table', 'Table does not exist');
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'Table Check Failed', $e->getMessage());
    }
    
    // Check monthly_work_summary table
    try {
        $tableCheck = $conn->query("SHOW TABLES LIKE 'monthly_work_summary'");
        if ($tableCheck->rowCount() > 0) {
            addDiagnostic('success', 'monthly_work_summary Table', 'Table exists');
        } else {
            addDiagnostic('warning', 'monthly_work_summary Table', 'Table does not exist');
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'Summary Table Check Failed', $e->getMessage());
    }
    
    // Check employee_shifts table structure
    try {
        $columnCheck = $conn->query("SHOW COLUMNS FROM employee_shifts LIKE 'shift_template_id'");
        if ($columnCheck->rowCount() > 0) {
            addDiagnostic('success', 'shift_template_id Column', 'Column exists in employee_shifts table');
        } else {
            addDiagnostic('error', 'shift_template_id Column', 'Column missing from employee_shifts table');
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'Column Check Failed', $e->getMessage());
    }
    
    // Check recent monthly summary errors
    try {
        $stmt = $conn->query("
            SELECT COUNT(*) as error_count 
            FROM system_error_log 
            WHERE (error_message LIKE '%shift_templates%' 
            OR error_message LIKE '%monthly_work_summary%'
            OR error_message LIKE '%Table%doesn\\'t exist%')
            AND status = 'unsolved'
            AND DATE(created_at) >= CURDATE() - INTERVAL 1 DAY
        ");
        $errorCount = $stmt->fetch(PDO::FETCH_ASSOC)['error_count'];
        
        if ($errorCount > 0) {
            addDiagnostic('error', 'Recent Errors', $errorCount . ' unsolved monthly summary errors in last 24 hours');
        } else {
            addDiagnostic('success', 'Recent Errors', 'No recent monthly summary errors');
        }
    } catch (Exception $e) {
        addDiagnostic('warning', 'Error Check', 'Could not check recent errors: ' . $e->getMessage());
    }

} catch (Exception $e) {
    $message = "Database connection failed: " . $e->getMessage();
    $messageType = "error";
    addDiagnostic('error', 'Critical Error', $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Summary Fix - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">📊 Monthly Summary Fix</h1>
                        <p class="text-gray-600 mt-1">Aylık çalışma özeti hatalarını düzeltin</p>
                    </div>
                    <a href="../super-admin/fix-critical-errors.php" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
                        ← Critical Errors
                    </a>
                </div>
            </div>

            <!-- Message -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg border <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border-green-200' : ($messageType === 'error' ? 'bg-red-100 text-red-800 border-red-200' : 'bg-blue-100 text-blue-800 border-blue-200'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Quick Fixes -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Quick Fixes</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <!-- Fix Monthly Summary Tables -->
                    <div class="border border-green-200 rounded-lg p-4 bg-green-50">
                        <h3 class="font-bold text-green-800 mb-2">📊 Monthly Summary Fix</h3>
                        <p class="text-sm text-green-600 mb-3">
                            Eksik shift_templates ve monthly_work_summary tablolarını oluştur.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="fix_monthly_summary_tables" 
                                    class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm">
                                📊 Tabloları Oluştur
                            </button>
                        </form>
                    </div>

                    <!-- Test Monthly Summary -->
                    <div class="border border-blue-200 rounded-lg p-4 bg-blue-50">
                        <h3 class="font-bold text-blue-800 mb-2">🧪 Test Monthly Summary</h3>
                        <p class="text-sm text-blue-600 mb-3">
                            Aylık çalışma özeti API'sini test et.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="test_monthly_summary" 
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                                🧪 API Test Et
                            </button>
                        </form>
                    </div>

                    <!-- Direct Links -->
                    <div class="border border-purple-200 rounded-lg p-4 bg-purple-50">
                        <h3 class="font-bold text-purple-800 mb-2">🔗 Direct Access</h3>
                        <p class="text-sm text-purple-600 mb-3">
                            Aylık özet hesaplama sayfasına direkt git.
                        </p>
                        <a href="../api/calculate-monthly-summary.php" target="_blank"
                           class="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm inline-block text-center">
                            📊 Monthly Summary
                        </a>
                    </div>

                    <!-- Additional Fix Tools -->
                    <div class="border border-orange-200 rounded-lg p-4 bg-orange-50">
                        <h3 class="font-bold text-orange-800 mb-2">🔧 Additional Tools</h3>
                        <p class="text-sm text-orange-600 mb-3">
                            Diğer shift management fix araçları.
                        </p>
                        <a href="fix-shift-management.php"
                           class="w-full bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm inline-block text-center">
                            ⚡ Shift Management
                        </a>
                    </div>
                </div>
            </div>

            <!-- Diagnostics -->
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🔍 Diagnostic Report</h2>
                
                <?php if (empty($diagnostics)): ?>
                    <p class="text-gray-500">No diagnostics available. Run a diagnostic check.</p>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($diagnostics as $diagnostic): ?>
                            <div class="flex items-start space-x-3 p-3 rounded-lg border 
                                <?php 
                                echo $diagnostic['type'] === 'success' ? 'bg-green-50 border-green-200' : 
                                    ($diagnostic['type'] === 'error' ? 'bg-red-50 border-red-200' : 
                                    ($diagnostic['type'] === 'warning' ? 'bg-yellow-50 border-yellow-200' : 'bg-blue-50 border-blue-200')); 
                                ?>">
                                <div class="flex-shrink-0">
                                    <?php 
                                    echo $diagnostic['type'] === 'success' ? '✅' : 
                                        ($diagnostic['type'] === 'error' ? '❌' : 
                                        ($diagnostic['type'] === 'warning' ? '⚠️' : 'ℹ️')); 
                                    ?>
                                </div>
                                <div class="flex-grow">
                                    <h4 class="font-semibold text-gray-900"><?php echo htmlspecialchars($diagnostic['title']); ?></h4>
                                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($diagnostic['details']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>