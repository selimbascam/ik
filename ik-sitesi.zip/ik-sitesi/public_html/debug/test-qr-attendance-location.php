<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$testResults = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🧪 QR Attendance Location Tests</h1>";
    
    // Test 1: Check if attendance_records table structure
    echo "<h2>Test 1: attendance_records Table Structure Check</h2>";
    try {
        $columns = $conn->query("SHOW COLUMNS FROM attendance_records")->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        
        echo "📋 All columns in attendance_records:<br>";
        foreach ($columnNames as $column) {
            echo "- " . $column . "<br>";
        }
        
        $requiredColumns = ['location', 'qr_location_id', 'location_name'];
        $existingColumns = array_intersect($requiredColumns, $columnNames);
        $missingColumns = array_diff($requiredColumns, $columnNames);
        
        if (!empty($existingColumns)) {
            echo "✅ Existing location columns: " . implode(', ', $existingColumns) . "<br>";
            $testResults[] = "PASS: Location columns exist - " . implode(', ', $existingColumns);
        }
        if (!empty($missingColumns)) {
            echo "❌ Missing location columns: " . implode(', ', $missingColumns) . "<br>";
            $testResults[] = "FAIL: Missing location columns - " . implode(', ', $missingColumns);
        }
        if (empty($missingColumns)) {
            $testResults[] = "PASS: attendance_records table structure correct";
        }
    } catch (Exception $e) {
        echo "❌ attendance_records table error: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: attendance_records - " . $e->getMessage();
    }
    
    // Test 2: Test the problematic query from employee/attendance-records.php
    echo "<h2>Test 2: Employee Attendance Records Query</h2>";
    try {
        $stmt = $conn->prepare("
            SELECT ar.*, COALESCE(ar.location, ar.location_name, 'Bilinmeyen') as location_name, 'other' as location_type
            FROM attendance_records ar
            WHERE ar.employee_id = 1
            LIMIT 5
        ");
        $stmt->execute();
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "✅ Employee attendance records query works - got " . count($records) . " records<br>";
        if (!empty($records)) {
            echo "Sample record:<br>";
            $sample = $records[0];
            foreach (['id', 'employee_id', 'location_name', 'date'] as $field) {
                if (isset($sample[$field])) {
                    echo "- $field: " . $sample[$field] . "<br>";
                }
            }
        }
        $testResults[] = "PASS: Employee attendance records query works";
    } catch (Exception $e) {
        echo "❌ Employee attendance records query failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Employee attendance query - " . $e->getMessage();
    }
    
    // Test 3: Test QR location-related queries
    echo "<h2>Test 3: QR Location Integration Test</h2>";
    try {
        $stmt = $conn->prepare("
            SELECT 
                ar.id,
                ar.employee_id,
                COALESCE(ar.location, ar.location_name, 'Bilinmeyen') as location_name,
                ql.name as qr_location_name,
                ar.activity_type
            FROM attendance_records ar
            LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
            WHERE ar.employee_id = 1
            ORDER BY ar.created_at DESC
            LIMIT 3
        ");
        $stmt->execute();
        $qrRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "✅ QR location integration query works - got " . count($qrRecords) . " records<br>";
        foreach ($qrRecords as $record) {
            echo "- Record ID: {$record['id']}, Location: {$record['location_name']}, QR Location: " . ($record['qr_location_name'] ?? 'None') . "<br>";
        }
        $testResults[] = "PASS: QR location integration works";
    } catch (Exception $e) {
        echo "❌ QR location integration test failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: QR location integration - " . $e->getMessage();
    }
    
    // Test 4: Test attendance records with location data
    echo "<h2>Test 4: Attendance Records With Location Data</h2>";
    try {
        // Check if we have any attendance records with location data
        $stmt = $conn->prepare("
            SELECT 
                COUNT(*) as total_records,
                COUNT(CASE WHEN ar.location IS NOT NULL THEN 1 END) as with_location,
                COUNT(CASE WHEN ar.location_name IS NOT NULL THEN 1 END) as with_location_name,
                COUNT(CASE WHEN ar.qr_location_id IS NOT NULL THEN 1 END) as with_qr_location
            FROM attendance_records ar
        ");
        $stmt->execute();
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "📊 Attendance Records Statistics:<br>";
        echo "- Total records: " . $stats['total_records'] . "<br>";
        echo "- Records with location: " . ($stats['with_location'] ?? 0) . "<br>";
        echo "- Records with location_name: " . ($stats['with_location_name'] ?? 0) . "<br>";
        echo "- Records with qr_location_id: " . ($stats['with_qr_location'] ?? 0) . "<br>";
        
        $testResults[] = "PASS: Location data statistics retrieved";
    } catch (Exception $e) {
        echo "❌ Location data statistics failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Location data statistics - " . $e->getMessage();
    }
    
    // Test 5: Test INSERT with location data
    echo "<h2>Test 5: INSERT Test With Location Data</h2>";
    try {
        // Try to insert a test record with location data
        $stmt = $conn->prepare("
            INSERT IGNORE INTO attendance_records 
            (employee_id, activity_type, location_name, qr_location_id, date) 
            VALUES (1, 'work_in', 'Test Location', 1, CURDATE())
        ");
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            echo "✅ INSERT with location data successful<br>";
            $testResults[] = "PASS: INSERT with location data works";
        } else {
            echo "ℹ️ INSERT ignored (record may already exist)<br>";
            $testResults[] = "INFO: INSERT ignored (duplicate)";
        }
    } catch (Exception $e) {
        echo "❌ INSERT with location data failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: INSERT with location - " . $e->getMessage();
    }
    
    echo "<h2>📋 Test Summary</h2>";
    foreach ($testResults as $result) {
        $status = substr($result, 0, 4);
        if ($status === 'PASS') {
            $color = 'green';
        } elseif ($status === 'FAIL') {
            $color = 'red';
        } elseif ($status === 'INFO') {
            $color = 'blue';
        } else {
            $color = 'orange';
        }
        echo "<div style='color: $color;'>$result</div>";
    }
    
    $passCount = count(array_filter($testResults, fn($r) => substr($r, 0, 4) === 'PASS'));
    $totalTests = count(array_filter($testResults, fn($r) => in_array(substr($r, 0, 4), ['PASS', 'FAIL'])));
    
    echo "<h3>Results: $passCount/$totalTests tests passed</h3>";
    
    if ($passCount === $totalTests && $totalTests > 0) {
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "🎉 All tests passed! QR Attendance Location system is working correctly.";
        echo "</div>";
    }

} catch (Exception $e) {
    echo "<h2>❌ Critical Error</h2>";
    echo "<p>Database connection failed: " . $e->getMessage() . "</p>";
}
?>

<div style="margin-top: 20px;">
    <a href="../super-admin/fix-critical-errors.php" style="background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px;">
        ← Back to Critical Errors
    </a>
    <a href="fix-qr-attendance-location.php" style="background: #dc3545; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        📱 QR Attendance Location Fix
    </a>
    <a href="../employee/attendance-records.php" style="background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        📊 Employee Attendance Records
    </a>
</div>