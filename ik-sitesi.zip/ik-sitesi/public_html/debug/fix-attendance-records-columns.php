<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔧 Attendance Records Sütun Düzeltmesi</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();

    // Mevcut tablo yapısını kontrol et
    echo "<h3>📊 Mevcut Tablo Yapısı</h3>";
    $stmt = $conn->query("DESCRIBE attendance_records");
    $currentColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
    echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Varsayılan</th></tr>";
    foreach ($currentColumns as $col) {
        echo "<tr>";
        echo "<td>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Gerekli sütunları tanımla
    $requiredColumns = [
        'latitude' => 'DECIMAL(10,8) NULL COMMENT "GPS Enlem"',
        'longitude' => 'DECIMAL(11,8) NULL COMMENT "GPS Boylam"',
        'qr_location_id' => 'INT(11) NULL COMMENT "QR Lokasyon ID"',
        'activity_type' => 'VARCHAR(50) NULL DEFAULT "work_in" COMMENT "Aktivite türü"',
        'check_in_time' => 'TIME NULL COMMENT "Giriş saati"',
        'check_out_time' => 'TIME NULL COMMENT "Çıkış saati"',
        'notes' => 'TEXT NULL COMMENT "Notlar"'
    ];

    // Eksik sütunları tespit et
    $existingColumnNames = array_column($currentColumns, 'Field');
    $missingColumns = [];
    
    foreach ($requiredColumns as $colName => $colDef) {
        if (!in_array($colName, $existingColumnNames)) {
            $missingColumns[] = [$colName, $colDef];
        }
    }

    echo "<h3>⚠️ Eksik Sütun Analizi</h3>";
    if (empty($missingColumns)) {
        echo "<p style='color: green;'>✅ Tüm gerekli sütunlar mevcut!</p>";
    } else {
        echo "<p style='color: orange;'>📋 Eklenecek sütunlar: " . count($missingColumns) . "</p>";
        echo "<ul>";
        foreach ($missingColumns as [$name, $def]) {
            echo "<li><strong>$name:</strong> $def</li>";
        }
        echo "</ul>";
    }

    // Eksik sütunları ekle
    if (!empty($missingColumns)) {
        echo "<h3>🔧 Sütun Ekleme İşlemleri</h3>";
        
        foreach ($missingColumns as [$colName, $colDef]) {
            try {
                $sql = "ALTER TABLE attendance_records ADD COLUMN $colName $colDef";
                $conn->exec($sql);
                echo "<p style='color: green;'>✅ $colName sütunu başarıyla eklendi</p>";
            } catch (Exception $e) {
                echo "<p style='color: red;'>❌ $colName sütunu eklenemedi: " . $e->getMessage() . "</p>";
            }
        }
    }

    // Güncellenmiş tablo yapısını göster
    echo "<h3>📊 Güncellenmiş Tablo Yapısı</h3>";
    $stmt = $conn->query("DESCRIBE attendance_records");
    $updatedColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
    echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Varsayılan</th><th>Açıklama</th></tr>";
    foreach ($updatedColumns as $col) {
        $isNew = !in_array($col['Field'], $existingColumnNames);
        $rowStyle = $isNew ? "background-color: #d4edda;" : "";
        echo "<tr style='$rowStyle'>";
        echo "<td>" . ($isNew ? "🆕 " : "") . "{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "<td>{$col['Comment']}</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Test INSERT işlemi
    echo "<h3>🧪 Test INSERT İşlemi</h3>";
    try {
        $testStmt = $conn->prepare("
            INSERT INTO attendance_records 
            (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        // Test verisi (gerçek veri olmayacak)
        $testData = [
            999999, // employee_id (test)
            1,      // qr_location_id
            'test', // activity_type
            '12:00:00', // check_in_time
            41.0082, // latitude (İstanbul)
            28.9784, // longitude (İstanbul)
            'Test kayıt - silinecek', // notes
            date('Y-m-d H:i:s') // created_at
        ];
        
        $testStmt->execute($testData);
        $testId = $conn->lastInsertId();
        
        echo "<p style='color: green;'>✅ Test INSERT başarılı! Record ID: $testId</p>";
        
        // Test kaydını sil
        $deleteStmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
        $deleteStmt->execute([$testId]);
        echo "<p style='color: blue;'>🗑️ Test kayıt temizlendi</p>";
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Test INSERT hatası: " . $e->getMessage() . "</p>";
    }

    // QR lokasyonları kontrol et
    echo "<h3>📍 QR Lokasyonları Kontrolü</h3>";
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations WHERE is_active = 1");
        $locationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($locationCount > 0) {
            echo "<p style='color: green;'>✅ $locationCount aktif QR lokasyonu mevcut</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ Aktif QR lokasyonu bulunamadı</p>";
            
            // Örnek lokasyon oluştur
            try {
                $stmt = $conn->prepare("
                    INSERT INTO qr_locations (name, description, latitude, longitude, is_active, company_id, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    'Ana Giriş',
                    'Şirket ana giriş kapısı',
                    41.0082,
                    28.9784,
                    1,
                    1,
                    date('Y-m-d H:i:s')
                ]);
                echo "<p style='color: green;'>✅ Örnek QR lokasyonu oluşturuldu</p>";
            } catch (Exception $e) {
                echo "<p style='color: red;'>❌ QR lokasyon oluşturulamadı: " . $e->getMessage() . "</p>";
            }
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ QR lokasyon kontrolü hatası: " . $e->getMessage() . "</p>";
    }

    echo "<h3>🎉 Düzeltme Tamamlandı</h3>";
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>✅ Veritabanı Şeması Düzeltildi!</h2>";
    echo "<p>Artık QR kod okutma sistemi latitude/longitude hatası vermeyecek.</p>";
    echo "<p><strong>Test etmek için:</strong> <a href='../employee/qr-unified.php'>QR Kod Okut</a></p>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ Veritabanı Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>