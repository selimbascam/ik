<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔍 Password Column Investigation</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📋 Companies Table Structure</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse:collapse;'>";
    echo "<tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    $hasPassword = false;
    $passwordColumns = [];
    
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td><strong>{$col['Field']}</strong></td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Key']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "<td>{$col['Extra']}</td>";
        echo "</tr>";
        
        // Look for password-related columns
        if (stripos($col['Field'], 'password') !== false || 
            stripos($col['Field'], 'pass') !== false ||
            stripos($col['Field'], 'pwd') !== false) {
            $passwordColumns[] = $col['Field'];
            $hasPassword = true;
        }
    }
    echo "</table>";
    
    if ($hasPassword) {
        echo "<p class='success'>✅ Password columns found: " . implode(', ', $passwordColumns) . "</p>";
    } else {
        echo "<p class='error'>❌ No password column found in companies table</p>";
        
        echo "<h2>🔧 Solution: Add Password Column</h2>";
        echo "<p>We need to add a password column to the companies table or check if there's a separate authentication method.</p>";
        
        // Check if there are any admin users for this company
        echo "<h3>🔍 Check for Admin Users</h3>";
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
        $stmt->execute(['zeynep@szb.com.tr']);
        $adminUser = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($adminUser) {
            echo "<p class='success'>✅ Admin user found in users table!</p>";
            echo "<pre>" . print_r($adminUser, true) . "</pre>";
        } else {
            echo "<p class='info'>ℹ️ No admin user found. We'll create a password column for companies.</p>";
            
            // Add password column
            try {
                $conn->exec("ALTER TABLE companies ADD COLUMN password VARCHAR(255) DEFAULT NULL");
                echo "<p class='success'>✅ Password column added to companies table</p>";
                
                // Set default password for the test company
                $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE email = ?");
                $stmt->execute([md5('Abc123456'), 'zeynep@szb.com.tr']);
                echo "<p class='success'>✅ Default password set for zeynep@szb.com.tr (MD5 hash)</p>";
                
            } catch (Exception $e) {
                echo "<p class='error'>❌ Error adding password column: " . $e->getMessage() . "</p>";
            }
        }
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='test-login-fix.php'>🔄 Re-test Login</a> | <a href='../auth/company-login.php'>🔙 Try Login Again</a></p>";
?>