<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔧 Employee Login Gelişmiş Test</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;} pre{background:#f5f5f5;padding:10px;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📊 Companies Tablo Yapısı</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $companyColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse:collapse; margin:10px 0;'>";
    echo "<tr><th>Sütun</th><th>Tür</th><th>Varsayılan</th></tr>";
    
    $availableColumns = [];
    foreach ($companyColumns as $col) {
        $availableColumns[] = $col['Field'];
        echo "<tr>";
        echo "<td><strong>{$col['Field']}</strong></td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Determine correct fields
    $companyNameField = 'id';
    $companyCodeField = 'id';
    
    if (in_array('company_name', $availableColumns)) {
        $companyNameField = 'company_name';
    } elseif (in_array('name', $availableColumns)) {
        $companyNameField = 'name';
    }
    
    if (in_array('company_code', $availableColumns)) {
        $companyCodeField = 'company_code';
    }
    
    echo "<h3>🎯 Kullanılacak Alanlar:</h3>";
    echo "<p><strong>Company Name:</strong> $companyNameField</p>";
    echo "<p><strong>Company Code:</strong> $companyCodeField</p>";
    
    // Test correct SQL
    $testSQL = "
        SELECT e.id, e.first_name, e.last_name, e.email, e.employee_code, 
               e.company_id, 
               c.{$companyNameField} as company_name, 
               c.{$companyCodeField} as company_code
        FROM employees e 
        JOIN companies c ON e.company_id = c.id 
        WHERE e.is_active = TRUE
        LIMIT 3
    ";
    
    echo "<h2>🧪 Test SQL Sorgusu:</h2>";
    echo "<pre>" . htmlspecialchars($testSQL) . "</pre>";
    
    try {
        $stmt = $conn->query($testSQL);
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($employees) {
            echo "<p class='success'>✅ SQL sorgusu başarılı! Bulunan personel:</p>";
            echo "<table border='1' style='border-collapse:collapse; margin:10px 0;'>";
            echo "<tr><th>ID</th><th>İsim</th><th>Employee Code</th><th>Company Name</th></tr>";
            foreach ($employees as $emp) {
                echo "<tr>";
                echo "<td>{$emp['id']}</td>";
                echo "<td>{$emp['first_name']} {$emp['last_name']}</td>";
                echo "<td><strong>{$emp['employee_code']}</strong></td>";
                echo "<td>{$emp['company_name']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='info'>ℹ️ Aktif personel bulunamadı</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ SQL hatası: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Veritabanı bağlantı hatası: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='../auth/employee-login.php'>← Employee Login Test</a></p>";
?>