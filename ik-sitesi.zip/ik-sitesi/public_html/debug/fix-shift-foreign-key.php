<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔧 Shift Foreign Key Constraint Düzeltme</h2>";
    echo "<hr>";
    
    // 1. Check current table structure
    echo "<h3>📊 Mevcut Tablo Yapısı Kontrolü</h3>";
    
    // Check if shifts table exists
    $checkShiftsTable = $conn->query("SHOW TABLES LIKE 'shifts'");
    $shiftsExists = $checkShiftsTable->rowCount() > 0;
    echo "<p>shifts tablosu: " . ($shiftsExists ? "✅ Mevcut" : "❌ Yok") . "</p>";
    
    // Check if shift_templates table exists
    $checkTemplatesTable = $conn->query("SHOW TABLES LIKE 'shift_templates'");
    $templatesExists = $checkTemplatesTable->rowCount() > 0;
    echo "<p>shift_templates tablosu: " . ($templatesExists ? "✅ Mevcut" : "❌ Yok") . "</p>";
    
    // Check employee_shifts structure
    $checkEmployeeShifts = $conn->query("SHOW TABLES LIKE 'employee_shifts'");
    $employeeShiftsExists = $checkEmployeeShifts->rowCount() > 0;
    echo "<p>employee_shifts tablosu: " . ($employeeShiftsExists ? "✅ Mevcut" : "❌ Yok") . "</p>";
    
    if ($employeeShiftsExists) {
        $result = $conn->query("DESCRIBE employee_shifts");
        echo "<h4>employee_shifts tablo yapısı:</h4>";
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . $row['Field'] . "</td>";
            echo "<td>" . $row['Type'] . "</td>";
            echo "<td>" . $row['Null'] . "</td>";
            echo "<td>" . $row['Key'] . "</td>";
            echo "<td>" . $row['Default'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Check constraints
        $constraints = $conn->query("
            SELECT 
                CONSTRAINT_NAME,
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'employee_shifts'
            AND REFERENCED_TABLE_NAME IS NOT NULL
        ");
        
        echo "<h4>Foreign Key Constraints:</h4>";
        if ($constraints->rowCount() > 0) {
            echo "<table border='1' style='border-collapse: collapse;'>";
            echo "<tr><th>Constraint</th><th>Column</th><th>References Table</th><th>References Column</th></tr>";
            while ($row = $constraints->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . $row['CONSTRAINT_NAME'] . "</td>";
                echo "<td>" . $row['COLUMN_NAME'] . "</td>";
                echo "<td>" . $row['REFERENCED_TABLE_NAME'] . "</td>";
                echo "<td>" . $row['REFERENCED_COLUMN_NAME'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>❌ Foreign key constraint bulunamadı</p>";
        }
    }
    
    echo "<hr>";
    echo "<h3>🔧 Düzeltme İşlemleri</h3>";
    
    // Fix 1: Drop problematic foreign key constraint if it exists
    try {
        $conn->exec("ALTER TABLE employee_shifts DROP FOREIGN KEY employee_shifts_ibfk_3");
        echo "<p>✅ Problemli foreign key constraint silindi (employee_shifts_ibfk_3)</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ employee_shifts_ibfk_3 constraint zaten mevcut değil</p>";
    }
    
    // Fix 2: Update employee_shifts table structure to use shift_template_id correctly
    try {
        // Check if shift_id column exists
        $result = $conn->query("SHOW COLUMNS FROM employee_shifts LIKE 'shift_id'");
        if ($result->rowCount() > 0) {
            // Drop shift_id column if it exists
            $conn->exec("ALTER TABLE employee_shifts DROP COLUMN shift_id");
            echo "<p>✅ shift_id sütunu silindi</p>";
        }
    } catch (Exception $e) {
        echo "<p>ℹ️ shift_id sütunu zaten mevcut değil</p>";
    }
    
    // Fix 3: Ensure shift_template_id column exists and has proper foreign key
    try {
        $result = $conn->query("SHOW COLUMNS FROM employee_shifts LIKE 'shift_template_id'");
        if ($result->rowCount() == 0) {
            // Add shift_template_id column
            $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT");
            echo "<p>✅ shift_template_id sütunu eklendi</p>";
        }
        
        // Ensure shift_templates table exists with proper structure
        if (!$templatesExists) {
            $conn->exec("
                CREATE TABLE shift_templates (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    start_time TIME NOT NULL,
                    end_time TIME NOT NULL,
                    break_duration INT DEFAULT 60,
                    is_active BOOLEAN DEFAULT 1,
                    color_code VARCHAR(7) DEFAULT '#3B82F6',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            echo "<p>✅ shift_templates tablosu oluşturuldu</p>";
            
            // Add default shift templates
            $conn->exec("
                INSERT INTO shift_templates (name, start_time, end_time, break_duration, color_code) VALUES
                ('Sabah Vardiyası', '09:30:00', '19:30:00', 60, '#3B82F6'),
                ('Gece Vardiyası', '22:00:00', '08:00:00', 60, '#7C3AED'),
                ('Öğle Vardiyası', '13:00:00', '23:00:00', 60, '#059669')
            ");
            echo "<p>✅ Varsayılan vardiya şablonları eklendi</p>";
        }
        
        // Add proper foreign key constraint
        try {
            $conn->exec("
                ALTER TABLE employee_shifts 
                ADD CONSTRAINT fk_employee_shifts_template 
                FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
            ");
            echo "<p>✅ Doğru foreign key constraint eklendi (shift_template_id → shift_templates.id)</p>";
        } catch (Exception $e) {
            echo "<p>ℹ️ Foreign key constraint zaten mevcut: " . $e->getMessage() . "</p>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ Shift template düzeltme hatası: " . $e->getMessage() . "</p>";
    }
    
    // Fix 4: Update any existing records that might have invalid references
    try {
        // Get default shift template ID
        $stmt = $conn->query("SELECT id FROM shift_templates WHERE start_time = '09:30:00' AND end_time = '19:30:00' LIMIT 1");
        $template = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($template) {
            $defaultTemplateId = $template['id'];
            
            // Update any records with NULL shift_template_id
            $stmt = $conn->prepare("UPDATE employee_shifts SET shift_template_id = ? WHERE shift_template_id IS NULL");
            $stmt->execute([$defaultTemplateId]);
            $updatedCount = $stmt->rowCount();
            
            if ($updatedCount > 0) {
                echo "<p>✅ $updatedCount kayıt varsayılan vardiya şablonu ile güncellendi</p>";
            }
        }
    } catch (Exception $e) {
        echo "<p>❌ Kayıt güncelleme hatası: " . $e->getMessage() . "</p>";
    }
    
    echo "<hr>";
    echo "<h3>✅ Düzeltme Tamamlandı</h3>";
    echo "<p><strong>Yapılan işlemler:</strong></p>";
    echo "<ul>";
    echo "<li>Problemli shift_id foreign key constraint silindi</li>";
    echo "<li>shift_id sütunu kaldırıldı (varsa)</li>";
    echo "<li>shift_template_id sütunu eklendi (yoksa)</li>";
    echo "<li>shift_templates tablosu oluşturuldu (yoksa)</li>";
    echo "<li>Doğru foreign key constraint eklendi</li>";
    echo "<li>Mevcut kayıtlar güncellendi</li>";
    echo "</ul>";
    
    echo "<h3>🎯 Sonraki Adımlar</h3>";
    echo "<p>Artık vardiya atamaları shift_templates tablosunu kullanacak. Vardiya ataması yaparken shift_template_id kullanın.</p>";
    
    echo "<p><a href='../admin/index.php' style='background: #3B82F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>← Admin Panel'e Dön</a></p>";
    
} catch (Exception $e) {
    echo "<h2>❌ Hata</h2>";
    echo "<p>Düzeltme işlemi sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "<p><strong>Hata detayları:</strong> " . $e->getTraceAsString() . "</p>";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift Foreign Key Düzeltme - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        table { width: 100%; margin: 10px 0; }
        th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
        th { background-color: #f2f2f2; }
        h2, h3, h4 { color: #333; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .info { color: #17a2b8; }
    </style>
</head>
<body>
</body>
</html>