<?php
session_start();
require_once '../includes/config.php';

// QR Real Debug Log Görüntüleyici
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Gerçek Debug Logları - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .log-entry {
            font-family: 'Courier New', monospace;
            font-size: 12px;
        }
        .debug-qr { color: #3b82f6; }
        .error-log { color: #ef4444; }
        .master-qr { color: #10b981; }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <div class="bg-white rounded-lg shadow p-6">
            <h1 class="text-2xl font-bold mb-4">🔍 QR Kod Gerçek Debug Logları</h1>
            
            <div class="mb-4 flex gap-2">
                <button id="refreshBtn" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                    🔄 Yenile
                </button>
                <button id="clearBtn" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                    🗑️ Temizle
                </button>
                <a href="../employee/qr-attendance-master.php" target="_blank" class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
                    🔗 QR Okuyucuyu Aç
                </a>
            </div>

            <div id="status" class="mb-4 p-3 bg-gray-50 rounded">
                <strong>Debug Status:</strong> QR kod okutmaya hazır
            </div>

            <div id="logContainer" class="bg-black text-green-400 p-4 rounded h-96 overflow-y-auto log-entry">
                <div class="text-gray-500">Manuel log dosyası kontrol ediliyor...</div>
            </div>
        </div>

        <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="bg-white p-4 rounded shadow">
                <h3 class="font-bold mb-2">📊 Test QR Kodları</h3>
                <ul class="text-sm">
                    <li><strong>Giriş:</strong> QR içeriği "1" (work_start)</li>
                    <li><strong>Çıkış:</strong> QR içeriği "2" (work_end)</li> 
                    <li><strong>Mola:</strong> QR içeriği "3" (break toggle)</li>
                </ul>
            </div>
            <div class="bg-white p-4 rounded shadow">
                <h3 class="font-bold mb-2">🎯 Beklenen Loglar</h3>
                <ul class="text-sm">
                    <li>Master QR DEBUG: Raw QR Code</li>
                    <li>Master QR DEBUG: LocationID, Type</li>
                    <li>Master QR DEBUG: Final activityType</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        let refreshInterval;

        // Manuel log dosyasını oku
        async function loadLogs() {
            try {
                const response = await fetch('qr-debug-api.php?action=get_logs&last_size=0');
                const data = await response.json();
                
                const container = document.getElementById('logContainer');
                container.innerHTML = '';
                
                if (data.success) {
                    // Debug bilgilerini göster
                    if (data.debug_info) {
                        addLogLine('=== SİSTEM BİLGİLERİ ===', 'system');
                        addLogLine('PHP Error Log: ' + (data.debug_info.php_error_log_setting || 'Ayarlanmamış'));
                        addLogLine('Kullanıcı: ' + data.debug_info.current_user);
                        addLogLine('Log Dosyaları: ' + data.debug_info.log_files_found.length);
                        
                        data.debug_info.log_files_found.forEach(file => {
                            addLogLine('  📁 ' + file.path + ' (Boyut: ' + file.size + ')');
                        });
                        addLogLine('');
                    }
                    
                    if (data.new_logs && data.new_logs.length > 0) {
                        addLogLine('=== QR DEBUG LOGLARI ===', 'header');
                        data.new_logs.forEach(log => {
                            addLogLine(log);
                        });
                    } else {
                        addLogLine('Henüz QR kod okutulmamış.', 'warning');
                        addLogLine('QR okuyucuyu açıp bir kod okutun.');
                    }
                } else {
                    addLogLine('HATA: ' + (data.error || 'Bilinmeyen hata'), 'error');
                }
            } catch (error) {
                addLogLine('FETCH HATASI: ' + error.message, 'error');
            }
        }

        function addLogLine(text, type = 'log') {
            const container = document.getElementById('logContainer');
            const div = document.createElement('div');
            div.className = 'mb-1';
            
            const timestamp = new Date().toLocaleTimeString();
            let className = '';
            
            if (type === 'system') className = 'text-gray-400';
            else if (type === 'header') className = 'text-yellow-400 font-bold';
            else if (type === 'warning') className = 'text-yellow-300';
            else if (type === 'error') className = 'error-log';
            else if (text.includes('Master QR DEBUG')) className = 'debug-qr';
            else if (text.includes('Master QR ERROR')) className = 'error-log';
            else if (text.includes('Master QR:')) className = 'master-qr';
            
            if (type !== 'system' && type !== 'header') {
                div.innerHTML = `<span class="text-gray-400">[${timestamp}]</span> <span class="${className}">${escapeHtml(text)}</span>`;
            } else {
                div.innerHTML = `<span class="${className}">${escapeHtml(text)}</span>`;
            }
            
            container.appendChild(div);
            container.scrollTop = container.scrollHeight;
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function clearLogs() {
            // Manuel log dosyasını temizle
            fetch('clear-manual-log.php')
                .then(() => {
                    document.getElementById('logContainer').innerHTML = '<div class="text-gray-500">Loglar temizlendi. Yeni QR kod okutun.</div>';
                });
        }

        // Event listeners
        document.getElementById('refreshBtn').addEventListener('click', loadLogs);
        document.getElementById('clearBtn').addEventListener('click', clearLogs);

        // İlk yükleme
        loadLogs();

        // Otomatik yenileme (5 saniyede bir)
        refreshInterval = setInterval(loadLogs, 5000);

        // Sayfa kapanınca interval'ı temizle
        window.addEventListener('beforeunload', () => {
            if (refreshInterval) {
                clearInterval(refreshInterval);
            }
        });
    </script>
</body>
</html>