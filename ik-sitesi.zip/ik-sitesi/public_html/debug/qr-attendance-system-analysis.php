<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔍 QR Devam Takip Sistemi Analizi</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();

    echo "<h3>📋 Sistemde Bulunan QR Butonları</h3>";
    echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>🔵 Buton 1: ../qr/qr-reader.php</h4>";
    echo "<ul>";
    echo "<li><strong>Konum:</strong> Dashboard, attendance-summary, attendance-tracking sayfalarında</li>";
    echo "<li><strong>Text:</strong> '📱 QR Kod Okut'</li>";
    echo "<li><strong>Özellikler:</strong> QRAttendanceHelper kullanır, akıllı eylem belirleme</li>";
    echo "<li><strong>Session:</strong> employee_id kullanır</li>";
    echo "<li><strong>Yönlendirme:</strong> smart-attendance.php'ye yönlendirir</li>";
    echo "</ul>";
    
    echo "<h4>🟢 Buton 2: qr-attendance.php</h4>";
    echo "<ul>";
    echo "<li><strong>Konum:</strong> attendance-records sayfasında</li>";
    echo "<li><strong>Text:</strong> 'QR Devam Kaydı Yap'</li>";
    echo "<li><strong>Özellikler:</strong> Basit giriş/çıkış sistemi</li>";
    echo "<li><strong>Session:</strong> user_id kullanır</li>";
    echo "<li><strong>Yönlendirme:</strong> Aynı sayfada kalır</li>";
    echo "</ul>";
    echo "</div>";

    echo "<h3>🗄️ Veritabanı Tablo Kontrolü</h3>";
    
    // Check attendance_records table
    $stmt = $conn->query("DESCRIBE attendance_records");
    $attendanceColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>📊 attendance_records Tablosu</h4>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
    echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Varsayılan</th></tr>";
    foreach ($attendanceColumns as $col) {
        echo "<tr>";
        echo "<td>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>{$col['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Check today's records
    echo "<h3>📅 Bugünkü Kayıtlar (Tüm Personel)</h3>";
    $stmt = $conn->prepare("
        SELECT 
            ar.*,
            e.first_name,
            e.last_name,
            ql.name as location_name
        FROM attendance_records ar
        LEFT JOIN employees e ON ar.employee_id = e.id
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id OR ar.location_id = ql.id
        WHERE DATE(ar.created_at) = CURDATE()
        ORDER BY ar.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $todayRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($todayRecords)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 11px; margin: 10px 0;'>";
        echo "<tr><th>ID</th><th>Personel</th><th>Aktivite</th><th>Zaman</th><th>Lokasyon</th><th>Notlar</th></tr>";
        foreach ($todayRecords as $record) {
            echo "<tr>";
            echo "<td>{$record['id']}</td>";
            echo "<td>{$record['first_name']} {$record['last_name']}</td>";
            echo "<td>{$record['activity_type']}</td>";
            echo "<td>" . date('H:i', strtotime($record['created_at'])) . "</td>";
            echo "<td>" . ($record['location_name'] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars(substr($record['notes'] ?? '', 0, 30)) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>❌ Bugün hiç devam kaydı bulunamadı</p>";
    }

    // Check QR locations
    echo "<h3>📍 QR Lokasyonları</h3>";
    $stmt = $conn->query("SELECT * FROM qr_locations WHERE is_active = 1 LIMIT 5");
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($locations)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
        echo "<tr><th>ID</th><th>Ad</th><th>Tür</th><th>Şirket</th><th>Aktif</th></tr>";
        foreach ($locations as $loc) {
            echo "<tr>";
            echo "<td>{$loc['id']}</td>";
            echo "<td>{$loc['name']}</td>";
            echo "<td>" . ($loc['location_type'] ?? 'N/A') . "</td>";
            echo "<td>" . ($loc['company_id'] ?? 'N/A') . "</td>";
            echo "<td>" . ($loc['is_active'] ? 'Evet' : 'Hayır') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>❌ Aktif QR lokasyonu bulunamadı</p>";
    }

    // Test current session
    echo "<h3>🔐 Mevcut Session Bilgisi</h3>";
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    echo "<div style='background: #e9ecef; padding: 15px; border-radius: 5px; font-size: 12px;'>";
    if (isset($_SESSION['employee_id'])) {
        echo "<p><strong>Employee ID:</strong> {$_SESSION['employee_id']}</p>";
    }
    if (isset($_SESSION['user_id'])) {
        echo "<p><strong>User ID:</strong> {$_SESSION['user_id']}</p>";
    }
    if (isset($_SESSION['user_role'])) {
        echo "<p><strong>Role:</strong> {$_SESSION['user_role']}</p>";
    }
    if (isset($_SESSION['company_id'])) {
        echo "<p><strong>Company ID:</strong> {$_SESSION['company_id']}</p>";
    }
    
    if (empty($_SESSION)) {
        echo "<p>❌ Session boş - Giriş yapılmamış</p>";
    }
    echo "</div>";

    // Problem analysis
    echo "<h3>⚠️ Tespit Edilen Sorunlar</h3>";
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<ol>";
    echo "<li><strong>Session Uyumsuzluğu:</strong> Bir sistem employee_id, diğeri user_id kullanıyor</li>";
    echo "<li><strong>İki Farklı Sistem:</strong> qr-reader.php vs qr-attendance.php karmaşıklığı</li>";
    echo "<li><strong>Kayıt Sorunları:</strong> Farklı sütun adları ve yapıları</li>";
    echo "<li><strong>Kullanıcı Kafası:</strong> Hangi butona basılacağı belirsiz</li>";
    echo "</ol>";
    echo "</div>";

    // Recommendations
    echo "<h3>💡 Çözüm Önerileri</h3>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<ol>";
    echo "<li><strong>Tek QR Sistemi:</strong> qr/qr-reader.php'yi ana sistem olarak belirle</li>";
    echo "<li><strong>Session Standardı:</strong> Tüm sistemde employee_id kullan</li>";
    echo "<li><strong>Kayıt Standardı:</strong> attendance_records tablosunu standartlaştır</li>";
    echo "<li><strong>Kullanıcı Deneyimi:</strong> Tek 'QR Kod Okut' butonu bırak</li>";
    echo "</ol>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ Analiz Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>