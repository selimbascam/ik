<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔧 Final Foreign Key Constraint Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Employee 30716129672 details
    $employee_number = '30716129672';
    
    echo "<h3>1. Employee Lookup</h3>";
    $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute([$employee_number]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "❌ Employee not found<br>";
        exit;
    }
    
    echo "✅ Employee found: {$employee['first_name']} {$employee['last_name']} (ID: {$employee['id']})<br>";
    echo "Current company_id: " . ($employee['company_id'] ?? 'NULL') . "<br>";
    
    // Check if company exists
    echo "<h3>2. Company Validation</h3>";
    if ($employee['company_id']) {
        $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
        $stmt->execute([$employee['company_id']]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($company) {
            echo "✅ Company exists: {$company['company_name']} (ID: {$company['id']})<br>";
        } else {
            echo "❌ Company ID {$employee['company_id']} does not exist!<br>";
            
            // Get first available company
            $stmt = $conn->prepare("SELECT id, company_name FROM companies ORDER BY id LIMIT 1");
            $stmt->execute();
            $firstCompany = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($firstCompany) {
                echo "🔧 Fixing: Assigning to company {$firstCompany['id']} ({$firstCompany['company_name']})<br>";
                $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
                $stmt->execute([$firstCompany['id'], $employee['id']]);
                $employee['company_id'] = $firstCompany['id'];
                echo "✅ Employee company_id updated<br>";
            }
        }
    } else {
        echo "❌ Employee has NULL company_id<br>";
        
        // Assign to first company
        $stmt = $conn->prepare("SELECT id, company_name FROM companies ORDER BY id LIMIT 1");
        $stmt->execute();
        $firstCompany = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($firstCompany) {
            echo "🔧 Fixing: Assigning to company {$firstCompany['id']} ({$firstCompany['company_name']})<br>";
            $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
            $stmt->execute([$firstCompany['id'], $employee['id']]);
            $employee['company_id'] = $firstCompany['id'];
            echo "✅ Employee company_id updated<br>";
        }
    }
    
    // Test QR location
    echo "<h3>3. QR Location Test</h3>";
    $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? LIMIT 1");
    $stmt->execute([$employee['company_id']]);
    $location = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($location) {
        echo "✅ QR Location found: {$location['name']} (ID: {$location['id']})<br>";
    } else {
        echo "❌ No QR location for this company<br>";
        
        // Create default QR location
        $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, location_type, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$employee['company_id'], 'Default QR Location', 'entrance', 'active']);
        $location_id = $conn->lastInsertId();
        echo "🔧 Created default QR location (ID: $location_id)<br>";
        $location = ['id' => $location_id, 'name' => 'Default QR Location'];
    }
    
    // Final test insert
    echo "<h3>4. Test Attendance Record Insert</h3>";
    try {
        $stmt = $conn->prepare("
            INSERT INTO attendance_records 
            (company_id, employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date) 
            VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
        ");
        
        $result = $stmt->execute([
            $employee['company_id'],
            $employee['id'],
            $location['id'],
            'work_start',
            'Final foreign key test - ' . date('Y-m-d H:i:s')
        ]);
        
        if ($result) {
            $recordId = $conn->lastInsertId();
            echo "✅ SUCCESS! Test record inserted (ID: $recordId)<br>";
            
            // Clean up test record
            $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
            $stmt->execute([$recordId]);
            echo "🧹 Test record cleaned up<br>";
        } else {
            echo "❌ Insert failed<br>";
        }
        
    } catch (Exception $e) {
        echo "❌ Insert error: " . $e->getMessage() . "<br>";
    }
    
    // Show final status
    echo "<h3>5. Final Status</h3>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
    echo "✅ Employee ID: {$employee['id']}<br>";
    echo "✅ Company ID: {$employee['company_id']}<br>";
    echo "✅ QR Location ID: {$location['id']}<br>";
    echo "✅ Foreign key constraint should now work!<br>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>