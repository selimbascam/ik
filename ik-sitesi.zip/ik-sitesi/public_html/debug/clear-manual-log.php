<?php
// Manuel log dosyasını temizle
$logFile = __DIR__ . '/manual_log.txt';
if (file_exists($logFile)) {
    file_put_contents($logFile, '');
    echo json_encode(['success' => true, 'message' => 'Log dosyası temizlendi']);
} else {
    echo json_encode(['success' => false, 'message' => 'Log dosyası bulunamadı']);
}
?>