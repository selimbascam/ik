<?php
// Quick redirect to Company 4 specific fix
header("Location: fix-company-4-personnel.php");
exit;
?>