<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/error-logger.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$message = '';
$messageType = '';
$testResults = [];

function addTestResult($test, $status, $details) {
    global $testResults;
    $testResults[] = [
        'test' => $test,
        'status' => $status,
        'details' => $details
    ];
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_tests'])) {
        // Test 1: Check if employee_shifts table exists
        try {
            $stmt = $conn->query("SHOW TABLES LIKE 'employee_shifts'");
            if ($stmt->rowCount() > 0) {
                addTestResult('employee_shifts Table', 'success', 'Table exists');
                
                // Check columns
                $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll(PDO::FETCH_ASSOC);
                $columnNames = array_column($columns, 'Field');
                
                $requiredColumns = ['id', 'company_id', 'employee_id', 'shift_template_id', 'shift_date', 'start_time', 'end_time'];
                $missingColumns = array_diff($requiredColumns, $columnNames);
                
                if (empty($missingColumns)) {
                    addTestResult('employee_shifts Columns', 'success', 'All required columns exist: ' . implode(', ', $columnNames));
                } else {
                    addTestResult('employee_shifts Columns', 'error', 'Missing columns: ' . implode(', ', $missingColumns));
                }
            } else {
                addTestResult('employee_shifts Table', 'error', 'Table does not exist');
            }
        } catch (Exception $e) {
            addTestResult('employee_shifts Table', 'error', $e->getMessage());
        }
        
        // Test 2: Check if shift_templates table exists
        try {
            $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
            if ($stmt->rowCount() > 0) {
                addTestResult('shift_templates Table', 'success', 'Table exists');
                
                // Check if it has sample data
                $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates");
                $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                addTestResult('shift_templates Data', $count > 0 ? 'success' : 'warning', "Contains $count templates");
            } else {
                addTestResult('shift_templates Table', 'error', 'Table does not exist');
            }
        } catch (Exception $e) {
            addTestResult('shift_templates Table', 'error', $e->getMessage());
        }
        
        // Test 3: Check for old shift_assignments table
        try {
            $stmt = $conn->query("SHOW TABLES LIKE 'shift_assignments'");
            if ($stmt->rowCount() > 0) {
                addTestResult('Legacy shift_assignments', 'warning', 'Old table still exists - consider removing');
            } else {
                addTestResult('Legacy shift_assignments', 'success', 'Old table correctly removed');
            }
        } catch (Exception $e) {
            addTestResult('Legacy shift_assignments', 'error', $e->getMessage());
        }
        
        // Test 4: Test monthly summary API
        try {
            $testUrl = '/api/calculate-monthly-summary.php';
            addTestResult('Monthly Summary API', 'info', 'API endpoint available at: ' . $testUrl);
        } catch (Exception $e) {
            addTestResult('Monthly Summary API', 'error', $e->getMessage());
        }
        
        // Test 5: Check error log for recent shift-related errors
        try {
            $stmt = $conn->query("
                SELECT COUNT(*) as error_count 
                FROM system_error_log 
                WHERE (error_message LIKE '%shift_assignments%' 
                OR error_message LIKE '%shift_template_id%')
                AND status = 'unsolved'
                AND DATE(created_at) >= CURDATE() - INTERVAL 7 DAYS
            ");
            $errorCount = $stmt->fetch(PDO::FETCH_ASSOC)['error_count'];
            
            if ($errorCount == 0) {
                addTestResult('Recent Shift Errors', 'success', 'No recent shift-related errors');
            } else {
                addTestResult('Recent Shift Errors', 'warning', "$errorCount unsolved shift-related errors in last 7 days");
            }
        } catch (Exception $e) {
            addTestResult('Recent Shift Errors', 'error', $e->getMessage());
        }
        
        $message = "System tests completed. Check results below.";
        $messageType = "info";
    }
    
} catch (Exception $e) {
    $message = "Database connection failed: " . $e->getMessage();
    $messageType = "error";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift System Test - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">🧪 Shift System Test</h1>
                        <p class="text-gray-600 mt-1">Vardiya sistemini test edin</p>
                    </div>
                    <div class="flex gap-2">
                        <a href="../debug/fix-shift-management.php" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm">
                            🔧 Fix Tool
                        </a>
                        <a href="../super-admin/fix-critical-errors.php" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
                            ← Critical Errors
                        </a>
                    </div>
                </div>
            </div>

            <!-- Message -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg border <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border-green-200' : ($messageType === 'error' ? 'bg-red-100 text-red-800 border-red-200' : 'bg-blue-100 text-blue-800 border-blue-200'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Run Test -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Run System Tests</h2>
                
                <form method="POST">
                    <button type="submit" name="run_tests" value="1" 
                            class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg text-lg font-semibold">
                        🧪 Run All Tests
                    </button>
                </form>
            </div>

            <!-- Test Results -->
            <?php if (!empty($testResults)): ?>
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">📋 Test Results</h2>
                
                <div class="space-y-4">
                    <?php foreach ($testResults as $result): ?>
                        <div class="border-l-4 p-4 <?php echo $result['status'] === 'success' ? 'border-green-500 bg-green-50' : ($result['status'] === 'error' ? 'border-red-500 bg-red-50' : ($result['status'] === 'warning' ? 'border-yellow-500 bg-yellow-50' : 'border-blue-500 bg-blue-50')); ?>">
                            <div class="flex items-center justify-between">
                                <h3 class="font-bold <?php echo $result['status'] === 'success' ? 'text-green-800' : ($result['status'] === 'error' ? 'text-red-800' : ($result['status'] === 'warning' ? 'text-yellow-800' : 'text-blue-800')); ?>">
                                    <?php 
                                    $icon = $result['status'] === 'success' ? '✅' : ($result['status'] === 'error' ? '❌' : ($result['status'] === 'warning' ? '⚠️' : 'ℹ️'));
                                    echo $icon . ' ' . $result['test']; 
                                    ?>
                                </h3>
                                <span class="text-xs px-2 py-1 rounded-full <?php echo $result['status'] === 'success' ? 'bg-green-200 text-green-800' : ($result['status'] === 'error' ? 'bg-red-200 text-red-800' : ($result['status'] === 'warning' ? 'bg-yellow-200 text-yellow-800' : 'bg-blue-200 text-blue-800')); ?>">
                                    <?php echo strtoupper($result['status']); ?>
                                </span>
                            </div>
                            <p class="text-sm <?php echo $result['status'] === 'success' ? 'text-green-600' : ($result['status'] === 'error' ? 'text-red-600' : ($result['status'] === 'warning' ? 'text-yellow-600' : 'text-blue-600')); ?> mt-1">
                                <?php echo $result['details']; ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Summary -->
                <div class="mt-6 p-4 bg-gray-100 rounded-lg">
                    <h4 class="font-bold text-gray-800 mb-2">📊 Test Summary</h4>
                    <?php
                    $successCount = count(array_filter($testResults, fn($r) => $r['status'] === 'success'));
                    $errorCount = count(array_filter($testResults, fn($r) => $r['status'] === 'error'));
                    $warningCount = count(array_filter($testResults, fn($r) => $r['status'] === 'warning'));
                    $infoCount = count(array_filter($testResults, fn($r) => $r['status'] === 'info'));
                    $total = count($testResults);
                    ?>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div class="text-center">
                            <div class="text-lg font-bold text-green-600"><?php echo $successCount; ?></div>
                            <div class="text-gray-600">Success</div>
                        </div>
                        <div class="text-center">
                            <div class="text-lg font-bold text-red-600"><?php echo $errorCount; ?></div>
                            <div class="text-gray-600">Errors</div>
                        </div>
                        <div class="text-center">
                            <div class="text-lg font-bold text-yellow-600"><?php echo $warningCount; ?></div>
                            <div class="text-gray-600">Warnings</div>
                        </div>
                        <div class="text-center">
                            <div class="text-lg font-bold text-blue-600"><?php echo $infoCount; ?></div>
                            <div class="text-gray-600">Info</div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</body>
</html>