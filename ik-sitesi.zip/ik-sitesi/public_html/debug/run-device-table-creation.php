<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Device Tables Oluşturucu</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100'>
    <div class='container mx-auto px-4 py-8 max-w-4xl'>
        <div class='bg-white rounded-lg shadow-lg p-6'>
            <h1 class='text-2xl font-bold text-gray-900 mb-6'>📱 Device Tables Otomatik Oluşturucu</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-4'>";
    
    // Create device_records table
    $sql = "CREATE TABLE IF NOT EXISTS device_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT,
        session_id VARCHAR(100),
        device_fingerprint VARCHAR(255),
        ip_address VARCHAR(45),
        mac_address VARCHAR(17),
        user_agent TEXT,
        device_type VARCHAR(50),
        browser_name VARCHAR(50),
        operating_system VARCHAR(50),
        screen_resolution VARCHAR(20),
        timezone_offset INT,
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        location_accuracy DECIMAL(10, 2),
        location_timestamp TIMESTAMP,
        qr_location_id INT,
        action_type ENUM('checkin', 'checkout', 'break_start', 'break_end') NOT NULL,
        success BOOLEAN DEFAULT TRUE,
        error_message TEXT,
        recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_employee_date (employee_id, created_at),
        INDEX idx_ip_address (ip_address),
        INDEX idx_device_fingerprint (device_fingerprint),
        INDEX idx_company_date (company_id, created_at)
    )";
    $conn->exec($sql);
    echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded'>";
    echo "✅ device_records tablosu başarıyla oluşturuldu/doğrulandı";
    echo "</div>";
    
    // Create employee_devices table
    $sql = "CREATE TABLE IF NOT EXISTS employee_devices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT NOT NULL,
        device_fingerprint VARCHAR(255) NOT NULL,
        device_name VARCHAR(100),
        device_type VARCHAR(50),
        first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        is_trusted BOOLEAN DEFAULT FALSE,
        is_blocked BOOLEAN DEFAULT FALSE,
        usage_count INT DEFAULT 1,
        notes TEXT,
        UNIQUE KEY unique_device_employee (employee_id, device_fingerprint),
        INDEX idx_device_fingerprint (device_fingerprint)
    )";
    $conn->exec($sql);
    echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded'>";
    echo "✅ employee_devices tablosu başarıyla oluşturuldu/doğrulandı";
    echo "</div>";
    
    // Create device_security_logs table
    $sql = "CREATE TABLE IF NOT EXISTS device_security_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT,
        device_fingerprint VARCHAR(255),
        ip_address VARCHAR(45),
        event_type ENUM('new_device', 'suspicious_location', 'multiple_devices', 'blocked_device', 'trusted_device') NOT NULL,
        severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
        description TEXT,
        metadata JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_severity_date (severity, created_at),
        INDEX idx_employee_event (employee_id, event_type)
    )";
    $conn->exec($sql);
    echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded'>";
    echo "✅ device_security_logs tablosu başarıyla oluşturuldu/doğrulandı";
    echo "</div>";
    
    echo "<div class='bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mt-6'>";
    echo "<h3 class='font-semibold mb-2'>🎉 Device Tracking Sistemi Hazır!</h3>";
    echo "<p>Tüm device tracking tabloları başarıyla oluşturuldu.</p>";
    
    echo "<h4 class='font-medium mt-4 mb-2'>Etkinleştirilen Özellikler:</h4>";
    echo "<ul class='list-disc list-inside space-y-1 text-sm'>";
    echo "<li>📱 Device fingerprinting ve tanımlama</li>";
    echo "<li>🌍 GPS konum takibi ve doğruluk kontrolü</li>";
    echo "<li>🔍 IP address ve MAC address kayıtları</li>";
    echo "<li>🔒 Personel-cihaz ilişki yönetimi</li>";
    echo "<li>⚠️ Güvenlik olay kayıtları ve uyarılar</li>";
    echo "<li>📊 Cihaz kullanım analitikleri</li>";
    echo "</ul>";
    echo "</div>";
    
    // Test the tables
    echo "<div class='bg-gray-50 border border-gray-300 text-gray-700 px-4 py-3 rounded mt-4'>";
    echo "<h4 class='font-medium mb-2'>📊 Tablo Test Sonuçları:</h4>";
    
    $tables = ['device_records', 'employee_devices', 'device_security_logs'];
    foreach ($tables as $table) {
        try {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM $table");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p class='text-sm'>✅ $table: $count kayıt</p>";
        } catch (Exception $e) {
            echo "<p class='text-sm text-red-600'>❌ $table: Hata - " . $e->getMessage() . "</p>";
        }
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>";
    echo "❌ Hata: " . htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo "<div class='flex flex-wrap gap-3 mt-6 pt-4 border-t'>
        <a href='../admin/device-management.php' class='bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm'>
            ⚙️ Device Management
        </a>
        <a href='../view-device-records.php' class='bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm'>
            📱 View Device Records
        </a>
        <a href='fix-device-records.php' class='bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm'>
            🔧 Device Records Tanı
        </a>
        <a href='../dashboard/company-dashboard.php' class='bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm'>
            🏠 Dashboard
        </a>
      </div>";

echo "        </div>
    </div>
</body>
</html>";
?>