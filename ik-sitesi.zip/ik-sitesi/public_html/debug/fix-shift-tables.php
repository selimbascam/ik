<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$message = '';
$messageType = '';
$diagnostics = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    function addDiagnostic($type, $title, $details) {
        global $diagnostics;
        $diagnostics[] = [
            'type' => $type,
            'title' => $title,
            'details' => $details
        ];
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix_action'])) {
        switch ($_POST['fix_action']) {
            case 'create_shift_templates_table':
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS shift_templates (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            name VARCHAR(255) NOT NULL,
                            start_time TIME NOT NULL,
                            end_time TIME NOT NULL,
                            break_duration INT DEFAULT 60,
                            description TEXT,
                            color_code VARCHAR(7) DEFAULT '#3B82F6',
                            is_active TINYINT(1) DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            INDEX idx_company_id (company_id),
                            INDEX idx_active (is_active),
                            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    
                    $message = "✅ shift_templates tablosu başarıyla oluşturuldu";
                    $messageType = "success";
                    addDiagnostic('success', 'shift_templates Table Created', 'Table created with proper structure');
                } catch (Exception $e) {
                    $message = "❌ shift_templates tablosu oluşturulamadı: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'shift_templates Creation Failed', $e->getMessage());
                }
                break;
                
            case 'create_employee_shifts_table':
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS employee_shifts (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            employee_id INT NOT NULL,
                            shift_template_id INT NOT NULL,
                            shift_date DATE NOT NULL,
                            status ENUM('scheduled', 'checked_in', 'checked_out', 'absent', 'late') DEFAULT 'scheduled',
                            check_in_time TIME DEFAULT NULL,
                            check_out_time TIME DEFAULT NULL,
                            break_start_time TIME DEFAULT NULL,
                            break_end_time TIME DEFAULT NULL,
                            late_reason TEXT DEFAULT NULL,
                            early_leave_reason TEXT DEFAULT NULL,
                            absence_reason TEXT DEFAULT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            UNIQUE KEY unique_employee_date (employee_id, shift_date),
                            INDEX idx_employee_id (employee_id),
                            INDEX idx_shift_date (shift_date),
                            INDEX idx_status (status),
                            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                            FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    
                    $message = "✅ employee_shifts tablosu başarıyla oluşturuldu";
                    $messageType = "success";
                    addDiagnostic('success', 'employee_shifts Table Created', 'Table created with proper structure and foreign keys');
                } catch (Exception $e) {
                    $message = "❌ employee_shifts tablosu oluşturulamadı: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'employee_shifts Creation Failed', $e->getMessage());
                }
                break;
                
            case 'create_default_shift_templates':
                try {
                    // Check if default templates already exist for company 1 (or create for all companies)
                    $stmt = $conn->query("SELECT id FROM companies LIMIT 1");
                    $company = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($company) {
                        $companyId = $company['id'];
                        
                        $defaultTemplates = [
                            ['Gündüz Vardiyası', '08:00:00', '17:00:00', 60, 'Standart gündüz mesai saatleri', '#3B82F6'],
                            ['Gece Vardiyası', '22:00:00', '06:00:00', 60, 'Gece vardiya mesai saatleri', '#DC2626'],
                            ['Sabah Vardiyası', '06:00:00', '14:00:00', 30, 'Erken sabah vardiya saatleri', '#059669'],
                            ['Öğleden Sonra', '14:00:00', '22:00:00', 30, 'Öğleden sonra vardiya saatleri', '#D97706'],
                            ['Esnek Vardiya', '09:00:00', '18:00:00', 60, 'Esnek çalışma saatleri', '#7C3AED']
                        ];
                        
                        $insertCount = 0;
                        foreach ($defaultTemplates as $template) {
                            try {
                                // Try with color_code first, then fallback without it
                                try {
                                    $stmt = $conn->prepare("
                                        INSERT IGNORE INTO shift_templates 
                                        (company_id, name, start_time, end_time, break_duration, description, color_code) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $companyId,
                                        $template[0], // name
                                        $template[1], // start_time
                                        $template[2], // end_time
                                        $template[3], // break_duration
                                        $template[4], // description
                                        $template[5]  // color_code
                                    ]);
                                } catch (PDOException $colorError) {
                                    // Fallback without color_code column
                                    $stmt = $conn->prepare("
                                        INSERT IGNORE INTO shift_templates 
                                        (company_id, name, start_time, end_time, break_duration, description) 
                                        VALUES (?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $companyId,
                                        $template[0], // name
                                        $template[1], // start_time
                                        $template[2], // end_time
                                        $template[3], // break_duration
                                        $template[4]  // description
                                    ]);
                                }
                                if ($stmt->rowCount() > 0) {
                                    $insertCount++;
                                }
                            } catch (Exception $e) {
                                // Continue with next template if one fails
                            }
                        }
                        
                        $message = "✅ $insertCount varsayılan vardiya şablonu eklendi";
                        $messageType = "success";
                        addDiagnostic('success', 'Default Templates Added', "$insertCount templates created successfully");
                    } else {
                        $message = "❌ Şirket bulunamadı, varsayılan şablonlar eklenemedi";
                        $messageType = "error";
                    }
                } catch (Exception $e) {
                    $message = "❌ Varsayılan şablonlar eklenemedi: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Default Templates Failed', $e->getMessage());
                }
                break;
                
            case 'fix_shift_tables_columns':
                try {
                    $steps = [];
                    
                    // Check and fix shift_templates table columns
                    $columns = $conn->query("SHOW COLUMNS FROM shift_templates")->fetchAll(PDO::FETCH_ASSOC);
                    $columnNames = array_column($columns, 'Field');
                    
                    $requiredShiftTemplatesColumns = [
                        'color_code' => 'VARCHAR(7) DEFAULT \'#3B82F6\'',
                        'is_active' => 'TINYINT(1) DEFAULT 1',
                        'description' => 'TEXT',
                        'break_duration' => 'INT DEFAULT 60'
                    ];
                    
                    foreach ($requiredShiftTemplatesColumns as $column => $definition) {
                        if (!in_array($column, $columnNames)) {
                            $conn->exec("ALTER TABLE shift_templates ADD COLUMN $column $definition");
                            $steps[] = "✅ shift_templates.$column added";
                        } else {
                            $steps[] = "ℹ️ shift_templates.$column exists";
                        }
                    }
                    
                    // Check and fix employee_shifts table columns
                    $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll(PDO::FETCH_ASSOC);
                    $columnNames = array_column($columns, 'Field');
                    
                    $requiredEmployeeShiftsColumns = [
                        'shift_date' => 'DATE NOT NULL',
                        'status' => 'ENUM(\'scheduled\', \'checked_in\', \'checked_out\', \'absent\', \'late\') DEFAULT \'scheduled\'',
                        'check_in_time' => 'TIME DEFAULT NULL',
                        'check_out_time' => 'TIME DEFAULT NULL',
                        'late_reason' => 'TEXT DEFAULT NULL',
                        'early_leave_reason' => 'TEXT DEFAULT NULL',
                        'absence_reason' => 'TEXT DEFAULT NULL'
                    ];
                    
                    foreach ($requiredEmployeeShiftsColumns as $column => $definition) {
                        if (!in_array($column, $columnNames)) {
                            $conn->exec("ALTER TABLE employee_shifts ADD COLUMN $column $definition");
                            $steps[] = "✅ employee_shifts.$column added";
                        } else {
                            $steps[] = "ℹ️ employee_shifts.$column exists";
                        }
                    }
                    
                    $message = "🔧 Shift table columns fixed:<br>" . implode('<br>', $steps);
                    $messageType = "success";
                    addDiagnostic('success', 'Column Fix Complete', 'All required columns checked and added');
                } catch (Exception $e) {
                    $message = "❌ Column fixes failed: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Column Fix Failed', $e->getMessage());
                }
                break;
                
            case 'comprehensive_shift_fix':
                $steps = [];
                
                // Step 1: Create shift_templates table
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS shift_templates (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            name VARCHAR(255) NOT NULL,
                            start_time TIME NOT NULL,
                            end_time TIME NOT NULL,
                            break_duration INT DEFAULT 60,
                            description TEXT,
                            color_code VARCHAR(7) DEFAULT '#3B82F6',
                            is_active TINYINT(1) DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            INDEX idx_company_id (company_id),
                            INDEX idx_active (is_active)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    $steps[] = "✅ shift_templates table created/verified";
                } catch (Exception $e) {
                    $steps[] = "❌ shift_templates table failed: " . $e->getMessage();
                }
                
                // Step 2: Create employee_shifts table
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS employee_shifts (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            employee_id INT NOT NULL,
                            shift_template_id INT NOT NULL,
                            shift_date DATE NOT NULL,
                            status ENUM('scheduled', 'checked_in', 'checked_out', 'absent', 'late') DEFAULT 'scheduled',
                            check_in_time TIME DEFAULT NULL,
                            check_out_time TIME DEFAULT NULL,
                            break_start_time TIME DEFAULT NULL,
                            break_end_time TIME DEFAULT NULL,
                            late_reason TEXT DEFAULT NULL,
                            early_leave_reason TEXT DEFAULT NULL,
                            absence_reason TEXT DEFAULT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            UNIQUE KEY unique_employee_date (employee_id, shift_date),
                            INDEX idx_employee_id (employee_id),
                            INDEX idx_shift_date (shift_date),
                            INDEX idx_status (status)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    $steps[] = "✅ employee_shifts table created/verified";
                } catch (Exception $e) {
                    $steps[] = "❌ employee_shifts table failed: " . $e->getMessage();
                }
                
                // Step 3: Add default shift templates
                try {
                    $stmt = $conn->query("SELECT id FROM companies LIMIT 1");
                    $company = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($company) {
                        $companyId = $company['id'];
                        
                        $defaultTemplates = [
                            ['Gündüz Vardiyası', '08:00:00', '17:00:00', 60, 'Standart gündüz mesai saatleri', '#3B82F6'],
                            ['Gece Vardiyası', '22:00:00', '06:00:00', 60, 'Gece vardiya mesai saatleri', '#DC2626'],
                            ['Sabah Vardiyası', '06:00:00', '14:00:00', 30, 'Erken sabah vardiya saatleri', '#059669']
                        ];
                        
                        $insertCount = 0;
                        foreach ($defaultTemplates as $template) {
                            try {
                                // Try with color_code first, then fallback without it
                                try {
                                    $stmt = $conn->prepare("
                                        INSERT IGNORE INTO shift_templates 
                                        (company_id, name, start_time, end_time, break_duration, description, color_code) 
                                        VALUES (?, ?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $companyId,
                                        $template[0], $template[1], $template[2], 
                                        $template[3], $template[4], $template[5]
                                    ]);
                                } catch (PDOException $colorError) {
                                    // Fallback without color_code column
                                    $stmt = $conn->prepare("
                                        INSERT IGNORE INTO shift_templates 
                                        (company_id, name, start_time, end_time, break_duration, description) 
                                        VALUES (?, ?, ?, ?, ?, ?)
                                    ");
                                    $stmt->execute([
                                        $companyId,
                                        $template[0], $template[1], $template[2], 
                                        $template[3], $template[4]
                                    ]);
                                }
                                if ($stmt->rowCount() > 0) {
                                    $insertCount++;
                                }
                            } catch (Exception $e) {
                                // Continue
                            }
                        }
                        $steps[] = "✅ $insertCount default shift templates added";
                    }
                } catch (Exception $e) {
                    $steps[] = "⚠️ Default templates: " . $e->getMessage();
                }
                
                // Step 4: Mark related errors as solved
                try {
                    $stmt = $conn->prepare("
                        UPDATE system_error_log 
                        SET status = 'solved', 
                            solution_notes = 'Shift tables created and configured properly',
                            solved_by = 'Shift Tables Fix Tool',
                            solved_at = NOW()
                        WHERE (error_message LIKE '%shift_templates%' 
                        OR error_message LIKE '%employee_shifts%'
                        OR error_message LIKE '%Vardiya tabloları%')
                        AND status = 'unsolved'
                    ");
                    $stmt->execute();
                    $fixedErrorCount = $stmt->rowCount();
                    $steps[] = "✅ " . $fixedErrorCount . " shift-related errors marked as solved";
                } catch (Exception $e) {
                    $steps[] = "⚠️ Error marking: " . $e->getMessage();
                }
                
                $message = "🔧 Comprehensive Shift Tables Fix Completed:<br>" . implode('<br>', $steps);
                $messageType = "success";
                break;
                
            case 'test_shift_tables':
                try {
                    $testResults = [];
                    
                    // Test shift_templates table
                    $stmt = $conn->query("SELECT COUNT(*) FROM shift_templates");
                    $templateCount = $stmt->fetchColumn();
                    $testResults[] = "shift_templates: $templateCount records";
                    
                    // Test employee_shifts table
                    $stmt = $conn->query("SELECT COUNT(*) FROM employee_shifts");
                    $shiftCount = $stmt->fetchColumn();
                    $testResults[] = "employee_shifts: $shiftCount records";
                    
                    // Test a simple join query
                    $stmt = $conn->query("
                        SELECT st.name, COUNT(es.id) as assignment_count
                        FROM shift_templates st
                        LEFT JOIN employee_shifts es ON st.id = es.shift_template_id
                        GROUP BY st.id
                        LIMIT 5
                    ");
                    $joinResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $testResults[] = "Join query returned " . count($joinResults) . " template results";
                    
                    $message = "✅ Shift tables test successful:<br>" . implode('<br>', $testResults);
                    $messageType = "success";
                    addDiagnostic('success', 'Tables Test', 'All shift tables are working correctly');
                } catch (Exception $e) {
                    $message = "❌ Shift tables test failed: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Tables Test Failed', $e->getMessage());
                }
                break;
        }
    }
    
    // Diagnostic checks
    addDiagnostic('info', 'Database Connection', 'Connected successfully');
    
    // Check shift_templates table
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
        if ($stmt->rowCount() > 0) {
            $stmt = $conn->query("SELECT COUNT(*) FROM shift_templates");
            $count = $stmt->fetchColumn();
            addDiagnostic('success', 'shift_templates Table', "Exists with $count records");
        } else {
            addDiagnostic('error', 'shift_templates Table', 'Table does not exist');
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'shift_templates Check', $e->getMessage());
    }
    
    // Check employee_shifts table
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'employee_shifts'");
        if ($stmt->rowCount() > 0) {
            $stmt = $conn->query("SELECT COUNT(*) FROM employee_shifts");
            $count = $stmt->fetchColumn();
            addDiagnostic('success', 'employee_shifts Table', "Exists with $count records");
        } else {
            addDiagnostic('error', 'employee_shifts Table', 'Table does not exist');
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'employee_shifts Check', $e->getMessage());
    }
    
    // Check for recent shift table errors
    try {
        $stmt = $conn->query("
            SELECT COUNT(*) as error_count 
            FROM system_error_log 
            WHERE (error_message LIKE '%shift_templates%' 
            OR error_message LIKE '%employee_shifts%'
            OR error_message LIKE '%Vardiya tabloları%')
            AND status = 'unsolved'
            AND DATE(created_at) >= CURDATE() - INTERVAL 1 DAY
        ");
        $errorCount = $stmt->fetch(PDO::FETCH_ASSOC)['error_count'];
        
        if ($errorCount > 0) {
            addDiagnostic('error', 'Recent Shift Table Errors', $errorCount . ' unsolved shift table errors in last 24 hours');
        } else {
            addDiagnostic('success', 'Recent Shift Table Errors', 'No recent shift table errors');
        }
    } catch (Exception $e) {
        addDiagnostic('warning', 'Error Check', 'Could not check recent errors: ' . $e->getMessage());
    }

} catch (Exception $e) {
    $message = "Database connection failed: " . $e->getMessage();
    $messageType = "error";
    addDiagnostic('error', 'Critical Error', $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift Tables Fix - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">📅 Vardiya Tabloları Düzeltme</h1>
                        <p class="text-gray-600 mt-1">Vardiya yönetimi için gerekli veritabanı tablolarını oluşturun ve düzeltin</p>
                    </div>
                    <a href="../super-admin/fix-critical-errors.php" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
                        ← Critical Errors
                    </a>
                </div>
            </div>

            <!-- Message -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg border <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border-green-200' : ($messageType === 'error' ? 'bg-red-100 text-red-800 border-red-200' : 'bg-blue-100 text-blue-800 border-blue-200'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Quick Fixes -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Quick Fixes</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <!-- Create shift_templates table -->
                    <div class="border border-blue-200 rounded-lg p-4 bg-blue-50">
                        <h3 class="font-bold text-blue-800 mb-2">📋 Shift Templates Table</h3>
                        <p class="text-sm text-blue-600 mb-3">
                            shift_templates tablosunu oluştur (vardiya şablonları için).
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="create_shift_templates_table" 
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                                📋 Create Shift Templates Table
                            </button>
                        </form>
                    </div>
                    
                    <!-- Create employee_shifts table -->
                    <div class="border border-purple-200 rounded-lg p-4 bg-purple-50">
                        <h3 class="font-bold text-purple-800 mb-2">👥 Employee Shifts Table</h3>
                        <p class="text-sm text-purple-600 mb-3">
                            employee_shifts tablosunu oluştur (vardiya atamaları için).
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="create_employee_shifts_table" 
                                    class="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm">
                                👥 Create Employee Shifts Table
                            </button>
                        </form>
                    </div>

                    <!-- Create default shift templates -->
                    <div class="border border-orange-200 rounded-lg p-4 bg-orange-50">
                        <h3 class="font-bold text-orange-800 mb-2">⭐ Default Shift Templates</h3>
                        <p class="text-sm text-orange-600 mb-3">
                            Varsayılan vardiya şablonları ekle (Gündüz, Gece, Sabah).
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="create_default_shift_templates" 
                                    class="w-full bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm">
                                ⭐ Add Default Templates
                            </button>
                        </form>
                    </div>

                    <!-- Fix table columns -->
                    <div class="border border-yellow-200 rounded-lg p-4 bg-yellow-50">
                        <h3 class="font-bold text-yellow-800 mb-2">🔧 Fix Table Columns</h3>
                        <p class="text-sm text-yellow-600 mb-3">
                            Eksik sütunları kontrol et ve ekle (shift_date, status vs.).
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="fix_shift_tables_columns" 
                                    class="w-full bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg text-sm">
                                🔧 Fix Missing Columns
                            </button>
                        </form>
                    </div>

                    <!-- Test shift tables -->
                    <div class="border border-indigo-200 rounded-lg p-4 bg-indigo-50">
                        <h3 class="font-bold text-indigo-800 mb-2">🧪 Test Shift Tables</h3>
                        <p class="text-sm text-indigo-600 mb-3">
                            Vardiya tablolarının çalışıp çalışmadığını test et.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="test_shift_tables" 
                                    class="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">
                                🧪 Test Shift Tables
                            </button>
                        </form>
                    </div>

                    <!-- Comprehensive Fix -->
                    <div class="border border-green-200 rounded-lg p-4 bg-green-50">
                        <h3 class="font-bold text-green-800 mb-2">🔧 Complete Shift Fix</h3>
                        <p class="text-sm text-green-600 mb-3">
                            Tüm vardiya tablolarını oluştur ve hataları işaretle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="comprehensive_shift_fix" 
                                    class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm">
                                🔧 Complete Shift Tables Fix
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Diagnostics -->
            <?php if (!empty($diagnostics)): ?>
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🔍 System Diagnostics</h2>
                
                <div class="space-y-3">
                    <?php foreach ($diagnostics as $diagnostic): ?>
                        <div class="border-l-4 p-3 <?php echo $diagnostic['type'] === 'success' ? 'border-green-500 bg-green-50' : ($diagnostic['type'] === 'error' ? 'border-red-500 bg-red-50' : ($diagnostic['type'] === 'warning' ? 'border-yellow-500 bg-yellow-50' : 'border-blue-500 bg-blue-50')); ?>">
                            <h4 class="font-bold <?php echo $diagnostic['type'] === 'success' ? 'text-green-800' : ($diagnostic['type'] === 'error' ? 'text-red-800' : ($diagnostic['type'] === 'warning' ? 'text-yellow-800' : 'text-blue-800')); ?>">
                                <?php 
                                $icon = $diagnostic['type'] === 'success' ? '✅' : ($diagnostic['type'] === 'error' ? '❌' : ($diagnostic['type'] === 'warning' ? '⚠️' : 'ℹ️'));
                                echo $icon . ' ' . $diagnostic['title']; 
                                ?>
                            </h4>
                            <p class="text-sm <?php echo $diagnostic['type'] === 'success' ? 'text-green-600' : ($diagnostic['type'] === 'error' ? 'text-red-600' : ($diagnostic['type'] === 'warning' ? 'text-yellow-600' : 'text-blue-600')); ?> mt-1">
                                <?php echo $diagnostic['details']; ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</body>
</html>