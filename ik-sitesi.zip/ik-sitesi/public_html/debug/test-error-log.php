<?php
// Test error logging
echo "PHP Error Log Test<br>";

// Test error_log() fonksiyonu
error_log("TEST LOG MESAJI: " . date('Y-m-d H:i:s'));

// Log ayarlarını kontrol et
echo "Error log setting: " . ini_get('error_log') . "<br>";
echo "Log errors: " . ini_get('log_errors') . "<br>";
echo "Display errors: " . ini_get('display_errors') . "<br>";

// Manuel log dosyası yaz
$logFile = __DIR__ . '/manual_log.txt';
file_put_contents($logFile, "Manual log test: " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

echo "Manual log yazıldı: " . $logFile . "<br>";

// QR master dosyasındaki debug logunu test et
error_log("Master QR DEBUG: Test mesajı - LocationID=99, Type='test'");

echo "Test tamamlandı. Debug ekranında mesajları kontrol edin.";
?>