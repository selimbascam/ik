<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Quick device table creation script for immediate fixing
echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <title>Device Tables Quick Fix</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100 p-8'>
    <div class='max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-6'>
        <h1 class='text-xl font-bold text-gray-900 mb-4'>🚀 Device Tables Quick Fix</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-4'>";
    
    // Create device_records table
    echo "<div class='bg-blue-50 p-4 rounded'>
            <h3 class='font-semibold text-blue-800'>Creating device_records table...</h3>";
    
    $conn->exec("CREATE TABLE IF NOT EXISTS device_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT,
        session_id VARCHAR(100),
        device_fingerprint VARCHAR(255),
        ip_address VARCHAR(45),
        mac_address VARCHAR(17),
        user_agent TEXT,
        device_type VARCHAR(50),
        browser_name VARCHAR(50),
        operating_system VARCHAR(50),
        screen_resolution VARCHAR(20),
        timezone_offset INT,
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        location_accuracy DECIMAL(10, 2),
        location_timestamp TIMESTAMP,
        qr_location_id INT,
        action_type ENUM('checkin', 'checkout', 'break_start', 'break_end') NOT NULL,
        success BOOLEAN DEFAULT TRUE,
        error_message TEXT,
        recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_employee_date (employee_id, created_at),
        INDEX idx_ip_address (ip_address),
        INDEX idx_device_fingerprint (device_fingerprint),
        INDEX idx_company_date (company_id, created_at)
    )");
    
    echo "<p class='text-green-600 mt-2'>✅ device_records table created successfully</p></div>";
    
    // Create employee_devices table
    echo "<div class='bg-green-50 p-4 rounded'>
            <h3 class='font-semibold text-green-800'>Creating employee_devices table...</h3>";
    
    $conn->exec("CREATE TABLE IF NOT EXISTS employee_devices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT NOT NULL,
        device_fingerprint VARCHAR(255) NOT NULL,
        device_name VARCHAR(100),
        device_type VARCHAR(50),
        first_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        is_trusted BOOLEAN DEFAULT FALSE,
        is_blocked BOOLEAN DEFAULT FALSE,
        usage_count INT DEFAULT 1,
        notes TEXT,
        trust_granted_by INT,
        trust_granted_at TIMESTAMP NULL,
        UNIQUE KEY unique_device_employee (employee_id, device_fingerprint),
        INDEX idx_device_fingerprint (device_fingerprint),
        INDEX idx_company_employee (company_id, employee_id)
    )");
    
    echo "<p class='text-green-600 mt-2'>✅ employee_devices table created successfully</p></div>";
    
    // Create device_security_logs table
    echo "<div class='bg-purple-50 p-4 rounded'>
            <h3 class='font-semibold text-purple-800'>Creating device_security_logs table...</h3>";
    
    $conn->exec("CREATE TABLE IF NOT EXISTS device_security_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT,
        device_fingerprint VARCHAR(255),
        ip_address VARCHAR(45),
        event_type ENUM('new_device', 'suspicious_location', 'multiple_devices', 'blocked_device', 'trusted_device', 'trust_granted', 'blocked_attempt') NOT NULL,
        severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
        description TEXT,
        metadata JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_severity_date (severity, created_at),
        INDEX idx_employee_event (employee_id, event_type)
    )");
    
    echo "<p class='text-green-600 mt-2'>✅ device_security_logs table created successfully</p></div>";
    
    // Verify tables exist
    echo "<div class='bg-yellow-50 p-4 rounded'>
            <h3 class='font-semibold text-yellow-800'>Verifying tables...</h3>";
    
    $tables = ['device_records', 'employee_devices', 'device_security_logs'];
    foreach ($tables as $table) {
        $stmt = $conn->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "<p class='text-green-600'>✅ $table table verified</p>";
        } else {
            echo "<p class='text-red-600'>❌ $table table verification failed</p>";
        }
    }
    echo "</div>";
    
    echo "<div class='bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mt-4'>
            <h3 class='font-bold'>🎉 Device Tables Created Successfully!</h3>
            <p>All required device management tables have been created. You can now:</p>
            <ul class='list-disc list-inside mt-2'>
                <li>Access Device Management without errors</li>
                <li>Track employee devices and security</li>
                <li>Monitor device usage patterns</li>
            </ul>
          </div>";
    
    echo "<div class='mt-6 flex gap-3'>
            <a href='../admin/device-management.php' class='bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded'>
                📱 Go to Device Management
            </a>
            <a href='fix-device-records.php' class='bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded'>
                🔧 Full Diagnostic Tool
            </a>
            <a href='../dashboard/company-dashboard.php' class='bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded'>
                🏠 Back to Dashboard
            </a>
          </div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>
            <strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "
          </div>";
}

echo "    </div>
</body>
</html>";
?>