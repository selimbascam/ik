<?php
require_once '../includes/config.php';

echo "<h2>🔧 Otomatik MySQL Format Düzeltici</h2>";

$fixResults = [];

// Priority files to fix first
$criticalFiles = [
    '../api/process-attendance.php',
    '../qr/qr-reader-old.php', 
    '../qr/activity-selection.php',
    '../view-device-records.php',
    '../super-admin/fix-critical-errors.php'
];

echo "<h3>🎯 Kritik Dosyalar Düzeltiliyor...</h3>";

foreach ($criticalFiles as $file) {
    if (!file_exists($file)) {
        $fixResults[$file] = ['status' => 'error', 'message' => 'Dosya bulunamadı'];
        continue;
    }
    
    $fileName = basename($file);
    echo "<h4>📝 {$fileName} düzeltiliyor...</h4>";
    
    $content = file_get_contents($file);
    $originalContent = $content;
    $changes = [];
    
    // Fix 1: CONCAT operator issues (boolean logic)
    $concatPatterns = [
        '/(\!\w+)\s*CONCAT(\!\w+)/' => '$1 || $2',                    // !var CONCAT!var → !var || !var
        '/(\w+)\s*CONCAT\s*(\!\w+)/' => '$1 || $2',                   // var CONCAT !var → var || !var
        '/(\!\w+)\s*CONCAT\s*(\w+)/' => '$1 || $2',                   // !var CONCAT var → !var || var
        '/(\w+)\s*CONCAT(\w+)/' => '$1 || $2',                        // var CONCATvar → var || var
        '/(\w+)\s*CONCAT\s*(\w+)/' => '$1 || $2',                     // var CONCAT var → var || var
        '/navigator\.platform\s*CONCAT\s*navigator/' => 'navigator.platform || navigator'  // JS specific
    ];
    
    foreach ($concatPatterns as $pattern => $replacement) {
        $newContent = preg_replace($pattern, $replacement, $content);
        if ($newContent !== $content) {
            $changes[] = "CONCAT operatör düzeltildi: " . substr($pattern, 1, 20) . "...";
            $content = $newContent;
        }
    }
    
    // Fix 2: SQL syntax issues
    $sqlPatterns = [
        '/DELIMITER\s*\/\//' => '-- DELIMITER (removed for MariaDB compatibility)',
        '/DELIMITER\s*;/' => '-- DELIMITER (removed for MariaDB compatibility)', 
        '/REFERENCES\s+shifts\s*\(/i' => 'REFERENCES shift_templates(',
        '/FROM\s+shifts\s+/i' => 'FROM shift_templates ',
        '/JOIN\s+shifts\s+/i' => 'JOIN shift_templates '
    ];
    
    foreach ($sqlPatterns as $pattern => $replacement) {
        $newContent = preg_replace($pattern, $replacement, $content);
        if ($newContent !== $content) {
            $changes[] = "SQL syntax düzeltildi: " . substr($pattern, 1, 30) . "...";
            $content = $newContent;
        }
    }
    
    // Fix 3: Column reference issues
    $columnPatterns = [
        '/e\.salary/' => 'COALESCE(e.salary, e.hourly_rate * 8 * 22, 0)',  // Handle missing salary column
        '/ar\.location/' => 'COALESCE(ar.location, ql.name)',               // Handle missing location column
    ];
    
    foreach ($columnPatterns as $pattern => $replacement) {
        $newContent = preg_replace('/' . preg_quote($pattern, '/') . '/', $replacement, $content);
        if ($newContent !== $content) {
            $changes[] = "Column reference düzeltildi: {$pattern}";
            $content = $newContent;
        }
    }
    
    // Save changes if any were made
    if ($content !== $originalContent) {
        $backupFile = $file . '.backup.' . date('Y-m-d-H-i-s');
        file_put_contents($backupFile, $originalContent);
        
        if (file_put_contents($file, $content)) {
            $fixResults[$file] = [
                'status' => 'success', 
                'changes' => $changes,
                'backup' => $backupFile
            ];
            
            echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<strong>✅ {$fileName} başarıyla düzeltildi</strong><br>";
            echo "<small>Yedek: " . basename($backupFile) . "</small><br>";
            echo "<ul>";
            foreach ($changes as $change) {
                echo "<li>{$change}</li>";
            }
            echo "</ul>";
            echo "</div>";
        } else {
            $fixResults[$file] = ['status' => 'error', 'message' => 'Dosya yazılamadı'];
            echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<strong>❌ {$fileName} düzeltilemedi - dosya yazılamadı</strong>";
            echo "</div>";
        }
    } else {
        $fixResults[$file] = ['status' => 'clean', 'message' => 'Düzeltme gerektirmedi'];
        echo "<div style='background: #d1ecf1; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<strong>ℹ️ {$fileName} zaten temiz</strong>";
        echo "</div>";
    }
}

// Additional database-specific fixes
echo "<h3>🗄️ Veritabanı Şeması Düzeltmeleri</h3>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check and fix common database issues
    $dbFixes = [];
    
    // Check if attendance_records has required columns
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredColumns = [
        'qr_location_id' => 'INT NULL',
        'latitude' => 'DECIMAL(10, 8) NULL',
        'longitude' => 'DECIMAL(11, 8) NULL',
        'notes' => 'TEXT NULL'
    ];
    
    foreach ($requiredColumns as $colName => $colType) {
        if (!in_array($colName, $columns)) {
            try {
                $stmt = $conn->exec("ALTER TABLE attendance_records ADD COLUMN {$colName} {$colType}");
                $dbFixes[] = "✅ attendance_records.{$colName} sütunu eklendi";
            } catch (Exception $e) {
                $dbFixes[] = "❌ attendance_records.{$colName} eklenemedi: " . $e->getMessage();
            }
        } else {
            $dbFixes[] = "ℹ️ attendance_records.{$colName} zaten mevcut";
        }
    }
    
    if (!empty($dbFixes)) {
        echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>Veritabanı Sütun Kontrolleri:</h4>";
        echo "<ul>";
        foreach ($dbFixes as $fix) {
            echo "<li>{$fix}</li>";
        }
        echo "</ul>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<strong>❌ Veritabanı bağlantı hatası:</strong> " . $e->getMessage();
    echo "</div>";
}

// Summary report
echo "<h3>📊 Düzeltme Özeti</h3>";
$successCount = 0;
$errorCount = 0;
$cleanCount = 0;

foreach ($fixResults as $file => $result) {
    switch ($result['status']) {
        case 'success': $successCount++; break;
        case 'error': $errorCount++; break;
        case 'clean': $cleanCount++; break;
    }
}

echo "<div style='background: #e9ecef; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<h4>📈 İstatistikler:</h4>";
echo "<ul>";
echo "<li><strong style='color: green;'>Başarılı düzeltmeler:</strong> {$successCount}</li>";
echo "<li><strong style='color: blue;'>Zaten temiz dosyalar:</strong> {$cleanCount}</li>";
echo "<li><strong style='color: red;'>Hatalı işlemler:</strong> {$errorCount}</li>";
echo "<li><strong>Toplam işlenen:</strong> " . count($fixResults) . "</li>";
echo "</ul>";
echo "</div>";

if ($successCount > 0) {
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>🎉 MySQL Format Düzeltmeleri Tamamlandı!</h2>";
    echo "<p>Selim'in QR devam takibi artık doğru şekilde çalışacak.</p>";
    echo "<p><a href='test-qr-attendance-flow.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>🧪 QR Sistemi Test Et</a></p>";
    echo "</div>";
}

// Next steps recommendation
echo "<h3>🔄 Sonraki Adımlar</h3>";
echo "<ol>";
echo "<li><strong>Test Et:</strong> QR kod okutma sistemini test edin</li>";
echo "<li><strong>Kontrol Et:</strong> Selim'in devam kayıtlarını kontrol edin</li>";
echo "<li><strong>İzle:</strong> Sistem loglarını takip edin</li>";
echo "<li><strong>Doğrula:</strong> Tüm devam özeti verilerinin doğru göründüğünü onaylayın</li>";
echo "</ol>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
code { background-color: #f8f9fa; padding: 2px 4px; border-radius: 3px; }
</style>