<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Personel Numarası Alanları Kontrolü</h3>";
    
    // Check table structure
    $stmt = $conn->query("SHOW COLUMNS FROM employees");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>Employee tablosu kolonları:</h4>";
    echo "<ul>";
    foreach ($columns as $column) {
        echo "<li>" . $column['Field'] . " - " . $column['Type'] . "</li>";
    }
    echo "</ul>";
    
    // Check Selim başçam's data
    $stmt = $conn->prepare("SELECT * FROM employees WHERE first_name LIKE '%Selim%' OR last_name LIKE '%başçam%'");
    $stmt->execute();
    $selim = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>Selim başçam kayıtları:</h4>";
    if (!empty($selim)) {
        foreach ($selim as $row) {
            echo "<table border='1'>";
            foreach ($row as $key => $value) {
                echo "<tr><td><strong>$key</strong></td><td>" . htmlspecialchars($value ?: '') . "</td></tr>";
            }
            echo "</table><br>";
        }
    } else {
        echo "Selim başçam bulunamadı.";
    }
    
    // Check all employees with these number mismatches
    echo "<h4>Tüm personeller ve numaraları:</h4>";
    $stmt = $conn->query("SELECT id, first_name, last_name, employee_number, employee_code, tc_identity FROM employees");
    $allEmployees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Ad Soyad</th><th>employee_number</th><th>employee_code</th><th>tc_identity</th></tr>";
    foreach ($allEmployees as $emp) {
        echo "<tr>";
        echo "<td>" . $emp['id'] . "</td>";
        echo "<td>" . htmlspecialchars(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) . "</td>";
        echo "<td>" . htmlspecialchars($emp['employee_number'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($emp['employee_code'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($emp['tc_identity'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "Hata: " . $e->getMessage();
}
?>