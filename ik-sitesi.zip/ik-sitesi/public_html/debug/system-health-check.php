<?php
// Simple system health check without session requirements
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: application/json');

$health_data = [
    'timestamp' => date('Y-m-d H:i:s'),
    'status' => 'checking',
    'php_version' => PHP_VERSION,
    'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'database' => 'disconnected',
    'tables' => [],
    'errors' => [],
    'warnings' => []
];

try {
    // Test database connection
    if ($pdo) {
        $health_data['database'] = 'connected';
        
        // Get table list
        $tables_stmt = $pdo->query("SHOW TABLES");
        $tables = $tables_stmt->fetchAll(PDO::FETCH_COLUMN);
        $health_data['tables'] = $tables;
        $health_data['table_count'] = count($tables);
        
        // Test key tables
        $key_tables = ['companies', 'employees', 'attendance_records', 'qr_locations'];
        foreach ($key_tables as $table) {
            if (in_array($table, $tables)) {
                try {
                    $count_stmt = $pdo->query("SELECT COUNT(*) FROM $table");
                    $count = $count_stmt->fetchColumn();
                    $health_data['tables_data'][$table] = $count;
                } catch (Exception $e) {
                    $health_data['warnings'][] = "Table $table exists but query failed: " . $e->getMessage();
                }
            } else {
                $health_data['errors'][] = "Missing critical table: $table";
            }
        }
        
        // Test QR system components
        try {
            $qr_locations_count = $pdo->query("SELECT COUNT(*) FROM qr_locations WHERE company_id = 4")->fetchColumn();
            $health_data['qr_system']['locations'] = $qr_locations_count;
            
            $active_employees = $pdo->query("SELECT COUNT(*) FROM employees WHERE company_id = 4 AND is_active = 1")->fetchColumn();
            $health_data['qr_system']['active_employees'] = $active_employees;
            
        } catch (Exception $e) {
            $health_data['warnings'][] = "QR system check failed: " . $e->getMessage();
        }
        
    } else {
        $health_data['errors'][] = "Database connection failed";
    }
    
    // Check file system
    $critical_files = [
        '../qr/new-qr-reader.php',
        '../qr/enhanced-qr-scanner.php',
        '../qr/qr-test-simple.php',
        '../includes/qr-attendance-fixed.php',
        '../debug/test-gate-behaviors-direct.php'
    ];
    
    foreach ($critical_files as $file) {
        if (file_exists($file)) {
            $health_data['files'][$file] = 'exists';
        } else {
            $health_data['warnings'][] = "Missing file: $file";
        }
    }
    
    // Overall status
    if (empty($health_data['errors'])) {
        if (empty($health_data['warnings'])) {
            $health_data['status'] = 'healthy';
            $health_data['score'] = 100;
        } else {
            $health_data['status'] = 'warning';
            $health_data['score'] = 75;
        }
    } else {
        $health_data['status'] = 'error';
        $health_data['score'] = 50;
    }
    
} catch (Exception $e) {
    $health_data['status'] = 'error';
    $health_data['errors'][] = "System check failed: " . $e->getMessage();
    $health_data['score'] = 0;
}

echo json_encode($health_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>