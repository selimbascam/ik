<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check test employee password
$employee_number = '30716129672';
$test_password = 'Abc123456';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>Employee Password Debug (Employee: $employee_number)</h2>";
    
    // Get employee data
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, employee_number, password, company_id 
        FROM employees 
        WHERE employee_number = ? OR tc_no = ? OR employee_code = ?
    ");
    $stmt->execute([$employee_number, $employee_number, $employee_number]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ <strong>Employee Found:</strong><br>";
        echo "ID: {$employee['id']}<br>";
        echo "Name: {$employee['first_name']} {$employee['last_name']}<br>";
        echo "Employee Number: {$employee['employee_number']}<br>";
        echo "Company ID: {$employee['company_id']}<br>";
        
        $currentPassword = $employee['password'] ?? 'NULL';
        echo "Current Password Hash: " . (strlen($currentPassword) > 50 ? substr($currentPassword, 0, 50) . '...' : $currentPassword) . "<br>";
        echo "Password Length: " . strlen($currentPassword) . "<br>";
        echo "</div>";
        
        // Test different password verification methods
        echo "<h3>Password Verification Tests:</h3>";
        
        // Test 1: Plain text
        if ($currentPassword === $test_password) {
            echo "✅ Plain text match<br>";
        } else {
            echo "❌ Plain text NO match<br>";
        }
        
        // Test 2: MD5
        if (md5($test_password) === $currentPassword) {
            echo "✅ MD5 hash match<br>";
        } else {
            echo "❌ MD5 hash NO match (expected: " . md5($test_password) . ")<br>";
        }
        
        // Test 3: password_verify (Argon2ID/bcrypt)
        if (password_verify($test_password, $currentPassword)) {
            echo "✅ password_verify match (Argon2ID/bcrypt)<br>";
        } else {
            echo "❌ password_verify NO match<br>";
        }
        
        // Test 4: PASSWORD() function (MySQL)
        $stmt = $conn->prepare("SELECT PASSWORD(?) as mysql_hash");
        $stmt->execute([$test_password]);
        $mysqlHash = $stmt->fetch(PDO::FETCH_ASSOC)['mysql_hash'];
        if ($mysqlHash === $currentPassword) {
            echo "✅ MySQL PASSWORD() match<br>";
        } else {
            echo "❌ MySQL PASSWORD() NO match (expected: $mysqlHash)<br>";
        }
        
        // Solution: Update password with Argon2ID
        echo "<h3>🔧 Fix Solution:</h3>";
        $newHash = password_hash($test_password, PASSWORD_ARGON2ID);
        
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "Recommended fix: Update password to Argon2ID hash<br>";
        echo "New hash: " . substr($newHash, 0, 50) . "...<br>";
        echo "<br>";
        echo "<strong>SQL Command:</strong><br>";
        echo "<code style='background: #f8f9fa; padding: 5px;'>";
        echo "UPDATE employees SET password = '$newHash' WHERE id = {$employee['id']};";
        echo "</code>";
        echo "</div>";
        
        // Auto-fix option
        if (isset($_GET['fix']) && $_GET['fix'] === 'auto') {
            $updateStmt = $conn->prepare("UPDATE employees SET password = ? WHERE id = ?");
            if ($updateStmt->execute([$newHash, $employee['id']])) {
                echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
                echo "✅ <strong>Password Updated Successfully!</strong><br>";
                echo "Employee {$employee['employee_number']} can now login with password: $test_password";
                echo "</div>";
            } else {
                echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
                echo "❌ <strong>Update Failed</strong>";
                echo "</div>";
            }
        } else {
            echo "<a href='?fix=auto' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0;'>🔧 Auto-Fix Password</a>";
        }
        
    } else {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ <strong>Employee Not Found</strong><br>";
        echo "Employee number '$employee_number' not found in database";
        echo "</div>";
        
        // Check if any employees exist
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees");
        $stmt->execute();
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "Total employees in database: $count<br>";
        
        if ($count > 0) {
            $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number, tc_no, employee_code FROM employees LIMIT 5");
            $stmt->execute();
            $samples = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<h3>Sample employees:</h3>";
            foreach ($samples as $emp) {
                echo "ID: {$emp['id']}, Name: {$emp['first_name']} {$emp['last_name']}, Number: {$emp['employee_number']}, TC: {$emp['tc_no']}, Code: {$emp['employee_code']}<br>";
            }
        }
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ <strong>Database Error:</strong> " . $e->getMessage();
    echo "</div>";
}
?>