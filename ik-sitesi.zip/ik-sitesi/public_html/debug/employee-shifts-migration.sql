-- Employee Shifts Foreign Key Constraint Düzeltme
-- Problem: employee_shifts tablosu mevcut olmayan 'shifts' tablosuna referans veriyor
-- Çözüm: Doğru 'shift_templates' referansı oluştur

-- 1. Mevcut foreign key constraints'i kontrol et ve sil
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'employee_shifts'
AND REFERENCED_TABLE_NAME IS NOT NULL;

-- 2. Hatalı foreign key'i sil (shifts tablosuna referans veren)
-- ALTER TABLE employee_shifts DROP FOREIGN KEY employee_shifts_ibfk_3;

-- 3. shift_id kolonu varsa shift_template_id olarak değiştir
-- ALTER TABLE employee_shifts CHANGE shift_id shift_template_id INT;

-- 4. Doğru foreign key constraint ekle
-- ALTER TABLE employee_shifts 
-- ADD CONSTRAINT fk_employee_shifts_template 
-- FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE;

-- 5. Test query - bu başarılı olmalı
-- INSERT INTO employee_shifts 
-- (employee_id, shift_template_id, shift_date, status) 
-- VALUES (1, 1, '2025-08-15', 'scheduled');

-- 6. Temizlik
-- DELETE FROM employee_shifts WHERE shift_date = '2025-08-15' AND employee_id = 1;

-- 7. Tablo yapısını kontrol et
DESCRIBE employee_shifts;

-- 8. Foreign key'leri tekrar kontrol et
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'employee_shifts'
AND REFERENCED_TABLE_NAME IS NOT NULL;