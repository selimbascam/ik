<?php
/**
 * QR Action Tester - Simulate QR actions for testing
 */

require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/qr-attendance-fixed.php';

header('Content-Type: text/html; charset=utf-8');

// Get parameters
$action = $_GET['action'] ?? '';
$employeeId = (int)($_GET['employee_id'] ?? 1);
$companyId = (int)($_GET['company_id'] ?? 1);
$locationId = (int)($_GET['location_id'] ?? 13);
$today = date('Y-m-d');

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Action Test Result</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #059669; background: #d1fae5; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .error { color: #dc2626; background: #fee2e2; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .info { color: #0369a1; background: #dbeafe; padding: 15px; border-radius: 8px; margin: 15px 0; }
        h1 { color: #1f2937; text-align: center; }
        .back-button { display: inline-block; background: #6b7280; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 10px 5px; }
        .back-button:hover { background: #4b5563; }
        pre { background: #f9fafb; padding: 10px; border-radius: 5px; overflow: auto; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 QR Action Test</h1>
        
        <?php
        if (!$action) {
            echo "<div class='error'>❌ No action specified</div>";
        } else {
            echo "<div class='info'>🎯 Testing Action: <strong>" . strtoupper($action) . "</strong></div>";
            
            try {
                $conn = Database::getInstance()->getConnection();
                
                // Get location info
                $stmt = $conn->prepare("SELECT name FROM qr_locations WHERE id = ?");
                $stmt->execute([$locationId]);
                $location = $stmt->fetch(PDO::FETCH_ASSOC);
                $locationName = $location['name'] ?? "Test Location $locationId";
                
                // Execute the action
                $success = QRAttendanceHelper::updateAttendanceRecord(
                    $conn, $employeeId, $companyId, $action, $locationName, $locationId, $today
                );
                
                if ($success) {
                    $actionMessages = [
                        'check_in' => '🟢 İşe giriş başarılı',
                        'break_start' => '🟡 Mola başlatıldı',
                        'break_end' => '🟢 Mola bitirildi',
                        'check_out' => '🔴 İşten çıkış yapıldı'
                    ];
                    
                    $message = $actionMessages[$action] ?? 'Kayıt güncellendi';
                    
                    echo "<div class='success'>";
                    echo "<h2>✅ $message</h2>";
                    echo "<p><strong>Konum:</strong> $locationName</p>";
                    echo "<p><strong>Zaman:</strong> " . date('Y-m-d H:i:s') . "</p>";
                    echo "</div>";
                    
                    // Show current status
                    $colMap = QRAttendanceHelper::getColumnMapping($conn);
                    $stmt = $conn->prepare("
                        SELECT 
                            {$colMap['check_in']} as check_in,
                            {$colMap['check_out']} as check_out,
                            {$colMap['break_start']} as break_start,
                            {$colMap['break_end']} as break_end,
                            work_minutes
                        FROM attendance_records 
                        WHERE employee_id = ? AND {$colMap['date']} = ?
                    ");
                    $stmt->execute([$employeeId, $today]);
                    $record = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($record) {
                        echo "<div class='info'>";
                        echo "<h3>📋 Current Status</h3>";
                        echo "<pre>" . json_encode($record, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
                        echo "</div>";
                    }
                    
                } else {
                    echo "<div class='error'>❌ Action failed to execute</div>";
                }
                
            } catch (Exception $e) {
                echo "<div class='error'>";
                echo "<h2>❌ Error</h2>";
                echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
                echo "</div>";
            }
        }
        ?>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="complete-qr-test.php" class="back-button">🔙 Back to Tests</a>
            <a href="../qr/qr-reader.php" class="back-button">📱 QR Reader</a>
        </div>
    </div>
</body>
</html>