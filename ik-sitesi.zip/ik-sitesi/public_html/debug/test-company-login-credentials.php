<?php
/**
 * Company Login Credentials Test
 * Test specific credentials: zeynep@szb.com.tr / Abc123456 / SZB01164
 */

require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=utf-8');

// Test credentials - company code no longer required
$testEmail = 'zeynep@szb.com.tr';
$testPassword = 'Abc123456';

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Login Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #059669; background: #d1fae5; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .error { color: #dc2626; background: #fee2e2; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .warning { color: #d97706; background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .info { color: #0369a1; background: #dbeafe; padding: 15px; border-radius: 8px; margin: 15px 0; }
        h1, h2 { color: #1f2937; }
        pre { background: #f9fafb; padding: 10px; border-radius: 5px; overflow: auto; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #f8f9fa; font-weight: bold; }
        .fix-button { background: #dc2626; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block; }
        .fix-button:hover { background: #b91c1c; }
        .credentials { background: #f0f9ff; padding: 15px; border-radius: 8px; margin: 15px 0; border: 2px solid #0369a1; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔐 Company Login Credentials Test</h1>
        
        <div class="credentials">
            <h3>🎯 Testing Credentials:</h3>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($testEmail); ?></p>
            <p><strong>Password:</strong> <?php echo htmlspecialchars($testPassword); ?></p>
            <p><em>Şirket kodu artık gerekli değil - sadece e-posta ve şifre ile giriş</em></p>
        </div>
        
        <?php
        try {
            $conn = Database::getInstance()->getConnection();
            
            // Test 1: Check companies table structure
            echo "<h2>📊 Test 1: Companies Table Structure</h2>";
            $stmt = $conn->query("SHOW COLUMNS FROM companies");
            $companyColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            echo "<div class='info'>Available columns: " . implode(', ', $companyColumns) . "</div>";
            
            // Map column names for compatibility
            $emailCol = in_array('email', $companyColumns) ? 'email' : 
                       (in_array('admin_email', $companyColumns) ? 'admin_email' : 'email');
                       
            $codeCol = in_array('company_code', $companyColumns) ? 'company_code' : 
                      (in_array('code', $companyColumns) ? 'code' : 'company_code');
                      
            $nameCol = in_array('company_name', $companyColumns) ? 'company_name' : 
                      (in_array('name', $companyColumns) ? 'name' : 'company_name');
            
            $hasPassword = in_array('password', $companyColumns);
            
            echo "<div class='info'>";
            echo "Using email column: <strong>$emailCol</strong><br>";
            echo "Using code column: <strong>$codeCol</strong><br>";
            echo "Using name column: <strong>$nameCol</strong><br>";
            echo "Password column exists: " . ($hasPassword ? "✅ Yes" : "❌ No") . "<br>";
            echo "</div>";
            
            // Test 2: Search for company by email
            echo "<h2>🔍 Test 2: Search Company by Email</h2>";
            
            $stmt = $conn->prepare("SELECT * FROM companies WHERE $emailCol = ?");
            $stmt->execute([$testEmail]);
            $companyByEmail = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($companyByEmail) {
                echo "<div class='success'>✅ Company found by email</div>";
                echo "<table>";
                foreach ($companyByEmail as $key => $value) {
                    echo "<tr><td><strong>$key</strong></td><td>" . htmlspecialchars($value) . "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<div class='error'>❌ No company found with email: $testEmail</div>";
                
                // Show similar emails
                $stmt = $conn->prepare("SELECT $emailCol, $nameCol FROM companies WHERE $emailCol LIKE ?");
                $stmt->execute(['%szb%']);
                $similarEmails = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if ($similarEmails) {
                    echo "<div class='warning'>Similar emails found:</div>";
                    echo "<table>";
                    echo "<tr><th>Email</th><th>Company Name</th></tr>";
                    foreach ($similarEmails as $email) {
                        echo "<tr><td>{$email[$emailCol]}</td><td>{$email[$nameCol]}</td></tr>";
                    }
                    echo "</table>";
                }
            }
            
            // Test 3: Search by company code
            echo "<h2>🏢 Test 3: Search by Company Code</h2>";
            
            if ($codeCol !== 'company_code') {
                echo "<div class='warning'>Note: Using '$codeCol' column instead of 'company_code'</div>";
            }
            
            $stmt = $conn->prepare("SELECT * FROM companies WHERE $codeCol = ?");
            $stmt->execute([$testCompanyCode]);
            $companyByCode = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($companyByCode) {
                echo "<div class='success'>✅ Company found by code</div>";
                echo "<table>";
                foreach ($companyByCode as $key => $value) {
                    echo "<tr><td><strong>$key</strong></td><td>" . htmlspecialchars($value) . "</td></tr>";
                }
                echo "</table>";
            } else {
                echo "<div class='error'>❌ No company found with code: $testCompanyCode</div>";
                
                // Show all company codes
                $stmt = $conn->query("SELECT $codeCol, $nameCol FROM companies WHERE $codeCol IS NOT NULL AND $codeCol != ''");
                $allCodes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if ($allCodes) {
                    echo "<div class='info'>Available company codes:</div>";
                    echo "<table>";
                    echo "<tr><th>Code</th><th>Company Name</th></tr>";
                    foreach ($allCodes as $code) {
                        echo "<tr><td>{$code[$codeCol]}</td><td>{$code[$nameCol]}</td></tr>";
                    }
                    echo "</table>";
                }
            }
            
            // Test 4: Password authentication test
            echo "<h2>🔐 Test 4: Password Authentication</h2>";
            
            if (!$hasPassword) {
                echo "<div class='error'>❌ Password column missing from companies table</div>";
                echo "<div class='warning'>";
                echo "<h3>🔧 Fix Available</h3>";
                echo "<p>The password column is missing. You can add it and set up authentication:</p>";
                echo "<a href='?action=add_password_column' class='fix-button'>Add Password Column</a>";
                echo "</div>";
            } else {
                // Test different password hashing methods
                $authMethods = [
                    'MD5' => "SELECT * FROM companies WHERE $emailCol = ? AND password = MD5(?)",
                    'Plain Text' => "SELECT * FROM companies WHERE $emailCol = ? AND password = ?",
                    'PASSWORD()' => "SELECT * FROM companies WHERE $emailCol = ? AND password = PASSWORD(?)"
                ];
                
                $authSuccess = false;
                $matchedCompany = null;
                
                foreach ($authMethods as $method => $query) {
                    try {
                        $stmt = $conn->prepare($query);
                        $stmt->execute([$testEmail, $testPassword]);
                        $result = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($result) {
                            echo "<div class='success'>✅ Authentication successful with $method</div>";
                            $authSuccess = true;
                            $matchedCompany = $result;
                            break;
                        } else {
                            echo "<div class='info'>ℹ️ $method authentication failed</div>";
                        }
                    } catch (PDOException $e) {
                        echo "<div class='error'>❌ $method test error: " . htmlspecialchars($e->getMessage()) . "</div>";
                    }
                }
                
                if (!$authSuccess) {
                    echo "<div class='error'>❌ All authentication methods failed</div>";
                    
                    // Check if company exists but password is wrong
                    if ($companyByEmail) {
                        echo "<div class='warning'>";
                        echo "<h3>🔧 Fix Available</h3>";
                        echo "<p>Company exists but password doesn't match. You can reset the password:</p>";
                        echo "<a href='?action=reset_password&company_id={$companyByEmail['id']}' class='fix-button'>Reset Password to Abc123456</a>";
                        echo "</div>";
                    }
                }
            }
            
            // Test 5: Complete login simulation
            echo "<h2>🎯 Test 5: Complete Login Simulation</h2>";
            
            if ($companyByEmail && $hasPassword) {
                // Simulate the exact login process (simplified - no company code)
                echo "<div class='info'>Simulating complete login process (email + password only)...</div>";
                
                try {
                    // Test with MD5 (most common)
                    $stmt = $conn->prepare("
                        SELECT * FROM companies 
                        WHERE $emailCol = ? AND password = MD5(?)
                    ");
                    $stmt->execute([$testEmail, $testPassword]);
                    $loginResult = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($loginResult) {
                        echo "<div class='success'>✅ Complete login simulation successful!</div>";
                        echo "<div class='success'>Company authenticated: {$loginResult[$nameCol]}</div>";
                        echo "<div class='info'>Şirket kodu: " . ($loginResult[$codeCol] ?? 'Yok') . "</div>";
                    } else {
                        echo "<div class='error'>❌ Complete login simulation failed</div>";
                        echo "<div class='error'>Email + Password combination fails</div>";
                    }
                } catch (PDOException $e) {
                    echo "<div class='error'>Login simulation error: " . htmlspecialchars($e->getMessage()) . "</div>";
                }
            } else {
                echo "<div class='warning'>Cannot simulate login - missing company data or password column</div>";
            }
            
            // Handle fix actions
            if (isset($_GET['action'])) {
                echo "<h2>🛠️ Applying Fix</h2>";
                
                switch ($_GET['action']) {
                    case 'add_password_column':
                        try {
                            $conn->exec("ALTER TABLE companies ADD COLUMN password VARCHAR(255) DEFAULT NULL");
                            echo "<div class='success'>✅ Added password column to companies table</div>";
                        } catch (PDOException $e) {
                            echo "<div class='error'>❌ Failed to add password column: " . htmlspecialchars($e->getMessage()) . "</div>";
                        }
                        break;
                        
                    case 'reset_password':
                        $companyId = (int)$_GET['company_id'];
                        try {
                            $stmt = $conn->prepare("UPDATE companies SET password = MD5(?) WHERE id = ?");
                            $stmt->execute([$testPassword, $companyId]);
                            echo "<div class='success'>✅ Password reset to MD5 hash of '$testPassword' for company ID $companyId</div>";
                        } catch (PDOException $e) {
                            echo "<div class='error'>❌ Failed to reset password: " . htmlspecialchars($e->getMessage()) . "</div>";
                        }
                        break;
                }
                
                echo "<a href='?' class='fix-button' style='background: #059669;'>🔄 Re-run Tests</a>";
            }
            
        } catch (Exception $e) {
            echo "<div class='error'>";
            echo "<h2>❌ Critical Error</h2>";
            echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
            echo "</div>";
        }
        ?>
        
        <div style="margin-top: 30px; text-align: center;">
            <a href="../auth/company-login.php" style="background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🔙 Back to Company Login</a>
            <a href="../debug/company-login-debug.php" style="background: #6b7280; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🔧 General Debug</a>
        </div>
    </div>
</body>
</html>