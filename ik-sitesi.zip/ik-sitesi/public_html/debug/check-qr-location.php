<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>QR Locations Check</h2>";
    
    // Check if qr_locations table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'qr_locations'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✅ qr_locations table exists</p>";
        
        // Check all QR locations
        $stmt = $conn->query("SELECT * FROM qr_locations");
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>All QR Locations:</h3>";
        echo "<pre>" . print_r($locations, true) . "</pre>";
        
        // Check specifically location ID 1
        $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE id = 1");
        $stmt->execute();
        $location1 = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($location1) {
            echo "<p>✅ Location ID 1 found:</p>";
            echo "<pre>" . print_r($location1, true) . "</pre>";
        } else {
            echo "<p>❌ Location ID 1 NOT found</p>";
            
            // Check if company ID 1 has any locations
            $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = 1");
            $stmt->execute();
            $company1Locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<h3>Company ID 1 locations:</h3>";
            echo "<pre>" . print_r($company1Locations, true) . "</pre>";
        }
        
    } else {
        echo "<p>❌ qr_locations table does NOT exist</p>";
        
        // Check what tables do exist
        $stmt = $conn->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "<h3>Available tables:</h3>";
        echo "<pre>" . print_r($tables, true) . "</pre>";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>