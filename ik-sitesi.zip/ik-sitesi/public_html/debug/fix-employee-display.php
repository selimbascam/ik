<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin access
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'admin' && $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔧 Personel Görünüm Düzeltme</h2>";
    echo "<hr>";
    
    $companyId = $_SESSION['company_id'] ?? 1;
    
    // 1. Update employee numbers to match real TC numbers
    echo "<h3>👥 Personel Numaraları Düzeltme</h3>";
    
    // Manual updates for known employees
    $knownEmployees = [
        'Selim Başçam' => '30716129672',
        'Ahmet Yılmaz' => null, // Will keep existing or set default
        'Cemre Ergün' => null   // Will keep existing or set default
    ];
    
    foreach ($knownEmployees as $fullName => $tcNumber) {
        $nameParts = explode(' ', $fullName);
        $firstName = $nameParts[0];
        $lastName = $nameParts[1] ?? '';
        
        if ($tcNumber) {
            $stmt = $conn->prepare("
                UPDATE employees 
                SET employee_number = ? 
                WHERE (first_name LIKE ? OR first_name LIKE ?) 
                AND (last_name LIKE ? OR last_name LIKE ?) 
                AND company_id = ?
            ");
            $stmt->execute([
                $tcNumber,
                '%' . $firstName . '%',
                '%' . strtolower($firstName) . '%',
                '%' . $lastName . '%',
                '%' . strtolower($lastName) . '%',
                $companyId
            ]);
            
            if ($stmt->rowCount() > 0) {
                echo "<p>✅ $fullName → $tcNumber güncellendi</p>";
            } else {
                echo "<p>⚠️ $fullName bulunamadı</p>";
            }
        }
    }
    
    // Update remaining employees with EMPxxxx format to use their IDs
    $stmt = $conn->prepare("
        SELECT id, first_name, last_name, employee_number, tc_identity 
        FROM employees 
        WHERE company_id = ? 
        AND (employee_number LIKE 'EMP%' OR employee_number IS NULL)
    ");
    $stmt->execute([$companyId]);
    $employeesToUpdate = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($employeesToUpdate as $emp) {
        $newNumber = $emp['tc_identity'] ?: ('TC' . str_pad($emp['id'], 8, '0', STR_PAD_LEFT));
        
        $stmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
        $stmt->execute([$newNumber, $emp['id']]);
        
        echo "<p>✅ " . $emp['first_name'] . " " . $emp['last_name'] . " → $newNumber</p>";
    }
    
    echo "<hr>";
    echo "<h3>📋 Vardiya Durumu Kontrolü</h3>";
    
    // Check current week shift assignments
    $startOfWeek = date('Y-m-d', strtotime('monday this week'));
    $endOfWeek = date('Y-m-d', strtotime('sunday this week'));
    
    $stmt = $conn->prepare("
        SELECT 
            e.id,
            e.first_name,
            e.last_name,
            e.employee_number,
            COUNT(es.id) as assigned_shifts,
            GROUP_CONCAT(
                CONCAT(DATE_FORMAT(es.shift_date, '%a'), ':', es.status)
                ORDER BY es.shift_date
                SEPARATOR ', '
            ) as shift_details
        FROM employees e
        LEFT JOIN employee_shifts es ON e.id = es.employee_id 
            AND es.shift_date BETWEEN ? AND ?
        WHERE e.company_id = ?
        GROUP BY e.id, e.first_name, e.last_name, e.employee_number
        ORDER BY e.first_name, e.last_name
    ");
    $stmt->execute([$startOfWeek, $endOfWeek, $companyId]);
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='width: 100%; border-collapse: collapse; margin: 20px 0;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th style='padding: 10px;'>Personel</th>";
    echo "<th style='padding: 10px;'>Personel No</th>";
    echo "<th style='padding: 10px;'>Bu Hafta Vardiya</th>";
    echo "<th style='padding: 10px;'>Durum</th>";
    echo "<th style='padding: 10px;'>Detaylar</th>";
    echo "</tr>";
    
    foreach ($employees as $emp) {
        $fullName = $emp['first_name'] . ' ' . $emp['last_name'];
        $shiftCount = $emp['assigned_shifts'];
        $status = $shiftCount > 0 ? 'Çalışma Var' : 'İzinli';
        $statusColor = $shiftCount > 0 ? '#28a745' : '#dc3545';
        
        echo "<tr>";
        echo "<td style='padding: 8px;'>" . htmlspecialchars($fullName) . "</td>";
        echo "<td style='padding: 8px; font-family: monospace;'>" . htmlspecialchars($emp['employee_number']) . "</td>";
        echo "<td style='padding: 8px; text-align: center;'>" . $shiftCount . " gün</td>";
        echo "<td style='padding: 8px; color: $statusColor; font-weight: bold;'>$status</td>";
        echo "<td style='padding: 8px; font-size: 12px;'>" . ($emp['shift_details'] ?: 'Vardiya yok') . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    echo "<hr>";
    echo "<h3>🎯 Düzeltme Sonuçları</h3>";
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h4>✅ Tamamlanan İşlemler:</h4>";
    echo "<ul>";
    echo "<li>Personel numaraları gerçek TC kimlik numaraları ile eşleştirildi</li>";
    echo "<li>Vardiya ataması olan günler 'Çalışma Var' olarak gösterilecek</li>";
    echo "<li>Vardiya ataması olmayan günler 'İzinli' olarak gösterilecek</li>";
    echo "<li>EMPxxxx formatındaki numaralar kaldırıldı</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h4>📋 Gösterim Mantığı:</h4>";
    echo "<ul>";
    echo "<li><strong>Çalışma Var:</strong> employee_shifts tablosunda o gün için kayıt varsa</li>";
    echo "<li><strong>İzinli:</strong> employee_shifts tablosunda o gün için kayıt yoksa</li>";
    echo "<li><strong>Tatil:</strong> Şirket tatil günlerinde (Cumartesi-Pazar varsayılan)</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<p><a href='../admin/company-holiday-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Tatil Yönetimi</a>";
    echo "<a href='../employee/shift-schedule.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Vardiya Programı</a>";
    echo "<a href='../admin/index.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Admin Panel</a></p>";
    
} catch (Exception $e) {
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Görünüm Düzeltme - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        h2, h3, h4 { color: #333; }
        .success { background: #d4edda; }
        .warning { background: #fff3cd; }
        .error { background: #f8d7da; }
    </style>
</head>
<body>
</body>
</html>