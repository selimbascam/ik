<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔧 QR Veritabanı Insert Sorunu Düzeltme</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if QR locations table exists
    echo "<h3>📍 QR Lokasyonları Kontrolü</h3>";
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations");
        $locationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>✅ qr_locations tablosu mevcut ({$locationCount} lokasyon)</p>";
        
        if ($locationCount == 0) {
            echo "<p style='color: orange;'>⚠️ QR lokasyon bulunamadı, varsayılan lokasyon oluşturuluyor...</p>";
            
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (name, address, latitude, longitude, tolerance_meters, is_active, created_at)
                VALUES ('Ana Ofis', 'Merkez Lokasyon', 41.0082, 28.9784, 100, 1, NOW())
            ");
            $stmt->execute();
            $locationId = $conn->lastInsertId();
            echo "<p>✅ Varsayılan QR lokasyon oluşturuldu (ID: {$locationId})</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ QR lokasyon tablosu sorunu: " . $e->getMessage() . "</p>";
        
        // Create QR locations table if missing
        echo "<p>🔧 qr_locations tablosu oluşturuluyor...</p>";
        $stmt = $conn->exec("
            CREATE TABLE IF NOT EXISTS qr_locations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                address TEXT,
                latitude DECIMAL(10, 8),
                longitude DECIMAL(11, 8),
                tolerance_meters INT DEFAULT 100,
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ");
        
        // Insert default location
        $stmt = $conn->prepare("
            INSERT INTO qr_locations (name, address, latitude, longitude, tolerance_meters, is_active, created_at)
            VALUES ('Ana Ofis', 'Merkez Lokasyon', 41.0082, 28.9784, 100, 1, NOW())
        ");
        $stmt->execute();
        echo "<p>✅ qr_locations tablosu ve varsayılan lokasyon oluşturuldu</p>";
    }
    
    // Check attendance_records table structure
    echo "<h3>📋 Attendance Records Tablo Yapısı</h3>";
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $requiredColumns = [
        'employee_id' => 'INT',
        'qr_location_id' => 'INT',
        'activity_type' => 'VARCHAR',
        'check_in_time' => 'TIME',
        'latitude' => 'DECIMAL',
        'longitude' => 'DECIMAL',
        'notes' => 'TEXT',
        'created_at' => 'TIMESTAMP'
    ];
    
    $existingColumns = [];
    foreach ($columns as $col) {
        $existingColumns[$col['Field']] = $col['Type'];
    }
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Sütun</th><th>Gerekli Tip</th><th>Mevcut Durumu</th><th>Aksiyon</th></tr>";
    
    $missingColumns = [];
    foreach ($requiredColumns as $colName => $colType) {
        echo "<tr>";
        echo "<td>{$colName}</td>";
        echo "<td>{$colType}</td>";
        
        if (isset($existingColumns[$colName])) {
            echo "<td style='color: green;'>✅ Mevcut ({$existingColumns[$colName]})</td>";
            echo "<td>-</td>";
        } else {
            echo "<td style='color: red;'>❌ Eksik</td>";
            echo "<td style='color: orange;'>Eklenecek</td>";
            $missingColumns[] = $colName;
        }
        echo "</tr>";
    }
    echo "</table>";
    
    // Add missing columns
    if (!empty($missingColumns)) {
        echo "<h4>🔧 Eksik Sütunlar Ekleniyor</h4>";
        
        foreach ($missingColumns as $colName) {
            try {
                switch ($colName) {
                    case 'qr_location_id':
                        $stmt = $conn->exec("ALTER TABLE attendance_records ADD COLUMN qr_location_id INT NULL");
                        break;
                    case 'latitude':
                        $stmt = $conn->exec("ALTER TABLE attendance_records ADD COLUMN latitude DECIMAL(10, 8) NULL");
                        break;
                    case 'longitude':
                        $stmt = $conn->exec("ALTER TABLE attendance_records ADD COLUMN longitude DECIMAL(11, 8) NULL");
                        break;
                    case 'notes':
                        $stmt = $conn->exec("ALTER TABLE attendance_records ADD COLUMN notes TEXT NULL");
                        break;
                }
                echo "<p>✅ {$colName} sütunu eklendi</p>";
            } catch (Exception $e) {
                echo "<p style='color: red;'>❌ {$colName} sütunu eklenemedi: " . $e->getMessage() . "</p>";
            }
        }
    }
    
    // Test the actual QR scan process
    echo "<h3>🧪 QR Tarama İşlemi Testi</h3>";
    
    // Find first employee
    $stmt = $conn->query("SELECT id, first_name, last_name FROM employees LIMIT 1");
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$testEmployee) {
        echo "<p style='color: red;'>❌ Test için personel bulunamadı</p>";
    } else {
        echo "<p>Test personeli: {$testEmployee['first_name']} {$testEmployee['last_name']} (ID: {$testEmployee['id']})</p>";
        
        // Get QR location
        $stmt = $conn->query("SELECT id FROM qr_locations WHERE is_active = 1 LIMIT 1");
        $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$qrLocation) {
            echo "<p style='color: red;'>❌ Aktif QR lokasyon bulunamadı</p>";
        } else {
            echo "<p>QR Lokasyon ID: {$qrLocation['id']}</p>";
            
            // Test insert
            $currentTime = date('H:i:s');
            $currentDateTime = date('Y-m-d H:i:s');
            
            try {
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records (
                        employee_id, qr_location_id, activity_type, 
                        check_in_time, latitude, longitude, 
                        notes, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $result = $stmt->execute([
                    $testEmployee['id'],
                    $qrLocation['id'],
                    'work_in',
                    $currentTime,
                    41.0082,
                    28.9784,
                    'QR düzeltme testi - ' . date('Y-m-d H:i:s'),
                    $currentDateTime
                ]);
                
                if ($result) {
                    $insertId = $conn->lastInsertId();
                    echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px;'>";
                    echo "<p><strong>✅ Test QR kayıt başarılı!</strong></p>";
                    echo "<p>Yeni kayıt ID: {$insertId}</p>";
                    echo "<p>Zaman: {$currentTime}</p>";
                    echo "<p>Aktivite: work_in</p>";
                    echo "</div>";
                } else {
                    echo "<p style='color: red;'>❌ Test kayıt başarısız</p>";
                    $errorInfo = $stmt->errorInfo();
                    echo "<p>SQL Hatası: " . $errorInfo[2] . "</p>";
                }
                
            } catch (Exception $e) {
                echo "<p style='color: red;'>❌ Test kayıt hatası: " . $e->getMessage() . "</p>";
            }
        }
    }
    
    // Show recent attendance records
    echo "<h3>📊 Son Devam Kayıtları</h3>";
    $stmt = $conn->prepare("
        SELECT 
            ar.*,
            e.first_name,
            e.last_name,
            ql.name as location_name
        FROM attendance_records ar
        LEFT JOIN employees e ON ar.employee_id = e.id
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        ORDER BY ar.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recentRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($recentRecords)) {
        echo "<p>❌ Hiç devam kaydı bulunamadı</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
        echo "<tr><th>ID</th><th>Personel</th><th>Aktivite</th><th>Saat</th><th>Lokasyon</th><th>Tarih</th></tr>";
        
        foreach ($recentRecords as $record) {
            echo "<tr>";
            echo "<td>{$record['id']}</td>";
            echo "<td>{$record['first_name']} {$record['last_name']}</td>";
            echo "<td>{$record['activity_type']}</td>";
            echo "<td>{$record['check_in_time']}</td>";
            echo "<td>" . ($record['location_name'] ?? 'N/A') . "</td>";
            echo "<td>" . date('d.m.Y H:i', strtotime($record['created_at'])) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Genel Hata</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
</style>