<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/error-logger.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$message = '';
$messageType = '';
$diagnostics = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    function addDiagnostic($type, $title, $details) {
        global $diagnostics;
        $diagnostics[] = [
            'type' => $type,
            'title' => $title,
            'details' => $details
        ];
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix_action'])) {
        switch ($_POST['fix_action']) {
            case 'fix_employee_shifts_table':
                try {
                    // Check current table structure
                    $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll(PDO::FETCH_ASSOC);
                    $columnNames = array_column($columns, 'Field');
                    
                    $steps = [];
                    
                    // Add missing shift_date column
                    if (!in_array('shift_date', $columnNames)) {
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_date DATE NOT NULL DEFAULT CURRENT_DATE");
                        $steps[] = "✅ shift_date column added to employee_shifts table";
                    } else {
                        $steps[] = "ℹ️ shift_date column already exists";
                    }
                    
                    // Add missing shift_template_id column if needed
                    if (!in_array('shift_template_id', $columnNames)) {
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT DEFAULT NULL");
                        $steps[] = "✅ shift_template_id column added to employee_shifts table";
                    } else {
                        $steps[] = "ℹ️ shift_template_id column already exists";
                    }
                    
                    // Add status column if missing
                    if (!in_array('status', $columnNames)) {
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN status ENUM('scheduled', 'in_progress', 'completed', 'missed', 'cancelled') DEFAULT 'scheduled'");
                        $steps[] = "✅ status column added to employee_shifts table";
                    } else {
                        $steps[] = "ℹ️ status column already exists";
                    }
                    
                    $message = "🔧 Employee Shifts Table Fixed:<br>" . implode('<br>', $steps);
                    $messageType = "success";
                    addDiagnostic('success', 'Table Fix Complete', 'employee_shifts table structure corrected');
                } catch (Exception $e) {
                    $message = "❌ Failed to fix employee_shifts table: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Table Fix Failed', $e->getMessage());
                }
                break;
                
            case 'create_shift_templates_table':
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS shift_templates (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            name VARCHAR(100) NOT NULL,
                            start_time TIME NOT NULL,
                            end_time TIME NOT NULL,
                            break_duration INT DEFAULT 0 COMMENT 'Minutes',
                            is_active BOOLEAN DEFAULT 1,
                            color_code VARCHAR(7) DEFAULT '#3B82F6',
                            description TEXT,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            INDEX idx_company_active (company_id, is_active)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    
                    // Add default shift templates
                    $defaultShifts = [
                        ['Sabah Vardiyası', '08:00:00', '17:00:00', 60, '#3B82F6', 'Standart sabah vardiyası (8:00-17:00, 1 saat mola)'],
                        ['Öğle Vardiyası', '12:00:00', '21:00:00', 60, '#10B981', 'Öğle vardiyası (12:00-21:00, 1 saat mola)'],
                        ['Gece Vardiyası', '22:00:00', '06:00:00', 30, '#8B5CF6', 'Gece vardiyası (22:00-06:00, 30 dk mola)'],
                        ['Yarım Gün', '08:00:00', '13:00:00', 30, '#F59E0B', 'Yarım gün çalışma (8:00-13:00, 30 dk mola)']
                    ];

                    foreach ($defaultShifts as $shift) {
                        $stmt = $conn->prepare("
                            INSERT IGNORE INTO shift_templates (company_id, name, start_time, end_time, break_duration, color_code, description)
                            VALUES (1, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute($shift);
                    }
                    
                    $message = "✅ shift_templates table created with default templates";
                    $messageType = "success";
                    addDiagnostic('success', 'Table Created', 'shift_templates table created with default data');
                } catch (Exception $e) {
                    $message = "❌ Failed to create shift_templates table: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Table Creation Failed', $e->getMessage());
                }
                break;
                
            case 'comprehensive_shift_fix':
                $steps = [];
                
                // Step 1: Create shift_templates table
                try {
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS shift_templates (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            company_id INT NOT NULL,
                            name VARCHAR(100) NOT NULL,
                            start_time TIME NOT NULL,
                            end_time TIME NOT NULL,
                            break_duration INT DEFAULT 0 COMMENT 'Minutes',
                            is_active BOOLEAN DEFAULT 1,
                            color_code VARCHAR(7) DEFAULT '#3B82F6',
                            description TEXT,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            INDEX idx_company_active (company_id, is_active)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    $steps[] = "✅ shift_templates table created/verified";
                } catch (Exception $e) {
                    $steps[] = "❌ shift_templates table failed: " . $e->getMessage();
                }
                
                // Step 2: Fix employee_shifts table
                try {
                    $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll(PDO::FETCH_ASSOC);
                    $columnNames = array_column($columns, 'Field');
                    
                    if (!in_array('shift_date', $columnNames)) {
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_date DATE NOT NULL DEFAULT CURRENT_DATE");
                        $steps[] = "✅ shift_date column added";
                    } else {
                        $steps[] = "ℹ️ shift_date column exists";
                    }
                    
                    if (!in_array('shift_template_id', $columnNames)) {
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT DEFAULT NULL");
                        $steps[] = "✅ shift_template_id column added";
                    } else {
                        $steps[] = "ℹ️ shift_template_id column exists";
                    }
                    
                } catch (Exception $e) {
                    $steps[] = "❌ employee_shifts fix failed: " . $e->getMessage();
                }
                
                // Step 3: Add default shift templates
                try {
                    $defaultShifts = [
                        ['Sabah Vardiyası', '08:00:00', '17:00:00', 60, '#3B82F6', 'Standart sabah vardiyası'],
                        ['Öğle Vardiyası', '12:00:00', '21:00:00', 60, '#10B981', 'Öğle vardiyası'],
                        ['Gece Vardiyası', '22:00:00', '06:00:00', 30, '#8B5CF6', 'Gece vardiyası']
                    ];

                    $addedCount = 0;
                    foreach ($defaultShifts as $shift) {
                        $stmt = $conn->prepare("
                            INSERT IGNORE INTO shift_templates (company_id, name, start_time, end_time, break_duration, color_code, description)
                            VALUES (1, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute($shift);
                        if ($stmt->rowCount() > 0) $addedCount++;
                    }
                    $steps[] = "✅ {$addedCount} default shift templates added";
                } catch (Exception $e) {
                    $steps[] = "❌ Default templates failed: " . $e->getMessage();
                }
                
                // Step 4: Mark errors as solved
                try {
                    $stmt = $conn->prepare("
                        UPDATE system_error_log 
                        SET status = 'solved', 
                            solution_notes = 'Shift management errors fixed - missing shift_date column and shiftTemplates variable',
                            solved_by = 'Shift Management Fix Tool',
                            solved_at = NOW()
                        WHERE (error_message LIKE '%shift_date%' 
                        OR error_message LIKE '%shiftTemplates%' 
                        OR error_message LIKE '%shift_template%')
                        AND status = 'unsolved'
                    ");
                    $stmt->execute();
                    $fixedErrorCount = $stmt->rowCount();
                    $steps[] = "✅ " . $fixedErrorCount . " related errors marked as solved";
                } catch (Exception $e) {
                    $steps[] = "⚠️ Error marking: " . $e->getMessage();
                }
                
                $message = "🔧 Comprehensive Shift Fix Completed:<br>" . implode('<br>', $steps);
                $messageType = "success";
                break;
                
            case 'test_shift_queries':
                try {
                    // Test shift templates query
                    $stmt = $conn->prepare("
                        SELECT COUNT(*) as template_count 
                        FROM shift_templates 
                        WHERE company_id = 1 AND is_active = 1
                    ");
                    $stmt->execute();
                    $templateCount = $stmt->fetch(PDO::FETCH_ASSOC)['template_count'];
                    
                    // Test employee_shifts insert
                    $stmt = $conn->prepare("
                        INSERT IGNORE INTO employee_shifts (employee_id, shift_template_id, shift_date) 
                        VALUES (1, 1, CURRENT_DATE)
                    ");
                    $stmt->execute();
                    
                    $message = "✅ Shift queries test successful. Found {$templateCount} templates.";
                    $messageType = "success";
                    addDiagnostic('success', 'Query Test', 'All shift management queries work correctly');
                } catch (Exception $e) {
                    $message = "❌ Shift queries test failed: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Query Test Failed', $e->getMessage());
                }
                break;
        }
    }
    
    // Diagnostic checks
    addDiagnostic('info', 'Database Connection', 'Connected successfully');
    
    // Check shift_templates table
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
        if ($stmt->rowCount() > 0) {
            addDiagnostic('success', 'shift_templates Table', 'Table exists');
            
            $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates WHERE is_active = 1");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            addDiagnostic('success', 'Active Shift Templates', $count . ' templates found');
        } else {
            addDiagnostic('error', 'shift_templates Table', 'Table does not exist');
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'shift_templates Check', $e->getMessage());
    }
    
    // Check employee_shifts table structure
    try {
        $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        
        $requiredColumns = ['shift_date', 'shift_template_id'];
        $existingColumns = array_intersect($requiredColumns, $columnNames);
        $missingColumns = array_diff($requiredColumns, $columnNames);
        
        if (!empty($existingColumns)) {
            addDiagnostic('success', 'Existing Shift Columns', implode(', ', $existingColumns));
        }
        if (!empty($missingColumns)) {
            addDiagnostic('error', 'Missing Shift Columns', implode(', ', $missingColumns));
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'employee_shifts Check', $e->getMessage());
    }
    
    // Check recent shift-related errors
    try {
        $stmt = $conn->query("
            SELECT COUNT(*) as error_count 
            FROM system_error_log 
            WHERE (error_message LIKE '%shift_date%' 
            OR error_message LIKE '%shiftTemplates%' 
            OR error_message LIKE '%shift_template%')
            AND status = 'unsolved'
            AND DATE(created_at) >= CURDATE() - INTERVAL 1 DAY
        ");
        $errorCount = $stmt->fetch(PDO::FETCH_ASSOC)['error_count'];
        
        if ($errorCount > 0) {
            addDiagnostic('error', 'Recent Shift Errors', $errorCount . ' unsolved shift errors in last 24 hours');
        } else {
            addDiagnostic('success', 'Recent Shift Errors', 'No recent shift-related errors');
        }
    } catch (Exception $e) {
        addDiagnostic('warning', 'Error Check', 'Could not check recent errors: ' . $e->getMessage());
    }

} catch (Exception $e) {
    $message = "Database connection failed: " . $e->getMessage();
    $messageType = "error";
    addDiagnostic('error', 'Critical Error', $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shift Management Fix - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">📅 Shift Management Fix</h1>
                        <p class="text-gray-600 mt-1">Vardiya yönetimi hatalarını düzeltin</p>
                    </div>
                    <a href="../super-admin/fix-critical-errors.php" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
                        ← Critical Errors
                    </a>
                </div>
            </div>

            <!-- Message -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg border <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border-green-200' : ($messageType === 'error' ? 'bg-red-100 text-red-800 border-red-200' : 'bg-blue-100 text-blue-800 border-blue-200'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Quick Fixes -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Quick Fixes</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <!-- Fix employee_shifts table -->
                    <div class="border border-red-200 rounded-lg p-4 bg-red-50">
                        <h3 class="font-bold text-red-800 mb-2">📅 Employee Shifts Table</h3>
                        <p class="text-sm text-red-600 mb-3">
                            employee_shifts tablosuna eksik shift_date sütununu ekle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="fix_employee_shifts_table" 
                                    class="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm">
                                📅 Fix Shifts Table
                            </button>
                        </form>
                    </div>
                    
                    <!-- Create shift_templates table -->
                    <div class="border border-purple-200 rounded-lg p-4 bg-purple-50">
                        <h3 class="font-bold text-purple-800 mb-2">📋 Shift Templates Table</h3>
                        <p class="text-sm text-purple-600 mb-3">
                            shift_templates tablosunu oluştur ve varsayılan şablonları ekle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="create_shift_templates_table" 
                                    class="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm">
                                📋 Create Templates Table
                            </button>
                        </form>
                    </div>

                    <!-- Test shift queries -->
                    <div class="border border-blue-200 rounded-lg p-4 bg-blue-50">
                        <h3 class="font-bold text-blue-800 mb-2">🧪 Test Shift Queries</h3>
                        <p class="text-sm text-blue-600 mb-3">
                            Vardiya yönetimi sorgularının çalışıp çalışmadığını test et.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="test_shift_queries" 
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                                🧪 Test Queries
                            </button>
                        </form>
                    </div>

                    <!-- Comprehensive Fix -->
                    <div class="border border-green-200 rounded-lg p-4 bg-green-50">
                        <h3 class="font-bold text-green-800 mb-2">🔧 Comprehensive Shift Fix</h3>
                        <p class="text-sm text-green-600 mb-3">
                            Tüm vardiya tablolarını düzelt, şablonları ekle ve hataları işaretle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="comprehensive_shift_fix" 
                                    class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm">
                                🔧 Complete Shift Fix
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Diagnostics -->
            <?php if (!empty($diagnostics)): ?>
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🔍 System Diagnostics</h2>
                
                <div class="space-y-3">
                    <?php foreach ($diagnostics as $diagnostic): ?>
                        <div class="border-l-4 p-3 <?php echo $diagnostic['type'] === 'success' ? 'border-green-500 bg-green-50' : ($diagnostic['type'] === 'error' ? 'border-red-500 bg-red-50' : ($diagnostic['type'] === 'warning' ? 'border-yellow-500 bg-yellow-50' : 'border-blue-500 bg-blue-50')); ?>">
                            <h4 class="font-bold <?php echo $diagnostic['type'] === 'success' ? 'text-green-800' : ($diagnostic['type'] === 'error' ? 'text-red-800' : ($diagnostic['type'] === 'warning' ? 'text-yellow-800' : 'text-blue-800')); ?>">
                                <?php 
                                $icon = $diagnostic['type'] === 'success' ? '✅' : ($diagnostic['type'] === 'error' ? '❌' : ($diagnostic['type'] === 'warning' ? '⚠️' : 'ℹ️'));
                                echo $icon . ' ' . $diagnostic['title']; 
                                ?>
                            </h4>
                            <p class="text-sm <?php echo $diagnostic['type'] === 'success' ? 'text-green-600' : ($diagnostic['type'] === 'error' ? 'text-red-600' : ($diagnostic['type'] === 'warning' ? 'text-yellow-600' : 'text-blue-600')); ?> mt-1">
                                <?php echo $diagnostic['details']; ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</body>
</html>