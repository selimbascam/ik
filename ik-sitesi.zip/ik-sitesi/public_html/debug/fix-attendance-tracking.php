<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

session_start();

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Aylık Devam Takibi Düzeltme</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100'>
    <div class='container mx-auto px-4 py-8 max-w-4xl'>
        <div class='bg-white rounded-lg shadow-lg p-6'>
            <h1 class='text-2xl font-bold text-gray-900 mb-6'>🔧 Aylık Devam Takibi Tanı ve Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-6'>";
    
    // 1. Test the main query from attendance-tracking.php
    echo "<div class='border-l-4 border-blue-500 bg-blue-50 p-4'>
            <h2 class='text-lg font-semibold text-blue-800'>1. Aylık Devam Query Test</h2>";
    
    $companyId = $_SESSION['company_id'] ?? 4;
    $selectedMonth = date('Y-m');
    
    echo "<p class='text-sm text-gray-600 mb-2'>Test company ID: $companyId</p>
          <p class='text-sm text-gray-600 mb-4'>Test month: $selectedMonth</p>";
    
    try {
        // Test the exact query from attendance-tracking.php
        $stmt = $conn->prepare("
            SELECT 
                e.id,
                COALESCE(e.employee_number, CONCAT('EMP', LPAD(e.id, 4, '0'))) as employee_number,
                e.first_name,
                e.last_name,
                e.email,
                e.position,
                d.name as department_name,
                e.status,
                e.salary,
                COUNT(DISTINCT DATE(ar.check_in)) as days_worked,
                COALESCE(SUM(
                    CASE 
                        WHEN ar.check_in IS NOT NULL AND ar.check_out IS NOT NULL 
                        THEN TIMESTAMPDIFF(MINUTE, ar.check_in, ar.check_out) / 60.0
                        ELSE 0
                    END
                ), 0) as total_hours,
                MIN(DATE(ar.check_in)) as first_work_date,
                MAX(DATE(ar.check_in)) as last_work_date
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            LEFT JOIN attendance_records ar ON e.id = ar.employee_id 
                AND ar.date BETWEEN ? AND ?
            WHERE e.company_id = ?
            GROUP BY e.id
            ORDER BY e.first_name, e.last_name
        ");
        
        $monthStart = $selectedMonth . '-01';
        $monthEnd = date('Y-m-t', strtotime($monthStart));
        $stmt->execute([$monthStart, $monthEnd, $companyId]);
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<p class='text-green-600'>✅ Query başarılı! " . count($employees) . " personel bulundu.</p>";
        
        if (!empty($employees)) {
            echo "<div class='mt-2 text-xs'>
                    <p><strong>İlk 3 personel:</strong></p>
                    <ul class='list-disc list-inside ml-4'>";
            foreach (array_slice($employees, 0, 3) as $emp) {
                $name = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
                echo "<li>ID: {$emp['id']}, İsim: $name, Sicil: {$emp['employee_number']}, Çalışılan Gün: {$emp['days_worked']}, Toplam Saat: " . number_format($emp['total_hours'], 1) . "</li>";
            }
            echo "</ul></div>";
            
            // Calculate summary stats
            $totalEmployees = count($employees);
            $totalDaysWorked = array_sum(array_column($employees, 'days_worked'));
            $totalHours = array_sum(array_column($employees, 'total_hours'));
            $averageHoursPerEmployee = $totalEmployees > 0 ? ($totalHours / $totalEmployees) : 0;
            
            echo "<div class='mt-4 p-3 bg-green-50 border border-green-200 rounded'>
                    <p class='text-green-800 font-medium'>📊 Özet İstatistikler:</p>
                    <ul class='text-sm text-green-700 mt-2'>
                        <li>Toplam Personel: $totalEmployees</li>
                        <li>Toplam Çalışılan Gün: $totalDaysWorked</li>
                        <li>Toplam Saat: " . number_format($totalHours, 1) . "</li>
                        <li>Ortalama Saat/Personel: " . number_format($averageHoursPerEmployee, 1) . "</li>
                    </ul>
                  </div>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Query hatası: " . $e->getMessage() . "</p>";
        
        if (strpos($e->getMessage(), 'employee_number') !== false) {
            echo "<div class='mt-4 p-3 bg-orange-50 border border-orange-200 rounded'>
                    <p class='text-orange-600'>⚠️ employee_number sütunu hatası tespit edildi!</p>
                    <a href='fix-employee-number-column.php' class='inline-block mt-2 bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm'>
                        🔧 Employee Number Sütunu Düzeltme
                    </a>
                  </div>";
        }
    }
    echo "</div>";
    
    // 2. Check attendance_records table
    echo "<div class='border-l-4 border-purple-500 bg-purple-50 p-4'>
            <h2 class='text-lg font-semibold text-purple-800'>2. Attendance Records Tablo Kontrolü</h2>";
    
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<p class='text-sm text-gray-600 mb-2'>Attendance_records tablo sütunları:</p>
              <ul class='list-disc list-inside ml-4 text-xs'>";
        foreach ($columns as $column) {
            echo "<li>{$column['Field']} - {$column['Type']}</li>";
        }
        echo "</ul>";
        
        // Check if there are any attendance records
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM attendance_records WHERE employee_id IN (SELECT id FROM employees WHERE company_id = ?)");
        $stmt->execute([$companyId]);
        $recordCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "<p class='mt-2 text-sm'><strong>Company $companyId için toplam devam kaydı:</strong> $recordCount</p>";
        
        if ($recordCount == 0) {
            echo "<p class='text-orange-600 mt-2'>⚠️ Bu şirket için hiç devam kaydı yok!</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Attendance records kontrol hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 3. Check departments table
    echo "<div class='border-l-4 border-green-500 bg-green-50 p-4'>
            <h2 class='text-lg font-semibold text-green-800'>3. Departments Tablo Kontrolü</h2>";
    
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM departments WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $deptCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "<p class='text-sm'><strong>Company $companyId için departman sayısı:</strong> $deptCount</p>";
        
        if ($deptCount == 0) {
            echo "<p class='text-orange-600 mt-2'>⚠️ Bu şirket için hiç departman tanımlanmamış!</p>";
        } else {
            $stmt = $conn->prepare("SELECT id, name FROM departments WHERE company_id = ? LIMIT 5");
            $stmt->execute([$companyId]);
            $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<p class='text-sm mt-2'><strong>Departmanlar:</strong></p>
                  <ul class='list-disc list-inside ml-4 text-xs'>";
            foreach ($departments as $dept) {
                echo "<li>ID: {$dept['id']}, İsim: " . htmlspecialchars($dept['name']) . "</li>";
            }
            echo "</ul>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Departments kontrol hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 4. Auto-fix actions
    echo "<div class='border-l-4 border-red-500 bg-red-50 p-4'>
            <h2 class='text-lg font-semibold text-red-800'>4. Otomatik Düzeltme İşlemleri</h2>";
    
    if (isset($_POST['fix_action'])) {
        $action = $_POST['fix_action'];
        
        if ($action === 'create_sample_attendance') {
            try {
                // Create sample attendance records for testing
                $stmt = $conn->prepare("SELECT id FROM employees WHERE company_id = ? LIMIT 3");
                $stmt->execute([$companyId]);
                $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $created = 0;
                foreach ($employees as $emp) {
                    // Create a few sample attendance records
                    for ($i = 1; $i <= 5; $i++) {
                        $date = date('Y-m-d', strtotime("-$i days"));
                        $checkIn = $date . ' 09:00:00';
                        $checkOut = $date . ' 18:00:00';
                        
                        $stmt = $conn->prepare("
                            INSERT IGNORE INTO attendance_records 
                            (employee_id, date, check_in, check_out, activity_type, created_at) 
                            VALUES (?, ?, ?, ?, 'work', NOW())
                        ");
                        $stmt->execute([$emp['id'], $date, $checkIn, $checkOut]);
                        $created++;
                    }
                }
                
                echo "<p class='text-green-600'>✅ $created örnek devam kaydı oluşturuldu</p>";
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Örnek devam kaydı oluşturma hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        if ($action === 'create_sample_department') {
            try {
                $stmt = $conn->prepare("
                    INSERT IGNORE INTO departments (company_id, name, description, created_at) 
                    VALUES (?, 'Genel', 'Genel Departman', NOW())
                ");
                $stmt->execute([$companyId]);
                
                echo "<p class='text-green-600'>✅ Genel departmanı oluşturuldu</p>";
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Departman oluşturma hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        echo "<script>setTimeout(() => window.location.reload(), 2000);</script>";
    }
    
    echo "<div class='mt-4 grid grid-cols-1 md:grid-cols-2 gap-4'>
            <form method='POST'>
                <button type='submit' name='fix_action' value='create_sample_attendance' 
                        class='w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm'>
                    📅 Örnek Devam Kayıtları Oluştur
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='create_sample_department' 
                        class='w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🏢 Genel Departman Oluştur
                </button>
            </form>
          </div>";
    
    echo "</div>";
    
    // 5. Navigation Links
    echo "<div class='border-t pt-4 mt-6'>
            <h3 class='text-lg font-medium text-gray-900 mb-3'>İlgili Sayfalar</h3>
            <div class='flex flex-wrap gap-3'>
                <a href='../admin/attendance-tracking.php' class='bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm'>
                    📊 Aylık Devam Takibine Dön
                </a>
                <a href='fix-employee-number-column.php' class='bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🔢 Employee Number Düzeltme
                </a>
                <a href='../super-admin/fix-critical-errors.php' class='bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🚨 Kritik Hata Düzeltme
                </a>
            </div>
          </div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>
            <strong>Kritik Hata:</strong> " . $e->getMessage() . "
          </div>";
}

echo "        </div>
    </div>
</body>
</html>";
?>