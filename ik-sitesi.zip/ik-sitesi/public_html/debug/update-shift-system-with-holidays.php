<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'create_holiday_table':
                try {
                    // Create employee_weekly_holidays table
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS employee_weekly_holidays (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            employee_id INT NOT NULL,
                            company_id INT NOT NULL,
                            monday BOOLEAN DEFAULT 0,
                            tuesday BOOLEAN DEFAULT 0,
                            wednesday BOOLEAN DEFAULT 0,
                            thursday BOOLEAN DEFAULT 0,
                            friday BOOLEAN DEFAULT 0,
                            saturday BOOLEAN DEFAULT 1,
                            sunday BOOLEAN DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                            UNIQUE KEY unique_employee (employee_id)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    ");
                    
                    $message = "✅ employee_weekly_holidays tablosu başarıyla oluşturuldu!";
                    $messageType = "success";
                } catch (Exception $e) {
                    $message = "❌ Tablo oluşturma hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
                
            case 'set_default_holidays':
                try {
                    // Get all employees
                    $stmt = $conn->query("SELECT id, company_id FROM employees");
                    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    $insertedCount = 0;
                    foreach ($employees as $employee) {
                        $stmt = $conn->prepare("
                            INSERT IGNORE INTO employee_weekly_holidays 
                            (employee_id, company_id, saturday, sunday) 
                            VALUES (?, ?, 1, 1)
                        ");
                        $stmt->execute([$employee['id'], $employee['company_id']]);
                        
                        if ($stmt->rowCount() > 0) {
                            $insertedCount++;
                        }
                    }
                    
                    $message = "✅ $insertedCount personele varsayılan tatil günleri (Cumartesi-Pazar) atandı!";
                    $messageType = "success";
                } catch (Exception $e) {
                    $message = "❌ Varsayılan tatil atama hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
                
            case 'update_shift_logic':
                try {
                    // PHP logic kullanılacak - MySQL fonksiyonu MariaDB ile uyumsuz
                    // DELIMITER syntax hatası verdiği için kaldırıldı
                    $conn->exec("SELECT 'PHP tabanlı tatil sistemi aktif' as status");
                    
                    $message = "✅ Vardiya mantığı tatil sistemi ile güncellendi!";
                    $messageType = "success";
                } catch (Exception $e) {
                    $message = "❌ Vardiya mantığı güncelleme hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
                
            case 'test_holiday_system':
                try {
                    echo "<div class='bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4'>";
                    echo "<h3 class='font-bold text-blue-900 mb-2'>🧪 Tatil Sistemi Test Sonuçları</h3>";
                    
                    // Test table existence
                    $stmt = $conn->query("SHOW TABLES LIKE 'employee_weekly_holidays'");
                    if ($stmt->rowCount() > 0) {
                        echo "<p class='text-green-600'>✅ employee_weekly_holidays tablosu mevcut</p>";
                        
                        // Check employee holiday records
                        $stmt = $conn->query("SELECT COUNT(*) as count FROM employee_weekly_holidays");
                        $count = $stmt->fetch()['count'];
                        echo "<p class='text-blue-600'>📊 Toplam tatil kaydı: $count</p>";
                        
                        // Test some employees
                        $stmt = $conn->query("
                            SELECT 
                                e.first_name, 
                                e.last_name,
                                ewh.saturday,
                                ewh.sunday,
                                ewh.monday,
                                ewh.tuesday,
                                ewh.wednesday,
                                ewh.thursday,
                                ewh.friday
                            FROM employees e
                            LEFT JOIN employee_weekly_holidays ewh ON e.id = ewh.employee_id
                            LIMIT 5
                        ");
                        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        echo "<table class='w-full mt-3 text-sm border'>";
                        echo "<tr class='bg-gray-100'>";
                        echo "<th class='border p-2'>Personel</th>";
                        echo "<th class='border p-2'>Pzt</th><th class='border p-2'>Sal</th><th class='border p-2'>Çar</th>";
                        echo "<th class='border p-2'>Per</th><th class='border p-2'>Cum</th><th class='border p-2'>Cmt</th><th class='border p-2'>Paz</th>";
                        echo "</tr>";
                        
                        foreach ($employees as $emp) {
                            echo "<tr>";
                            echo "<td class='border p-2'>" . $emp['first_name'] . " " . $emp['last_name'] . "</td>";
                            $days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
                            foreach ($days as $day) {
                                $isHoliday = $emp[$day] ?? ($day === 'saturday' || $day === 'sunday' ? 1 : 0);
                                echo "<td class='border p-2 text-center " . ($isHoliday ? 'bg-red-100' : 'bg-green-100') . "'>" . 
                                     ($isHoliday ? '🚫' : '✅') . "</td>";
                            }
                            echo "</tr>";
                        }
                        echo "</table>";
                        
                    } else {
                        echo "<p class='text-red-600'>❌ employee_weekly_holidays tablosu bulunamadı</p>";
                    }
                    
                    // Test PHP-based holiday function
                    try {
                        function testIsEmployeeHoliday($employeeId, $checkDate, $conn) {
                            $dayOfWeek = date('N', strtotime($checkDate)); // 1=Monday, 7=Sunday
                            
                            $stmt = $conn->prepare("
                                SELECT 
                                    CASE 
                                        WHEN ? = 1 THEN COALESCE(monday, 0)
                                        WHEN ? = 2 THEN COALESCE(tuesday, 0)
                                        WHEN ? = 3 THEN COALESCE(wednesday, 0)
                                        WHEN ? = 4 THEN COALESCE(thursday, 0)
                                        WHEN ? = 5 THEN COALESCE(friday, 0)
                                        WHEN ? = 6 THEN COALESCE(saturday, 1)
                                        WHEN ? = 7 THEN COALESCE(sunday, 1)
                                        ELSE 1
                                    END as is_holiday
                                FROM employee_weekly_holidays 
                                WHERE employee_id = ?
                            ");
                            $stmt->execute([$dayOfWeek, $dayOfWeek, $dayOfWeek, $dayOfWeek, $dayOfWeek, $dayOfWeek, $dayOfWeek, $employeeId]);
                            $result = $stmt->fetch(PDO::FETCH_ASSOC);
                            
                            return $result ? (bool)$result['is_holiday'] : ($dayOfWeek == 6 || $dayOfWeek == 7); // Default weekend
                        }
                        
                        $result = testIsEmployeeHoliday(1, date('Y-m-d'), $conn);
                        echo "<p class='text-green-600'>✅ PHP tatil fonksiyonu çalışıyor (sonuç: " . ($result ? 'tatil' : 'çalışma') . ")</p>";
                    } catch (Exception $e) {
                        echo "<p class='text-red-600'>❌ PHP tatil fonksiyonu hatası: " . $e->getMessage() . "</p>";
                    }
                    
                    echo "</div>";
                } catch (Exception $e) {
                    $message = "❌ Test hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
                
            case 'regenerate_shifts_with_holidays':
                try {
                    // Clear existing shifts for next 30 days
                    $stmt = $conn->prepare("
                        DELETE FROM employee_shifts 
                        WHERE shift_date >= CURDATE() AND shift_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
                    ");
                    $stmt->execute();
                    $deletedCount = $stmt->rowCount();
                    
                    // Get employees and their holiday settings
                    $stmt = $conn->query("
                        SELECT 
                            e.id as employee_id,
                            e.first_name,
                            e.last_name,
                            COALESCE(ewh.monday, 0) as monday_holiday,
                            COALESCE(ewh.tuesday, 0) as tuesday_holiday,
                            COALESCE(ewh.wednesday, 0) as wednesday_holiday,
                            COALESCE(ewh.thursday, 0) as thursday_holiday,
                            COALESCE(ewh.friday, 0) as friday_holiday,
                            COALESCE(ewh.saturday, 1) as saturday_holiday,
                            COALESCE(ewh.sunday, 1) as sunday_holiday
                        FROM employees e
                        LEFT JOIN employee_weekly_holidays ewh ON e.id = ewh.employee_id
                        ORDER BY e.first_name
                    ");
                    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    // Get 09:30-19:30 shift template
                    $stmt = $conn->prepare("
                        SELECT id FROM shift_templates 
                        WHERE start_time = '09:30:00' AND end_time = '19:30:00' 
                        AND is_active = 1
                        LIMIT 1
                    ");
                    $stmt->execute();
                    $template = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$template) {
                        throw new Exception("09:30-19:30 vardiya şablonu bulunamadı");
                    }
                    
                    $templateId = $template['id'];
                    $totalAssigned = 0;
                    
                    foreach ($employees as $employee) {
                        $employeeAssigned = 0;
                        
                        // Generate shifts for next 30 days
                        for ($i = 0; $i < 30; $i++) {
                            $date = date('Y-m-d', strtotime("+$i day"));
                            $dayOfWeek = date('N', strtotime($date)); // 1=Monday, 7=Sunday
                            
                            $isHoliday = false;
                            switch ($dayOfWeek) {
                                case 1: $isHoliday = (bool)$employee['monday_holiday']; break;
                                case 2: $isHoliday = (bool)$employee['tuesday_holiday']; break;
                                case 3: $isHoliday = (bool)$employee['wednesday_holiday']; break;
                                case 4: $isHoliday = (bool)$employee['thursday_holiday']; break;
                                case 5: $isHoliday = (bool)$employee['friday_holiday']; break;
                                case 6: $isHoliday = (bool)$employee['saturday_holiday']; break;
                                case 7: $isHoliday = (bool)$employee['sunday_holiday']; break;
                            }
                            
                            // Only assign shift if it's not a holiday
                            if (!$isHoliday) {
                                $stmt = $conn->prepare("
                                    INSERT INTO employee_shifts 
                                    (employee_id, shift_template_id, shift_date, status) 
                                    VALUES (?, ?, ?, 'scheduled')
                                ");
                                $stmt->execute([$employee['employee_id'], $templateId, $date]);
                                $employeeAssigned++;
                                $totalAssigned++;
                            }
                        }
                        
                        echo "<p class='text-green-600'>✅ " . $employee['first_name'] . " " . $employee['last_name'] . ": $employeeAssigned çalışma günü atandı</p>";
                    }
                    
                    $message = "✅ Tatil ayarlarına göre $totalAssigned vardiya ataması yapıldı ($deletedCount eski kayıt silindi)";
                    $messageType = "success";
                } catch (Exception $e) {
                    $message = "❌ Vardiya yeniden oluşturma hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
        }
        
    } catch (Exception $e) {
        $message = "❌ Genel hata: " . $e->getMessage();
        $messageType = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tatil Sistemi Kurulum - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 p-6">
    <div class="max-w-6xl mx-auto">
        <div class="bg-white rounded-xl shadow-lg p-8">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">🏖️ Bireysel Tatil Sistemi Kurulumu</h1>
                    <p class="text-gray-600 mt-2">Personellerin kendi tatil günlerini seçebilmesi için sistem güncellemeleri</p>
                </div>
                <a href="../super-admin/fix-critical-errors.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                    ← Geri Dön
                </a>
            </div>

            <?php if ($message): ?>
                <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Step 1: Create Holiday Table -->
                <div class="bg-blue-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-blue-900 mb-4">1️⃣ Tatil Tablosu</h2>
                    
                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="action" value="create_holiday_table">
                        <button type="submit" class="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Tatil Tablosunu Oluştur
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-blue-700">
                        <p><strong>Bu işlem:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>employee_weekly_holidays tablosunu oluşturur</li>
                            <li>Her personelin günlük tatil tercihlerini saklar</li>
                            <li>Varsayılan: Cumartesi-Pazar tatil</li>
                        </ul>
                    </div>
                </div>

                <!-- Step 2: Set Default Holidays -->
                <div class="bg-green-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-green-900 mb-4">2️⃣ Varsayılan Tatiller</h2>
                    
                    <form method="POST" class="space-y-3">
                        <input type="hidden" name="action" value="set_default_holidays">
                        <button type="submit" class="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                            Varsayılan Tatilleri Ata
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-green-700">
                        <p><strong>Bu işlem:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>Tüm personellere Cumartesi-Pazar tatil atar</li>
                            <li>Mevcut kayıtları korur</li>
                            <li>Başlangıç noktası sağlar</li>
                        </ul>
                    </div>
                </div>

                <!-- Step 3: Update Logic -->
                <div class="bg-purple-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-purple-900 mb-4">3️⃣ Vardiya Mantığı</h2>
                    
                    <form method="POST" class="space-y-3">
                        <input type="hidden" name="action" value="update_shift_logic">
                        <button type="submit" class="w-full bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                            Vardiya Mantığını Güncelle
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-purple-700">
                        <p><strong>Bu işlem:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>PHP tabanlı tatil kontrolü kullanır</li>
                            <li>Bireysel tatil kontrolü sağlar</li>
                            <li>Vardiya ataması mantığını günceller</li>
                        </ul>
                    </div>
                </div>

                <!-- Step 4: Test System -->
                <div class="bg-yellow-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-yellow-900 mb-4">4️⃣ Sistem Testi</h2>
                    
                    <form method="POST" class="space-y-3">
                        <input type="hidden" name="action" value="test_holiday_system">
                        <button type="submit" class="w-full bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700 transition-colors">
                            Tatil Sistemini Test Et
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-yellow-700">
                        <p><strong>Bu test:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>Tablo varlığını kontrol eder</li>
                            <li>Personel tatil ayarlarını gösterir</li>
                            <li>Fonksiyon çalışmasını test eder</li>
                        </ul>
                    </div>
                </div>

                <!-- Step 5: Regenerate Shifts -->
                <div class="bg-red-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-red-900 mb-4">5️⃣ Vardiya Yenileme</h2>
                    
                    <form method="POST" class="space-y-3">
                        <input type="hidden" name="action" value="regenerate_shifts_with_holidays">
                        <button type="submit" class="w-full bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors">
                            Vardiyaları Tatile Göre Yenile
                        </button>
                    </form>
                    
                    <div class="mt-4 text-sm text-red-700">
                        <p><strong>Bu işlem:</strong></p>
                        <ul class="list-disc pl-5 mt-2">
                            <li>Mevcut vardiyaları temizler (30 gün)</li>
                            <li>Tatil ayarlarına göre yeniden oluşturur</li>
                            <li>09:30-19:30 çalışma günlerini atar</li>
                        </ul>
                    </div>
                </div>

                <!-- Info Panel -->
                <div class="bg-gray-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">ℹ️ Kullanım Bilgisi</h2>
                    
                    <div class="text-sm text-gray-700 space-y-2">
                        <p><strong>Kurulum Sırası:</strong></p>
                        <ol class="list-decimal pl-5 space-y-1">
                            <li>Tatil tablosunu oluştur</li>
                            <li>Varsayılan tatilleri ata</li>
                            <li>Vardiya mantığını güncelle</li>
                            <li>Sistemi test et</li>
                            <li>Vardiyaları yenile</li>
                        </ol>
                        
                        <p class="mt-4"><strong>Sonrasında:</strong></p>
                        <ul class="list-disc pl-5">
                            <li>Personeller kendi tatil günlerini seçebilir</li>
                            <li>Yöneticiler toplu tatil ataması yapabilir</li>
                            <li>Vardiya sistemi otomatik uyum sağlar</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>