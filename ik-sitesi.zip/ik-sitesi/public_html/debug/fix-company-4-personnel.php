<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Force session for debugging
session_start();

// Allow super admin access for debugging
if (!isset($_SESSION['company_id']) && !isset($_SESSION['user_role'])) {
    $_SESSION['company_id'] = 4;
    $_SESSION['user_role'] = 'super_admin';
}

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Şirket ID 4 Personel Listesi Düzeltme</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-100'>
    <div class='container mx-auto px-4 py-8 max-w-4xl'>
        <div class='bg-white rounded-lg shadow-lg p-6'>
            <h1 class='text-2xl font-bold text-gray-900 mb-6'>🔧 Şirket ID 4 Personel Listesi Tanı ve Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='space-y-6'>";
    
    // 1. Company ID 4 Basic Info
    echo "<div class='border-l-4 border-blue-500 bg-blue-50 p-4'>
            <h2 class='text-lg font-semibold text-blue-800'>1. Şirket ID 4 Temel Bilgileri</h2>";
    
    $stmt = $conn->prepare("SELECT * FROM companies WHERE id = 4");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        echo "<div class='mt-2 text-sm'>
                <p><strong>Şirket:</strong> " . htmlspecialchars($company['name'] ?? 'N/A') . "</p>
                <p><strong>Email:</strong> " . htmlspecialchars($company['email'] ?? 'N/A') . "</p>
                <p><strong>Oluşturma:</strong> " . ($company['created_at'] ?? 'N/A') . "</p>
                <p><strong>Durum:</strong> " . ($company['is_active'] ?? 'N/A') . "</p>
              </div>";
    } else {
        echo "<p class='text-red-600'>❌ Şirket ID 4 bulunamadı!</p>";
    }
    echo "</div>";
    
    // 2. Employees Table Structure
    echo "<div class='border-l-4 border-yellow-500 bg-yellow-50 p-4'>
            <h2 class='text-lg font-semibold text-yellow-800'>2. Employees Tablo Yapısı</h2>";
    
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<div class='mt-2 text-sm'>
                <p><strong>Sütunlar:</strong></p>
                <ul class='list-disc list-inside ml-4'>";
        
        $hasIsActive = false;
        $hasCompanyId = false;
        foreach ($columns as $column) {
            echo "<li>" . $column['Field'] . " (" . $column['Type'] . ")</li>";
            if ($column['Field'] === 'is_active') $hasIsActive = true;
            if ($column['Field'] === 'company_id') $hasCompanyId = true;
        }
        echo "</ul>";
        
        if (!$hasIsActive) {
            echo "<p class='text-red-600 mt-2'>⚠️ is_active sütunu eksik!</p>";
        }
        if (!$hasCompanyId) {
            echo "<p class='text-red-600 mt-2'>⚠️ company_id sütunu eksik!</p>";
        }
        echo "</div>";
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Tablo yapısı okunamadı: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 3. Direct Employee Count
    echo "<div class='border-l-4 border-green-500 bg-green-50 p-4'>
            <h2 class='text-lg font-semibold text-green-800'>3. Direkt Personel Sayımı</h2>";
    
    try {
        // All employees for company 4
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM employees WHERE company_id = 4");
        $stmt->execute();
        $totalCount = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
        
        // Active employees
        $stmt = $conn->prepare("SELECT COUNT(*) as active FROM employees WHERE company_id = 4 AND (is_active = 1 OR is_active IS NULL)");
        $stmt->execute();
        $activeCount = $stmt->fetch(PDO::FETCH_ASSOC)['active'];
        
        echo "<div class='mt-2 text-sm'>
                <p><strong>Toplam personel:</strong> $totalCount</p>
                <p><strong>Aktif personel:</strong> $activeCount</p>
              </div>";
        
        if ($totalCount > 0) {
            echo "<p class='text-green-600 mt-2'>✅ Personeller mevcut</p>";
        } else {
            echo "<p class='text-red-600 mt-2'>❌ Hiç personel yok</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Sayım hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 4. Exact Query Test (from shift-management.php)
    echo "<div class='border-l-4 border-purple-500 bg-purple-50 p-4'>
            <h2 class='text-lg font-semibold text-purple-800'>4. Vardiya Yönetimi Query'si Test</h2>";
    
    try {
        // Exact query from shift-management.php
        $query = "SELECT 
                    e.id,
                    e.first_name,
                    e.last_name,
                    e.employee_number,
                    e.email,
                    e.phone,
                    e.department,
                    e.position,
                    e.hire_date,
                    e.is_active
                  FROM employees e 
                  WHERE e.company_id = ? 
                  AND (e.is_active = 1 OR e.is_active IS NULL)
                  ORDER BY e.first_name, e.last_name";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([4]);
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<div class='mt-2 text-sm'>
                <p><strong>Query sonucu:</strong> " . count($employees) . " personel</p>";
        
        if (!empty($employees)) {
            echo "<div class='mt-2'>
                    <p><strong>Bulunan personeller:</strong></p>
                    <ul class='list-disc list-inside ml-4'>";
            foreach ($employees as $emp) {
                $name = trim(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? ''));
                if (empty($name)) $name = 'İsimsiz';
                echo "<li>ID: {$emp['id']}, İsim: $name, Sicil: " . ($emp['employee_number'] ?? 'N/A') . ", Aktif: " . ($emp['is_active'] ?? 'NULL') . "</li>";
            }
            echo "</ul></div>";
            echo "<p class='text-green-600 mt-2'>✅ Query başarılı</p>";
        } else {
            echo "<p class='text-red-600 mt-2'>❌ Query sonuç getirmedi</p>";
        }
    } catch (Exception $e) {
        echo "<p class='text-red-600'>❌ Query hatası: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    // 5. Permission and Access Check
    echo "<div class='border-l-4 border-indigo-500 bg-indigo-50 p-4'>
            <h2 class='text-lg font-semibold text-indigo-800'>5. Yetki ve Erişim Kontrolü</h2>";
    
    echo "<div class='mt-2 text-sm'>
            <p><strong>Session Company ID:</strong> " . ($_SESSION['company_id'] ?? 'not set') . "</p>
            <p><strong>Session User Role:</strong> " . ($_SESSION['user_role'] ?? 'not set') . "</p>
            <p><strong>Session User ID:</strong> " . ($_SESSION['user_id'] ?? 'not set') . "</p>";
    
    // Test database connection permissions
    try {
        $stmt = $conn->query("SELECT CONNECTION_ID(), USER(), DATABASE()");
        $connInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p><strong>DB Connection ID:</strong> " . $connInfo['CONNECTION_ID()'] . "</p>
              <p><strong>DB User:</strong> " . $connInfo['USER()'] . "</p>
              <p><strong>DB Database:</strong> " . $connInfo['DATABASE()'] . "</p>";
    } catch (Exception $e) {
        echo "<p class='text-red-600'>DB bağlantı bilgisi alınamadı</p>";
    }
    echo "</div></div>";
    
    // 6. Auto-Fix Actions
    echo "<div class='border-l-4 border-red-500 bg-red-50 p-4'>
            <h2 class='text-lg font-semibold text-red-800'>6. Otomatik Düzeltme İşlemleri</h2>";
    
    if (isset($_POST['fix_action'])) {
        $action = $_POST['fix_action'];
        
        if ($action === 'add_is_active') {
            try {
                $conn->exec("ALTER TABLE employees ADD COLUMN is_active TINYINT(1) DEFAULT 1");
                echo "<p class='text-green-600'>✅ is_active sütunu eklendi</p>";
            } catch (Exception $e) {
                echo "<p class='text-orange-600'>⚠️ is_active sütunu zaten var veya eklenemedi</p>";
            }
        }
        
        if ($action === 'fix_null_active') {
            try {
                $stmt = $conn->prepare("UPDATE employees SET is_active = 1 WHERE company_id = 4 AND is_active IS NULL");
                $stmt->execute();
                $affected = $stmt->rowCount();
                echo "<p class='text-green-600'>✅ $affected personelin is_active durumu güncellendi</p>";
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ is_active güncelleme hatası: " . $e->getMessage() . "</p>";
            }
        }
        
        if ($action === 'create_test_employee') {
            try {
                $stmt = $conn->prepare("
                    INSERT INTO employees (company_id, first_name, last_name, employee_number, email, is_active) 
                    VALUES (4, 'Test', 'Personel', 'TEST001', 'test@company4.com', 1)
                ");
                $stmt->execute();
                echo "<p class='text-green-600'>✅ Test personeli oluşturuldu</p>";
            } catch (Exception $e) {
                echo "<p class='text-red-600'>❌ Test personeli oluşturulamadı: " . $e->getMessage() . "</p>";
            }
        }
        
        if ($action === 'fix_company_session') {
            $_SESSION['company_id'] = 4;
            $_SESSION['user_role'] = 'admin';
            $_SESSION['user_id'] = 1;
            echo "<p class='text-green-600'>✅ Session şirket ID'si düzeltildi</p>";
        }
        
        echo "<script>setTimeout(() => window.location.reload(), 2000);</script>";
    }
    
    echo "<div class='mt-4 grid grid-cols-1 md:grid-cols-2 gap-4'>
            <form method='POST'>
                <button type='submit' name='fix_action' value='add_is_active' 
                        class='w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🔧 is_active Sütunu Ekle
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='fix_null_active' 
                        class='w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm'>
                    ✅ NULL is_active Değerleri Düzelt
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='create_test_employee' 
                        class='w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm'>
                    👤 Test Personeli Oluştur
                </button>
            </form>
            
            <form method='POST'>
                <button type='submit' name='fix_action' value='fix_company_session' 
                        class='w-full bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🔑 Session Düzelt
                </button>
            </form>
          </div>";
    
    echo "</div>";
    
    // 7. Navigation Links
    echo "<div class='border-t pt-4 mt-6'>
            <h3 class='text-lg font-medium text-gray-900 mb-3'>Bağlantılar</h3>
            <div class='flex flex-wrap gap-3'>
                <a href='../admin/shift-management.php' class='bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🔄 Vardiya Yönetimine Dön
                </a>
                <a href='../admin/employee-management.php' class='bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm'>
                    👥 Personel Yönetimi
                </a>
                <a href='../super-admin/fix-critical-errors.php' class='bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🚨 Kritik Hata Düzeltme
                </a>
                <a href='fix-shift-employee-list.php' class='bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg text-sm'>
                    🔧 Genel Personel Listesi Düzeltme
                </a>
            </div>
          </div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>
            <strong>Kritik Hata:</strong> " . $e->getMessage() . "
          </div>";
}

echo "        </div>
    </div>
</body>
</html>";
?>