<?php
header('Content-Type: application/json');

// QR Debug Log API
$action = $_GET['action'] ?? '';

if ($action === 'get_logs') {
    $lastSize = intval($_GET['last_size'] ?? 0);
    
    // PHP error log dosyasını bul - Hostinger uyumlu yerler + manual log
    $logFiles = [
        __DIR__ . '/manual_log.txt',  // Manuel log dosyası
        '/home/' . get_current_user() . '/public_html/error_log',
        '/home/' . get_current_user() . '/logs/error_log',
        '/tmp/php_errors.log',
        ini_get('error_log'),
        './error_log',
        '../error_log',
        '../../error_log',
        '/var/log/php_errors.log',
        '/var/log/apache2/error.log'
    ];
    
    $logContent = '';
    $currentSize = 0;
    
    // İlk bulduğu log dosyasını kullan
    foreach ($logFiles as $logFile) {
        if ($logFile && file_exists($logFile) && is_readable($logFile)) {
            $currentSize = filesize($logFile);
            
            // Sadece yeni içeriği al
            if ($currentSize > $lastSize) {
                $handle = fopen($logFile, 'r');
                if ($handle) {
                    fseek($handle, $lastSize);
                    $logContent = fread($handle, $currentSize - $lastSize);
                    fclose($handle);
                }
            }
            break;
        }
    }
    
    // Log satırlarını ayır ve QR ile ilgili olanları filtrele
    $lines = explode("\n", $logContent);
    $qrLogs = [];
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        
        // QR ile ilgili logları filtrele
        if (stripos($line, 'Master QR') !== false || 
            stripos($line, 'QR DEBUG') !== false ||
            stripos($line, 'QR ERROR') !== false ||
            stripos($line, 'attendance') !== false) {
            $qrLogs[] = $line;
        }
    }
    
    // Debug bilgisi ekle
    $debugInfo = [
        'php_error_log_setting' => ini_get('error_log'),
        'current_user' => get_current_user(),
        'log_files_found' => [],
        'log_files_checked' => $logFiles
    ];
    
    // Hangi log dosyalarının var olduğunu kontrol et
    foreach ($logFiles as $logFile) {
        if ($logFile && file_exists($logFile)) {
            $debugInfo['log_files_found'][] = [
                'path' => $logFile,
                'readable' => is_readable($logFile),
                'size' => filesize($logFile)
            ];
        }
    }

    echo json_encode([
        'success' => true,
        'new_logs' => $qrLogs,
        'current_size' => $currentSize,
        'debug_info' => $debugInfo
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Invalid action'
    ]);
}
?>