<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔧 Employee Login Düzeltici</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .warning{color:orange;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔍 Veritabanı Yapısı Analizi</h2>";
    
    // Check companies table structure
    $stmt = $conn->query("DESCRIBE companies");
    $companyColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasCompanyName = false;
    $hasCompanyCode = false;
    $hasName = false;
    
    foreach ($companyColumns as $col) {
        if ($col['Field'] === 'company_name') $hasCompanyName = true;
        if ($col['Field'] === 'company_code') $hasCompanyCode = true;
        if ($col['Field'] === 'name') $hasName = true;
    }
    
    echo "<h3>Companies Tablo Sütunları:</h3>";
    echo "<ul>";
    echo "<li>company_name: " . ($hasCompanyName ? '✅ Var' : '❌ Yok') . "</li>";
    echo "<li>company_code: " . ($hasCompanyCode ? '✅ Var' : '❌ Yok') . "</li>";
    echo "<li>name: " . ($hasName ? '✅ Var' : '❌ Yok') . "</li>";
    echo "</ul>";
    
    // Check employees table structure  
    $stmt = $conn->query("DESCRIBE employees");
    $employeeColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasPasswordHash = false;
    $hasEmployeeCode = false;
    $hasIsActive = false;
    
    foreach ($employeeColumns as $col) {
        if ($col['Field'] === 'password_hash') $hasPasswordHash = true;
        if ($col['Field'] === 'employee_code') $hasEmployeeCode = true;
        if ($col['Field'] === 'is_active') $hasIsActive = true;
    }
    
    echo "<h3>Employees Tablo Sütunları:</h3>";
    echo "<ul>";
    echo "<li>password_hash: " . ($hasPasswordHash ? '✅ Var' : '❌ Yok') . "</li>";
    echo "<li>employee_code: " . ($hasEmployeeCode ? '✅ Var' : '❌ Yok') . "</li>";
    echo "<li>is_active: " . ($hasIsActive ? '✅ Var' : '❌ Yok') . "</li>";
    echo "</ul>";
    
    // Generate correct SQL based on available columns
    echo "<h2>🔧 Doğru SQL Sorgusu</h2>";
    
    $companySelect = "";
    if ($hasCompanyName && $hasCompanyCode) {
        $companySelect = "c.company_name, c.company_code";
    } elseif ($hasName) {
        $companySelect = "c.name as company_name, c.id as company_code";
    } else {
        $companySelect = "'Unknown' as company_name, c.id as company_code";
    }
    
    $correctSQL = "
    SELECT e.id, e.first_name, e.last_name, e.email, e.employee_code, 
           e.company_id, {$companySelect}
    FROM employees e 
    JOIN companies c ON e.company_id = c.id 
    WHERE e.employee_code = ? AND e.password_hash = PASSWORD(?) AND e.is_active = TRUE
    ";
    
    echo "<pre style='background:#f5f5f5; padding:15px; border-radius:5px;'>";
    echo htmlspecialchars($correctSQL);
    echo "</pre>";
    
    if (isset($_GET['autofix']) && $_GET['autofix'] === 'true') {
        echo "<h2>🔄 Employee Login Dosyasını Düzeltiliyor...</h2>";
        
        $loginFile = '../auth/employee-login.php';
        $content = file_get_contents($loginFile);
        
        // Fix the SQL query
        $oldPattern = '/c\.name as company_name, c\.id as company_code/';
        $newReplacement = $companySelect;
        
        if (preg_match($oldPattern, $content)) {
            $content = preg_replace($oldPattern, $newReplacement, $content);
            file_put_contents($loginFile, $content);
            echo "<p class='success'>✅ Employee login SQL sorgusu düzeltildi</p>";
        } else {
            echo "<p class='warning'>⚠️ SQL sorgusu zaten doğru görünüyor</p>";
        }
        
        // Test the fixed query
        echo "<h3>🧪 Düzeltilmiş Sorgu Testi</h3>";
        try {
            $stmt = $conn->prepare($correctSQL);
            echo "<p class='success'>✅ SQL sorgusu geçerli - prepare işlemi başarılı</p>";
        } catch (Exception $e) {
            echo "<p class='error'>❌ SQL sorgusu hâlâ hatalı: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<hr>";
    echo "<div style='background:#fff3cd; padding:15px; border-radius:5px; margin:20px 0;'>";
    echo "<h3>🔧 Otomatik Düzeltme</h3>";
    echo "<p>Employee login sayfasındaki SQL sorgusunu otomatik olarak düzeltmek ister misiniz?</p>";
    echo "<a href='?autofix=true' style='background:#28a745; color:white; padding:10px 20px; text-decoration:none; border-radius:5px; font-weight:bold;'>🔧 OTOMATİK DÜZELT</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ HATA: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='check-companies-table.php'>🔍 Companies Tablo</a> | <a href='../auth/employee-login.php'>← Employee Login</a></p>";
?>