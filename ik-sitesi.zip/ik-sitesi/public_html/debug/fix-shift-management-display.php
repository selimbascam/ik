<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=UTF-8');

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Vardiya Yönetimi Görünüm Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }";
echo ".container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo "table { border-collapse: collapse; width: 100%; margin: 20px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "button { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }";
echo "button:hover { background: #0056b3; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";

echo "<h1>🔧 Vardiya Yönetimi Görünüm Düzeltme</h1>";
echo "<p><strong>Sorunlar:</strong></p>";
echo "<ul>";
echo "<li>\"Son Vardiya Atamaları\" kısmında atamalar görünmüyor</li>";
echo "<li>Personel numaraları EMP formatında görünüyor (TC kimlik olmalı)</li>";
echo "<li>Çalışma programında atanan vardiyalar gözükmüyor</li>";
echo "<li>Foreign key constraint hatası vardiya atamalarını engelliyor</li>";
echo "</ul>";
echo "<hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get company ID
    $companyId = $_SESSION['company_id'] ?? 1;
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'fix_foreign_key') {
            echo "<h3>🔧 Foreign Key Constraint Düzeltiliyor...</h3>";
            
            try {
                // Drop problematic foreign key
                $conn->exec("ALTER TABLE employee_shifts DROP FOREIGN KEY employee_shifts_ibfk_3");
                echo "<div class='success'>✅ Hatalı foreign key constraint silindi</div>";
            } catch (Exception $e) {
                echo "<div class='warning'>⚠️ Foreign key silme: " . $e->getMessage() . "</div>";
            }
            
            try {
                // Fix column name if needed
                $conn->exec("ALTER TABLE employee_shifts CHANGE shift_id shift_template_id INT");
                echo "<div class='success'>✅ Kolon adı düzeltildi: shift_id → shift_template_id</div>";
            } catch (Exception $e) {
                echo "<div class='warning'>⚠️ Kolon değiştirme: " . $e->getMessage() . "</div>";
            }
            
            try {
                // Add correct foreign key
                $conn->exec("
                    ALTER TABLE employee_shifts 
                    ADD CONSTRAINT fk_employee_shifts_template 
                    FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
                ");
                echo "<div class='success'>✅ Doğru foreign key constraint eklendi</div>";
            } catch (Exception $e) {
                echo "<div class='warning'>⚠️ Foreign key ekleme: " . $e->getMessage() . "</div>";
            }
        }
        
        if ($action === 'test_shift_assignment') {
            echo "<h3>🧪 Vardiya Atama Test Ediliyor...</h3>";
            
            // Get first active employee and shift template
            $stmt = $conn->query("SELECT id FROM employees WHERE company_id = $companyId LIMIT 1");
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $stmt = $conn->query("SELECT id FROM shift_templates WHERE is_active = 1 LIMIT 1");
            $template = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($employee && $template) {
                try {
                    $testDate = date('Y-m-d', strtotime('+1 day'));
                    
                    $stmt = $conn->prepare("
                        INSERT INTO employee_shifts 
                        (employee_id, shift_template_id, shift_date, status) 
                        VALUES (?, ?, ?, 'scheduled')
                    ");
                    $stmt->execute([$employee['id'], $template['id'], $testDate]);
                    
                    echo "<div class='success'>✅ Test vardiyası başarıyla oluşturuldu!</div>";
                    
                    // Clean up
                    $conn->exec("DELETE FROM employee_shifts WHERE shift_date = '$testDate' AND employee_id = " . $employee['id']);
                    echo "<div class='info'>ℹ️ Test verisi temizlendi</div>";
                    
                } catch (Exception $e) {
                    echo "<div class='error'>❌ Test vardiya oluşturma hatası: " . $e->getMessage() . "</div>";
                }
            } else {
                echo "<div class='warning'>⚠️ Test için personel veya vardiya şablonu bulunamadı</div>";
            }
        }
        
        if ($action === 'clean_recent_shifts_cache') {
            echo "<h3>🧹 Son Vardiya Atamaları Cache Temizleniyor...</h3>";
            
            try {
                // Force refresh of recent shifts
                $stmt = $conn->prepare("
                    SELECT COUNT(*) as total 
                    FROM employee_shifts es 
                    INNER JOIN employees e ON es.employee_id = e.id 
                    WHERE e.company_id = ?
                ");
                $stmt->execute([$companyId]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                
                echo "<div class='success'>✅ Toplam " . $result['total'] . " vardiya ataması bulundu</div>";
                
                // Check recent assignments
                $stmt = $conn->prepare("
                    SELECT COUNT(*) as recent 
                    FROM employee_shifts es 
                    INNER JOIN employees e ON es.employee_id = e.id 
                    WHERE e.company_id = ? AND es.shift_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                ");
                $stmt->execute([$companyId]);
                $recentResult = $stmt->fetch(PDO::FETCH_ASSOC);
                
                echo "<div class='info'>ℹ️ Son 7 gündeki atama: " . $recentResult['recent'] . "</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Cache temizleme hatası: " . $e->getMessage() . "</div>";
            }
        }
    }
    
    echo "<div class='info'>";
    echo "<h3>🔍 Mevcut Durum Analizi</h3>";
    
    // Check foreign key constraints
    $stmt = $conn->query("
        SELECT 
            CONSTRAINT_NAME,
            TABLE_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'employee_shifts'
        AND REFERENCED_TABLE_NAME IS NOT NULL
    ");
    $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>📋 Foreign Key Constraints:</h4>";
    if (count($constraints) > 0) {
        echo "<table>";
        echo "<tr><th>Constraint</th><th>Kolon</th><th>Referans</th></tr>";
        foreach ($constraints as $constraint) {
            $status = ($constraint['REFERENCED_TABLE_NAME'] === 'shifts') ? "❌ HATALI" : "✅ DOĞRU";
            echo "<tr>";
            echo "<td>" . $constraint['CONSTRAINT_NAME'] . " $status</td>";
            echo "<td>" . $constraint['COLUMN_NAME'] . "</td>";
            echo "<td>" . $constraint['REFERENCED_TABLE_NAME'] . "." . $constraint['REFERENCED_COLUMN_NAME'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Hiç foreign key constraint bulunamadı.</p>";
    }
    
    // Check recent shift assignments
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total, 
               COUNT(CASE WHEN es.shift_date >= CURDATE() THEN 1 END) as future,
               COUNT(CASE WHEN es.shift_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN 1 END) as recent
        FROM employee_shifts es 
        INNER JOIN employees e ON es.employee_id = e.id 
        WHERE e.company_id = ?
    ");
    $stmt->execute([$companyId]);
    $shiftStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h4>📊 Vardiya İstatistikleri:</h4>";
    echo "<ul>";
    echo "<li>Toplam vardiya ataması: <strong>" . $shiftStats['total'] . "</strong></li>";
    echo "<li>Gelecekteki vardiyalar: <strong>" . $shiftStats['future'] . "</strong></li>";
    echo "<li>Son 7 günlük atama: <strong>" . $shiftStats['recent'] . "</strong></li>";
    echo "</ul>";
    
    // Check employee numbers
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total,
               COUNT(CASE WHEN tc_identity IS NOT NULL AND tc_identity != '' THEN 1 END) as with_tc,
               COUNT(CASE WHEN employee_number LIKE 'EMP%' THEN 1 END) as with_emp
        FROM employees 
        WHERE company_id = ?
    ");
    $stmt->execute([$companyId]);
    $empStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h4>👥 Personel Numarası Durumu:</h4>";
    echo "<ul>";
    echo "<li>Toplam personel: <strong>" . $empStats['total'] . "</strong></li>";
    echo "<li>TC kimlik olan: <strong>" . $empStats['with_tc'] . "</strong></li>";
    echo "<li>EMP formatında: <strong>" . $empStats['with_emp'] . "</strong></li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<hr>";
    echo "<h3>🛠️ Düzeltme İşlemleri</h3>";
    
    echo "<div style='display: flex; flex-wrap: wrap; gap: 10px; margin: 20px 0;'>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='fix_foreign_key'>";
    echo "<button type='submit' onclick='return confirm(\"Foreign key constraint düzeltilecek. Onaylıyor musunuz?\")'>🔧 Foreign Key Düzelt</button>";
    echo "</form>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='test_shift_assignment'>";
    echo "<button type='submit'>🧪 Vardiya Atama Test Et</button>";
    echo "</form>";
    
    echo "<form method='POST' style='display: inline;'>";
    echo "<input type='hidden' name='action' value='clean_recent_shifts_cache'>";
    echo "<button type='submit'>🧹 Vardiya Cache Temizle</button>";
    echo "</form>";
    
    echo "</div>";
    
    echo "<hr>";
    echo "<h3>📋 Son Vardiya Atamaları Testi</h3>";
    
    // Test recent shifts query
    try {
        $stmt = $conn->prepare("
            SELECT 
                es.id,
                es.shift_date,
                COALESCE(e.first_name, '') as first_name, 
                COALESCE(e.last_name, '') as last_name, 
                COALESCE(e.employee_number, CONCAT('EMP', e.id)) as employee_number,
                COALESCE(st.name, 'Vardiya') as shift_name
            FROM employee_shifts es
            INNER JOIN employees e ON es.employee_id = e.id AND e.company_id = ?
            LEFT JOIN shift_templates st ON es.shift_template_id = st.id
            WHERE es.shift_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            ORDER BY es.created_at DESC
            LIMIT 10
        ");
        $stmt->execute([$companyId]);
        $recentShifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($recentShifts) > 0) {
            echo "<div class='success'>";
            echo "<h4>✅ Son Vardiya Atamaları (Test Query)</h4>";
            echo "<table>";
            echo "<tr><th>Personel</th><th>Vardiya</th><th>Tarih</th></tr>";
            foreach ($recentShifts as $shift) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($shift['first_name'] . ' ' . $shift['last_name']) . "<br>";
                echo "<small>" . htmlspecialchars($shift['employee_number']) . "</small></td>";
                echo "<td>" . htmlspecialchars($shift['shift_name']) . "</td>";
                echo "<td>" . htmlspecialchars($shift['shift_date']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            echo "</div>";
        } else {
            echo "<div class='warning'>";
            echo "<h4>⚠️ Son Vardiya Atamaları Bulunamadı</h4>";
            echo "<p>Son 7 günde hiç vardiya ataması yapılmamış veya sorgu çalışmıyor.</p>";
            echo "</div>";
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>";
        echo "<h4>❌ Son Vardiya Atamaları Query Hatası</h4>";
        echo "<p>" . $e->getMessage() . "</p>";
        echo "</div>";
    }
    
    echo "<div style='margin-top: 30px;'>";
    echo "<h4>🔗 Kontrol Bağlantıları</h4>";
    echo "<div style='display: flex; gap: 10px;'>";
    echo "<a href='../admin/shift-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Yönetimi</a>";
    echo "<a href='../employee/shift-schedule.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Çalışma Programı</a>";
    echo "<a href='fix-employee-number-display.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Personel No Düzelt</a>";
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>