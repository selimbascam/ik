<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$testResults = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🧪 Salary Column Tests</h1>";
    
    // Test 1: Check if salary column exists
    echo "<h2>Test 1: Salary Column Check</h2>";
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'salary'");
        if ($stmt->rowCount() > 0) {
            echo "✅ salary column exists<br>";
            $testResults[] = "PASS: salary column exists";
        } else {
            echo "❌ salary column missing<br>";
            $testResults[] = "FAIL: salary column missing";
        }
    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: " . $e->getMessage();
    }
    
    // Test 2: Test COALESCE query
    echo "<h2>Test 2: COALESCE Salary Query</h2>";
    try {
        $stmt = $conn->query("SELECT e.id, e.first_name, COALESCE(e.salary, 0) as salary FROM employees e LIMIT 3");
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "✅ COALESCE query works - got " . count($results) . " results<br>";
        foreach ($results as $row) {
            echo "- Employee: {$row['first_name']}, Salary: {$row['salary']}<br>";
        }
        $testResults[] = "PASS: COALESCE query works";
    } catch (Exception $e) {
        echo "❌ COALESCE query failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: COALESCE query - " . $e->getMessage();
    }
    
    // Test 3: Test attendance tracking query
    echo "<h2>Test 3: Attendance Tracking Query</h2>";
    try {
        $stmt = $conn->prepare("
            SELECT 
                e.id,
                e.first_name,
                e.last_name,
                COALESCE(e.salary, 0) as salary
            FROM employees e
            WHERE e.company_id = 1
            LIMIT 1
        ");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            echo "✅ Attendance tracking salary query works<br>";
            echo "- Sample: {$result['first_name']} {$result['last_name']}, Salary: {$result['salary']}<br>";
            $testResults[] = "PASS: Attendance tracking query works";
        } else {
            echo "⚠️ No employees found for company 1<br>";
            $testResults[] = "WARNING: No employees in company 1";
        }
    } catch (Exception $e) {
        echo "❌ Attendance tracking query failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Attendance tracking - " . $e->getMessage();
    }
    
    // Test 4: Test monthly summary API compatibility
    echo "<h2>Test 4: Monthly Summary API Compatibility</h2>";
    try {
        // Test a query similar to what monthly summary uses
        $stmt = $conn->query("
            SELECT e.*, d.name as department_name, COALESCE(e.salary, 0) as calculated_salary
            FROM employees e 
            LEFT JOIN departments d ON e.department_id = d.id 
            WHERE COALESCE(e.status, 'active') = 'active'
            LIMIT 1
        ");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            echo "✅ Monthly summary compatible query works<br>";
            echo "- Sample: {$result['first_name']}, Calculated Salary: {$result['calculated_salary']}<br>";
            $testResults[] = "PASS: Monthly summary compatibility";
        } else {
            echo "⚠️ No active employees found<br>";
            $testResults[] = "WARNING: No active employees";
        }
    } catch (Exception $e) {
        echo "❌ Monthly summary compatibility failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Monthly summary - " . $e->getMessage();
    }
    
    echo "<h2>📋 Test Summary</h2>";
    foreach ($testResults as $result) {
        $status = substr($result, 0, 4);
        $color = $status === 'PASS' ? 'green' : ($status === 'FAIL' ? 'red' : 'orange');
        echo "<div style='color: $color;'>$result</div>";
    }
    
    $passCount = count(array_filter($testResults, fn($r) => substr($r, 0, 4) === 'PASS'));
    $totalCount = count($testResults);
    
    echo "<h3>Results: $passCount/$totalCount tests passed</h3>";
    
    if ($passCount === $totalCount) {
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "🎉 All tests passed! Salary column issues are resolved.";
        echo "</div>";
    }

} catch (Exception $e) {
    echo "<h2>❌ Critical Error</h2>";
    echo "<p>Database connection failed: " . $e->getMessage() . "</p>";
}
?>

<div style="margin-top: 20px;">
    <a href="../super-admin/fix-critical-errors.php" style="background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px;">
        ← Back to Critical Errors
    </a>
    <a href="fix-salary-column.php" style="background: #ffc107; color: black; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        💰 Salary Column Fix
    </a>
</div>