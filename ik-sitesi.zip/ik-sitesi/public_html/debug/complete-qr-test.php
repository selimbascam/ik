<?php
/**
 * Complete QR System Test - Final Verification
 * Tests all aspects of the QR attendance system
 */

// Basic includes
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/qr-attendance-fixed.php';

header('Content-Type: text/html; charset=utf-8');

// Test parameters
$testEmployeeId = 1;
$testCompanyId = 1;
$testLocationId = 13; // From the screenshot
$today = date('Y-m-d');

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete QR System Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #059669; background: #d1fae5; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .error { color: #dc2626; background: #fee2e2; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .info { color: #0369a1; background: #dbeafe; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .test-section { border: 1px solid #e5e7eb; margin: 15px 0; padding: 15px; border-radius: 8px; }
        .test-result { margin: 10px 0; padding: 8px; border-radius: 4px; }
        h1, h2 { color: #1f2937; }
        pre { background: #f9fafb; padding: 10px; border-radius: 5px; overflow: auto; font-size: 12px; }
        .action-button { display: inline-block; background: #3b82f6; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; margin: 5px; }
        .action-button:hover { background: #2563eb; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 QR Attendance System - Complete Test</h1>
        <p>Testing all aspects of the QR attendance system with fixed column mapping.</p>
        
        <?php
        try {
            // Test 1: Database Connection
            echo "<div class='test-section'>";
            echo "<h2>📊 Test 1: Database Connection</h2>";
            
            $conn = Database::getInstance()->getConnection();
            echo "<div class='success'>✅ Database connection successful</div>";
            
            // Test 2: Column Mapping
            echo "<h2>🗂️ Test 2: Column Mapping</h2>";
            $colMap = QRAttendanceHelper::getColumnMapping($conn);
            echo "<div class='success'>✅ Column mapping successful</div>";
            echo "<pre>" . json_encode($colMap, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
            
            // Test 3: Employee & Company Validation
            echo "<h2>👤 Test 3: Employee & Company Validation</h2>";
            $stmt = $conn->prepare("SELECT e.*, c.name as company_name FROM employees e LEFT JOIN companies c ON e.company_id = c.id WHERE e.id = ? AND e.company_id = ?");
            $stmt->execute([$testEmployeeId, $testCompanyId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($employee) {
                echo "<div class='success'>✅ Employee found: {$employee['first_name']} {$employee['last_name']} - {$employee['company_name']}</div>";
            } else {
                echo "<div class='error'>❌ Employee not found</div>";
                throw new Exception("Employee validation failed");
            }
            
            // Test 4: QR Location Validation
            echo "<h2>📍 Test 4: QR Location Validation</h2>";
            $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE id = ?");
            $stmt->execute([$testLocationId]);
            $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($qrLocation) {
                echo "<div class='success'>✅ QR Location found: {$qrLocation['name']}</div>";
                echo "<div class='info'>Gate Behavior: " . ($qrLocation['gate_behavior'] ?? 'user_choice') . "</div>";
            } else {
                echo "<div class='error'>❌ QR Location not found</div>";
                throw new Exception("QR Location validation failed");
            }
            
            // Test 5: Current Attendance Status
            echo "<h2>⏰ Test 5: Current Attendance Status</h2>";
            $stmt = $conn->prepare("
                SELECT 
                    {$colMap['check_in']} as check_in,
                    {$colMap['check_out']} as check_out,
                    {$colMap['break_start']} as break_start,
                    {$colMap['break_end']} as break_end
                FROM attendance_records 
                WHERE employee_id = ? AND {$colMap['date']} = ?
            ");
            $stmt->execute([$testEmployeeId, $today]);
            $currentAttendance = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($currentAttendance) {
                echo "<div class='info'>📋 Current attendance record found for today</div>";
                echo "<pre>" . json_encode($currentAttendance, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
            } else {
                echo "<div class='info'>📋 No attendance record for today - ready for first check-in</div>";
            }
            
            // Test 6: Gate Action Determination
            echo "<h2>🎯 Test 6: Gate Action Determination</h2>";
            $behaviors = ['work_start', 'work_end', 'break_toggle', 'user_choice'];
            
            foreach ($behaviors as $behavior) {
                echo "<h3>Testing: $behavior</h3>";
                $result = QRAttendanceHelper::determineGateAction($conn, $testEmployeeId, $testCompanyId, $testLocationId, $behavior, $today);
                
                if ($result) {
                    echo "<div class='success'>✅ $behavior: {$result['action']} - {$result['message']}</div>";
                } else {
                    echo "<div class='error'>❌ $behavior: Failed to determine action</div>";
                }
            }
            
            // Test 7: Test Actions (Simulation)
            echo "<h2>🧪 Test 7: Action Simulation</h2>";
            echo "<div class='info'>
                <strong>Simulation Links:</strong><br>
                <a href='qr-test-action.php?action=check_in&employee_id=$testEmployeeId&company_id=$testCompanyId&location_id=$testLocationId' class='action-button'>🟢 Test Check In</a>
                <a href='qr-test-action.php?action=break_start&employee_id=$testEmployeeId&company_id=$testCompanyId&location_id=$testLocationId' class='action-button'>🟡 Test Break Start</a>
                <a href='qr-test-action.php?action=break_end&employee_id=$testEmployeeId&company_id=$testCompanyId&location_id=$testLocationId' class='action-button'>🟢 Test Break End</a>
                <a href='qr-test-action.php?action=check_out&employee_id=$testEmployeeId&company_id=$testCompanyId&location_id=$testLocationId' class='action-button'>🔴 Test Check Out</a>
            </div>";
            
            // Test 8: Real QR Processing
            echo "<h2>🔍 Test 8: QR Reader Integration</h2>";
            echo "<div class='info'>
                <strong>Test QR Scanning:</strong><br>
                <a href='../qr/qr-reader.php?qr_code=Location_13' class='action-button'>📱 Test QR Reader with Location 13</a>
                <a href='test-qr-detection.php' class='action-button'>🔧 Advanced QR Detection Test</a>
            </div>";
            
            echo "</div>"; // End test-section
            
            echo "<div class='success'>";
            echo "<h2>🎉 Test Results Summary</h2>";
            echo "✅ Database connection: Working<br>";
            echo "✅ Column mapping: Working<br>";
            echo "✅ Employee validation: Working<br>";
            echo "✅ QR location validation: Working<br>";
            echo "✅ Attendance status check: Working<br>";
            echo "✅ Gate action determination: Working<br>";
            echo "✅ QR system integration: Ready for testing<br>";
            echo "</div>";
            
        } catch (Exception $e) {
            echo "<div class='error'>";
            echo "<h2>❌ Test Failed</h2>";
            echo "<p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
            echo "<p><strong>Location:</strong> " . $e->getFile() . " on line " . $e->getLine() . "</p>";
            echo "</div>";
        }
        ?>
        
        <div class="test-section">
            <h2>🔗 Quick Links</h2>
            <a href="../employee/dashboard.php" class="action-button">👤 Employee Dashboard</a>
            <a href="../admin/dashboard.php" class="action-button">👨‍💼 Admin Dashboard</a>
            <a href="../qr/qr-reader.php" class="action-button">📱 QR Reader</a>
            <a href="fix-all-attendance-columns.php" class="action-button">🔧 Fix Columns</a>
        </div>
    </div>
</body>
</html>