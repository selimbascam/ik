<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/error-logger.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin']) && (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'super_admin')) {
    header('Location: ../admin/login.php');
    exit();
}

$message = '';
$messageType = '';
$diagnostics = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix_action'])) {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        switch ($_POST['fix_action']) {
            case 'diagnose_employee_issue':
                // Comprehensive employee diagnostics for shift management
                $companyId = $_POST['company_id'] ?? 4;
                
                // 1. Check if company exists
                $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
                $stmt->execute([$companyId]);
                $company = $stmt->fetch(PDO::FETCH_ASSOC);
                $diagnostics['company_exists'] = $company ? "✅ Şirket bulundu: " . $company['company_name'] : "❌ Şirket ID $companyId bulunamadı";
                
                // 2. Check employees table structure
                $stmt = $conn->query("DESCRIBE employees");
                $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $hasIsActive = false;
                $hasCompanyId = false;
                foreach ($columns as $col) {
                    if ($col['Field'] === 'is_active') $hasIsActive = true;
                    if ($col['Field'] === 'company_id') $hasCompanyId = true;
                }
                $diagnostics['table_structure'] = "✅ Employees tablo: " . ($hasCompanyId ? "company_id ✅" : "company_id ❌") . ", " . ($hasIsActive ? "is_active ✅" : "is_active ❌");
                
                // 3. Count total employees for company
                if ($company) {
                    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM employees WHERE company_id = ?");
                    $stmt->execute([$companyId]);
                    $totalEmployees = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
                    
                    // 4. Count active employees
                    $activeCount = 0;
                    if ($hasIsActive) {
                        $stmt = $conn->prepare("SELECT COUNT(*) as active FROM employees WHERE company_id = ? AND is_active = 1");
                        $stmt->execute([$companyId]);
                        $activeCount = $stmt->fetch(PDO::FETCH_ASSOC)['active'];
                    }
                    
                    $diagnostics['employee_count'] = "📊 Toplam personel: $totalEmployees, Aktif: $activeCount";
                    
                    // 5. Sample employee data
                    $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number, is_active FROM employees WHERE company_id = ? LIMIT 5");
                    $stmt->execute([$companyId]);
                    $sampleEmployees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $diagnostics['sample_data'] = count($sampleEmployees) > 0 ? "✅ Örnek personel: " . count($sampleEmployees) . " kayıt" : "❌ Hiç personel kaydı yok";
                }
                
                $message = "🔍 Tanı tamamlandı";
                $messageType = "info";
                break;
                
            case 'fix_employee_data':
                $companyId = $_POST['company_id'] ?? 4;
                $fixedIssues = [];
                
                // 1. Add missing is_active column if needed
                try {
                    $conn->exec("ALTER TABLE employees ADD COLUMN is_active TINYINT(1) DEFAULT 1");
                    $fixedIssues[] = "is_active kolonu eklendi";
                } catch (PDOException $e) {
                    if (!strpos($e->getMessage(), 'Duplicate column')) {
                        $fixedIssues[] = "is_active kolonu zaten mevcut";
                    }
                }
                
                // 2. Update null is_active values
                $stmt = $conn->prepare("UPDATE employees SET is_active = 1 WHERE is_active IS NULL AND company_id = ?");
                $stmt->execute([$companyId]);
                $updatedRows = $stmt->rowCount();
                if ($updatedRows > 0) {
                    $fixedIssues[] = "$updatedRows personelin is_active değeri güncellendi";
                }
                
                // 3. Check if company has no employees - create a sample
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE company_id = ?");
                $stmt->execute([$companyId]);
                $employeeCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                
                if ($employeeCount == 0) {
                    // Create a sample employee for testing
                    $stmt = $conn->prepare("
                        INSERT INTO employees (company_id, first_name, last_name, employee_number, email, is_active, created_at)
                        VALUES (?, 'Test', 'Personel', ?, 'test@company.com', 1, NOW())
                    ");
                    $stmt->execute([$companyId, 'EMP' . $companyId . '001']);
                    $fixedIssues[] = "Test personeli oluşturuldu";
                }
                
                // 4. Ensure proper indexing for performance
                try {
                    $conn->exec("CREATE INDEX IF NOT EXISTS idx_company_active ON employees(company_id, is_active)");
                    $fixedIssues[] = "Index optimizasyonu yapıldı";
                } catch (PDOException $e) {
                    // Index already exists
                }
                
                $message = "✅ Düzeltmeler tamamlandı: " . implode(", ", $fixedIssues);
                $messageType = "success";
                break;
                
            case 'test_employee_query':
                $companyId = $_POST['company_id'] ?? 4;
                
                // Test the exact query from shift-management.php
                try {
                    $stmt = $conn->prepare("
                        SELECT 
                            id, 
                            COALESCE(first_name, '') as first_name, 
                            COALESCE(last_name, '') as last_name, 
                            COALESCE(employee_number, CONCAT('EMP', id)) as employee_number,
                            COALESCE(department_id, 0) as department_id
                        FROM employees 
                        WHERE company_id = ? AND is_active = 1 
                        ORDER BY first_name, last_name
                    ");
                    $stmt->execute([$companyId]);
                    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (count($employees) > 0) {
                        $message = "✅ Query başarılı - " . count($employees) . " aktif personel bulundu";
                        $messageType = "success";
                    } else {
                        // Try without is_active
                        $stmt = $conn->prepare("SELECT id, first_name, last_name FROM employees WHERE company_id = ?");
                        $stmt->execute([$companyId]);
                        $allEmployees = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        $message = "⚠️ Aktif personel yok, toplam: " . count($allEmployees);
                        $messageType = "warning";
                    }
                } catch (PDOException $e) {
                    $message = "❌ Query hatası: " . $e->getMessage();
                    $messageType = "error";
                }
                break;
        }
        
    } catch (Exception $e) {
        $message = "❌ Hata: " . $e->getMessage();
        $messageType = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vardiya Personel Listesi Sorun Giderme - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            
            <!-- Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h1 class="text-2xl font-bold text-gray-900 mb-2">🔧 Vardiya Personel Listesi Sorun Giderme</h1>
                <p class="text-gray-600">
                    "Personel listesi alınamadı" hatası için kapsamlı tanı ve düzeltme aracı
                </p>
            </div>

            <!-- Message Display -->
            <?php if ($message): ?>
                <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 border border-green-200 text-green-800' : ($messageType === 'error' ? 'bg-red-100 border border-red-200 text-red-800' : 'bg-blue-100 border border-blue-200 text-blue-800'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Diagnostics Results -->
            <?php if (!empty($diagnostics)): ?>
                <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">📊 Tanı Sonuçları</h2>
                    <div class="space-y-2">
                        <?php foreach ($diagnostics as $key => $result): ?>
                            <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                <span class="font-medium"><?php echo ucfirst(str_replace('_', ' ', $key)); ?>:</span>
                                <span><?php echo $result; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Diagnostic Tools -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                
                <!-- Company Diagnostics -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">🔍 Şirket Tanısı</h2>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Şirket ID</label>
                            <input type="number" name="company_id" value="4" class="w-full border border-gray-300 rounded-lg px-3 py-2" required>
                        </div>
                        <button type="submit" name="fix_action" value="diagnose_employee_issue" 
                                class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                            🔍 Tanı Çalıştır
                        </button>
                    </form>
                </div>

                <!-- Quick Fix -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">⚡ Hızlı Düzeltme</h2>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Şirket ID</label>
                            <input type="number" name="company_id" value="4" class="w-full border border-gray-300 rounded-lg px-3 py-2" required>
                        </div>
                        <button type="submit" name="fix_action" value="fix_employee_data" 
                                class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg">
                            🔧 Otomatik Düzelt
                        </button>
                    </form>
                </div>

                <!-- Query Test -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">🧪 Query Testi</h2>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Şirket ID</label>
                            <input type="number" name="company_id" value="4" class="w-full border border-gray-300 rounded-lg px-3 py-2" required>
                        </div>
                        <button type="submit" name="fix_action" value="test_employee_query" 
                                class="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg">
                            🧪 Query'yi Test Et
                        </button>
                    </form>
                </div>

                <!-- Back to Admin -->
                <div class="bg-white rounded-lg shadow-lg p-6 flex items-center justify-center">
                    <div class="text-center">
                        <h3 class="text-lg font-bold text-gray-900 mb-4">🔙 Geri Dön</h3>
                        <a href="../admin/shift-management.php" class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg inline-block">
                            Vardiya Yönetimine Dön
                        </a>
                    </div>
                </div>
                
            </div>

            <!-- Instructions -->
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 class="text-lg font-bold text-blue-800 mb-3">📋 Kullanım Talimatları</h3>
                <ol class="list-decimal list-inside space-y-2 text-blue-700">
                    <li><strong>Tanı Çalıştır:</strong> Şirket ve personel verilerini kontrol eder</li>
                    <li><strong>Otomatik Düzelt:</strong> Eksik kolonları ekler ve veri tutarlılığını sağlar</li>
                    <li><strong>Query'yi Test Et:</strong> Vardiya yönetiminde kullanılan sorguyu test eder</li>
                    <li><strong>Sonuç:</strong> Vardiya yönetimine geri dönerek personel listesini kontrol edin</li>
                </ol>
            </div>

        </div>
    </div>
</body>
</html>