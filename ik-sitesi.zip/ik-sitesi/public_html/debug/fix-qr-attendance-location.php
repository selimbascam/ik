<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/error-logger.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$message = '';
$messageType = '';
$diagnostics = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    function addDiagnostic($type, $title, $details) {
        global $diagnostics;
        $diagnostics[] = [
            'type' => $type,
            'title' => $title,
            'details' => $details
        ];
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fix_action'])) {
        switch ($_POST['fix_action']) {
            case 'add_location_column':
                try {
                    // Check if location column already exists
                    $columns = $conn->query("SHOW COLUMNS FROM attendance_records")->fetchAll(PDO::FETCH_ASSOC);
                    $columnNames = array_column($columns, 'Field');
                    
                    $steps = [];
                    
                    if (!in_array('location', $columnNames)) {
                        $conn->exec("ALTER TABLE attendance_records ADD COLUMN location VARCHAR(255) DEFAULT NULL AFTER qr_location_id");
                        $steps[] = "✅ location column added to attendance_records table";
                    } else {
                        $steps[] = "ℹ️ location column already exists";
                    }
                    
                    // Also check for qr_location_id column
                    if (!in_array('qr_location_id', $columnNames)) {
                        $conn->exec("ALTER TABLE attendance_records ADD COLUMN qr_location_id INT DEFAULT NULL");
                        $steps[] = "✅ qr_location_id column added to attendance_records table";
                    } else {
                        $steps[] = "ℹ️ qr_location_id column already exists";
                    }
                    
                    // Add location_name column for better QR support
                    if (!in_array('location_name', $columnNames)) {
                        $conn->exec("ALTER TABLE attendance_records ADD COLUMN location_name VARCHAR(255) DEFAULT NULL");
                        $steps[] = "✅ location_name column added to attendance_records table";
                    } else {
                        $steps[] = "ℹ️ location_name column already exists";
                    }
                    
                    $message = "🔧 Attendance Records Table Fixed:<br>" . implode('<br>', $steps);
                    $messageType = "success";
                    addDiagnostic('success', 'Table Fix Complete', 'attendance_records table structure corrected');
                } catch (Exception $e) {
                    $message = "❌ Failed to fix attendance_records table: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Table Fix Failed', $e->getMessage());
                }
                break;
                
            case 'fix_attendance_queries':
                try {
                    $steps = [];
                    
                    // Check attendance-tracking.php query
                    $attendanceTrackingPath = '../admin/attendance-tracking.php';
                    if (file_exists($attendanceTrackingPath)) {
                        $content = file_get_contents($attendanceTrackingPath);
                        
                        // Fix the problematic query that references ar.location
                        $oldQuery = 'LEFT JOIN attendance_records ar ON e.id = ar.employee_id 
            AND ar.date BETWEEN ? AND ?';
                        
                        $newQuery = 'LEFT JOIN attendance_records ar ON e.id = ar.employee_id 
            AND ar.date BETWEEN ? AND ?';
                        
                        // The actual issue is likely in a different part - let's check for ar.location references
                        if (strpos($content, 'ar.location') !== false) {
                            // Replace ar.location with COALESCE(ar.location, ar.location_name, 'Bilinmeyen')
                            $content = str_replace('ar.location', "COALESCE(ar.location, ar.location_name, 'Bilinmeyen') as location", $content);
                            file_put_contents($attendanceTrackingPath, $content);
                            $steps[] = "✅ Fixed ar.location references in attendance-tracking.php";
                        } else {
                            $steps[] = "ℹ️ No ar.location references found in attendance-tracking.php";
                        }
                    }
                    
                    // Check for other files that might have ar.location
                    $phpFiles = glob('../**/*.php');
                    $fixedFiles = 0;
                    
                    foreach ($phpFiles as $file) {
                        if (is_file($file)) {
                            $content = file_get_contents($file);
                            if (strpos($content, 'ar.location') !== false && strpos($content, 'SELECT') !== false) {
                                $content = str_replace('ar.location', "COALESCE(ar.location, ar.location_name, 'Bilinmeyen') as location", $content);
                                file_put_contents($file, $content);
                                $fixedFiles++;
                                $steps[] = "✅ Fixed ar.location in " . basename($file);
                            }
                        }
                    }
                    
                    if ($fixedFiles === 0) {
                        $steps[] = "ℹ️ No additional files with ar.location found";
                    }
                    
                    $message = "🔧 QR Attendance Queries Fixed:<br>" . implode('<br>', $steps);
                    $messageType = "success";
                    addDiagnostic('success', 'Query Fix Complete', 'Fixed all ar.location references');
                } catch (Exception $e) {
                    $message = "❌ Failed to fix attendance queries: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Query Fix Failed', $e->getMessage());
                }
                break;
                
            case 'comprehensive_qr_attendance_fix':
                $steps = [];
                
                // Step 1: Fix attendance_records table structure
                try {
                    $columns = $conn->query("SHOW COLUMNS FROM attendance_records")->fetchAll(PDO::FETCH_ASSOC);
                    $columnNames = array_column($columns, 'Field');
                    
                    $requiredColumns = [
                        'location' => 'VARCHAR(255) DEFAULT NULL',
                        'qr_location_id' => 'INT DEFAULT NULL',
                        'location_name' => 'VARCHAR(255) DEFAULT NULL',
                        'latitude' => 'DECIMAL(10,8) DEFAULT NULL',
                        'longitude' => 'DECIMAL(11,8) DEFAULT NULL'
                    ];
                    
                    foreach ($requiredColumns as $column => $definition) {
                        if (!in_array($column, $columnNames)) {
                            $conn->exec("ALTER TABLE attendance_records ADD COLUMN $column $definition");
                            $steps[] = "✅ $column column added";
                        } else {
                            $steps[] = "ℹ️ $column column exists";
                        }
                    }
                } catch (Exception $e) {
                    $steps[] = "❌ Table structure fix failed: " . $e->getMessage();
                }
                
                // Step 2: Fix PHP query files
                try {
                    $phpFiles = [
                        '../admin/attendance-tracking.php',
                        '../api/process-attendance.php',
                        '../qr/qr-reader.php',
                        '../qr/qr-reader-enhanced.php'
                    ];
                    
                    $fixedFiles = 0;
                    foreach ($phpFiles as $file) {
                        if (file_exists($file)) {
                            $content = file_get_contents($file);
                            $originalContent = $content;
                            
                            // Fix ar.location references
                            $content = str_replace(
                                'ar.location',
                                "COALESCE(ar.location, ar.location_name, 'Bilinmeyen') as location",
                                $content
                            );
                            
                            // Fix other potential issues
                            $content = str_replace(
                                'SELECT ar.location',
                                "SELECT COALESCE(ar.location, ar.location_name, 'Bilinmeyen') as location",
                                $content
                            );
                            
                            if ($content !== $originalContent) {
                                file_put_contents($file, $content);
                                $fixedFiles++;
                                $steps[] = "✅ Fixed " . basename($file);
                            }
                        }
                    }
                    
                    if ($fixedFiles === 0) {
                        $steps[] = "ℹ️ No PHP files needed fixing";
                    }
                } catch (Exception $e) {
                    $steps[] = "❌ PHP files fix failed: " . $e->getMessage();
                }
                
                // Step 3: Mark errors as solved
                try {
                    $stmt = $conn->prepare("
                        UPDATE system_error_log 
                        SET status = 'solved', 
                            solution_notes = 'QR attendance location column errors fixed - added missing location columns',
                            solved_by = 'QR Attendance Location Fix Tool',
                            solved_at = NOW()
                        WHERE (error_message LIKE '%ar.location%' 
                        OR error_message LIKE '%attendance_records%location%'
                        OR error_message LIKE '%Column not found%location%')
                        AND status = 'unsolved'
                    ");
                    $stmt->execute();
                    $fixedErrorCount = $stmt->rowCount();
                    $steps[] = "✅ " . $fixedErrorCount . " related errors marked as solved";
                } catch (Exception $e) {
                    $steps[] = "⚠️ Error marking: " . $e->getMessage();
                }
                
                $message = "🔧 Comprehensive QR Attendance Fix Completed:<br>" . implode('<br>', $steps);
                $messageType = "success";
                break;
                
            case 'test_qr_attendance':
                try {
                    // Test attendance_records table structure
                    $columns = $conn->query("SHOW COLUMNS FROM attendance_records")->fetchAll(PDO::FETCH_ASSOC);
                    $columnNames = array_column($columns, 'Field');
                    
                    $requiredColumns = ['location', 'qr_location_id', 'location_name'];
                    $existingColumns = array_intersect($requiredColumns, $columnNames);
                    
                    // Test a simple SELECT query
                    $stmt = $conn->prepare("
                        SELECT 
                            e.id,
                            e.first_name,
                            COALESCE(ar.location, ar.location_name, 'Bilinmeyen') as location
                        FROM employees e
                        LEFT JOIN attendance_records ar ON e.id = ar.employee_id
                        WHERE e.company_id = 1
                        LIMIT 5
                    ");
                    $stmt->execute();
                    $testResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    $message = "✅ QR attendance queries test successful. Found " . count($existingColumns) . " location columns. Test returned " . count($testResults) . " records.";
                    $messageType = "success";
                    addDiagnostic('success', 'Query Test', 'QR attendance system queries work correctly');
                } catch (Exception $e) {
                    $message = "❌ QR attendance test failed: " . $e->getMessage();
                    $messageType = "error";
                    addDiagnostic('error', 'Query Test Failed', $e->getMessage());
                }
                break;
        }
    }
    
    // Diagnostic checks
    addDiagnostic('info', 'Database Connection', 'Connected successfully');
    
    // Check attendance_records table structure
    try {
        $columns = $conn->query("SHOW COLUMNS FROM attendance_records")->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        
        $requiredColumns = ['location', 'qr_location_id', 'location_name'];
        $existingColumns = array_intersect($requiredColumns, $columnNames);
        $missingColumns = array_diff($requiredColumns, $columnNames);
        
        if (!empty($existingColumns)) {
            addDiagnostic('success', 'Existing Location Columns', implode(', ', $existingColumns));
        }
        if (!empty($missingColumns)) {
            addDiagnostic('error', 'Missing Location Columns', implode(', ', $missingColumns));
        }
    } catch (Exception $e) {
        addDiagnostic('error', 'attendance_records Check', $e->getMessage());
    }
    
    // Check for recent QR attendance errors
    try {
        $stmt = $conn->query("
            SELECT COUNT(*) as error_count 
            FROM system_error_log 
            WHERE (error_message LIKE '%ar.location%' 
            OR error_message LIKE '%attendance_records%location%')
            AND status = 'unsolved'
            AND DATE(created_at) >= CURDATE() - INTERVAL 1 DAY
        ");
        $errorCount = $stmt->fetch(PDO::FETCH_ASSOC)['error_count'];
        
        if ($errorCount > 0) {
            addDiagnostic('error', 'Recent QR Attendance Errors', $errorCount . ' unsolved location errors in last 24 hours');
        } else {
            addDiagnostic('success', 'Recent QR Attendance Errors', 'No recent QR attendance location errors');
        }
    } catch (Exception $e) {
        addDiagnostic('warning', 'Error Check', 'Could not check recent errors: ' . $e->getMessage());
    }

} catch (Exception $e) {
    $message = "Database connection failed: " . $e->getMessage();
    $messageType = "error";
    addDiagnostic('error', 'Critical Error', $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Attendance Location Fix - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Header -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">📱 QR Attendance Location Fix</h1>
                        <p class="text-gray-600 mt-1">QR kod devam takibi location hatalarını düzeltin</p>
                    </div>
                    <a href="../super-admin/fix-critical-errors.php" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg">
                        ← Critical Errors
                    </a>
                </div>
            </div>

            <!-- Message -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg border <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border-green-200' : ($messageType === 'error' ? 'bg-red-100 text-red-800 border-red-200' : 'bg-blue-100 text-blue-800 border-blue-200'); ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Quick Fixes -->
            <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Quick Fixes</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    <!-- Fix attendance_records table -->
                    <div class="border border-red-200 rounded-lg p-4 bg-red-50">
                        <h3 class="font-bold text-red-800 mb-2">📊 Attendance Records Table</h3>
                        <p class="text-sm text-red-600 mb-3">
                            attendance_records tablosuna eksik location sütunlarını ekle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="add_location_column" 
                                    class="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm">
                                📊 Fix Location Columns
                            </button>
                        </form>
                    </div>
                    
                    <!-- Fix attendance queries -->
                    <div class="border border-purple-200 rounded-lg p-4 bg-purple-50">
                        <h3 class="font-bold text-purple-800 mb-2">🔍 Attendance Queries</h3>
                        <p class="text-sm text-purple-600 mb-3">
                            PHP dosyalarındaki ar.location referanslarını düzelt.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="fix_attendance_queries" 
                                    class="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm">
                                🔍 Fix Query References
                            </button>
                        </form>
                    </div>

                    <!-- Test QR attendance -->
                    <div class="border border-blue-200 rounded-lg p-4 bg-blue-50">
                        <h3 class="font-bold text-blue-800 mb-2">🧪 Test QR Attendance</h3>
                        <p class="text-sm text-blue-600 mb-3">
                            QR devam takibi sorgularının çalışıp çalışmadığını test et.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="test_qr_attendance" 
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                                🧪 Test QR Attendance
                            </button>
                        </form>
                    </div>

                    <!-- Comprehensive Fix -->
                    <div class="border border-green-200 rounded-lg p-4 bg-green-50">
                        <h3 class="font-bold text-green-800 mb-2">🔧 Comprehensive QR Fix</h3>
                        <p class="text-sm text-green-600 mb-3">
                            Tüm QR devam takibi hatalarını düzelt ve hataları işaretle.
                        </p>
                        <form method="POST">
                            <button type="submit" name="fix_action" value="comprehensive_qr_attendance_fix" 
                                    class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm">
                                🔧 Complete QR Attendance Fix
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Diagnostics -->
            <?php if (!empty($diagnostics)): ?>
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🔍 System Diagnostics</h2>
                
                <div class="space-y-3">
                    <?php foreach ($diagnostics as $diagnostic): ?>
                        <div class="border-l-4 p-3 <?php echo $diagnostic['type'] === 'success' ? 'border-green-500 bg-green-50' : ($diagnostic['type'] === 'error' ? 'border-red-500 bg-red-50' : ($diagnostic['type'] === 'warning' ? 'border-yellow-500 bg-yellow-50' : 'border-blue-500 bg-blue-50')); ?>">
                            <h4 class="font-bold <?php echo $diagnostic['type'] === 'success' ? 'text-green-800' : ($diagnostic['type'] === 'error' ? 'text-red-800' : ($diagnostic['type'] === 'warning' ? 'text-yellow-800' : 'text-blue-800')); ?>">
                                <?php 
                                $icon = $diagnostic['type'] === 'success' ? '✅' : ($diagnostic['type'] === 'error' ? '❌' : ($diagnostic['type'] === 'warning' ? '⚠️' : 'ℹ️'));
                                echo $icon . ' ' . $diagnostic['title']; 
                                ?>
                            </h4>
                            <p class="text-sm <?php echo $diagnostic['type'] === 'success' ? 'text-green-600' : ($diagnostic['type'] === 'error' ? 'text-red-600' : ($diagnostic['type'] === 'warning' ? 'text-yellow-600' : 'text-blue-600')); ?> mt-1">
                                <?php echo $diagnostic['details']; ?>
                            </p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</body>
</html>