<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$testResults = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🧪 Shift Management Tests</h1>";
    
    // Test 1: Check if shift_templates table exists
    echo "<h2>Test 1: shift_templates Table Check</h2>";
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
        if ($stmt->rowCount() > 0) {
            echo "✅ shift_templates table exists<br>";
            $testResults[] = "PASS: shift_templates table exists";
            
            // Check columns
            $columns = $conn->query("SHOW COLUMNS FROM shift_templates")->fetchAll(PDO::FETCH_ASSOC);
            $columnNames = array_column($columns, 'Field');
            
            $requiredColumns = ['id', 'company_id', 'name', 'start_time', 'end_time'];
            $missingColumns = array_diff($requiredColumns, $columnNames);
            
            if (empty($missingColumns)) {
                echo "✅ All required columns exist: " . implode(', ', $columnNames) . "<br>";
                $testResults[] = "PASS: Required columns exist";
            } else {
                echo "❌ Missing columns: " . implode(', ', $missingColumns) . "<br>";
                $testResults[] = "FAIL: Missing columns - " . implode(', ', $missingColumns);
            }
            
            // Check for default templates
            $stmt = $conn->query("SELECT COUNT(*) as count FROM shift_templates WHERE is_active = 1");
            $templateCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "ℹ️ Found {$templateCount} active shift templates<br>";
            $testResults[] = "INFO: {$templateCount} active shift templates";
            
        } else {
            echo "❌ shift_templates table does not exist<br>";
            $testResults[] = "FAIL: shift_templates table missing";
        }
    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: " . $e->getMessage();
    }
    
    // Test 2: Check employee_shifts table structure
    echo "<h2>Test 2: employee_shifts Table Structure</h2>";
    try {
        $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        
        $requiredColumns = ['shift_date', 'shift_template_id'];
        $existingColumns = array_intersect($requiredColumns, $columnNames);
        $missingColumns = array_diff($requiredColumns, $columnNames);
        
        if (!empty($existingColumns)) {
            echo "✅ Existing shift columns: " . implode(', ', $existingColumns) . "<br>";
            $testResults[] = "PASS: Shift columns exist - " . implode(', ', $existingColumns);
        }
        if (!empty($missingColumns)) {
            echo "❌ Missing shift columns: " . implode(', ', $missingColumns) . "<br>";
            $testResults[] = "FAIL: Missing shift columns - " . implode(', ', $missingColumns);
        }
        if (empty($missingColumns)) {
            $testResults[] = "PASS: employee_shifts table structure correct";
        }
    } catch (Exception $e) {
        echo "❌ employee_shifts table error: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: employee_shifts - " . $e->getMessage();
    }
    
    // Test 3: Test shift template loading (like in shift-management.php)
    echo "<h2>Test 3: Shift Template Loading</h2>";
    try {
        $stmt = $conn->prepare("
            SELECT 
                id,
                name,
                start_time,
                end_time,
                break_duration,
                COALESCE(description, '') as description,
                COALESCE(color_code, '#3B82F6') as color_code
            FROM shift_templates 
            WHERE company_id = 1 AND is_active = 1 
            ORDER BY name
        ");
        $stmt->execute();
        $shiftTemplates = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "✅ Shift template loading works - got " . count($shiftTemplates) . " templates<br>";
        foreach ($shiftTemplates as $template) {
            echo "- Template: {$template['name']} ({$template['start_time']} - {$template['end_time']})<br>";
        }
        $testResults[] = "PASS: Shift template loading works";
    } catch (Exception $e) {
        echo "❌ Shift template loading failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Template loading - " . $e->getMessage();
    }
    
    // Test 4: Test shift assignment INSERT query
    echo "<h2>Test 4: Shift Assignment Query Test</h2>";
    try {
        // Get first employee and template IDs
        $stmt = $conn->prepare("SELECT id FROM employees WHERE company_id = 1 LIMIT 1");
        $stmt->execute();
        $employeeId = $stmt->fetchColumn();
        
        $stmt = $conn->prepare("SELECT id FROM shift_templates WHERE company_id = 1 AND is_active = 1 LIMIT 1");
        $stmt->execute();
        $templateId = $stmt->fetchColumn();
        
        if ($employeeId && $templateId) {
            // Test the exact INSERT query that was failing
            $stmt = $conn->prepare("INSERT IGNORE INTO employee_shifts (employee_id, shift_template_id, shift_date) VALUES (?, ?, ?)");
            $stmt->execute([$employeeId, $templateId, date('Y-m-d')]);
            
            echo "✅ Shift assignment INSERT query works<br>";
            echo "- Employee ID: {$employeeId}<br>";
            echo "- Template ID: {$templateId}<br>";
            echo "- Date: " . date('Y-m-d') . "<br>";
            $testResults[] = "PASS: Shift assignment INSERT works";
        } else {
            echo "❌ No employee or template found for testing<br>";
            $testResults[] = "FAIL: Missing test data (employee or template)";
        }
    } catch (Exception $e) {
        echo "❌ Shift assignment test failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Shift assignment - " . $e->getMessage();
    }
    
    echo "<h2>📋 Test Summary</h2>";
    foreach ($testResults as $result) {
        $status = substr($result, 0, 4);
        if ($status === 'PASS') {
            $color = 'green';
        } elseif ($status === 'FAIL') {
            $color = 'red';
        } elseif ($status === 'INFO') {
            $color = 'blue';
        } else {
            $color = 'orange';
        }
        echo "<div style='color: $color;'>$result</div>";
    }
    
    $passCount = count(array_filter($testResults, fn($r) => substr($r, 0, 4) === 'PASS'));
    $totalTests = count(array_filter($testResults, fn($r) => in_array(substr($r, 0, 4), ['PASS', 'FAIL'])));
    
    echo "<h3>Results: $passCount/$totalTests tests passed</h3>";
    
    if ($passCount === $totalTests && $totalTests > 0) {
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "🎉 All tests passed! Shift Management is working correctly.";
        echo "</div>";
    }

} catch (Exception $e) {
    echo "<h2>❌ Critical Error</h2>";
    echo "<p>Database connection failed: " . $e->getMessage() . "</p>";
}
?>

<div style="margin-top: 20px;">
    <a href="../super-admin/fix-critical-errors.php" style="background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px;">
        ← Back to Critical Errors
    </a>
    <a href="fix-shift-management.php" style="background: #fd7e14; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        📅 Shift Management Fix
    </a>
    <a href="../admin/shift-management.php" style="background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        📅 Shift Management
    </a>
</div>