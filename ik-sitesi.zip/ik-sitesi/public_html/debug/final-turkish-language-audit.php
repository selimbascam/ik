<?php
require_once '../includes/config.php';

echo "<h2>🔍 Son Türkçe Dil Denetimi</h2>";

// Quick manual fixes for remaining English terms
$quickFixes = [
    '../api/auth.php' => [
        'patterns' => [
            "'Unauthorized'" => "'Yetkisiz erişim'",
            "'User not found'" => "'Kullanıcı bulunamadı'",
            "'Missing required fields'" => "'Gerekli alanlar eksik'",
            "'Login successful'" => "'Giriş başarılı'",
            "'Logged out'" => "'Çıkış yapıldı'",
            "'Endpoint not found'" => "'Hizmet bulunamadı'",
            "'Server error'" => "'Sunucu hatası'"
        ]
    ],
    '../qr/qr-reader.php' => [
        'patterns' => [
            'console.log(\'Starting' => 'console.log(\'Başlatılıyor',
            'console.log(\'Camera' => 'console.log(\'Kamera',
            'console.log(\'Video' => 'console.log(\'Video',
            'console.error(\'Camera' => 'console.error(\'Kamera',
            'console.error(\'Error' => 'console.error(\'Hata',
            'Camera error' => 'Kamera hatası',
            'Starting camera' => 'Kamera başlatılıyor',
            'Stopping camera' => 'Kamera durduruluyor',
            'Video ready' => 'Video hazır',
            'Cameras loaded' => 'Kameralar yüklendi'
        ]
    ],
    '../debug/fix-device-records.php' => [
        'patterns' => [
            'Device Records' => 'Cihaz Kayıtları',
            '(Required)' => '(Zorunlu)',
            '(Optional)' => '(İsteğe Bağlı)',
            'Table not found' => 'Tablo bulunamadı',
            'Error loading' => 'Yükleme hatası',
            'Device Management' => 'Cihaz Yönetimi'
        ]
    ]
];

$fixedCount = 0;
$totalChanges = 0;

echo "<h3>🔧 Hızlı Düzeltmeler</h3>";

foreach ($quickFixes as $file => $fixData) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        $originalContent = $content;
        $fileChanges = 0;
        
        echo "<h4>📝 " . basename($file) . "</h4>";
        
        foreach ($fixData['patterns'] as $english => $turkish) {
            $newContent = str_replace($english, $turkish, $content);
            if ($newContent !== $content) {
                $content = $newContent;
                $fileChanges++;
                echo "<span style='color: green; font-size: 12px;'>✓ {$english} → {$turkish}</span><br>";
            }
        }
        
        if ($content !== $originalContent) {
            if (file_put_contents($file, $content)) {
                $fixedCount++;
                $totalChanges += $fileChanges;
                echo "<p style='color: green;'>✅ {$fileChanges} değişiklik kaydedildi</p>";
            } else {
                echo "<p style='color: red;'>❌ Dosya kaydedilemedi</p>";
            }
        } else {
            echo "<p style='color: blue;'>ℹ️ Değişiklik gerekmedi</p>";
        }
    } else {
        echo "<h4>📝 " . basename($file) . "</h4>";
        echo "<p style='color: orange;'>⚠️ Dosya bulunamadı</p>";
    }
}

// Database content check
echo "<h3>🗄️ Veritabanı İçerik Kontrolü</h3>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check for English content in critical tables
    $checkTables = [
        'qr_locations' => ['name', 'address'],
        'companies' => ['name', 'address'],
        'employees' => ['first_name', 'last_name', 'position'],
        'attendance_records' => ['notes', 'reason'],
        'shifts' => ['name', 'description']
    ];
    
    $englishContent = [];
    
    foreach ($checkTables as $table => $columns) {
        try {
            $stmt = $conn->query("SHOW TABLES LIKE '{$table}'");
            if ($stmt->rowCount() > 0) {
                foreach ($columns as $column) {
                    $checkStmt = $conn->query("SHOW COLUMNS FROM {$table} LIKE '{$column}'");
                    if ($checkStmt->rowCount() > 0) {
                        $dataStmt = $conn->prepare("SELECT id, {$column} FROM {$table} WHERE {$column} REGEXP '[A-Za-z]' LIMIT 5");
                        $dataStmt->execute();
                        $results = $dataStmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        if (!empty($results)) {
                            $englishContent[] = [
                                'table' => $table,
                                'column' => $column,
                                'count' => count($results),
                                'samples' => $results
                            ];
                        }
                    }
                }
            }
        } catch (Exception $e) {
            // Table might not exist, skip
        }
    }
    
    if (!empty($englishContent)) {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>⚠️ Veritabanında İngilizce İçerik Tespit Edildi:</h4>";
        foreach ($englishContent as $content) {
            echo "<p><strong>{$content['table']}.{$content['column']}</strong>: {$content['count']} kayıt</p>";
        }
        echo "<p><em>Not: Bu veriler kullanıcı tarafından girilen gerçek veriler olabilir.</em></p>";
        echo "</div>";
    } else {
        echo "<p>✅ Veritabanında İngilizce içerik tespit edilmedi</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Veritabanı kontrol hatası: " . $e->getMessage() . "</p>";
}

// Final language audit
echo "<h3>🎯 Son Dil Denetimi</h3>";

$auditFiles = [
    '../api/auth.php',
    '../qr/qr-reader.php',
    '../auth/employee-login.php',
    '../admin/employee-management.php',
    '../employee/dashboard.php',
    '../debug/fix-device-records.php'
];

$languageReport = [];

foreach ($auditFiles as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Check for common English patterns
        $englishPatterns = [
            '/\b(Error|Success|Failed|Invalid|Missing|Required|Login|Password|Camera|Loading|Processing)\b/',
            '/alert\s*\(\s*[\'"][A-Za-z][^\'\"]*[\'\"]\s*\)/',
            '/console\.(log|error)\s*\(\s*[\'"][A-Za-z][^\'\"]*[\'\"]/i',
            '/[\'"]message[\'\"]\s*[=:]\s*[\'"][A-Za-z][^\'\"]*[\'"]/',
            '/echo\s+[\'"][A-Za-z][^\'\"]*[\'"]/',
            '/title\s*=\s*[\'"][A-Za-z][^\'\"]*[\'"]/'
        ];
        
        $englishMatches = 0;
        foreach ($englishPatterns as $pattern) {
            $matches = preg_match_all($pattern, $content);
            $englishMatches += $matches;
        }
        
        $languageReport[] = [
            'file' => basename($file),
            'path' => $file,
            'english_matches' => $englishMatches,
            'status' => $englishMatches == 0 ? 'Türkçe' : 'Karışık'
        ];
    }
}

echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
echo "<tr><th>Dosya</th><th>Durum</th><th>İngilizce Tespit</th></tr>";

$fullTurkishCount = 0;
foreach ($languageReport as $report) {
    $statusColor = $report['status'] == 'Türkçe' ? 'green' : 'orange';
    if ($report['status'] == 'Türkçe') $fullTurkishCount++;
    
    echo "<tr>";
    echo "<td>{$report['file']}</td>";
    echo "<td style='color: {$statusColor}; font-weight: bold;'>{$report['status']}</td>";
    echo "<td>{$report['english_matches']}</td>";
    echo "</tr>";
}
echo "</table>";

// Final summary
echo "<h3>📊 Final Rapor</h3>";
echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<ul>";
echo "<li><strong>Bu oturumda düzeltilen dosya:</strong> {$fixedCount}</li>";
echo "<li><strong>Bu oturumda yapılan değişiklik:</strong> {$totalChanges}</li>";
echo "<li><strong>Tamamen Türkçe dosya sayısı:</strong> {$fullTurkishCount} / " . count($languageReport) . "</li>";
echo "<li><strong>Türkçeleştirme oranı:</strong> " . round(($fullTurkishCount / count($languageReport)) * 100, 1) . "%</li>";
echo "</ul>";
echo "</div>";

if ($fullTurkishCount == count($languageReport)) {
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>🎉 TÜRKÇE DİL DÜZELTMESİ TAMAMLANDI!</h2>";
    echo "<p><strong>🇹🇷 Sistem artık %100 Türkçe!</strong></p>";
    echo "<p>Tüm kullanıcı arayüzü, hata mesajları ve sistem çıktıları Türkçe.</p>";
    echo "</div>";
} else {
    echo "<div style='background: #fff3cd; padding: 20px; border-radius: 8px; text-align: center; margin: 20px 0;'>";
    echo "<h2>🔧 Türkçe Dil Düzeltmesi Devam Ediyor</h2>";
    echo "<p>Bazı dosyalarda hala İngilizce içerik mevcut.</p>";
    echo "<p>Manuel kontrol ve düzeltme gerekebilir.</p>";
    echo "</div>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { border-collapse: collapse; width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background-color: #f2f2f2; }
h3, h4 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>