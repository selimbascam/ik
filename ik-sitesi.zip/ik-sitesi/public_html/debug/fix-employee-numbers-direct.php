<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Direct access version - no session required for emergency fixes
// This is for database maintenance purposes only

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔧 Personel Numarası Düzeltme (Doğrudan Erişim)</h2>";
    echo "<p>Bu araç acil durum database bakımı için tasarlanmıştır.</p>";
    
    // Get company selection
    $companies = $conn->query("SELECT id, company_name FROM companies ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    
    if ($_POST['action'] ?? '' === 'fix_company' && isset($_POST['company_id'])) {
        $companyId = (int)$_POST['company_id'];
        
        echo "<h3>✅ Şirket ID $companyId - Personel Numaraları Eşitleme</h3>";
        
        // Step 1: Use employee_code as the master field - copy it to other fields
        $stmt = $conn->prepare("
            UPDATE employees 
            SET employee_number = employee_code, tc_identity = employee_code
            WHERE company_id = ?
            AND employee_code IS NOT NULL 
            AND employee_code != '' 
        ");
        $stmt->execute([$companyId]);
        $affected1 = $stmt->rowCount();
        
        echo "<p>✅ $affected1 personelin employee_code değeri employee_number ve tc_identity alanlarına kopyalandı.</p>";
        
        // Step 2: If employee_code is empty but tc_identity exists, use tc_identity as master
        $stmt2 = $conn->prepare("
            UPDATE employees 
            SET employee_code = tc_identity, employee_number = tc_identity 
            WHERE company_id = ?
            AND (employee_code IS NULL OR employee_code = '') 
            AND tc_identity IS NOT NULL 
            AND tc_identity != ''
        ");
        $stmt2->execute([$companyId]);
        $affected2 = $stmt2->rowCount();
        
        echo "<p>✅ $affected2 personelin tc_identity değeri employee_code ve employee_number alanlarına kopyalandı.</p>";
        
        // Step 3: Generate EMP format for completely empty records
        $stmt3 = $conn->prepare("
            UPDATE employees 
            SET employee_code = CONCAT('EMP', id), 
                employee_number = CONCAT('EMP', id),
                tc_identity = CONCAT('EMP', id)
            WHERE company_id = ?
            AND (tc_identity IS NULL OR tc_identity = '') 
            AND (employee_code IS NULL OR employee_code = '') 
        ");
        $stmt3->execute([$companyId]);
        $affected3 = $stmt3->rowCount();
        
        echo "<p>✅ $affected3 personelin tüm alanları EMP formatında oluşturuldu.</p>";
        
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
        echo "<h4>✅ İşlem Tamamlandı!</h4>";
        echo "Toplam " . ($affected1 + $affected2 + $affected3) . " personel kaydı güncellendi.";
        echo "</div>";
    }
    
    // Show current status for all companies
    echo "<h3>📊 Şirket Seçimi ve Durum</h3>";
    
    foreach ($companies as $company) {
        echo "<div style='border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px;'>";
        echo "<h4>" . htmlspecialchars($company['company_name']) . " (ID: {$company['id']})</h4>";
        
        // Get employee status for this company
        $stmt = $conn->prepare("
            SELECT 
                id,
                first_name,
                last_name,
                employee_code,
                employee_number,
                tc_identity,
                CASE 
                    WHEN tc_identity IS NOT NULL AND tc_identity != '' THEN tc_identity
                    WHEN employee_code IS NOT NULL AND employee_code != '' THEN employee_code  
                    WHEN employee_number IS NOT NULL AND employee_number != '' THEN employee_number
                    ELSE CONCAT('EMP', id)
                END as display_number,
                CASE 
                    WHEN employee_code = employee_number AND employee_code = tc_identity THEN 'Tutarlı'
                    WHEN employee_code IS NOT NULL AND (employee_code != COALESCE(employee_number, '') OR employee_code != COALESCE(tc_identity, '')) THEN 'Tutarsız'
                    ELSE 'Eksik Veri'
                END as status
            FROM employees 
            WHERE company_id = ?
            ORDER BY id
            LIMIT 10
        ");
        $stmt->execute([$company['id']]);
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($employees)) {
            echo "<p>Bu şirkette personel bulunamadı.</p>";
        } else {
            echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 12px;'>";
            echo "<tr style='background: #f8f9fa;'>";
            echo "<th>Ad Soyad</th><th>employee_code</th><th>employee_number</th><th>tc_identity</th><th>Durum</th>";
            echo "</tr>";
            
            $inconsistentCount = 0;
            foreach ($employees as $emp) {
                $statusColor = '';
                if ($emp['status'] === 'Tutarsız') {
                    $statusColor = 'background: #f8d7da;';
                    $inconsistentCount++;
                } elseif ($emp['status'] === 'Tutarlı') {
                    $statusColor = 'background: #d4edda;';
                } else {
                    $statusColor = 'background: #fff3cd;';
                }
                
                echo "<tr style='$statusColor'>";
                echo "<td>" . htmlspecialchars(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) . "</td>";
                echo "<td>" . htmlspecialchars($emp['employee_code'] ?: 'NULL') . "</td>";
                echo "<td>" . htmlspecialchars($emp['employee_number'] ?: 'NULL') . "</td>";
                echo "<td>" . htmlspecialchars($emp['tc_identity'] ?: 'NULL') . "</td>";
                echo "<td>" . $emp['status'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            
            if ($inconsistentCount > 0) {
                echo "<form method='POST' style='margin-top: 10px;'>";
                echo "<input type='hidden' name='action' value='fix_company'>";
                echo "<input type='hidden' name='company_id' value='{$company['id']}'>";
                echo "<button type='submit' style='background: #dc3545; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;'>";
                echo "🔧 Bu Şirketi Düzelt ($inconsistentCount tutarsızlık)";
                echo "</button>";
                echo "</form>";
            } else {
                echo "<p style='color: green;'>✅ Bu şirket tutarlı</p>";
            }
        }
        echo "</div>";
    }
    
    echo "<hr>";
    echo "<p><strong>Not:</strong> Bu araç session kontrolü yapmaz, doğrudan database'e erişir.</p>";
    echo "<p><a href='../admin/shift-management.php'>← Vardiya Yönetimine Dön</a></p>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 20px 0; border-radius: 5px;'>";
    echo "<h4>❌ Hata Oluştu</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>