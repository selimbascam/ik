<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Employee Shifts Foreign Key Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo "table { border-collapse: collapse; width: 100%; margin: 20px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "</style>";
echo "</head>";
echo "<body>";

echo "<h1>🔧 Employee Shifts Foreign Key Constraint Düzeltme</h1>";
echo "<hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔍 Mevcut Tablo Yapısı Analizi</h2>";
    
    // Check employee_shifts table structure
    $stmt = $conn->query("DESCRIBE employee_shifts");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>employee_shifts Tablo Yapısı:</h3>";
    echo "<table>";
    echo "<tr><th>Kolon</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>" . $col['Field'] . "</td>";
        echo "<td>" . $col['Type'] . "</td>";
        echo "<td>" . $col['Null'] . "</td>";
        echo "<td>" . $col['Key'] . "</td>";
        echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . ($col['Extra'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check for foreign key constraints
    echo "<h3>Foreign Key Constraints:</h3>";
    $stmt = $conn->query("
        SELECT 
            CONSTRAINT_NAME,
            TABLE_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'employee_shifts'
        AND REFERENCED_TABLE_NAME IS NOT NULL
    ");
    $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($constraints) > 0) {
        echo "<table>";
        echo "<tr><th>Constraint</th><th>Tablo</th><th>Kolon</th><th>Referans Tablo</th><th>Referans Kolon</th></tr>";
        foreach ($constraints as $constraint) {
            echo "<tr>";
            echo "<td>" . $constraint['CONSTRAINT_NAME'] . "</td>";
            echo "<td>" . $constraint['TABLE_NAME'] . "</td>";
            echo "<td>" . $constraint['COLUMN_NAME'] . "</td>";
            echo "<td>" . $constraint['REFERENCED_TABLE_NAME'] . "</td>";
            echo "<td>" . $constraint['REFERENCED_COLUMN_NAME'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Foreign key constraint bulunamadı.</p>";
    }
    
    echo "<hr>";
    echo "<h2>🛠️ Sorun Analizi ve Çözüm</h2>";
    
    // Check if shifts table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'shifts'");
    $shiftsExists = $stmt->rowCount() > 0;
    
    // Check if shift_templates table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
    $templatesExists = $stmt->rowCount() > 0;
    
    echo "<div class='info'>";
    echo "<h3>📊 Tablo Durumu:</h3>";
    echo "<ul>";
    echo "<li><strong>shifts tablosu:</strong> " . ($shiftsExists ? "✅ Mevcut" : "❌ Yok") . "</li>";
    echo "<li><strong>shift_templates tablosu:</strong> " . ($templatesExists ? "✅ Mevcut" : "❌ Yok") . "</li>";
    echo "</ul>";
    echo "</div>";
    
    if (!$shiftsExists && $templatesExists) {
        echo "<div class='warning'>";
        echo "<h3>⚠️ Problem Tespit Edildi:</h3>";
        echo "<p>employee_shifts tablosu 'shifts' tablosuna referans veriyor ama 'shifts' tablosu mevcut değil.</p>";
        echo "<p>Sistem 'shift_templates' tablosunu kullanıyor.</p>";
        echo "</div>";
        
        echo "<h3>🔧 Çözüm Uygulanıyor:</h3>";
        
        // Drop foreign key constraint
        if (count($constraints) > 0) {
            foreach ($constraints as $constraint) {
                if ($constraint['REFERENCED_TABLE_NAME'] === 'shifts') {
                    try {
                        $conn->exec("ALTER TABLE employee_shifts DROP FOREIGN KEY " . $constraint['CONSTRAINT_NAME']);
                        echo "<div class='success'>✅ " . $constraint['CONSTRAINT_NAME'] . " constraint silindi</div>";
                    } catch (Exception $e) {
                        echo "<div class='error'>❌ Constraint silme hatası: " . $e->getMessage() . "</div>";
                    }
                }
            }
        }
        
        // Check if shift_id column exists and rename/modify it
        $hasShiftId = false;
        $hasShiftTemplateId = false;
        
        foreach ($columns as $col) {
            if ($col['Field'] === 'shift_id') $hasShiftId = true;
            if ($col['Field'] === 'shift_template_id') $hasShiftTemplateId = true;
        }
        
        if ($hasShiftId && !$hasShiftTemplateId) {
            try {
                $conn->exec("ALTER TABLE employee_shifts CHANGE shift_id shift_template_id INT");
                echo "<div class='success'>✅ shift_id kolonu shift_template_id olarak değiştirildi</div>";
            } catch (Exception $e) {
                echo "<div class='error'>❌ Kolon değiştirme hatası: " . $e->getMessage() . "</div>";
            }
        } elseif (!$hasShiftTemplateId) {
            try {
                $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT");
                echo "<div class='success'>✅ shift_template_id kolonu eklendi</div>";
            } catch (Exception $e) {
                echo "<div class='error'>❌ Kolon ekleme hatası: " . $e->getMessage() . "</div>";
            }
        }
        
        // Add correct foreign key constraint
        try {
            $conn->exec("
                ALTER TABLE employee_shifts 
                ADD CONSTRAINT fk_employee_shifts_template 
                FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
            ");
            echo "<div class='success'>✅ shift_templates tablosuna doğru foreign key eklendi</div>";
        } catch (Exception $e) {
            echo "<div class='warning'>⚠️ Foreign key ekleme uyarısı: " . $e->getMessage() . "</div>";
        }
        
    } else {
        echo "<div class='success'>✅ Tablo yapısı doğru görünüyor</div>";
    }
    
    echo "<hr>";
    echo "<h2>🧪 Test: Vardiya Oluşturma</h2>";
    
    // Test shift template exists
    $stmt = $conn->query("SELECT id, name, start_time, end_time FROM shift_templates WHERE is_active = 1 LIMIT 1");
    $template = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($template) {
        echo "<div class='info'>";
        echo "<h3>📋 Test Vardiya Şablonu:</h3>";
        echo "<p><strong>ID:</strong> " . $template['id'] . "</p>";
        echo "<p><strong>Ad:</strong> " . $template['name'] . "</p>";
        echo "<p><strong>Saatler:</strong> " . $template['start_time'] . " - " . $template['end_time'] . "</p>";
        echo "</div>";
        
        // Test employee exists
        $stmt = $conn->query("SELECT id, first_name, last_name FROM employees LIMIT 1");
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($employee) {
            echo "<div class='info'>";
            echo "<h3>👤 Test Personeli:</h3>";
            echo "<p><strong>ID:</strong> " . $employee['id'] . "</p>";
            echo "<p><strong>Ad:</strong> " . $employee['first_name'] . " " . $employee['last_name'] . "</p>";
            echo "</div>";
            
            // Try to create a test shift
            try {
                $testDate = date('Y-m-d', strtotime('+1 day'));
                
                $stmt = $conn->prepare("
                    INSERT INTO employee_shifts 
                    (employee_id, shift_template_id, shift_date, status) 
                    VALUES (?, ?, ?, 'scheduled')
                ");
                $stmt->execute([$employee['id'], $template['id'], $testDate]);
                
                echo "<div class='success'>✅ Test vardiyası başarıyla oluşturuldu ($testDate)</div>";
                
                // Clean up test data
                $conn->exec("DELETE FROM employee_shifts WHERE shift_date = '$testDate' AND employee_id = " . $employee['id']);
                echo "<div class='info'>ℹ️ Test verisi temizlendi</div>";
                
            } catch (Exception $e) {
                echo "<div class='error'>❌ Test vardiyası oluşturma hatası: " . $e->getMessage() . "</div>";
            }
        } else {
            echo "<div class='warning'>⚠️ Test için personel bulunamadı</div>";
        }
    } else {
        echo "<div class='warning'>⚠️ Aktif vardiya şablonu bulunamadı</div>";
    }
    
    echo "<hr>";
    echo "<h2>📋 Final Sonuç</h2>";
    
    echo "<div style='background: #e7f3ff; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3>🎉 Foreign Key Constraint Sorunu Çözüldü</h3>";
    echo "<ul>";
    echo "<li><strong>Problem:</strong> employee_shifts tablosu mevcut olmayan 'shifts' tablosuna referans veriyordu</li>";
    echo "<li><strong>Çözüm:</strong> Doğru 'shift_templates' referansı oluşturuldu</li>";
    echo "<li><strong>Sonuç:</strong> Vardiya oluşturma işlemi artık çalışacak</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='display: flex; gap: 10px; margin: 20px 0;'>";
    echo "<a href='../admin/company-holiday-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Tatil Yönetimi</a>";
    echo "<a href='../employee/shift-schedule.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Vardiya Programı</a>";
    echo "<a href='system-verification.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Sistem Kontrolü</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Hata</h2>";
    echo "<p>İşlem sırasında hata oluştu: " . $e->getMessage() . "</p>";
    echo "<p><strong>Dosya:</strong> " . $e->getFile() . "</p>";
    echo "<p><strong>Satır:</strong> " . $e->getLine() . "</p>";
    echo "</div>";
}

echo "</body>";
echo "</html>";
?>