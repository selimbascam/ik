<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Allow super admin access or employee access
if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../index.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 4; // Default to SZB company for super admin
$employee_id = $_SESSION['employee_id'] ?? null;

$test_results = [];
$comprehensive_data = [];

// Get company information
try {
    $company_stmt = $pdo->prepare("SELECT company_name, email FROM companies WHERE id = ?");
    $company_stmt->execute([$company_id]);
    $company_data = $company_stmt->fetch(PDO::FETCH_ASSOC);
    $comprehensive_data['company'] = $company_data;
} catch (Exception $e) {
    $comprehensive_data['company_error'] = $e->getMessage();
}

// Get all QR locations
try {
    $locations_stmt = $pdo->prepare("
        SELECT id, location_name, gate_behavior, qr_code_data, latitude, longitude, 
               location_tolerance, is_active, created_at
        FROM qr_locations 
        WHERE company_id = ? 
        ORDER BY gate_behavior, location_name
    ");
    $locations_stmt->execute([$company_id]);
    $comprehensive_data['locations'] = $locations_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Group by gate behavior
    $behavior_stats = [];
    foreach ($comprehensive_data['locations'] as $location) {
        $behavior = $location['gate_behavior'];
        if (!isset($behavior_stats[$behavior])) {
            $behavior_stats[$behavior] = ['count' => 0, 'active' => 0];
        }
        $behavior_stats[$behavior]['count']++;
        if ($location['is_active']) {
            $behavior_stats[$behavior]['active']++;
        }
    }
    $comprehensive_data['behavior_stats'] = $behavior_stats;
    
} catch (Exception $e) {
    $comprehensive_data['locations_error'] = $e->getMessage();
}

// Get employees for testing
try {
    $employees_stmt = $pdo->prepare("
        SELECT id, first_name, last_name, email, is_active
        FROM employees 
        WHERE company_id = ? 
        ORDER BY first_name, last_name
    ");
    $employees_stmt->execute([$company_id]);
    $comprehensive_data['employees'] = $employees_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $comprehensive_data['employees_error'] = $e->getMessage();
}

// Comprehensive QR test
if ($_POST && isset($_POST['run_comprehensive_test'])) {
    require_once '../includes/qr-attendance-fixed.php';
    
    $test_results['timestamp'] = date('Y-m-d H:i:s');
    $test_results['tests'] = [];
    
    foreach ($comprehensive_data['locations'] as $location) {
        if (!$location['is_active']) continue;
        
        $test_case = [
            'location_id' => $location['id'],
            'location_name' => $location['location_name'],
            'gate_behavior' => $location['gate_behavior'],
            'qr_code_data' => $location['qr_code_data'],
            'steps' => []
        ];
        
        try {
            // Test with each employee
            foreach ($comprehensive_data['employees'] as $employee) {
                if (!$employee['is_active']) continue;
                
                $employee_test = [
                    'employee_id' => $employee['id'],
                    'employee_name' => $employee['first_name'] . ' ' . $employee['last_name'],
                    'results' => []
                ];
                
                // Step 1: Test gate action determination
                $gate_action = QRAttendanceHelper::determineGateAction(
                    $pdo, 
                    $employee['id'], 
                    $company_id, 
                    $location['id'], 
                    $location['gate_behavior']
                );
                
                $employee_test['results']['gate_action'] = $gate_action;
                
                // Step 2: Test activity lookup
                $activity_stmt = $pdo->prepare("SELECT id, activity_name FROM attendance_activities WHERE activity_name = ?");
                $activity_stmt->execute([$gate_action]);
                $activity = $activity_stmt->fetch(PDO::FETCH_ASSOC);
                
                $employee_test['results']['activity_lookup'] = $activity;
                
                // Step 3: Test today's records
                $today = date('Y-m-d');
                $today_records_stmt = $pdo->prepare("
                    SELECT ar.*, aa.activity_name, ql.location_name as qr_location_name
                    FROM attendance_records ar
                    LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id
                    LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
                    WHERE ar.employee_id = ? AND DATE(ar.created_at) = ?
                    ORDER BY ar.created_at ASC
                ");
                $today_records_stmt->execute([$employee['id'], $today]);
                $today_records = $today_records_stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $employee_test['results']['today_records'] = $today_records;
                $employee_test['results']['today_count'] = count($today_records);
                
                // Step 4: Behavioral analysis
                $expected_behavior = '';
                switch ($location['gate_behavior']) {
                    case 'work_start':
                        $expected_behavior = 'Her zaman work_start yapmalı';
                        break;
                    case 'work_end':
                        $expected_behavior = 'Her zaman work_end yapmalı';
                        break;
                    case 'break_toggle':
                        $expected_behavior = empty($today_records) ? 'İlk kayıt: break_start' : 'Son duruma göre break toggle';
                        break;
                    case 'user_choice':
                        $expected_behavior = empty($today_records) ? 'İlk kayıt: work_start' : 'Son duruma göre otomatik';
                        break;
                }
                
                $employee_test['results']['expected_behavior'] = $expected_behavior;
                $employee_test['results']['actual_vs_expected'] = [
                    'expected' => $expected_behavior,
                    'actual_gate_action' => $gate_action,
                    'match' => true // We'll determine this based on logic
                ];
                
                $test_case['steps'][] = $employee_test;
                
                // Only test with first employee to avoid spam
                break;
            }
            
        } catch (Exception $e) {
            $test_case['error'] = $e->getMessage();
        }
        
        $test_results['tests'][] = $test_case;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapsamlı QR Test Sistemi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .test-pass { @apply bg-green-100 border-green-300 text-green-800; }
        .test-fail { @apply bg-red-100 border-red-300 text-red-800; }
        .test-warn { @apply bg-yellow-100 border-yellow-300 text-yellow-800; }
        .json-viewer { font-family: monospace; background: #1f2937; color: #f3f4f6; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen py-8">
    <div class="container mx-auto px-4">
        
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">🧪 Kapsamlı QR Test Sistemi</h1>
            <div class="text-gray-600">
                <?php if ($comprehensive_data['company']): ?>
                    Şirket: <strong><?= htmlspecialchars($comprehensive_data['company']['company_name']) ?></strong>
                    (<?= htmlspecialchars($comprehensive_data['company']['email']) ?>)
                <?php else: ?>
                    Şirket bilgisi alınamadı
                <?php endif; ?>
            </div>
            <div class="mt-2 text-sm text-gray-500">
                Bu test sistemi QR gate behavior mantığının doğru çalışıp çalışmadığını kontrol eder.
            </div>
        </div>

        <!-- System Overview -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📊 Sistem Genel Bakış</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- QR Locations Stats -->
                <div class="p-4 bg-blue-50 rounded-lg">
                    <h4 class="font-semibold text-blue-900 mb-2">QR Lokasyonları</h4>
                    <?php if (isset($comprehensive_data['behavior_stats'])): ?>
                        <div class="space-y-1">
                            <?php foreach ($comprehensive_data['behavior_stats'] as $behavior => $stats): ?>
                            <div class="text-sm text-blue-800">
                                <?= htmlspecialchars($behavior) ?>: <?= $stats['active'] ?>/<?= $stats['count'] ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-2 text-xs text-blue-600">
                            Toplam: <?= count($comprehensive_data['locations']) ?> lokasyon
                        </div>
                    <?php else: ?>
                        <div class="text-red-600">Lokasyon bilgisi alınamadı</div>
                    <?php endif; ?>
                </div>

                <!-- Employees Stats -->
                <div class="p-4 bg-green-50 rounded-lg">
                    <h4 class="font-semibold text-green-900 mb-2">Personeller</h4>
                    <?php if (isset($comprehensive_data['employees'])): ?>
                        <div class="text-sm text-green-800">
                            Aktif: <?= count(array_filter($comprehensive_data['employees'], function($e) { return $e['is_active']; })) ?>
                        </div>
                        <div class="text-sm text-green-800">
                            Toplam: <?= count($comprehensive_data['employees']) ?>
                        </div>
                    <?php else: ?>
                        <div class="text-red-600">Personel bilgisi alınamadı</div>
                    <?php endif; ?>
                </div>

                <!-- Current Status -->
                <div class="p-4 bg-yellow-50 rounded-lg">
                    <h4 class="font-semibold text-yellow-900 mb-2">Mevcut Durum</h4>
                    <div class="text-sm text-yellow-800">
                        <?php if ($employee_id): ?>
                            Employee ID: <?= $employee_id ?>
                        <?php else: ?>
                            Super Admin Mode
                        <?php endif; ?>
                    </div>
                    <div class="text-sm text-yellow-800">
                        Company ID: <?= $company_id ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Test Control -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">🚀 Test Kontrolü</h3>
            
            <form method="POST">
                <div class="flex gap-4">
                    <button type="submit" name="run_comprehensive_test" value="1" 
                            class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                        🧪 Kapsamlı Test Başlat
                    </button>
                    
                    <a href="qr-gate-behavior-diagnosis.php" 
                       class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 inline-block">
                        🔬 Detaylı Tanı Sistemi
                    </a>
                    
                    <a href="../qr/qr-system-status.php" 
                       class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 inline-block">
                        📊 QR Sistem Durumu
                    </a>
                </div>
            </form>
        </div>

        <!-- Test Results -->
        <?php if (!empty($test_results)): ?>
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📋 Test Sonuçları</h3>
            
            <div class="mb-4 text-sm text-gray-600">
                Test Zamanı: <?= htmlspecialchars($test_results['timestamp']) ?>
            </div>
            
            <div class="space-y-6">
                <?php foreach ($test_results['tests'] as $index => $test_case): ?>
                <div class="border border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-3">
                        <div>
                            <h4 class="font-semibold text-gray-900">
                                <?= htmlspecialchars($test_case['location_name']) ?>
                            </h4>
                            <div class="text-sm text-gray-600">
                                Gate Behavior: <code class="bg-gray-100 px-1 rounded"><?= htmlspecialchars($test_case['gate_behavior']) ?></code>
                            </div>
                        </div>
                        <div class="text-xs text-gray-500">
                            Test #<?= $index + 1 ?>
                        </div>
                    </div>
                    
                    <?php if (isset($test_case['error'])): ?>
                        <div class="p-3 test-fail border rounded">
                            <strong>Hata:</strong> <?= htmlspecialchars($test_case['error']) ?>
                        </div>
                    <?php else: ?>
                        <?php foreach ($test_case['steps'] as $step): ?>
                        <div class="ml-4 border-l-2 border-blue-200 pl-4 mb-3">
                            <div class="font-medium text-blue-900">
                                Personel: <?= htmlspecialchars($step['employee_name']) ?>
                            </div>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mt-2">
                                <div class="p-2 bg-gray-50 rounded text-xs">
                                    <div class="font-semibold">Gate Action</div>
                                    <div class="text-blue-600"><?= htmlspecialchars($step['results']['gate_action']) ?></div>
                                </div>
                                
                                <div class="p-2 bg-gray-50 rounded text-xs">
                                    <div class="font-semibold">Activity</div>
                                    <div class="<?= $step['results']['activity_lookup'] ? 'text-green-600' : 'text-red-600' ?>">
                                        <?= $step['results']['activity_lookup'] ? htmlspecialchars($step['results']['activity_lookup']['activity_name']) : 'Bulunamadı' ?>
                                    </div>
                                </div>
                                
                                <div class="p-2 bg-gray-50 rounded text-xs">
                                    <div class="font-semibold">Bugünkü Kayıtlar</div>
                                    <div class="text-gray-600"><?= $step['results']['today_count'] ?> kayıt</div>
                                </div>
                                
                                <div class="p-2 bg-gray-50 rounded text-xs">
                                    <div class="font-semibold">Beklenen Davranış</div>
                                    <div class="text-gray-600"><?= htmlspecialchars($step['results']['expected_behavior']) ?></div>
                                </div>
                            </div>
                            
                            <?php if ($step['results']['today_count'] > 0): ?>
                            <details class="mt-2">
                                <summary class="text-xs text-blue-600 cursor-pointer">Bugünkü kayıtları göster</summary>
                                <div class="mt-1 space-y-1">
                                    <?php foreach ($step['results']['today_records'] as $record): ?>
                                    <div class="text-xs bg-blue-50 p-2 rounded">
                                        <?= date('H:i', strtotime($record['created_at'])) ?> - 
                                        <?= htmlspecialchars($record['activity_name']) ?> @ 
                                        <?= htmlspecialchars($record['qr_location_name']) ?>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </details>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Expected Behaviors Reference -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📚 Beklenen Davranışlar Rehberi</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-4">
                    <div class="p-4 border border-green-300 rounded-lg">
                        <h4 class="font-semibold text-green-900">work_start</h4>
                        <p class="text-sm text-green-800">Her durumda "work_start" aktivitesi oluşturmalı</p>
                        <div class="text-xs text-green-600 mt-1">Sabit davranış - durumdan etkilenmez</div>
                    </div>
                    
                    <div class="p-4 border border-red-300 rounded-lg">
                        <h4 class="font-semibold text-red-900">work_end</h4>
                        <p class="text-sm text-red-800">Her durumda "work_end" aktivitesi oluşturmalı</p>
                        <div class="text-xs text-red-600 mt-1">Sabit davranış - durumdan etkilenmez</div>
                    </div>
                </div>
                
                <div class="space-y-4">
                    <div class="p-4 border border-yellow-300 rounded-lg">
                        <h4 class="font-semibold text-yellow-900">break_toggle</h4>
                        <p class="text-sm text-yellow-800">Mola durumuna göre "break_start" veya "break_end"</p>
                        <div class="text-xs text-yellow-600 mt-1">Dinamik - son mola durumuna göre değişir</div>
                    </div>
                    
                    <div class="p-4 border border-blue-300 rounded-lg">
                        <h4 class="font-semibold text-blue-900">user_choice</h4>
                        <p class="text-sm text-blue-800">Çalışma durumuna göre otomatik tespit</p>
                        <div class="text-xs text-blue-600 mt-1">Akıllı - giriş/çıkış durumuna göre karar verir</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>