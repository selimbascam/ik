<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🏢 Company Login Debug Test</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>📋 Database Tables</h3>";
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<ul>";
    foreach ($tables as $table) {
        echo "<li>" . htmlspecialchars($table) . "</li>";
    }
    echo "</ul>";
    
    // Check companies table structure
    echo "<h3>🏢 Companies Table Structure</h3>";
    
    $companiesTable = in_array('companies', $tables) ? 'companies' : 
                     (in_array('şirketler', $tables) ? 'şirketler' : null);
    
    if ($companiesTable) {
        echo "<p>✅ Companies table found: <strong>$companiesTable</strong></p>";
        
        $stmt = $conn->query("SHOW COLUMNS FROM `$companiesTable`");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background: #f8f9fa;'>";
        echo "<th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th>";
        echo "</tr>";
        
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($col['Field']) . "</td>";
            echo "<td>" . htmlspecialchars($col['Type']) . "</td>";
            echo "<td>" . htmlspecialchars($col['Null']) . "</td>";
            echo "<td>" . htmlspecialchars($col['Key']) . "</td>";
            echo "<td>" . htmlspecialchars($col['Default']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Check for existing companies
        echo "<h3>📊 Existing Companies</h3>";
        
        $stmt = $conn->query("SELECT * FROM `$companiesTable` LIMIT 5");
        $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($companies)) {
            echo "<p>❌ No companies found in database</p>";
            
            // Try to create a test company
            echo "<h4>🔧 Creating Test Company</h4>";
            
            try {
                $stmt = $conn->prepare("
                    INSERT INTO `$companiesTable` 
                    (company_name, name, email, admin_email, password, company_code, code, is_active, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $testData = [
                    'SZB Test Şirketi',        // company_name
                    'SZB Test Şirketi',        // name
                    'test@szb.com.tr',         // email
                    'test@szb.com.tr',         // admin_email
                    md5('123456'),             // password (MD5 hashed)
                    'SZB001',                  // company_code
                    'SZB001',                  // code
                    1,                         // is_active
                    'active'                   // status
                ];
                
                $stmt->execute($testData);
                echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px;'>";
                echo "✅ Test company created successfully<br>";
                echo "Email: test@szb.com.tr<br>";
                echo "Password: 123456";
                echo "</div>";
                
            } catch (Exception $e) {
                // Try simpler insert
                try {
                    $stmt = $conn->prepare("
                        INSERT INTO `$companiesTable` 
                        (email, password)
                        VALUES (?, ?)
                    ");
                    $stmt->execute(['test@szb.com.tr', md5('123456')]);
                    
                    echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px;'>";
                    echo "✅ Basic test company created<br>";
                    echo "Email: test@szb.com.tr<br>";
                    echo "Password: 123456";
                    echo "</div>";
                    
                } catch (Exception $e2) {
                    echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px;'>";
                    echo "❌ Could not create test company: " . $e2->getMessage();
                    echo "</div>";
                }
            }
            
        } else {
            echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr style='background: #f8f9fa;'>";
            foreach (array_keys($companies[0]) as $key) {
                echo "<th>" . htmlspecialchars($key) . "</th>";
            }
            echo "</tr>";
            
            foreach ($companies as $company) {
                echo "<tr>";
                foreach ($company as $value) {
                    echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        }
        
        // Test login functionality
        echo "<h3>🔐 Test Login Process</h3>";
        
        // Get first company for testing
        $stmt = $conn->query("SELECT * FROM `$companiesTable` LIMIT 1");
        $testCompany = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($testCompany) {
            echo "<div style='background: #e7f3ff; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
            echo "<h4>🧪 Test Login Credentials</h4>";
            echo "<p><strong>Email:</strong> " . htmlspecialchars($testCompany['email'] ?? $testCompany['admin_email'] ?? 'N/A') . "</p>";
            echo "<p><strong>Password:</strong> 123456 (if using MD5) or check database</p>";
            echo "<p><strong>Password Hash in DB:</strong> " . htmlspecialchars($testCompany['password'] ?? 'No password set') . "</p>";
            echo "</div>";
            
            // Test password verification
            if (isset($testCompany['password'])) {
                $testPass = '123456';
                $dbPass = $testCompany['password'];
                
                echo "<div style='background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                echo "<h4>🔑 Password Test Results</h4>";
                echo "<ul>";
                echo "<li>Plain text match: " . ($testPass === $dbPass ? '✅ Yes' : '❌ No') . "</li>";
                echo "<li>MD5 match: " . (md5($testPass) === $dbPass ? '✅ Yes' : '❌ No') . "</li>";
                echo "<li>SHA1 match: " . (sha1($testPass) === $dbPass ? '✅ Yes' : '❌ No') . "</li>";
                echo "</ul>";
                echo "</div>";
            }
        }
        
    } else {
        echo "<p>❌ No companies table found</p>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Database Error</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { border-collapse: collapse; width: 100%; margin: 10px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "</style>";

echo "<hr>";
echo "<p><a href='../auth/company-login.php'>← Company Login'e Dön</a></p>";
?>