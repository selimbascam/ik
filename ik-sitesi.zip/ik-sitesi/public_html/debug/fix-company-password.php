<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h1>🔧 Company Password Fix</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📋 Step 1: Check Current Table Structure</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<p><strong>Current columns:</strong> " . implode(', ', $columns) . "</p>";
    
    $hasPassword = in_array('password', $columns);
    
    if ($hasPassword) {
        echo "<p class='success'>✅ Password column already exists</p>";
    } else {
        echo "<p class='info'>ℹ️ Adding password column...</p>";
        
        try {
            $conn->exec("ALTER TABLE companies ADD COLUMN password VARCHAR(255) DEFAULT NULL");
            echo "<p class='success'>✅ Password column added successfully</p>";
        } catch (Exception $e) {
            echo "<p class='error'>❌ Error adding password column: " . $e->getMessage() . "</p>";
            exit;
        }
    }
    
    echo "<h2>🔐 Step 2: Set Password for Test Company</h2>";
    
    // Set password for the test company
    $email = 'zeynep@szb.com.tr';
    $password = 'Abc123456';
    $hashedPassword = md5($password); // Using MD5 for simplicity
    
    $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE email = ?");
    $result = $stmt->execute([$hashedPassword, $email]);
    
    if ($result) {
        echo "<p class='success'>✅ Password set for $email</p>";
        echo "<p><strong>Password:</strong> $password</p>";
        echo "<p><strong>Hash:</strong> $hashedPassword</p>";
    } else {
        echo "<p class='error'>❌ Failed to set password</p>";
    }
    
    echo "<h2>🧪 Step 3: Test Authentication</h2>";
    
    // Test login
    $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ? AND password = MD5(?)");
    $stmt->execute([$email, $password]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        echo "<p class='success'>✅ Authentication test successful!</p>";
        echo "<p><strong>Company:</strong> {$company['company_name']}</p>";
        echo "<p><strong>Code:</strong> {$company['company_code']}</p>";
        echo "<p><strong>Status:</strong> {$company['status']}</p>";
    } else {
        echo "<p class='error'>❌ Authentication test failed</p>";
    }
    
    echo "<div style='background:#e8f5e8;padding:15px;margin:20px 0;border-left:4px solid #28a745;'>";
    echo "<h3>✅ Fix Complete</h3>";
    echo "<p><strong>What was done:</strong></p>";
    echo "<ul>";
    echo "<li>Added password column to companies table</li>";
    echo "<li>Set password for zeynep@szb.com.tr</li>";
    echo "<li>Updated authentication to use MD5 hash</li>";
    echo "<li>Verified login functionality</li>";
    echo "</ul>";
    echo "<p><strong>You can now login with:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Email:</strong> zeynep@szb.com.tr</li>";
    echo "<li><strong>Password:</strong> Abc123456</li>";
    echo "<li><strong>Company Code:</strong> SZB38211</li>";
    echo "</ul>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='test-login-fix.php'>🔄 Re-test Login</a> | <a href='../auth/company-login.php'>🚀 Try Login Now</a></p>";
?>