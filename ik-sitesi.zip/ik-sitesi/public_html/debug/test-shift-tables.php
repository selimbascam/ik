<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: ../super-admin/index.php');
    exit();
}

$testResults = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🧪 Shift Tables Tests</h1>";
    
    // Test 1: Check if shift_templates table exists
    echo "<h2>Test 1: shift_templates Table Check</h2>";
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'shift_templates'");
        if ($stmt->rowCount() > 0) {
            echo "✅ shift_templates table exists<br>";
            
            // Check table structure
            $columns = $conn->query("SHOW COLUMNS FROM shift_templates")->fetchAll(PDO::FETCH_ASSOC);
            $columnNames = array_column($columns, 'Field');
            
            echo "📋 Columns in shift_templates:<br>";
            foreach ($columnNames as $column) {
                echo "- " . $column . "<br>";
            }
            
            // Count records
            $stmt = $conn->query("SELECT COUNT(*) FROM shift_templates");
            $count = $stmt->fetchColumn();
            echo "📊 Total shift templates: $count<br>";
            
            $testResults[] = "PASS: shift_templates table exists with $count records";
        } else {
            echo "❌ shift_templates table does not exist<br>";
            $testResults[] = "FAIL: shift_templates table missing";
        }
    } catch (Exception $e) {
        echo "❌ shift_templates table error: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: shift_templates - " . $e->getMessage();
    }
    
    // Test 2: Check if employee_shifts table exists
    echo "<h2>Test 2: employee_shifts Table Check</h2>";
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'employee_shifts'");
        if ($stmt->rowCount() > 0) {
            echo "✅ employee_shifts table exists<br>";
            
            // Check table structure
            $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll(PDO::FETCH_ASSOC);
            $columnNames = array_column($columns, 'Field');
            
            echo "📋 Columns in employee_shifts:<br>";
            foreach ($columnNames as $column) {
                echo "- " . $column . "<br>";
            }
            
            // Count records
            $stmt = $conn->query("SELECT COUNT(*) FROM employee_shifts");
            $count = $stmt->fetchColumn();
            echo "📊 Total employee shifts: $count<br>";
            
            // Check for critical columns
            $requiredColumns = ['shift_date', 'shift_template_id', 'employee_id'];
            $missingColumns = array_diff($requiredColumns, $columnNames);
            if (empty($missingColumns)) {
                echo "✅ All required columns present<br>";
                $testResults[] = "PASS: employee_shifts table complete with $count records";
            } else {
                echo "❌ Missing columns: " . implode(', ', $missingColumns) . "<br>";
                $testResults[] = "FAIL: employee_shifts missing columns - " . implode(', ', $missingColumns);
            }
        } else {
            echo "❌ employee_shifts table does not exist<br>";
            $testResults[] = "FAIL: employee_shifts table missing";
        }
    } catch (Exception $e) {
        echo "❌ employee_shifts table error: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: employee_shifts - " . $e->getMessage();
    }
    
    // Test 3: Test shift management queries
    echo "<h2>Test 3: Shift Management Queries</h2>";
    try {
        // Test the main query from shift-management.php
        $stmt = $conn->prepare("
            SELECT 
                id,
                name,
                start_time,
                end_time,
                COALESCE(break_duration, 60) as break_duration,
                COALESCE(description, '') as description,
                COALESCE(color_code, '#3B82F6') as color_code
            FROM shift_templates 
            WHERE company_id = ? AND is_active = 1 
            ORDER BY name
            LIMIT 5
        ");
        $stmt->execute([1]); // Test with company_id = 1
        $templates = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "✅ Shift templates query works - got " . count($templates) . " templates<br>";
        if (!empty($templates)) {
            echo "Sample template:<br>";
            $sample = $templates[0];
            foreach (['id', 'name', 'start_time', 'end_time'] as $field) {
                if (isset($sample[$field])) {
                    echo "- $field: " . $sample[$field] . "<br>";
                }
            }
        }
        $testResults[] = "PASS: Shift templates query works";
    } catch (Exception $e) {
        echo "❌ Shift templates query failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Shift templates query - " . $e->getMessage();
    }
    
    // Test 4: Test JOIN query between tables
    echo "<h2>Test 4: Tables JOIN Test</h2>";
    try {
        $stmt = $conn->prepare("
            SELECT 
                st.id,
                st.name as template_name,
                COUNT(es.id) as assignment_count
            FROM shift_templates st
            LEFT JOIN employee_shifts es ON st.id = es.shift_template_id
            WHERE st.company_id = ?
            GROUP BY st.id
            LIMIT 5
        ");
        $stmt->execute([1]); // Test with company_id = 1
        $joinResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "✅ JOIN query works - got " . count($joinResults) . " results<br>";
        foreach ($joinResults as $result) {
            echo "- Template: {$result['template_name']}, Assignments: {$result['assignment_count']}<br>";
        }
        $testResults[] = "PASS: Tables JOIN query works";
    } catch (Exception $e) {
        echo "❌ JOIN query failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Tables JOIN query - " . $e->getMessage();
    }
    
    // Test 5: Test INSERT capabilities
    echo "<h2>Test 5: INSERT Test</h2>";
    try {
        // Try to insert a test shift template
        $stmt = $conn->prepare("
            INSERT IGNORE INTO shift_templates 
            (company_id, name, start_time, end_time, break_duration, description) 
            VALUES (1, 'Test Vardiya', '09:00:00', '17:00:00', 60, 'Test için oluşturuldu')
        ");
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            echo "✅ INSERT test successful<br>";
            $testResults[] = "PASS: INSERT capabilities work";
        } else {
            echo "ℹ️ INSERT ignored (record may already exist)<br>";
            $testResults[] = "INFO: INSERT ignored (duplicate)";
        }
    } catch (Exception $e) {
        echo "❌ INSERT test failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: INSERT test - " . $e->getMessage();
    }
    
    // Test 6: Test shift assignment INSERT
    echo "<h2>Test 6: Shift Assignment INSERT Test</h2>";
    try {
        // Get a template ID for testing
        $stmt = $conn->query("SELECT id FROM shift_templates WHERE company_id = 1 LIMIT 1");
        $template = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($template) {
            $stmt = $conn->prepare("
                INSERT IGNORE INTO employee_shifts 
                (employee_id, shift_template_id, shift_date) 
                VALUES (1, ?, CURDATE())
            ");
            $stmt->execute([$template['id']]);
            
            if ($stmt->rowCount() > 0) {
                echo "✅ Shift assignment INSERT successful<br>";
                $testResults[] = "PASS: Shift assignment INSERT works";
            } else {
                echo "ℹ️ Shift assignment INSERT ignored (may already exist)<br>";
                $testResults[] = "INFO: Shift assignment INSERT ignored";
            }
        } else {
            echo "⚠️ No shift template found for assignment test<br>";
            $testResults[] = "WARN: No templates available for assignment test";
        }
    } catch (Exception $e) {
        echo "❌ Shift assignment INSERT test failed: " . $e->getMessage() . "<br>";
        $testResults[] = "FAIL: Shift assignment INSERT - " . $e->getMessage();
    }
    
    echo "<h2>📋 Test Summary</h2>";
    foreach ($testResults as $result) {
        $status = substr($result, 0, 4);
        if ($status === 'PASS') {
            $color = 'green';
        } elseif ($status === 'FAIL') {
            $color = 'red';
        } elseif ($status === 'INFO') {
            $color = 'blue';
        } elseif ($status === 'WARN') {
            $color = 'orange';
        } else {
            $color = 'gray';
        }
        echo "<div style='color: $color;'>$result</div>";
    }
    
    $passCount = count(array_filter($testResults, fn($r) => substr($r, 0, 4) === 'PASS'));
    $totalTests = count(array_filter($testResults, fn($r) => in_array(substr($r, 0, 4), ['PASS', 'FAIL'])));
    
    echo "<h3>Results: $passCount/$totalTests tests passed</h3>";
    
    if ($passCount === $totalTests && $totalTests > 0) {
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "🎉 All tests passed! Shift management system is working correctly.";
        echo "</div>";
    }

} catch (Exception $e) {
    echo "<h2>❌ Critical Error</h2>";
    echo "<p>Database connection failed: " . $e->getMessage() . "</p>";
}
?>

<div style="margin-top: 20px;">
    <a href="../super-admin/fix-critical-errors.php" style="background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px;">
        ← Back to Critical Errors
    </a>
    <a href="fix-shift-tables.php" style="background: #dc3545; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        📅 Shift Tables Fix
    </a>
    <a href="../admin/shift-management.php" style="background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-left: 10px;">
        📋 Shift Management
    </a>
</div>