<?php
/**
 * Quick Fix for Zeynep's Company Login
 * SZB Mühendislik - zeynep@szb.com.tr - SZB38211
 */

require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: text/html; charset=utf-8');

$email = 'zeynep@szb.com.tr';
$password = 'Abc123456';
$correctCode = 'SZB38211';
$companyName = 'SZB Mühendislik';

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zeynep Login Fix</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f0f9ff; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #059669; background: #d1fae5; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .error { color: #dc2626; background: #fee2e2; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .warning { color: #d97706; background: #fef3c7; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .info { color: #0369a1; background: #dbeafe; padding: 15px; border-radius: 8px; margin: 15px 0; }
        h1, h2 { color: #1f2937; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #f8f9fa; font-weight: bold; }
        .fix-button { background: #dc2626; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block; }
        .fix-button:hover { background: #b91c1c; }
        .test-button { background: #059669; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; margin: 5px; display: inline-block; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏢 SZB Mühendislik - Zeynep Giriş Düzeltme</h1>
        
        <div class="info">
            <h3>Doğru Bilgiler:</h3>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            <p><strong>Şirket Adı:</strong> <?php echo htmlspecialchars($companyName); ?></p>
            <p><strong>Doğru Şirket Kodu:</strong> <?php echo htmlspecialchars($correctCode); ?></p>
            <p><strong>Şifre:</strong> <?php echo htmlspecialchars($password); ?></p>
        </div>
        
        <?php
        try {
            $conn = Database::getInstance()->getConnection();
            
            // Check companies table structure
            $stmt = $conn->query("SHOW COLUMNS FROM companies");
            $companyColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Map column names for compatibility
            $emailCol = in_array('email', $companyColumns) ? 'email' : 
                       (in_array('admin_email', $companyColumns) ? 'admin_email' : 'email');
                       
            $codeCol = in_array('company_code', $companyColumns) ? 'company_code' : 
                      (in_array('code', $companyColumns) ? 'code' : 'company_code');
                      
            $nameCol = in_array('company_name', $companyColumns) ? 'company_name' : 
                      (in_array('name', $companyColumns) ? 'name' : 'company_name');
            
            $hasPassword = in_array('password', $companyColumns);
            
            echo "<h2>📊 Durum Analizi</h2>";
            
            // Search for company by email
            $stmt = $conn->prepare("SELECT * FROM companies WHERE $emailCol = ?");
            $stmt->execute([$email]);
            $companyByEmail = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($companyByEmail) {
                echo "<div class='success'>✅ Şirket email ile bulundu</div>";
                echo "<table>";
                echo "<tr><th>Alan</th><th>Değer</th></tr>";
                echo "<tr><td>ID</td><td>{$companyByEmail['id']}</td></tr>";
                echo "<tr><td>Email</td><td>{$companyByEmail[$emailCol]}</td></tr>";
                echo "<tr><td>Şirket Adı</td><td>{$companyByEmail[$nameCol]}</td></tr>";
                echo "<tr><td>Şirket Kodu</td><td>" . ($companyByEmail[$codeCol] ?? 'YOK') . "</td></tr>";
                echo "<tr><td>Şifre Durumu</td><td>" . ($companyByEmail['password'] ? 'VAR' : 'YOK') . "</td></tr>";
                echo "</table>";
                
                $currentCode = $companyByEmail[$codeCol] ?? null;
                
                if ($currentCode !== $correctCode) {
                    echo "<div class='warning'>";
                    echo "<h3>🔧 Şirket Kodu Uyumsuzluğu</h3>";
                    echo "<p>Mevcut kod: <strong>" . ($currentCode ?? 'YOK') . "</strong></p>";
                    echo "<p>Doğru kod: <strong>$correctCode</strong></p>";
                    echo "<a href='?action=fix_company_code&company_id={$companyByEmail['id']}' class='fix-button'>Şirket Kodunu Düzelt</a>";
                    echo "</div>";
                }
                
                if (!$companyByEmail['password']) {
                    echo "<div class='warning'>";
                    echo "<h3>🔧 Şifre Eksik</h3>";
                    echo "<p>Şirket için şifre ayarlanmamış.</p>";
                    echo "<a href='?action=set_password&company_id={$companyByEmail['id']}' class='fix-button'>Şifreyi Ayarla</a>";
                    echo "</div>";
                } else {
                    // Test password authentication
                    echo "<h3>🔐 Şifre Testi</h3>";
                    
                    $authMethods = [
                        'MD5' => "SELECT * FROM companies WHERE $emailCol = ? AND password = MD5(?)",
                        'Plain Text' => "SELECT * FROM companies WHERE $emailCol = ? AND password = ?",
                    ];
                    
                    $authSuccess = false;
                    
                    foreach ($authMethods as $method => $query) {
                        try {
                            $stmt = $conn->prepare($query);
                            $stmt->execute([$email, $password]);
                            $result = $stmt->fetch(PDO::FETCH_ASSOC);
                            
                            if ($result) {
                                echo "<div class='success'>✅ $method ile giriş başarılı</div>";
                                $authSuccess = true;
                                break;
                            } else {
                                echo "<div class='info'>ℹ️ $method başarısız</div>";
                            }
                        } catch (PDOException $e) {
                            echo "<div class='error'>❌ $method test hatası: " . htmlspecialchars($e->getMessage()) . "</div>";
                        }
                    }
                    
                    if (!$authSuccess) {
                        echo "<div class='warning'>";
                        echo "<h3>🔧 Şifre Formatı Sorunu</h3>";
                        echo "<p>Şifre doğru formatta değil.</p>";
                        echo "<a href='?action=reset_password&company_id={$companyByEmail['id']}' class='fix-button'>Şifreyi MD5 Formatına Çevir</a>";
                        echo "</div>";
                    }
                }
                
            } else {
                echo "<div class='error'>❌ Bu email ile şirket bulunamadı</div>";
                
                // Show all companies for reference
                $stmt = $conn->query("SELECT $emailCol, $nameCol FROM companies LIMIT 5");
                $allCompanies = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if ($allCompanies) {
                    echo "<div class='info'>";
                    echo "<h3>Mevcut şirketler:</h3>";
                    echo "<table>";
                    echo "<tr><th>Email</th><th>Şirket Adı</th></tr>";
                    foreach ($allCompanies as $company) {
                        echo "<tr><td>{$company[$emailCol]}</td><td>{$company[$nameCol]}</td></tr>";
                    }
                    echo "</table>";
                    echo "</div>";
                    
                    echo "<div class='warning'>";
                    echo "<h3>🔧 Şirket Oluştur</h3>";
                    echo "<p>Bu email için şirket kaydı bulunamadı.</p>";
                    echo "<a href='?action=create_company' class='fix-button'>SZB Mühendislik Kaydını Oluştur</a>";
                    echo "</div>";
                }
            }
            
            // Handle fix actions
            if (isset($_GET['action'])) {
                echo "<h2>🛠️ Düzeltme İşlemi</h2>";
                
                switch ($_GET['action']) {
                    case 'fix_company_code':
                        $companyId = (int)$_GET['company_id'];
                        try {
                            $stmt = $conn->prepare("UPDATE companies SET $codeCol = ? WHERE id = ?");
                            $stmt->execute([$correctCode, $companyId]);
                            echo "<div class='success'>✅ Şirket kodu '$correctCode' olarak güncellendi</div>";
                        } catch (PDOException $e) {
                            echo "<div class='error'>❌ Şirket kodu güncellenemedi: " . htmlspecialchars($e->getMessage()) . "</div>";
                        }
                        break;
                        
                    case 'set_password':
                    case 'reset_password':
                        $companyId = (int)$_GET['company_id'];
                        try {
                            $hashedPassword = md5($password);
                            $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE id = ?");
                            $stmt->execute([$hashedPassword, $companyId]);
                            echo "<div class='success'>✅ Şifre MD5 formatında ayarlandı</div>";
                        } catch (PDOException $e) {
                            echo "<div class='error'>❌ Şifre ayarlanamadı: " . htmlspecialchars($e->getMessage()) . "</div>";
                        }
                        break;
                        
                    case 'create_company':
                        try {
                            $stmt = $conn->prepare("
                                INSERT INTO companies ($emailCol, $nameCol, $codeCol, password) 
                                VALUES (?, ?, ?, MD5(?))
                            ");
                            $stmt->execute([$email, $companyName, $correctCode, $password]);
                            echo "<div class='success'>✅ SZB Mühendislik şirket kaydı oluşturuldu</div>";
                        } catch (PDOException $e) {
                            echo "<div class='error'>❌ Şirket kaydı oluşturulamadı: " . htmlspecialchars($e->getMessage()) . "</div>";
                        }
                        break;
                }
                
                echo "<a href='?' class='test-button'>🔄 Durumu Tekrar Kontrol Et</a>";
                echo "<a href='../auth/company-login.php' class='test-button'>🚀 Giriş Sayfasına Git</a>";
            }
            
        } catch (Exception $e) {
            echo "<div class='error'>";
            echo "<h2>❌ Kritik Hata</h2>";
            echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
            echo "</div>";
        }
        ?>
        
        <div style="margin-top: 30px;">
            <h3>📝 Giriş için doğru bilgiler:</h3>
            <div class="info">
                <p><strong>Email:</strong> zeynep@szb.com.tr</p>
                <p><strong>Şifre:</strong> Abc123456</p>
                <p><strong>Şirket Kodu:</strong> SZB38211 (SZB01164 değil!)</p>
            </div>
        </div>
        
        <div style="margin-top: 20px; text-align: center;">
            <a href="../auth/company-login.php" class="test-button">🔙 Giriş Sayfasına Dön</a>
        </div>
    </div>
</body>
</html>