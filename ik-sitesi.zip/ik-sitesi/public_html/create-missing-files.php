<?php
// Create Missing Files - Generate required system files
echo "<h1>Eksik Dosya Oluşturma</h1>";
echo "<p>Başlangıç: " . date('Y-m-d H:i:s') . "</p><hr>";

$created = [];

// 1. Create missing admin files
$adminFiles = [
    'admin/company-settings.php' => 'Company Settings Management',
    'admin/leave-management.php' => 'Leave Requests Management',
    'reports/dashboard.php' => 'Reports Dashboard'
];

foreach ($adminFiles as $file => $description) {
    if (!file_exists($file)) {
        $dir = dirname($file);
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
            echo "📁 Created directory: $dir<br>";
        }
        
        $content = createBasicPHPFile($file, $description);
        file_put_contents($file, $content);
        $created[] = "$file - $description";
        echo "✅ Created: $file<br>";
    } else {
        echo "✅ Exists: $file<br>";
    }
}

// 2. Create logout file
if (!file_exists('auth/logout.php')) {
    $logoutContent = '<?php
session_start();
session_destroy();
header("Location: /ik/auth/company-login.php");
exit;
?>';
    file_put_contents('auth/logout.php', $logoutContent);
    $created[] = "auth/logout.php - User logout";
    echo "✅ Created: auth/logout.php<br>";
}

// 3. Create employee dashboard
if (!file_exists('dashboard/employee-dashboard.php')) {
    $employeeDashContent = createEmployeeDashboard();
    file_put_contents('dashboard/employee-dashboard.php', $employeeDashContent);
    $created[] = "dashboard/employee-dashboard.php - Employee Dashboard";
    echo "✅ Created: dashboard/employee-dashboard.php<br>";
}

// Helper functions
function createBasicPHPFile($filename, $title) {
    $basename = basename($filename, '.php');
    $content = '<?php
require_once "../includes/config.php";
require_once "../includes/database.php";

session_start();

// Check authentication
if (!isset($_SESSION["user_id"]) || !isset($_SESSION["company_id"])) {
    header("Location: /ik/auth/company-login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . $title . ' - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex flex-col">
        <!-- Header -->
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center">
                    <h1 class="text-3xl font-bold text-gray-900">' . $title . '</h1>
                    <a href="/ik/dashboard/company-dashboard.php" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        ← Ana Panel
                    </a>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-1 max-w-7xl w-full mx-auto py-6 sm:px-6 lg:px-8">
            <div class="bg-white shadow rounded-lg p-6">
                <h2 class="text-xl font-semibold text-gray-900 mb-4">' . $title . '</h2>
                <p class="text-gray-600">Bu sayfa henüz geliştiriliyor...</p>
                
                <div class="mt-6">
                    <a href="/ik/dashboard/company-dashboard.php" class="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700">
                        Ana Panele Dön
                    </a>
                </div>
            </div>
        </main>
    </div>
</body>
</html>';
    
    return $content;
}

function createEmployeeDashboard() {
    return '<?php
require_once "../includes/config.php";
require_once "../includes/database.php";

session_start();

// Check employee authentication
if (!isset($_SESSION["employee_id"])) {
    header("Location: /ik/auth/employee-login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Paneli - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex flex-col">
        <!-- Header -->
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center">
                    <h1 class="text-3xl font-bold text-gray-900">Personel Paneli</h1>
                    <div class="flex space-x-4">
                        <a href="/ik/qr/qr-reader.php" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                            📱 QR Okut
                        </a>
                        <a href="/ik/auth/logout.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
                            Çıkış
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-1 max-w-7xl w-full mx-auto py-6 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-4">Hızlı İşlemler</h2>
                    <div class="space-y-4">
                        <a href="/ik/qr/qr-reader.php" class="block w-full bg-blue-600 text-white p-4 rounded-lg text-center hover:bg-blue-700">
                            📱 Giriş/Çıkış QR Okut
                        </a>
                        <a href="/ik/attendance/my-records.php" class="block w-full bg-green-600 text-white p-4 rounded-lg text-center hover:bg-green-700">
                            📊 Çalışma Kayıtlarım
                        </a>
                    </div>
                </div>
                
                <div class="bg-white shadow rounded-lg p-6">
                    <h2 class="text-xl font-semibold text-gray-900 mb-4">Bugünkü Durum</h2>
                    <p class="text-gray-600">Giriş durumunuz ve çalışma saatleriniz burada görünecek...</p>
                </div>
            </div>
        </main>
    </div>
</body>
</html>';
}

echo "<hr>";
echo "<h2>Özet</h2>";
echo "<p>Toplam oluşturulan dosya: " . count($created) . "</p>";
foreach ($created as $file) {
    echo "• $file<br>";
}

echo "<p>Bitiş: " . date('Y-m-d H:i:s') . "</p>";
?>