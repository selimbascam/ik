-- Fix duplicate employee_code issue for 30716129672
-- This happens when employee_code column has UNIQUE constraint

-- Option 1: Check if employee already exists with different employee_number
SELECT employee_number, first_name, last_name, employee_code 
FROM employees 
WHERE employee_code = '30716129672';

-- Option 2: Update existing employee instead of creating new one
UPDATE employees 
SET employee_number = '30716129672', 
    first_name = 'Test', 
    last_name = 'Personel',
    password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
WHERE employee_code = '30716129672';

-- Option 3: Create with different employee_code
INSERT INTO employees (
    employee_number, first_name, last_name, password, 
    company_id, status, is_active, employee_code, email, hire_date, monthly_salary
) VALUES (
    '30716129672', 'Test', 'Personel',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    1, 'active', 1, 'EMP30716129672', 'test30716129672@szb.com.tr', CURDATE(), 17000
);

-- Option 4: Minimal INSERT without employee_code
INSERT INTO employees (
    employee_number, first_name, last_name, password, 
    company_id, status, is_active
) VALUES (
    '30716129672', 'Test', 'Personel',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    1, 'active', 1
);

-- Verify creation
SELECT employee_number, first_name, last_name, employee_code 
FROM employees 
WHERE employee_number = '30716129672';