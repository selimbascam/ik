<?php
echo "<h2>🔧 Database Config Fix</h2>";

// Test current config
echo "<h3>📊 Mevcut Yapılandırma</h3>";
echo "<p>Dosyada bulunan bilgiler:</p>";
echo "<ul>";
echo "<li><strong>Database:</strong> u978874874_ik</li>";
echo "<li><strong>Username:</strong> u978874874_ik</li>";
echo "<li><strong>Password:</strong> Szb2013@+-!</li>";
echo "</ul>";

echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>❌ Sorun Tespit Edildi</h4>";
echo "<p><strong>Hata:</strong> Access denied for user 'u123456_szb'@'localhost'</p>";
echo "<p><strong>Sebep:</strong> Database config dosyasında placeholder değerler var</p>";
echo "</div>";

echo "<div style='background: #d1ecf1; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>💡 Çözüm Adımları</h4>";
echo "<ol>";
echo "<li><strong>Hostinger Panel'e giriş yapın</strong></li>";
echo "<li><strong>Database section'a gidin</strong> (MySQL Databases)</li>";
echo "<li><strong>Gerçek bilgilerinizi alın:</strong>";
echo "<ul style='margin: 10px 0;'>";
echo "<li>Database Name (u ile başlayan)</li>";
echo "<li>Username (u ile başlayan)</li>";  
echo "<li>Password (panel'de oluşturduğunuz)</li>";
echo "</ul>";
echo "</li>";
echo "<li><strong>includes/database.php dosyasını düzenleyin</strong></li>";
echo "</ol>";
echo "</div>";

echo "<div style='background: #fff3cd; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>⚙️ Manuel Düzeltme</h4>";
echo "<p><strong>includes/database.php</strong> dosyasında <strong>satır 22-24</strong>'ü değiştirin:</p>";
echo "<pre style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>";
echo htmlspecialchars('
// Eski (çalışmıyor):
$this->db_name = "u123456_szb_ik";     // PLACEHOLDER
$this->username = "u123456_szb";       // PLACEHOLDER  
$this->password = "your_password";     // PLACEHOLDER

// Yeni (gerçek bilgilerinizle):
$this->db_name = "u978874874_ik";      // GERÇEK DB ADI
$this->username = "u978874874_ik";     // GERÇEK USERNAME
$this->password = "Szb2013@+-!";       // GERÇEK PASSWORD
');
echo "</pre>";
echo "</div>";

// Create corrected database file content
echo "<div style='background: #e7f3ff; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>📄 Düzeltilmiş Database.php İçeriği</h4>";
echo "<p>Aşağıdaki kodu kopyalayıp <strong>includes/database.php</strong> dosyasına yapıştırın:</p>";
echo "<textarea style='width: 100%; height: 300px; font-family: monospace;' readonly>";

$corrected_content = '<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    public $conn;

    public function __construct() {
        // Hostinger database config - GERÇEK BİLGİLER
        $this->host = "localhost";
        $this->port = 3306;
        $this->db_name = "u978874874_ik";      // GERÇEK DB ADI
        $this->username = "u978874874_ik";     // GERÇEK USERNAME  
        $this->password = "Szb2013@+-!";       // GERÇEK PASSWORD
    }

    public function getConnection() {
        if ($this->conn !== null) {
            return $this->conn;
        }

        try {
            // MySQL DSN for Hostinger
            $dsn = "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            
            $this->conn = new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]);
            
            // MySQL için timezone ayarla
            $this->conn->exec("SET time_zone = \'+03:00\'");
            
        } catch(PDOException $exception) {
            error_log("Veritabanı bağlantı hatası: " . $exception->getMessage());
            throw new Exception("Veritabanı bağlantısı kurulamadı: " . $exception->getMessage());
        }

        return $this->conn;
    }
    
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }
    
    public function showTables() {
        $stmt = $this->conn->query("SHOW TABLES");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    public function showColumns($tableName) {
        $stmt = $this->conn->prepare("SHOW COLUMNS FROM `$tableName`");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>';

echo htmlspecialchars($corrected_content);
echo "</textarea>";
echo "</div>";

echo "<div style='background: #d4edda; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>🎯 Test Adımları</h4>";
echo "<ol>";
echo "<li>Yukarıdaki kodu <strong>includes/database.php</strong>'ye yapıştırın</li>";
echo "<li><strong>test-connection.php</strong>'yi yenileyin - bağlantı başarılı olmalı</li>";
echo "<li><strong>auth/company-login.php</strong>'yi test edin</li>";
echo "<li>Login: <strong>info@mobofis.com</strong> / <strong>szb123</strong></li>";
echo "</ol>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
pre { white-space: pre-wrap; }
</style>