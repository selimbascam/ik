<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔧 Shift Management Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check employees table structure
    echo "<h3>📊 Employees Table Structure</h3>";
    $result = $conn->query("DESCRIBE employees");
    $columns = $result->fetchAll();
    
    $hasEmployeeNumber = false;
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p><strong>Current columns in employees table:</strong></p>";
    echo "<ul>";
    foreach ($columns as $column) {
        echo "<li><strong>{$column['Field']}</strong> ({$column['Type']})</li>";
        if ($column['Field'] === 'employee_number') {
            $hasEmployeeNumber = true;
        }
    }
    echo "</ul>";
    echo "</div>";
    
    if (!$hasEmployeeNumber) {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>⚠️ <strong>employee_number column missing!</strong></p>";
        echo "<p>Adding employee_number column to employees table...</p>";
        echo "</div>";
        
        // Add employee_number column
        $conn->query("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) AFTER id");
        
        // Generate employee numbers for existing employees
        $stmt = $conn->prepare("SELECT id, company_id FROM employees ORDER BY id");
        $stmt->execute();
        $employees = $stmt->fetchAll();
        
        foreach ($employees as $employee) {
            $employeeNumber = 'EMP' . str_pad($employee['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            $updateStmt->execute([$employeeNumber, $employee['id']]);
        }
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>✅ <strong>employee_number column added successfully!</strong></p>";
        echo "<p>Generated employee numbers for existing employees (EMP0001, EMP0002, etc.)</p>";
        echo "</div>";
    } else {
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>✅ <strong>employee_number column already exists</strong></p>";
        echo "</div>";
    }
    
    // Test shift management query
    echo "<h3>🔧 Test Shift Management Query</h3>";
    $testQuery = "SELECT e.id, e.first_name, e.last_name, e.employee_number, d.name as department_name 
                  FROM employees e 
                  LEFT JOIN departments d ON e.department_id = d.id 
                  WHERE e.company_id = ? 
                  ORDER BY e.employee_number, e.first_name";
    
    // Test with company_id = 1
    $stmt = $conn->prepare($testQuery);
    $stmt->execute([1]);
    $employees = $stmt->fetchAll();
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p>✅ <strong>Query test successful!</strong></p>";
    echo "<p>Found " . count($employees) . " employees for company_id = 1</p>";
    if (count($employees) > 0) {
        echo "<p><strong>Sample employee:</strong></p>";
        $sample = $employees[0];
        echo "<ul>";
        foreach ($sample as $key => $value) {
            echo "<li><strong>$key:</strong> " . htmlspecialchars($value ?? 'NULL') . "</li>";
        }
        echo "</ul>";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p>❌ <strong>Error:</strong> " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Check departments table
echo "<h3>📋 Departments Table Check</h3>";
try {
    $result = $conn->query("SELECT COUNT(*) FROM departments");
    $deptCount = $result->fetchColumn();
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p>✅ Departments table exists with $deptCount departments</p>";
    echo "</div>";
    
    if ($deptCount == 0) {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>⚠️ No departments found. Creating sample departments...</p>";
        echo "</div>";
        
        // Create sample departments
        $sampleDepts = [
            ['İnsan Kaynakları', 'HR department'],
            ['Bilgi İşlem', 'IT department'], 
            ['Muhasebe', 'Accounting department'],
            ['Operasyon', 'Operations department']
        ];
        
        foreach ($sampleDepts as $dept) {
            $stmt = $conn->prepare("INSERT INTO departments (name, description, company_id) VALUES (?, ?, ?)");
            $stmt->execute([$dept[0], $dept[1], 1]); // Company ID 1
        }
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>✅ Sample departments created</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p>❌ Departments error: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "<h3>🔗 Test Shift Management</h3>";
echo "<div>";
echo "<a href='admin/shift-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Test Shift Management</a>";
echo "<a href='admin/dashboard.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Back to Dashboard</a>";
echo "<a href='auth/company-login-fixed.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Login</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
</style>