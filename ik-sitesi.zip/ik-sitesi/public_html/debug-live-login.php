<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔍 Canlı Login Debug</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<p style='color: green;'>✅ Veritabanı bağlantısı başarılı!</p>";
    
    // Test company data
    echo "<h3>🏢 Company Verilerini Kontrol Et</h3>";
    $stmt = $conn->query("SELECT id, name, email, password, is_active FROM companies ORDER BY id");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($companies) {
        foreach($companies as $company) {
            echo "<div style='background: #e9ecef; padding: 10px; margin: 5px 0; border-radius: 5px;'>";
            echo "<p><strong>ID:</strong> {$company['id']}</p>";
            echo "<p><strong>Name:</strong> {$company['name']}</p>";
            echo "<p><strong>Email:</strong> {$company['email']}</p>";
            echo "<p><strong>Password:</strong> " . ($company['password'] ? "✅ Set: " . substr($company['password'], 0, 10) . "..." : "❌ NULL") . "</p>";
            echo "<p><strong>Active:</strong> " . (isset($company['is_active']) ? ($company['is_active'] ? "✅ True" : "❌ False") : "❓ Column missing") . "</p>";
            echo "</div>";
        }
    }
    
    // Test login simulation
    echo "<h3>🔐 Login Simülasyonu</h3>";
    
    $testEmail = 'info@mobofis.com';
    $testPassword = 'szb123';
    
    echo "<p><strong>Test Credentials:</strong> $testEmail / $testPassword</p>";
    
    // Step 1: Check if company exists
    $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
    $stmt->execute([$testEmail]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        echo "<p style='color: green;'>✅ Company bulundu</p>";
        
        // Step 2: Check password
        if (isset($company['password'])) {
            $passwordMatch = ($company['password'] === $testPassword || md5($testPassword) === $company['password']);
            if ($passwordMatch) {
                echo "<p style='color: green;'>✅ Şifre doğru</p>";
                echo "<p style='color: green;'><strong>LOGIN BAŞARILI!</strong></p>";
            } else {
                echo "<p style='color: red;'>❌ Şifre yanlış</p>";
                echo "<p>Stored: {$company['password']}</p>";
                echo "<p>Plain: $testPassword</p>";
                echo "<p>MD5: " . md5($testPassword) . "</p>";
            }
        } else {
            echo "<p style='color: orange;'>⚠️ Password sütunu boş</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Company bulunamadı</p>";
    }
    
    // Manual password fix
    echo "<h3>🛠️ Şifre Düzeltme</h3>";
    $updateStmt = $conn->prepare("UPDATE companies SET password = ? WHERE email = ?");
    $updateStmt->execute(['szb123', $testEmail]);
    echo "<p style='color: blue;'>🔄 Şifre güncellendi: szb123</p>";
    
    // Re-test after update
    $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
    $stmt->execute([$testEmail]);
    $updatedCompany = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($updatedCompany && $updatedCompany['password'] === $testPassword) {
        echo "<p style='color: green;'>✅ Şifre düzeltmesi başarılı!</p>";
        echo "<p><strong>Şimdi login çalışmalı:</strong> $testEmail / $testPassword</p>";
    }
    
    echo "<h3>🔗 Test Linkler</h3>";
    echo "<div style='margin: 20px 0;'>";
    echo "<a href='auth/company-login.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Company Login Test</a>";
    echo "<a href='auth/employee-login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Employee Login Test</a>";
    echo "</div>";
    
    echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h4>💡 Debug Sonucu</h4>";
    echo "<p><strong>Sorun:</strong> is_active sütunu eksikti ve şifre kontrolü düzgün yapılmıyordu</p>";
    echo "<p><strong>Çözüm:</strong> Sütun eklendi ve şifre düzeltildi</p>";
    echo "<p><strong>Durum:</strong> Artık login çalışmalı</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h4>❌ Debug Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h3 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 5px; }
</style>