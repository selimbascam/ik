<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Comprehensive QR Foreign Key Fix Implementation</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;line-height:1.6;background:#f8f9fa;}h1,h2,h3{color:#333;}p{margin:10px 0;}.success{color:#22c55e;font-weight:bold;}.error{color:#ef4444;font-weight:bold;}.warning{color:#f59e0b;font-weight:bold;}.info{color:#3b82f6;font-weight:bold;}.fixed{background:#d4edda;color:#155724;padding:10px;border:1px solid #c3e6cb;border-radius:5px;margin:10px 0;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>🔍 Diagnostic Analysis</h2>";
    
    // Check if test employee exists
    $stmt = $conn->prepare("SELECT id, employee_number, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<p class='success'>✅ Test employee found: ID {$employee['id']}, Company ID: {$employee['company_id']}</p>";
        
        // Check if company exists
        $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
        $stmt->execute([$employee['company_id']]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($company) {
            echo "<p class='success'>✅ Company exists: {$company['company_name']} (ID: {$company['id']})</p>";
        } else {
            echo "<p class='error'>❌ CRITICAL: Company ID {$employee['company_id']} does NOT exist in companies table!</p>";
            echo "<p class='warning'>This is the root cause of the foreign key constraint error.</p>";
            
            // Create missing company
            $stmt = $conn->prepare("INSERT INTO companies (id, company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $employee['company_id'],
                'Test Company (Auto-created)',
                'test@company.com',
                '555-0123',
                'Auto-created for foreign key fix'
            ]);
            echo "<p class='success'>✅ Created missing company record</p>";
        }
        
    } else {
        echo "<p class='error'>❌ Test employee not found</p>";
    }
    
    // Check QR locations
    echo "<h3>📍 QR Locations Check</h3>";
    $stmt = $conn->prepare("SELECT id, name, company_id FROM qr_locations WHERE company_id = ? LIMIT 3");
    $stmt->execute([$employee['company_id']]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($locations) {
        echo "<p class='success'>✅ Found " . count($locations) . " QR locations for company</p>";
        foreach ($locations as $loc) {
            echo "<p class='info'>- Location {$loc['id']}: {$loc['name']}</p>";
        }
    } else {
        echo "<p class='warning'>⚠️ No QR locations found, creating test location</p>";
        $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $employee['company_id'],
            'Test QR Location',
            'Auto-created test location',
            '41.0082',
            '28.9784',
            'entrance',
            1
        ]);
        echo "<p class='success'>✅ Created test QR location</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Database error: " . $e->getMessage() . "</p>";
}

echo "<h2>🔧 Implementing Enhanced Validation</h2>";
echo "<p class='info'>Now implementing the comprehensive Deepseek validation solution...</p>";
?>