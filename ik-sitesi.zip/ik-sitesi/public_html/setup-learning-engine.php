<?php
// Setup script for Adaptive Learning Recommendation Engine
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Adaptif Öğrenme Motoru Kurulumu - SZB İK Takip</title>";
echo "<style>";
echo "body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }";
echo ".container { max-width: 900px; margin: 0 auto; background: white; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); overflow: hidden; }";
echo ".header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; }";
echo ".content { padding: 30px; }";
echo ".step { background: #f8f9fa; border-radius: 10px; padding: 20px; margin: 15px 0; border-left: 4px solid #667eea; }";
echo ".success { border-left-color: #28a745; background: #d4edda; color: #155724; }";
echo ".error { border-left-color: #dc3545; background: #f8d7da; color: #721c24; }";
echo ".warning { border-left-color: #ffc107; background: #fff3cd; color: #856404; }";
echo ".btn { background: #667eea; color: white; padding: 12px 24px; border: none; border-radius: 6px; cursor: pointer; font-weight: 500; text-decoration: none; display: inline-block; margin: 5px; }";
echo ".btn:hover { background: #5a67d8; }";
echo ".code-block { background: #2d3748; color: #e2e8f0; padding: 15px; border-radius: 6px; font-family: monospace; font-size: 14px; overflow-x: auto; margin: 15px 0; }";
echo "</style>";
echo "</head>";
echo "<body>";

echo "<div class='container'>";
echo "<div class='header'>";
echo "<h1 style='margin: 0; font-size: 32px;'>🧠 Adaptif Öğrenme Motoru</h1>";
echo "<p style='margin: 15px 0 0 0; opacity: 0.9; font-size: 18px;'>AI Destekli Personel Gelişim Sistemi Kurulumu</p>";
echo "</div>";

echo "<div class='content'>";

$setupStartTime = microtime(true);
$errors = [];
$successes = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>🔧 Kurulum Adımları</h3>";
    
    // Step 1: Create tables
    echo "<div class='step'>";
    echo "<h4>Adım 1: Veritabanı Tablolarını Oluştur</h4>";
    
    $sql_statements = [
        "learning_recommendations" => "
            CREATE TABLE IF NOT EXISTS learning_recommendations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                employee_id INT NOT NULL,
                recommendation_type VARCHAR(50) NOT NULL,
                title VARCHAR(255) NOT NULL,
                description TEXT,
                priority_score DECIMAL(5,2) DEFAULT 0.00,
                ai_confidence DECIMAL(3,2) DEFAULT 0.00,
                status ENUM('pending', 'in_progress', 'completed', 'dismissed') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                
                INDEX idx_company_employee (company_id, employee_id),
                INDEX idx_recommendation_type (recommendation_type),
                INDEX idx_priority_score (priority_score DESC),
                INDEX idx_status (status),
                INDEX idx_created_at (created_at DESC),
                
                UNIQUE KEY unique_recommendation (company_id, employee_id, recommendation_type, title)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ",
        
        "learning_analytics" => "
            CREATE TABLE IF NOT EXISTS learning_analytics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                employee_id INT NOT NULL,
                metric_type VARCHAR(50) NOT NULL,
                metric_value DECIMAL(10,2),
                analysis_date DATE,
                data_source VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                INDEX idx_company_employee (company_id, employee_id),
                INDEX idx_metric_type (metric_type),
                INDEX idx_analysis_date (analysis_date DESC)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ",
        
        "employee_skill_assessments" => "
            CREATE TABLE IF NOT EXISTS employee_skill_assessments (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                employee_id INT NOT NULL,
                skill_category VARCHAR(100) NOT NULL,
                skill_name VARCHAR(255) NOT NULL,
                current_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'beginner',
                target_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
                assessment_score DECIMAL(5,2),
                assessed_by INT,
                assessment_date DATE,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                
                INDEX idx_company_employee (company_id, employee_id),
                INDEX idx_skill_category (skill_category),
                INDEX idx_current_level (current_level),
                INDEX idx_assessment_date (assessment_date DESC)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ",
        
        "meeting_participations" => "
            CREATE TABLE IF NOT EXISTS meeting_participations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                employee_id INT NOT NULL,
                meeting_title VARCHAR(255),
                date DATE,
                duration_minutes INT DEFAULT 0,
                participation_type ENUM('organizer', 'required', 'optional', 'observer') DEFAULT 'required',
                attendance_status ENUM('present', 'absent', 'late') DEFAULT 'present',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                
                INDEX idx_company_employee (company_id, employee_id),
                INDEX idx_date (date DESC),
                INDEX idx_attendance_status (attendance_status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        "
    ];
    
    foreach ($sql_statements as $table => $sql) {
        try {
            $conn->exec($sql);
            echo "<p>✅ <strong>$table</strong> tablosu oluşturuldu</p>";
            $successes[] = "$table tablosu başarıyla oluşturuldu";
        } catch (PDOException $e) {
            echo "<p>❌ <strong>$table</strong> tablosu hatası: " . $e->getMessage() . "</p>";
            $errors[] = "$table tablosu oluşturulamadı: " . $e->getMessage();
        }
    }
    echo "</div>";
    
    // Step 2: Insert sample data
    echo "<div class='step'>";
    echo "<h4>Adım 2: Örnek Veri Ekleme</h4>";
    
    $sample_data = [
        "learning_recommendations" => [
            [1, 1, 'time_management', 'Zaman Yönetimi Eğitimi', 'Geç kalma oranı yüksek. Zaman yönetimi becerilerini geliştirmek için özel eğitim önerilir.', 85.5, 0.92],
            [1, 2, 'technical_skills', 'Siber Güvenlik Farkındalığı', 'IT departmanı için güncel siber güvenlik tehditleri ve koruma yöntemleri eğitimi.', 78.0, 0.88],
            [1, 3, 'communication', 'İletişim Becerileri Geliştirme', 'Toplantı katılımı düşük. Etkili iletişim ve sunum becerileri eğitimi önerilir.', 65.3, 0.75]
        ],
        
        "learning_analytics" => [
            [1, 1, 'attendance_score', 87.5, date('Y-m-d'), 'attendance_records'],
            [1, 1, 'punctuality_score', 72.3, date('Y-m-d'), 'attendance_records'],
            [1, 2, 'training_completion_rate', 95.0, date('Y-m-d'), 'employee_trainings'],
            [1, 3, 'meeting_participation_rate', 45.5, date('Y-m-d'), 'meeting_participations']
        ],
        
        "employee_skill_assessments" => [
            [1, 1, 'Soft Skills', 'Zaman Yönetimi', 'beginner', 'intermediate', 45.0, date('Y-m-d')],
            [1, 2, 'Technical Skills', 'Siber Güvenlik', 'intermediate', 'advanced', 75.5, date('Y-m-d')],
            [1, 3, 'Communication', 'Sunum Becerileri', 'beginner', 'intermediate', 38.0, date('Y-m-d')]
        ]
    ];
    
    // Insert learning recommendations
    $stmt = $conn->prepare("
        INSERT IGNORE INTO learning_recommendations 
        (company_id, employee_id, recommendation_type, title, description, priority_score, ai_confidence) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($sample_data['learning_recommendations'] as $rec) {
        $stmt->execute($rec);
    }
    echo "<p>✅ <strong>3</strong> örnek öğrenme önerisi eklendi</p>";
    
    // Insert analytics data  
    $stmt = $conn->prepare("
        INSERT IGNORE INTO learning_analytics 
        (company_id, employee_id, metric_type, metric_value, analysis_date, data_source) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($sample_data['learning_analytics'] as $analytics) {
        $stmt->execute($analytics);
    }
    echo "<p>✅ <strong>4</strong> analitik metrik eklendi</p>";
    
    // Insert skill assessments
    $stmt = $conn->prepare("
        INSERT IGNORE INTO employee_skill_assessments 
        (company_id, employee_id, skill_category, skill_name, current_level, target_level, assessment_score, assessment_date) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($sample_data['employee_skill_assessments'] as $skill) {
        $stmt->execute($skill);
    }
    echo "<p>✅ <strong>3</strong> beceri değerlendirmesi eklendi</p>";
    
    echo "</div>";
    
    // Step 3: Test the recommendation engine
    echo "<div class='step'>";
    echo "<h4>Adım 3: Öneri Motoru Testi</h4>";
    
    // Test recommendation generation
    $stmt = $conn->prepare("SELECT COUNT(*) FROM employees WHERE company_id = 1");
    $stmt->execute();
    $employee_count = $stmt->fetchColumn();
    
    echo "<p>📊 Şirkette <strong>$employee_count</strong> aktif personel bulundu</p>";
    
    $stmt = $conn->prepare("SELECT COUNT(*) FROM learning_recommendations WHERE company_id = 1");
    $stmt->execute();
    $rec_count = $stmt->fetchColumn();
    
    echo "<p>🎯 Toplam <strong>$rec_count</strong> öğrenme önerisi mevcut</p>";
    
    // Test AI confidence levels
    $stmt = $conn->prepare("SELECT AVG(ai_confidence) as avg_confidence FROM learning_recommendations WHERE company_id = 1");
    $stmt->execute();
    $avg_confidence = $stmt->fetchColumn();
    
    echo "<p>🤖 Ortalama AI güven oranı: <strong>" . number_format($avg_confidence * 100, 1) . "%</strong></p>";
    
    echo "</div>";
    
    // Step 4: System status
    echo "<div class='step success'>";
    echo "<h4>Adım 4: Sistem Durumu</h4>";
    
    $setupEndTime = microtime(true);
    $setupDuration = round(($setupEndTime - $setupStartTime) * 1000, 2);
    
    echo "<p>✅ <strong>Adaptif Öğrenme Motoru başarıyla kuruldu!</strong></p>";
    echo "<p>⏱️ Kurulum süresi: <strong>{$setupDuration}ms</strong></p>";
    echo "<p>📈 Sistem hazır ve önerileri analiz etmeye başlayabilir</p>";
    
    echo "<div style='margin-top: 20px;'>";
    echo "<a href='admin/learning-recommendations.php' class='btn'>🧠 Öğrenme Önerilerine Git</a>";
    echo "<a href='dashboard/company-dashboard.php' class='btn'>🏠 Ana Dashboard</a>";
    echo "</div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='step error'>";
    echo "<h4>❌ Kurulum Hatası</h4>";
    echo "<p>Hata: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
    $errors[] = $e->getMessage();
}

// Summary
echo "<h3>📋 Kurulum Özeti</h3>";

if (!empty($successes)) {
    echo "<div class='step success'>";
    echo "<h4>✅ Başarılı İşlemler (" . count($successes) . ")</h4>";
    foreach ($successes as $success) {
        echo "<p>• " . htmlspecialchars($success) . "</p>";
    }
    echo "</div>";
}

if (!empty($errors)) {
    echo "<div class='step error'>";
    echo "<h4>❌ Hata Listesi (" . count($errors) . ")</h4>";
    foreach ($errors as $error) {
        echo "<p>• " . htmlspecialchars($error) . "</p>";
    }
    echo "</div>";
}

// System features overview
echo "<div class='step'>";
echo "<h4>🚀 Adaptif Öğrenme Motoru Özellikleri</h4>";
echo "<ul>";
echo "<li><strong>AI Destekli Analiz:</strong> Personel verilerini analiz ederek özelleştirilmiş önerileri üretir</li>";
echo "<li><strong>Devamsızlık Analizi:</strong> Geç kalma ve fazla mesai verilerini değerlendirir</li>";
echo "<li><strong>Departman Bazlı Öneriler:</strong> IT, Satış, İK gibi departmanlara özel eğitim önerileri</li>";
echo "<li><strong>Öncelik Skorlaması:</strong> Önerileri önem derecesine göre sıralar</li>";
echo "<li><strong>Güven Oranı:</strong> AI algoritmalarının öneriler için güven seviyesini gösterir</li>";
echo "<li><strong>Beceri Değerlendirmesi:</strong> Mevcut ve hedef beceri seviyelerini takip eder</li>";
echo "<li><strong>Toplantı Katılım Analizi:</strong> İletişim ve katılım verilerini analiz eder</li>";
echo "</ul>";
echo "</div>";

echo "<div class='step' style='text-align: center; background: #e9ecef;'>";
echo "<p style='margin: 0; color: #495057;'><strong>Kurulum Tarihi:</strong> " . date('d.m.Y H:i:s') . "</p>";
echo "</div>";

echo "</div>"; // content
echo "</div>"; // container

echo "</body>";
echo "</html>";
?>