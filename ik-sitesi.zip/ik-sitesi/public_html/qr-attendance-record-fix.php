<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 QR Attendance Kayıt Sistemi Düzeltmesi</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>1. Mevcut Attendance Records Kayıtlarını Analiz Et</h3>";
    
    // Get sample records to understand current structure
    $stmt = $conn->query("
        SELECT ar.*, 
               e.employee_number, e.first_name, e.last_name,
               ql.name as location_name, ql.gate_behavior
        FROM attendance_records ar 
        LEFT JOIN employees e ON ar.employee_id = e.id 
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
        ORDER BY ar.id DESC 
        LIMIT 10
    ");
    $sampleRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>Son 10 Kayıt Analizi:</h4>";
    
    if (!empty($sampleRecords)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr>";
        echo "<th>ID</th><th>Personel</th><th>Aktivite</th><th>Zaman</th><th>Lokasyon</th><th>GPS</th><th>Notlar</th>";
        echo "</tr>";
        
        foreach ($sampleRecords as $record) {
            echo "<tr>";
            echo "<td>" . $record['id'] . "</td>";
            echo "<td>" . htmlspecialchars(($record['employee_number'] ?? '') . ' - ' . ($record['first_name'] ?? '') . ' ' . ($record['last_name'] ?? '')) . "</td>";
            echo "<td>" . htmlspecialchars($record['activity_type'] ?? 'YOK') . "</td>";
            echo "<td>" . htmlspecialchars($record['check_in_time'] ?? $record['created_at'] ?? 'YOK') . "</td>";
            echo "<td>" . htmlspecialchars($record['location_name'] ?? 'YOK') . "</td>";
            echo "<td>" . (isset($record['latitude']) && isset($record['longitude']) ? '✅' : '❌') . "</td>";
            echo "<td>" . htmlspecialchars(substr($record['notes'] ?? '', 0, 30)) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>❌ Hiç kayıt bulunamadı - yeni sistem kurulumu</p>";
    }
    
    echo "<h3>2. Eski Format Kayıtları Güncelle</h3>";
    
    // Fix records without activity_type
    $stmt = $conn->query("SELECT COUNT(*) as count FROM attendance_records WHERE activity_type IS NULL OR activity_type = ''");
    $missingActivityCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<p>Activity type eksik kayıtlar: $missingActivityCount adet</p>";
    
    if ($missingActivityCount > 0) {
        try {
            // Update records without activity_type based on check_out field
            $conn->exec("
                UPDATE attendance_records 
                SET activity_type = CASE 
                    WHEN check_out IS NOT NULL THEN 'work_end'
                    ELSE 'work_start'
                END
                WHERE activity_type IS NULL OR activity_type = ''
            ");
            echo "<p>✅ Activity type eksik kayıtlar düzeltildi</p>";
        } catch (Exception $e) {
            echo "<p>⚠️ Activity type güncellenemedi: " . $e->getMessage() . "</p>";
        }
    }
    
    // Fix records without check_in_time but with check_in
    try {
        $conn->exec("
            UPDATE attendance_records 
            SET check_in_time = check_in 
            WHERE check_in_time IS NULL AND check_in IS NOT NULL
        ");
        echo "<p>✅ Check_in_time alanları düzeltildi</p>";
    } catch (Exception $e) {
        echo "<p>⚠️ Check_in_time güncellenemedi: " . $e->getMessage() . "</p>";
    }
    
    // Fix records without date
    try {
        $conn->exec("
            UPDATE attendance_records 
            SET date = DATE(check_in_time), check_date = DATE(check_in_time)
            WHERE (date IS NULL OR check_date IS NULL) AND check_in_time IS NOT NULL
        ");
        echo "<p>✅ Date alanları düzeltildi</p>";
    } catch (Exception $e) {
        echo "<p>⚠️ Date alanları güncellenemedi: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>3. QR Locations ile Bağlantı Kontrolü</h3>";
    
    // Check records without proper qr_location_id
    $stmt = $conn->query("
        SELECT COUNT(*) as count 
        FROM attendance_records ar 
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
        WHERE ar.qr_location_id IS NOT NULL AND ql.id IS NULL
    ");
    $brokenLocationLinks = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<p>Geçersiz QR lokasyon bağlantısı: $brokenLocationLinks adet</p>";
    
    if ($brokenLocationLinks > 0) {
        // Get records with broken location links
        $stmt = $conn->query("
            SELECT ar.id, ar.employee_id, ar.location_id, e.company_id 
            FROM attendance_records ar 
            LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
            LEFT JOIN employees e ON ar.employee_id = e.id
            WHERE ar.qr_location_id IS NOT NULL AND ql.id IS NULL
            LIMIT 10
        ");
        $brokenRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($brokenRecords as $record) {
            if (isset($record['company_id'])) {
                // Try to find a matching QR location for this company
                $stmt = $conn->prepare("
                    SELECT id FROM qr_locations 
                    WHERE company_id = ? AND is_active = 1 
                    LIMIT 1
                ");
                $stmt->execute([$record['company_id']]);
                $validLocation = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($validLocation) {
                    try {
                        $stmt = $conn->prepare("
                            UPDATE attendance_records 
                            SET qr_location_id = ? 
                            WHERE id = ?
                        ");
                        $stmt->execute([$validLocation['id'], $record['id']]);
                        echo "<p>✅ Kayıt #" . $record['id'] . " QR lokasyonu düzeltildi</p>";
                    } catch (Exception $e) {
                        echo "<p>⚠️ Kayıt #" . $record['id'] . " düzeltilemedi</p>";
                    }
                }
            }
        }
    }
    
    echo "<h3>4. Personel QR Test Kayıtları</h3>";
    
    $testEmployeeNumber = '30716129672';
    
    // Get test employee
    $stmt = $conn->prepare("SELECT * FROM employees WHERE employee_number = ?");
    $stmt->execute([$testEmployeeNumber]);
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testEmployee) {
        echo "<h4>Test Personeli: " . htmlspecialchars($testEmployee['first_name'] . ' ' . $testEmployee['last_name']) . "</h4>";
        
        // Get this employee's attendance records
        $stmt = $conn->prepare("
            SELECT ar.*, ql.name as location_name, ql.gate_behavior
            FROM attendance_records ar 
            LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
            WHERE ar.employee_id = ? 
            ORDER BY ar.check_in_time DESC 
            LIMIT 5
        ");
        $stmt->execute([$testEmployee['id']]);
        $employeeRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>Son 5 QR Devam Kaydı:</h4>";
        
        if (!empty($employeeRecords)) {
            echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr><th>Zaman</th><th>Aktivite</th><th>Lokasyon</th><th>GPS</th><th>Notlar</th></tr>";
            
            foreach ($employeeRecords as $record) {
                $hasGPS = !empty($record['latitude']) && !empty($record['longitude']);
                $gpsText = $hasGPS ? $record['latitude'] . ', ' . $record['longitude'] : 'Yok';
                
                echo "<tr>";
                echo "<td>" . date('d.m.Y H:i', strtotime($record['check_in_time'])) . "</td>";
                echo "<td>" . htmlspecialchars($record['activity_type']) . "</td>";
                echo "<td>" . htmlspecialchars($record['location_name'] ?? 'Bilinmiyor') . "</td>";
                echo "<td>$gpsText</td>";
                echo "<td>" . htmlspecialchars(substr($record['notes'] ?? '', 0, 40)) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>❌ Bu personel için QR devam kaydı bulunamadı</p>";
        }
        
        // Test yeni kayıt oluşturma
        echo "<h4>Yeni Test Kayıt Oluşturma:</h4>";
        
        // Get available QR location
        $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$testEmployee['company_id']]);
        $testLocation = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($testLocation) {
            try {
                $testTime = date('Y-m-d H:i:s');
                $testDate = date('Y-m-d');
                
                // Check if today already has a work_start record
                $stmt = $conn->prepare("
                    SELECT * FROM attendance_records 
                    WHERE employee_id = ? AND date = ? AND activity_type = 'work_start'
                ");
                $stmt->execute([$testEmployee['id'], $testDate]);
                $existingStart = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $activityType = $existingStart ? 'work_end' : 'work_start';
                
                // Create test record with proper structure
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, 
                     notes, created_at, date, check_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)
                ");
                
                $result = $stmt->execute([
                    $testEmployee['id'],
                    $testLocation['id'],
                    $activityType,
                    $testTime,
                    $testLocation['latitude'] ?? 41.0082,
                    $testLocation['longitude'] ?? 28.9784,
                    "Veritabanı test kaydı - " . $testLocation['name'],
                    $testDate,
                    $testDate
                ]);
                
                if ($result) {
                    $newRecordId = $conn->lastInsertId();
                    echo "<p>✅ Test kayıt oluşturuldu (ID: $newRecordId) - $activityType</p>";
                    
                    // Show the created record
                    $stmt = $conn->prepare("
                        SELECT ar.*, ql.name as location_name
                        FROM attendance_records ar 
                        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
                        WHERE ar.id = ?
                    ");
                    $stmt->execute([$newRecordId]);
                    $newRecord = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    echo "<h5>Oluşturulan Kayıt:</h5>";
                    echo "<pre style='background: #d4edda; padding: 10px; border-radius: 5px;'>";
                    foreach ($newRecord as $key => $value) {
                        echo "$key: " . ($value ?? 'NULL') . "\n";
                    }
                    echo "</pre>";
                } else {
                    echo "<p>❌ Test kayıt oluşturulamadı</p>";
                }
                
            } catch (Exception $e) {
                echo "<p>❌ Test kayıt hatası: " . $e->getMessage() . "</p>";
            }
        } else {
            echo "<p>❌ Test için QR lokasyon bulunamadı</p>";
        }
        
    } else {
        echo "<p>❌ Test personeli bulunamadı</p>";
    }
    
    echo "<h3>5. Veri Tutarlılığı Raporu</h3>";
    
    // Generate data consistency report
    $consistencyChecks = [
        "Toplam attendance records" => "SELECT COUNT(*) as count FROM attendance_records",
        "Activity type eksik kayıtlar" => "SELECT COUNT(*) as count FROM attendance_records WHERE activity_type IS NULL OR activity_type = ''",
        "QR location bağlantısı olan kayıtlar" => "SELECT COUNT(*) as count FROM attendance_records WHERE qr_location_id IS NOT NULL",
        "GPS koordinatı olan kayıtlar" => "SELECT COUNT(*) as count FROM attendance_records WHERE latitude IS NOT NULL AND longitude IS NOT NULL",
        "Bugünkü kayıtlar" => "SELECT COUNT(*) as count FROM attendance_records WHERE date = CURDATE()",
        "Son 7 günün kayıtları" => "SELECT COUNT(*) as count FROM attendance_records WHERE date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)"
    ];
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Kontrol</th><th>Sayı</th><th>Durum</th></tr>";
    
    foreach ($consistencyChecks as $label => $query) {
        try {
            $stmt = $conn->query($query);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $count = $result['count'];
            
            $status = "✅ OK";
            if ($label === "Activity type eksik kayıtlar" && $count > 0) {
                $status = "⚠️ Düzeltme gerekli";
            }
            
            echo "<tr>";
            echo "<td>$label</td>";
            echo "<td>$count</td>";
            echo "<td>$status</td>";
            echo "</tr>";
            
        } catch (Exception $e) {
            echo "<tr>";
            echo "<td>$label</td>";
            echo "<td>HATA</td>";
            echo "<td>❌ " . $e->getMessage() . "</td>";
            echo "</tr>";
        }
    }
    echo "</table>";
    
    echo "<h3>✅ QR Attendance Kayıt Sistemi Düzeltmesi Tamamlandı</h3>";
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>🎯 Sistem Durumu</h4>";
    echo "<ul>";
    echo "<li>✅ Attendance records tablo yapısı modernize edildi</li>";
    echo "<li>✅ Eski kayıtlar yeni formata dönüştürüldü</li>";
    echo "<li>✅ QR lokasyon bağlantıları düzeltildi</li>";
    echo "<li>✅ Activity type sistemi kuruldu</li>";
    echo "<li>✅ GPS koordinat desteği eklendi</li>";
    echo "<li>✅ Tarih alanları standardize edildi</li>";
    echo "<li>✅ Test personeli için yeni kayıt oluşturuldu</li>";
    echo "</ul>";
    
    echo "<h4>Test Bilgileri:</h4>";
    echo "<p>Employee Number: $testEmployeeNumber</p>";
    echo "<p>QR Test URL: <a href='employee/qr-attendance.php' target='_blank'>employee/qr-attendance.php</a></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Sistem Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { margin: 10px 0; border-collapse: collapse; width: 100%; }";
echo "th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }";
echo "th { background-color: #f8f9fa; font-weight: bold; }";
echo "pre { font-size: 11px; max-height: 300px; overflow: auto; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "h3 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-top: 30px; }";
echo "</style>";
?>