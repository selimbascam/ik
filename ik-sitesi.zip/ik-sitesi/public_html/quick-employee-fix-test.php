<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔧 Quick Employee Management Fix</h2>";

// Test the specific method that was failing
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Test fetchColumn method on MySQLi Statement
    $stmt = $conn->prepare("SELECT COUNT(*) FROM companies WHERE id > ?");
    $stmt->execute([0]);
    $count = $stmt->fetchColumn();
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p>✅ <strong>fetchColumn() method fixed!</strong></p>";
    echo "<p>Test result: $count companies found</p>";
    echo "</div>";
    
    // Test employee table existence and structure
    $result = $conn->query("SHOW TABLES LIKE 'employees'");
    if ($result->fetch()) {
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>✅ employees table exists</p>";
        echo "</div>";
        
        // Test employee management specific query
        $stmt = $conn->prepare("SELECT COUNT(*) FROM employees");
        $stmt->execute();
        $employeeCount = $stmt->fetchColumn();
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>✅ Employee count query successful: $employeeCount employees</p>";
        echo "</div>";
        
        // Test related tables for the exact queries from employee-management.php
        $relatedTables = [
            'attendance_records' => 'Attendance records',
            'employee_shifts' => 'Employee shifts', 
            'device_records' => 'Device records',
            'employee_devices' => 'Employee devices'
        ];
        
        foreach ($relatedTables as $table => $description) {
            try {
                $stmt = $conn->prepare("SELECT COUNT(*) FROM $table LIMIT 1");
                $stmt->execute();
                $count = $stmt->fetchColumn();
                
                echo "<div style='background: #d4edda; padding: 10px; margin: 5px 0; border-radius: 3px;'>";
                echo "<p>✅ $description table: $count records</p>";
                echo "</div>";
            } catch (Exception $e) {
                echo "<div style='background: #fff3cd; padding: 10px; margin: 5px 0; border-radius: 3px;'>";
                echo "<p>⚠️ $description table: " . $e->getMessage() . "</p>";
                echo "</div>";
            }
        }
    } else {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>⚠️ employees table not found - will be created when needed</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "<h3>✅ Fix Applied</h3>";
echo "<div style='background: #e7f3ff; padding: 15px; border-radius: 5px;'>";
echo "<p><strong>Added missing methods to database wrapper:</strong></p>";
echo "<ul>";
echo "<li><code>MySQLiStatement::fetchColumn()</code> - Returns single column value from prepared statement result</li>";
echo "<li><code>MySQLiResult::fetchColumn()</code> - Returns single column value from query result</li>";
echo "</ul>";
echo "<p>These methods provide PDO compatibility for the employee management page.</p>";
echo "</div>";

echo "<h3>🔗 Test Employee Management</h3>";
echo "<div>";
echo "<a href='auth/company-login-fixed.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Login First</a>";
echo "<a href='admin/employee-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Employee Management</a>";
echo "<a href='admin/dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
code { background: #f8f9fa; padding: 2px 6px; border-radius: 3px; }
</style>