<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Company Login Fix</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>📋 Company Login Düzeltmesi</h3>";
    
    // 1. Backup original file
    $originalFile = 'auth/company-login.php';
    $backupFile = 'auth/company-login-backup-' . date('Y-m-d-H-i-s') . '.php';
    
    if (file_exists($originalFile)) {
        copy($originalFile, $backupFile);
        echo "<p>✅ Orijinal dosya yedeklendi: $backupFile</p>";
    }
    
    // 2. Replace with fixed version
    if (file_exists('auth/company-login-fixed.php')) {
        copy('auth/company-login-fixed.php', $originalFile);
        echo "<p>✅ Düzeltilmiş dosya aktif edildi</p>";
    }
    
    // 3. Check companies table
    echo "<h4>🏢 Companies Table Kontrolü</h4>";
    
    $stmt = $conn->query("SHOW TABLES LIKE '%companies%'");
    $companyTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($companyTables)) {
        echo "<p>❌ Companies tablosu bulunamadı - oluşturuluyor...</p>";
        
        $createTableSQL = "
            CREATE TABLE companies (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_name VARCHAR(255) NOT NULL,
                name VARCHAR(255),
                email VARCHAR(255) UNIQUE NOT NULL,
                admin_email VARCHAR(255),
                password VARCHAR(255),
                company_code VARCHAR(50),
                code VARCHAR(50),
                is_active TINYINT(1) DEFAULT 1,
                status VARCHAR(50) DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ";
        
        $conn->exec($createTableSQL);
        echo "<p>✅ Companies tablosu oluşturuldu</p>";
    } else {
        echo "<p>✅ Companies tablosu mevcut: " . implode(', ', $companyTables) . "</p>";
    }
    
    // 4. Check for test company
    $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
    $stmt->execute(['test@szb.com.tr']);
    $testCompany = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$testCompany) {
        echo "<h4>🧪 Test Şirketi Oluşturuluyor</h4>";
        
        $stmt = $conn->prepare("
            INSERT INTO companies 
            (company_name, name, email, admin_email, password, company_code, code, is_active, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            'SZB Test Şirketi',
            'SZB Test Şirketi', 
            'test@szb.com.tr',
            'test@szb.com.tr',
            md5('123456'),
            'SZB001',
            'SZB001',
            1,
            'active'
        ]);
        
        echo "<p>✅ Test şirketi oluşturuldu</p>";
        echo "<p><strong>Giriş Bilgileri:</strong></p>";
        echo "<ul>";
        echo "<li>E-posta: test@szb.com.tr</li>";
        echo "<li>Şifre: 123456</li>";
        echo "</ul>";
    } else {
        echo "<h4>✅ Test Şirketi Mevcut</h4>";
        echo "<p>E-posta: test@szb.com.tr</p>";
        echo "<p>Şifre: 123456</p>";
        echo "<p>ID: " . $testCompany['id'] . "</p>";
    }
    
    // 5. Test login functionality
    echo "<h4>🔐 Login Testi</h4>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<strong>✅ Company Login Düzeltildi!</strong><br>";
    echo "<p>Artık şu linkle giriş yapabilirsiniz:</p>";
    echo "<p><a href='auth/company-login.php' style='color: #0056b3; font-weight: bold;'>https://szb.com.tr/ik/auth/company-login.php</a></p>";
    echo "<p><strong>Test Bilgileri:</strong></p>";
    echo "<ul>";
    echo "<li>E-posta: test@szb.com.tr</li>";
    echo "<li>Şifre: 123456</li>";
    echo "</ul>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Hata Oluştu</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "</style>";

echo "<hr>";
echo "<p><a href='auth/company-login.php'>🏢 Company Login'e Git</a></p>";
echo "<p><a href='debug/test-company-login.php'>🔧 Login Debug Test</a></p>";
?>