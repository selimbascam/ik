-- İcra Takip Tabloları
-- SZB İK Takip Sistemi için icra ve haciz takip modülü

-- Garnishments (İcra Dosyaları) Tablosu
CREATE TABLE IF NOT EXISTS garnishments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    court_name VARCHAR(255) NOT NULL COMMENT 'İcra Müdürlüğü Adı',
    case_number VARCHAR(100) NOT NULL COMMENT 'İcra Dosya Numarası',
    debt_amount DECIMAL(10,2) NOT NULL COMMENT 'Toplam Borç Miktarı',
    remaining_debt DECIMAL(10,2) NOT NULL COMMENT 'Kalan Borç Miktarı',
    deduction_rate DECIMAL(5,2) NOT NULL COMMENT 'Kesinti Oranı (%)',
    monthly_deduction DECIMAL(10,2) NOT NULL COMMENT 'Aylık Kesinti Miktarı',
    start_date DATE NOT NULL COMMENT 'Başlangıç Tarihi',
    end_date DATE NULL COMMENT 'Bitiş Tarihi',
    description TEXT NULL COMMENT 'Açıklama',
    status ENUM('active', 'completed', 'closed', 'suspended') DEFAULT 'active' COMMENT 'Durum',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    
    -- Indexes
    INDEX idx_employee_id (employee_id),
    INDEX idx_status (status),
    INDEX idx_case_number (case_number),
    INDEX idx_start_date (start_date),
    
    -- Unique constraint for active garnishments per employee
    UNIQUE KEY unique_active_garnishment (employee_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='İcra ve Haciz Dosyaları';

-- Garnishment Payments (İcra Ödemeleri) Tablosu
CREATE TABLE IF NOT EXISTS garnishment_payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    garnishment_id INT NOT NULL,
    payment_amount DECIMAL(10,2) NOT NULL COMMENT 'Ödeme Miktarı',
    payment_date DATE NOT NULL COMMENT 'Ödeme Tarihi',
    payment_method ENUM('salary_deduction', 'manual', 'bank_transfer') DEFAULT 'salary_deduction' COMMENT 'Ödeme Yöntemi',
    notes TEXT NULL COMMENT 'Ödeme Notları',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (garnishment_id) REFERENCES garnishments(id) ON DELETE CASCADE,
    
    -- Indexes
    INDEX idx_garnishment_id (garnishment_id),
    INDEX idx_payment_date (payment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='İcra Ödeme Kayıtları';

-- Garnishment History (İcra Geçmişi) Tablosu
CREATE TABLE IF NOT EXISTS garnishment_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    garnishment_id INT NOT NULL,
    action_type ENUM('created', 'updated', 'payment_added', 'suspended', 'resumed', 'completed', 'closed') NOT NULL,
    old_values JSON NULL COMMENT 'Eski Değerler',
    new_values JSON NULL COMMENT 'Yeni Değerler',
    performed_by INT NULL COMMENT 'İşlemi Yapan Kullanıcı ID',
    notes TEXT NULL COMMENT 'İşlem Notları',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (garnishment_id) REFERENCES garnishments(id) ON DELETE CASCADE,
    
    -- Indexes
    INDEX idx_garnishment_id (garnishment_id),
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='İcra İşlem Geçmişi';

-- Legal Limits (Yasal Limitler) Tablosu
CREATE TABLE IF NOT EXISTS legal_limits (
    id INT PRIMARY KEY AUTO_INCREMENT,
    year YEAR NOT NULL,
    minimum_wage DECIMAL(10,2) NOT NULL COMMENT 'Asgari Ücret',
    protected_amount DECIMAL(10,2) NOT NULL COMMENT 'Korunan Miktar (Asgari ücretin 2/3\'ü)',
    max_deduction_rate DECIMAL(5,2) DEFAULT 25.00 COMMENT 'Maksimum Kesinti Oranı (%)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Unique constraint for year
    UNIQUE KEY unique_year (year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Yasal Limit Değerleri';

-- Insert current year legal limits (2024 values)
INSERT INTO legal_limits (year, minimum_wage, protected_amount, max_deduction_rate) 
VALUES (2024, 17002.12, 11334.75, 25.00)
ON DUPLICATE KEY UPDATE 
    minimum_wage = VALUES(minimum_wage),
    protected_amount = VALUES(protected_amount),
    updated_at = CURRENT_TIMESTAMP;

-- Demo data for testing
INSERT INTO garnishments (
    employee_id, court_name, case_number, debt_amount, remaining_debt, 
    deduction_rate, monthly_deduction, start_date, description, status
) VALUES 
(1, 'İstanbul 1. İcra Müdürlüğü', '2024/1234', 15000.00, 12000.00, 25.00, 2000.00, '2024-01-15', 'Kredi kartı borcu için icra takibi', 'active'),
(2, 'İstanbul 3. İcra Müdürlüğü', '2024/5678', 8500.00, 6500.00, 15.00, 1000.00, '2024-02-01', 'Telefon faturası borcu', 'active')
ON DUPLICATE KEY UPDATE id=id;

-- Demo payment records
INSERT INTO garnishment_payments (garnishment_id, payment_amount, payment_date, payment_method) VALUES 
(1, 2000.00, '2024-02-01', 'salary_deduction'),
(1, 1000.00, '2024-02-15', 'manual'),
(2, 1000.00, '2024-03-01', 'salary_deduction'),
(2, 1000.00, '2024-04-01', 'salary_deduction')
ON DUPLICATE KEY UPDATE id=id;

-- Views for reporting
CREATE OR REPLACE VIEW v_active_garnishments AS
SELECT 
    g.id,
    g.case_number,
    g.court_name,
    CONCAT(e.first_name, ' ', e.last_name) as employee_name,
    e.employee_code,
    c.company_name,
    g.debt_amount,
    g.remaining_debt,
    g.deduction_rate,
    g.monthly_deduction,
    g.start_date,
    DATEDIFF(CURDATE(), g.start_date) as days_active,
    ROUND((g.debt_amount - g.remaining_debt) / g.debt_amount * 100, 2) as completion_percentage
FROM garnishments g
JOIN employees e ON g.employee_id = e.id
JOIN companies c ON e.company_id = c.id
WHERE g.status = 'active'
ORDER BY g.start_date DESC;

-- View for monthly deduction summary
CREATE OR REPLACE VIEW v_monthly_deductions AS
SELECT 
    c.company_name,
    COUNT(g.id) as active_cases,
    SUM(g.monthly_deduction) as total_monthly_deduction,
    SUM(g.remaining_debt) as total_remaining_debt,
    AVG(g.deduction_rate) as avg_deduction_rate
FROM garnishments g
JOIN employees e ON g.employee_id = e.id
JOIN companies c ON e.company_id = c.id
WHERE g.status = 'active'
GROUP BY c.id, c.company_name
ORDER BY total_monthly_deduction DESC;

-- Stored procedure for calculating legal deduction limits
DELIMITER //
CREATE OR REPLACE PROCEDURE CalculateLegalDeduction(
    IN p_employee_id INT,
    IN p_requested_rate DECIMAL(5,2),
    OUT p_max_deduction DECIMAL(10,2),
    OUT p_is_legal BOOLEAN
)
BEGIN
    DECLARE v_salary DECIMAL(10,2);
    DECLARE v_protected_amount DECIMAL(10,2);
    DECLARE v_max_rate DECIMAL(5,2);
    DECLARE v_calculated_deduction DECIMAL(10,2);
    
    -- Get employee salary
    SELECT salary INTO v_salary 
    FROM employees 
    WHERE id = p_employee_id;
    
    -- Get current year legal limits
    SELECT protected_amount, max_deduction_rate 
    INTO v_protected_amount, v_max_rate
    FROM legal_limits 
    WHERE year = YEAR(CURDATE());
    
    -- Calculate maximum legal deduction
    -- Cannot exceed 25% of salary and must leave protected amount
    SET p_max_deduction = LEAST(
        v_salary * (v_max_rate / 100),
        GREATEST(0, v_salary - v_protected_amount)
    );
    
    -- Calculate requested deduction
    SET v_calculated_deduction = v_salary * (p_requested_rate / 100);
    
    -- Check if requested deduction is legal
    SET p_is_legal = (v_calculated_deduction <= p_max_deduction);
    
END //
DELIMITER ;

-- Trigger to log garnishment changes
DELIMITER //
CREATE OR REPLACE TRIGGER tr_garnishment_history 
AFTER UPDATE ON garnishments
FOR EACH ROW
BEGIN
    INSERT INTO garnishment_history (
        garnishment_id, 
        action_type, 
        old_values, 
        new_values,
        created_at
    ) VALUES (
        NEW.id,
        'updated',
        JSON_OBJECT(
            'debt_amount', OLD.debt_amount,
            'remaining_debt', OLD.remaining_debt,
            'deduction_rate', OLD.deduction_rate,
            'monthly_deduction', OLD.monthly_deduction,
            'status', OLD.status
        ),
        JSON_OBJECT(
            'debt_amount', NEW.debt_amount,
            'remaining_debt', NEW.remaining_debt,
            'deduction_rate', NEW.deduction_rate,
            'monthly_deduction', NEW.monthly_deduction,
            'status', NEW.status
        ),
        NOW()
    );
END //
DELIMITER ;

-- Function to get remaining months for garnishment completion
DELIMITER //
CREATE OR REPLACE FUNCTION GetRemainingMonths(p_garnishment_id INT) 
RETURNS INT
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE v_remaining_debt DECIMAL(10,2);
    DECLARE v_monthly_deduction DECIMAL(10,2);
    DECLARE v_remaining_months INT;
    
    SELECT remaining_debt, monthly_deduction 
    INTO v_remaining_debt, v_monthly_deduction
    FROM garnishments 
    WHERE id = p_garnishment_id AND status = 'active';
    
    IF v_monthly_deduction > 0 THEN
        SET v_remaining_months = CEIL(v_remaining_debt / v_monthly_deduction);
    ELSE
        SET v_remaining_months = 999; -- Sonsuz
    END IF;
    
    RETURN v_remaining_months;
END //
DELIMITER ;