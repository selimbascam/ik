-- SZB İK Takip Sistemi - MySQL Database Setup
-- Hostinger MySQL 8.x Compatible

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Şirketler tablosu (Multi-tenant support)
CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(20),
  `contact_email` varchar(100) UNIQUE NOT NULL COMMENT 'Firma iletişim email - giriş için kullanılır',
  `tax_number` varchar(20) UNIQUE,
  `sector` varchar(100) COMMENT 'Firma sektörü',
  `employee_count` int(11) DEFAULT 0 COMMENT 'Tahmini personel sayısı',
  `is_active` tinyint(1) DEFAULT 1,
  `subscription_type` enum('trial','basic','premium','enterprise') DEFAULT 'trial',
  `trial_end_date` date COMMENT 'Deneme süresi bitiş tarihi',
  `subscription_end_date` date COMMENT 'Abonelik bitiş tarihi',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contact_email` (`contact_email`),
  KEY `idx_tax_number` (`tax_number`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Departmanlar tablosu
CREATE TABLE `departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_company_id` (`company_id`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Personel tablosu
CREATE TABLE `employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11),
  `company_id` int(11) NOT NULL,
  `department_id` int(11),
  `employee_code` varchar(20) UNIQUE NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100),
  `phone` varchar(20),
  `position` varchar(100),
  `hire_date` date,
  `salary` decimal(10,2),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_company_id` (`company_id`),
  KEY `idx_department_id` (`department_id`),
  KEY `idx_employee_code` (`employee_code`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- QR Lokasyonları tablosu
CREATE TABLE `qr_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location_code` varchar(50) UNIQUE NOT NULL,
  `location_type` enum('check_in','check_out','tea_break','lunch_break','smoke_break','other') NOT NULL,
  `description` text,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_company_id` (`company_id`),
  KEY `idx_location_code` (`location_code`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Devam kayıtları tablosu
CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `check_in` time,
  `check_out` time,
  `break_duration` int(11) DEFAULT 0 COMMENT 'Dakika cinsinden toplam mola süresi',
  `work_duration` int(11) DEFAULT 0 COMMENT 'Dakika cinsinden çalışma süresi',
  `overtime_duration` int(11) DEFAULT 0 COMMENT 'Dakika cinsinden mesai süresi',
  `status` enum('present','absent','late','early_leave','holiday') DEFAULT 'present',
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_employee_date` (`employee_id`, `date`),
  KEY `idx_employee_id` (`employee_id`),
  KEY `idx_date` (`date`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Aktivite kayıtları tablosu
CREATE TABLE `attendance_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `qr_location_id` int(11) NOT NULL,
  `activity_type` enum('check_in','check_out','tea_break','lunch_break','smoke_break','break_end') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `device_info` text COMMENT 'JSON formatında cihaz bilgileri',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `idx_employee_id` (`employee_id`),
  KEY `idx_qr_location_id` (`qr_location_id`),
  KEY `idx_timestamp` (`timestamp`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`qr_location_id`) REFERENCES `qr_locations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- İzin türleri tablosu
CREATE TABLE `leave_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `annual_limit` int(11) DEFAULT 0 COMMENT 'Yıllık limit (gün)',
  `requires_approval` tinyint(1) DEFAULT 1,
  `is_paid` tinyint(1) DEFAULT 1,
  `color` varchar(7) DEFAULT '#007bff' COMMENT 'Hex color code',
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_company_id` (`company_id`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- İzin talepleri tablosu
CREATE TABLE `leave_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `days_requested` int(11) NOT NULL,
  `reason` text,
  `status` enum('pending','approved','rejected','cancelled') DEFAULT 'pending',
  `approved_by` int(11),
  `approved_at` timestamp NULL,
  `rejection_reason` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_employee_id` (`employee_id`),
  KEY `idx_leave_type_id` (`leave_type_id`),
  KEY `idx_status` (`status`),
  KEY `idx_start_date` (`start_date`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`approved_by`) REFERENCES `employees` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vardiya tablosu
CREATE TABLE `shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `break_duration` int(11) DEFAULT 60 COMMENT 'Dakika cinsinden mola süresi',
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_company_id` (`company_id`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Personel vardiya atamaları
CREATE TABLE `employee_shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `shift_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_employee_shift_date` (`employee_id`, `date`),
  KEY `idx_shift_id` (`shift_id`),
  KEY `idx_date` (`date`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mola hakları tablosu
CREATE TABLE `employee_break_entitlements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `break_type` enum('tea_break','lunch_break','smoke_break') NOT NULL,
  `daily_limit_minutes` int(11) NOT NULL DEFAULT 15,
  `used_minutes_today` int(11) DEFAULT 0,
  `last_reset_date` date DEFAULT (CURDATE()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_employee_break_type` (`employee_id`, `break_type`),
  FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PHP Sessions tablosu (isteğe bağlı - PHP session handler için)
CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `data` mediumtext,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Firma yöneticileri tablosu (Şirket sahipleri/yöneticileri)
CREATE TABLE `company_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) UNIQUE NOT NULL,
  `phone` varchar(20),
  `password_hash` varchar(255) NOT NULL,
  `is_owner` tinyint(1) DEFAULT 0 COMMENT '1=Şirket sahibi, 0=Yönetici',
  `permissions` text COMMENT 'JSON formatında yetkiler',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_company_id` (`company_id`),
  KEY `idx_email` (`email`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Şirket paketleri tablosu (Fiyatlandırma planları)
CREATE TABLE `company_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `max_employees` int(11) NOT NULL DEFAULT 50,
  `max_locations` int(11) NOT NULL DEFAULT 10,
  `features` text COMMENT 'JSON formatında özellikler',
  `price_monthly` decimal(10,2) NOT NULL DEFAULT 0.00,
  `price_yearly` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Şirket abonelikleri tablosu
CREATE TABLE `company_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','expired','cancelled','suspended') DEFAULT 'active',
  `payment_method` varchar(50),
  `amount_paid` decimal(10,2),
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_company_id` (`company_id`),
  KEY `idx_package_id` (`package_id`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`package_id`) REFERENCES `company_packages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Şirket ayarları tablosu
CREATE TABLE `company_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `data_type` enum('string','integer','float','boolean','json') DEFAULT 'string',
  `description` text,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_company_setting` (`company_id`, `setting_key`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Kullanıcılar tablosu (OAuth desteği ile)
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) UNIQUE,
  `email` varchar(100) UNIQUE NOT NULL,
  `password_hash` varchar(255) NULL COMMENT 'OAuth kullanıcıları için boş olabilir',
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(20),
  `role` enum('admin','employee') DEFAULT 'employee',
  `oauth_provider` enum('google','apple','facebook') NULL,
  `oauth_provider_id` varchar(255) NULL,
  `profile_picture` varchar(500) NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_oauth` (`oauth_provider`, `oauth_provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sistem yöneticileri tablosu (Platform yöneticileri)
CREATE TABLE `system_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) UNIQUE NOT NULL,
  `email` varchar(100) UNIQUE NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(50),
  `last_name` varchar(50),
  `role` enum('super_admin','admin','support') DEFAULT 'admin',
  `permissions` text COMMENT 'JSON formatında yetkiler',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Demo Data Insertion

-- Paket tanımları
INSERT INTO `company_packages` (`name`, `description`, `max_employees`, `max_locations`, `features`, `price_monthly`, `price_yearly`) VALUES
('Başlangıç', 'Küçük işletmeler için temel PDKS sistemi', 10, 3, '["basic_attendance","qr_tracking","basic_reports"]', 199.00, 1990.00),
('Standart', 'Orta ölçekli şirketler için gelişmiş özellikler', 50, 10, '["advanced_attendance","qr_tracking","detailed_reports","leave_management","shift_planning"]', 499.00, 4990.00),
('Premium', 'Büyük şirketler için tam özellikli sistem', 200, 25, '["all_features","advanced_reports","api_access","priority_support","custom_integration"]', 999.00, 9990.00),
('Enterprise', 'Kurumsal çözümler ve özel geliştirmeler', 999999, 999999, '["unlimited_features","custom_development","dedicated_support","on_premise_option"]', 2499.00, 24990.00);

-- Demo şirket
INSERT INTO `companies` (`name`, `address`, `phone`, `email`, `tax_number`) VALUES
('SZB Teknoloji A.Ş.', 'Maslak Mahallesi, Büyükdere Caddesi No:123, Sarıyer/İstanbul', '+90 212 555 0123', 'info@szb.com.tr', '1234567890'),
('Demo Şirketi Ltd.', 'Atatürk Mahallesi, Demo Sokak No:456, Kadıköy/İstanbul', '+90 216 555 0456', 'info@demo.com.tr', '0987654321');

INSERT INTO `departments` (`company_id`, `name`, `description`) VALUES
(1, 'Bilgi İşlem', 'IT ve yazılım geliştirme departmanı'),
(1, 'İnsan Kaynakları', 'İK ve personel işlemleri'),
(1, 'Muhasebe', 'Mali işler ve muhasebe'),
(1, 'Satış', 'Satış ve pazarlama');

INSERT INTO `qr_locations` (`company_id`, `name`, `location_code`, `location_type`, `description`) VALUES
(1, 'Ana Giriş Kapısı', 'SZB001GIRIS', 'check_in', 'SZB Teknoloji ana giriş kapısı'),
(1, 'Ana Çıkış Kapısı', 'SZB002CIKIS', 'check_out', 'SZB Teknoloji ana çıkış kapısı'),
(1, 'Çay Ocağı', 'SZB003CAYMOLA', 'tea_break', 'SZB Teknoloji çay molası alanı'),
(1, 'Yemekhane', 'SZB004YEMEK', 'lunch_break', 'SZB Teknoloji yemekhane'),
(1, 'Sigara İçme Alanı', 'SZB005SIGARA', 'smoke_break', 'SZB Teknoloji sigara içme alanı'),
(2, 'Ofis Girişi', 'DEMO001GIRIS', 'check_in', 'Demo şirketi ofis girişi'),
(2, 'Ofis Çıkışı', 'DEMO002CIKIS', 'check_out', 'Demo şirketi ofis çıkışı'),
(2, 'Mutfak', 'DEMO003MUTFAK', 'tea_break', 'Demo şirketi mutfak alanı');

-- Sistem yöneticisi
INSERT INTO `system_admins` (`username`, `email`, `password_hash`, `first_name`, `last_name`, `role`, `permissions`) VALUES
('superadmin', 'admin@system.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System', 'Admin', 'super_admin', '["all_permissions"]');

-- Şirket yöneticileri tablosuna OAuth desteği ekleme
ALTER TABLE `company_admins` 
ADD COLUMN `oauth_provider` enum('google','apple','facebook') NULL AFTER `permissions`,
ADD COLUMN `oauth_provider_id` varchar(255) NULL AFTER `oauth_provider`,
ADD COLUMN `profile_picture` varchar(500) NULL AFTER `oauth_provider_id`,
ADD KEY `idx_oauth` (`oauth_provider`, `oauth_provider_id`);

-- Şirket yöneticileri
INSERT INTO `company_admins` (`company_id`, `first_name`, `last_name`, `email`, `phone`, `password_hash`, `is_owner`, `permissions`) VALUES
(1, 'Ahmet', 'Yılmaz', 'ahmet@szb.com.tr', '+90 555 123 4567', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, '["all_company_permissions"]'),
(1, 'Mehmet', 'Kaya', 'mehmet@szb.com.tr', '+90 555 765 4321', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 0, '["employee_management","attendance_reports"]'),
(2, 'Ayşe', 'Demir', 'ayse@demo.com.tr', '+90 555 987 6543', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, '["all_company_permissions"]');

-- Şirket abonelikleri
INSERT INTO `company_subscriptions` (`company_id`, `package_id`, `start_date`, `end_date`, `status`, `amount_paid`) VALUES
(1, 2, '2024-01-01', '2024-12-31', 'active', 4990.00),
(2, 1, '2024-01-15', '2025-01-15', 'active', 1990.00);

-- Şirket ayarları
INSERT INTO `company_settings` (`company_id`, `setting_key`, `setting_value`, `data_type`, `description`) VALUES
(1, 'work_hours_start', '09:00', 'string', 'Normal mesai başlangıç saati'),
(1, 'work_hours_end', '18:00', 'string', 'Normal mesai bitiş saati'),
(1, 'lunch_break_duration', '60', 'integer', 'Öğle yemeği molası süresi (dakika)'),
(1, 'overtime_rate', '1.5', 'float', 'Mesai ücreti katsayısı'),
(1, 'allow_early_checkin', 'true', 'boolean', 'Erken giriş izni'),
(1, 'require_photo_checkin', 'false', 'boolean', 'Giriş sırasında fotoğraf zorunluluğu'),
(2, 'work_hours_start', '08:30', 'string', 'Normal mesai başlangıç saati'),
(2, 'work_hours_end', '17:30', 'string', 'Normal mesai bitiş saati'),
(2, 'lunch_break_duration', '45', 'integer', 'Öğle yemeği molası süresi (dakika)');

-- Kullanıcılar tablosu (Multi-role support)
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) UNIQUE NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(50),
  `last_name` varchar(50),
  `role` enum('system_admin','company_admin','hr','manager','employee') DEFAULT 'employee',
  `company_id` int(11) COMMENT 'Null for system_admin, required for others',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_company_id` (`company_id`),
  FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Demo kullanıcılar (Multi-tenant)
INSERT INTO `users` (`email`, `password_hash`, `first_name`, `last_name`, `role`, `company_id`) VALUES
('info@szb.com.tr', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ahmet', 'Yılmaz', 'company_admin', 1),
('demo@firma.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ayşe', 'Demir', 'company_admin', 2),
('admin@system.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System', 'Admin', 'system_admin', NULL),
('demo1@szb.com.tr', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Demo', 'Personel 1', 'employee', 1),
('demo2@firma.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Demo', 'Personel 2', 'employee', 2);

INSERT INTO `employees` (`user_id`, `company_id`, `department_id`, `employee_code`, `first_name`, `last_name`, `email`, `position`, `hire_date`) VALUES
(4, 1, 1, 'SZB001', 'Demo', 'Personel 1', 'demo1@szb.com.tr', 'Yazılım Geliştirici', '2024-01-01'),
(5, 2, NULL, 'DEMO001', 'Demo', 'Personel 2', 'demo2@firma.com', 'Muhasebe Uzmanı', '2024-01-15');

INSERT INTO `leave_types` (`company_id`, `name`, `annual_limit`, `color`) VALUES
(1, 'Yıllık İzin', 14, '#007bff'),
(1, 'Hastalık İzni', 10, '#dc3545'),
(1, 'Doğum İzni', 60, '#28a745'),
(1, 'Mazeret İzni', 5, '#ffc107');

INSERT INTO `shifts` (`company_id`, `name`, `start_time`, `end_time`, `break_duration`) VALUES
(1, 'Normal Mesai', '09:00:00', '18:00:00', 60),
(1, 'Vardiya 1', '06:00:00', '14:00:00', 45),
(1, 'Vardiya 2', '14:00:00', '22:00:00', 45),
(1, 'Vardiya 3', '22:00:00', '06:00:00', 45);

INSERT INTO `employee_break_entitlements` (`employee_id`, `break_type`, `daily_limit_minutes`) VALUES
(1, 'tea_break', 30),
(1, 'lunch_break', 60),
(1, 'smoke_break', 20);

COMMIT;