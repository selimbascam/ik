<?php
// Redirect to the correct device table creation script
header('Location: debug/fix-device-records.php');
exit;
?>