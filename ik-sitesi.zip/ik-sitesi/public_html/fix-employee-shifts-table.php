<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Employee Shifts Table Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Step 1: Check Employee Shifts Table</h3>";
    
    // Check if employee_shifts table exists
    $tables = $conn->query("SHOW TABLES LIKE 'employee_shifts'")->fetchAll();
    
    if (count($tables) == 0) {
        echo "<p style='color: orange;'>Employee shifts table missing. Creating it...</p>";
        
        $conn->exec("
            CREATE TABLE employee_shifts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                shift_template_id INT NULL,
                shift_id INT NULL,
                shift_date DATE NOT NULL,
                start_time TIME DEFAULT '09:00:00',
                end_time TIME DEFAULT '17:00:00',
                break_duration INT DEFAULT 60,
                status ENUM('scheduled', 'present', 'absent', 'late', 'early_leave') DEFAULT 'scheduled',
                actual_start_time TIME NULL,
                actual_end_time TIME NULL,
                worked_minutes INT DEFAULT 0,
                overtime_minutes INT DEFAULT 0,
                break_minutes INT DEFAULT 60,
                early_leave_reason TEXT NULL,
                notes TEXT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_employee_id (employee_id),
                INDEX idx_shift_date (shift_date),
                INDEX idx_employee_date (employee_id, shift_date)
            )
        ");
        
        echo "<p style='color: green;'>Employee shifts table created successfully</p>";
        
        // Create sample shift data for current month
        $currentYear = date('Y');
        $currentMonth = date('m');
        $employees = $conn->query("SELECT id FROM employees LIMIT 3")->fetchAll();
        
        foreach ($employees as $emp) {
            for ($day = 1; $day <= 22; $day++) {
                $shiftDate = sprintf('%04d-%02d-%02d', $currentYear, $currentMonth, $day);
                
                // Skip weekends (basic check)
                $dayOfWeek = date('N', strtotime($shiftDate));
                if ($dayOfWeek > 5) continue;
                
                $status = 'present';
                $workedMinutes = 480; // 8 hours
                $overtimeMinutes = 0;
                
                // Add some variation
                if ($day % 7 == 0) {
                    $status = 'late';
                    $workedMinutes = 450; // 7.5 hours due to lateness
                } elseif ($day % 11 == 0) {
                    $overtimeMinutes = 60; // 1 hour overtime
                    $workedMinutes = 540; // 9 hours total
                }
                
                $stmt = $conn->prepare("
                    INSERT INTO employee_shifts (
                        employee_id, shift_date, start_time, end_time,
                        status, worked_minutes, overtime_minutes
                    ) VALUES (?, ?, '09:00:00', '17:00:00', ?, ?, ?)
                ");
                $stmt->execute([$emp['id'], $shiftDate, $status, $workedMinutes, $overtimeMinutes]);
            }
        }
        
        echo "<p style='color: green;'>Created sample shift data for current month</p>";
        
    } else {
        echo "<p style='color: green;'>Employee shifts table exists</p>";
        
        // Check columns
        $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll();
        $columnNames = array_column($columns, 'Field');
        
        echo "<h4>Current Columns:</h4>";
        echo "<ul>";
        foreach ($columnNames as $col) {
            echo "<li>{$col}</li>";
        }
        echo "</ul>";
        
        // Check if shift_date column exists
        if (!in_array('shift_date', $columnNames)) {
            echo "<p style='color: orange;'>shift_date column missing. Adding it...</p>";
            $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_date DATE NOT NULL AFTER shift_id");
            echo "<p style='color: green;'>shift_date column added</p>";
        }
        
        // Check if other required columns exist
        $requiredColumns = ['status', 'worked_minutes', 'overtime_minutes', 'break_duration'];
        foreach ($requiredColumns as $col) {
            if (!in_array($col, $columnNames)) {
                echo "<p style='color: orange;'>{$col} column missing. Adding it...</p>";
                
                switch ($col) {
                    case 'status':
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN status ENUM('scheduled', 'present', 'absent', 'late', 'early_leave') DEFAULT 'scheduled'");
                        break;
                    case 'worked_minutes':
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN worked_minutes INT DEFAULT 0");
                        break;
                    case 'overtime_minutes':
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN overtime_minutes INT DEFAULT 0");
                        break;
                    case 'break_duration':
                        $conn->exec("ALTER TABLE employee_shifts ADD COLUMN break_duration INT DEFAULT 60");
                        break;
                }
                echo "<p style='color: green;'>{$col} column added</p>";
            }
        }
    }
    
    echo "<h3>Step 2: Test Shift Query</h3>";
    
    // Test the exact query from calculate-monthly-summary.php
    $testQuery = "
        SELECT 
            es.*,
            st.start_time as template_start_time,
            st.end_time as template_end_time,
            st.break_duration as template_break_duration
        FROM employee_shifts es
        LEFT JOIN shift_templates st ON es.shift_template_id = st.id
        WHERE es.employee_id = ? 
        AND YEAR(es.shift_date) = ? 
        AND MONTH(es.shift_date) = ?
        ORDER BY es.shift_date
        LIMIT 5
    ";
    
    try {
        $stmt = $conn->prepare($testQuery);
        $stmt->execute([1, date('Y'), date('m')]);
        $shifts = $stmt->fetchAll();
        
        echo "<p style='color: green;'>Shift query successful! Found " . count($shifts) . " shifts</p>";
        
        if (count($shifts) > 0) {
            echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
            echo "<tr style='background: #f0f0f0;'>";
            echo "<th style='padding: 8px;'>Date</th>";
            echo "<th style='padding: 8px;'>Status</th>";
            echo "<th style='padding: 8px;'>Start</th>";
            echo "<th style='padding: 8px;'>End</th>";
            echo "<th style='padding: 8px;'>Worked</th>";
            echo "<th style='padding: 8px;'>Overtime</th>";
            echo "</tr>";
            
            foreach ($shifts as $shift) {
                echo "<tr>";
                echo "<td style='padding: 8px;'>{$shift['shift_date']}</td>";
                echo "<td style='padding: 8px;'>" . ucfirst($shift['status']) . "</td>";
                echo "<td style='padding: 8px;'>{$shift['start_time']}</td>";
                echo "<td style='padding: 8px;'>{$shift['end_time']}</td>";
                echo "<td style='padding: 8px;'>" . ($shift['worked_minutes'] / 60) . "h</td>";
                echo "<td style='padding: 8px;'>" . ($shift['overtime_minutes'] / 60) . "h</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>Shift query failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>Step 3: Check Shift Templates Table</h3>";
    
    // Check shift_templates table
    $templates = $conn->query("SHOW TABLES LIKE 'shift_templates'")->fetchAll();
    
    if (count($templates) == 0) {
        echo "<p style='color: orange;'>Shift templates table missing. Creating it...</p>";
        
        $conn->exec("
            CREATE TABLE shift_templates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                break_duration INT DEFAULT 60,
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Insert default templates
        $conn->exec("
            INSERT INTO shift_templates (name, start_time, end_time, break_duration) VALUES
            ('Sabah Vardiyası', '09:00:00', '17:00:00', 60),
            ('Öğle Vardiyası', '13:00:00', '21:00:00', 60),
            ('Gece Vardiyası', '21:00:00', '05:00:00', 60)
        ");
        
        echo "<p style='color: green;'>Shift templates table created with default templates</p>";
    } else {
        echo "<p style='color: green;'>Shift templates table exists</p>";
    }
    
    echo "<h3>Step 4: Data Statistics</h3>";
    
    // Show data statistics
    $employeeCount = $conn->query("SELECT COUNT(*) as count FROM employees")->fetch()['count'];
    $shiftsCount = $conn->query("SELECT COUNT(*) as count FROM employee_shifts")->fetch()['count'];
    $currentMonthShifts = $conn->query("
        SELECT COUNT(*) as count FROM employee_shifts 
        WHERE YEAR(shift_date) = YEAR(CURDATE()) 
        AND MONTH(shift_date) = MONTH(CURDATE())
    ")->fetch()['count'];
    
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p><strong>Data Overview:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Total Employees:</strong> {$employeeCount}</li>";
    echo "<li><strong>Total Shifts:</strong> {$shiftsCount}</li>";
    echo "<li><strong>Current Month Shifts:</strong> {$currentMonthShifts}</li>";
    echo "</ul>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
}

echo "<h3>Summary</h3>";
echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
echo "<p><strong>✅ Shift System Fixed:</strong></p>";
echo "<ul>";
echo "<li>Employee_shifts table with shift_date column</li>";
echo "<li>Required columns: status, worked_minutes, overtime_minutes</li>";
echo "<li>Shift_templates table for shift definitions</li>";
echo "<li>Sample data for current month testing</li>";
echo "<li>Payroll API queries should now work</li>";
echo "</ul>";
echo "</div>";

echo "<h3>Test Payroll System</h3>";
echo "<div>";
$currentYear = date('Y');
$currentMonth = date('m');
$apiUrl = "api/calculate-monthly-summary.php?year={$currentYear}&month={$currentMonth}";
echo "<a href='{$apiUrl}' target='_blank' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Test Payroll API</a>";
echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Admin Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
table { width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background: #f0f0f0; }
ul { background: #f8f9fa; padding: 15px; border-radius: 5px; }
</style>