<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$message = '';
$messageType = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($email) || empty($password)) {
        $message = "E-posta ve şifre gereklidir.";
        $messageType = 'error';
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Find company by email
            $stmt = $conn->prepare("SELECT id, email, company_name, password FROM companies WHERE email = ?");
            $stmt->execute([$email]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                $passwordValid = false;
                
                // Check different password formats
                if ($company['password'] === $password) {
                    $passwordValid = true; // Plain text match
                } elseif (md5($password) === $company['password']) {
                    $passwordValid = true; // MD5 hash match
                } elseif (password_verify($password, $company['password'])) {
                    $passwordValid = true; // PHP password hash match
                } elseif (empty($company['password'])) {
                    // No password set - set it now
                    $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE id = ?");
                    $stmt->execute([$password, $company['id']]);
                    $passwordValid = true;
                }
                
                if ($passwordValid) {
                    // Set all necessary session variables
                    $_SESSION['user_id'] = $company['id'];
                    $_SESSION['company_id'] = $company['id'];
                    $_SESSION['user_email'] = $company['email'];
                    $_SESSION['admin_email'] = $company['email'];
                    $_SESSION['company_name'] = $company['company_name'];
                    $_SESSION['user_role'] = 'admin';
                    $_SESSION['user_type'] = 'company';
                    $_SESSION['login_type'] = 'company';
                    $_SESSION['user_name'] = 'Şirket Yöneticisi';
                    $_SESSION['is_admin'] = true;
                    
                    // Redirect to dashboard
                    header("Location: admin/dashboard.php");
                    exit;
                    
                } else {
                    $message = "Geçersiz e-posta veya şifre.";
                    $messageType = 'error';
                }
                
            } else {
                $message = "Şirket bulunamadı. E-posta adresinizi kontrol edin.";
                $messageType = 'error';
            }
            
        } catch (Exception $e) {
            $message = "Giriş hatası: " . $e->getMessage();
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Girişi - SZB İK Takip</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .logo h1 {
            color: #333;
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
        }
        
        .logo p {
            color: #666;
            font-size: 0.9rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: 500;
        }
        
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            width: 100%;
            padding: 0.75rem;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background: #5a6fd8;
        }
        
        .message {
            padding: 0.75rem;
            border-radius: 5px;
            margin-bottom: 1rem;
            text-align: center;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .links {
            text-align: center;
            margin-top: 1rem;
        }
        
        .links a {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .links a:hover {
            text-decoration: underline;
        }
        
        .test-info {
            background: #e7f3ff;
            padding: 1rem;
            border-radius: 5px;
            margin-top: 1rem;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <h1>SZB İK Takip</h1>
            <p>Şirket Yönetici Girişi</p>
        </div>

        <?php if ($message): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="email">E-posta Adresi</label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password">Şifre</label>
                <input 
                    type="password" 
                    id="password" 
                    name="password" 
                    required
                >
            </div>

            <button type="submit" class="btn">Giriş Yap</button>
        </form>

        <div class="links">
            <a href="auth/employee-login.php">Personel Girişi</a> |
            <a href="index.php">Ana Sayfa</a>
        </div>

        <div class="test-info">
            <strong>Test Bilgileri:</strong><br>
            E-posta: test@szb.com.tr<br>
            Şifre: 123456
        </div>
    </div>
</body>
</html>