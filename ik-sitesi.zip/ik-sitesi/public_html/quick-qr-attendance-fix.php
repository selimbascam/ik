<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Quick QR Attendance Foreign Key Fix</h1>";
echo "<p>Emergency fix for QR attendance foreign key constraint errors</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📊 Diagnosing attendance_records table</h2>";
    
    // Check table structure
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $columnNames = array_column($columns, 'Field');
    
    $hasCompanyId = in_array('company_id', $columnNames);
    
    if (!$hasCompanyId) {
        echo "<h3>🛠️ Adding company_id column</h3>";
        
        // Add company_id column
        $conn->exec("ALTER TABLE attendance_records ADD COLUMN company_id INT NULL AFTER id");
        echo "<p>✅ company_id column added</p>";
        
        // Populate from employees table
        $conn->exec("
            UPDATE attendance_records ar 
            INNER JOIN employees e ON ar.employee_id = e.id 
            SET ar.company_id = e.company_id 
            WHERE ar.company_id IS NULL
        ");
        echo "<p>✅ company_id populated from employees</p>";
        
        // Make it NOT NULL
        $conn->exec("ALTER TABLE attendance_records MODIFY COLUMN company_id INT NOT NULL");
        echo "<p>✅ company_id set to NOT NULL</p>";
        
    } else {
        echo "<p>✅ company_id column already exists</p>";
        
        // Fill any NULL values
        $stmt = $conn->query("SELECT COUNT(*) as count FROM attendance_records WHERE company_id IS NULL");
        $nullCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($nullCount > 0) {
            $conn->exec("
                UPDATE attendance_records ar 
                INNER JOIN employees e ON ar.employee_id = e.id 
                SET ar.company_id = e.company_id 
                WHERE ar.company_id IS NULL
            ");
            echo "<p>✅ Fixed $nullCount NULL company_id values</p>";
        }
    }
    
    // Add foreign key constraint
    echo "<h3>🔗 Adding foreign key constraint</h3>";
    
    try {
        // Add index first
        $conn->exec("ALTER TABLE attendance_records ADD INDEX idx_company_id (company_id)");
    } catch (Exception $e) {
        // Index might already exist
    }
    
    try {
        $conn->exec("
            ALTER TABLE attendance_records 
            ADD CONSTRAINT fk_attendance_company 
            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
        ");
        echo "<p>✅ Foreign key constraint added</p>";
    } catch (Exception $e) {
        if (strpos($e->getMessage(), 'already exists') !== false) {
            echo "<p>✅ Foreign key constraint already exists</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ Foreign key warning: " . $e->getMessage() . "</p>";
        }
    }
    
    // Create trigger for auto-population
    echo "<h3>🤖 Creating auto-population trigger</h3>";
    
    try {
        $conn->exec("DROP TRIGGER IF EXISTS attendance_company_id_trigger");
        $conn->exec("
            CREATE TRIGGER attendance_company_id_trigger
            BEFORE INSERT ON attendance_records
            FOR EACH ROW
            BEGIN
                IF NEW.company_id IS NULL THEN
                    SET NEW.company_id = (
                        SELECT company_id FROM employees WHERE id = NEW.employee_id LIMIT 1
                    );
                END IF;
            END
        ");
        echo "<p>✅ Trigger created for automatic company_id</p>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Trigger error: " . $e->getMessage() . "</p>";
    }
    
    // Test the fix
    echo "<h3>🧪 Testing Fix</h3>";
    
    $stmt = $conn->query("SELECT id, company_id FROM employees WHERE is_active = 1 LIMIT 1");
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testEmployee) {
        try {
            // Test insert
            $testStmt = $conn->prepare("
                INSERT INTO attendance_records (employee_id, activity_type, check_in_time, date, notes) 
                VALUES (?, 'test', NOW(), CURDATE(), 'Test record')
            ");
            $testStmt->execute([$testEmployee['id']]);
            
            $testId = $conn->lastInsertId();
            
            // Verify company_id
            $verifyStmt = $conn->prepare("SELECT company_id FROM attendance_records WHERE id = ?");
            $verifyStmt->execute([$testId]);
            $testRecord = $verifyStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($testRecord['company_id'] == $testEmployee['company_id']) {
                echo "<p>✅ Test successful - company_id automatically set</p>";
            } else {
                echo "<p style='color: red;'>❌ Test failed</p>";
            }
            
            // Cleanup
            $conn->prepare("DELETE FROM attendance_records WHERE id = ?")->execute([$testId]);
            echo "<p>🧹 Test data cleaned</p>";
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Test failed: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>✅ QR Attendance Fix Complete!</h3>";
    echo "<p>The foreign key constraint error should now be resolved.</p>";
    echo "<p><strong>QR kod okuma sistemi artık düzgün çalışmalıdır.</strong></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ Error</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}
?>