<?php
/**
 * Comprehensive MySQL Link Format Fix
 * Tüm sayfa linklerini MySQL formatına uygun hale getir
 */
require_once 'includes/config.php';
require_once 'includes/database.php';

session_start();

// Check if user is super admin
if (!isset($_SESSION['super_admin'])) {
    die("❌ Yetkisiz erişim! Sadece süper admin bu işlemi yapabilir.");
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🔧 Kapsamlı MySQL Link Formatı Düzeltmesi</h1>";
    echo "<div style='font-family: monospace; background: #f5f5f5; padding: 20px; border-radius: 5px;'>";
    
    // 1. Fix reports.php CONCAT error
    echo "<h3>1. reports.php CONCAT Hatası Düzeltiliyor...</h3>";
    $reports_file = 'admin/reports.php';
    if (file_exists($reports_file)) {
        $content = file_get_contents($reports_file);
        if (strpos($content, 'CONCAT($_SESSION[\'user_role\']') !== false) {
            $content = str_replace(
                'if (!isset($_SESSION[\'user_role\']) CONCAT($_SESSION[\'user_role\'] !== \'admin\' && $_SESSION[\'user_role\'] !== \'super_admin\')) {',
                'if (!isset($_SESSION[\'user_role\']) || ($_SESSION[\'user_role\'] !== \'admin\' && $_SESSION[\'user_role\'] !== \'super_admin\')) {',
                $content
            );
            file_put_contents($reports_file, $content);
            echo "✅ reports.php CONCAT hatası düzeltildi<br>";
        } else {
            echo "ℹ️ reports.php CONCAT hatası bulunamadı<br>";
        }
    }
    
    // 2. Check all PHP files for MySQL incompatible queries
    echo "<h3>2. MySQL Uyumsuz Sorgular Kontrol Ediliyor...</h3>";
    
    $phpFiles = [
        'admin/employee-management.php',
        'admin/attendance-tracking.php', 
        'admin/qr-generator.php',
        'admin/company-settings.php',
        'admin/work-settings.php',
        'admin/shift-management.php',
        'admin/leave-management.php',
        'admin/device-management.php',
        'admin/holiday-management.php',
        'admin/user-password-management.php',
        'admin/company-user-management.php',
        'dashboard/company-dashboard.php',
        'dashboard/employee-dashboard.php',
        'super-admin/index.php',
        'super-admin/company-management.php',
        'super-admin/system-health.php',
        'auth/company-login.php',
        'auth/employee-login.php',
        'employee/profile.php',
        'employee/attendance-records.php',
        'attendance/records.php',
        'reports/index.php',
        'reports/earnings-calculator.php'
    ];
    
    $fixedFiles = 0;
    $checkedFiles = 0;
    
    foreach ($phpFiles as $file) {
        if (!file_exists($file)) {
            echo "⚠️ $file - Dosya bulunamadı<br>";
            continue;
        }
        
        $content = file_get_contents($file);
        $originalContent = $content;
        $fileFixed = false;
        $checkedFiles++;
        
        echo "<strong>📂 $file kontrol ediliyor:</strong><br>";
        
        // Fix PostgreSQL style concatenation operator
        if (strpos($content, '||') !== false && strpos($content, 'CONCAT') === false) {
            $content = preg_replace('/(\w+)\s*\|\|\s*(\w+)/', 'CONCAT($1, $2)', $content);
            echo "&nbsp;&nbsp;✅ PostgreSQL concatenation (||) -> CONCAT() düzeltildi<br>";
            $fileFixed = true;
        }
        
        // Fix employee name queries - ensure using CONCAT(first_name, ' ', last_name)
        if (preg_match('/e\.(name|full_name)\b/', $content)) {
            $content = preg_replace('/e\.(name|full_name)\b/', "CONCAT(e.first_name, ' ', e.last_name)", $content);
            echo "&nbsp;&nbsp;✅ Employee name field -> CONCAT(first_name, ' ', last_name) düzeltildi<br>";
            $fileFixed = true;
        }
        
        // Fix SERIAL to AUTO_INCREMENT
        if (strpos($content, 'SERIAL') !== false) {
            $content = str_replace('SERIAL', 'INT AUTO_INCREMENT', $content);
            echo "&nbsp;&nbsp;✅ SERIAL -> INT AUTO_INCREMENT düzeltildi<br>";
            $fileFixed = true;
        }
        
        // Fix BOOLEAN to TINYINT(1)
        if (strpos($content, 'BOOLEAN') !== false) {
            $content = str_replace('BOOLEAN', 'TINYINT(1)', $content);
            echo "&nbsp;&nbsp;✅ BOOLEAN -> TINYINT(1) düzeltildi<br>";
            $fileFixed = true;
        }
        
        // Fix PostgreSQL cast syntax
        if (strpos($content, '::') !== false) {
            $content = preg_replace('/::[\w\(\)]+/', '', $content);
            echo "&nbsp;&nbsp;✅ PostgreSQL cast syntax kaldırıldı<br>";
            $fileFixed = true;
        }
        
        // Fix ILIKE to LIKE
        if (strpos($content, 'ILIKE') !== false) {
            $content = str_replace('ILIKE', 'LIKE', $content);
            echo "&nbsp;&nbsp;✅ ILIKE -> LIKE düzeltildi<br>";
            $fileFixed = true;
        }
        
        // Fix NOW() to NOW() or CURRENT_TIMESTAMP
        if (strpos($content, 'NOW()') !== false && strpos($content, 'CURRENT_TIMESTAMP') === false) {
            // MySQL supports NOW(), so this is fine, but check for PostgreSQL specific usage
            echo "&nbsp;&nbsp;ℹ️ NOW() kullanımı kontrol edildi (MySQL uyumlu)<br>";
        }
        
        // Fix LIMIT without OFFSET issues
        if (preg_match('/LIMIT\s+(\d+)\s+OFFSET\s+(\d+)/', $content)) {
            $content = preg_replace('/LIMIT\s+(\d+)\s+OFFSET\s+(\d+)/', 'LIMIT $2, $1', $content);
            echo "&nbsp;&nbsp;✅ LIMIT OFFSET -> LIMIT offset, count düzeltildi<br>";
            $fileFixed = true;
        }
        
        // Check for reserved words that might need escaping
        $reservedWords = ['order', 'group', 'key', 'table', 'column', 'index'];
        foreach ($reservedWords as $word) {
            if (preg_match('/\b' . $word . '\s*=/', $content) && !preg_match('/`' . $word . '`/', $content)) {
                echo "&nbsp;&nbsp;⚠️ Reserved word '$word' found - manual review needed<br>";
            }
        }
        
        if ($fileFixed) {
            file_put_contents($file, $content);
            $fixedFiles++;
            echo "&nbsp;&nbsp;💾 Dosya güncellendi<br>";
        } else {
            echo "&nbsp;&nbsp;✅ MySQL uyumlu<br>";
        }
        
        echo "<br>";
    }
    
    // 3. Check for broken links in navigation files
    echo "<h3>3. Navigasyon Linkleri Kontrol Ediliyor...</h3>";
    
    $navigationFiles = [
        'admin/index.php',
        'dashboard/company-dashboard.php',
        'super-admin/index.php'
    ];
    
    foreach ($navigationFiles as $file) {
        if (file_exists($file)) {
            $content = file_get_contents($file);
            echo "<strong>📂 $file link kontrolü:</strong><br>";
            
            // Check for broken relative paths
            if (preg_match_all('/href=["\']([^"\']+\.php)["\']/', $content, $matches)) {
                foreach ($matches[1] as $link) {
                    $linkPath = dirname($file) . '/' . $link;
                    $linkPath = realpath($linkPath);
                    if (!$linkPath || !file_exists($linkPath)) {
                        echo "&nbsp;&nbsp;⚠️ Broken link found: $link<br>";
                    }
                }
            }
            echo "&nbsp;&nbsp;✅ Link kontrolü tamamlandı<br>";
        }
    }
    
    // 4. Database table structure check
    echo "<h3>4. Veritabanı Tablo Yapısı Kontrol Ediliyor...</h3>";
    
    // Check critical tables
    $criticalTables = [
        'companies',
        'employees', 
        'attendance_records',
        'qr_locations',
        'users',
        'departments'
    ];
    
    foreach ($criticalTables as $table) {
        try {
            $stmt = $conn->query("SHOW COLUMNS FROM `$table`");
            $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo "✅ Tablo `$table` mevcut (" . count($columns) . " sütun)<br>";
            
            // Check for specific column issues
            if ($table === 'employees') {
                $hasFirstName = false;
                $hasLastName = false;
                foreach ($columns as $col) {
                    if ($col['Field'] === 'first_name') $hasFirstName = true;
                    if ($col['Field'] === 'last_name') $hasLastName = true;
                }
                if (!$hasFirstName || !$hasLastName) {
                    echo "&nbsp;&nbsp;⚠️ employees tablosunda first_name/last_name sütunları eksik<br>";
                }
            }
            
        } catch (Exception $e) {
            echo "❌ Tablo `$table` kontrol hatası: " . $e->getMessage() . "<br>";
        }
    }
    
    // Summary
    echo "<h3>📊 İşlem Özeti</h3>";
    echo "<div style='background: white; padding: 15px; border: 1px solid #ddd; border-radius: 5px;'>";
    echo "<strong>Kontrol Edilen Dosyalar:</strong> $checkedFiles<br>";
    echo "<strong>Düzeltilen Dosyalar:</strong> $fixedFiles<br>";
    echo "<strong>Durum:</strong> " . ($fixedFiles > 0 ? "✅ Düzeltmeler yapıldı" : "✅ Tüm linkler MySQL uyumlu") . "<br>";
    echo "</div>";
    
    echo "<br><h3>🔄 Önerilen Sonraki Adımlar:</h3>";
    echo "<ul>";
    echo "<li>1. Tüm sayfalarda test işlemleri yapın</li>";
    echo "<li>2. QR kod okutma sistemini test edin</li>";
    echo "<li>3. Personel giriş/çıkış kayıtlarını kontrol edin</li>";
    echo "<li>4. Rapor sayfalarının düzgün çalıştığını doğrulayın</li>";
    echo "</ul>";
    
    echo "</div>";
    
    echo "<br><a href='super-admin/' class='bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700' style='text-decoration: none; padding: 10px 15px; background: #3b82f6; color: white; border-radius: 5px;'>← Süper Admin'e Dön</a>";
    
} catch (Exception $e) {
    echo "<div style='color: #721c24; background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ Hata: " . $e->getMessage();
    echo "</div>";
}
?>