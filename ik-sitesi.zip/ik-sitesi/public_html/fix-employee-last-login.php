<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>🔧 Employee Last Login Column Fixer</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { background: white; padding: 20px; border-radius: 8px; max-width: 800px; }
        .success { color: green; }
        .error { color: red; }
        .info { color: blue; }
        .warning { color: orange; }
        pre { background: #f8f8f8; padding: 10px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
<div class="container">
<h1>🔧 Employee Last Login Column Fixer</h1>

<?php
try {
    $db = new Database();
    $conn = $db->getConnection();
    echo "<p class='success'>✅ Connected to MySQL database successfully!</p>";
    
    echo "<h3>📋 Checking employees table structure...</h3>";
    
    // Get table structure
    $stmt = $conn->query("DESCRIBE employees");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p class='info'>Current columns:</p><pre>";
    $hasLastLogin = false;
    foreach ($columns as $column) {
        echo "  - {$column['Field']} ({$column['Type']})\n";
        if ($column['Field'] === 'last_login') {
            $hasLastLogin = true;
        }
    }
    echo "</pre>";
    
    if ($hasLastLogin) {
        echo "<p class='success'>✅ 'last_login' column already exists!</p>";
    } else {
        echo "<p class='warning'>❌ 'last_login' column is missing!</p>";
        echo "<p class='info'>➕ Adding 'last_login' column now...</p>";
        
        try {
            $conn->exec("ALTER TABLE employees ADD COLUMN last_login DATETIME NULL");
            echo "<p class='success'>✅ 'last_login' column added successfully!</p>";
        } catch (Exception $e) {
            echo "<p class='error'>❌ Failed to add column: " . $e->getMessage() . "</p>";
        }
    }
    
    // Verify column addition
    echo "<h3>🔍 Verifying column addition...</h3>";
    $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'last_login'");
    $column = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($column) {
        echo "<p class='success'>✅ 'last_login' column confirmed: {$column['Type']}</p>";
    } else {
        echo "<p class='error'>❌ 'last_login' column still missing!</p>";
    }
    
    // Test SELECT with last_login
    echo "<h3>🧪 Testing SELECT with last_login column...</h3>";
    try {
        $stmt = $conn->prepare("SELECT id, first_name, last_name, last_login FROM employees LIMIT 1");
        $stmt->execute();
        $testResult = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($testResult) {
            echo "<p class='success'>✅ SELECT test successful!</p>";
            echo "<pre>";
            foreach ($testResult as $key => $value) {
                echo "$key: " . ($value ?? 'NULL') . "\n";
            }
            echo "</pre>";
        } else {
            echo "<p class='warning'>⚠️ No employees found to test with.</p>";
        }
    } catch (Exception $e) {
        echo "<p class='error'>❌ Test failed: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Database connection failed: " . $e->getMessage() . "</p>";
}
?>

<h3>ℹ️ What does this script do?</h3>
<ul>
    <li>Connects to your MySQL database</li>
    <li>Checks if the 'last_login' column exists in employees table</li>
    <li>If missing, adds the column automatically</li>
    <li>Tests that the column works correctly</li>
</ul>

<p><a href="index.php">← Back to Home</a></p>
</div>
</body>
</html>