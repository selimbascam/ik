<?php
// Redirect to employee management
header("Location: ../admin/employee-management.php");
exit;
?>