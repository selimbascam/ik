<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div style='max-width: 1000px; margin: 20px auto; font-family: Arial, sans-serif;'>";
    echo "<h1 style='background: #4CAF50; color: white; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>🔧 MySQL Veritabanı Kurulum & Güncelleme</h1>";
    echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";
    
    echo "<p><strong>Sistem MySQL Development Veritabanına Göre Yapılandırılıyor...</strong></p>";
    
    // 1. Create shift_templates table (MySQL syntax)
    echo "<h2>1️⃣ Shift Templates Tablosu (MySQL)</h2>";
    try {
        $stmt = $conn->prepare("
            CREATE TABLE IF NOT EXISTS shift_templates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                name VARCHAR(100) NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                break_duration INT DEFAULT 0 COMMENT 'Minutes',
                is_active BOOLEAN DEFAULT 1,
                color_code VARCHAR(7) DEFAULT '#3B82F6',
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_company_active (company_id, is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $stmt->execute();
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ shift_templates tablosu oluşturuldu";
        echo "</div>";
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ shift_templates tablosu hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    // 2. Insert default shift templates
    echo "<h2>2️⃣ Varsayılan Vardiya Şablonları</h2>";
    try {
        $defaultShifts = [
            ['Sabah Vardiyası', '08:00:00', '17:00:00', 60, '#3B82F6', 'Standart sabah vardiyası (8:00-17:00, 1 saat mola)'],
            ['Öğle Vardiyası', '12:00:00', '21:00:00', 60, '#10B981', 'Öğle vardiyası (12:00-21:00, 1 saat mola)'],
            ['Gece Vardiyası', '22:00:00', '06:00:00', 30, '#8B5CF6', 'Gece vardiyası (22:00-06:00, 30 dk mola)'],
            ['Yarım Gün', '08:00:00', '13:00:00', 30, '#F59E0B', 'Yarım gün çalışma (8:00-13:00, 30 dk mola)'],
            ['Esnek Çalışma', '09:00:00', '18:00:00', 60, '#EF4444', 'Esnek çalışma saatleri (9:00-18:00, 1 saat mola)']
        ];

        foreach ($defaultShifts as $shift) {
            $stmt = $conn->prepare("
                INSERT IGNORE INTO shift_templates (company_id, name, start_time, end_time, break_duration, color_code, description)
                VALUES (1, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute($shift);
        }
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ 5 adet varsayılan vardiya şablonu eklendi";
        echo "</div>";
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Varsayılan şablonlar hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    // 3. Update employee_shifts table (MySQL syntax)
    echo "<h2>3️⃣ Employee Shifts Tablosu Güncelleme</h2>";
    try {
        // Add shift_template_id column
        $stmt = $conn->prepare("
            ALTER TABLE employee_shifts 
            ADD COLUMN IF NOT EXISTS shift_template_id INT,
            ADD COLUMN IF NOT EXISTS shift_date DATE,
            ADD COLUMN IF NOT EXISTS actual_start_time TIME,
            ADD COLUMN IF NOT EXISTS actual_end_time TIME,
            ADD COLUMN IF NOT EXISTS late_reason TEXT,
            ADD COLUMN IF NOT EXISTS early_leave_reason TEXT,
            ADD COLUMN IF NOT EXISTS absence_reason TEXT,
            ADD COLUMN IF NOT EXISTS break_minutes INT DEFAULT 0,
            ADD COLUMN IF NOT EXISTS worked_minutes INT DEFAULT 0,
            ADD COLUMN IF NOT EXISTS overtime_minutes INT DEFAULT 0,
            ADD COLUMN IF NOT EXISTS is_complete BOOLEAN DEFAULT 0,
            ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ");
        $stmt->execute();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ employee_shifts tablosu güncellendi";
        echo "</div>";
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ employee_shifts güncelleme hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    // 4. Add is_active column to employees table
    echo "<h2>4️⃣ Employees Tablosu is_active Sütunu</h2>";
    try {
        $stmt = $conn->prepare("ALTER TABLE employees ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT 1");
        $stmt->execute();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ employees tablosuna is_active sütunu eklendi";
        echo "</div>";
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ employees is_active hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    // 5. Create monthly_work_summary table (MySQL syntax)
    echo "<h2>5️⃣ Monthly Work Summary Tablosu (MySQL)</h2>";
    try {
        $stmt = $conn->prepare("
            CREATE TABLE IF NOT EXISTS monthly_work_summary (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                work_year YEAR NOT NULL,
                work_month TINYINT NOT NULL,
                total_scheduled_hours DECIMAL(6,2) DEFAULT 0,
                total_worked_hours DECIMAL(6,2) DEFAULT 0,
                total_overtime_hours DECIMAL(6,2) DEFAULT 0,
                total_break_hours DECIMAL(6,2) DEFAULT 0,
                total_late_minutes INT DEFAULT 0,
                total_early_leave_minutes INT DEFAULT 0,
                days_present INT DEFAULT 0,
                days_absent INT DEFAULT 0,
                days_late INT DEFAULT 0,
                days_early_leave INT DEFAULT 0,
                base_salary DECIMAL(10,2),
                overtime_rate DECIMAL(4,2) DEFAULT 1.5,
                calculated_salary DECIMAL(10,2),
                bonus_amount DECIMAL(10,2) DEFAULT 0,
                penalty_amount DECIMAL(10,2) DEFAULT 0,
                final_salary DECIMAL(10,2),
                is_finalized BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_employee_month (employee_id, work_year, work_month),
                INDEX idx_employee_period (employee_id, work_year, work_month),
                FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $stmt->execute();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ monthly_work_summary tablosu oluşturuldu";
        echo "</div>";
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ monthly_work_summary hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    // 6. Check database status
    echo "<h2>6️⃣ Veritabanı Durum Kontrolü</h2>";
    try {
        // Check shift_templates
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM shift_templates");
        $stmt->execute();
        $shiftCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Check employees
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE is_active = 1");
        $stmt->execute();
        $employeeCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Check monthly_work_summary
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM monthly_work_summary");
        $stmt->execute();
        $summaryCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        echo "<div style='background: #e7f3ff; color: #0056b3; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h3>📊 Veritabanı İstatistikleri:</h3>";
        echo "<ul>";
        echo "<li><strong>Vardiya Şablonları:</strong> {$shiftCount} adet</li>";
        echo "<li><strong>Aktif Personel:</strong> {$employeeCount} adet</li>";
        echo "<li><strong>Maaş Kayıtları:</strong> {$summaryCount} adet</li>";
        echo "</ul>";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Durum kontrolü hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    echo "<h2>✅ MySQL Veritabanı Kurulumu Tamamlandı!</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>🎯 Sistem Özellikleri (MySQL Development):</h3>";
    echo "<ul>";
    echo "<li>✅ Vardiya şablonları sistemi (MySQL AUTO_INCREMENT)</li>";
    echo "<li>✅ Personel vardiya atama sistemi</li>";
    echo "<li>✅ Bordro hesaplama sistemi (225 saat/ay esası)</li>";
    echo "<li>✅ Kullanıcı şifre yönetimi (basitleştirilmiş)</li>";
    echo "<li>✅ MySQL uyumlu veri tipleri ve yapılar</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='admin/shift-management.php' style='background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🕒 Vardiya Yönetimi</a>";
    echo "<a href='api/calculate-monthly-summary.php' style='background: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>💰 Bordro Hesaplama</a>";
    echo "<a href='admin/user-password-management.php' style='background: #FF9800; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🔐 Şifre Yönetimi</a>";
    echo "</div>";
    
    echo "</div>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Kurulum Hatası</h3>";
    echo "Hata: " . $e->getMessage();
    echo "</div>";
}
?>