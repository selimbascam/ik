<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔍 Personel QR Sistemi - Kapsamlı Veritabanı Validasyonu</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>1. Core Tabloların Varlığı ve Yapısı</h3>";
    
    $requiredTables = [
        'employees' => [
            'purpose' => 'Personel bilgileri',
            'required_columns' => ['id', 'employee_number', 'password', 'first_name', 'last_name', 'company_id'],
            'optional_columns' => ['tc_no', 'email', 'phone', 'department_id', 'is_active', 'created_at']
        ],
        'attendance_records' => [
            'purpose' => 'QR devam kayıtları',
            'required_columns' => ['id', 'employee_id', 'qr_location_id', 'activity_type', 'check_in_time'],
            'optional_columns' => ['latitude', 'longitude', 'notes', 'created_at', 'date', 'check_date']
        ],
        'qr_locations' => [
            'purpose' => 'QR kod lokasyonları',
            'required_columns' => ['id', 'company_id', 'name', 'latitude', 'longitude'],
            'optional_columns' => ['gate_behavior', 'qr_code_data', 'is_active', 'description', 'created_at']
        ],
        'companies' => [
            'purpose' => 'Şirket bilgileri',
            'required_columns' => ['id', 'company_name'],
            'optional_columns' => ['company_code', 'email', 'phone', 'address', 'created_at']
        ]
    ];
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Tablo</th><th>Amaç</th><th>Durum</th><th>Eksik Kolonlar</th></tr>";
    
    $allTablesValid = true;
    
    foreach ($requiredTables as $tableName => $tableInfo) {
        try {
            $stmt = $conn->query("SHOW TABLES LIKE '$tableName'");
            $tableExists = $stmt->rowCount() > 0;
            
            if ($tableExists) {
                $stmt = $conn->query("SHOW COLUMNS FROM $tableName");
                $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                $missingColumns = [];
                foreach ($tableInfo['required_columns'] as $reqCol) {
                    if (!in_array($reqCol, $columns)) {
                        $missingColumns[] = $reqCol;
                        $allTablesValid = false;
                    }
                }
                
                $status = empty($missingColumns) ? '✅ TAM' : '⚠️ EKSİK';
                $missingText = empty($missingColumns) ? '-' : implode(', ', $missingColumns);
                
                echo "<tr>";
                echo "<td><strong>$tableName</strong></td>";
                echo "<td>" . $tableInfo['purpose'] . "</td>";
                echo "<td>$status</td>";
                echo "<td>$missingText</td>";
                echo "</tr>";
                
            } else {
                echo "<tr>";
                echo "<td><strong>$tableName</strong></td>";
                echo "<td>" . $tableInfo['purpose'] . "</td>";
                echo "<td>❌ YOK</td>";
                echo "<td>Tablo mevcut değil</td>";
                echo "</tr>";
                $allTablesValid = false;
            }
            
        } catch (Exception $e) {
            echo "<tr>";
            echo "<td><strong>$tableName</strong></td>";
            echo "<td>" . $tableInfo['purpose'] . "</td>";
            echo "<td>❌ HATA</td>";
            echo "<td>" . $e->getMessage() . "</td>";
            echo "</tr>";
            $allTablesValid = false;
        }
    }
    echo "</table>";
    
    echo "<h3>2. Attendance Records Tablo Detay Analizi</h3>";
    
    try {
        $stmt = $conn->query("SHOW CREATE TABLE attendance_records");
        $createTable = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<h4>Mevcut Tablo Yapısı:</h4>";
        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 5px; font-size: 11px; max-height: 300px; overflow: auto;'>";
        echo htmlspecialchars($createTable['Create Table']);
        echo "</pre>";
        
        // Analyze column types
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>Kolon Detayları:</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Kolon</th><th>Tip</th><th>Null</th><th>Default</th><th>Önerilen Düzeltme</th></tr>";
        
        foreach ($columns as $col) {
            $colName = $col['Field'];
            $colType = $col['Type'];
            $nullable = $col['Null'];
            $default = $col['Default'] ?? 'NULL';
            
            $suggestion = '';
            
            // Check specific columns for proper types
            switch ($colName) {
                case 'activity_type':
                    if (strpos($colType, 'enum') === false) {
                        $suggestion = "ENUM('work_start', 'work_end', 'break_start', 'break_end') olmalı";
                    }
                    break;
                case 'latitude':
                    if (strpos($colType, 'decimal') === false) {
                        $suggestion = "DECIMAL(10,8) olmalı";
                    }
                    break;
                case 'longitude':
                    if (strpos($colType, 'decimal') === false) {
                        $suggestion = "DECIMAL(11,8) olmalı";
                    }
                    break;
                case 'check_in_time':
                    if (strpos($colType, 'datetime') === false) {
                        $suggestion = "DATETIME olmalı";
                    }
                    break;
                case 'date':
                case 'check_date':
                    if (strpos($colType, 'date') === false) {
                        $suggestion = "DATE olmalı";
                    }
                    break;
            }
            
            echo "<tr>";
            echo "<td><strong>$colName</strong></td>";
            echo "<td>$colType</td>";
            echo "<td>$nullable</td>";
            echo "<td>$default</td>";
            echo "<td>" . ($suggestion ?: '✅ OK') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
    } catch (Exception $e) {
        echo "<p>❌ Attendance records analiz hatası: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>3. Test Personeli ve Verilerinin Kontrolü</h3>";
    
    $testEmployeeNumber = '30716129672';
    
    // Get test employee
    $stmt = $conn->prepare("
        SELECT e.*, c.company_name 
        FROM employees e 
        LEFT JOIN companies c ON e.company_id = c.id 
        WHERE e.employee_number = ?
    ");
    $stmt->execute([$testEmployeeNumber]);
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testEmployee) {
        echo "<h4>Test Personeli Bilgileri:</h4>";
        echo "<div style='background: #e7f3ff; padding: 15px; border-radius: 5px;'>";
        echo "<p><strong>Adı:</strong> " . htmlspecialchars($testEmployee['first_name'] . ' ' . $testEmployee['last_name']) . "</p>";
        echo "<p><strong>Employee Number:</strong> " . htmlspecialchars($testEmployee['employee_number']) . "</p>";
        echo "<p><strong>Şirket:</strong> " . htmlspecialchars($testEmployee['company_name'] ?? 'Bilinmiyor') . "</p>";
        echo "<p><strong>ID:</strong> " . $testEmployee['id'] . "</p>";
        echo "<p><strong>Company ID:</strong> " . $testEmployee['company_id'] . "</p>";
        echo "</div>";
        
        // Check QR locations for this company
        $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? AND is_active = 1");
        $stmt->execute([$testEmployee['company_id']]);
        $qrLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>Şirket QR Lokasyonları (" . count($qrLocations) . " adet):</h4>";
        
        if (!empty($qrLocations)) {
            echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr><th>ID</th><th>Adı</th><th>GPS</th><th>Gate Behavior</th><th>Durum</th></tr>";
            
            foreach ($qrLocations as $location) {
                $gps = $location['latitude'] . ', ' . $location['longitude'];
                $gateBehavior = $location['gate_behavior'] ?? 'user_choice';
                
                echo "<tr>";
                echo "<td>" . $location['id'] . "</td>";
                echo "<td>" . htmlspecialchars($location['name']) . "</td>";
                echo "<td>$gps</td>";
                echo "<td>$gateBehavior</td>";
                echo "<td>✅ Aktif</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>❌ Bu şirket için QR lokasyon bulunamadı</p>";
        }
        
        // Check attendance records for test employee
        $stmt = $conn->prepare("
            SELECT 
                ar.*,
                ql.name as location_name,
                ql.gate_behavior,
                DATE(ar.check_in_time) as record_date,
                TIME(ar.check_in_time) as record_time
            FROM attendance_records ar 
            LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
            WHERE ar.employee_id = ? 
            ORDER BY ar.check_in_time DESC 
            LIMIT 10
        ");
        $stmt->execute([$testEmployee['id']]);
        $attendanceRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>Son 10 Devam Kaydı:</h4>";
        
        if (!empty($attendanceRecords)) {
            echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr><th>Tarih</th><th>Saat</th><th>Aktivite</th><th>Lokasyon</th><th>GPS</th><th>Notlar</th></tr>";
            
            foreach ($attendanceRecords as $record) {
                $hasGPS = !empty($record['latitude']) && !empty($record['longitude']);
                $gpsText = $hasGPS ? '✅' : '❌';
                
                echo "<tr>";
                echo "<td>" . $record['record_date'] . "</td>";
                echo "<td>" . $record['record_time'] . "</td>";
                echo "<td>" . htmlspecialchars($record['activity_type']) . "</td>";
                echo "<td>" . htmlspecialchars($record['location_name'] ?? 'Bilinmiyor') . "</td>";
                echo "<td>$gpsText</td>";
                echo "<td>" . htmlspecialchars(substr($record['notes'] ?? '', 0, 30)) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>❌ Bu personel için devam kaydı bulunamadı</p>";
        }
        
    } else {
        echo "<p>❌ Test personeli ($testEmployeeNumber) bulunamadı</p>";
    }
    
    echo "<h3>4. QR Attendance İş Akışı Simülasyonu</h3>";
    
    if ($testEmployee && !empty($qrLocations)) {
        echo "<h4>Gerçek QR Kayıt Testi:</h4>";
        
        $testLocation = $qrLocations[0]; // Use first available location
        $today = date('Y-m-d');
        
        // Check today's last record to determine next activity
        $stmt = $conn->prepare("
            SELECT * FROM attendance_records 
            WHERE employee_id = ? AND date = ? 
            ORDER BY check_in_time DESC 
            LIMIT 1
        ");
        $stmt->execute([$testEmployee['id'], $today]);
        $lastRecord = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Determine next activity based on gate behavior
        $nextActivity = 'work_start'; // Default
        
        switch ($testLocation['gate_behavior']) {
            case 'work_start':
                $nextActivity = 'work_start';
                break;
            case 'work_end':
                $nextActivity = 'work_end';
                break;
            case 'break_toggle':
                $nextActivity = ($lastRecord && $lastRecord['activity_type'] === 'break_start') ? 'break_end' : 'break_start';
                break;
            case 'user_choice':
                if (!$lastRecord || $lastRecord['activity_type'] === 'work_end') {
                    $nextActivity = 'work_start';
                } else {
                    $nextActivity = 'work_end';
                }
                break;
        }
        
        echo "<p><strong>Test Bilgileri:</strong></p>";
        echo "<ul>";
        echo "<li>Lokasyon: " . htmlspecialchars($testLocation['name']) . "</li>";
        echo "<li>Gate Behavior: " . $testLocation['gate_behavior'] . "</li>";
        echo "<li>Son kayıt: " . ($lastRecord ? $lastRecord['activity_type'] : 'Yok') . "</li>";
        echo "<li>Belirlenen aktivite: $nextActivity</li>";
        echo "</ul>";
        
        // Create test record
        try {
            $testTime = date('Y-m-d H:i:s');
            
            // Check columns before insert
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $hasGPS = in_array('latitude', $columns) && in_array('longitude', $columns);
            
            if ($hasGPS) {
                $insertQuery = "
                    INSERT INTO attendance_records 
                    (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, 
                     notes, created_at, date, check_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)
                ";
                $params = [
                    $testEmployee['id'],
                    $testLocation['id'],
                    $nextActivity,
                    $testTime,
                    $testLocation['latitude'],
                    $testLocation['longitude'],
                    "Veritabanı validasyon testi - " . $testLocation['name'],
                    $today,
                    $today
                ];
            } else {
                $insertQuery = "
                    INSERT INTO attendance_records 
                    (employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date, check_date) 
                    VALUES (?, ?, ?, ?, ?, NOW(), ?, ?)
                ";
                $params = [
                    $testEmployee['id'],
                    $testLocation['id'],
                    $nextActivity,
                    $testTime,
                    "Veritabanı validasyon testi - " . $testLocation['name'] . " (GPS yok)",
                    $today,
                    $today
                ];
            }
            
            $stmt = $conn->prepare($insertQuery);
            $result = $stmt->execute($params);
            
            if ($result) {
                $newRecordId = $conn->lastInsertId();
                echo "<p>✅ Test kayıt başarıyla oluşturuldu (ID: $newRecordId)</p>";
                
                // Verify the record
                $stmt = $conn->prepare("
                    SELECT ar.*, ql.name as location_name 
                    FROM attendance_records ar 
                    LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
                    WHERE ar.id = ?
                ");
                $stmt->execute([$newRecordId]);
                $newRecord = $stmt->fetch(PDO::FETCH_ASSOC);
                
                echo "<h5>Oluşturulan Kayıt Detayları:</h5>";
                echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
                echo "<tr><th>Alanlar</th><th>Değer</th></tr>";
                
                $importantFields = ['id', 'employee_id', 'qr_location_id', 'activity_type', 'check_in_time', 'latitude', 'longitude', 'notes', 'date'];
                
                foreach ($importantFields as $field) {
                    $value = $newRecord[$field] ?? 'NULL';
                    echo "<tr>";
                    echo "<td><strong>$field</strong></td>";
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
                
            } else {
                echo "<p>❌ Test kayıt oluşturulamadı</p>";
            }
            
        } catch (Exception $e) {
            echo "<p>❌ Test kayıt hatası: " . $e->getMessage() . "</p>";
        }
        
    } else {
        echo "<p>❌ Test personeli veya QR lokasyon eksik - simülasyon yapılamadı</p>";
    }
    
    echo "<h3>5. Sistem Performans ve İndex Kontrolü</h3>";
    
    try {
        $stmt = $conn->query("SHOW INDEX FROM attendance_records");
        $indexes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>Mevcut İndeksler:</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Tablo</th><th>İndeks Adı</th><th>Kolon</th><th>Benzersiz</th></tr>";
        
        foreach ($indexes as $index) {
            $isUnique = $index['Non_unique'] == 0 ? '✅' : '❌';
            echo "<tr>";
            echo "<td>" . $index['Table'] . "</td>";
            echo "<td>" . $index['Key_name'] . "</td>";
            echo "<td>" . $index['Column_name'] . "</td>";
            echo "<td>$isUnique</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Recommend missing indexes
        $recommendedIndexes = [
            "idx_employee_date" => "attendance_records(employee_id, date)",
            "idx_activity_type" => "attendance_records(activity_type)",
            "idx_check_in_time" => "attendance_records(check_in_time)",
            "idx_qr_location" => "attendance_records(qr_location_id)"
        ];
        
        $existingIndexNames = array_column($indexes, 'Key_name');
        
        echo "<h4>Önerilen İndeksler:</h4>";
        echo "<ul>";
        foreach ($recommendedIndexes as $indexName => $indexDef) {
            $exists = in_array($indexName, $existingIndexNames);
            $status = $exists ? '✅ Mevcut' : '⚠️ Önerilir';
            echo "<li>$indexDef - $status</li>";
        }
        echo "</ul>";
        
    } catch (Exception $e) {
        echo "<p>⚠️ İndeks kontrolü yapılamadı: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>6. Final Sistem Durumu Raporu</h3>";
    
    // Generate comprehensive status
    $systemChecks = [
        "Employees tablo" => "SELECT COUNT(*) as count FROM employees",
        "QR Locations tablo" => "SELECT COUNT(*) as count FROM qr_locations WHERE is_active = 1",
        "Attendance Records tablo" => "SELECT COUNT(*) as count FROM attendance_records",
        "Bugünkü kayıtlar" => "SELECT COUNT(*) as count FROM attendance_records WHERE date = CURDATE()",
        "GPS koordinatlı kayıtlar" => "SELECT COUNT(*) as count FROM attendance_records WHERE latitude IS NOT NULL",
        "Activity type belirtilmiş kayıtlar" => "SELECT COUNT(*) as count FROM attendance_records WHERE activity_type IS NOT NULL"
    ];
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Kontrol</th><th>Sayı</th><th>Durum</th></tr>";
    
    $allChecksPass = true;
    
    foreach ($systemChecks as $checkName => $query) {
        try {
            $stmt = $conn->query($query);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $count = $result['count'];
            
            $status = "✅ OK";
            if (strpos($checkName, 'Activity type') !== false && $count == 0) {
                $status = "⚠️ Dikkat";
                $allChecksPass = false;
            }
            
            echo "<tr>";
            echo "<td>$checkName</td>";
            echo "<td>$count</td>";
            echo "<td>$status</td>";
            echo "</tr>";
            
        } catch (Exception $e) {
            echo "<tr>";
            echo "<td>$checkName</td>";
            echo "<td>HATA</td>";
            echo "<td>❌ " . substr($e->getMessage(), 0, 50) . "</td>";
            echo "</tr>";
            $allChecksPass = false;
        }
    }
    echo "</table>";
    
    echo "<h3>✅ Veritabanı Validasyon Tamamlandı</h3>";
    
    $overallStatus = $allTablesValid && $allChecksPass ? 'BAŞARILI' : 'DİKKAT GEREKİYOR';
    $bgColor = $overallStatus === 'BAŞARILI' ? '#d4edda' : '#fff3cd';
    
    echo "<div style='background: $bgColor; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>🎯 Genel Sistem Durumu: $overallStatus</h4>";
    echo "<ul>";
    echo "<li>✅ Core tablolar kontrol edildi</li>";
    echo "<li>✅ Attendance records yapısı analiz edildi</li>";
    echo "<li>✅ Test personeli ve veriler kontrol edildi</li>";
    echo "<li>✅ QR iş akışı test edildi</li>";
    echo "<li>✅ Performans indeksleri incelendi</li>";
    echo "<li>✅ Sistem durumu raporlandı</li>";
    echo "</ul>";
    
    echo "<h4>Test Bilgileri:</h4>";
    echo "<p>Employee Number: $testEmployeeNumber</p>";
    echo "<p>Test Sayfaları:</p>";
    echo "<ul>";
    echo "<li><a href='employee/qr-attendance.php'>Employee QR Attendance</a></li>";
    echo "<li><a href='database-structure-fix.php'>Database Structure Fix</a></li>";
    echo "<li><a href='qr-attendance-record-fix.php'>QR Record Fix</a></li>";
    echo "</ul>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Sistem Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { margin: 10px 0; border-collapse: collapse; width: 100%; }";
echo "th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }";
echo "th { background-color: #f8f9fa; font-weight: bold; }";
echo "pre { font-size: 11px; max-height: 300px; overflow: auto; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "h3 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-top: 30px; }";
echo "</style>";
?>