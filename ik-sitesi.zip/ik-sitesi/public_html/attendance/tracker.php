<?php
header("Location: records.php");
exit;
?>