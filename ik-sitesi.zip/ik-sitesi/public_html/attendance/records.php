<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/holiday-calculator.php';

// Create attendance directory if it doesn't exist
if (!is_dir('../attendance')) {
    mkdir('../attendance', 0755, true);
}

// Check if user is logged in as employee
if (!isset($_SESSION['employee_id'])) {
    header('Location: /ik/auth/employee-login.php');
    exit;
}

$employeeId = $_GET['employee_id'] ?? $_SESSION['employee_id'];
$dateFilter = $_GET['date'] ?? date('Y-m-d');
$message = '';
$messageType = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get employee details
    $stmt = $conn->prepare("
        SELECT e.*, c.company_name 
        FROM employees e 
        JOIN companies c ON e.company_id = c.id 
        WHERE e.id = ?
    ");
    $stmt->execute([$employeeId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        throw new Exception("Personel bulunamadı");
    }
    
    // Get attendance records for the date
    $stmt = $conn->prepare("
        SELECT 
            ar.*,
            ql.name as location_name,
            ql.location_code,
            ar.activity_type,
            '#007bff' as color_code,
            DATE_FORMAT(ar.check_in_time, '%H:%i:%s') as time_formatted,
            DATE_FORMAT(ar.check_in_time, '%Y-%m-%d') as date_formatted,
            CASE 
                WHEN ar.activity_type = 'work_in' THEN 'İş Giriş'
                WHEN ar.activity_type = 'work_out' THEN 'İş Çıkış'
                WHEN ar.activity_type = 'break_start' THEN 'Mola Başlangıcı'
                WHEN ar.activity_type = 'break_end' THEN 'Mola Bitişi'
                WHEN ar.activity_type = 'meal_start' THEN 'Öğle Yemeği'
                WHEN ar.activity_type = 'meal_end' THEN 'Yemek Dönüş'
                ELSE ar.activity_type
            END as activity_name
        FROM attendance_records ar
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ? 
        AND DATE(ar.check_in_time) = ?
        ORDER BY ar.check_in_time ASC
    ");
    $stmt->execute([$employeeId, $dateFilter]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate work summary
    $workStartTime = null;
    $workEndTime = null;
    $breakTimes = [];
    $totalWorkMinutes = 0;
    $totalBreakMinutes = 0;
    
    foreach ($records as $record) {
        $time = strtotime($record['check_in_time']);
        
        switch ($record['activity_type']) {
            case 'work_in':
                if (!$workStartTime) $workStartTime = $time;
                break;
            case 'work_out':
                $workEndTime = $time;
                break;
            case 'break_start':
            case 'lunch_start':
                $breakTimes[] = ['start' => $time, 'type' => $record['activity_type']];
                break;
            case 'break_end':
            case 'lunch_end':
                // Find matching break start
                for ($i = count($breakTimes) - 1; $i >= 0; $i--) {
                    if (!isset($breakTimes[$i]['end'])) {
                        $breakTimes[$i]['end'] = $time;
                        $breakTimes[$i]['duration'] = ($time - $breakTimes[$i]['start']) / 60;
                        $totalBreakMinutes += $breakTimes[$i]['duration'];
                        break;
                    }
                }
                break;
        }
    }
    
    // Calculate total work time
    if ($workStartTime && $workEndTime) {
        $totalMinutes = ($workEndTime - $workStartTime) / 60;
        $totalWorkMinutes = $totalMinutes - $totalBreakMinutes;
    } elseif ($workStartTime) {
        // Still working
        $totalMinutes = (time() - $workStartTime) / 60;
        $totalWorkMinutes = $totalMinutes - $totalBreakMinutes;
    }
    
    // Get work settings for earnings calculation (with error handling)
    $workSettings = [
        'hourly_rate' => 50.00,
        'overtime_multiplier' => 1.5,
        'holiday_multiplier' => 2.0,
        'weekly_hours' => 45
    ];
    
    try {
        $stmt = $conn->prepare("SELECT * FROM work_settings WHERE company_id = ?");
        $stmt->execute([$employee['company_id']]);
        $dbSettings = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($dbSettings) {
            $workSettings = array_merge($workSettings, $dbSettings);
        }
    } catch (PDOException $e) {
        // Work settings table doesn't exist or has issues, use defaults
        error_log("Work settings query failed: " . $e->getMessage());
    }
    
    // Check if today is a holiday (with error handling)
    $isHoliday = false;
    try {
        if (class_exists('TurkishHolidayCalculator')) {
            $isHoliday = TurkishHolidayCalculator::isHoliday($dateFilter, $employee['company_id'], $conn);
        }
    } catch (Exception $e) {
        // Holiday calculator has issues, default to no holiday
        error_log("Holiday calculator failed: " . $e->getMessage());
        $isHoliday = false;
    }
    
    // Calculate earnings with new rules
    $hourlyRate = $workSettings['hourly_rate'];
    $totalHours = $totalWorkMinutes / 60;
    
    // Get weekly hours worked (for overtime calculation)
    $weekStart = date('Y-m-d', strtotime('monday this week', strtotime($dateFilter)));
    $weekEnd = date('Y-m-d', strtotime('sunday this week', strtotime($dateFilter)));
    
    // Calculate weekly hours using simplified approach
    $stmt = $conn->prepare("
        SELECT SUM(
            CASE 
                WHEN ar1.check_in_time IS NOT NULL AND ar2.check_in_time IS NOT NULL 
                THEN TIMESTAMPDIFF(MINUTE, ar1.check_in_time, ar2.check_in_time) / 60.0
                ELSE 0 
            END
        ) as weekly_hours
        FROM attendance_records ar1
        LEFT JOIN attendance_records ar2 ON ar1.employee_id = ar2.employee_id 
            AND DATE(ar1.check_in_time) = DATE(ar2.check_in_time)
            AND ar1.activity_type != ar2.activity_type
            AND ar1.check_in_time < ar2.check_in_time
        WHERE ar1.employee_id = ? 
        AND DATE(ar1.check_in_time) BETWEEN ? AND ?
        AND ar1.activity_type = 'work_in'
        AND ar2.activity_type = 'work_out'
    ");
    $stmt->execute([$employeeId, $weekStart, $weekEnd]);
    $weeklyData = $stmt->fetch(PDO::FETCH_ASSOC);
    $weeklyHours = $weeklyData['weekly_hours'] ?? 0;
    
    if ($isHoliday) {
        // Holiday rate: 2x
        $totalEarnings = $totalHours * $hourlyRate * $workSettings['holiday_multiplier'];
        $regularHours = 0;
        $overtimeHours = 0;
        $holidayHours = $totalHours;
    } elseif ($weeklyHours > $workSettings['weekly_hours']) {
        // Overtime after weekly limit (45 hours)
        $regularHours = min($totalHours, $workSettings['weekly_hours'] - ($weeklyHours - $totalHours));
        $overtimeHours = max($totalHours - $regularHours, 0);
        $totalEarnings = ($regularHours * $hourlyRate) + ($overtimeHours * $hourlyRate * $workSettings['overtime_multiplier']);
        $holidayHours = 0;
    } else {
        // Regular hours
        $regularHours = $totalHours;
        $overtimeHours = 0;
        $holidayHours = 0;
        $totalEarnings = $regularHours * $hourlyRate;
    }
    
} catch (Exception $e) {
    $message = "❌ Hata: " . $e->getMessage();
    $messageType = "error";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devam Kayıtları - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">📊</span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Devam Kayıtları</h1>
            <?php if (isset($employee)): ?>
            <p class="text-gray-600 mt-2">
                <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                <span class="text-sm">(#<?php echo htmlspecialchars($employee['employee_number']); ?>)</span>
            </p>
            <?php endif; ?>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                    ($messageType === 'error' ? 'bg-red-100 text-red-800 border border-red-200' : 
                    'bg-yellow-100 text-yellow-800 border border-yellow-200'); 
            ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Date Filter -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">📅 Tarih Seçimi</h2>
            <form method="GET" class="flex flex-wrap gap-4 items-end">
                <input type="hidden" name="employee_id" value="<?php echo htmlspecialchars($employeeId); ?>">
                <div class="flex-1 min-w-48">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Tarih</label>
                    <input 
                        type="date" 
                        name="date" 
                        value="<?php echo htmlspecialchars($dateFilter); ?>"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    >
                </div>
                <button 
                    type="submit" 
                    class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                >
                    Göster
                </button>
            </form>
        </div>

        <?php if (isset($records)): ?>
        <!-- Work Summary -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">📈 Günlük Özet</h2>
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div class="bg-green-50 p-4 rounded-lg text-center">
                    <div class="text-2xl font-bold text-green-700">
                        <?php echo number_format($totalWorkMinutes / 60, 1); ?>
                    </div>
                    <div class="text-sm text-green-600">Çalışma Saati</div>
                </div>
                
                <div class="bg-yellow-50 p-4 rounded-lg text-center">
                    <div class="text-2xl font-bold text-yellow-700">
                        <?php echo number_format($totalBreakMinutes / 60, 1); ?>
                    </div>
                    <div class="text-sm text-yellow-600">Mola Saati</div>
                </div>
                
                <div class="bg-blue-50 p-4 rounded-lg text-center">
                    <div class="text-2xl font-bold text-blue-700">
                        <?php echo $overtimeHours > 0 ? number_format($overtimeHours, 1) : '0'; ?>
                    </div>
                    <div class="text-sm text-blue-600">Fazla Mesai</div>
                </div>
                
                <?php if (isset($holidayHours) && $holidayHours > 0): ?>
                <div class="bg-red-50 p-4 rounded-lg text-center">
                    <div class="text-2xl font-bold text-red-700">
                        <?php echo number_format($holidayHours, 1); ?>
                    </div>
                    <div class="text-sm text-red-600">Tatil Mesai</div>
                </div>
                <?php endif; ?>
                
                <div class="bg-purple-50 p-4 rounded-lg text-center">
                    <div class="text-2xl font-bold text-purple-700">
                        ₺<?php echo number_format($totalEarnings, 2); ?>
                    </div>
                    <div class="text-sm text-purple-600">
                        <?php if (isset($isHoliday) && $isHoliday): ?>
                            Tatil Kazancı
                        <?php else: ?>
                            Günlük Kazanç
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <?php if (isset($isHoliday) && $isHoliday): ?>
            <div class="mt-4 p-4 bg-red-100 border border-red-200 rounded-lg">
                <div class="flex items-center">
                    <span class="text-2xl mr-3">🎉</span>
                    <div>
                        <div class="font-semibold text-red-800">Resmi Tatil Günü</div>
                        <div class="text-sm text-red-600">
                            <?php echo htmlspecialchars($isHoliday['holiday_name']); ?> - 
                            Saatlik ücret: ₺<?php echo number_format($hourlyRate * $workSettings['holiday_multiplier'], 2); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php elseif ($overtimeHours > 0): ?>
            <div class="mt-4 p-4 bg-blue-100 border border-blue-200 rounded-lg">
                <div class="flex items-center">
                    <span class="text-2xl mr-3">⏰</span>
                    <div>
                        <div class="font-semibold text-blue-800">Fazla Mesai Uygulandı</div>
                        <div class="text-sm text-blue-600">
                            Normal: <?php echo number_format($regularHours, 1); ?>sa × ₺<?php echo number_format($hourlyRate, 2); ?> + 
                            Fazla: <?php echo number_format($overtimeHours, 1); ?>sa × ₺<?php echo number_format($hourlyRate * $workSettings['overtime_multiplier'], 2); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Records Timeline -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">⏰ Aktivite Zaman Çizelgesi</h2>
            
            <?php if (empty($records)): ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="text-4xl mb-2">📝</div>
                    <p>Bu tarih için kayıt bulunamadı.</p>
                </div>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($records as $record): ?>
                        <div class="flex items-center p-4 bg-gray-50 rounded-lg border-l-4" 
                             style="border-left-color: <?php echo $record['color_code'] ?? '#6b7280'; ?>">
                            <div class="flex-shrink-0 w-16 text-center">
                                <div class="text-lg font-bold text-gray-900">
                                    <?php echo $record['time_formatted']; ?>
                                </div>
                            </div>
                            
                            <div class="flex-1 ml-4">
                                <div class="flex items-center gap-2">
                                    <span class="text-lg">
                                        <?php 
                                        $activityIcons = [
                                            'work_in' => '🏢',
                                            'work_out' => '🚪', 
                                            'break_start' => '☕',
                                            'break_end' => '⏰',
                                            'lunch_start' => '🍽️',
                                            'lunch_end' => '🍴'
                                        ];
                                        echo $activityIcons[$record['activity_type']] ?? '📍';
                                        ?>
                                    </span>
                                    <span class="font-medium text-gray-900">
                                        <?php echo htmlspecialchars($record['activity_name'] ?? 'Bilinmeyen Aktivite'); ?>
                                    </span>
                                </div>
                                
                                <div class="text-sm text-gray-600 mt-1">
                                    📍 <?php echo htmlspecialchars($record['location_name'] ?? 'Bilinmeyen Lokasyon'); ?>
                                    <?php if ($record['distance_meters']): ?>
                                        <span class="ml-2">📏 <?php echo number_format($record['distance_meters'], 0); ?>m uzaklık</span>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($record['notes']): ?>
                                    <div class="text-xs text-gray-500 mt-1">
                                        💬 <?php echo htmlspecialchars($record['notes']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="flex-shrink-0 text-right">
                                <div class="text-xs text-gray-500">
                                    GPS: <?php echo $record['latitude'] ? number_format($record['latitude'], 6) : 'N/A'; ?>, 
                                         <?php echo $record['longitude'] ? number_format($record['longitude'], 6) : 'N/A'; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Break Analysis -->
        <?php if (!empty($breakTimes)): ?>
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">☕ Mola Analizi</h2>
            <div class="space-y-2">
                <?php foreach ($breakTimes as $i => $break): ?>
                    <?php if (isset($break['end'])): ?>
                        <div class="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                            <div>
                                <span class="font-medium">Mola #<?php echo $i + 1; ?></span>
                                <span class="text-sm text-gray-600 ml-2">
                                    (<?php echo date('H:i', $break['start']); ?> - <?php echo date('H:i', $break['end']); ?>)
                                </span>
                            </div>
                            <div class="text-right">
                                <span class="font-bold text-yellow-700">
                                    <?php echo number_format($break['duration'], 0); ?> dakika
                                </span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                            <div>
                                <span class="font-medium">Mola #<?php echo $i + 1; ?></span>
                                <span class="text-sm text-gray-600 ml-2">
                                    (<?php echo date('H:i', $break['start']); ?> - devam ediyor)
                                </span>
                            </div>
                            <div class="text-right">
                                <span class="font-bold text-red-700">
                                    <?php echo number_format((time() - $break['start']) / 60, 0); ?> dakika
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>

        <!-- Navigation -->
        <div class="text-center space-y-3">
            <a href="../dashboard/employee-dashboard.php" class="inline-block text-indigo-600 hover:text-indigo-500 font-medium">
                ← Personel Paneli
            </a>
            <br>
            <a href="../qr/qr-reader.php" class="inline-block bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors">
                📱 QR Kod Okut
            </a>
        </div>
    </div>

    <script>
        // Auto-refresh every 30 seconds if today's date is selected
        <?php if ($dateFilter === date('Y-m-d')): ?>
        setTimeout(() => {
            window.location.reload();
        }, 30000);
        <?php endif; ?>
    </script>
</body>
</html>