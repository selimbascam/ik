<?php
/**
 * QR Scanner Ana Sayfası
 */
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Kod Tarayıcı - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center py-6">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                            <span class="text-white font-bold">📱</span>
                        </div>
                        <div>
                            <h1 class="text-xl font-semibold text-gray-900">QR Kod Tarayıcı</h1>
                            <p class="text-sm text-gray-600">Personel giriş/çıkış kayıtları</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <a href="index.php" class="text-gray-600 hover:text-gray-900">
                            🏠 Ana Sayfa
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="bg-white rounded-lg shadow-lg p-8">
                <div class="text-center mb-8">
                    <div class="text-6xl mb-4">📱</div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-2">QR Kod Tarayıcı</h2>
                    <p class="text-gray-600">Devam kayıtları için QR kodunuzu taratın</p>
                </div>

                <!-- Scanner Options -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <a href="qr/scanner.php" class="bg-blue-50 border border-blue-200 rounded-lg p-6 hover:bg-blue-100 transition-colors">
                        <div class="text-center">
                            <div class="text-3xl mb-4">📷</div>
                            <h3 class="text-lg font-medium text-blue-900 mb-2">Kamera ile Tarama</h3>
                            <p class="text-blue-700 text-sm">Cihazınızın kamerasını kullanarak QR kod tarayın</p>
                        </div>
                    </a>

                    <a href="qr/qr-reader.php" class="bg-green-50 border border-green-200 rounded-lg p-6 hover:bg-green-100 transition-colors">
                        <div class="text-center">
                            <div class="text-3xl mb-4">🔍</div>
                            <h3 class="text-lg font-medium text-green-900 mb-2">Manuel Kod Girişi</h3>
                            <p class="text-green-700 text-sm">QR kod numarasını manuel olarak girin</p>
                        </div>
                    </a>
                </div>

                <!-- Quick Access -->
                <div class="border-t border-gray-200 pt-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Hızlı Erişim</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <a href="employee/dashboard.php" class="text-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                            <div class="text-2xl mb-2">👤</div>
                            <div class="text-sm font-medium">Personel Paneli</div>
                        </a>
                        
                        <a href="dashboard/company-dashboard.php" class="text-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                            <div class="text-2xl mb-2">📊</div>
                            <div class="text-sm font-medium">Şirket Dashboard</div>
                        </a>
                        
                        <a href="admin/qr-generator.php" class="text-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                            <div class="text-2xl mb-2">⚙️</div>
                            <div class="text-sm font-medium">QR Üretici</div>
                        </a>
                        
                        <a href="reports/index.php" class="text-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                            <div class="text-2xl mb-2">📈</div>
                            <div class="text-sm font-medium">Raporlar</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>