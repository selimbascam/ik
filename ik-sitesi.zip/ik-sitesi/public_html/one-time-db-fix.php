<?php
// One-time database fix script - can only be used once
$lockFile = __DIR__ . '/db-fix-completed.lock';

// Check if already executed
if (file_exists($lockFile)) {
    ?>
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Veritabanı Düzeltme - Tamamlandı</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .error { color: #e74c3c; background: #ffeaea; padding: 15px; border-radius: 5px; border-left: 4px solid #e74c3c; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🔒 Bu Link Zaten Kullanıldı</h1>
            <div class="error">
                <strong>Güvenlik:</strong> Bu veritabanı düzeltme linki tek kullanımlıktır ve daha önce başarıyla çalıştırılmıştır.
                <br><br>
                Güvenlik nedeniyle tekrar çalıştırılamaz.
            </div>
            <p><a href="../dashboard/company-dashboard.php">← Ana Panele Dön</a></p>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Database connection
$servername = "localhost";
$username = "u978874874_ik"; 
$password = "Szb2013@+-!";
$dbname = "u978874874_ik";

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veritabanı Düzeltme - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #27ae60; background: #eafaf1; padding: 10px; border-radius: 5px; border-left: 4px solid #27ae60; margin: 10px 0; }
        .error { color: #e74c3c; background: #ffeaea; padding: 10px; border-radius: 5px; border-left: 4px solid #e74c3c; margin: 10px 0; }
        .warning { color: #f39c12; background: #fef9e7; padding: 10px; border-radius: 5px; border-left: 4px solid #f39c12; margin: 10px 0; }
        h1 { color: #2c3e50; }
        h2 { color: #34495e; margin-top: 30px; }
        .step { margin: 15px 0; padding: 10px; border-left: 3px solid #3498db; background: #f8f9fa; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Tek Kullanımlık Veritabanı Düzeltme</h1>
        
        <?php
        try {
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                throw new Exception("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
            }
            
            echo '<div class="success">✅ Veritabanı bağlantısı başarılı</div>';
            
            $allSuccess = true;
            $completedTasks = 0;
            
            // Fix 1: Add missing columns to employee_devices
            echo '<div class="step"><h3>1. employee_devices tablosu düzeltiliyor...</h3>';
            $result = $conn->query("SHOW COLUMNS FROM employee_devices LIKE 'is_blocked'");
            if ($result->num_rows === 0) {
                $result->free(); // Free result before new query
                $sql = "ALTER TABLE employee_devices ADD COLUMN is_blocked TINYINT(1) DEFAULT 0";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ is_blocked kolonu eklendi</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="error">❌ is_blocked kolonu eklenirken hata: ' . $conn->error . '</div>';
                    $allSuccess = false;
                }
            } else {
                $result->free(); // Free result
                echo '<div class="warning">⚠️ is_blocked kolonu zaten mevcut</div>';
                $completedTasks++;
            }
            echo '</div>';

            // Fix 2: Add missing columns to work_settings
            echo '<div class="step"><h3>2. work_settings tablosu düzeltiliyor...</h3>';
            $result = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'hourly_rate'");
            if ($result->num_rows === 0) {
                $result->free(); // Free result before new query
                $sql = "ALTER TABLE work_settings ADD COLUMN hourly_rate DECIMAL(10,2) DEFAULT 0.00";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ hourly_rate kolonu eklendi</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="error">❌ hourly_rate kolonu eklenirken hata: ' . $conn->error . '</div>';
                    $allSuccess = false;
                }
            } else {
                $result->free(); // Free result
                echo '<div class="warning">⚠️ hourly_rate kolonu zaten mevcut</div>';
                $completedTasks++;
            }
            
            $result = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'monthly_hours'");
            if ($result->num_rows === 0) {
                $result->free(); // Free result before new query
                $sql = "ALTER TABLE work_settings ADD COLUMN monthly_hours INT DEFAULT 225";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ monthly_hours kolonu eklendi</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="error">❌ monthly_hours kolonu eklenirken hata: ' . $conn->error . '</div>';
                    $allSuccess = false;
                }
            } else {
                $result->free(); // Free result
                echo '<div class="warning">⚠️ monthly_hours kolonu zaten mevcut</div>';
                $completedTasks++;
            }
            
            $result = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'weekly_holiday'");
            if ($result->num_rows === 0) {
                $result->free(); // Free result before new query
                $sql = "ALTER TABLE work_settings ADD COLUMN weekly_holiday INT DEFAULT 1";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ weekly_holiday kolonu eklendi</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="error">❌ weekly_holiday kolonu eklenirken hata: ' . $conn->error . '</div>';
                    $allSuccess = false;
                }
            } else {
                $result->free(); // Free result
                echo '<div class="warning">⚠️ weekly_holiday kolonu zaten mevcut</div>';
                $completedTasks++;
            }
            
            // Fix hourly_rate precision to 4 decimal places
            $result = $conn->query("SHOW COLUMNS FROM work_settings LIKE 'hourly_rate'");
            if ($result->num_rows > 0) {
                $result->free(); // Free result before new query
                $sql = "ALTER TABLE work_settings MODIFY COLUMN hourly_rate DECIMAL(10,4) DEFAULT 50.0000";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ hourly_rate kolonu 4 basamak hassasiyete güncellendi</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="warning">⚠️ hourly_rate hassasiyet güncellemesi başarısız: ' . $conn->error . '</div>';
                    $completedTasks++;
                }
            } else {
                $result->free(); // Free result
            }
            echo '</div>';

            // Fix 3: Create shift_templates table and add missing columns
            echo '<div class="step"><h3>3. shift_templates tablosu düzeltiliyor...</h3>';
            
            // First, check if table exists, if not create it
            $result = $conn->query("SHOW TABLES LIKE 'shift_templates'");
            if ($result->num_rows === 0) {
                $result->free(); // Free result before new query
                $sql = "CREATE TABLE shift_templates (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    company_id INT NOT NULL,
                    name VARCHAR(100) NOT NULL,
                    start_time TIME NOT NULL,
                    end_time TIME NOT NULL,
                    break_duration INT DEFAULT 60,
                    description TEXT,
                    color_code VARCHAR(7) DEFAULT '#3B82F6',
                    is_active TINYINT(1) DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
                )";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ shift_templates tablosu oluşturuldu</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="error">❌ shift_templates tablosu oluşturulurken hata: ' . $conn->error . '</div>';
                    $allSuccess = false;
                }
            } else {
                $result->free(); // Free result
                echo '<div class="warning">⚠️ shift_templates tablosu zaten mevcut</div>';
                $completedTasks++;
                
                // Add missing columns if table exists
                $result = $conn->query("SHOW COLUMNS FROM shift_templates LIKE 'description'");
                if ($result->num_rows === 0) {
                    $result->free(); // Free result before new query
                    $sql = "ALTER TABLE shift_templates ADD COLUMN description TEXT";
                    if ($conn->query($sql) === TRUE) {
                        echo '<div class="success">✅ description kolonu eklendi</div>';
                        $completedTasks++;
                    } else {
                        echo '<div class="error">❌ description kolonu eklenirken hata: ' . $conn->error . '</div>';
                        $allSuccess = false;
                    }
                } else {
                    $result->free(); // Free result
                    echo '<div class="warning">⚠️ description kolonu zaten mevcut</div>';
                    $completedTasks++;
                }

                $result = $conn->query("SHOW COLUMNS FROM shift_templates LIKE 'color_code'");
                if ($result->num_rows === 0) {
                    $result->free(); // Free result before new query
                    $sql = "ALTER TABLE shift_templates ADD COLUMN color_code VARCHAR(7) DEFAULT '#3B82F6'";
                    if ($conn->query($sql) === TRUE) {
                        echo '<div class="success">✅ color_code kolonu eklendi</div>';
                        $completedTasks++;
                    } else {
                        echo '<div class="error">❌ color_code kolonu eklenirken hata: ' . $conn->error . '</div>';
                        $allSuccess = false;
                    }
                } else {
                    $result->free(); // Free result
                    echo '<div class="warning">⚠️ color_code kolonu zaten mevcut</div>';
                    $completedTasks++;
                }

                $result = $conn->query("SHOW COLUMNS FROM shift_templates LIKE 'is_active'");
                if ($result->num_rows === 0) {
                    $result->free(); // Free result before new query
                    $sql = "ALTER TABLE shift_templates ADD COLUMN is_active TINYINT(1) DEFAULT 1";
                    if ($conn->query($sql) === TRUE) {
                        echo '<div class="success">✅ is_active kolonu eklendi</div>';
                        $completedTasks++;
                    } else {
                        echo '<div class="error">❌ is_active kolonu eklenirken hata: ' . $conn->error . '</div>';
                        $allSuccess = false;
                    }
                } else {
                    $result->free(); // Free result
                    echo '<div class="warning">⚠️ is_active kolonu zaten mevcut</div>';
                    $completedTasks++;
                }
            }
            echo '</div>';

            // Fix 4: Fix employee_shifts table structure
            echo '<div class="step"><h3>4. employee_shifts tablosu düzeltiliyor...</h3>';
            
            // Drop and recreate employee_shifts table to ensure correct structure
            $conn->query("DROP TABLE IF EXISTS employee_shifts");
            
            $sql = "CREATE TABLE employee_shifts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                shift_template_id INT NOT NULL,
                shift_date DATE NOT NULL,
                status ENUM('scheduled', 'completed', 'absent', 'late', 'early_leave') DEFAULT 'scheduled',
                late_reason TEXT,
                early_leave_reason TEXT,
                absence_reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_employee_date (employee_id, shift_date),
                INDEX idx_employee (employee_id),
                INDEX idx_shift_template (shift_template_id),
                INDEX idx_date (shift_date),
                INDEX idx_created_at (created_at),
                FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            
            if ($conn->query($sql) === TRUE) {
                echo '<div class="success">✅ employee_shifts tablosu yeniden oluşturuldu</div>';
                $completedTasks++;
                
                // Insert some test data for company_id = 1
                $testShiftStmt = $conn->prepare("SELECT id FROM shift_templates WHERE company_id = 1 LIMIT 1");
                $testShiftStmt->execute();
                $testShiftResult = $testShiftStmt->get_result();
                $testShift = $testShiftResult->fetch_assoc();
                $testShiftResult->free();
                $testShiftStmt->close();
                
                $testEmpStmt = $conn->prepare("SELECT id FROM employees WHERE company_id = 1 LIMIT 1");
                $testEmpStmt->execute();
                $testEmpResult = $testEmpStmt->get_result();
                $testEmp = $testEmpResult->fetch_assoc();
                $testEmpResult->free();
                $testEmpStmt->close();
                
                if ($testShift && $testEmp) {
                    $conn->query("INSERT IGNORE INTO employee_shifts (employee_id, shift_template_id, shift_date, status) VALUES ({$testEmp['id']}, {$testShift['id']}, CURDATE(), 'scheduled')");
                    echo '<div class="success">✅ Test vardiya ataması eklendi</div>';
                }
            } else {
                echo '<div class="error">❌ employee_shifts tablosu hatası: ' . $conn->error . '</div>';
                $allSuccess = false;
            }
            echo '</div>';

            // Fix 5: Update employees table
            echo '<div class="step"><h3>5. employees tablosu düzeltiliyor...</h3>';
            $result = $conn->query("SHOW COLUMNS FROM employees LIKE 'is_active'");
            if ($result->num_rows === 0) {
                $result->free(); // Free result before new query
                $sql = "ALTER TABLE employees ADD COLUMN is_active TINYINT(1) DEFAULT 1";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ is_active kolonu eklendi</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="error">❌ is_active kolonu eklenirken hata: ' . $conn->error . '</div>';
                    $allSuccess = false;
                }
            } else {
                $result->free(); // Free result
                echo '<div class="warning">⚠️ is_active kolonu zaten mevcut</div>';
                $completedTasks++;
            }

            $result = $conn->query("SHOW COLUMNS FROM employees LIKE 'status'");
            if ($result->num_rows === 0) {
                $result->free(); // Free result before new query
                $sql = "ALTER TABLE employees ADD COLUMN status ENUM('active', 'inactive', 'terminated') DEFAULT 'active'";
                if ($conn->query($sql) === TRUE) {
                    echo '<div class="success">✅ status kolonu eklendi</div>';
                    $completedTasks++;
                } else {
                    echo '<div class="error">❌ status kolonu eklenirken hata: ' . $conn->error . '</div>';
                    $allSuccess = false;
                }
            } else {
                $result->free(); // Free result
                echo '<div class="warning">⚠️ status kolonu zaten mevcut</div>';
                $completedTasks++;
            }
            echo '</div>';

            // Fix 6: Add default shift templates for company_id = 1
            echo '<div class="step"><h3>6. Varsayılan vardiya şablonları ekleniyor...</h3>';
            
            // Check if there are any shift templates for company_id = 1
            $result = $conn->query("SELECT COUNT(*) as count FROM shift_templates WHERE company_id = 1");
            $row = $result->fetch_assoc();
            $result->free(); // Free result after fetching
            
            if ($row['count'] == 0) {
                $defaultShifts = [
                    "INSERT INTO shift_templates (company_id, name, start_time, end_time, break_duration, description, color_code, is_active) VALUES (1, 'Gündüz Vardiyası', '09:00:00', '17:00:00', 60, 'Standart gündüz mesaisi', '#3B82F6', 1)",
                    "INSERT INTO shift_templates (company_id, name, start_time, end_time, break_duration, description, color_code, is_active) VALUES (1, 'Gece Vardiyası', '22:00:00', '06:00:00', 60, 'Gece vardiyası', '#DC2626', 1)",
                    "INSERT INTO shift_templates (company_id, name, start_time, end_time, break_duration, description, color_code, is_active) VALUES (1, 'Yarım Gün', '09:00:00', '13:00:00', 30, 'Yarım günlük çalışma', '#059669', 1)"
                ];
                
                foreach ($defaultShifts as $shiftSql) {
                    if ($conn->query($shiftSql) === TRUE) {
                        echo '<div class="success">✅ Varsayılan vardiya şablonu eklendi</div>';
                        $completedTasks++;
                    } else {
                        echo '<div class="error">❌ Vardiya şablonu eklenemedi: ' . $conn->error . '</div>';
                        $allSuccess = false;
                    }
                }
            } else {
                echo '<div class="warning">⚠️ Zaten vardiya şablonları mevcut</div>';
                $completedTasks++;
            }
            echo '</div>'; 
            
            // Fix 7: Test shift assignment functionality
            echo '<div class="step"><h3>7. Vardiya atama sistemi test ediliyor...</h3>';
            
            try {
                // Test query similar to what shift-management.php uses
                $testStmt = $conn->prepare("
                    SELECT 
                        es.id,
                        es.employee_id,
                        es.shift_template_id,
                        es.shift_date,
                        es.created_at,
                        COALESCE(es.status, 'scheduled') as status,
                        COALESCE(st.name, 'Vardiya') as shift_name,
                        e.first_name, 
                        e.last_name, 
                        e.employee_number
                    FROM employee_shifts es
                    JOIN employees e ON es.employee_id = e.id
                    LEFT JOIN shift_templates st ON es.shift_template_id = st.id
                    WHERE e.company_id = ? 
                    ORDER BY es.created_at DESC
                    LIMIT 5
                ");
                $testStmt->execute([1]);
                $result = $testStmt->get_result();
                $testResults = $result->fetch_all(MYSQLI_ASSOC);
                $result->free();
                $testStmt->close();
                
                echo '<div class="success">✅ Vardiya sorgulama sistemi çalışıyor (' . count($testResults) . ' kayıt bulundu)</div>';
                $completedTasks++;
                
                // Display some results for verification
                if (!empty($testResults)) {
                    echo '<div class="success">📋 Test Sonuçları:</div>';
                    foreach ($testResults as $result) {
                        echo '<div class="warning">- ' . ($result['first_name'] ?? 'N/A') . ' ' . ($result['last_name'] ?? 'N/A') . ' (' . ($result['employee_number'] ?? 'N/A') . ') - ' . ($result['shift_name'] ?? 'N/A') . '</div>';
                    }
                }
                
            } catch (Exception $e) {
                echo '<div class="error">❌ Vardiya sorgulama hatası: ' . $e->getMessage() . '</div>';
                $allSuccess = false;
            }
            echo '</div>';

            $conn->close();
            
            // Final result
            echo '<h2>📊 Sonuç</h2>';
            if ($allSuccess) {
                echo '<div class="success">
                    <h3>🎉 Tüm Veritabanı Düzeltmeleri Başarıyla Tamamlandı!</h3>
                    <p><strong>Tamamlanan işlemler:</strong> ' . $completedTasks . ' adım</p>
                    <p><strong>Durum:</strong> Artık tüm sistemler çalışır durumda olmalı</p>
                </div>';
                
                // Create lock file to prevent re-execution
                file_put_contents($lockFile, date('Y-m-d H:i:s') . " - Database fixes completed successfully\n");
                
                echo '<div class="warning">
                    <strong>ÖNEMLİ:</strong> Bu link artık devre dışı bırakıldı. Güvenlik nedeniyle tekrar çalıştırılamaz.
                </div>';
                
            } else {
                echo '<div class="error">
                    <h3>⚠️ Bazı İşlemler Tamamlanamadı</h3>
                    <p>Lütfen hataları kontrol edin ve gerekirse manuel düzeltme yapın.</p>
                </div>';
            }
            
        } catch (Exception $e) {
            echo '<div class="error">
                <h3>❌ Kritik Hata</h3>
                <p>' . htmlspecialchars($e->getMessage()) . '</p>
            </div>';
        }
        ?>
        
        <h2>🔗 İleri Adımlar</h2>
        <div class="step">
            <p><strong>Test Edilecek Alanlar:</strong></p>
            <ul>
                <li>Vardiya yönetimi - personel atama</li>
                <li>Shift template düzenleme/silme</li>
                <li>Çalışma ayarları kaydetme</li>
                <li>Cihaz kayıtları listesi</li>
                <li>Tatil günleri yönetimi</li>
            </ul>
            
            <p><strong>Yararlı Linkler:</strong></p>
            <ul>
                <li><a href="../admin/shift-management.php">Vardiya Yönetimi Test Et</a></li>
                <li><a href="../admin/work-settings.php">Çalışma Ayarları Test Et</a></li>
                <li><a href="../dashboard/company-dashboard.php">Ana Panele Dön</a></li>
            </ul>
        </div>
    </div>
</body>
</html>