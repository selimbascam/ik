<?php
/**
 * KRİTİK QR DAVRANIŞI DÜZELTMESİ
 * Ana sorun: QR reader her zaman work_start döndürüyor
 */
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🚨 KRİTİK QR DAVRANIŞI DÜZELTMESİ</h1>";
    
    // Ana sorunun kaynağını bul
    echo "<h2>1. QR Reader Algoritması Test</h2>";
    
    // Test QR isimleri
    $testNames = ['giriş', 'çıkış', 'mola', 'Giriş Kapısı', 'Çıkış Kapısı', 'Mola Alanı'];
    
    foreach ($testNames as $name) {
        echo "<div style='border: 1px solid #ccc; margin: 10px; padding: 10px;'>";
        echo "<h3>Test: '$name'</h3>";
        
        // QR Reader algoritmasının aynısını burada test et
        $qrName = mb_strtolower(trim($name), 'UTF-8');
        $qrName = str_replace(['İ', 'I'], 'i', $qrName);
        $qrName = str_replace(['Ğ'], 'ğ', $qrName);
        $qrName = str_replace(['Ü'], 'ü', $qrName);
        $qrName = str_replace(['Ş'], 'ş', $qrName);
        $qrName = str_replace(['Ö'], 'ö', $qrName);
        $qrName = str_replace(['Ç'], 'ç', $qrName);
        
        echo "<p>Normalize: '$qrName'</p>";
        
        // Aynı algoritma
        if (strpos($qrName, 'mola') !== false || strpos($qrName, 'break') !== false) {
            $result = 'break_toggle';
            echo "<p style='color: orange;'>✅ MOLA TESPİT EDİLDİ: break_toggle</p>";
        } elseif (strpos($qrName, 'giriş') !== false || strpos($qrName, 'giris') !== false || 
                strpos($qrName, 'entrance') !== false || strpos($qrName, 'entry') !== false) {
            $result = 'work_start';
            echo "<p style='color: green;'>✅ GİRİŞ TESPİT EDİLDİ: work_start</p>";
        } elseif (strpos($qrName, 'çıkış') !== false || strpos($qrName, 'cikis') !== false || 
                strpos($qrName, 'exit') !== false) {
            $result = 'work_end';
            echo "<p style='color: blue;'>✅ ÇIKIŞ TESPİT EDİLDİ: work_end</p>";
        } else {
            $result = 'user_choice';
            echo "<p style='color: red;'>❌ TESPİT EDİLEMEDİ: user_choice</p>";
        }
        
        echo "</div>";
    }
    
    // SZB30912 için gerçek durum kontrolü
    echo "<h2>2. SZB30912 Gerçek Durum</h2>";
    
    $stmt = $conn->prepare("SELECT id FROM companies WHERE company_code = 'SZB30912'");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        echo "<p style='color: red;'>❌ SZB30912 bulunamadı!</p>";
    } else {
        $companyId = $company['id'];
        
        $stmt = $conn->prepare("SELECT id, name, gate_behavior FROM qr_locations WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>Mevcut QR Lokasyonları:</h3>";
        foreach ($locations as $loc) {
            echo "<p><strong>{$loc['name']}</strong> → {$loc['gate_behavior']}</p>";
        }
        
        // KRİTİK SORUN TESPİTİ
        echo "<h3>🔍 Kritik Sorun Tespiti</h3>";
        $allWorkStart = true;
        foreach ($locations as $loc) {
            if ($loc['gate_behavior'] !== 'work_start') {
                $allWorkStart = false;
                break;
            }
        }
        
        if ($allWorkStart && count($locations) > 0) {
            echo "<div style='background: #ffebee; padding: 15px; border-left: 5px solid #f44336;'>";
            echo "<h4 style='color: #d32f2f;'>🚨 SORUN TESPİT EDİLDİ!</h4>";
            echo "<p>Tüm QR lokasyonları 'work_start' olarak ayarlanmış!</p>";
            echo "<p>Bu durum QR reader'ın her zaman aynı davranışı göstermesine neden oluyor.</p>";
            echo "</div>";
        }
    }
    
    // Attendance Helper kontrolü
    echo "<h2>3. Attendance Helper Algoritması</h2>";
    
    // Attendance Helper'ın determineActionByGateType metodunu test et
    $testCases = [
        ['break_gate', 'break_toggle'],
        ['entrance_gate', 'work_start'],
        ['exit_gate', 'work_end'],
        ['general_gate', 'user_choice']
    ];
    
    foreach ($testCases as $case) {
        echo "<p><strong>Gate Type:</strong> {$case[0]}, <strong>Behavior:</strong> {$case[1]}</p>";
        
        // Burada gerçek AttendanceHelper'ı çağırmak yerine beklenen sonucu göster
        switch ($case[1]) {
            case 'break_toggle':
                echo "<p style='color: orange;'>→ Beklenen: Mola başlat/bitir</p>";
                break;
            case 'work_start':
                echo "<p style='color: green;'>→ Beklenen: İşe giriş</p>";
                break;
            case 'work_end':
                echo "<p style='color: blue;'>→ Beklenen: İşten çıkış</p>";
                break;
            default:
                echo "<p style='color: gray;'>→ Beklenen: Kullanıcı seçimi</p>";
        }
    }
    
    // ZORLA DÜZELTİCİ
    echo "<h2>4. ⚡ ZORLA DÜZELTİCİ</h2>";
    echo "<form method='post'>";
    echo "<button type='submit' name='force_fix' style='background: #f44336; color: white; padding: 20px 40px; border: none; border-radius: 5px; font-size: 18px; font-weight: bold; cursor: pointer;'>⚡ ZORLA DÜZELT</button>";
    echo "</form>";
    
    if (isset($_POST['force_fix'])) {
        echo "<div style='background: #e8f5e8; padding: 15px; border: 1px solid #4caf50; border-radius: 5px; margin-top: 10px;'>";
        echo "<h3>⚡ Zorla Düzeltme Sonuçları:</h3>";
        
        if ($company) {
            // Tüm gate_behavior'ları sıfırla ve yeniden ayarla
            $forceUpdates = [
                ['name_pattern' => 'giriş', 'behavior' => 'work_start'],
                ['name_pattern' => 'giris', 'behavior' => 'work_start'],
                ['name_pattern' => 'çıkış', 'behavior' => 'work_end'],
                ['name_pattern' => 'cikis', 'behavior' => 'work_end'],
                ['name_pattern' => 'exit', 'behavior' => 'work_end'],
                ['name_pattern' => 'mola', 'behavior' => 'break_toggle'],
                ['name_pattern' => 'break', 'behavior' => 'break_toggle']
            ];
            
            // Önce tüm lokasyonları user_choice yap
            $stmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = 'user_choice' WHERE company_id = ?");
            $stmt->execute([$companyId]);
            echo "<p>1. Tüm lokasyonlar user_choice olarak sıfırlandı</p>";
            
            // Sonra isimlere göre güncelle
            foreach ($forceUpdates as $update) {
                $stmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE company_id = ? AND LOWER(name) LIKE ?");
                $pattern = '%' . $update['name_pattern'] . '%';
                $stmt->execute([$update['behavior'], $companyId, $pattern]);
                $affected = $stmt->rowCount();
                
                if ($affected > 0) {
                    echo "<p>2. '{$update['name_pattern']}' içeren $affected lokasyon → {$update['behavior']}</p>";
                }
            }
            
            // Final kontrol
            $stmt = $conn->prepare("SELECT name, gate_behavior FROM qr_locations WHERE company_id = ?");
            $stmt->execute([$companyId]);
            $finalResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<h4>Final Sonuçlar:</h4>";
            foreach ($finalResults as $result) {
                $color = 'black';
                if ($result['gate_behavior'] === 'work_start') $color = 'green';
                elseif ($result['gate_behavior'] === 'work_end') $color = 'blue';
                elseif ($result['gate_behavior'] === 'break_toggle') $color = 'orange';
                
                echo "<p style='color: $color;'><strong>{$result['name']}</strong> → {$result['gate_behavior']}</p>";
            }
            
            echo "<p style='font-weight: bold; color: #2e7d32; margin-top: 15px;'>🎯 Zorla düzeltme tamamlandı! Şimdi QR okutma testi yapın.</p>";
        }
        
        echo "</div>";
    }
    
    echo "<br><a href='super-admin/index.php' style='color: #1976d2; text-decoration: none;'>← Süper Admin Paneline Dön</a>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Hata: " . $e->getMessage() . "</p>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
</style>