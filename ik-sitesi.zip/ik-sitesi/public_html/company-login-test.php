<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Şirket Giriş Test ve Çözüm</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>1. Test Şirket Verilerini Kontrol Et</h3>";
    
    // Test company credentials
    $testEmail = 'test@szb.com.tr';
    $testPassword = '123456';
    
    // Check if test company exists
    $stmt = $conn->prepare("SELECT id, email, company_name, password FROM companies WHERE email = ?");
    $stmt->execute([$testEmail]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        echo "<p>✅ Test şirket bulundu: " . htmlspecialchars($company['company_name']) . "</p>";
        echo "<p>Email: " . htmlspecialchars($company['email']) . "</p>";
        echo "<p>Şifre Hash: " . substr($company['password'], 0, 20) . "...</p>";
        
        // Test password verification
        $isPlaintext = !password_get_info($company['password'])['algo'];
        
        if ($isPlaintext) {
            $passwordMatch = ($company['password'] === $testPassword);
            echo "<p>Şifre türü: Düz metin (plaintext)</p>";
        } else {
            $passwordMatch = password_verify($testPassword, $company['password']);
            echo "<p>Şifre türü: Hash edilmiş</p>";
        }
        
        echo "<p>Şifre doğrulama: " . ($passwordMatch ? '✅ DOĞRU' : '❌ YANLIŞ') . "</p>";
        
        if (!$passwordMatch && $isPlaintext) {
            echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
            echo "<h4>⚠️ Şifre Sorun Tespiti</h4>";
            echo "<p>Şifre düz metin olarak saklanıyor ama eşleşmiyor. Şifreyi düzeltelim:</p>";
            
            // Update password to correct value
            $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE email = ?");
            $stmt->execute([$testPassword, $testEmail]);
            echo "<p>✅ Şifre '123456' olarak güncellendi</p>";
            echo "</div>";
        }
        
    } else {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>❌ Test Şirket Bulunamadı</h4>";
        echo "<p>Test şirketi oluşturalım:</p>";
        
        try {
            $stmt = $conn->prepare("
                INSERT INTO companies (email, password, company_name, phone, address, created_at) 
                VALUES (?, ?, 'Test Şirket', '555-0123', 'Test Adres', NOW())
            ");
            $stmt->execute([$testEmail, $testPassword]);
            echo "<p>✅ Test şirket oluşturuldu</p>";
            
        } catch (Exception $e) {
            echo "<p>❌ Şirket oluşturma hatası: " . $e->getMessage() . "</p>";
        }
        echo "</div>";
    }
    
    echo "<h3>2. Giriş Formunu Test Et</h3>";
    
    // Simulate login process
    if ($company && isset($passwordMatch) && $passwordMatch) {
        echo "<p>✅ Giriş bilgileri doğru - session test:</p>";
        
        session_start();
        $_SESSION['company_id'] = $company['id'];
        $_SESSION['company_email'] = $company['email'];
        $_SESSION['company_name'] = $company['company_name'];
        $_SESSION['user_type'] = 'company';
        
        echo "<ul>";
        echo "<li>Session ID: " . session_id() . "</li>";
        echo "<li>Company ID: " . ($_SESSION['company_id'] ?? 'Not set') . "</li>";
        echo "<li>User Type: " . ($_SESSION['user_type'] ?? 'Not set') . "</li>";
        echo "</ul>";
        
        echo "<p>✅ Session başarıyla kuruldu</p>";
    }
    
    echo "<h3>3. Giriş Sayfalarını Kontrol Et</h3>";
    
    $loginFiles = [
        'auth/company-login.php',
        'auth/company-login-fixed.php',
        'company-login.php'
    ];
    
    foreach ($loginFiles as $file) {
        $fullPath = __DIR__ . '/' . $file;
        if (file_exists($fullPath)) {
            echo "<p>✅ $file mevcut</p>";
        } else {
            echo "<p>❌ $file bulunamadı</p>";
        }
    }
    
    echo "<h3>4. Database Bağlantı Testi</h3>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM companies");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>✅ Database bağlantısı çalışıyor - " . $result['count'] . " şirket kayıtlı</p>";
        
        // Test companies table structure
        $stmt = $conn->query("SHOW COLUMNS FROM companies");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "<p>Companies tablosu sütunları: " . implode(', ', $columns) . "</p>";
        
    } catch (Exception $e) {
        echo "<p>❌ Database hatası: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>5. Çözüm ve Test Linkleri</h3>";
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>🔗 Test Giriş Yapın</h4>";
    echo "<p><strong>Email:</strong> test@szb.com.tr</p>";
    echo "<p><strong>Şifre:</strong> 123456</p>";
    echo "<ul>";
    echo "<li><a href='auth/company-login.php' style='color: #0056b3; font-weight: bold;'>Ana Şirket Giriş →</a></li>";
    echo "<li><a href='auth/company-login-fixed.php' style='color: #0056b3;'>Düzeltilmiş Şirket Giriş →</a></li>";
    echo "<li><a href='company-login.php' style='color: #0056b3;'>Direkt Şirket Giriş →</a></li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<h3>6. Hata Ayıklama</h3>";
    
    // Check for common issues
    echo "<p>Yaygın sorunları kontrol ediyorum:</p>";
    echo "<ul>";
    echo "<li>Session başlatılması: " . (session_status() === PHP_SESSION_ACTIVE ? '✅' : '❌') . "</li>";
    echo "<li>Database bağlantısı: ✅</li>";
    echo "<li>Test şirket verileri: ✅</li>";
    echo "<li>Şifre doğrulama: " . (isset($passwordMatch) && $passwordMatch ? '✅' : '❌') . "</li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Sistem Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "h3 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; }";
echo "</style>";
?>