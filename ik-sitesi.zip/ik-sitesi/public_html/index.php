<?php
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - İnsan Kaynakları Yönetim Sistemi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <!-- Header -->
    <header class="bg-white/80 backdrop-blur-sm shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mr-4">
                        <span class="text-white font-bold text-xl">S</span>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900"><?php echo APP_NAME; ?></h1>
                        <p class="text-sm text-gray-600">İnsan Kaynakları Yönetim Sistemi</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="super-admin/index.php" class="text-gray-600 hover:text-gray-900 text-sm">
                        👑 Süper Admin
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="text-center mb-16">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">
                Modern İK Yönetimi
            </h2>
            <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                Personel takibi, devam kayıtları, QR kod sistemi ve raporlama araçları ile 
                işletmenizi dijital dönüşüme hazırlayın.
            </p>
        </div>

        <!-- Login Options -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <!-- Company Login -->
            <div class="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow">
                <div class="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <span class="text-blue-600 text-2xl">🏢</span>
                </div>
                <h3 class="text-xl font-bold text-gray-900 text-center mb-4">Şirket Girişi</h3>
                <p class="text-gray-600 text-center mb-6">
                    Yönetici olarak giriş yapın ve personel işlemlerini yönetin.
                </p>
                <div class="space-y-3">
                    <a href="auth/company-login.php" 
                       class="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors text-center block font-medium">
                        Giriş Yap
                    </a>
                    <a href="admin/company-setup.php" 
                       class="w-full border border-blue-600 text-blue-600 py-3 px-6 rounded-lg hover:bg-blue-50 transition-colors text-center block">
                        Yeni Şirket Kayıt
                    </a>
                </div>
            </div>

            <!-- Employee Login -->
            <div class="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-shadow">
                <div class="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <span class="text-green-600 text-2xl">👤</span>
                </div>
                <h3 class="text-xl font-bold text-gray-900 text-center mb-4">Personel Girişi</h3>
                <p class="text-gray-600 text-center mb-6">
                    Kişisel devam kayıtlarınızı görüntüleyin ve self servis işlemlerinizi yapın.
                </p>
                <div class="space-y-3">
                    <a href="auth/employee-login.php" 
                       class="w-full bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors text-center block font-medium">
                        Giriş Yap
                    </a>
                    <a href="qr/qr-reader.php" 
                       class="w-full border border-green-600 text-green-600 py-3 px-6 rounded-lg hover:bg-green-50 transition-colors text-center block">
                        QR Kod Okut
                    </a>
                </div>
            </div>


        </div>

        <!-- Features -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            <div class="text-center">
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <span class="text-blue-600 text-xl">📱</span>
                </div>
                <h4 class="font-medium text-gray-900 mb-2">QR Kod Sistemi</h4>
                <p class="text-sm text-gray-600">Lokasyon bazlı devam takibi</p>
            </div>
            
            <div class="text-center">
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <span class="text-green-600 text-xl">📊</span>
                </div>
                <h4 class="font-medium text-gray-900 mb-2">Detaylı Raporlar</h4>
                <p class="text-sm text-gray-600">Kapsamlı analiz ve raporlama</p>
            </div>
            
            <div class="text-center">
                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <span class="text-purple-600 text-xl">🏢</span>
                </div>
                <h4 class="font-medium text-gray-900 mb-2">Multi-Tenant</h4>
                <p class="text-sm text-gray-600">Çoklu şirket desteği</p>
            </div>
            
            <div class="text-center">
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <span class="text-yellow-600 text-xl">📍</span>
                </div>
                <h4 class="font-medium text-gray-900 mb-2">GPS Doğrulama</h4>
                <p class="text-sm text-gray-600">Lokasyon bazlı güvenlik</p>
            </div>
        </div>

        <!-- System Status -->
        <div class="bg-white rounded-2xl shadow-lg p-8">
            <h3 class="text-xl font-bold text-gray-900 mb-6 text-center">Sistem Durumu</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="text-center">
                    <div class="w-3 h-3 bg-green-400 rounded-full mx-auto mb-2"></div>
                    <p class="text-sm font-medium text-gray-900">Veritabanı</p>
                    <p class="text-xs text-gray-600">Çevrimiçi</p>
                </div>
                
                <div class="text-center">
                    <div class="w-3 h-3 bg-green-400 rounded-full mx-auto mb-2"></div>
                    <p class="text-sm font-medium text-gray-900">API Servisleri</p>
                    <p class="text-xs text-gray-600">Aktif</p>
                </div>
                
                <div class="text-center">
                    <div class="w-3 h-3 bg-green-400 rounded-full mx-auto mb-2"></div>
                    <p class="text-sm font-medium text-gray-900">QR Tarayıcı</p>
                    <p class="text-xs text-gray-600">Hazır</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white/80 backdrop-blur-sm border-t border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="text-center text-gray-600">
                <p>&copy; 2025 <?php echo APP_NAME; ?>. Tüm hakları saklıdır.</p>
                <p class="text-sm mt-2">Modern İnsan Kaynakları Yönetim Sistemi</p>
            </div>
        </div>
    </footer>
</body>
</html>