-- Final solution for 30716129672 employee issue
-- Since both employee_number and employee_code have UNIQUE constraints

-- Step 1: Find any existing records that might conflict
SELECT 'Records with employee_number 30716129672:' as check_type;
SELECT id, employee_number, first_name, last_name, employee_code, password
FROM employees WHERE employee_number = '30716129672';

SELECT 'Records with employee_code 30716129672:' as check_type;
SELECT id, employee_number, first_name, last_name, employee_code, password
FROM employees WHERE employee_code = '30716129672';

-- Step 2: Solution A - Update any existing record with employee_code 30716129672
UPDATE employees 
SET employee_number = '30716129672',
    first_name = 'Test',
    last_name = 'Personel',
    password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    status = 'active',
    is_active = 1
WHERE employee_code = '30716129672' 
AND employee_number != '30716129672';

-- Step 3: If no record exists, try minimal insert with auto-generated employee_code
INSERT INTO employees (employee_number, first_name, last_name, password, company_id, status, is_active)
SELECT '30716129672', 'Test', 'Personel', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 'active', 1
WHERE NOT EXISTS (
    SELECT 1 FROM employees WHERE employee_number = '30716129672'
);

-- Step 4: Verify the result
SELECT id, employee_number, first_name, last_name, employee_code, 
       CASE WHEN password IS NOT NULL AND password != '' THEN 'HAS PASSWORD' ELSE 'NO PASSWORD' END as password_status,
       status, is_active
FROM employees 
WHERE employee_number = '30716129672';

-- Step 5: Test password verification
-- Note: This needs to be done in PHP, not SQL
-- password_verify('123456', password_hash_from_database) should return true