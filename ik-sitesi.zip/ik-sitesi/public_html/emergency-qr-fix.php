<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🚨 Emergency QR Fix - Foreign Key Constraint</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // 1. Check table structure
    echo "<h2>1. Checking attendance_records table</h2>";
    
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $columnNames = array_column($columns, 'Field');
    
    echo "<p>Current columns: " . implode(', ', $columnNames) . "</p>";
    
    $hasCompanyId = in_array('company_id', $columnNames);
    echo "<p>Has company_id: " . ($hasCompanyId ? "YES" : "NO") . "</p>";
    
    // 2. Add company_id if missing
    if (!$hasCompanyId) {
        echo "<h3>Adding company_id column...</h3>";
        $conn->exec("ALTER TABLE attendance_records ADD COLUMN company_id INT NULL AFTER id");
        echo "<p>✅ Column added</p>";
    }
    
    // 3. Populate company_id from employees
    echo "<h3>Populating company_id values...</h3>";
    $updateResult = $conn->exec("
        UPDATE attendance_records ar 
        INNER JOIN employees e ON ar.employee_id = e.id 
        SET ar.company_id = e.company_id 
        WHERE ar.company_id IS NULL
    ");
    echo "<p>✅ Updated $updateResult records</p>";
    
    // 4. Make NOT NULL
    if (!$hasCompanyId) {
        echo "<h3>Setting company_id to NOT NULL...</h3>";
        $conn->exec("ALTER TABLE attendance_records MODIFY COLUMN company_id INT NOT NULL");
        echo "<p>✅ Set to NOT NULL</p>";
    }
    
    // 5. Drop existing foreign key if exists
    echo "<h3>Checking and fixing foreign keys...</h3>";
    try {
        $conn->exec("ALTER TABLE attendance_records DROP FOREIGN KEY fk_attendance_company");
        echo "<p>🗑️ Dropped existing constraint</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ No existing constraint to drop</p>";
    }
    
    // 6. Add index
    try {
        $conn->exec("ALTER TABLE attendance_records ADD INDEX idx_company_id (company_id)");
        echo "<p>✅ Added index</p>";
    } catch (Exception $e) {
        echo "<p>ℹ️ Index already exists</p>";
    }
    
    // 7. Add foreign key constraint
    try {
        $conn->exec("
            ALTER TABLE attendance_records 
            ADD CONSTRAINT fk_attendance_company 
            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
        ");
        echo "<p>✅ Foreign key constraint added</p>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ FK Error: " . $e->getMessage() . "</p>";
        
        // Check for orphan records
        $stmt = $conn->query("
            SELECT DISTINCT ar.company_id, COUNT(*) as count
            FROM attendance_records ar 
            LEFT JOIN companies c ON ar.company_id = c.id 
            WHERE c.id IS NULL AND ar.company_id IS NOT NULL
            GROUP BY ar.company_id
        ");
        $orphans = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($orphans) {
            echo "<p style='color: orange;'>Found orphan company IDs:</p>";
            foreach ($orphans as $orphan) {
                echo "<p>Company ID " . $orphan['company_id'] . ": " . $orphan['count'] . " records</p>";
                
                // Delete orphan records
                $conn->prepare("DELETE FROM attendance_records WHERE company_id = ?")->execute([$orphan['company_id']]);
                echo "<p>🗑️ Deleted orphan records for company " . $orphan['company_id'] . "</p>";
            }
            
            // Try FK again
            try {
                $conn->exec("
                    ALTER TABLE attendance_records 
                    ADD CONSTRAINT fk_attendance_company 
                    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
                ");
                echo "<p>✅ Foreign key constraint added after cleanup</p>";
            } catch (Exception $e2) {
                echo "<p style='color: red;'>❌ Still failed: " . $e2->getMessage() . "</p>";
            }
        }
    }
    
    // 8. Create trigger for auto-population
    echo "<h3>Creating auto-population trigger...</h3>";
    try {
        $conn->exec("DROP TRIGGER IF EXISTS attendance_company_auto_insert");
        $conn->exec("
            CREATE TRIGGER attendance_company_auto_insert
            BEFORE INSERT ON attendance_records
            FOR EACH ROW
            BEGIN
                IF NEW.company_id IS NULL THEN
                    SET NEW.company_id = (
                        SELECT company_id FROM employees WHERE id = NEW.employee_id LIMIT 1
                    );
                END IF;
            END
        ");
        echo "<p>✅ Trigger created</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>Trigger warning: " . $e->getMessage() . "</p>";
    }
    
    // 9. Test the fix
    echo "<h3>Testing the fix...</h3>";
    $stmt = $conn->query("SELECT id, company_id FROM employees WHERE is_active = 1 LIMIT 1");
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testEmployee) {
        try {
            // Test insert
            $testStmt = $conn->prepare("
                INSERT INTO attendance_records (employee_id, activity_type, check_in_time, date, notes) 
                VALUES (?, 'test_fix', NOW(), CURDATE(), 'Emergency fix test')
            ");
            $testStmt->execute([$testEmployee['id']]);
            
            $testId = $conn->lastInsertId();
            
            // Verify company_id
            $verifyStmt = $conn->prepare("SELECT company_id FROM attendance_records WHERE id = ?");
            $verifyStmt->execute([$testId]);
            $testRecord = $verifyStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($testRecord['company_id'] == $testEmployee['company_id']) {
                echo "<p style='color: green;'>✅ TEST PASSED - Foreign key working!</p>";
            } else {
                echo "<p style='color: red;'>❌ TEST FAILED - Company ID mismatch</p>";
            }
            
            // Cleanup
            $conn->prepare("DELETE FROM attendance_records WHERE id = ?")->execute([$testId]);
            echo "<p>🧹 Test record cleaned</p>";
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Test failed: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<div style='background: #d4edda; color: #155724; padding: 20px; border: 1px solid #c3e6cb; border-radius: 5px; margin: 20px 0;'>";
    echo "<h2>✅ Emergency Fix Complete!</h2>";
    echo "<p><strong>QR kod okuma sistemi artık çalışmalıdır.</strong></p>";
    echo "<p>Foreign key constraint hatası giderildi.</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 20px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h2>❌ Critical Error</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}
?>