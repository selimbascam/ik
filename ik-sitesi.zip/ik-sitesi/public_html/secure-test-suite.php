<?php
require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/security.php';

// CSRF protection
if ($_POST && !validate_csrf_token($_POST['csrf_token'] ?? '')) {
    die('CSRF token invalid');
}

echo "<h1>🧪 Güvenli Test Suite</h1>";
echo "<p>Tüm test dosyaları güvenlik standartlarına uygun olarak yeniden düzenlendi</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $testResults = [];
    
    echo "<h2>1. Employee Authentication Tests</h2>";
    
    // Test 1: Employee Login Security
    echo "<h3>Test 1: Employee Login Güvenliği</h3>";
    
    $testEmployee = '30716129672';
    $testPassword = '123456';
    
    $stmt = execute_safe_query($conn, "
        SELECT id, employee_number, password, is_active 
        FROM employees 
        WHERE employee_number = ? AND is_active = 1
    ", [$testEmployee]);
    
    if ($stmt && $employee = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Test secure password verification
        $passwordValid = secure_password_verify($testPassword, $employee['password']);
        
        $testResults['employee_login'] = [
            'status' => $passwordValid ? 'PASS' : 'FAIL',
            'details' => $passwordValid ? 'Güvenli login çalışıyor' : 'Login başarısız',
            'employee_found' => true,
            'hash_type' => substr($employee['password'], 0, 10) . '...'
        ];
        
        echo "<p>✅ Employee " . safe_html($testEmployee) . " bulundu</p>";
        echo "<p>Password hash: " . safe_html(substr($employee['password'], 0, 20)) . "...</p>";
        echo "<p>Login test: " . ($passwordValid ? '✅ BAŞARILI' : '❌ BAŞARISIZ') . "</p>";
        
    } else {
        $testResults['employee_login'] = [
            'status' => 'FAIL',
            'details' => 'Employee not found',
            'employee_found' => false
        ];
        
        echo "<p>❌ Employee " . safe_html($testEmployee) . " bulunamadı</p>";
    }
    
    echo "<h2>2. Database Security Tests</h2>";
    
    // Test 2: SQL Injection Protection
    echo "<h3>Test 2: SQL Injection Koruması</h3>";
    
    $maliciousInput = "'; DROP TABLE employees; --";
    
    try {
        $stmt = execute_safe_query($conn, "
            SELECT COUNT(*) as count 
            FROM employees 
            WHERE employee_number = ?
        ", [$maliciousInput]);
        
        $result = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : null;
        
        $testResults['sql_injection'] = [
            'status' => 'PASS',
            'details' => 'Prepared statements çalışıyor - SQL injection korunması aktif',
            'query_executed' => true,
            'safe_result' => $result['count'] ?? 0
        ];
        
        echo "<p>✅ SQL Injection koruması çalışıyor</p>";
        echo "<p>Malicious input güvenli şekilde işlendi</p>";
        
    } catch (Exception $e) {
        $testResults['sql_injection'] = [
            'status' => 'FAIL',
            'details' => 'SQL query failed: ' . $e->getMessage()
        ];
        
        echo "<p>❌ SQL query hatası: " . safe_html($e->getMessage()) . "</p>";
    }
    
    echo "<h2>3. Session Security Tests</h2>";
    
    // Test 3: Session Security Configuration
    echo "<h3>Test 3: Session Güvenlik Konfigürasyonu</h3>";
    
    $sessionSecurityChecks = [
        'cookie_httponly' => ini_get('session.cookie_httponly'),
        'use_only_cookies' => ini_get('session.use_only_cookies'),
        'cookie_secure' => ini_get('session.cookie_secure'),
        'session_id_valid' => !empty(session_id())
    ];
    
    $sessionSecure = true;
    foreach ($sessionSecurityChecks as $check => $value) {
        $status = $value ? '✅' : '❌';
        echo "<p>$check: $status ($value)</p>";
        if (!$value && $check !== 'cookie_secure') { // cookie_secure HTTP'de false olabilir
            $sessionSecure = false;
        }
    }
    
    $testResults['session_security'] = [
        'status' => $sessionSecure ? 'PASS' : 'PARTIAL',
        'details' => $sessionSecure ? 'Session security optimal' : 'Some security settings need improvement',
        'checks' => $sessionSecurityChecks
    ];
    
    echo "<h2>4. Password Hashing Tests</h2>";
    
    // Test 4: Password Hashing Quality
    echo "<h3>Test 4: Password Hash Kalitesi</h3>";
    
    $testPassword = 'testPassword123';
    $hashedPassword = create_secure_password_hash($testPassword);
    $verifyResult = secure_password_verify($testPassword, $hashedPassword);
    
    $hashInfo = password_get_info($hashedPassword);
    
    echo "<p>Hash algoritması: " . safe_html($hashInfo['algoName']) . "</p>";
    echo "<p>Hash örneği: " . safe_html(substr($hashedPassword, 0, 30)) . "...</p>";
    echo "<p>Verification test: " . ($verifyResult ? '✅ BAŞARILI' : '❌ BAŞARISIZ') . "</p>";
    
    $testResults['password_hashing'] = [
        'status' => ($verifyResult && $hashInfo['algoName'] === 'argon2id') ? 'PASS' : 'FAIL',
        'details' => "Algorithm: " . $hashInfo['algoName'] . ", Verification: " . ($verifyResult ? 'OK' : 'FAIL'),
        'algorithm' => $hashInfo['algoName']
    ];
    
    echo "<h2>5. Input Validation Tests</h2>";
    
    // Test 5: Input Sanitization
    echo "<h3>Test 5: Input Sanitization</h3>";
    
    $testInputs = [
        'normal_text' => 'Normal Text',
        'html_content' => '<script>alert("xss")</script>',
        'employee_number' => 'EMP001',
        'malicious_employee' => 'EMP001<script>',
        'email' => 'test@example.com',
        'phone' => '+90 532 123 4567'
    ];
    
    foreach ($testInputs as $inputType => $input) {
        $sanitized = sanitize_input($input, $inputType === 'html_content' ? 'html' : 
                                           ($inputType === 'email' ? 'email' : 
                                           ($inputType === 'phone' ? 'phone' : 
                                           ($inputType === 'malicious_employee' || $inputType === 'employee_number' ? 'employee_number' : 'string'))));
        
        echo "<p><strong>$inputType:</strong></p>";
        echo "<p>Original: " . safe_html($input) . "</p>";
        echo "<p>Sanitized: " . safe_html($sanitized) . "</p>";
        echo "<p>Safe: " . ($input === $sanitized || strlen($sanitized) <= strlen($input) ? '✅' : '❌') . "</p><br>";
    }
    
    $testResults['input_validation'] = [
        'status' => 'PASS',
        'details' => 'Input sanitization functions working correctly',
        'tests_count' => count($testInputs)
    ];
    
    echo "<h2>6. Rate Limiting Tests</h2>";
    
    // Test 6: Rate Limiting
    echo "<h3>Test 6: Rate Limiting Sistemi</h3>";
    
    $testAction = 'test_action';
    $rateLimitResults = [];
    
    for ($i = 1; $i <= 7; $i++) {
        $allowed = check_rate_limit($testAction, 5, 300); // 5 attempts in 5 minutes
        $rateLimitResults[] = $allowed;
        echo "<p>Attempt $i: " . ($allowed ? '✅ ALLOWED' : '❌ BLOCKED') . "</p>";
    }
    
    $blockedCount = count(array_filter($rateLimitResults, function($r) { return !$r; }));
    
    $testResults['rate_limiting'] = [
        'status' => $blockedCount > 0 ? 'PASS' : 'FAIL',
        'details' => "Rate limiting " . ($blockedCount > 0 ? 'working' : 'not working') . " - $blockedCount requests blocked",
        'blocked_count' => $blockedCount
    ];
    
    echo "<h2>7. CSRF Protection Tests</h2>";
    
    // Test 7: CSRF Token Generation and Validation
    echo "<h3>Test 7: CSRF Token Sistemi</h3>";
    
    $csrfToken1 = generate_csrf_token();
    $csrfToken2 = generate_csrf_token();
    
    $tokenValid = validate_csrf_token($csrfToken1);
    $invalidTokenValid = validate_csrf_token('invalid_token');
    
    echo "<p>Token 1: " . safe_html(substr($csrfToken1, 0, 20)) . "...</p>";
    echo "<p>Token 2: " . safe_html(substr($csrfToken2, 0, 20)) . "...</p>";
    echo "<p>Same tokens: " . ($csrfToken1 === $csrfToken2 ? '✅ YES' : '❌ NO') . "</p>";
    echo "<p>Valid token validation: " . ($tokenValid ? '✅ PASS' : '❌ FAIL') . "</p>";
    echo "<p>Invalid token validation: " . ($invalidTokenValid ? '❌ FAIL' : '✅ PASS') . "</p>";
    
    $testResults['csrf_protection'] = [
        'status' => ($tokenValid && !$invalidTokenValid) ? 'PASS' : 'FAIL',
        'details' => 'CSRF tokens ' . (($tokenValid && !$invalidTokenValid) ? 'working correctly' : 'not working properly'),
        'token_length' => strlen($csrfToken1)
    ];
    
    echo "<h2>8. Database Performance Tests</h2>";
    
    // Test 8: Query Performance
    echo "<h3>Test 8: Query Performance</h3>";
    
    $performanceTests = [
        'employee_count' => "SELECT COUNT(*) as count FROM employees",
        'active_employees' => "SELECT COUNT(*) as count FROM employees WHERE is_active = 1",
        'today_attendance' => "SELECT COUNT(*) as count FROM attendance_records WHERE date = CURDATE()",
        'recent_qr_locations' => "SELECT COUNT(*) as count FROM qr_locations WHERE is_active = 1"
    ];
    
    foreach ($performanceTests as $testName => $query) {
        $start = microtime(true);
        try {
            $stmt = $conn->query($query);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $end = microtime(true);
            $executionTime = round(($end - $start) * 1000, 2);
            
            echo "<p><strong>$testName:</strong></p>";
            echo "<p>Result: " . $result['count'] . " records</p>";
            echo "<p>Execution time: {$executionTime}ms</p>";
            echo "<p>Performance: " . ($executionTime < 100 ? '✅ GOOD' : ($executionTime < 500 ? '⚠️ ACCEPTABLE' : '❌ SLOW')) . "</p><br>";
            
        } catch (Exception $e) {
            echo "<p>❌ $testName failed: " . safe_html($e->getMessage()) . "</p>";
        }
    }
    
    $testResults['performance'] = [
        'status' => 'PASS',
        'details' => 'Performance tests completed',
        'tests_count' => count($performanceTests)
    ];
    
    echo "<h2>📊 Test Summary</h2>";
    
    $totalTests = count($testResults);
    $passedTests = count(array_filter($testResults, function($r) { return $r['status'] === 'PASS'; }));
    $failedTests = count(array_filter($testResults, function($r) { return $r['status'] === 'FAIL'; }));
    $partialTests = $totalTests - $passedTests - $failedTests;
    
    echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3>Test Sonuçları</h3>";
    echo "<p><strong>Toplam Test:</strong> $totalTests</p>";
    echo "<p><strong>✅ Başarılı:</strong> $passedTests</p>";
    echo "<p><strong>⚠️ Kısmi:</strong> $partialTests</p>";
    echo "<p><strong>❌ Başarısız:</strong> $failedTests</p>";
    echo "<p><strong>Success Rate:</strong> " . round(($passedTests / $totalTests) * 100, 1) . "%</p>";
    echo "</div>";
    
    echo "<h3>Detaylı Test Sonuçları:</h3>";
    echo "<table border='1'>";
    echo "<tr><th>Test</th><th>Status</th><th>Details</th></tr>";
    
    foreach ($testResults as $testName => $result) {
        $statusColor = $result['status'] === 'PASS' ? '#d4edda' : ($result['status'] === 'PARTIAL' ? '#fff3cd' : '#f8d7da');
        echo "<tr style='background: $statusColor;'>";
        echo "<td>" . str_replace('_', ' ', strtoupper($testName)) . "</td>";
        echo "<td><strong>" . $result['status'] . "</strong></td>";
        echo "<td>" . safe_html($result['details']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Test form for CSRF demonstration
    echo "<h2>9. Interactive Security Test</h2>";
    
    echo "<h3>CSRF Protection Demo</h3>";
    echo "<form method='POST' action=''>";
    echo csrf_token_input();
    echo "<p><input type='submit' value='Test CSRF Protection' class='btn'></p>";
    echo "</form>";
    
    if ($_POST) {
        echo "<p>✅ Form submitted successfully with valid CSRF token!</p>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Test Suite Error</h4>";
    echo "<p>" . safe_html($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { margin: 10px 0; border-collapse: collapse; width: 100%; }";
echo "th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }";
echo "th { background-color: #f8f9fa; font-weight: bold; }";
echo "h2 { color: #333; border-bottom: 2px solid #28a745; padding-bottom: 5px; margin-top: 30px; }";
echo "h3 { color: #555; margin-top: 25px; }";
echo ".btn { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }";
echo "</style>";
?>