<?php
echo "<h2>🚨 Acil Site Düzeltme</h2>";

echo "<h3>❌ Tespit Edilen Sorunlar</h3>";
echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
echo "<p><strong>1. Session Config Çakışması:</strong></p>";
echo "<p>includes/config.php satır 6'da session ayarları session başladıktan sonra yapılıyor</p>";
echo "<p><strong>Hostinger Hatası:</strong> 'Session ini settings cannot be changed when a session is active'</p>";
echo "</div>";

echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
echo "<p><strong>2. APP_NAME Tanımlı Değil:</strong></p>";
echo "<p>index.php'de kullanılan APP_NAME constant tanımlanmamış</p>";
echo "</div>";

echo "<h3>✅ Hızlı Çözüm</h3>";
echo "<p>Aşağıdaki düzeltilmiş dosyaları kullanın:</p>";

echo "<h4>📄 includes/config.php (düzeltilmiş)</h4>";
echo "<textarea style='width: 100%; height: 300px; font-family: monospace;'>";
$fixed_config = '<?php
// APP_NAME tanımla
define("APP_NAME", "SZB İK Takip");

// Timezone configuration
date_default_timezone_set("Europe/Istanbul");

// Error reporting (development mode)
error_reporting(E_ALL);
ini_set("display_errors", 1);

// Session configuration - SESSION BAŞLAMADAN ÖNCE
if (session_status() === PHP_SESSION_NONE) {
    ini_set("session.gc_maxlifetime", 3600);
    ini_set("session.cookie_lifetime", 3600);
    session_start();
}

// Database constants (fallback - not used with new Database class)
define("DB_HOST", "localhost");
define("DB_NAME", "u978874874_ik");
define("DB_USER", "u978874874_ik");
define("DB_PASS", "Szb2013@+-!");

// Function to check if user is authenticated
function isAuthenticated($userType = null) {
    if (!isset($_SESSION["user_id"]) && !isset($_SESSION["employee_id"]) && !isset($_SESSION["company_id"])) {
        return false;
    }
    
    if ($userType && isset($_SESSION["user_type"])) {
        return $_SESSION["user_type"] === $userType;
    }
    
    return true;
}

// Function to redirect if not authenticated
function requireAuth($userType = null, $redirectTo = "/login.php") {
    if (!isAuthenticated($userType)) {
        header("Location: $redirectTo");
        exit;
    }
}

// Get base URL
function getBaseUrl() {
    $protocol = isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on" ? "https" : "http";
    $host = $_SERVER["HTTP_HOST"];
    $path = dirname($_SERVER["SCRIPT_NAME"]);
    return $protocol . "://" . $host . $path;
}
?>';

echo htmlspecialchars($fixed_config);
echo "</textarea>";

echo "<h4>🎯 Test Adımları</h4>";
echo "<ol>";
echo "<li>Yukarıdaki kodu <strong>includes/config.php</strong>'ye yapıştırın</li>";
echo "<li>Ana sayfayı yenileyin - <strong>PHP hatası gitmeli</strong></li>";  
echo "<li><strong>auth/company-login.php</strong> test edin</li>";
echo "<li>Login: <strong>info@mobofis.com</strong> / <strong>szb123</strong></li>";
echo "</ol>";

echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<h4>🔧 Alternatif Hızlı Fix</h4>";
echo "<p>Eğer config düzeltmesi işe yaramazsa:</p>";
echo "<ol>";
echo "<li>includes/config.php dosyasını tamamen silin</li>";
echo "<li>Basit bir config oluşturun:</li>";
echo "</ol>";
echo "<pre style='background: #f8f9fa; padding: 10px;'>";
echo htmlspecialchars('<?php
define("APP_NAME", "SZB İK Takip");
session_start();
date_default_timezone_set("Europe/Istanbul");
?>');
echo "</pre>";
echo "</div>";

echo "<h3>🔗 Test Linkleri</h3>";
echo "<div>";
echo "<a href='index.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Ana Sayfa Test</a>";
echo "<a href='auth/company-login.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Company Login</a>";
echo "<a href='test-connection.php' style='background: #ffc107; color: black; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>DB Test</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
textarea { font-size: 12px; }
</style>