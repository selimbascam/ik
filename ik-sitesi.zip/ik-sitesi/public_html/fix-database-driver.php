<?php
echo "<h2>🔧 Database Driver Fix</h2>";

echo "<h3>📊 PHP Extensions Check</h3>";

$extensions = [
    'PDO' => extension_loaded('pdo'),
    'PDO MySQL' => extension_loaded('pdo_mysql'), 
    'MySQLi' => extension_loaded('mysqli'),
    'MySQL (legacy)' => function_exists('mysql_connect')
];

foreach ($extensions as $ext => $loaded) {
    $status = $loaded ? '✅ Yüklü' : '❌ Eksik';
    $color = $loaded ? 'green' : 'red';
    echo "<p style='color: $color;'>$ext: $status</p>";
}

echo "<h3>🔧 Driver Fix Test</h3>";

// Test original database class
echo "<h4>1. Orijinal Database Class</h4>";
try {
    require_once 'includes/database.php';
    $db = new Database();
    $conn = $db->getConnection();
    echo "<p style='color: green;'>✅ Orijinal database class çalışıyor</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Orijinal: " . $e->getMessage() . "</p>";
}

// Test Hostinger optimized class
echo "<h4>2. Hostinger Optimized Class</h4>";
try {
    require_once 'includes/database-hostinger.php';
    $db = new Database();
    $conn = $db->getConnection();
    echo "<p style='color: green;'>✅ Hostinger optimized class çalışıyor</p>";
    
    // Test query
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(defined('PDO::FETCH_COLUMN') ? PDO::FETCH_COLUMN : 7);
    echo "<p style='color: green;'>✅ Query test başarılı - " . count($tables) . " tablo bulundu</p>";
    
    // Test companies table
    $companiesTable = in_array('şirketler', $tables) ? 'şirketler' : 
                     (in_array('companies', $tables) ? 'companies' : null);
    
    if ($companiesTable) {
        echo "<p style='color: green;'>✅ Companies table: $companiesTable</p>";
        
        // Test data
        $stmt = $conn->query("SELECT COUNT(*) as count FROM `$companiesTable`");
        $result = $stmt->fetch();
        echo "<p style='color: green;'>✅ Data test: {$result['count']} companies</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Hostinger: " . $e->getMessage() . "</p>";
}

echo "<h3>💡 Çözüm</h3>";
echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<p><strong>Database driver sorunu tespit edildi.</strong></p>";
echo "<p>Hostinger optimized database class oluşturuldu:</p>";
echo "<ul>";
echo "<li>✅ PDO MySQL desteği (birincil)</li>";
echo "<li>✅ MySQLi fallback (ikincil)</li>"; 
echo "<li>✅ PDO uyumluluk wrapper'ı</li>";
echo "<li>✅ Türkçe tablo desteği</li>";
echo "</ul>";
echo "</div>";

echo "<h3>🔄 Database Class Değiştirme</h3>";
echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<p><strong>Şu adımları uygulayın:</strong></p>";
echo "<ol>";
echo "<li><code>includes/database.php</code> dosyasını yedekleyin</li>";
echo "<li><code>includes/database-hostinger.php</code> içeriğini <code>includes/database.php</code>'ye kopyalayın</li>";
echo "<li>Sayfayı yenileyin ve test edin</li>";
echo "</ol>";
echo "</div>";

echo "<h3>🔗 Test Linkleri</h3>";
echo "<div>";
echo "<a href='turkish-table-login-test.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Turkish Login Test</a>";
echo "<a href='auth/company-login-fixed.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Company Login</a>";
echo "<a href='test-connection.php' style='background: #ffc107; color: black; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Connection Test</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
code { background: #f1f1f1; padding: 2px 6px; border-radius: 3px; }
</style>