<?php
/**
 * QR Davranış Sistemi Ayrıntılı Debug
 */
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h1>🔍 QR Davranış Sistemi Debug</h1>";
    
    // 1. SZB30912 şirketi analizi
    echo "<h2>1. SZB30912 Şirket Analizi</h2>";
    $stmt = $conn->prepare("SELECT id, company_name, company_code FROM companies WHERE company_code = 'SZB30912'");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        echo "<p style='color: red;'>❌ SZB30912 şirketi bulunamadı!</p>";
        exit;
    }
    
    $companyId = $company['id'];
    echo "<p>✅ Şirket: {$company['company_name']} (ID: $companyId, Kod: {$company['company_code']})</p>";
    
    // 2. QR Lokasyonları detay analizi
    echo "<h2>2. QR Lokasyonları Detay Analizi</h2>";
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($locations)) {
        echo "<p style='color: red;'>❌ SZB30912 için QR lokasyonu yok!</p>";
    } else {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>İsim</th><th>QR Kod</th><th>Gate Behavior</th><th>Location Type</th><th>Aktif</th></tr>";
        foreach ($locations as $loc) {
            $behavior = $loc['gate_behavior'] ?: 'NULL';
            $color = 'black';
            if ($behavior === 'work_start') $color = 'green';
            elseif ($behavior === 'work_end') $color = 'blue';
            elseif ($behavior === 'break_toggle') $color = 'orange';
            elseif ($behavior === 'NULL' || $behavior === 'user_choice') $color = 'red';
            
            echo "<tr>";
            echo "<td>{$loc['id']}</td>";
            echo "<td><strong>{$loc['name']}</strong></td>";
            echo "<td>{$loc['qr_code']}</td>";
            echo "<td style='color: $color; font-weight: bold;'>$behavior</td>";
            echo "<td>{$loc['location_type']}</td>";
            echo "<td>" . ($loc['is_active'] ? 'Evet' : 'Hayır') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // 3. Selim kullanıcısı analizi
    echo "<h2>3. Selim Kullanıcısı Analizi</h2>";
    $stmt = $conn->prepare("SELECT e.*, c.company_name FROM employees e JOIN companies c ON e.company_id = c.id WHERE e.first_name LIKE '%selim%' OR e.last_name LIKE '%selim%'");
    $stmt->execute();
    $selim = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$selim) {
        echo "<p style='color: red;'>❌ Selim kullanıcısı bulunamadı!</p>";
    } else {
        echo "<p>✅ Selim: {$selim['first_name']} {$selim['last_name']} (ID: {$selim['id']}, Şirket: {$selim['company_name']})</p>";
        
        // Selim'in son QR aktivitelerini kontrol et
        $stmt = $conn->prepare("SELECT ar.*, qr.name as qr_name, qr.gate_behavior FROM attendance_records ar LEFT JOIN qr_locations qr ON ar.qr_location_id = qr.id WHERE ar.employee_id = ? ORDER BY ar.created_at DESC LIMIT 5");
        $stmt->execute([$selim['id']]);
        $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($activities)) {
            echo "<h3>Son 5 QR Aktivitesi:</h3>";
            echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr><th>Tarih</th><th>QR Lokasyon</th><th>Gate Behavior</th><th>Aktivite Türü</th><th>Durum</th></tr>";
            foreach ($activities as $act) {
                echo "<tr>";
                echo "<td>{$act['created_at']}</td>";
                echo "<td>{$act['qr_name']}</td>";
                echo "<td>{$act['gate_behavior']}</td>";
                echo "<td>{$act['activity_type']}</td>";
                echo "<td>{$act['status']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
    
    // 4. QR Reader algoritması simülasyonu
    echo "<h2>4. QR Reader Algoritması Simülasyonu</h2>";
    
    foreach ($locations as $location) {
        echo "<div style='border: 1px solid #ccc; margin: 10px 0; padding: 10px;'>";
        echo "<h3>QR: '{$location['name']}'</h3>";
        
        // Türkçe karakter uyumlu küçük harf dönüşümü
        $qrName = mb_strtolower(trim($location['name']), 'UTF-8');
        $qrName = str_replace(['İ', 'I'], 'i', $qrName);
        $qrName = str_replace(['Ğ'], 'ğ', $qrName);
        $qrName = str_replace(['Ü'], 'ü', $qrName);
        $qrName = str_replace(['Ş'], 'ş', $qrName);
        $qrName = str_replace(['Ö'], 'ö', $qrName);
        $qrName = str_replace(['Ç'], 'ç', $qrName);
        
        echo "<p><strong>Normalize İsim:</strong> '$qrName'</p>";
        echo "<p><strong>DB Gate Behavior:</strong> " . ($location['gate_behavior'] ?: 'NULL') . "</p>";
        
        // Algoritma testi
        if (!empty($location['gate_behavior']) && $location['gate_behavior'] !== 'user_choice') {
            echo "<p style='color: green;'><strong>✅ VERİTABANI KULLANILIYOR:</strong> {$location['gate_behavior']}</p>";
        } else {
            echo "<p style='color: orange;'><strong>⚠️ İSİM ANALİZİ:</strong></p>";
            
            if (strpos($qrName, 'mola') !== false) {
                echo "<p style='color: blue;'>→ 'mola' kelimesi bulundu → break_toggle</p>";
            } elseif (strpos($qrName, 'giriş') !== false || strpos($qrName, 'giris') !== false) {
                echo "<p style='color: blue;'>→ 'giriş' kelimesi bulundu → work_start</p>";
            } elseif (strpos($qrName, 'çıkış') !== false || strpos($qrName, 'cikis') !== false) {
                echo "<p style='color: blue;'>→ 'çıkış' kelimesi bulundu → work_end</p>";
            } else {
                echo "<p style='color: red;'>→ Hiçbir kelime bulunamadı → user_choice (VARSAYILAN)</p>";
            }
        }
        echo "</div>";
    }
    
    // 5. Çözüm önerisi
    echo "<h2>5. Çözüm Önerisi</h2>";
    echo "<div style='background: #fff3cd; padding: 15px; border: 1px solid #ffeaa7; border-radius: 5px;'>";
    echo "<h3>🔧 Hemen Düzelt:</h3>";
    
    $fixes = [
        'giriş' => 'work_start',
        'çıkış' => 'work_end',
        'mola' => 'break_toggle'
    ];
    
    foreach ($locations as $location) {
        $name = mb_strtolower(trim($location['name']), 'UTF-8');
        $expectedBehavior = 'user_choice';
        
        foreach ($fixes as $keyword => $behavior) {
            if (strpos($name, $keyword) !== false) {
                $expectedBehavior = $behavior;
                break;
            }
        }
        
        if ($location['gate_behavior'] !== $expectedBehavior) {
            echo "<p><strong>DÜZELTİLMELİ:</strong> '{$location['name']}' → '$expectedBehavior'</p>";
        }
    }
    echo "</div>";
    
    // 6. Otomatik düzeltme butonu
    echo "<br><h2>6. Otomatik Düzeltme</h2>";
    echo "<form method='post'>";
    echo "<button type='submit' name='auto_fix' style='background: #28a745; color: white; padding: 15px 30px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;'>🔧 OTOMATİK DÜZELT</button>";
    echo "</form>";
    
    // Otomatik düzeltme işlemi
    if (isset($_POST['auto_fix'])) {
        echo "<div style='background: #d4edda; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px; margin-top: 10px;'>";
        echo "<h3>🔧 Otomatik Düzeltme Sonuçları:</h3>";
        
        foreach ($locations as $location) {
            $name = mb_strtolower(trim($location['name']), 'UTF-8');
            $newBehavior = 'user_choice';
            
            foreach ($fixes as $keyword => $behavior) {
                if (strpos($name, $keyword) !== false) {
                    $newBehavior = $behavior;
                    break;
                }
            }
            
            if ($location['gate_behavior'] !== $newBehavior) {
                $updateStmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE id = ?");
                $updateStmt->execute([$newBehavior, $location['id']]);
                echo "<p>✅ '{$location['name']}' düzeltildi: {$location['gate_behavior']} → <strong>$newBehavior</strong></p>";
            } else {
                echo "<p>✓ '{$location['name']}' zaten doğru: <strong>$newBehavior</strong></p>";
            }
        }
        
        echo "<p style='margin-top: 15px; font-weight: bold; color: #155724;'>🎯 Tüm düzeltmeler tamamlandı! Şimdi QR okutma testi yapabilirsiniz.</p>";
        echo "</div>";
        
        // Sayfayı yenile
        echo "<script>setTimeout(function(){ window.location.reload(); }, 2000);</script>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Hata: " . $e->getMessage() . "</p>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
table { margin: 10px 0; }
th, td { padding: 8px; text-align: left; }
th { background-color: #f8f9fa; }
</style>