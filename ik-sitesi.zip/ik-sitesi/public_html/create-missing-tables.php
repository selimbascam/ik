<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<div style='max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif;'>";
echo "<h1 style='background: #4CAF50; color: white; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>🔧 Eksik Tabloları Oluştur</h1>";
echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";

echo "<p><strong>device_records ve employee_devices tablolarını MySQL veritabanına ekliyoruz...</strong></p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📋 1. Mevcut Durumu Kontrol Et</h2>";
    $stmt = $conn->query("SHOW TABLES");
    $existingTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p>Veritabanında bulunan tablolar: " . count($existingTables) . "</p>";
    
    $deviceTablesExist = [
        'device_records' => in_array('device_records', $existingTables),
        'employee_devices' => in_array('employee_devices', $existingTables)
    ];
    
    foreach ($deviceTablesExist as $tableName => $exists) {
        $status = $exists ? "✅ Mevcut" : "❌ Eksik";
        $color = $exists ? "green" : "red";
        echo "<p style='color: $color;'><strong>$tableName:</strong> $status</p>";
    }
    echo "</div>";
    
    // Create device_records table
    if (!$deviceTablesExist['device_records']) {
        echo "<h2>🛠️ 2. device_records Tablosunu Oluştur</h2>";
        
        $sql = "CREATE TABLE `device_records` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `employee_id` int(11) NOT NULL,
            `device_fingerprint` varchar(255) DEFAULT NULL,
            `device_platform` varchar(100) DEFAULT NULL,
            `device_browser` varchar(100) DEFAULT NULL,
            `device_ip_address` varchar(45) DEFAULT NULL,
            `device_user_agent` text DEFAULT NULL,
            `device_mac_address` varchar(17) DEFAULT NULL,
            `last_seen` timestamp NOT NULL DEFAULT current_timestamp(),
            `is_active` tinyint(1) DEFAULT 1,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `idx_employee_device` (`employee_id`),
            KEY `idx_device_fingerprint` (`device_fingerprint`),
            CONSTRAINT `fk_device_records_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ <strong>device_records</strong> tablosu başarıyla oluşturuldu!";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "⚠️ device_records tablosu zaten mevcut";
        echo "</div>";
    }
    
    // Create employee_devices table
    if (!$deviceTablesExist['employee_devices']) {
        echo "<h2>🛠️ 3. employee_devices Tablosunu Oluştur</h2>";
        
        $sql = "CREATE TABLE `employee_devices` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `employee_id` int(11) NOT NULL,
            `device_fingerprint` varchar(255) DEFAULT NULL,
            `device_name` varchar(100) DEFAULT NULL,
            `device_type` varchar(50) DEFAULT NULL,
            `is_trusted` tinyint(1) DEFAULT 0,
            `last_used` timestamp NOT NULL DEFAULT current_timestamp(),
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            UNIQUE KEY `device_fingerprint` (`device_fingerprint`),
            KEY `idx_employee_devices` (`employee_id`),
            CONSTRAINT `fk_employee_devices_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ <strong>employee_devices</strong> tablosu başarıyla oluşturuldu!";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "⚠️ employee_devices tablosu zaten mevcut";
        echo "</div>";
    }
    
    // Test the tables
    echo "<h2>🧪 4. Tabloları Test Et</h2>";
    
    try {
        // Test device_records
        $stmt = $conn->prepare("SELECT COUNT(*) FROM device_records");
        $stmt->execute();
        $deviceRecordsCount = $stmt->fetchColumn();
        
        // Test employee_devices
        $stmt = $conn->prepare("SELECT COUNT(*) FROM employee_devices");
        $stmt->execute();
        $employeeDevicesCount = $stmt->fetchColumn();
        
        // Test the safety check query from employee management
        $stmt = $conn->prepare("
            SELECT 
                (SELECT COUNT(*) FROM attendance_records WHERE employee_id = 1) +
                (SELECT COUNT(*) FROM employee_shifts WHERE employee_id = 1) +
                (SELECT COUNT(*) FROM device_records WHERE employee_id = 1) +
                (SELECT COUNT(*) FROM employee_devices WHERE employee_id = 1) as total_related
        ");
        $stmt->execute();
        $safetyCheckResult = $stmt->fetchColumn();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h3>✅ Tüm Testler Başarılı!</h3>";
        echo "<ul>";
        echo "<li><strong>device_records:</strong> $deviceRecordsCount kayıt (erişilebilir)</li>";
        echo "<li><strong>employee_devices:</strong> $employeeDevicesCount kayıt (erişilebilir)</li>";
        echo "<li><strong>Güvenlik kontrolü:</strong> Çalışıyor (sonuç: $safetyCheckResult)</li>";
        echo "</ul>";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Test hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    echo "<h2>🎉 İşlem Tamamlandı!</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>Yapılan İşlemler:</h3>";
    echo "<ul>";
    echo "<li>✅ <strong>device_records</strong> tablosu oluşturuldu</li>";
    echo "<li>✅ <strong>employee_devices</strong> tablosu oluşturuldu</li>";
    echo "<li>✅ Foreign key bağlantıları kuruldu</li>";
    echo "<li>✅ Index'ler eklendi (performans için)</li>";
    echo "<li>✅ Personel yönetimi artık hatasız çalışacak</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='admin/employee-management.php' style='background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>👥 Personel Yönetimi Test Et</a>";
    echo "<a href='check-mysql-database.php' style='background: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🗄️ Veritabanı Kontrol</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Kritik Hata</h3>";
    echo "<p>Veritabanı hatası: " . $e->getMessage() . "</p>";
    echo "<p><strong>Çözüm:</strong> Veritabanı bağlantınızı kontrol edin ve yeniden deneyin.</p>";
    echo "</div>";
}

echo "</div>";
echo "</div>";
?>