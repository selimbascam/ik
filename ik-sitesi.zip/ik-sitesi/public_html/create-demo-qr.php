<?php
/**
 * DEMO001 şirketi için QR lokasyonları oluşturucu
 */
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Autocommit modunu etkinleştir (transaction hatalarını önlemek için)
    $conn->setAttribute(PDO::ATTR_AUTOCOMMIT, true);
    
    // DEMO001 şirketi ID'sini bul veya oluştur
    $stmt = $conn->prepare("SELECT id FROM companies WHERE company_code = 'DEMO001'");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        // DEMO001 şirketini oluştur
        $stmt = $conn->prepare("INSERT INTO companies (company_code, company_name, address, phone, email, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute(['DEMO001', 'Demo Şirketi', 'Demo Adres', '555-1234', 'demo@test.com']);
        $companyId = $conn->lastInsertId();
        echo "✅ DEMO001 şirketi oluşturuldu (ID: $companyId)<br>";
    } else {
        $companyId = $company['id'];
        echo "✅ DEMO001 şirketi mevcut (ID: $companyId)<br>";
    }
    
    // gate_behavior kolonu kontrolü
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
    if ($stmt->rowCount() == 0) {
        $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(50) DEFAULT 'user_choice'");
        echo "✅ gate_behavior kolonu eklendi<br>";
    }
    
    // Mevcut QR lokasyonlarını kontrol et
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ?");
    $stmt->execute([$companyId]);
    $existingCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($existingCount > 0) {
        echo "⚠️ DEMO001 için $existingCount QR lokasyonu zaten mevcut<br>";
        
        // Mevcut lokasyonları listele
        $stmt = $conn->prepare("SELECT id, name, gate_behavior FROM qr_locations WHERE company_id = ? ORDER BY name");
        $stmt->execute([$companyId]);
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>Mevcut QR Lokasyonları:</h3><ul>";
        foreach ($locations as $loc) {
            echo "<li>ID: {$loc['id']}, İsim: {$loc['name']}, Davranış: {$loc['gate_behavior']}</li>";
        }
        echo "</ul>";
        
        // Davranışları güncelle
        $updates = [
            'giriş' => 'work_start',
            'çıkış' => 'work_end',
            'mola' => 'break_toggle',
            'mola giriş' => 'break_toggle'
        ];
        
        foreach ($locations as $location) {
            $name = mb_strtolower(trim($location['name']), 'UTF-8');
            $newBehavior = 'user_choice';
            
            foreach ($updates as $keyword => $behavior) {
                if (strpos($name, $keyword) !== false) {
                    $newBehavior = $behavior;
                    break;
                }
            }
            
            if ($location['gate_behavior'] !== $newBehavior) {
                $updateStmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE id = ?");
                $updateStmt->execute([$newBehavior, $location['id']]);
                echo "🔄 '{$location['name']}' güncellendi: {$location['gate_behavior']} → {$newBehavior}<br>";
            }
        }
    } else {
        // Demo QR lokasyonları oluştur
        $demoLocations = [
            ['name' => 'giriş', 'gate_behavior' => 'work_start', 'latitude' => 41.0082, 'longitude' => 28.9784],
            ['name' => 'çıkış', 'gate_behavior' => 'work_end', 'latitude' => 41.0083, 'longitude' => 28.9785],
            ['name' => 'mola', 'gate_behavior' => 'break_toggle', 'latitude' => 41.0084, 'longitude' => 28.9786],
            ['name' => 'mola giriş', 'gate_behavior' => 'break_toggle', 'latitude' => 41.0085, 'longitude' => 28.9787]
        ];
        
        foreach ($demoLocations as $location) {
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (
                    company_id, name, latitude, longitude, tolerance_meters, 
                    expires_at, location_type, gate_behavior, created_at
                ) VALUES (?, ?, ?, ?, 50, DATE_ADD(NOW(), INTERVAL 1 YEAR), 'general_gate', ?, NOW())
            ");
            
            $stmt->execute([
                $companyId, 
                $location['name'], 
                $location['latitude'], 
                $location['longitude'], 
                $location['gate_behavior']
            ]);
            
            echo "✅ '{$location['name']}' QR lokasyonu oluşturuldu (davranış: {$location['gate_behavior']})<br>";
        }
    }
    
    // Selim kullanıcısını kontrol et veya oluştur
    $stmt = $conn->prepare("SELECT id FROM employees WHERE company_id = ? AND first_name = 'selim'");
    $stmt->execute([$companyId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        $stmt = $conn->prepare("
            INSERT INTO employees (
                company_id, first_name, last_name, email, phone, hire_date, 
                department, position, hourly_rate, created_at
            ) VALUES (?, 'selim', 'demo', 'selim@demo.com', '555-0001', CURDATE(), 'IT', 'Developer', 50.00, NOW())
        ");
        $stmt->execute([$companyId]);
        echo "✅ 'selim' çalışanı oluşturuldu<br>";
    } else {
        echo "✅ 'selim' çalışanı zaten mevcut<br>";
    }
    
    echo "<br><strong>🎉 DEMO001 kurulumu tamamlandı!</strong><br>";
    echo "<a href='debug-qr-selim.php' target='_blank'>Debug Raporu</a> | ";
    echo "<a href='super-admin/'>Super Admin</a>";
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage();
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
a { color: blue; text-decoration: none; margin: 0 10px; }
a:hover { text-decoration: underline; }
</style>