<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔧 Quick Add Employee Number Column</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if employee_number column exists
    $result = $conn->query("DESCRIBE employees");
    $columns = $result->fetchAll();
    
    $hasEmployeeNumber = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'employee_number') {
            $hasEmployeeNumber = true;
            break;
        }
    }
    
    if (!$hasEmployeeNumber) {
        echo "<p style='color: orange;'>⚠️ employee_number column missing. Adding it now...</p>";
        
        // Add the column
        $conn->query("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
        
        // Generate employee numbers for existing employees
        $stmt = $conn->prepare("SELECT id FROM employees ORDER BY id");
        $stmt->execute();
        $employees = $stmt->fetchAll();
        
        foreach ($employees as $employee) {
            $employeeNumber = 'EMP' . str_pad($employee['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            $updateStmt->execute([$employeeNumber, $employee['id']]);
        }
        
        echo "<p style='color: green;'>✅ employee_number column added successfully!</p>";
        echo "<p style='color: green;'>✅ Generated employee numbers for " . count($employees) . " existing employees</p>";
    } else {
        echo "<p style='color: green;'>✅ employee_number column already exists</p>";
    }
    
    // Test the column
    $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number FROM employees LIMIT 3");
    $stmt->execute();
    $testEmployees = $stmt->fetchAll();
    
    echo "<h3>✅ Test Results</h3>";
    if (count($testEmployees) > 0) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background: #f0f0f0;'>";
        echo "<th style='padding: 8px;'>ID</th>";
        echo "<th style='padding: 8px;'>Employee Number</th>";
        echo "<th style='padding: 8px;'>Name</th>";
        echo "</tr>";
        
        foreach ($testEmployees as $emp) {
            echo "<tr>";
            echo "<td style='padding: 8px;'>{$emp['id']}</td>";
            echo "<td style='padding: 8px;'>{$emp['employee_number']}</td>";
            echo "<td style='padding: 8px;'>{$emp['first_name']} {$emp['last_name']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No employees found in the table</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<h3>🔗 Test Shift Management</h3>";
echo "<a href='admin/shift-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Test Shift Management</a>";
echo "<a href='admin/dashboard.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Back to Dashboard</a>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
table { margin: 10px 0; }
</style>