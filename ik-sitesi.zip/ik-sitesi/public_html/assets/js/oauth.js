// OAuth Authentication JavaScript
// Supports Google and Apple Sign-In for both employees and company admins

class OAuthManager {
    constructor() {
        this.isInitialized = false;
        this.currentUserType = 'employee'; // Default
    }

    // Initialize OAuth providers
    async init(userType = 'employee') {
        this.currentUserType = userType;
        
        // Initialize Google Sign-In
        if (typeof google !== 'undefined' && google.accounts) {
            this.initializeGoogle();
        }
        
        // Initialize Apple Sign-In if available
        if (typeof AppleID !== 'undefined') {
            this.initializeApple();
        }
        
        this.isInitialized = true;
    }

    // Initialize Google Sign-In
    initializeGoogle() {
        try {
            google.accounts.id.initialize({
                client_id: window.GOOGLE_CLIENT_ID || '',
                callback: this.handleGoogleCallback.bind(this),
                auto_select: false,
                cancel_on_tap_outside: true
            });
        } catch (error) {
            console.error('Google Sign-In initialization failed:', error);
        }
    }

    // Initialize Apple Sign-In
    initializeApple() {
        try {
            AppleID.auth.init({
                clientId: window.APPLE_CLIENT_ID || '',
                scope: 'name email',
                redirectURI: window.location.origin + '/api/auth/apple-oauth',
                state: this.generateState(),
                usePopup: true
            });
        } catch (error) {
            console.error('Apple Sign-In initialization failed:', error);
        }
    }

    // Handle Google Sign-In callback
    async handleGoogleCallback(response) {
        try {
            const result = await fetch('/api/auth/google-oauth', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id_token: response.credential,
                    user_type: this.currentUserType
                })
            });

            const data = await result.json();
            
            if (data.success) {
                this.showMessage('Google ile giriş başarılı! Yönlendiriliyorsunuz...', 'success');
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            } else {
                this.showMessage(data.error || 'Google ile giriş başarısız', 'error');
            }
        } catch (error) {
            console.error('Google OAuth error:', error);
            this.showMessage('Google ile giriş sırasında bir hata oluştu', 'error');
        }
    }

    // Start Google Sign-In
    signInWithGoogle() {
        if (!this.isInitialized) {
            this.showMessage('OAuth sistemi henüz yüklenmedi', 'error');
            return;
        }

        try {
            // Use redirect flow for better compatibility
            const redirectUri = window.location.origin + '/api/auth/google-oauth';
            const authUrl = `/api/auth/google-oauth?user_type=${this.currentUserType}`;
            window.location.href = authUrl;
        } catch (error) {
            console.error('Google Sign-In error:', error);
            this.showMessage('Google ile giriş başlatılamadı', 'error');
        }
    }

    // Start Apple Sign-In
    async signInWithApple() {
        if (!this.isInitialized) {
            this.showMessage('OAuth sistemi henüz yüklenmedi', 'error');
            return;
        }

        try {
            const response = await AppleID.auth.signIn();
            
            if (response.authorization) {
                await this.handleAppleCallback(response.authorization);
            }
        } catch (error) {
            console.error('Apple Sign-In error:', error);
            this.showMessage('Apple ile giriş başarısız', 'error');
        }
    }

    // Handle Apple Sign-In callback
    async handleAppleCallback(authorization) {
        try {
            const result = await fetch('/api/auth/apple-oauth', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id_token: authorization.id_token,
                    user: authorization.user,
                    user_type: this.currentUserType
                })
            });

            const data = await result.json();
            
            if (data.success) {
                this.showMessage('Apple ile giriş başarılı! Yönlendiriliyorsunuz...', 'success');
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            } else {
                this.showMessage(data.error || 'Apple ile giriş başarısız', 'error');
            }
        } catch (error) {
            console.error('Apple OAuth error:', error);
            this.showMessage('Apple ile giriş sırasında bir hata oluştu', 'error');
        }
    }

    // Generate random state for security
    generateState() {
        return Math.random().toString(36).substring(2, 15) + 
               Math.random().toString(36).substring(2, 15);
    }

    // Show message to user
    showMessage(message, type = 'info') {
        // Try to use existing showAlert function if available
        if (typeof showAlert === 'function') {
            showAlert(message, type === 'error' ? 'danger' : type);
            return;
        }

        // Fallback to simple alert
        alert(message);
    }

    // Set user type for OAuth flow
    setUserType(userType) {
        this.currentUserType = userType;
    }
}

// Global OAuth manager instance
window.oauthManager = new OAuthManager();

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on a login page and determine user type
    let userType = 'employee';
    
    if (window.location.pathname.includes('company-login') || 
        window.location.pathname.includes('company-register')) {
        userType = 'company_admin';
    }
    
    // Initialize OAuth with appropriate user type
    window.oauthManager.init(userType);
});

// Helper functions for easy integration
function signInWithGoogle(userType = null) {
    if (userType) {
        window.oauthManager.setUserType(userType);
    }
    window.oauthManager.signInWithGoogle();
}

function signInWithApple(userType = null) {
    if (userType) {
        window.oauthManager.setUserType(userType);
    }
    window.oauthManager.signInWithApple();
}

// Load OAuth SDKs dynamically
function loadOAuthSDKs() {
    // Load Google Sign-In SDK
    if (!document.querySelector('script[src*="accounts.google.com"]')) {
        const googleScript = document.createElement('script');
        googleScript.src = 'https://accounts.google.com/gsi/client';
        googleScript.async = true;
        googleScript.defer = true;
        document.head.appendChild(googleScript);
    }

    // Load Apple Sign-In SDK
    if (!document.querySelector('script[src*="appleid.cdn-apple.com"]')) {
        const appleScript = document.createElement('script');
        appleScript.src = 'https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid/1/en_US/appleid.auth.js';
        appleScript.async = true;
        document.head.appendChild(appleScript);
    }
}

// Auto-load SDKs
loadOAuthSDKs();