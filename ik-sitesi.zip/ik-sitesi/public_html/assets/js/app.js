// SZB İK Takip Sistemi - JavaScript Functions

// API Base URL
const API_BASE = '/api';

// Utility Functions
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container') || createAlertContainer();
    
    const alertElement = document.createElement('div');
    alertElement.className = `alert alert-${type} alert-dismissible fade show`;
    alertElement.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    alertContainer.appendChild(alertElement);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alertElement.parentNode) {
            alertElement.remove();
        }
    }, 5000);
}

function createAlertContainer() {
    const container = document.createElement('div');
    container.id = 'alert-container';
    container.className = 'position-fixed top-0 end-0 p-3';
    container.style.zIndex = '1050';
    document.body.appendChild(container);
    return container;
}

function formatTime(timeString) {
    if (!timeString) return '-';
    return new Date('1970-01-01T' + timeString + 'Z').toLocaleTimeString('tr-TR', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatDuration(minutes) {
    if (!minutes || minutes === 0) return '0sa';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}sa ${mins}dk` : `${mins}dk`;
}

function apiRequest(endpoint, options = {}) {
    const url = endpoint.startsWith('http') ? endpoint : API_BASE + endpoint;
    
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        },
    };
    
    const config = { ...defaultOptions, ...options };
    
    if (config.body && typeof config.body === 'object') {
        config.body = JSON.stringify(config.body);
    }
    
    return fetch(url, config)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return response.json();
        })
        .catch(error => {
            console.error('API Request Error:', error);
            throw error;
        });
}

// Dashboard Functions
function loadDashboardStats() {
    const presentTodayEl = document.getElementById('present-today');
    const totalEmployeesEl = document.getElementById('total-employees');
    const leaveRequestsEl = document.getElementById('leave-requests');
    const overtimeHoursEl = document.getElementById('overtime-hours');
    
    if (!presentTodayEl) return;
    
    // For Hostinger PHP version, we'll use demo data initially
    // This would be replaced with actual API calls
    
    // Simulate API call delay
    setTimeout(() => {
        presentTodayEl.textContent = '23';
        totalEmployeesEl.textContent = '45';
        leaveRequestsEl.textContent = '5';
        overtimeHoursEl.textContent = '127sa';
    }, 500);
}

function loadRecentActivities() {
    const container = document.getElementById('recent-activities');
    if (!container) return;
    
    // For demo purposes, show sample activities
    // In real implementation, this would fetch from API
    setTimeout(() => {
        container.innerHTML = `
            <div class="activity-timeline">
                <div class="activity-item">
                    <div class="activity-time">14:30</div>
                    <div class="activity-description">Ali Veli - Çıkış yapıldı</div>
                    <div class="activity-location">Ana Çıkış Kapısı</div>
                </div>
                <div class="activity-item">
                    <div class="activity-time">14:15</div>
                    <div class="activity-description">Ayşe Kaya - Yemek molası bitirildi</div>
                    <div class="activity-location">Yemekhane</div>
                </div>
                <div class="activity-item">
                    <div class="activity-time">13:30</div>
                    <div class="activity-description">Mehmet Özkan - Yemek molası başlatıldı</div>
                    <div class="activity-location">Yemekhane</div>
                </div>
                <div class="activity-item">
                    <div class="activity-time">09:15</div>
                    <div class="activity-description">Fatma Demir - Giriş yapıldı</div>
                    <div class="activity-location">Ana Giriş Kapısı</div>
                </div>
            </div>
        `;
    }, 800);
}

function loadQRLocations() {
    const container = document.getElementById('qr-locations');
    if (!container) return;
    
    // Load QR locations from API
    apiRequest('/qr/locations')
        .then(locations => {
            container.innerHTML = locations.map(location => `
                <div class="d-flex align-items-center mb-2 p-2 bg-light rounded">
                    <i class="fas fa-qrcode text-primary me-2"></i>
                    <div>
                        <div class="fw-bold">${location.name}</div>
                        <small class="text-muted">${getLocationTypeText(location.location_type)}</small>
                    </div>
                    <div class="ms-auto">
                        <span class="badge ${location.is_active ? 'bg-success' : 'bg-secondary'}">
                            ${location.is_active ? 'Aktif' : 'Pasif'}
                        </span>
                    </div>
                </div>
            `).join('');
        })
        .catch(error => {
            console.error('QR Locations loading error:', error);
            container.innerHTML = `
                <div class="text-center p-3">
                    <i class="fas fa-exclamation-triangle text-warning"></i>
                    <p class="mt-2 text-muted">Lokasyonlar yüklenemedi</p>
                </div>
            `;
        });
}

// QR Scanner Functions
function loadQRScannerLocations() {
    const container = document.querySelector('.qr-location-grid');
    if (!container) return;
    
    container.innerHTML = '<div class="text-center p-4"><i class="fas fa-spinner fa-spin fa-2x"></i><p class="mt-2">Lokasyonlar yükleniyor...</p></div>';
    
    apiRequest('/qr/locations')
        .then(locations => {
            container.innerHTML = locations.map(location => `
                <div class="qr-location-card" data-location-code="${location.location_code}" data-activity-type="${location.location_type}">
                    <div class="qr-location-icon">
                        ${getLocationIcon(location.location_type)}
                    </div>
                    <div class="qr-location-name">${location.name}</div>
                    <div class="qr-location-type">${getLocationTypeText(location.location_type)}</div>
                </div>
            `).join('');
            
            // Add click handlers
            document.querySelectorAll('.qr-location-card').forEach(card => {
                card.addEventListener('click', function() {
                    const locationCode = this.dataset.locationCode;
                    const activityType = this.dataset.activityType;
                    simulateQRScan(locationCode, activityType);
                });
            });
        })
        .catch(error => {
            console.error('QR Scanner locations loading error:', error);
            container.innerHTML = `
                <div class="text-center p-4">
                    <i class="fas fa-exclamation-triangle text-warning fa-2x"></i>
                    <p class="mt-2">Lokasyonlar yüklenemedi</p>
                </div>
            `;
        });
}

function simulateQRScan(locationCode, activityType) {
    const deviceInfo = {
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
        language: navigator.language,
        platform: navigator.platform
    };
    
    // Show loading state
    const cards = document.querySelectorAll('.qr-location-card');
    cards.forEach(card => card.classList.add('disabled'));
    
    apiRequest('/qr/scan', {
        method: 'POST',
        body: {
            locationCode: locationCode,
            activityType: activityType,
            deviceInfo: deviceInfo
        }
    })
    .then(response => {
        showAlert(response.message, 'success');
        
        // Highlight successful scan
        const successCard = document.querySelector(`[data-location-code="${locationCode}"]`);
        if (successCard) {
            successCard.classList.add('active');
            setTimeout(() => {
                successCard.classList.remove('active');
            }, 3000);
        }
    })
    .catch(error => {
        console.error('QR Scan error:', error);
        showAlert('QR kod tarama başarısız: ' + error.message, 'danger');
    })
    .finally(() => {
        // Remove loading state
        cards.forEach(card => card.classList.remove('disabled'));
    });
}

function getLocationIcon(locationType) {
    switch (locationType) {
        case 'check_in':
            return '<i class="fas fa-sign-in-alt"></i>';
        case 'check_out':
            return '<i class="fas fa-sign-out-alt"></i>';
        case 'tea_break':
            return '<i class="fas fa-coffee"></i>';
        case 'lunch_break':
            return '<i class="fas fa-utensils"></i>';
        case 'smoke_break':
            return '<i class="fas fa-smoking"></i>';
        default:
            return '<i class="fas fa-qrcode"></i>';
    }
}

function getLocationTypeText(locationType) {
    switch (locationType) {
        case 'check_in':
            return 'Giriş Kapısı';
        case 'check_out':
            return 'Çıkış Kapısı';
        case 'tea_break':
            return 'Çay Molası';
        case 'lunch_break':
            return 'Yemek Molası';
        case 'smoke_break':
            return 'Sigara Molası';
        default:
            return 'Diğer';
    }
}

// Self Service Functions
function loadSelfServiceData() {
    loadEmployeeInfo();
    loadTodayAttendance();
    loadTodayActivities();
    loadBreakEntitlements();
    loadWeeklySummary();
}

function loadEmployeeInfo() {
    const container = document.getElementById('employee-info');
    if (!container) return;
    
    apiRequest('/employee/self-service?action=employee-info&employee_id=1')
        .then(employee => {
            container.innerHTML = `
                <div class="d-flex align-items-center">
                    <div class="me-3">
                        <i class="fas fa-user-circle fa-3x text-primary"></i>
                    </div>
                    <div>
                        <h5 class="mb-0">${employee.first_name} ${employee.last_name}</h5>
                        <p class="text-muted mb-0">${employee.position || 'Pozisyon belirtilmemiş'}</p>
                        <small class="text-muted">${employee.department_name || 'Departman belirtilmemiş'}</small>
                    </div>
                </div>
            `;
        })
        .catch(error => {
            console.error('Employee info loading error:', error);
            container.innerHTML = '<p class="text-muted">Personel bilgileri yüklenemedi</p>';
        });
}

function loadTodayAttendance() {
    const container = document.getElementById('today-attendance');
    if (!container) return;
    
    const today = new Date().toISOString().split('T')[0];
    
    apiRequest(`/employee/self-service?action=attendance&employee_id=1&date=${today}`)
        .then(attendance => {
            container.innerHTML = `
                <div class="row text-center">
                    <div class="col-6">
                        <div class="stat-card">
                            <div class="stat-value text-success">${formatTime(attendance.check_in)}</div>
                            <div class="stat-label">Giriş</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-card">
                            <div class="stat-value text-danger">${formatTime(attendance.check_out)}</div>
                            <div class="stat-label">Çıkış</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-card">
                            <div class="stat-value text-info">${formatDuration(attendance.work_duration)}</div>
                            <div class="stat-label">Çalışma</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-card">
                            <div class="stat-value text-warning">${formatDuration(attendance.overtime_duration)}</div>
                            <div class="stat-label">Mesai</div>
                        </div>
                    </div>
                </div>
            `;
        })
        .catch(error => {
            console.error('Today attendance loading error:', error);
            container.innerHTML = '<p class="text-muted">Günlük devam bilgisi yüklenemedi</p>';
        });
}

function loadTodayActivities() {
    const container = document.getElementById('today-activities');
    if (!container) return;
    
    const today = new Date().toISOString().split('T')[0];
    
    apiRequest(`/employee/self-service?action=activities&employee_id=1&date=${today}`)
        .then(activities => {
            if (activities.length === 0) {
                container.innerHTML = '<p class="text-muted text-center">Bugün henüz aktivite yok</p>';
                return;
            }
            
            container.innerHTML = `
                <div class="activity-timeline">
                    ${activities.map(activity => `
                        <div class="activity-item">
                            <div class="activity-time">${formatTime(activity.timestamp.split(' ')[1])}</div>
                            <div class="activity-description">
                                ${getLocationTypeText(activity.location_type)}
                            </div>
                            <div class="activity-location">${activity.location_name}</div>
                        </div>
                    `).join('')}
                </div>
            `;
        })
        .catch(error => {
            console.error('Today activities loading error:', error);
            container.innerHTML = '<p class="text-muted">Aktiviteler yüklenemedi</p>';
        });
}

function loadBreakEntitlements() {
    const container = document.getElementById('break-entitlements');
    if (!container) return;
    
    apiRequest('/employee/self-service?action=break-entitlements&employee_id=1')
        .then(entitlements => {
            container.innerHTML = entitlements.map(entitlement => {
                const percentage = (entitlement.used_minutes_today / entitlement.daily_limit_minutes) * 100;
                const progressClass = percentage > 90 ? 'danger' : percentage > 70 ? 'warning' : '';
                
                return `
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <span class="fw-bold">${getLocationTypeText(entitlement.break_type)}</span>
                            <span class="text-muted">
                                ${entitlement.used_minutes_today}/${entitlement.daily_limit_minutes} dk
                            </span>
                        </div>
                        <div class="break-progress">
                            <div class="break-progress-bar ${progressClass}" 
                                 style="width: ${Math.min(percentage, 100)}%"></div>
                        </div>
                        <small class="text-muted">
                            Kalan: ${entitlement.remaining_minutes} dakika
                        </small>
                    </div>
                `;
            }).join('');
        })
        .catch(error => {
            console.error('Break entitlements loading error:', error);
            container.innerHTML = '<p class="text-muted">Mola hakları yüklenemedi</p>';
        });
}

function loadWeeklySummary() {
    const container = document.getElementById('weekly-summary');
    if (!container) return;
    
    apiRequest('/employee/self-service?action=weekly-summary&employee_id=1')
        .then(summary => {
            container.innerHTML = `
                <div class="row text-center mb-3">
                    <div class="col-3">
                        <div class="stat-card">
                            <div class="stat-value">${summary.statistics.present_days}</div>
                            <div class="stat-label">Gelen Gün</div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="stat-card">
                            <div class="stat-value">${summary.statistics.total_work_hours}sa</div>
                            <div class="stat-label">Toplam Çalışma</div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="stat-card">
                            <div class="stat-value">${summary.statistics.total_overtime_hours}sa</div>
                            <div class="stat-label">Toplam Mesai</div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="stat-card">
                            <div class="stat-value">${summary.statistics.average_daily_hours}sa</div>
                            <div class="stat-label">Günlük Ort.</div>
                        </div>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Tarih</th>
                                <th>Giriş</th>
                                <th>Çıkış</th>
                                <th>Çalışma</th>
                                <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${summary.daily_records.map(record => `
                                <tr>
                                    <td>${new Date(record.date).toLocaleDateString('tr-TR')}</td>
                                    <td>${formatTime(record.check_in)}</td>
                                    <td>${formatTime(record.check_out)}</td>
                                    <td>${formatDuration(record.work_duration)}</td>
                                    <td>
                                        <span class="badge ${getStatusBadgeClass(record.status)}">${getStatusText(record.status)}</span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        })
        .catch(error => {
            console.error('Weekly summary loading error:', error);
            container.innerHTML = '<p class="text-muted">Haftalık özet yüklenemedi</p>';
        });
}

function getStatusBadgeClass(status) {
    switch (status) {
        case 'present':
            return 'bg-success';
        case 'absent':
            return 'bg-danger';
        case 'late':
            return 'bg-warning';
        case 'early_leave':
            return 'bg-info';
        case 'holiday':
            return 'bg-secondary';
        default:
            return 'bg-secondary';
    }
}

function getStatusText(status) {
    switch (status) {
        case 'present':
            return 'Geldi';
        case 'absent':
            return 'Gelmedi';
        case 'late':
            return 'Geç Geldi';
        case 'early_leave':
            return 'Erken Çıktı';
        case 'holiday':
            return 'Tatil';
        default:
            return 'Bilinmiyor';
    }
}

// Initialize page-specific functions
document.addEventListener('DOMContentLoaded', function() {
    const currentPage = window.location.pathname;
    
    if (currentPage.includes('qr-scanner')) {
        loadQRScannerLocations();
    } else if (currentPage.includes('self-service')) {
        loadSelfServiceData();
    }
    
    // Update times every minute
    setInterval(() => {
        const timeElements = document.querySelectorAll('.current-time');
        timeElements.forEach(el => {
            el.textContent = new Date().toLocaleTimeString('tr-TR');
        });
    }, 1000);
});

// Global logout function - Ana sayfaya yönlendirir
function logout() {
    if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
        fetch('/api/auth/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert('Çıkış başarılı! Ana sayfaya yönlendiriliyorsunuz...', 'success');
                setTimeout(() => {
                    window.location.href = '/';
                }, 1000);
            } else {
                // Hata durumunda da ana sayfaya yönlendir
                window.location.href = '/';
            }
        })
        .catch(() => {
            // Hata durumunda ana sayfaya yönlendir
            window.location.href = '/';
        });
    }
}

// Eski globalLogout fonksiyonunu da destekle
function globalLogout() {
    logout();
}

// Export functions for global use
window.SZBApp = {
    loadDashboardStats,
    loadRecentActivities,
    loadQRLocations,
    loadQRScannerLocations,
    loadSelfServiceData,
    simulateQRScan,
    showAlert,
    apiRequest,
    logout,
    globalLogout
};