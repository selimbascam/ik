<?php
// Tek tıkla veritabanı kurulum aracı
echo "<h1>🚀 SZB İK Takip - Veritabanı Kurulumu</h1>";

if ($_POST['confirm'] ?? false) {
    try {
        // MySQL bağlantısı
        $pdo = new PDO("mysql:host=localhost;dbname=u978874874_ik;charset=utf8mb4", 'u978874874_ik', 'Szb2013@+-!');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ MySQL bağlantısı başarılı";
        echo "</div>";
        
        // SQL dosyasını oku ve çalıştır
        $sql_file = '../szb_ik_takip_complete.sql';
        if (!file_exists($sql_file)) {
            throw new Exception("SQL dosyası bulunamadı: $sql_file");
        }
        
        $sql_content = file_get_contents($sql_file);
        
        // SQL komutlarını böl ve çalıştır
        $statements = explode(';', $sql_content);
        $executed = 0;
        
        foreach ($statements as $statement) {
            $statement = trim($statement);
            if (empty($statement) || strpos($statement, '--') === 0) continue;
            
            try {
                $pdo->exec($statement);
                $executed++;
            } catch (PDOException $e) {
                // SELECT statements ve bazı komutlar hata verebilir, devam et
                if (!strpos($e->getMessage(), 'not allowed')) {
                    echo "<div style='color: orange;'>⚠️ " . htmlspecialchars($statement) . "</div>";
                }
            }
        }
        
        echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h3>✅ KURULUM TAMAMLANDI!</h3>";
        echo "<p>$executed SQL komutu başarıyla çalıştırıldı.</p>";
        echo "</div>";
        
        // Test sorgusu
        $stmt = $pdo->prepare("
            SELECT e.employee_number, e.first_name, e.last_name, c.company_name
            FROM employees e 
            JOIN companies c ON e.company_id = c.id 
            WHERE e.password = SHA2('demo123', 256)
            LIMIT 3
        ");
        $stmt->execute();
        $test_employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($test_employees) {
            echo "<div style='background: #e7f3ff; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
            echo "<h2>🎉 SİSTEM HAZIR!</h2>";
            echo "<p><strong>Demo Personel Giriş Bilgileri:</strong></p>";
            echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr><th>Personel No</th><th>Ad Soyad</th><th>Şirket</th><th>Şifre</th></tr>";
            foreach ($test_employees as $emp) {
                echo "<tr>";
                echo "<td><strong>{$emp['employee_number']}</strong></td>";
                echo "<td>{$emp['first_name']} {$emp['last_name']}</td>";
                echo "<td>{$emp['company_name']}</td>";
                echo "<td><strong>demo123</strong></td>";
                echo "</tr>";
            }
            echo "</table>";
            echo "<p>Artık personel girişi yapmaya hazırsınız!</p>";
            echo "</div>";
        }
        
        echo "<div style='text-align: center; margin: 20px 0;'>";
        echo "<a href='auth/employee-login.php' style='background: #28a745; color: white; padding: 20px 40px; text-decoration: none; border-radius: 10px; font-size: 20px; font-weight: bold;'>🚀 PERSONEL GİRİŞİ TEST ET</a>";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
        echo "<h3>❌ KURULUM HATASI</h3>";
        echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
        echo "</div>";
    }
} else {
    // Kurulum onay formu
    echo "<div style='background: #fff3cd; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h2>⚠️ DİKKAT</h2>";
    echo "<p>Bu işlem mevcut tüm verileri silecek ve yeni demo veriler oluşturacak.</p>";
    echo "<p>Devam etmek istiyor musunuz?</p>";
    echo "</div>";
    
    echo "<form method='post' style='text-align: center;'>";
    echo "<input type='hidden' name='confirm' value='1'>";
    echo "<button type='submit' style='background: #dc3545; color: white; padding: 15px 30px; border: none; border-radius: 5px; font-size: 18px; cursor: pointer;'>✅ EVET, VERİTABANINI KUR</button>";
    echo "</form>";
    
    echo "<div style='margin: 20px 0;'>";
    echo "<h3>📋 Kurulacak İçerik:</h3>";
    echo "<ul>";
    echo "<li>16 tablo (companies, employees, departments, vs.)</li>";
    echo "<li>Demo şirket: Demo Şirket Ltd. Şti.</li>";
    echo "<li>5 demo personel (EMP001-EMP005)</li>";
    echo "<li>Demo departmanlar (IT, İK, Muhasebe)</li>";
    echo "<li>QR lokasyonları ve aktivite türleri</li>";
    echo "<li>Tüm personeller için şifre: <strong>demo123</strong></li>";
    echo "</ul>";
    echo "</div>";
}
?>