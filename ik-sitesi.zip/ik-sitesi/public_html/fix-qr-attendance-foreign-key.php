<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 QR Attendance Foreign Key Constraint Fix</h1>";
echo "<p>Fixing foreign key constraint error for attendance_records table</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📊 Current Table Analysis</h2>";
    
    // 1. Check attendance_records table structure
    echo "<h3>1. Attendance Records Table Structure</h3>";
    
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $columnNames = array_column($columns, 'Field');
        
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr><th>Column Name</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $column) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($column['Field']) . "</td>";
            echo "<td>" . htmlspecialchars($column['Type']) . "</td>";
            echo "<td>" . htmlspecialchars($column['Null']) . "</td>";
            echo "<td>" . htmlspecialchars($column['Key']) . "</td>";
            echo "<td>" . htmlspecialchars($column['Default']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        $hasCompanyId = in_array('company_id', $columnNames);
        echo "<p><strong>Company ID Column Present:</strong> " . ($hasCompanyId ? "✅ Yes" : "❌ No") . "</p>";
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Error checking attendance_records: " . $e->getMessage() . "</p>";
        exit;
    }
    
    // 2. Check foreign key constraints
    echo "<h3>2. Current Foreign Key Constraints</h3>";
    
    try {
        $stmt = $conn->query("
            SELECT 
                CONSTRAINT_NAME,
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME
            FROM information_schema.KEY_COLUMN_USAGE 
            WHERE TABLE_NAME = 'attendance_records' 
            AND TABLE_SCHEMA = DATABASE()
            AND REFERENCED_TABLE_NAME IS NOT NULL
        ");
        $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($constraints) {
            echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
            echo "<tr><th>Constraint Name</th><th>Column</th><th>References Table</th><th>References Column</th></tr>";
            foreach ($constraints as $constraint) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($constraint['CONSTRAINT_NAME']) . "</td>";
                echo "<td>" . htmlspecialchars($constraint['COLUMN_NAME']) . "</td>";
                echo "<td>" . htmlspecialchars($constraint['REFERENCED_TABLE_NAME']) . "</td>";
                echo "<td>" . htmlspecialchars($constraint['REFERENCED_COLUMN_NAME']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>ℹ️ No foreign key constraints found on attendance_records table</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ Could not check constraints: " . $e->getMessage() . "</p>";
    }
    
    // 3. Check companies table
    echo "<h3>3. Companies Table Verification</h3>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM companies");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>✅ Companies table exists with " . $result['count'] . " records</p>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Companies table issue: " . $e->getMessage() . "</p>";
    }
    
    // 4. Fix the issue
    echo "<h2>🛠️ Applying Fixes</h2>";
    
    // Step 1: Add company_id column if missing
    if (!$hasCompanyId) {
        echo "<h3>Step 1: Adding company_id column</h3>";
        
        try {
            $conn->exec("ALTER TABLE attendance_records ADD COLUMN company_id INT NULL AFTER employee_id");
            echo "<p>✅ company_id column added to attendance_records</p>";
            
            // Populate company_id from employee records
            $conn->exec("
                UPDATE attendance_records ar 
                INNER JOIN employees e ON ar.employee_id = e.id 
                SET ar.company_id = e.company_id 
                WHERE ar.company_id IS NULL
            ");
            echo "<p>✅ company_id populated from employee records</p>";
            
            // Make company_id NOT NULL after population
            $conn->exec("ALTER TABLE attendance_records MODIFY COLUMN company_id INT NOT NULL");
            echo "<p>✅ company_id set to NOT NULL</p>";
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Error adding company_id: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<h3>Step 1: Company ID column already exists</h3>";
        
        // Check if company_id is properly populated
        try {
            $stmt = $conn->query("SELECT COUNT(*) as null_count FROM attendance_records WHERE company_id IS NULL");
            $nullCount = $stmt->fetch(PDO::FETCH_ASSOC)['null_count'];
            
            if ($nullCount > 0) {
                echo "<p>⚠️ Found $nullCount records with NULL company_id. Fixing...</p>";
                
                $conn->exec("
                    UPDATE attendance_records ar 
                    INNER JOIN employees e ON ar.employee_id = e.id 
                    SET ar.company_id = e.company_id 
                    WHERE ar.company_id IS NULL
                ");
                echo "<p>✅ NULL company_id values fixed</p>";
            } else {
                echo "<p>✅ All company_id values are properly set</p>";
            }
        } catch (Exception $e) {
            echo "<p style='color: orange;'>⚠️ Could not check NULL values: " . $e->getMessage() . "</p>";
        }
    }
    
    // Step 2: Add foreign key constraint if missing
    echo "<h3>Step 2: Adding Foreign Key Constraint</h3>";
    
    $hasCompanyFk = false;
    foreach ($constraints as $constraint) {
        if ($constraint['COLUMN_NAME'] === 'company_id' && $constraint['REFERENCED_TABLE_NAME'] === 'companies') {
            $hasCompanyFk = true;
            break;
        }
    }
    
    if (!$hasCompanyFk) {
        try {
            // First add index for better performance
            try {
                $conn->exec("ALTER TABLE attendance_records ADD INDEX idx_company_id (company_id)");
                echo "<p>✅ Index added for company_id</p>";
            } catch (Exception $e) {
                if (strpos($e->getMessage(), 'Duplicate key name') === false) {
                    echo "<p style='color: orange;'>⚠️ Index warning: " . $e->getMessage() . "</p>";
                }
            }
            
            // Add foreign key constraint
            $conn->exec("
                ALTER TABLE attendance_records 
                ADD CONSTRAINT fk_attendance_company 
                FOREIGN KEY (company_id) 
                REFERENCES companies(id) 
                ON DELETE CASCADE
            ");
            echo "<p>✅ Foreign key constraint added for company_id</p>";
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Error adding foreign key: " . $e->getMessage() . "</p>";
            
            // Try to analyze the issue
            try {
                $stmt = $conn->query("
                    SELECT DISTINCT ar.company_id 
                    FROM attendance_records ar 
                    LEFT JOIN companies c ON ar.company_id = c.id 
                    WHERE c.id IS NULL AND ar.company_id IS NOT NULL
                ");
                $orphanCompanies = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                if ($orphanCompanies) {
                    echo "<p style='color: red;'>🔍 Found orphan company IDs: " . implode(', ', $orphanCompanies) . "</p>";
                    echo "<p>These attendance records reference companies that don't exist.</p>";
                }
            } catch (Exception $e2) {
                echo "<p style='color: orange;'>⚠️ Could not analyze orphan records</p>";
            }
        }
    } else {
        echo "<p>✅ Foreign key constraint already exists</p>";
    }
    
    // Step 3: Create trigger for automatic company_id population
    echo "<h3>Step 3: Creating Trigger for Automatic Company ID</h3>";
    
    try {
        // Drop trigger if exists
        try {
            $conn->exec("DROP TRIGGER IF EXISTS attendance_records_company_id_trigger");
        } catch (Exception $e) {
            // Ignore if trigger doesn't exist
        }
        
        // Create trigger
        $conn->exec("
            CREATE TRIGGER attendance_records_company_id_trigger
            BEFORE INSERT ON attendance_records
            FOR EACH ROW
            BEGIN
                IF NEW.company_id IS NULL THEN
                    SET NEW.company_id = (
                        SELECT company_id 
                        FROM employees 
                        WHERE id = NEW.employee_id
                        LIMIT 1
                    );
                END IF;
            END
        ");
        echo "<p>✅ Trigger created for automatic company_id population</p>";
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Error creating trigger: " . $e->getMessage() . "</p>";
    }
    
    // Step 4: Test the fix
    echo "<h2>🧪 Testing the Fix</h2>";
    
    try {
        // Get a test employee
        $stmt = $conn->query("SELECT id, company_id FROM employees WHERE is_active = 1 LIMIT 1");
        $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($testEmployee) {
            echo "<p>Testing with employee ID: " . $testEmployee['id'] . " (company: " . $testEmployee['company_id'] . ")</p>";
            
            // Try to insert a test record (will be deleted immediately)
            $testStmt = $conn->prepare("
                INSERT INTO attendance_records (
                    employee_id, activity_type, check_in_time, date, notes
                ) VALUES (?, 'test', NOW(), CURDATE(), 'Foreign key test - will be deleted')
            ");
            $testStmt->execute([$testEmployee['id']]);
            
            $testId = $conn->lastInsertId();
            
            // Verify company_id was set
            $verifyStmt = $conn->prepare("SELECT company_id FROM attendance_records WHERE id = ?");
            $verifyStmt->execute([$testId]);
            $testRecord = $verifyStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($testRecord && $testRecord['company_id'] == $testEmployee['company_id']) {
                echo "<p>✅ Test INSERT successful - company_id automatically set to " . $testRecord['company_id'] . "</p>";
            } else {
                echo "<p style='color: red;'>❌ Test failed - company_id not set correctly</p>";
            }
            
            // Clean up test record
            $conn->prepare("DELETE FROM attendance_records WHERE id = ?")->execute([$testId]);
            echo "<p>🧹 Test record cleaned up</p>";
            
        } else {
            echo "<p style='color: orange;'>⚠️ No active employees found for testing</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Test failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<h2>✅ Fix Complete</h2>";
    echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>Summary of Changes:</h3>";
    echo "<ul>";
    echo "<li>✅ Verified/Added company_id column to attendance_records</li>";
    echo "<li>✅ Populated existing NULL company_id values</li>";
    echo "<li>✅ Added foreign key constraint for data integrity</li>";
    echo "<li>✅ Created trigger for automatic company_id population</li>";
    echo "<li>✅ Tested the implementation</li>";
    echo "</ul>";
    echo "<p><strong>The QR attendance system should now work without foreign key constraint errors.</strong></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>❌ Critical Error</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "h1, h2, h3 { color: #333; }";
echo "table { width: 100%; border-collapse: collapse; margin: 10px 0; }";
echo "th, td { padding: 8px; border: 1px solid #ddd; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "code { background: #f4f4f4; padding: 2px 4px; border-radius: 3px; }";
echo "</style>";
?>