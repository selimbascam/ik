<?php
/**
 * Shift Tables Creation Script - MySQL Format
 */
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Shift Tables Creation - MySQL Format</h2>";
echo "<pre style='background: #f5f5f5; padding: 20px; border-radius: 5px; font-family: monospace;'>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "🔧 MySQL formatında shift tabloları oluşturuluyor...\n\n";
    
    // Create shift_templates table
    echo "1. shift_templates tablosu oluşturuluyor...\n";
    $createShiftTemplates = "
    CREATE TABLE IF NOT EXISTS shift_templates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        name VARCHAR(255) NOT NULL COMMENT 'Vardiya adı (örn: Sabah Vardiyası)',
        start_time TIME NOT NULL COMMENT 'Başlangıç saati',
        end_time TIME NOT NULL COMMENT 'Bitiş saati',
        break_duration INT DEFAULT 30 COMMENT 'Mola süresi (dakika)',
        is_overnight BOOLEAN DEFAULT FALSE COMMENT 'Gece vardiyası mı',
        days_of_week JSON COMMENT 'Çalışma günleri [1,2,3,4,5] format',
        hourly_rate DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Saatlik ücret',
        overtime_rate DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Fazla mesai ücreti',
        description TEXT COMMENT 'Vardiya açıklaması',
        is_active BOOLEAN DEFAULT TRUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        INDEX idx_company_shifts (company_id),
        INDEX idx_shift_active (is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $conn->exec($createShiftTemplates);
    echo "   ✅ shift_templates tablosu oluşturuldu\n";
    
    // Create shift_assignments table
    echo "\n2. shift_assignments tablosu oluşturuluyor...\n";
    $createShiftAssignments = "
    CREATE TABLE IF NOT EXISTS shift_assignments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT NOT NULL,
        shift_template_id INT NOT NULL,
        assigned_date DATE NOT NULL COMMENT 'Atanan tarih',
        start_datetime DATETIME NOT NULL COMMENT 'Başlangıç tarih-saat',
        end_datetime DATETIME NOT NULL COMMENT 'Bitiş tarih-saat',
        expected_hours DECIMAL(4,2) DEFAULT 8.00 COMMENT 'Beklenen çalışma saati',
        status ENUM('scheduled', 'in_progress', 'completed', 'missed', 'cancelled') DEFAULT 'scheduled',
        notes TEXT COMMENT 'Vardiya notları',
        created_by INT COMMENT 'Atayan admin ID',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
        FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE,
        UNIQUE KEY unique_employee_shift (employee_id, assigned_date, shift_template_id),
        INDEX idx_company_assignments (company_id),
        INDEX idx_employee_assignments (employee_id),
        INDEX idx_assignment_date (assigned_date),
        INDEX idx_assignment_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $conn->exec($createShiftAssignments);
    echo "   ✅ shift_assignments tablosu oluşturuldu\n";
    
    // Create shift_swaps table for shift exchange requests
    echo "\n3. shift_swaps tablosu oluşturuluyor...\n";
    $createShiftSwaps = "
    CREATE TABLE IF NOT EXISTS shift_swaps (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        requester_employee_id INT NOT NULL COMMENT 'Değişim isteyen personel',
        target_employee_id INT NOT NULL COMMENT 'Değişim yapılacak personel',
        requester_shift_id INT NOT NULL COMMENT 'İsteyen personelin vardiyası',
        target_shift_id INT NOT NULL COMMENT 'Hedef personelin vardiyası',
        request_reason TEXT COMMENT 'Değişim sebebi',
        status ENUM('pending', 'approved', 'rejected', 'completed') DEFAULT 'pending',
        approved_by INT COMMENT 'Onaylayan admin ID',
        approval_date DATETIME NULL,
        rejection_reason TEXT COMMENT 'Red sebebi',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (requester_employee_id) REFERENCES employees(id) ON DELETE CASCADE,
        FOREIGN KEY (target_employee_id) REFERENCES employees(id) ON DELETE CASCADE,
        FOREIGN KEY (requester_shift_id) REFERENCES shift_assignments(id) ON DELETE CASCADE,
        FOREIGN KEY (target_shift_id) REFERENCES shift_assignments(id) ON DELETE CASCADE,
        INDEX idx_company_swaps (company_id),
        INDEX idx_swap_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $conn->exec($createShiftSwaps);
    echo "   ✅ shift_swaps tablosu oluşturuldu\n";
    
    // Insert sample shift templates for Turkish work culture
    echo "\n4. Örnek vardiya şablonları ekleniyor...\n";
    
    // Get first company for sample data
    $stmt = $conn->prepare("SELECT id FROM companies LIMIT 1");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        $companyId = $company['id'];
        
        $sampleShifts = [
            [
                'name' => 'Sabah Vardiyası',
                'start_time' => '08:00:00',
                'end_time' => '16:00:00',
                'break_duration' => 60,
                'days_of_week' => json_encode([1,2,3,4,5]), // Pazartesi-Cuma
                'description' => 'Standart sabah vardiyası, 8 saat çalışma'
            ],
            [
                'name' => 'Akşam Vardiyası',
                'start_time' => '16:00:00',
                'end_time' => '00:00:00',
                'break_duration' => 45,
                'is_overnight' => true,
                'days_of_week' => json_encode([1,2,3,4,5]),
                'description' => 'Akşam vardiyası, gece geçişli'
            ],
            [
                'name' => 'Gece Vardiyası',
                'start_time' => '00:00:00',
                'end_time' => '08:00:00',
                'break_duration' => 30,
                'is_overnight' => true,
                'days_of_week' => json_encode([1,2,3,4,5]),
                'description' => 'Gece vardiyası, 24:00-08:00'
            ],
            [
                'name' => 'Hafta Sonu',
                'start_time' => '09:00:00',
                'end_time' => '17:00:00',
                'break_duration' => 60,
                'days_of_week' => json_encode([6,7]), // Cumartesi-Pazar
                'description' => 'Hafta sonu vardiyası'
            ]
        ];
        
        $insertShift = $conn->prepare("
            INSERT INTO shift_templates 
            (company_id, name, start_time, end_time, break_duration, is_overnight, days_of_week, description) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        foreach ($sampleShifts as $shift) {
            $insertShift->execute([
                $companyId,
                $shift['name'],
                $shift['start_time'],
                $shift['end_time'],
                $shift['break_duration'],
                $shift['is_overnight'] ?? false,
                $shift['days_of_week'],
                $shift['description']
            ]);
            echo "   ✅ {$shift['name']} şablonu eklendi\n";
        }
    }
    
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "🎉 Shift yönetimi tabloları başarıyla oluşturuldu!\n\n";
    
    echo "📋 Oluşturulan tablolar:\n";
    echo "✅ shift_templates - Vardiya şablonları\n";
    echo "✅ shift_assignments - Vardiya atamaları\n";
    echo "✅ shift_swaps - Vardiya değişim istekleri\n";
    
    echo "\n🔧 Özellikler:\n";
    echo "• Türkiye iş hukuku uyumlu\n";
    echo "• Gece vardiyası desteği\n";
    echo "• Mola süresi yönetimi\n";
    echo "• Vardiya değişim sistemi\n";
    echo "• JSON formatında çalışma günleri\n";
    echo "• Saatlik ücret hesaplaması\n";
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage() . "\n";
}

?>
</pre>

<p><a href="admin/shift-management.php">← Vardiya Yönetimine Dön</a></p>