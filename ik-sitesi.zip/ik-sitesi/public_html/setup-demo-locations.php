<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Demo QR Lokasyonları Kurulumu</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Demo QR locations
    $demoLocations = [
        [
            'name' => 'Ana Giriş',
            'location_code' => 'LOC001',
            'location_type' => 'entrance',
            'description' => 'Şirket ana giriş kapısı'
        ],
        [
            'name' => 'Çay Mutfağı',
            'location_code' => 'LOC002', 
            'location_type' => 'break_area',
            'description' => 'Personel çay-kahve alanı'
        ],
        [
            'name' => 'Yemekhane',
            'location_code' => 'LOC003',
            'location_type' => 'dining',
            'description' => 'Personel yemek alanı'
        ]
    ];
    
    // Insert demo locations for company 1
    foreach ($demoLocations as $location) {
        // Check if already exists
        $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = 1 AND location_code = ?");
        $stmt->execute([$location['location_code']]);
        
        if (!$stmt->fetch()) {
            // Insert new location
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (company_id, name, location_code, location_type, description, created_at) 
                VALUES (1, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $location['name'],
                $location['location_code'], 
                $location['location_type'],
                $location['description']
            ]);
            echo "<p>✅ Eklendi: {$location['name']} ({$location['location_code']})</p>";
        } else {
            echo "<p>ℹ️ Mevcut: {$location['name']} ({$location['location_code']})</p>";
        }
    }
    
    echo "<h3>Tüm QR Lokasyonlar:</h3>";
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = 1 ORDER BY location_code");
    $stmt->execute();
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<ul>";
    foreach ($locations as $loc) {
        echo "<li><strong>{$loc['name']}</strong> - {$loc['location_code']} ({$loc['location_type']})</li>";
    }
    echo "</ul>";
    
    echo "<p><strong>Test için kullanım:</strong></p>";
    echo "<p>1. QR Scanner sayfasına gidin</p>";
    echo "<p>2. Manuel olarak şu kodlardan birini girin: LOC001, LOC002, LOC003</p>";
    echo "<p>3. Personel numarası: EMP001 (demo personel)</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Hata: " . $e->getMessage() . "</p>";
}
?>

<br><br>
<a href="qr/locations.php">← QR Lokasyon Yönetimi</a> | 
<a href="qr/scanner.php">QR Scanner Test →</a>