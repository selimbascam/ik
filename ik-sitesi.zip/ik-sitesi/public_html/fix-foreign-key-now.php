<?php
// Acil Foreign Key Düzeltme - Hosting Ortamında Çalıştır
require_once 'includes/config.php';
require_once 'includes/database.php';

header('Content-Type: text/html; charset=UTF-8');

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Acil Foreign Key Düzeltme</title>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }";
echo ".container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
echo ".success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }";
echo ".step { background: #e7f3ff; padding: 15px; margin: 10px 0; border-left: 4px solid #007bff; }";
echo ".sql-code { background: #f8f9fa; border: 1px solid #dee2e6; padding: 15px; border-radius: 5px; font-family: monospace; white-space: pre-wrap; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";

echo "<h1>🚨 Acil Foreign Key Constraint Düzeltme</h1>";
echo "<p><strong>Hata:</strong> employee_shifts tablosu mevcut olmayan 'shifts' tablosuna referans veriyor</p>";
echo "<hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='step'>";
    echo "<h3>Adım 1: Mevcut Constraint Analizi</h3>";
    
    // Check current constraints
    $stmt = $conn->query("
        SELECT 
            CONSTRAINT_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'employee_shifts'
        AND REFERENCED_TABLE_NAME IS NOT NULL
    ");
    $constraints = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($constraints) > 0) {
        echo "<p>Bulunan constraint'ler:</p>";
        foreach ($constraints as $constraint) {
            echo "<div class='sql-code'>";
            echo "Constraint: " . $constraint['CONSTRAINT_NAME'] . "\n";
            echo "Kolon: " . $constraint['COLUMN_NAME'] . "\n";
            echo "Referans: " . $constraint['REFERENCED_TABLE_NAME'] . "." . $constraint['REFERENCED_COLUMN_NAME'];
            echo "</div>";
        }
    }
    echo "</div>";
    
    echo "<div class='step'>";
    echo "<h3>Adım 2: Tablo Yapısı Kontrolü</h3>";
    
    // Check table structure
    $stmt = $conn->query("DESCRIBE employee_shifts");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasShiftId = false;
    $hasShiftTemplateId = false;
    
    foreach ($columns as $col) {
        if ($col['Field'] === 'shift_id') $hasShiftId = true;
        if ($col['Field'] === 'shift_template_id') $hasShiftTemplateId = true;
    }
    
    echo "<p>Tablo durumu:</p>";
    echo "<div class='sql-code'>";
    echo "shift_id kolonu: " . ($hasShiftId ? "✅ VAR" : "❌ YOK") . "\n";
    echo "shift_template_id kolonu: " . ($hasShiftTemplateId ? "✅ VAR" : "❌ YOK");
    echo "</div>";
    echo "</div>";
    
    echo "<div class='step'>";
    echo "<h3>Adım 3: Düzeltme İşlemleri</h3>";
    
    $fixApplied = false;
    
    // Step 1: Drop problematic foreign key
    foreach ($constraints as $constraint) {
        if ($constraint['REFERENCED_TABLE_NAME'] === 'shifts') {
            try {
                $conn->exec("ALTER TABLE employee_shifts DROP FOREIGN KEY " . $constraint['CONSTRAINT_NAME']);
                echo "<div class='success'>✅ Hatalı constraint silindi: " . $constraint['CONSTRAINT_NAME'] . "</div>";
                $fixApplied = true;
            } catch (Exception $e) {
                echo "<div class='error'>❌ Constraint silme hatası: " . $e->getMessage() . "</div>";
            }
        }
    }
    
    // Step 2: Fix column name if needed
    if ($hasShiftId && !$hasShiftTemplateId) {
        try {
            $conn->exec("ALTER TABLE employee_shifts CHANGE shift_id shift_template_id INT");
            echo "<div class='success'>✅ Kolon adı düzeltildi: shift_id → shift_template_id</div>";
            $fixApplied = true;
        } catch (Exception $e) {
            echo "<div class='error'>❌ Kolon değiştirme hatası: " . $e->getMessage() . "</div>";
        }
    } elseif (!$hasShiftTemplateId) {
        try {
            $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_template_id INT");
            echo "<div class='success'>✅ shift_template_id kolonu eklendi</div>";
            $fixApplied = true;
        } catch (Exception $e) {
            echo "<div class='error'>❌ Kolon ekleme hatası: " . $e->getMessage() . "</div>";
        }
    }
    
    // Step 3: Add correct foreign key
    try {
        $conn->exec("
            ALTER TABLE employee_shifts 
            ADD CONSTRAINT fk_employee_shifts_template 
            FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
        ");
        echo "<div class='success'>✅ Doğru foreign key constraint eklendi</div>";
        $fixApplied = true;
    } catch (Exception $e) {
        echo "<div class='warning'>⚠️ Foreign key ekleme uyarısı: " . $e->getMessage() . "</div>";
    }
    echo "</div>";
    
    echo "<div class='step'>";
    echo "<h3>Adım 4: Test İşlemi</h3>";
    
    // Test the fix
    $stmt = $conn->query("SELECT id FROM shift_templates WHERE is_active = 1 LIMIT 1");
    $template = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $conn->query("SELECT id FROM employees LIMIT 1");
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($template && $employee) {
        try {
            $testDate = date('Y-m-d', strtotime('+1 day'));
            
            $stmt = $conn->prepare("
                INSERT INTO employee_shifts 
                (employee_id, shift_template_id, shift_date, status) 
                VALUES (?, ?, ?, 'scheduled')
            ");
            $stmt->execute([$employee['id'], $template['id'], $testDate]);
            
            echo "<div class='success'>✅ Test vardiyası başarıyla oluşturuldu!</div>";
            
            // Clean up test data
            $conn->exec("DELETE FROM employee_shifts WHERE shift_date = '$testDate' AND employee_id = " . $employee['id']);
            echo "<div class='info'>ℹ️ Test verisi temizlendi</div>";
            
        } catch (Exception $e) {
            echo "<div class='error'>❌ Test hatası: " . $e->getMessage() . "</div>";
        }
    } else {
        echo "<div class='warning'>⚠️ Test için gerekli veriler bulunamadı</div>";
    }
    echo "</div>";
    
    if ($fixApplied) {
        echo "<div class='step'>";
        echo "<h3>🎉 Başarılı!</h3>";
        echo "<p>Foreign key constraint hatası düzeltildi. Artık vardiya oluşturma işlemi çalışacak.</p>";
        echo "<div style='margin-top: 20px;'>";
        echo "<a href='admin/company-holiday-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Tatil Yönetimi</a>";
        echo "<a href='employee/shift-schedule.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Vardiya Programı</a>";
        echo "</div>";
        echo "</div>";
    } else {
        echo "<div class='error'>";
        echo "<h3>❌ Düzeltme Uygulanamadı</h3>";
        echo "<p>Manuel SQL komutları kullanılması gerekebilir.</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>❌ Kritik Hata</h2>";
    echo "<p>Veritabanı bağlantı hatası: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>