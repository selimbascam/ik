<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>🔧 Hostinger Canlı Sistem Fix</h2>";

// Test 1: PHP Version
echo "<h3>📊 Sistem Bilgileri</h3>";
echo "<p><strong>PHP Version:</strong> " . PHP_VERSION . "</p>";
echo "<p><strong>Server:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
echo "<p><strong>Host:</strong> " . $_SERVER['HTTP_HOST'] . "</p>";

// Test 2: Database Driver Check
echo "<h3>🗃️ Database Driver Kontrolü</h3>";
$drivers = PDO::getAvailableDrivers();
echo "<p><strong>Available PDO Drivers:</strong> " . implode(', ', $drivers) . "</p>";

if (in_array('mysql', $drivers)) {
    echo "<p style='color: green;'>✅ MySQL driver mevcut</p>";
} else {
    echo "<p style='color: red;'>❌ MySQL driver eksik</p>";
}

// Test 3: Database Connection Test with Error Details
echo "<h3>🔌 Database Bağlantı Testi</h3>";

// Hostinger tipik ayarları
$test_configs = [
    [
        'name' => 'Standard Hostinger Config',
        'host' => 'localhost',
        'dbname' => 'u123456_szb_ik', // Placeholder - kullanıcı değiştirecek
        'username' => 'u123456_szb',   // Placeholder - kullanıcı değiştirecek
        'password' => 'your_password'  // Placeholder - kullanıcı değiştirecek
    ],
    [
        'name' => 'Alternative Hostinger Config',
        'host' => '127.0.0.1',
        'dbname' => 'u123456_szb_ik',
        'username' => 'u123456_szb',
        'password' => 'your_password'
    ]
];

foreach ($test_configs as $config) {
    echo "<div style='background: #f8f9fa; padding: 15px; margin: 10px 0; border-radius: 5px;'>";
    echo "<h4>{$config['name']}</h4>";
    
    try {
        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4";
        echo "<p><strong>DSN:</strong> $dsn</p>";
        echo "<p><strong>Username:</strong> {$config['username']}</p>";
        echo "<p><strong>Password:</strong> " . (strlen($config['password']) > 5 ? "Set (" . strlen($config['password']) . " chars)" : "Not set") . "</p>";
        
        $conn = new PDO($dsn, $config['username'], $config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        
        echo "<p style='color: green;'>✅ Bağlantı başarılı!</p>";
        
        // Test tables
        $stmt = $conn->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        echo "<p><strong>Tables:</strong> " . (count($tables) > 0 ? implode(', ', $tables) : 'No tables found') . "</p>";
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Bağlantı hatası:</p>";
        echo "<p><code>" . htmlspecialchars($e->getMessage()) . "</code></p>";
    }
    echo "</div>";
}

// Test 4: File Permissions
echo "<h3>📁 Dosya İzinleri Kontrolü</h3>";
$files_to_check = [
    'includes/database.php',
    'auth/company-login.php',
    'auth/employee-login.php',
    'index.php'
];

foreach ($files_to_check as $file) {
    if (file_exists($file)) {
        $perms = fileperms($file);
        echo "<p><strong>$file:</strong> " . substr(sprintf('%o', $perms), -4) . " ✅</p>";
    } else {
        echo "<p style='color: red;'><strong>$file:</strong> Dosya bulunamadı ❌</p>";
    }
}

// Test 5: Session Support
echo "<h3>🔐 Session Desteği</h3>";
if (function_exists('session_start')) {
    @session_start();
    echo "<p style='color: green;'>✅ Session desteği aktif</p>";
    echo "<p><strong>Session ID:</strong> " . session_id() . "</p>";
} else {
    echo "<p style='color: red;'>❌ Session desteği yok</p>";
}

// Test 6: Error Log
echo "<h3>📝 Error Log Kontrolü</h3>";
$error_log = ini_get('error_log');
echo "<p><strong>Error Log Path:</strong> " . ($error_log ?: 'Default system log') . "</p>";

// Test 7: Include Path Test
echo "<h3>🔗 Include Path Testi</h3>";
$include_test_files = [
    'includes/config.php',
    'includes/database.php'
];

foreach ($include_test_files as $file) {
    echo "<p><strong>Testing:</strong> $file</p>";
    if (file_exists($file)) {
        try {
            ob_start();
            include_once $file;
            $output = ob_get_clean();
            echo "<p style='color: green;'>✅ Include başarılı</p>";
            if (!empty($output)) {
                echo "<p><strong>Output:</strong> <code>" . htmlspecialchars(substr($output, 0, 200)) . "</code></p>";
            }
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Include hatası: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Dosya bulunamadı</p>";
    }
}

// Manual Database Config Generator
echo "<h3>⚙️ Hostinger Database Config Generator</h3>";
echo "<div style='background: #e7f3ff; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<h4>📋 Hostinger Panel'den Bilgileri Alıp Aşağıdaki Kodu Kullanın:</h4>";
echo "<pre style='background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto;'>";
echo htmlspecialchars('
// includes/database.php içindeki satır 25-27 değiştirin:

$this->host = "localhost";           // Genelde localhost
$this->db_name = "u123456_yourdb";   // Hostinger DB adınız (u ile başlar)
$this->username = "u123456_user";    // Hostinger kullanıcı adınız
$this->password = "your_real_pass";  // Hostinger şifreniz (güçlü şifre)

// Örnek:
$this->host = "localhost";
$this->db_name = "u745632_szb_ik";
$this->username = "u745632_admin";
$this->password = "MyStr0ng_P@ss!";
');
echo "</pre>";
echo "</div>";

// Debug URL'ler
echo "<h3>🔗 Debug URL'leri</h3>";
echo "<div style='margin: 20px 0;'>";
echo "<a href='auth/company-login.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;' target='_blank'>Company Login</a>";
echo "<a href='debug-live-login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;' target='_blank'>Login Debug</a>";
echo "<a href='index.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;' target='_blank'>Ana Sayfa</a>";
echo "</div>";

echo "<div style='background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<h4>🎯 Sonraki Adımlar:</h4>";
echo "<ol>";
echo "<li><strong>Hostinger Panel'e gidin</strong> → Databases → MySQL Databases</li>";
echo "<li><strong>Database bilgilerini kopyalayın</strong> (DB name, username, password)</li>";
echo "<li><strong>includes/database.php</strong> dosyasını düzenleyin (satır 25-27)</li>";
echo "<li><strong>Test edin:</strong> company-login.php'ye girin</li>";
echo "</ol>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }
h2, h3 { color: #333; }
code { background: #f8f9fa; padding: 2px 5px; border-radius: 3px; }
pre { white-space: pre-wrap; }
</style>