<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🚨 Emergency Login Fix</h1>";
echo "<style>body{font-family:Arial;margin:20px;} .error{color:red;} .success{color:green;} .info{color:blue;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>Step 1: Add Password Column</h2>";
    
    // Check if password column exists
    $stmt = $conn->query("SHOW COLUMNS FROM companies LIKE 'password'");
    $passwordExists = $stmt->fetch();
    
    if (!$passwordExists) {
        echo "<p class='info'>Adding password column...</p>";
        $conn->exec("ALTER TABLE companies ADD COLUMN password VARCHAR(255) DEFAULT NULL");
        echo "<p class='success'>✅ Password column added</p>";
    } else {
        echo "<p class='success'>✅ Password column already exists</p>";
    }
    
    echo "<h2>Step 2: Set Test Password</h2>";
    
    // Set password for zeynep@szb.com.tr
    $email = 'zeynep@szb.com.tr';
    $password = 'Abc123456';
    $hashedPassword = md5($password);
    
    $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE email = ?");
    $stmt->execute([$hashedPassword, $email]);
    
    echo "<p class='success'>✅ Password set for $email</p>";
    echo "<p><strong>Login Credentials:</strong></p>";
    echo "<ul>";
    echo "<li>Email: $email</li>";
    echo "<li>Password: $password</li>";
    echo "<li>Company Code: SZB38211</li>";
    echo "</ul>";
    
    echo "<h2>Step 3: Test Login</h2>";
    
    // Test the login
    $stmt = $conn->prepare("
        SELECT * FROM companies 
        WHERE email = ? AND password = MD5(?) AND company_code = ?
    ");
    $stmt->execute([$email, $password, 'SZB38211']);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($company) {
        echo "<p class='success'>✅ Login test successful!</p>";
        echo "<p><strong>Company Found:</strong> {$company['company_name']}</p>";
    } else {
        echo "<p class='error'>❌ Login test failed</p>";
        
        // Debug info
        echo "<h3>Debug Info:</h3>";
        $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
        $stmt->execute([$email]);
        $companyData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($companyData) {
            echo "<p>Company exists but password mismatch</p>";
            echo "<p>Stored hash: " . ($companyData['password'] ?? 'NULL') . "</p>";
            echo "<p>Expected hash: " . md5($password) . "</p>";
        } else {
            echo "<p>No company found with email: $email</p>";
        }
    }
    
    echo "<div style='background:#d4edda;padding:15px;border:1px solid #c3e6cb;margin:20px 0;'>";
    echo "<h3>🎯 Emergency Fix Complete</h3>";
    echo "<p>The login system has been fixed. You can now try logging in again.</p>";
    echo "<p><a href='auth/company-login.php' style='background:#007bff;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;'>🚀 Try Login Now</a></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Emergency fix failed: " . $e->getMessage() . "</p>";
}
?>