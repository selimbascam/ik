<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/security.php';
require_once '../includes/helpers.php';

// Check if user is logged in as company admin
if (!isset($_SESSION['company_id'])) {
    header('Location: ../auth/company-login.php');
    exit();
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $companyId = $_SESSION['company_id'];
    
    // Get company details
    $companyStmt = execute_safe_query($conn, "
        SELECT * FROM companies 
        WHERE id = ? AND is_active = 1
    ", [$companyId]);
    
    $company = $companyStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        session_destroy();
        header('Location: ../auth/company-login.php?error=session_invalid');
        exit();
    }
    
    // Get system statistics
    $stats = getSystemStats($conn);
    
    // Get company-specific statistics
    $companyStats = [
        'total_employees' => 0,
        'active_employees' => 0,
        'departments' => 0,
        'today_attendance' => 0,
        'today_attendance_rate' => 0,
        'pending_leaves' => 0,
        'active_leaves' => 0,
        'qr_locations' => 0
    ];
    
    // Total employees for this company
    $empStmt = execute_safe_query($conn, "
        SELECT COUNT(*) as total, 
               SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active
        FROM employees 
        WHERE company_id = ?
    ", [$companyId]);
    
    $empData = $empStmt->fetch(PDO::FETCH_ASSOC);
    $companyStats['total_employees'] = $empData['total'] ?? 0;
    $companyStats['active_employees'] = $empData['active'] ?? 0;
    
    // Today's attendance
    $attStmt = execute_safe_query($conn, "
        SELECT COUNT(DISTINCT employee_id) as present
        FROM attendance_records ar
        JOIN employees e ON ar.employee_id = e.id
        WHERE e.company_id = ? AND ar.date = CURDATE()
    ", [$companyId]);
    
    $attData = $attStmt->fetch(PDO::FETCH_ASSOC);
    $companyStats['today_attendance'] = $attData['present'] ?? 0;
    
    if ($companyStats['active_employees'] > 0) {
        $companyStats['today_attendance_rate'] = round(($companyStats['today_attendance'] / $companyStats['active_employees']) * 100);
    }
    
    // QR Locations for this company
    $qrStmt = execute_safe_query($conn, "
        SELECT COUNT(*) as count
        FROM qr_locations 
        WHERE company_id = ? AND is_active = 1
    ", [$companyId]);
    
    $qrData = $qrStmt->fetch(PDO::FETCH_ASSOC);
    $companyStats['qr_locations'] = $qrData['count'] ?? 0;
    
    // Recent activities
    $recentStmt = execute_safe_query($conn, "
        SELECT ar.*, e.first_name, e.last_name, ql.name as location_name
        FROM attendance_records ar
        JOIN employees e ON ar.employee_id = e.id
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE e.company_id = ? AND ar.date >= DATE_SUB(CURDATE(), INTERVAL 7 DAYS)
        ORDER BY ar.check_in_time DESC
        LIMIT 10
    ", [$companyId]);
    
    $recentActivities = $recentStmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    error_log("Modern Dashboard Error: " . $e->getMessage());
    $error = "Dashboard yüklenirken bir hata oluştu.";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Yönetim Sistemi - Ana Sayfa</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --warning: #f72585;
            --light: #f8f9fa;
            --dark: #212529;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .card-hover {
            transition: all 0.3s ease;
        }
        
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .dashboard-stat {
            border-left: 4px solid var(--primary);
        }
        
        .stat-employee {
            border-left-color: #4cc9f0;
        }
        
        .stat-department {
            border-left-color: #f72585;
        }
        
        .stat-attendance {
            border-left-color: #3a0ca3;
        }
        
        .navigation-item {
            transition: all 0.2s;
        }
        
        .navigation-item:hover {
            background-color: rgba(67, 97, 238, 0.1);
            border-left: 4px solid var(--primary);
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background-color: #f72585;
            color: white;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .progress-ring {
            transform: rotate(-90deg);
        }
        
        .progress-ring-fill {
            transition: stroke-dashoffset 0.5s ease-in-out;
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-md flex flex-col">
            <!-- Logo -->
            <div class="p-5 border-b">
                <h1 class="text-lg font-bold text-gray-800 flex items-center">
                    <i class="fas fa-building mr-2 text-blue-600"></i>
                    <?php echo safe_html($company['company_name']); ?>
                </h1>
                <p class="text-xs text-gray-500 mt-1">Yönetim Paneli v2.1.0</p>
            </div>
            
            <!-- Navigation -->
            <div class="flex-1 overflow-y-auto py-4">
                <div class="px-4 space-y-2">
                    <div class="text-xs uppercase text-gray-500 font-semibold mb-2 px-2">Genel</div>
                    
                    <a href="modern-dashboard.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 bg-blue-50 rounded-lg">
                        <i class="fas fa-home mr-3 text-blue-600"></i>
                        <span>Ana Sayfa</span>
                    </a>
                    
                    <a href="../admin/work-settings.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 rounded-lg">
                        <i class="fas fa-cog mr-3 text-green-500"></i>
                        <span>İş Ayarları</span>
                    </a>
                    
                    <a href="../employee/employee-list.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 rounded-lg">
                        <i class="fas fa-users mr-3 text-purple-500"></i>
                        <span>Personel Yönetimi</span>
                    </a>
                    
                    <a href="../admin/attendance-reports.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 rounded-lg">
                        <i class="fas fa-chart-line mr-3 text-yellow-500"></i>
                        <span>Devam Raporları</span>
                    </a>
                    
                    <a href="../admin/shift-management.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 rounded-lg">
                        <i class="fas fa-calendar-alt mr-3 text-indigo-500"></i>
                        <span>Vardiya Yönetimi</span>
                    </a>
                    
                    <div class="text-xs uppercase text-gray-500 font-semibold mt-6 mb-2 px-2">Yönetim</div>
                    
                    <a href="../admin/qr-management.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 rounded-lg">
                        <i class="fas fa-qrcode mr-3 text-teal-500"></i>
                        <span>QR Kod Sistemleri</span>
                    </a>
                    
                    <a href="../admin/company-settings.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 rounded-lg">
                        <i class="fas fa-building mr-3 text-red-500"></i>
                        <span>Şirket Ayarları</span>
                    </a>
                    
                    <a href="../admin/system-reports.php" class="navigation-item flex items-center px-4 py-3 text-gray-700 rounded-lg">
                        <i class="fas fa-file-alt mr-3 text-gray-500"></i>
                        <span>Sistem Raporları</span>
                    </a>
                </div>
            </div>
            
            <!-- User Section -->
            <div class="p-4 border-t">
                <div class="flex items-center">
                    <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <i class="fas fa-user text-blue-600"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-gray-800"><?php echo safe_html($company['contact_person'] ?? 'Yönetici'); ?></p>
                        <p class="text-xs text-gray-500">Sistem Yöneticisi</p>
                    </div>
                </div>
                <div class="mt-3">
                    <a href="../auth/logout.php" class="text-xs text-red-600 hover:text-red-800 flex items-center">
                        <i class="fas fa-sign-out-alt mr-1"></i>
                        Çıkış Yap
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 overflow-y-auto">
            <!-- Header -->
            <div class="bg-white shadow-sm px-8 py-4 flex justify-between items-center">
                <div>
                    <h2 class="text-xl font-semibold text-gray-800">Ana Sayfa</h2>
                    <p class="text-sm text-gray-500">Hoş geldiniz, sistem istatistikleriniz aşağıda özetlenmiştir.</p>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="text-sm text-gray-600">
                        <span id="current-time"></span>
                    </div>
                    
                    <div class="relative">
                        <button class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors">
                            <i class="fas fa-bell text-gray-600"></i>
                        </button>
                        <?php if ($companyStats['today_attendance'] < $companyStats['active_employees'] * 0.8): ?>
                        <span class="notification-dot">!</span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="relative">
                        <a href="../employee/add-employee.php" class="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            <i class="fas fa-plus"></i>
                            <span>Personel Ekle</span>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="p-8">
                <!-- Stats Overview -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div class="dashboard-stat bg-white rounded-xl shadow-sm p-6">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-sm text-gray-500">Toplam Personel</p>
                                <h3 class="text-2xl font-bold text-gray-800 mt-1"><?php echo $companyStats['total_employees']; ?></h3>
                                <p class="text-xs text-green-500 mt-2">
                                    <i class="fas fa-check-circle mr-1"></i> 
                                    <?php echo $companyStats['active_employees']; ?> aktif
                                </p>
                            </div>
                            <div class="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                                <i class="fas fa-users text-blue-600 text-xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-stat stat-department bg-white rounded-xl shadow-sm p-6">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-sm text-gray-500">QR Lokasyonları</p>
                                <h3 class="text-2xl font-bold text-gray-800 mt-1"><?php echo $companyStats['qr_locations']; ?></h3>
                                <p class="text-xs text-gray-500 mt-2">Aktif tarama noktası</p>
                            </div>
                            <div class="w-12 h-12 rounded-lg bg-pink-100 flex items-center justify-center">
                                <i class="fas fa-qrcode text-pink-600 text-xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-stat stat-attendance bg-white rounded-xl shadow-sm p-6">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-sm text-gray-500">Bugünkü Devam</p>
                                <h3 class="text-2xl font-bold text-gray-800 mt-1"><?php echo $companyStats['today_attendance_rate']; ?>%</h3>
                                <p class="text-xs <?php echo $companyStats['today_attendance_rate'] >= 80 ? 'text-green-500' : 'text-yellow-500'; ?> mt-2">
                                    <?php echo $companyStats['today_attendance']; ?>/<?php echo $companyStats['active_employees']; ?> personel
                                </p>
                            </div>
                            <div class="w-12 h-12 rounded-lg bg-indigo-100 flex items-center justify-center">
                                <i class="fas fa-fingerprint text-indigo-600 text-xl"></i>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-stat stat-employee bg-white rounded-xl shadow-sm p-6">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="text-sm text-gray-500">Sistem Durumu</p>
                                <h3 class="text-2xl font-bold text-green-600 mt-1">Aktif</h3>
                                <p class="text-xs text-gray-500 mt-2">Tüm sistemler çalışıyor</p>
                            </div>
                            <div class="w-12 h-12 rounded-lg bg-teal-100 flex items-center justify-center">
                                <i class="fas fa-server text-teal-600 text-xl"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Main Dashboard Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Left Column -->
                    <div class="lg:col-span-2 space-y-8">
                        <!-- Quick Actions -->
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <div class="flex justify-between items-center mb-6">
                                <h3 class="text-lg font-semibold text-gray-800">Hızlı Erişim</h3>
                                <span class="text-sm text-gray-500">Sık kullanılan işlemler</span>
                            </div>
                            
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <a href="../admin/work-settings.php" class="card-hover flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg text-center">
                                    <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center mb-2">
                                        <i class="fas fa-cog text-blue-600"></i>
                                    </div>
                                    <span class="text-sm text-gray-700">İş Ayarları</span>
                                </a>
                                
                                <a href="../employee/add-employee.php" class="card-hover flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg text-center">
                                    <div class="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center mb-2">
                                        <i class="fas fa-user-plus text-green-600"></i>
                                    </div>
                                    <span class="text-sm text-gray-700">Personel Ekle</span>
                                </a>
                                
                                <a href="../admin/qr-generator.php" class="card-hover flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg text-center">
                                    <div class="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center mb-2">
                                        <i class="fas fa-qrcode text-purple-600"></i>
                                    </div>
                                    <span class="text-sm text-gray-700">QR Oluştur</span>
                                </a>
                                
                                <a href="../admin/attendance-reports.php" class="card-hover flex flex-col items-center justify-center p-4 bg-gray-50 rounded-lg text-center">
                                    <div class="w-10 h-10 rounded-lg bg-yellow-100 flex items-center justify-center mb-2">
                                        <i class="fas fa-chart-bar text-yellow-600"></i>
                                    </div>
                                    <span class="text-sm text-gray-700">Raporlar</span>
                                </a>
                            </div>
                        </div>
                        
                        <!-- Recent Activities -->
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <div class="flex justify-between items-center mb-6">
                                <h3 class="text-lg font-semibold text-gray-800">Son Aktiviteler</h3>
                                <a href="../admin/activity-log.php" class="text-sm text-blue-600 hover:text-blue-800">Tümünü Gör</a>
                            </div>
                            
                            <div class="space-y-4">
                                <?php if (!empty($recentActivities)): ?>
                                    <?php foreach (array_slice($recentActivities, 0, 5) as $activity): ?>
                                        <?php 
                                        $activityInfo = getActivityTypeInfo($activity['activity_type']);
                                        $timeAgo = date('H:i', strtotime($activity['check_in_time']));
                                        ?>
                                        <div class="flex items-center p-3 bg-gray-50 rounded-lg">
                                            <div class="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                                                <span class="text-lg"><?php echo $activityInfo['icon']; ?></span>
                                            </div>
                                            <div class="ml-4 flex-1">
                                                <p class="text-sm font-medium text-gray-800">
                                                    <?php echo safe_html($activity['first_name'] . ' ' . $activity['last_name']); ?>
                                                </p>
                                                <p class="text-xs text-gray-500">
                                                    <?php echo $activityInfo['text']; ?>
                                                    <?php if ($activity['location_name']): ?>
                                                        - <?php echo safe_html($activity['location_name']); ?>
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                            <div class="text-xs text-gray-400">
                                                <?php echo $timeAgo; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="text-center text-gray-500 py-8">
                                        <i class="fas fa-clock text-3xl mb-2 opacity-50"></i>
                                        <p>Henüz aktivite kaydı bulunmuyor</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Right Column -->
                    <div class="space-y-8">
                        <!-- Attendance Overview -->
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-6">Devam Özeti</h3>
                            
                            <div class="flex items-center justify-center mb-6">
                                <div class="relative w-32 h-32">
                                    <svg class="progress-ring w-32 h-32" viewBox="0 0 120 120">
                                        <circle cx="60" cy="60" r="54" fill="none" stroke="#e5e7eb" stroke-width="8"/>
                                        <circle cx="60" cy="60" r="54" fill="none" stroke="#4f46e5" stroke-width="8" 
                                                stroke-linecap="round" class="progress-ring-fill"
                                                stroke-dasharray="339.292" 
                                                stroke-dashoffset="<?php echo 339.292 - (339.292 * $companyStats['today_attendance_rate'] / 100); ?>"/>
                                    </svg>
                                    <div class="absolute inset-0 flex items-center justify-center">
                                        <div class="text-center">
                                            <div class="text-2xl font-bold text-gray-800"><?php echo $companyStats['today_attendance_rate']; ?>%</div>
                                            <div class="text-xs text-gray-500">Devam Oranı</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="space-y-3">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Mevcut</span>
                                    <span class="text-sm font-medium text-green-600"><?php echo $companyStats['today_attendance']; ?></span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Toplam</span>
                                    <span class="text-sm font-medium text-gray-800"><?php echo $companyStats['active_employees']; ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- System Status -->
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-6">Sistem Durumu</h3>
                            
                            <div class="space-y-4">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                                        <span class="text-sm text-gray-600">Database</span>
                                    </div>
                                    <span class="text-xs text-green-600 font-medium">Online</span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                                        <span class="text-sm text-gray-600">QR Sistemi</span>
                                    </div>
                                    <span class="text-xs text-green-600 font-medium">Aktif</span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                                        <span class="text-sm text-gray-600">Notifications</span>
                                    </div>
                                    <span class="text-xs text-green-600 font-medium">Çalışıyor</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Quick Stats -->
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-6">Hızlı İstatistikler</h3>
                            
                            <div class="space-y-4">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Bu Hafta Kayıt</span>
                                    <span class="text-sm font-medium text-blue-600">
                                        <?php 
                                        $weeklyStmt = execute_safe_query($conn, "
                                            SELECT COUNT(*) as count
                                            FROM attendance_records ar
                                            JOIN employees e ON ar.employee_id = e.id
                                            WHERE e.company_id = ? AND WEEK(ar.date) = WEEK(CURDATE())
                                        ", [$companyId]);
                                        $weeklyData = $weeklyStmt->fetch(PDO::FETCH_ASSOC);
                                        echo $weeklyData['count'] ?? 0;
                                        ?>
                                    </span>
                                </div>
                                
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Bu Ay Kayıt</span>
                                    <span class="text-sm font-medium text-purple-600">
                                        <?php 
                                        $monthlyStmt = execute_safe_query($conn, "
                                            SELECT COUNT(*) as count
                                            FROM attendance_records ar
                                            JOIN employees e ON ar.employee_id = e.id
                                            WHERE e.company_id = ? AND MONTH(ar.date) = MONTH(CURDATE())
                                        ", [$companyId]);
                                        $monthlyData = $monthlyStmt->fetch(PDO::FETCH_ASSOC);
                                        echo $monthlyData['count'] ?? 0;
                                        ?>
                                    </span>
                                </div>
                                
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-gray-600">Ortalama Devam</span>
                                    <span class="text-sm font-medium text-green-600">
                                        <?php echo $companyStats['today_attendance_rate']; ?>%
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Update current time
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('tr-TR', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            document.getElementById('current-time').textContent = timeString;
        }
        
        // Update time every second
        updateTime();
        setInterval(updateTime, 1000);
        
        // Auto-refresh page every 5 minutes
        setTimeout(() => {
            window.location.reload();
        }, 300000);
    </script>
</body>
</html>