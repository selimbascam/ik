<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 QR Locations Table Fix</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>📊 QR Locations Table Analysis</h3>";
    
    // Check table structure
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th>";
    echo "</tr>";
    
    $hasLocationName = false;
    $hasName = false;
    $availableColumns = [];
    
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($col['Field'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Type'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Null'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Key'] ?? '') . "</td>";
        echo "<td>" . htmlspecialchars($col['Default'] ?? '') . "</td>";
        echo "</tr>";
        
        $fieldName = $col['Field'] ?? '';
        $availableColumns[] = $fieldName;
        
        if ($fieldName === 'location_name') {
            $hasLocationName = true;
        } elseif ($fieldName === 'name') {
            $hasName = true;
        }
    }
    echo "</table>";
    
    echo "<h4>🔍 Column Mapping Analysis</h4>";
    echo "<ul>";
    echo "<li>location_name column: " . ($hasLocationName ? '✅ EXISTS' : '❌ MISSING') . "</li>";
    echo "<li>name column: " . ($hasName ? '✅ EXISTS' : '❌ MISSING') . "</li>";
    echo "<li>Available columns: " . implode(', ', $availableColumns) . "</li>";
    echo "</ul>";
    
    // Determine correct column name
    $nameColumn = 'id'; // Default fallback
    if ($hasLocationName) {
        $nameColumn = 'location_name';
    } elseif ($hasName) {
        $nameColumn = 'name';
    } elseif (in_array('location', $availableColumns)) {
        $nameColumn = 'location';
    } elseif (in_array('description', $availableColumns)) {
        $nameColumn = 'description';
    }
    
    echo "<p><strong>Recommended column for location name:</strong> <code>$nameColumn</code></p>";
    
    // Test query with correct column
    echo "<h4>🧪 Test Query with Correct Column</h4>";
    
    try {
        $stmt = $conn->prepare("SELECT id, $nameColumn as location_name, latitude, longitude FROM qr_locations LIMIT 5");
        $stmt->execute();
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<p>✅ Query successful - found " . count($locations) . " locations</p>";
        
        if (!empty($locations)) {
            echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
            echo "<tr style='background: #f8f9fa;'><th>ID</th><th>Location Name</th><th>Coordinates</th></tr>";
            
            foreach ($locations as $loc) {
                $lat = $loc['latitude'] ?? 'N/A';
                $lng = $loc['longitude'] ?? 'N/A';
                echo "<tr>";
                echo "<td>" . ($loc['id'] ?? 'N/A') . "</td>";
                echo "<td>" . htmlspecialchars($loc['location_name'] ?? 'Unnamed') . "</td>";
                echo "<td>$lat, $lng</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ Test query failed: " . htmlspecialchars($e->getMessage()) . "</p>";
    }
    
    // Check for test company locations
    echo "<h4>📍 Test Company QR Locations</h4>";
    
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = 4");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $testCompanyCount = $result['count'] ?? 0;
        
        echo "<p>Test company (ID: 4) locations: $testCompanyCount</p>";
        
        if ($testCompanyCount == 0) {
            echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
            echo "<h5>⚠️ No QR Locations for Test Company</h5>";
            echo "<p>The test company doesn't have any QR locations set up. This is why QR scanning might not work.</p>";
            echo "<p><strong>Solution:</strong> Create QR locations using the QR Generator in admin panel.</p>";
            echo "</div>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ Company location check failed: " . $e->getMessage() . "</p>";
    }
    
    // Generate corrected helper functions
    echo "<h4>🔧 QR Location Helper Function</h4>";
    
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>";
    echo "<h5>Recommended Helper Function:</h5>";
    echo "<pre style='background: white; padding: 10px; border-radius: 3px; overflow-x: auto;'>";
    echo htmlspecialchars("
function getQRLocationName(\$conn, \$locationId) {
    // Auto-detect correct column name
    \$stmt = \$conn->query(\"SHOW COLUMNS FROM qr_locations\");
    \$columns = \$stmt->fetchAll(PDO::FETCH_COLUMN);
    
    \$nameCol = 'id'; // fallback
    if (in_array('location_name', \$columns)) {
        \$nameCol = 'location_name';
    } elseif (in_array('name', \$columns)) {
        \$nameCol = 'name';
    } elseif (in_array('location', \$columns)) {
        \$nameCol = 'location';
    }
    
    \$stmt = \$conn->prepare(\"SELECT \$nameCol as name FROM qr_locations WHERE id = ?\");
    \$stmt->execute([\$locationId]);
    \$result = \$stmt->fetch(PDO::FETCH_ASSOC);
    
    return \$result['name'] ?? 'QR Location';
}
");
    echo "</pre>";
    echo "</div>";
    
    echo "<h3>🔗 Next Steps</h3>";
    echo "<ul>";
    echo "<li><a href='admin/qr-generator.php' style='color: #dc3545; font-weight: bold;'>Create QR Locations →</a></li>";
    echo "<li><a href='employee/qr-attendance.php' style='color: #0056b3;'>Test QR Attendance</a></li>";
    echo "<li><a href='critical-qr-fix-summary.php' style='color: #6c757d;'>QR Fix Summary</a></li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Database Error</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { border-collapse: collapse; width: 100%; margin: 10px 0; }";
echo "th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }";
echo "th { background-color: #f2f2f2; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "pre { overflow-x: auto; }";
echo "</style>";
?>