<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Test Employee Creation (30716129672)</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if employee already exists
    $checkStmt = $conn->prepare("SELECT id, first_name, last_name FROM employees WHERE employee_number = ?");
    $checkStmt->execute(['30716129672']);
    $existing = $checkStmt->fetch();
    
    if ($existing) {
        echo "<p style='color: green;'>✅ Employee 30716129672 already exists: {$existing['first_name']} {$existing['last_name']}</p>";
        
        // Update password to ensure login works
        $hashedPassword = password_hash('123456', PASSWORD_DEFAULT);
        $updateStmt = $conn->prepare("UPDATE employees SET password = ? WHERE employee_number = ?");
        $updateStmt->execute([$hashedPassword, '30716129672']);
        echo "<p style='color: green;'>✅ Password updated for existing employee</p>";
        
    } else {
        echo "<p>Creating new test employee with number 30716129672...</p>";
        
        // Check available columns
        $columns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll();
        $availableFields = array_column($columns, 'Field');
        
        echo "<h4>Available Employee Table Columns:</h4>";
        echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        foreach ($availableFields as $col) {
            echo "<span style='background: #e9ecef; padding: 2px 6px; margin: 2px; border-radius: 3px; display: inline-block; font-size: 12px;'>{$col}</span> ";
        }
        echo "</div>";
        
        // Build INSERT query based on available columns
        $insertData = [
            'employee_number' => '30716129672',
            'first_name' => 'Test',
            'last_name' => 'Personel',
            'password' => password_hash('123456', PASSWORD_DEFAULT)
        ];
        
        // Add optional fields if they exist
        $optionalFields = [
            'status' => 'active',
            'company_id' => 1,
            'department_id' => 1,
            'employee_code' => '30716129672',
            'is_active' => 1,
            'monthly_salary' => 17000,
            'wage_per_day' => 500,
            'wage_type' => 'monthly',
            'email' => 'test30716129672@example.com',
            'phone' => '05551234567',
            'hire_date' => date('Y-m-d'),
            'role' => 'employee'
        ];
        
        foreach ($optionalFields as $field => $value) {
            if (in_array($field, $availableFields)) {
                $insertData[$field] = $value;
            }
        }
        
        // Build and execute INSERT
        $fields = array_keys($insertData);
        $values = array_values($insertData);
        $placeholders = array_fill(0, count($fields), '?');
        
        $fieldsStr = implode(', ', $fields);
        $placeholdersStr = implode(', ', $placeholders);
        
        echo "<h4>INSERT Query:</h4>";
        echo "<code style='background: #f8f9fa; padding: 5px; display: block; margin: 10px 0;'>";
        echo "INSERT INTO employees ({$fieldsStr}) VALUES ({$placeholdersStr})";
        echo "</code>";
        
        try {
            $stmt = $conn->prepare("INSERT INTO employees ({$fieldsStr}) VALUES ({$placeholdersStr})");
            $stmt->execute($values);
            
            echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
            echo "<h4>🎉 SUCCESS! Test employee created</h4>";
            echo "<p><strong>Login Credentials:</strong></p>";
            echo "<ul>";
            echo "<li><strong>Employee Number:</strong> 30716129672</li>";
            echo "<li><strong>Password:</strong> 123456</li>";
            echo "<li><strong>Name:</strong> Test Personel</li>";
            echo "</ul>";
            echo "</div>";
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Insert failed: " . $e->getMessage() . "</p>";
            echo "<p>Trying simpler approach...</p>";
            
            // Fallback: minimal INSERT
            try {
                $minimalStmt = $conn->prepare("
                    INSERT INTO employees (employee_number, first_name, last_name, password) 
                    VALUES (?, ?, ?, ?)
                ");
                $minimalStmt->execute(['30716129672', 'Test', 'Personel', password_hash('123456', PASSWORD_DEFAULT)]);
                echo "<p style='color: green;'>✅ Minimal employee created successfully</p>";
                
                // Update additional fields separately
                if (in_array('company_id', $availableFields)) {
                    $conn->prepare("UPDATE employees SET company_id = 1 WHERE employee_number = ?")->execute(['30716129672']);
                }
                if (in_array('is_active', $availableFields)) {
                    $conn->prepare("UPDATE employees SET is_active = 1 WHERE employee_number = ?")->execute(['30716129672']);
                }
                if (in_array('status', $availableFields)) {
                    $conn->prepare("UPDATE employees SET status = 'active' WHERE employee_number = ?")->execute(['30716129672']);
                }
                
                echo "<p style='color: green;'>✅ Additional fields updated</p>";
                
            } catch (Exception $e2) {
                echo "<p style='color: red;'>❌ Even minimal insert failed: " . $e2->getMessage() . "</p>";
            }
        }
    }
    
    // Final verification
    echo "<h3>Final Verification</h3>";
    $finalCheck = $conn->prepare("SELECT id, first_name, last_name, employee_number, password FROM employees WHERE employee_number = ?");
    $finalCheck->execute(['30716129672']);
    $employee = $finalCheck->fetch();
    
    if ($employee) {
        echo "<p style='color: green; font-weight: bold;'>✅ Employee 30716129672 is ready for login!</p>";
        echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px;'>";
        echo "<ul>";
        echo "<li><strong>ID:</strong> {$employee['id']}</li>";
        echo "<li><strong>Name:</strong> {$employee['first_name']} {$employee['last_name']}</li>";
        echo "<li><strong>Employee Number:</strong> {$employee['employee_number']}</li>";
        echo "<li><strong>Password Set:</strong> " . (!empty($employee['password']) ? 'Yes' : 'No') . "</li>";
        echo "</ul>";
        echo "</div>";
        
        // Test password verification
        if (password_verify('123456', $employee['password'])) {
            echo "<p style='color: green;'>✅ Password verification successful</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ Password verification failed</p>";
        }
        
        echo "<p><strong>Test login here:</strong> <a href='auth/employee-login.php' target='_blank' style='color: #0066cc;'>Employee Login</a></p>";
        
    } else {
        echo "<p style='color: red;'>❌ Employee creation failed</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
code { background: #f8f9fa; padding: 2px 4px; border-radius: 3px; }
ul { margin: 10px 0; padding-left: 20px; }
</style>