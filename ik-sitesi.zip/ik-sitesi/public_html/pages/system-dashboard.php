<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../api/common/auth.php';

// Check system admin authentication
session_start();
if (!isset($_SESSION['system_admin_id']) || $_SESSION['login_type'] !== 'system') {
    header('Location: system-login.php');
    exit;
}

$adminId = $_SESSION['system_admin_id'];
$adminRole = $_SESSION['system_admin_role'];
$adminEmail = $_SESSION['system_admin_email'];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Yönetimi - SZB İK Takip</title>
    <meta name="description" content="SZB İK Takip sistem yönetim paneli.">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="fas fa-cogs me-2"></i>
                SZB İK Takip - Sistem Yönetimi
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-shield me-1"></i>
                            <?= htmlspecialchars($adminEmail) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil</a></li>
                            <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2"></i>Ayarlar</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-tachometer-alt me-2"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('companies')">
                                <i class="fas fa-building me-2"></i>
                                Şirket Yönetimi
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('packages')">
                                <i class="fas fa-box me-2"></i>
                                Paket Yönetimi
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('subscriptions')">
                                <i class="fas fa-credit-card me-2"></i>
                                Abonelikler
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('system-logs')">
                                <i class="fas fa-file-alt me-2"></i>
                                Sistem Logları
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('analytics')">
                                <i class="fas fa-chart-line me-2"></i>
                                Analizler
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('settings')">
                                <i class="fas fa-cog me-2"></i>
                                Sistem Ayarları
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div id="main-content">
                    <!-- Dashboard Content -->
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">
                            <i class="fas fa-tachometer-alt text-dark me-2"></i>
                            Sistem Yönetim Paneli
                        </h1>
                        <div class="btn-toolbar mb-2 mb-md-0">
                            <div class="btn-group me-2">
                                <button type="button" class="btn btn-sm btn-outline-secondary">
                                    <i class="fas fa-download me-1"></i>Sistem Raporu
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- System Stats -->
                    <div class="row mb-4">
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Toplam Şirket
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="total-companies">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-building fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Aktif Abonelikler
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="active-subscriptions">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                Toplam Personel
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="total-employees">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Aylık Gelir
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="monthly-revenue">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card shadow">
                                <div class="card-header">
                                    <h6 class="m-0 font-weight-bold text-primary">Hızlı İşlemler</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-primary btn-block w-100" onclick="loadSection('add-company')">
                                                <i class="fas fa-building me-2"></i>Yeni Şirket
                                            </button>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-info btn-block w-100" onclick="loadSection('create-package')">
                                                <i class="fas fa-box me-2"></i>Yeni Paket
                                            </button>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-success btn-block w-100" onclick="loadSection('system-backup')">
                                                <i class="fas fa-database me-2"></i>Sistem Yedekle
                                            </button>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-warning btn-block w-100" onclick="loadSection('system-maintenance')">
                                                <i class="fas fa-tools me-2"></i>Bakım Modu
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activities and System Status -->
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card shadow mb-4">
                                <div class="card-header">
                                    <h6 class="m-0 font-weight-bold text-primary">Son Sistem Aktiviteleri</h6>
                                </div>
                                <div class="card-body">
                                    <div id="system-activities">
                                        <div class="text-center p-4">
                                            <i class="fas fa-spinner fa-spin fa-2x text-gray-300"></i>
                                            <p class="mt-2 text-muted">Aktiviteler yükleniyor...</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="card shadow mb-4">
                                <div class="card-header">
                                    <h6 class="m-0 font-weight-bold text-primary">Sistem Durumu</h6>
                                </div>
                                <div class="card-body">
                                    <div id="system-status">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="status-indicator bg-success me-3"></div>
                                            <div>
                                                <div class="fw-bold">Web Sunucusu</div>
                                                <small class="text-muted">Çalışıyor</small>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="status-indicator bg-success me-3"></div>
                                            <div>
                                                <div class="fw-bold">Veritabanı</div>
                                                <small class="text-muted">Aktif</small>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="status-indicator bg-success me-3"></div>
                                            <div>
                                                <div class="fw-bold">OAuth Sistemi</div>
                                                <small class="text-muted">Çalışıyor</small>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <div class="status-indicator bg-warning me-3"></div>
                                            <div>
                                                <div class="fw-bold">Son Yedekleme</div>
                                                <small class="text-muted">1 gün önce</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>
    
    <script>
        // System Dashboard specific variables
        const adminId = <?= $adminId ?>;
        const adminRole = '<?= $adminRole ?>';
        
        document.addEventListener('DOMContentLoaded', function() {
            loadDashboardData();
        });

        function loadDashboardData() {
            // Load system statistics
            loadSystemStats();
            loadSystemActivities();
        }

        function loadSystemStats() {
            // For demo purposes - in real implementation, these would be API calls
            setTimeout(() => {
                document.getElementById('total-companies').textContent = '25';
                document.getElementById('active-subscriptions').textContent = '18';
                document.getElementById('total-employees').textContent = '347';
                document.getElementById('monthly-revenue').textContent = '₺12,450';
            }, 500);
        }

        function loadSection(section) {
            const content = document.getElementById('main-content');
            
            // Update active nav item  
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
            });
            event.target.closest('.nav-link').classList.add('active');
            
            // Load section content
            switch(section) {
                case 'companies':
                    loadCompaniesSection();
                    break;
                case 'packages':
                    loadPackagesSection();
                    break;
                case 'subscriptions':
                    loadSubscriptionsSection();
                    break;
                case 'system-logs':
                    loadSystemLogsSection();
                    break;
                case 'analytics':
                    loadAnalyticsSection();
                    break;
                case 'settings':
                    loadSystemSettingsSection();
                    break;
                default:
                    showAlert('Bu bölüm henüz geliştiriliyor', 'info');
            }
        }

        function loadCompaniesSection() {
            const content = `
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-building text-primary me-2"></i>
                        Şirket Yönetimi
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary me-2">
                            <i class="fas fa-plus me-1"></i>Yeni Şirket
                        </button>
                        <button type="button" class="btn btn-outline-secondary">
                            <i class="fas fa-download me-1"></i>Excel İndir
                        </button>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Şirket ID</th>
                                        <th>Şirket Adı</th>
                                        <th>İletişim Email</th>
                                        <th>Paket</th>
                                        <th>Durum</th>
                                        <th>Kayıt Tarihi</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>SZB Teknoloji</td>
                                        <td>contact@szb.com.tr</td>
                                        <td><span class="badge bg-primary">Premium</span></td>
                                        <td><span class="badge bg-success">Aktif</span></td>
                                        <td>01.01.2024</td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary me-1">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-warning me-1">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger">
                                                <i class="fas fa-ban"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Demo Şirketi</td>
                                        <td>demo@demo.com.tr</td>
                                        <td><span class="badge bg-info">Standart</span></td>
                                        <td><span class="badge bg-success">Aktif</span></td>
                                        <td>15.01.2024</td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary me-1">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-warning me-1">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger">
                                                <i class="fas fa-ban"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
            document.getElementById('main-content').innerHTML = content;
        }

        function logout() {
            if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
                // Çıkış işlemi başladığını göster
                const navbarBrand = document.querySelector('.navbar-brand');
                if (navbarBrand) {
                    navbarBrand.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Çıkış yapılıyor...';
                }
                
                fetch('api/auth/logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'same-origin'
                })
                .then(response => response.json())
                .then(data => {
                    // Başarılı olsun olmasın ana sayfaya yönlendir
                    window.location.href = 'index.php';
                })
                .catch(() => {
                    // Hata durumunda ana sayfaya yönlendir
                    window.location.href = 'index.php';
                });
            }
        }
    </script>

    <style>
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        
        .btn-block {
            display: block;
            width: 100%;
        }
    </style>
</body>
</html>