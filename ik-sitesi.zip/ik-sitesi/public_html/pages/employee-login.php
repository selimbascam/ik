<?php
require_once __DIR__ . '/../includes/config.php';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Girişi - SZB İK Takip</title>
    <meta name="description" content="SZB İK Takip sistemi personel giriş sayfası.">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body class="bg-light">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-user-circle me-2"></i>
                SZB İK Takip - Personel
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="../">Ana Sayfa</a>
                <a class="nav-link" href="company-login.php">Şirket Girişi</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <!-- Header -->
                <div class="text-center mb-5">
                    <h1 class="display-6 fw-bold text-info">Personel Girişi</h1>
                    <p class="lead text-muted">Çalışan hesabınızla giriş yapın</p>
                </div>

                <!-- Login Form -->
                <div class="card shadow-lg">
                    <div class="card-body p-5">
                        <form id="employeeLoginForm">
                            <div class="mb-4 text-center">
                                <i class="fas fa-user-circle fa-4x text-info mb-3"></i>
                                <h4>Personel Girişi</h4>
                            </div>

                            <div class="mb-3">
                                <label for="employee_code" class="form-label">Personel Kodu</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-id-badge"></i>
                                    </span>
                                    <input type="text" class="form-control" id="employee_code" name="employee_code" 
                                           placeholder="Örn: SZB001">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Email Adresi</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-envelope"></i>
                                    </span>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           placeholder="ornek@email.com">
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label">Şifre</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control" id="password" name="password" 
                                           placeholder="••••••••">
                                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="d-grid mb-4">
                                <button type="submit" class="btn btn-info btn-lg" id="loginBtn">
                                    <i class="fas fa-sign-in-alt me-2"></i>
                                    Giriş Yap
                                </button>
                            </div>
                        </form>

                        <!-- OAuth Login Options -->
                        <div class="text-center">
                            <div class="mb-3">
                                <small class="text-muted">veya</small>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="button" class="btn btn-outline-danger" onclick="signInWithGoogle('employee')">
                                    <i class="fab fa-google me-2"></i>
                                    Google ile Giriş Yap
                                </button>
                                
                                <button type="button" class="btn btn-outline-dark" onclick="signInWithApple('employee')">
                                    <i class="fab fa-apple me-2"></i>
                                    Apple ile Giriş Yap
                                </button>
                            </div>
                        </div>

                        <div class="text-center mt-4">
                            <div class="mb-3">
                                <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#helpModal">
                                    Giriş konusunda yardım mı gerekiyor?
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Demo Account Info -->
                <div class="card mt-4">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            Demo Personel Hesapları
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="text-center">
                            <p class="mb-2"><strong>Personel Kodu:</strong> SZB001</p>
                            <p class="mb-2"><strong>Email:</strong> personel@szb.com.tr</p>
                            <p class="mb-1"><strong>Şifre:</strong> demo123</p>
                            <button class="btn btn-sm btn-outline-info mt-2" onclick="fillDemoCredentials()">
                                Demo Bilgilerini Doldur
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Help Modal -->
    <div class="modal fade" id="helpModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Giriş Yardımı</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <h6>Giriş Bilgilerinizi Unuttuysanız:</h6>
                    <ul>
                        <li>Personel kodunuz için şirket yöneticinize başvurun</li>
                        <li>Şifrenizi sıfırlamak için İK departmanıyla iletişime geçin</li>
                        <li>OAuth (Google/Apple) ile giriş yapmayı deneyebilirsiniz</li>
                    </ul>
                    
                    <h6>OAuth ile Giriş:</h6>
                    <p>Eğer email adresiniz sistemde kayıtlıysa, Google veya Apple hesabınızla doğrudan giriş yapabilirsiniz.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>
    <script src="../assets/js/oauth.js"></script>
    
    <!-- OAuth Configuration -->
    <script>
        window.GOOGLE_CLIENT_ID = '<?= $_ENV['GOOGLE_CLIENT_ID'] ?? '' ?>';
        window.APPLE_CLIENT_ID = '<?= $_ENV['APPLE_CLIENT_ID'] ?? '' ?>';
    </script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('employeeLoginForm');
            const loginBtn = document.getElementById('loginBtn');
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');

            // Password visibility toggle
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                const icon = this.querySelector('i');
                icon.classList.toggle('fa-eye');
                icon.classList.toggle('fa-eye-slash');
            });

            // Employee login form submission
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(loginForm);
                const data = Object.fromEntries(formData);
                
                loginBtn.disabled = true;
                loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Giriş yapılıyor...';
                
                fetch('/api/auth/employee-login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        showAlert('Giriş başarılı! Yönlendiriliyorsunuz...', 'success');
                        setTimeout(() => {
                            window.location.href = result.redirect || '/self-service';
                        }, 1500);
                    } else {
                        showAlert(result.error || 'Giriş başarısız', 'danger');
                    }
                })
                .catch(error => {
                    console.error('Employee login error:', error);
                    showAlert('Giriş sırasında bir hata oluştu', 'danger');
                })
                .finally(() => {
                    loginBtn.disabled = false;
                    loginBtn.innerHTML = '<i class="fas fa-sign-in-alt me-2"></i>Giriş Yap';
                });
            });

            // Global logout function for employee dashboard
            window.logout = function() {
                if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
                    fetch('/api/auth/logout', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Ana sayfaya yönlendir
                            window.location.href = '/';
                        } else {
                            // Hata durumunda da ana sayfaya yönlendir
                            window.location.href = '/';
                        }
                    })
                    .catch(() => {
                        // Hata durumunda ana sayfaya yönlendir
                        window.location.href = '/';
                    });
                }
            };
        });

        // Fill demo credentials
        function fillDemoCredentials() {
            document.getElementById('employee_code').value = 'SZB001';
            document.getElementById('email').value = 'personel@szb.com.tr';
            document.getElementById('password').value = 'demo123';
            
            // Highlight the form briefly
            const form = document.getElementById('employeeLoginForm');
            form.classList.add('border', 'border-info');
            setTimeout(() => {
                form.classList.remove('border', 'border-info');
            }, 2000);
        }
    </script>
</body>
</html>