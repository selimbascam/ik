<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth.php';

// Check if user is logged in as company admin
if (!isset($_SESSION['admin_id']) || $_SESSION['user_type'] !== 'company') {
    header('Location: company-login.php');
    exit();
}

$companyId = $_SESSION['company_id'];
$companyName = $_SESSION['company_name'];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İcra Takip - <?= htmlspecialchars($companyName) ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="company-dashboard.php">
                <i class="fas fa-gavel me-2"></i>
                İcra Takip Modülü - <?= htmlspecialchars($companyName) ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="company-dashboard.php">
                            <i class="fas fa-arrow-left me-1"></i>Dashboard'a Dön
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-tie me-1"></i>
                            <?= htmlspecialchars($_SESSION['admin_email']) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil</a></li>
                            <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2"></i>Ayarlar</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <!-- Alert Container -->
        <div id="alert-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1050;"></div>

        <!-- İcra Takip Stats -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4 class="mb-0" id="active-cases">-</h4>
                                <p class="mb-0">Aktif İcra Dosyası</p>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-gavel fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-dark">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4 class="mb-0" id="total-debt">-</h4>
                                <p class="mb-0">Toplam Borç</p>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-money-bill-wave fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4 class="mb-0" id="monthly-deduction">-</h4>
                                <p class="mb-0">Aylık Kesinti</p>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-cut fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h4 class="mb-0" id="employees-with-garnishment">-</h4>
                                <p class="mb-0">Hacizli Personel</p>
                            </div>
                            <div class="align-self-center">
                                <i class="fas fa-users fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-cogs me-2"></i>İşlemler
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <button class="btn btn-primary w-100" onclick="showAddGarnishmentModal()">
                                    <i class="fas fa-plus me-2"></i>
                                    Yeni İcra Dosyası
                                </button>
                            </div>
                            <div class="col-md-3 mb-3">
                                <button class="btn btn-success w-100" onclick="calculateDeductions()">
                                    <i class="fas fa-calculator me-2"></i>
                                    Kesinti Hesapla
                                </button>
                            </div>
                            <div class="col-md-3 mb-3">
                                <button class="btn btn-info w-100" onclick="generateReport()">
                                    <i class="fas fa-file-excel me-2"></i>
                                    Rapor Oluştur
                                </button>
                            </div>
                            <div class="col-md-3 mb-3">
                                <button class="btn btn-warning w-100" onclick="showLegalLimitsModal()">
                                    <i class="fas fa-info-circle me-2"></i>
                                    Yasal Limitler
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Garnishments Table -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>İcra Dosyaları
                        </h5>
                        <div class="input-group" style="width: 300px;">
                            <input type="search" class="form-control" placeholder="Personel ara..." id="searchInput">
                            <button class="btn btn-outline-secondary" type="button">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="garnishments-table">
                                <thead>
                                    <tr>
                                        <th>Personel</th>
                                        <th>İcra Müdürlüğü</th>
                                        <th>Dosya No</th>
                                        <th>Borç Miktarı</th>
                                        <th>Kalan Borç</th>
                                        <th>Maaş</th>
                                        <th>Kesinti Miktarı</th>
                                        <th>Kesinti %</th>
                                        <th>Durum</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Dynamic content will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Garnishment Modal -->
    <div class="modal fade" id="addGarnishmentModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus-circle me-2"></i>Yeni İcra Dosyası Ekle
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="addGarnishmentForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Personel Seçin</label>
                                    <select class="form-select" name="employee_id" required onchange="calculateDeductionPreview()">
                                        <option value="">Personel seçin...</option>
                                        <!-- Will be populated dynamically -->
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">İcra Müdürlüğü</label>
                                    <input type="text" class="form-control" name="court_name" required 
                                           placeholder="Örn: İstanbul 1. İcra Müdürlüğü">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">İcra Dosya No</label>
                                    <input type="text" class="form-control" name="case_number" required 
                                           placeholder="Örn: 2024/1234">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Borç Miktarı (₺)</label>
                                    <input type="number" class="form-control" name="debt_amount" step="0.01" required 
                                           placeholder="0.00">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Başlangıç Tarihi</label>
                                    <input type="date" class="form-control" name="start_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Kesinti Oranı (%)</label>
                                    <select class="form-select" name="deduction_rate" required onchange="calculateDeductionPreview()">
                                        <option value="">Oran seçin...</option>
                                        <option value="5">%5</option>
                                        <option value="10">%10</option>
                                        <option value="15">%15</option>
                                        <option value="20">%20</option>
                                        <option value="25">%25 (Maksimum)</option>
                                    </select>
                                    <div id="deduction-preview" class="mt-2 small text-muted"></div>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Açıklama</label>
                            <textarea class="form-control" name="description" rows="3" 
                                      placeholder="İcra dosyası hakkında ek bilgiler..."></textarea>
                        </div>
                        
                        <!-- Yasal Uyarı -->
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Yasal Bilgilendirme:</strong> İİK 83. madde gereği, maaşın en fazla 1/4'ü (net maaşın %25'i) haczedilebilir. 
                            Asgari ücretin 2/3'ü haczedilemez.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Legal Limits Modal -->
    <div class="modal fade" id="legalLimitsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-balance-scale me-2"></i>Yasal Limitler ve Kurallar
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <h6 class="text-primary">İcra ve İflas Kanunu (İİK) 83. Madde</h6>
                            <ul class="list-group list-group-flush mb-4">
                                <li class="list-group-item">
                                    <i class="fas fa-check-circle text-success me-2"></i>
                                    Maaşın en fazla <strong>1/4'ü (%25)</strong> haczedilebilir
                                </li>
                                <li class="list-group-item">
                                    <i class="fas fa-shield-alt text-warning me-2"></i>
                                    Asgari ücretin <strong>2/3'ü haczedilemez</strong>
                                </li>
                                <li class="list-group-item">
                                    <i class="fas fa-calculator text-info me-2"></i>
                                    Net maaş üzerinden hesaplama yapılır
                                </li>
                                <li class="list-group-item">
                                    <i class="fas fa-clock text-primary me-2"></i>
                                    Kesinti işlemi aylık olarak yapılır
                                </li>
                            </ul>

                            <h6 class="text-primary">Hesaplama Örneği</h6>
                            <div class="card bg-light">
                                <div class="card-body">
                                    <p><strong>Net Maaş:</strong> 10.000 ₺</p>
                                    <p><strong>Maksimum Kesinti:</strong> 10.000 × 0.25 = 2.500 ₺</p>
                                    <p><strong>Asgari Ücret Koruması:</strong> <?= date('Y') ?> yılı asgari ücretin 2/3'ü</p>
                                    <hr>
                                    <p class="mb-0 text-success">
                                        <i class="fas fa-info-circle me-2"></i>
                                        Sistem otomatik olarak yasal limitleri kontrol eder ve aşılmasına izin vermez.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Anladım</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- App JS -->
    <script src="../assets/js/app.js"></script>

    <script>
        // Initialize page
        document.addEventListener('DOMContentLoaded', function() {
            loadGarnishments();
            loadEmployeesForSelect();
            loadStats();
        });

        // Load garnishments
        function loadGarnishments() {
            const tableBody = document.querySelector('#garnishments-table tbody');
            tableBody.innerHTML = '<tr><td colspan="10" class="text-center"><i class="fas fa-spinner fa-spin"></i> Yükleniyor...</td></tr>';
            
            fetch('/api/icra/demo.php?action=list')
                .then(response => response.json())
                .then(result => {
                    if (!result.success) {
                        throw new Error(result.error || 'Veri yüklenemedi');
                    }
                    
                    const garnishments = result.data;
                    
                    if (garnishments.length === 0) {
                        tableBody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">Henüz icra dosyası bulunmuyor</td></tr>';
                        return;
                    }
                    
                    tableBody.innerHTML = garnishments.map(garnishment => `
                        <tr>
                            <td><strong>${garnishment.employee_name}</strong></td>
                            <td>${garnishment.court_name}</td>
                            <td><span class="badge bg-primary">${garnishment.case_number}</span></td>
                            <td><strong>${parseFloat(garnishment.debt_amount).toLocaleString('tr-TR')} ₺</strong></td>
                            <td><strong class="text-danger">${parseFloat(garnishment.remaining_debt).toLocaleString('tr-TR')} ₺</strong></td>
                            <td>${parseFloat(garnishment.current_salary).toLocaleString('tr-TR')} ₺</td>
                            <td><strong class="text-warning">${parseFloat(garnishment.monthly_deduction).toLocaleString('tr-TR')} ₺</strong></td>
                            <td>
                                <span class="badge ${garnishment.deduction_rate >= 25 ? 'bg-danger' : garnishment.deduction_rate >= 15 ? 'bg-warning' : 'bg-success'}">
                                    %${garnishment.deduction_rate}
                                </span>
                            </td>
                            <td>
                                <span class="badge ${garnishment.status === 'active' ? 'bg-success' : 'bg-secondary'}">
                                    ${garnishment.status === 'active' ? 'Aktif' : 'Pasif'}
                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <button class="btn btn-sm btn-outline-primary" onclick="editGarnishment(${garnishment.id})" title="Düzenle">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info" onclick="viewPayments(${garnishment.id})" title="Ödemeleri Görüntüle">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger" onclick="closeGarnishment(${garnishment.id})" title="Dosyayı Kapat">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `).join('');
                })
                .catch(error => {
                    console.error('Garnishments loading error:', error);
                    tableBody.innerHTML = '<tr><td colspan="10" class="text-center text-danger">İcra dosyaları yüklenemedi: ' + error.message + '</td></tr>';
                });
        }

        // Load stats
        function loadStats() {
            fetch('/api/icra/demo.php?action=stats')
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        const stats = result.data;
                        document.getElementById('active-cases').textContent = stats.active_cases;
                        document.getElementById('total-debt').textContent = parseFloat(stats.total_debt).toLocaleString('tr-TR') + ' ₺';
                        document.getElementById('monthly-deduction').textContent = parseFloat(stats.monthly_deduction).toLocaleString('tr-TR') + ' ₺';
                        document.getElementById('employees-with-garnishment').textContent = stats.employees_with_garnishment;
                    }
                })
                .catch(error => {
                    console.error('Stats loading error:', error);
                    // Set error indicators
                    document.getElementById('active-cases').textContent = '!';
                    document.getElementById('total-debt').textContent = 'Hata';
                    document.getElementById('monthly-deduction').textContent = 'Hata';
                    document.getElementById('employees-with-garnishment').textContent = '!';
                });
        }

        // Load employees for select
        function loadEmployeesForSelect() {
            const select = document.querySelector('select[name="employee_id"]');
            
            fetch('/api/icra/demo.php?action=employees')
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        const employees = result.data;
                        select.innerHTML = '<option value="">Personel seçin...</option>' + 
                            employees.map(emp => `<option value="${emp.id}" data-salary="${emp.salary}">${emp.first_name} ${emp.last_name} (${parseFloat(emp.salary).toLocaleString('tr-TR')} ₺)</option>`).join('');
                    }
                })
                .catch(error => {
                    console.error('Employees loading error:', error);
                    select.innerHTML = '<option value="">Personel yüklenemedi</option>';
                });
        }

        // Show modals
        function showAddGarnishmentModal() {
            new bootstrap.Modal(document.getElementById('addGarnishmentModal')).show();
        }

        function showLegalLimitsModal() {
            new bootstrap.Modal(document.getElementById('legalLimitsModal')).show();
        }

        // Form submission
        document.getElementById('addGarnishmentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);
            
            // Validate deduction rate
            if (parseFloat(data.deduction_rate) > 25) {
                showAlert('Kesinti oranı %25\'i geçemez!', 'danger');
                return;
            }
            
            // Get selected employee salary for calculation
            const selectedOption = document.querySelector(`select[name="employee_id"] option[value="${data.employee_id}"]`);
            const salary = selectedOption ? parseFloat(selectedOption.dataset.salary) : 0;
            
            if (salary > 0) {
                const calculatedDeduction = salary * (parseFloat(data.deduction_rate) / 100);
                const maxLegalDeduction = salary * 0.25;
                
                if (calculatedDeduction > maxLegalDeduction) {
                    showAlert(`Yasal limit aşımı! Bu maaş için maksimum kesinti: ${maxLegalDeduction.toLocaleString('tr-TR')} ₺`, 'warning');
                }
            }
            
            showAlert('İcra dosyası kaydediliyor...', 'info');
            
            fetch('/api/icra/demo.php?action=create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showAlert('İcra dosyası başarıyla kaydedildi!', 'success');
                    bootstrap.Modal.getInstance(document.getElementById('addGarnishmentModal')).hide();
                    this.reset();
                    loadGarnishments();
                    loadStats();
                } else {
                    showAlert('Hata: ' + (result.error || 'Bilinmeyen hata'), 'danger');
                }
            })
            .catch(error => {
                console.error('Form submission error:', error);
                showAlert('Kaydetme sırasında hata oluştu', 'danger');
            });
        });

        // Action functions
        function calculateDeductions() {
            showAlert('Kesintiler hesaplanıyor...', 'info');
            setTimeout(() => {
                showAlert('Tüm kesintiler yasal limitler çerçevesinde hesaplandı!', 'success');
            }, 2000);
        }

        function generateReport() {
            showAlert('İcra takip raporu oluşturuluyor...', 'info');
            setTimeout(() => {
                showAlert('Rapor başarıyla oluşturuldu! İndiriliyor...', 'success');
            }, 2000);
        }

        function editGarnishment(id) {
            showAlert('Düzenleme özelliği geliştirme aşamasında...', 'info');
        }

        function viewPayments(id) {
            showAlert('Ödeme geçmişi görüntüleme özelliği geliştirme aşamasında...', 'info');
        }

        function closeGarnishment(id) {
            if (confirm('Bu icra dosyasını kapatmak istediğinizden emin misiniz?')) {
                showAlert('İcra dosyası kapatılıyor...', 'info');
                setTimeout(() => {
                    showAlert('İcra dosyası başarıyla kapatıldı!', 'success');
                    loadGarnishments();
                    loadStats();
                }, 1500);
            }
        }

        // Calculate deduction preview
        function calculateDeductionPreview() {
            const employeeSelect = document.querySelector('select[name="employee_id"]');
            const rateSelect = document.querySelector('select[name="deduction_rate"]');
            const previewDiv = document.getElementById('deduction-preview');
            
            if (!employeeSelect.value || !rateSelect.value) {
                previewDiv.innerHTML = '';
                return;
            }
            
            const selectedOption = employeeSelect.options[employeeSelect.selectedIndex];
            const salary = parseFloat(selectedOption.dataset.salary || 0);
            const rate = parseFloat(rateSelect.value);
            
            if (salary > 0 && rate > 0) {
                const calculatedDeduction = salary * (rate / 100);
                const maxLegalDeduction = salary * 0.25;
                const isLegal = calculatedDeduction <= maxLegalDeduction;
                
                const minWage = 17002.12; // 2024 asgari ücreti
                const protectedAmount = minWage * (2/3);
                const afterDeduction = salary - calculatedDeduction;
                const isProtectedAmountSafe = afterDeduction >= protectedAmount;
                
                let previewHTML = `
                    <div class="card bg-light border-0">
                        <div class="card-body py-2">
                            <strong>Kesinti Hesaplama Önizlemesi:</strong><br>
                            <span class="text-primary">Maaş: ${salary.toLocaleString('tr-TR')} ₺</span><br>
                            <span class="${isLegal ? 'text-success' : 'text-danger'}">
                                Hesaplanan Kesinti: ${calculatedDeduction.toLocaleString('tr-TR')} ₺ (%${rate})
                            </span><br>
                            <span class="text-info">Kalan Maaş: ${afterDeduction.toLocaleString('tr-TR')} ₺</span>
                `;
                
                if (!isLegal) {
                    previewHTML += `<br><span class="text-danger"><i class="fas fa-exclamation-triangle"></i> Yasal limit aşımı! Maksimum: ${maxLegalDeduction.toLocaleString('tr-TR')} ₺</span>`;
                }
                
                if (!isProtectedAmountSafe) {
                    previewHTML += `<br><span class="text-warning"><i class="fas fa-shield-alt"></i> Korunan miktar altında! Minimum: ${protectedAmount.toLocaleString('tr-TR')} ₺</span>`;
                }
                
                previewHTML += `
                        </div>
                    </div>
                `;
                
                previewDiv.innerHTML = previewHTML;
            }
        }

        // Logout function
        function logout() {
            if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
                // Show loading message
                showAlert('Çıkış yapılıyor...', 'info');
                
                fetch('../api/auth/logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'same-origin'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showAlert('Başarıyla çıkış yapıldı!', 'success');
                        // Wait a moment then redirect
                        setTimeout(() => {
                            window.location.href = '../index.php';
                        }, 1000);
                    } else {
                        throw new Error(data.error || 'Çıkış işlemi başarısız');
                    }
                })
                .catch(error => {
                    console.error('Logout error:', error);
                    showAlert('Çıkış işlemi başarısız: ' + error.message, 'danger');
                    // Force redirect anyway after error
                    setTimeout(() => {
                        window.location.href = '../index.php';
                    }, 2000);
                });
            }
        }
    </script>
</body>
</html>