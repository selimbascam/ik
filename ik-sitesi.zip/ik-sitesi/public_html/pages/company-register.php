<?php
header("Location: ../admin/company-setup.php");
exit;
?>