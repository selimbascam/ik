<?php
require_once '../includes/config.php';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Admin Girişi - SZB İK Takip</title>
    <meta name="description" content="Sistem yöneticisi olarak admin paneline giriş yapın.">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body class="bg-dark">
    <nav class="navbar navbar-expand-lg navbar-dark bg-warning">
        <div class="container">
            <a class="navbar-brand text-dark" href="../">
                <i class="fas fa-user-shield me-2"></i>SZB İK Admin
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center min-vh-100 align-items-center">
            <div class="col-lg-5 col-md-7">
                <div class="card shadow">
                    <div class="card-header bg-warning text-dark text-center">
                        <h4><i class="fas fa-user-shield me-2"></i>Sistem Admin</h4>
                        <p class="mb-0">Yönetim paneline erişim</p>
                    </div>
                    <div class="card-body p-4">
                        <div class="alert alert-warning" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Güvenlik Uyarısı:</strong> Bu alan sadece sistem yöneticileri içindir.
                        </div>
                        
                        <form id="admin-login-form">
                            <div class="mb-3">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope me-1"></i>Admin Email
                                </label>
                                <input type="email" class="form-control" id="email" name="email" required autocomplete="email">
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock me-1"></i>Admin Şifre
                                </label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password">
                                    <button class="btn btn-outline-secondary" type="button" id="toggle-password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-warning btn-lg text-dark">
                                    <i class="fas fa-sign-in-alt me-2"></i>Admin Girişi
                                </button>
                            </div>
                        </form>
                        
                        <hr class="my-4">
                        
                        <div class="text-center">
                            <p class="text-muted mb-2"><strong>Demo Admin:</strong></p>
                            <small class="text-muted">
                                Email: admin@system.com<br>
                                Şifre: admin123
                            </small>
                        </div>
                    </div>
                </div>
                
                <!-- Login Type Selector -->
                <div class="card mt-3">
                    <div class="card-body text-center">
                        <p class="mb-2"><strong>Diğer Giriş Türleri:</strong></p>
                        <div class="btn-group w-100" role="group">
                            <a href="../pages/company-login.php" class="btn btn-outline-primary">
                                <i class="fas fa-building me-1"></i>Firma Girişi
                            </a>
                            <a href="../pages/employee-login.php" class="btn btn-outline-info">
                                <i class="fas fa-user me-1"></i>Personel Girişi
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Alert Container -->
    <div id="alert-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1050;"></div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>
    
    <script>
        // Password toggle
        document.getElementById('toggle-password').addEventListener('click', function() {
            const passwordField = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                passwordField.type = 'password';
                icon.className = 'fas fa-eye';
            }
        });

        // Login form
        document.getElementById('admin-login-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            data.login_type = 'admin'; // Admin girişi
            
            // Show loading
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Giriş yapılıyor...';
            submitBtn.disabled = true;
            
            // Submit login
            fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    showAlert(result.message, 'success');
                    setTimeout(() => {
                        window.location.href = result.redirect || '/admin-dashboard';
                    }, 1000);
                } else {
                    showAlert(result.error || 'Admin girişi başarısız', 'danger');
                }
            })
            .catch(error => {
                console.error('Admin login error:', error);
                showAlert('Sistem hatası: ' + error.message, 'danger');
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            });
        });
    </script>
</body>
</html>