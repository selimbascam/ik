<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../api/common/auth.php';

// Check company admin authentication
session_start();
if (!isset($_SESSION['admin_id']) || $_SESSION['login_type'] !== 'company') {
    header('Location: company-login.php');
    exit;
}

$companyId = $_SESSION['company_id'];
$adminId = $_SESSION['admin_id'];
$companyName = $_SESSION['company_name'] ?? 'Şirket';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Yönetimi - <?= htmlspecialchars($companyName) ?></title>
    <meta name="description" content="<?= htmlspecialchars($companyName) ?> şirket yönetim paneli.">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="fas fa-building me-2"></i>
                <?= htmlspecialchars($companyName) ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-tie me-1"></i>
                            <?= htmlspecialchars($_SESSION['admin_email']) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#"><i class="fas fa-user me-2"></i>Profil</a></li>
                            <li><a class="dropdown-item" href="#"><i class="fas fa-cog me-2"></i>Ayarlar</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" onclick="logout()"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                <i class="fas fa-tachometer-alt me-2"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('employees')">
                                <i class="fas fa-users me-2"></i>
                                Personel Yönetimi
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('attendance')">
                                <i class="fas fa-clock me-2"></i>
                                Devam Takibi
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('qr-locations')">
                                <i class="fas fa-qrcode me-2"></i>
                                QR Lokasyonları
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('leave-management')">
                                <i class="fas fa-calendar-alt me-2"></i>
                                İzin Yönetimi
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('shifts')">
                                <i class="fas fa-business-time me-2"></i>
                                Vardiya Yönetimi
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('reports')">
                                <i class="fas fa-chart-bar me-2"></i>
                                Raporlar
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="icra-takip.php">
                                <i class="fas fa-gavel me-2"></i>
                                İcra Takip
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" onclick="loadSection('settings')">
                                <i class="fas fa-cog me-2"></i>
                                Şirket Ayarları
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div id="main-content">
                    <!-- Dashboard Content -->
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2">
                            <i class="fas fa-tachometer-alt text-primary me-2"></i>
                            Şirket Yönetim Paneli
                        </h1>
                        <div class="btn-toolbar mb-2 mb-md-0">
                            <div class="btn-group me-2">
                                <button type="button" class="btn btn-sm btn-outline-secondary">
                                    <i class="fas fa-download me-1"></i>Rapor İndir
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Dashboard Stats -->
                    <div class="row mb-4">
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Aktif Personel
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="active-employees">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Bugün Gelen
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="present-today">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-check fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                QR Lokasyonları
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="qr-locations-count">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-qrcode fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Bekleyen İzinler
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="pending-leaves">-</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card shadow">
                                <div class="card-header">
                                    <h6 class="m-0 font-weight-bold text-primary">Hızlı İşlemler</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-primary btn-block w-100" onclick="loadSection('add-employee')">
                                                <i class="fas fa-user-plus me-2"></i>Personel Ekle
                                            </button>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-info btn-block w-100" onclick="loadSection('add-qr-location')">
                                                <i class="fas fa-qrcode me-2"></i>QR Lokasyon Ekle
                                            </button>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-success btn-block w-100" onclick="loadSection('attendance-report')">
                                                <i class="fas fa-chart-line me-2"></i>Devam Raporu
                                            </button>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <button class="btn btn-warning btn-block w-100" onclick="loadSection('backup')">
                                                <i class="fas fa-download me-2"></i>Veri Yedekle
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activities -->
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card shadow mb-4">
                                <div class="card-header">
                                    <h6 class="m-0 font-weight-bold text-primary">Son Aktiviteler</h6>
                                </div>
                                <div class="card-body">
                                    <div id="recent-activities">
                                        <div class="text-center p-4">
                                            <i class="fas fa-spinner fa-spin fa-2x text-gray-300"></i>
                                            <p class="mt-2 text-muted">Aktiviteler yükleniyor...</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="card shadow mb-4">
                                <div class="card-header">
                                    <h6 class="m-0 font-weight-bold text-primary">Sistem Durumu</h6>
                                </div>
                                <div class="card-body">
                                    <div id="system-status">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="status-indicator bg-success me-3"></div>
                                            <div>
                                                <div class="fw-bold">QR Sistemi</div>
                                                <small class="text-muted">Çalışıyor</small>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="status-indicator bg-success me-3"></div>
                                            <div>
                                                <div class="fw-bold">Veritabanı</div>
                                                <small class="text-muted">Aktif</small>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center">
                                            <div class="status-indicator bg-warning me-3"></div>
                                            <div>
                                                <div class="fw-bold">Son Yedekleme</div>
                                                <small class="text-muted">2 gün önce</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>
    
    <script>
        // Company Dashboard specific variables
        const companyId = <?= $companyId ?>;
        const adminId = <?= $adminId ?>;
        
        document.addEventListener('DOMContentLoaded', function() {
            loadDashboardData();
        });

        function loadDashboardData() {
            // Load dashboard statistics
            loadCompanyStats();
            loadRecentActivities();
        }

        function loadCompanyStats() {
            // For demo purposes - in real implementation, these would be API calls
            setTimeout(() => {
                document.getElementById('active-employees').textContent = '15';
                document.getElementById('present-today').textContent = '12';
                document.getElementById('qr-locations-count').textContent = '5';
                document.getElementById('pending-leaves').textContent = '3';
            }, 500);
        }

        function loadSection(section) {
            const content = document.getElementById('main-content');
            
            // Update active nav item
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
            });
            event.target.closest('.nav-link').classList.add('active');
            
            // Load section content
            switch(section) {
                case 'employees':
                    loadEmployeesSection();
                    break;
                case 'attendance':
                    loadAttendanceSection();
                    break;
                case 'qr-locations':
                    loadQRLocationsSection();
                    break;
                case 'leave-management':
                    loadLeaveManagementSection();
                    break;
                case 'shifts':
                    loadShiftsSection();
                    break;
                case 'reports':
                    loadReportsSection();
                    break;
                case 'settings':
                    loadSettingsSection();
                    break;
                default:
                    showAlert('Bu bölüm henüz geliştiriliyor', 'info');
            }
        }

        function loadEmployeesSection() {
            const content = `
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-users text-primary me-2"></i>
                        Personel Yönetimi
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary me-2">
                            <i class="fas fa-user-plus me-1"></i>Yeni Personel
                        </button>
                        <button type="button" class="btn btn-outline-secondary">
                            <i class="fas fa-download me-1"></i>Excel İndir
                        </button>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Personel Kodu</th>
                                        <th>Ad Soyad</th>
                                        <th>Departman</th>
                                        <th>Pozisyon</th>
                                        <th>İşe Başlama</th>
                                        <th>Durum</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>SZB001</td>
                                        <td>Demo Personel 1</td>
                                        <td>İnsan Kaynakları</td>
                                        <td>Yazılım Geliştirici</td>
                                        <td>01.01.2024</td>
                                        <td><span class="badge bg-success">Aktif</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary me-1">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
            document.getElementById('main-content').innerHTML = content;
        }

        function loadQRLocationsSection() {
            const content = `
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-qrcode text-primary me-2"></i>
                        QR Lokasyonları
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i>Yeni Lokasyon
                        </button>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <i class="fas fa-sign-in-alt fa-3x text-primary mb-3"></i>
                                <h5>Ana Giriş Kapısı</h5>
                                <p class="text-muted">SZB001GIRIS</p>
                                <div class="d-flex justify-content-center gap-2">
                                    <button class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-qrcode me-1"></i>QR Kodu Göster
                                    </button>
                                    <button class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-edit me-1"></i>Düzenle
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <i class="fas fa-sign-out-alt fa-3x text-danger mb-3"></i>
                                <h5>Ana Çıkış Kapısı</h5>
                                <p class="text-muted">SZB002CIKIS</p>
                                <div class="d-flex justify-content-center gap-2">
                                    <button class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-qrcode me-1"></i>QR Kodu Göster
                                    </button>
                                    <button class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-edit me-1"></i>Düzenle
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            document.getElementById('main-content').innerHTML = content;
        }

        function logout() {
            if (confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
                fetch('api/auth/logout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'same-origin'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Ana sayfaya yönlendir
                        window.location.href = 'index.php';
                    } else {
                        console.error('Logout error:', data.error);
                        // Hata durumunda da ana sayfaya yönlendir
                        window.location.href = 'index.php';
                    }
                })
                .catch((error) => {
                    console.error('Logout request failed:', error);
                    // Hata durumunda ana sayfaya yönlendir
                    window.location.href = 'index.php';
                });
            }
        }
    </script>

    <style>
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        
        .btn-block {
            display: block;
            width: 100%;
        }
    </style>
</body>
</html>