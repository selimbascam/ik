<?php
require_once __DIR__ . '/../includes/config.php';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Girişi - SZB İK Takip Sistemi</title>
    <meta name="description" content="SZB İK Takip sistemi şirket yöneticisi giriş sayfası.">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body class="bg-light">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-building me-2"></i>
                SZB İK Takip
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="../">Ana Sayfa</a>
                <a class="nav-link" href="company-register.php">Kayıt Ol</a>
                <a class="nav-link" href="system-login.php">Sistem Yöneticisi</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <!-- Header -->
                <div class="text-center mb-5">
                    <h1 class="display-6 fw-bold text-primary">Şirket Girişi</h1>
                    <p class="lead text-muted">Şirket yöneticisi hesabınızla giriş yapın</p>
                </div>

                <!-- Login Form -->
                <div class="card shadow-lg">
                    <div class="card-body p-5">
                        <form id="companyLoginForm">
                            <div class="mb-4 text-center">
                                <i class="fas fa-user-tie fa-4x text-primary mb-3"></i>
                                <h4>Yönetici Girişi</h4>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Email Adresi</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-envelope"></i>
                                    </span>
                                    <input type="email" class="form-control" id="email" name="email" required 
                                           placeholder="ornek@sirket.com">
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label">Şifre</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control" id="password" name="password" required 
                                           placeholder="••••••••">
                                    <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="remember_me" name="remember_me">
                                    <label class="form-check-label" for="remember_me">
                                        Beni hatırla
                                    </label>
                                </div>
                            </div>

                            <div class="d-grid mb-4">
                                <button type="submit" class="btn btn-primary btn-lg" id="loginBtn">
                                    <i class="fas fa-sign-in-alt me-2"></i>
                                    Giriş Yap
                                </button>
                            </div>
                        </form>

                        <!-- OAuth Login Options -->
                        <div class="text-center">
                            <div class="mb-3">
                                <small class="text-muted">veya</small>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="button" class="btn btn-outline-danger" onclick="signInWithGoogle('company_admin')">
                                    <i class="fab fa-google me-2"></i>
                                    Google ile Giriş Yap
                                </button>
                                
                                <button type="button" class="btn btn-outline-dark" onclick="signInWithApple('company_admin')">
                                    <i class="fab fa-apple me-2"></i>
                                    Apple ile Giriş Yap
                                </button>
                            </div>
                        </div>

                        <div class="text-center">
                            <div class="mb-3">
                                <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#forgotPasswordModal">
                                    Şifrenizi mi unuttunuz?
                                </a>
                            </div>
                            <hr>
                            <div class="mt-3">
                                <p class="mb-2">Hesabınız yok mu?</p>
                                <a href="company-register.php" class="btn btn-outline-primary">
                                    <i class="fas fa-plus me-2"></i>
                                    Yeni Şirket Kaydet
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Demo Accounts Info -->
                <div class="card mt-4">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            Demo Hesapları
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="text-primary">SZB Teknoloji A.Ş.</h6>
                                <p class="small mb-1"><strong>Email:</strong> ahmet@szb.com.tr</p>
                                <p class="small mb-1"><strong>Şifre:</strong> demo123</p>
                                <p class="small mb-0">Şirket Sahibi (Tüm yetkiler)</p>
                            </div>
                            <div class="col-md-6">
                                <h6 class="text-primary">Demo Şirketi Ltd.</h6>
                                <p class="small mb-1"><strong>Email:</strong> ayse@demo.com.tr</p>
                                <p class="small mb-1"><strong>Şifre:</strong> demo123</p>
                                <p class="small mb-0">Şirket Sahibi</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Forgot Password Modal -->
    <div class="modal fade" id="forgotPasswordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Şifre Sıfırlama</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="forgotPasswordForm">
                        <div class="mb-3">
                            <label for="reset_email" class="form-label">Email Adresi</label>
                            <input type="email" class="form-control" id="reset_email" required 
                                   placeholder="Kayıtlı email adresinizi girin">
                        </div>
                        <div class="text-muted small">
                            Şifre sıfırlama bağlantısı email adresinize gönderilecektir.
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" form="forgotPasswordForm" class="btn btn-primary">
                        Sıfırlama Bağlantısı Gönder
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>
    <script src="../assets/js/oauth.js"></script>
    
    <!-- OAuth Configuration -->
    <script>
        // OAuth configuration - these should come from environment variables
        window.GOOGLE_CLIENT_ID = '<?= $_ENV['GOOGLE_CLIENT_ID'] ?? '' ?>';
        window.APPLE_CLIENT_ID = '<?= $_ENV['APPLE_CLIENT_ID'] ?? '' ?>';
    </script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('companyLoginForm');
            const loginBtn = document.getElementById('loginBtn');
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');

            // Password visibility toggle
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                const icon = this.querySelector('i');
                icon.classList.toggle('fa-eye');
                icon.classList.toggle('fa-eye-slash');
            });

            // Login form submission
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(loginForm);
                const data = Object.fromEntries(formData);
                
                loginBtn.disabled = true;
                loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Giriş yapılıyor...';
                
                fetch('/api/auth/company-login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        showAlert('Giriş başarılı! Yönlendiriliyorsunuz...', 'success');
                        setTimeout(() => {
                            window.location.href = result.redirect || 'company-dashboard.php';
                        }, 1500);
                    } else {
                        showAlert(result.error || 'Giriş başarısız', 'danger');
                    }
                })
                .catch(error => {
                    console.error('Login error:', error);
                    showAlert('Giriş sırasında bir hata oluştu', 'danger');
                })
                .finally(() => {
                    loginBtn.disabled = false;
                    loginBtn.innerHTML = '<i class="fas fa-sign-in-alt me-2"></i>Giriş Yap';
                });
            });

            // Forgot password form
            document.getElementById('forgotPasswordForm').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const email = document.getElementById('reset_email').value;
                
                // For demo purposes, just show a message
                showAlert('Şifre sıfırlama bağlantısı ' + email + ' adresine gönderildi.', 'info');
                
                // Close modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('forgotPasswordModal'));
                modal.hide();
            });

            // Auto-fill demo account on demo button click
            document.querySelectorAll('.card-body .row .col-md-6').forEach(function(demoAccount) {
                demoAccount.style.cursor = 'pointer';
                demoAccount.addEventListener('click', function() {
                    const emailElement = this.querySelector('p:nth-child(2)');
                    const email = emailElement.textContent.replace('Email: ', '');
                    
                    document.getElementById('email').value = email;
                    document.getElementById('password').value = 'demo123';
                    
                    // Highlight the form briefly
                    loginForm.classList.add('border', 'border-primary');
                    setTimeout(() => {
                        loginForm.classList.remove('border', 'border-primary');
                    }, 2000);
                });
            });
        });
    </script>
</body>
</html>