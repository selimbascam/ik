<?php
require_once __DIR__ . '/../includes/config.php';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Yöneticisi Girişi - SZB İK Takip</title>
    <meta name="description" content="SZB İK Takip sistemi platform yöneticisi giriş sayfası.">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>

<body class="bg-dark">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-bottom">
        <div class="container">
            <a class="navbar-brand" href="../">
                <i class="fas fa-cogs me-2"></i>
                SZB İK Takip - Sistem
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="../">Ana Sayfa</a>
                <a class="nav-link" href="company-login.php">Şirket Girişi</a>
                <a class="nav-link" href="company-register.php">Şirket Kayıt</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <!-- Header -->
                <div class="text-center mb-5">
                    <div class="bg-danger text-white p-3 rounded mb-4">
                        <i class="fas fa-shield-alt fa-2x mb-2"></i>
                        <h3 class="mb-0">Sistem Yöneticisi</h3>
                        <p class="mb-0 small">Platform Yönetim Paneli</p>
                    </div>
                </div>

                <!-- Login Form -->
                <div class="card shadow-lg bg-dark text-white">
                    <div class="card-body p-5">
                        <form id="systemLoginForm">
                            <div class="mb-4 text-center">
                                <i class="fas fa-user-shield fa-4x text-danger mb-3"></i>
                                <h4>Güvenli Giriş</h4>
                                <p class="text-muted">Yetkili personel erişimi</p>
                            </div>

                            <div class="mb-3">
                                <label for="username" class="form-label">Kullanıcı Adı</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-dark text-white border-secondary">
                                        <i class="fas fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control bg-dark text-white border-secondary" 
                                           id="username" name="username" required 
                                           placeholder="Sistem kullanıcı adınız">
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label">Şifre</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-dark text-white border-secondary">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control bg-dark text-white border-secondary" 
                                           id="password" name="password" required 
                                           placeholder="••••••••">
                                    <button class="btn btn-outline-secondary text-white" type="button" id="togglePassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="d-grid mb-4">
                                <button type="submit" class="btn btn-danger btn-lg" id="loginBtn">
                                    <i class="fas fa-shield-alt me-2"></i>
                                    Güvenli Giriş
                                </button>
                            </div>
                        </form>

                        <div class="text-center">
                            <div class="alert alert-warning" role="alert">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <strong>Uyarı:</strong> Bu alan sadece yetkili sistem yöneticileri içindir.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Demo Account Info -->
                <div class="card mt-4 bg-dark text-white">
                    <div class="card-header bg-info">
                        <h6 class="mb-0 text-white">
                            <i class="fas fa-info-circle me-2"></i>
                            Demo Hesabı
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="text-center">
                            <h6 class="text-info">Test Sistem Yöneticisi</h6>
                            <p class="small mb-1"><strong>Kullanıcı Adı:</strong> superadmin</p>
                            <p class="small mb-1"><strong>Şifre:</strong> admin123</p>
                            <p class="small mb-0 text-muted">Tüm sistem yetkileri</p>
                            <button class="btn btn-sm btn-outline-info mt-2" onclick="fillDemoCredentials()">
                                Demo Bilgilerini Doldur
                            </button>
                        </div>
                    </div>
                </div>

                <!-- System Features -->
                <div class="card mt-4 bg-dark text-white">
                    <div class="card-header bg-secondary">
                        <h6 class="mb-0 text-white">
                            <i class="fas fa-cogs me-2"></i>
                            Sistem Özellikleri
                        </h6>
                    </div>
                    <div class="card-body">
                        <ul class="list-unstyled small">
                            <li><i class="fas fa-check text-success me-2"></i>Şirket yönetimi ve onayları</li>
                            <li><i class="fas fa-check text-success me-2"></i>Paket ve abonelik yönetimi</li>
                            <li><i class="fas fa-check text-success me-2"></i>Sistem ayarları ve konfigürasyon</li>
                            <li><i class="fas fa-check text-success me-2"></i>Kullanıcı yetki yönetimi</li>
                            <li><i class="fas fa-check text-success me-2"></i>Sistem raporları ve analitik</li>
                            <li><i class="fas fa-check text-success me-2"></i>Veritabanı yönetimi</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/app.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('systemLoginForm');
            const loginBtn = document.getElementById('loginBtn');
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');

            // Password visibility toggle
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                const icon = this.querySelector('i');
                icon.classList.toggle('fa-eye');
                icon.classList.toggle('fa-eye-slash');
            });

            // System login form submission
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(loginForm);
                const data = Object.fromEntries(formData);
                
                loginBtn.disabled = true;
                loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Doğrulanıyor...';
                
                fetch('/api/auth/system-login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        showAlert('Sistem girişi başarılı! Yönlendiriliyorsunuz...', 'success');
                        setTimeout(() => {
                            window.location.href = result.redirect || 'system-dashboard.php';
                        }, 1500);
                    } else {
                        showAlert(result.error || 'Sistem girişi başarısız', 'danger');
                    }
                })
                .catch(error => {
                    console.error('System login error:', error);
                    showAlert('Sistem girişi sırasında bir hata oluştu', 'danger');
                })
                .finally(() => {
                    loginBtn.disabled = false;
                    loginBtn.innerHTML = '<i class="fas fa-shield-alt me-2"></i>Güvenli Giriş';
                });
            });
        });

        // Fill demo credentials
        function fillDemoCredentials() {
            document.getElementById('username').value = 'superadmin';
            document.getElementById('password').value = 'admin123';
            
            // Highlight the form briefly
            const form = document.getElementById('systemLoginForm');
            form.classList.add('border', 'border-info');
            setTimeout(() => {
                form.classList.remove('border', 'border-info');
            }, 2000);
        }
    </script>
</body>
</html>