<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Settings Tables Creation</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Create work_settings table
    $sql = "CREATE TABLE IF NOT EXISTS work_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        daily_work_hours DECIMAL(4,2) DEFAULT 8.00,
        weekly_work_hours DECIMAL(5,2) DEFAULT 40.00,
        monthly_work_hours DECIMAL(6,2) DEFAULT 160.00,
        overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
        holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
        weekend_multiplier DECIMAL(3,2) DEFAULT 1.50,
        grace_period_minutes INT DEFAULT 15,
        late_penalty_amount DECIMAL(10,2) DEFAULT 0.00,
        min_break_duration INT DEFAULT 30,
        max_break_duration INT DEFAULT 60,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ work_settings table created/verified";
    echo "</div>";
    
    // Create qr_settings table
    $sql = "CREATE TABLE IF NOT EXISTS qr_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        location_tolerance_meters INT DEFAULT 100,
        qr_expiry_minutes INT DEFAULT 5,
        allow_offline_checkin BOOLEAN DEFAULT FALSE,
        require_photo BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ qr_settings table created/verified";
    echo "</div>";
    
    // Create notification_settings table
    $sql = "CREATE TABLE IF NOT EXISTS notification_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        email_notifications BOOLEAN DEFAULT TRUE,
        sms_notifications BOOLEAN DEFAULT FALSE,
        late_arrival_alert BOOLEAN DEFAULT TRUE,
        absence_alert BOOLEAN DEFAULT TRUE,
        leave_request_alert BOOLEAN DEFAULT TRUE,
        overtime_alert BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ notification_settings table created/verified";
    echo "</div>";
    
    // Add missing columns to companies table if needed
    try {
        $conn->exec("ALTER TABLE companies ADD COLUMN IF NOT EXISTS time_zone VARCHAR(50) DEFAULT 'Europe/Istanbul'");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ time_zone column added to companies table";
        echo "</div>";
    } catch (Exception $e) {
        // Column might already exist
        if (strpos($e->getMessage(), 'Duplicate column name') === false) {
            throw $e;
        }
    }
    
    try {
        $conn->exec("ALTER TABLE companies ADD COLUMN IF NOT EXISTS tax_number VARCHAR(20)");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ tax_number column added to companies table";
        echo "</div>";
    } catch (Exception $e) {
        if (strpos($e->getMessage(), 'Duplicate column name') === false) {
            throw $e;
        }
    }
    
    try {
        $conn->exec("ALTER TABLE companies ADD COLUMN IF NOT EXISTS website VARCHAR(255)");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ website column added to companies table";
        echo "</div>";
    } catch (Exception $e) {
        if (strpos($e->getMessage(), 'Duplicate column name') === false) {
            throw $e;
        }
    }
    
    echo "<h3>Database Schema Updated Successfully!</h3>";
    echo "<p>All settings tables have been created and companies table updated.</p>";
    
} catch (Exception $e) {
    echo "<div style='color: #721c24; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ Error: " . htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo "<br><a href='admin/company-settings.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Test Company Settings</a>";
echo " <a href='dashboard/company-dashboard.php' style='background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 10px;'>Dashboard</a>";
?>