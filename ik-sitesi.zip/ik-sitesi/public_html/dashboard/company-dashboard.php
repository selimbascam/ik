<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if user is logged in
// Allow super admin bypass
if (!isset($_SESSION['user_id']) || !isset($_SESSION['company_id'])) {
    // Check if super admin is trying to bypass
    if (!isset($_SESSION['super_admin_bypass'])) {
        header('Location: ../auth/company-login.php');
        exit;
    }
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get company info
    $stmt = $conn->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$_SESSION['company_id']]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Initialize stats with default values
    $stats = [
        'total_employees' => 0,
        'present_today' => 0,
        'absent_today' => 0,
        'pending_leaves' => 0
    ];
    
    // Total employees - use is_active column with boolean check
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE company_id = ? AND (is_active = TRUE OR status = 'active')");
    $stmt->execute([$_SESSION['company_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['total_employees'] = $result ? (int)$result['count'] : 0;
    
    // Present today - safer query with null checks
    $today = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT COUNT(DISTINCT e.id) as count 
        FROM employees e 
        LEFT JOIN attendance_records ar ON e.id = ar.employee_id AND DATE(ar.check_in) = ?
        WHERE e.company_id = ? AND COALESCE(e.is_active, 1) = 1 AND COALESCE(e.status, 'active') = 'active' AND ar.id IS NOT NULL AND ar.check_out IS NULL
    ");
    $stmt->execute([$today, $_SESSION['company_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['present_today'] = $result ? (int)$result['count'] : 0;
    
    // Absent today - safe calculation
    $stats['absent_today'] = max(0, $stats['total_employees'] - $stats['present_today']);
    
    // Pending leave requests - safer query with table existence check
    try {
        $stmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM leave_requests lr 
            JOIN employees e ON lr.employee_id = e.id 
            WHERE e.company_id = ? AND lr.status = 'pending'
        ");
        $stmt->execute([$_SESSION['company_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stats['pending_leaves'] = $result ? (int)$result['count'] : 0;
    } catch (Exception $leave_error) {
        // If leave_requests table doesn't exist, keep default value
        $stats['pending_leaves'] = 0;
    }
    
} catch (Exception $e) {
    $error = "Veri yüklenirken hata: " . $e->getMessage();
    // Ensure stats array exists even on error
    if (!isset($stats)) {
        $stats = [
            'total_employees' => 0,
            'present_today' => 0,
            'absent_today' => 0,
            'pending_leaves' => 0
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yönetici Paneli - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-6">
                <div class="flex items-center">
                    <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                        <span class="text-white font-bold"><?php echo strtoupper(substr($company['company_name'] ?? 'S', 0, 1)); ?></span>
                    </div>
                    <div>
                        <h1 class="text-xl font-semibold text-gray-900"><?php echo $company['company_name'] ?? APP_NAME; ?></h1>
                        <p class="text-sm text-gray-600">
                            <?php if (isset($_SESSION['super_admin_bypass'])): ?>
                                Süper Admin Erişimi - Kod: <?php echo $company['company_code'] ?? 'N/A'; ?>
                            <?php else: ?>
                                Yönetici Paneli
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">
                        <?php echo $_SESSION['user_name'] ?? ($_SESSION['user_email'] ?? 'Admin'); ?>
                    </span>
                    <?php if (isset($_SESSION['super_admin_bypass'])): ?>
                        <a href="/ik/super-admin/" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
                            👑 Süper Admin'e Dön
                        </a>
                    <?php endif; ?>
                    <a href="/ik/auth/logout.php" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Çıkış</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                                <span class="text-white text-sm font-bold"><?php echo $stats['total_employees']; ?></span>
                            </div>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">Toplam Personel</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $stats['total_employees']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                                <span class="text-white text-sm font-bold"><?php echo $stats['present_today']; ?></span>
                            </div>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">Bugün İşte</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $stats['present_today']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                                <span class="text-white text-sm font-bold"><?php echo $stats['absent_today']; ?></span>
                            </div>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">Bugün Yok</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $stats['absent_today']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <div class="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                                <span class="text-white text-sm font-bold"><?php echo $stats['pending_leaves']; ?></span>
                            </div>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">Bekleyen İzin</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $stats['pending_leaves']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Hızlı Erişim</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <a href="/ik/admin/employee-management.php" class="group relative rounded-lg p-6 bg-blue-50 hover:bg-blue-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-blue-900">Personel Yönetimi</h4>
                            <p class="text-sm text-blue-700 mt-1">Personel ekle, düzenle, listele</p>
                        </div>
                    </a>

                    <a href="/ik/admin/employee-attendance-list.php" class="group relative rounded-lg p-6 bg-green-50 hover:bg-green-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-green-900">👥 Günlük Devam Listesi</h4>
                            <p class="text-sm text-green-700 mt-1">Gerçek zamanlı personel durumu ve IP takibi</p>
                        </div>
                    </a>

                    <a href="/ik/admin/attendance-tracking.php" class="group relative rounded-lg p-6 bg-teal-50 hover:bg-teal-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-teal-900">📊 Aylık Devam Takibi</h4>
                            <p class="text-sm text-teal-700 mt-1">Aylık raporlar ve istatistikler</p>
                        </div>
                    </a>

                    <a href="/ik/admin/qr-generator.php" class="group relative rounded-lg p-6 bg-purple-50 hover:bg-purple-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-purple-900">QR Lokasyonlar</h4>
                            <p class="text-sm text-purple-700 mt-1">QR kod noktalarını yönet</p>
                        </div>
                    </a>

                    <a href="/ik/admin/leave-management.php" class="group relative rounded-lg p-6 bg-yellow-50 hover:bg-yellow-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-yellow-900">İzin Talepleri</h4>
                            <p class="text-sm text-yellow-700 mt-1">İzin onay ve takibi</p>
                        </div>
                    </a>

                    <a href="/ik/reports/dashboard.php" class="group relative rounded-lg p-6 bg-red-50 hover:bg-red-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-red-900">Raporlar</h4>
                            <p class="text-sm text-red-700 mt-1">Detaylı analiz ve raporlar</p>
                        </div>
                    </a>

                    <a href="/ik/admin/company-user-management.php" class="group relative rounded-lg p-6 bg-cyan-50 hover:bg-cyan-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-cyan-900">👤 Kullanıcı Yönetimi</h4>
                            <p class="text-sm text-cyan-700 mt-1">Yönetici ve kullanıcı hesaplarını yönet</p>
                        </div>
                    </a>

                    <a href="/ik/admin/work-settings.php" class="group relative rounded-lg p-6 bg-orange-50 hover:bg-orange-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-orange-900">Çalışma Ayarları</h4>
                            <p class="text-sm text-orange-700 mt-1">Mesai, ücret ve çalışma planı</p>
                        </div>
                    </a>

                    <a href="/ik/admin/holiday-management.php" class="group relative rounded-lg p-6 bg-pink-50 hover:bg-pink-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-pink-900">Tatil Günleri</h4>
                            <p class="text-sm text-pink-700 mt-1">Resmi tatil ve özel günler</p>
                        </div>
                    </a>

                    <a href="/ik/admin/company-settings.php" class="group relative rounded-lg p-6 bg-gray-50 hover:bg-gray-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-gray-900">Ayarlar</h4>
                            <p class="text-sm text-gray-700 mt-1">Şirket ve sistem ayarları</p>
                        </div>
                    </a>

                    <a href="/ik/view-device-records.php" class="group relative rounded-lg p-6 bg-teal-50 hover:bg-teal-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-teal-900">📱 Cihaz Kayıtları</h4>
                            <p class="text-sm text-teal-700 mt-1">Personel cihaz bilgileri ve IP takibi</p>
                        </div>
                    </a>

                    <a href="/ik/admin/device-management.php" class="group relative rounded-lg p-6 bg-emerald-50 hover:bg-emerald-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-emerald-900">🛡️ Cihaz Yönetimi</h4>
                            <p class="text-sm text-emerald-700 mt-1">Cihaz onay, engelleme ve güvenlik yönetimi</p>
                        </div>
                    </a>

                    <a href="/ik/admin/shift-management.php" class="group relative rounded-lg p-6 bg-violet-50 hover:bg-violet-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-violet-900">🕒 Vardiya Yönetimi</h4>
                            <p class="text-sm text-violet-700 mt-1">Çalışma saatleri, vardiya planlaması ve atama</p>
                        </div>
                    </a>

                    <a href="/ik/api/calculate-monthly-summary.php" class="group relative rounded-lg p-6 bg-amber-50 hover:bg-amber-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-amber-900">💰 Bordro Hesaplama</h4>
                            <p class="text-sm text-amber-700 mt-1">225 saat esaslı maaş hesaplama ve bordro</p>
                        </div>
                    </a>

                    <a href="/ik/admin/learning-recommendations.php" class="group relative rounded-lg p-6 bg-gradient-to-r from-purple-50 to-blue-50 hover:from-purple-100 hover:to-blue-100 transition">
                        <div>
                            <h4 class="text-sm font-medium text-purple-900">🧠 Öğrenme Önerileri</h4>
                            <p class="text-sm text-purple-700 mt-1">AI destekli personel gelişim ve eğitim önerileri</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </main>
</body>
</html>