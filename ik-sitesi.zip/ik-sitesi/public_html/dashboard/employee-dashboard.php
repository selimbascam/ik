<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

session_start();

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/employee-login.php');
    exit;
}

$employeeName = $_SESSION['employee_name'] ?? 'Personel';
$employeeNumber = $_SESSION['employee_number'] ?? '';
$companyName = $_SESSION['company_name'] ?? 'Şirket';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Personel Dashboard - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6 max-w-4xl">
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mr-4">
                        <span class="text-white text-2xl font-bold">👤</span>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Hoş Geldiniz</h1>
                        <p class="text-gray-600"><?php echo htmlspecialchars($employeeName); ?> (<?php echo htmlspecialchars($employeeNumber); ?>)</p>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($companyName); ?></p>
                    </div>
                </div>
                <div class="text-right">
                    <a href="../auth/employee-login.php?logout=1" class="text-red-600 hover:text-red-800 text-sm">
                        🚪 Çıkış Yap
                    </a>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 max-w-2xl mx-auto">
            <!-- Attendance Records -->
            <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div class="text-center">
                    <div class="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span class="text-white text-2xl">📊</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Devam Kayıtları</h3>
                    <p class="text-gray-600 text-sm mb-4">Çalışma saatleri ve devam durumu</p>
                    <a href="../attendance/records.php" class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors inline-block">
                        📊 Kayıtları Gör
                    </a>
                </div>
            </div>

            <!-- Earnings -->
            <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                <div class="text-center">
                    <div class="w-16 h-16 bg-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span class="text-white text-2xl">💰</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Kazanç Takibi</h3>
                    <p class="text-gray-600 text-sm mb-4">Aylık kazanç ve bordro</p>
                    <a href="../attendance/earnings.php" class="w-full bg-yellow-600 text-white py-2 px-4 rounded-lg hover:bg-yellow-700 transition-colors inline-block">
                        💰 Kazançları Gör
                    </a>
                </div>
            </div>
        </div>

        <!-- Session Debug Info -->
        <div class="bg-gray-100 rounded-lg p-4 mt-6">
            <h3 class="text-sm font-semibold text-gray-700 mb-2">🔍 Session Bilgileri (Debug)</h3>
            <div class="text-xs text-gray-600 space-y-1">
                <p><strong>Employee ID:</strong> <?php echo $_SESSION['employee_id'] ?? 'Yok'; ?></p>
                <p><strong>Company ID:</strong> <?php echo $_SESSION['company_id'] ?? 'Yok'; ?></p>
                <p><strong>Session ID:</strong> <?php echo session_id(); ?></p>
                <p><strong>User Role:</strong> <?php echo $_SESSION['user_role'] ?? 'Yok'; ?></p>
            </div>
        </div>

        <!-- Navigation -->
        <div class="text-center mt-6">
            <div class="bg-white rounded-lg p-4">
                <h3 class="text-sm font-semibold text-gray-700 mb-2">Diğer İşlemler</h3>
                <div class="flex flex-wrap justify-center gap-2">
                    <a href="../ik-ana-sayfa.php" class="text-blue-600 hover:text-blue-800 text-sm px-3 py-1 rounded bg-blue-50 hover:bg-blue-100">
                        🏠 Ana Sayfa
                    </a>
                    <a href="../test-qr-login-fix.php" class="text-green-600 hover:text-green-800 text-sm px-3 py-1 rounded bg-green-50 hover:bg-green-100">
                        🧪 QR Test
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>