<?php
// Redirect to correct super admin path
header('Location: ../super-admin/index.php');
exit;
?>