<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Device Management Employee Number Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if employee_number column exists in employees table
    echo "<h3>Checking Employee Number Column</h3>";
    
    $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
    $columns = $columnCheck->fetchAll();
    
    if (count($columns) == 0) {
        echo "<p style='color: orange;'>Employee number column missing. Adding it now...</p>";
        
        // Add employee_number column
        $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
        echo "<p style='color: green;'>Employee number column added</p>";
        
        // Generate employee numbers for existing employees
        $existingEmps = $conn->query("SELECT id, first_name, last_name FROM employees WHERE employee_number IS NULL OR employee_number = ''");
        $employees = $existingEmps->fetchAll();
        
        foreach ($employees as $emp) {
            $employeeNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            $updateStmt->execute([$employeeNumber, $emp['id']]);
        }
        
        echo "<p style='color: green;'>Generated employee numbers for " . count($employees) . " employees</p>";
    } else {
        echo "<p style='color: green;'>Employee number column already exists</p>";
    }
    
    // Test the device management query
    echo "<h3>Testing Device Management Query</h3>";
    
    $testQuery = "
        SELECT 
            ed.id,
            ed.device_fingerprint,
            ed.device_name,
            ed.browser_info,
            ed.is_trusted,
            ed.last_used,
            ed.notes,
            e.id as employee_id,
            e.first_name,
            e.last_name,
            e.employee_number
        FROM employee_devices ed
        JOIN employees e ON ed.employee_id = e.id
        WHERE e.company_id = ?
        ORDER BY ed.last_used DESC
        LIMIT 5
    ";
    
    $testStmt = $conn->prepare($testQuery);
    $testStmt->execute([1]); // Test with company_id = 1
    $devices = $testStmt->fetchAll();
    
    echo "<p>Found " . count($devices) . " devices for testing</p>";
    
    if (count($devices) > 0) {
        echo "<h4>Sample Device Records:</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr>";
        echo "<th style='padding: 8px;'>Employee</th>";
        echo "<th style='padding: 8px;'>Employee No</th>";
        echo "<th style='padding: 8px;'>Device</th>";
        echo "<th style='padding: 8px;'>Trusted</th>";
        echo "</tr>";
        
        foreach ($devices as $device) {
            echo "<tr>";
            echo "<td style='padding: 8px;'>{$device['first_name']} {$device['last_name']}</td>";
            echo "<td style='padding: 8px;'>" . ($device['employee_number'] ?? 'N/A') . "</td>";
            echo "<td style='padding: 8px;'>" . substr($device['device_name'] ?? 'Unknown', 0, 30) . "</td>";
            echo "<td style='padding: 8px;'>" . ($device['is_trusted'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No device records found. Creating test device for demo...</p>";
        
        // Create a test employee if none exists
        $empCheck = $conn->query("SELECT id FROM employees WHERE company_id = 1 LIMIT 1");
        $testEmp = $empCheck->fetch();
        
        if (!$testEmp) {
            echo "<p style='color: orange;'>No employees found for company 1</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
}

echo "<h3>Test Device Management</h3>";
echo "<div>";
echo "<a href='admin/device-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Device Management</a>";
echo "<a href='admin/dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
table { width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background: #f0f0f0; }
</style>