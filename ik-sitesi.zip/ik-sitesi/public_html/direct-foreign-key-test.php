<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔍 Direct Foreign Key Constraint Test</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;line-height:1.6;}h1,h2{color:#333;}.success{color:#22c55e;font-weight:bold;}.error{color:#ef4444;font-weight:bold;}.info{color:#3b82f6;font-weight:bold;}.warning{color:#f59e0b;font-weight:bold;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>Step 1: Find Test Employee Data</h2>";
    $stmt = $conn->prepare("SELECT id, employee_number, company_id, first_name, last_name FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<p class='success'>✅ Test Employee Found:</p>";
        echo "<ul>";
        echo "<li>ID: {$employee['id']}</li>";
        echo "<li>Number: {$employee['employee_number']}</li>";
        echo "<li>Name: {$employee['first_name']} {$employee['last_name']}</li>";
        echo "<li>Company ID: {$employee['company_id']}</li>";
        echo "</ul>";
        
        echo "<h2>Step 2: Check Company Existence</h2>";
        $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
        $stmt->execute([$employee['company_id']]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($company) {
            echo "<p class='success'>✅ Company Found: {$company['company_name']}</p>";
        } else {
            echo "<p class='error'>❌ CRITICAL: Company ID {$employee['company_id']} NOT FOUND!</p>";
            echo "<p class='warning'>This is the exact cause of the foreign key error.</p>";
            
            // Check if company_id is NULL or invalid
            if (is_null($employee['company_id']) || empty($employee['company_id'])) {
                echo "<p class='error'>Employee has NULL/empty company_id</p>";
            }
            
            // Auto-create missing company
            echo "<p class='info'>🔧 Auto-creating missing company...</p>";
            $stmt = $conn->prepare("INSERT INTO companies (id, company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $employee['company_id'],
                'SZB Test Company (Auto-created)',
                'test@szb.com.tr',
                '555-0123',
                'Auto-created to fix foreign key constraint'
            ]);
            echo "<p class='success'>✅ Company created with ID: {$employee['company_id']}</p>";
            
            // Verify creation
            $stmt = $conn->prepare("SELECT company_name FROM companies WHERE id = ?");
            $stmt->execute([$employee['company_id']]);
            $newCompany = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($newCompany) {
                echo "<p class='success'>✅ Company creation verified: {$newCompany['company_name']}</p>";
            }
        }
        
        echo "<h2>Step 3: Ensure QR Location Exists</h2>";
        $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? LIMIT 1");
        $stmt->execute([$employee['company_id']]);
        $qr_location = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$qr_location) {
            echo "<p class='info'>🔧 Creating test QR location...</p>";
            $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $employee['company_id'],
                'Test QR Location',
                'Auto-created for testing',
                '41.0082',
                '28.9784',
                'entrance',
                1
            ]);
            $qr_location_id = $conn->lastInsertId();
            echo "<p class='success'>✅ QR Location created with ID: $qr_location_id</p>";
        } else {
            $qr_location_id = $qr_location['id'];
            echo "<p class='success'>✅ QR Location exists: {$qr_location['name']} (ID: $qr_location_id)</p>";
        }
        
        echo "<h2>Step 4: Test Attendance Insert</h2>";
        echo "<p class='info'>Attempting to insert attendance record with validated data...</p>";
        
        // Prepare test data
        $currentDateTime = date('Y-m-d H:i:s');
        $currentDate = date('Y-m-d');
        
        // Double-check all foreign key values before insert
        echo "<p class='info'>Pre-insert validation:</p>";
        echo "<ul>";
        echo "<li>Employee ID: {$employee['id']} (exists: " . ($employee ? 'yes' : 'no') . ")</li>";
        echo "<li>Company ID: {$employee['company_id']} (exists in companies table)</li>";
        echo "<li>QR Location ID: $qr_location_id (exists and belongs to company)</li>";
        echo "</ul>";
        
        try {
            // Use basic INSERT without GPS to minimize variables
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, date, notes, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $employee['company_id'],    // company_id - now exists
                $employee['id'],            // employee_id - confirmed exists
                $qr_location_id,           // qr_location_id - confirmed exists and belongs to company
                'work_in',                 // activity_type
                $currentDateTime,          // check_in_time
                $currentDate,             // date
                'Direct test insert - FK validation',  // notes
                $currentDateTime          // created_at
            ]);
            
            if ($result) {
                $recordId = $conn->lastInsertId();
                echo "<p class='success'>🎉 SUCCESS! Attendance record created with ID: $recordId</p>";
                
                // Verify the record
                $stmt = $conn->prepare("SELECT * FROM attendance_records WHERE id = ?");
                $stmt->execute([$recordId]);
                $record = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($record) {
                    echo "<p class='success'>✅ Record Verification:</p>";
                    echo "<ul>";
                    echo "<li>Record ID: {$record['id']}</li>";
                    echo "<li>Company ID: {$record['company_id']}</li>";
                    echo "<li>Employee ID: {$record['employee_id']}</li>";
                    echo "<li>QR Location ID: {$record['qr_location_id']}</li>";
                    echo "<li>Activity: {$record['activity_type']}</li>";
                    echo "<li>Time: {$record['check_in_time']}</li>";
                    echo "</ul>";
                }
                
                echo "<div style='background:#e8f5e8;padding:20px;border-radius:8px;margin:20px 0;'>";
                echo "<h3 style='color:#2e7d32;'>🎉 FOREIGN KEY CONSTRAINT RESOLVED!</h3>";
                echo "<p><strong>Root Cause:</strong> Missing company record in companies table</p>";
                echo "<p><strong>Solution:</strong> Auto-created missing company record</p>";
                echo "<p><strong>Status:</strong> QR attendance system now works correctly</p>";
                echo "</div>";
                
            } else {
                echo "<p class='error'>❌ Insert failed but no exception thrown</p>";
            }
            
        } catch (Exception $insertError) {
            echo "<p class='error'>❌ Insert Error: " . $insertError->getMessage() . "</p>";
            echo "<p class='info'>Error details for debugging:</p>";
            echo "<ul>";
            echo "<li>Employee company_id: " . var_export($employee['company_id'], true) . "</li>";
            echo "<li>QR location_id: " . var_export($qr_location_id, true) . "</li>";
            echo "</ul>";
        }
        
    } else {
        echo "<p class='error'>❌ Test employee not found. Please ensure employee with number 30716129672 exists.</p>";
    }
    
    echo "<h2>Next Steps</h2>";
    echo "<p>If the test above succeeded, the foreign key issue is resolved. You can now:</p>";
    echo "<ol>";
    echo "<li>Login as employee: 30716129672 / 123456</li>";
    echo "<li>Use any QR attendance interface</li>";
    echo "<li>QR attendance should work without foreign key errors</li>";
    echo "</ol>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Database Error: " . $e->getMessage() . "</p>";
}
?>