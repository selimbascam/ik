<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 QR Date Error Emergency Fix</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>🏥 Emergency QR Date Column Fix</h3>";
    
    // Check attendance_records table structure
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $hasDateColumn = in_array('date', $columns);
    $hasCreatedAtColumn = in_array('created_at', $columns);
    $hasCheckInTimeColumn = in_array('check_in_time', $columns);
    
    echo "<p>✅ Table structure analyzed:</p>";
    echo "<ul>";
    echo "<li>date column: " . ($hasDateColumn ? 'EXISTS' : 'MISSING') . "</li>";
    echo "<li>created_at column: " . ($hasCreatedAtColumn ? 'EXISTS' : 'MISSING') . "</li>";
    echo "<li>check_in_time column: " . ($hasCheckInTimeColumn ? 'EXISTS' : 'MISSING') . "</li>";
    echo "</ul>";
    
    // Add missing date column if needed
    if (!$hasDateColumn) {
        echo "<h4>🔧 Adding missing 'date' column</h4>";
        
        if ($hasCreatedAtColumn) {
            try {
                // Add date column as a computed column
                $conn->exec("ALTER TABLE attendance_records ADD COLUMN date DATE NULL");
                echo "<p>✅ Date column added</p>";
                
                // Populate with existing data
                $conn->exec("UPDATE attendance_records SET date = DATE(created_at) WHERE created_at IS NOT NULL");
                echo "<p>✅ Date column populated from created_at</p>";
                
                // Add index
                $conn->exec("ALTER TABLE attendance_records ADD INDEX idx_attendance_date (date)");
                echo "<p>✅ Index added</p>";
                
            } catch (Exception $e) {
                echo "<p>❌ Column addition failed: " . $e->getMessage() . "</p>";
            }
        } elseif ($hasCheckInTimeColumn) {
            try {
                $conn->exec("ALTER TABLE attendance_records ADD COLUMN date DATE NULL");
                $conn->exec("UPDATE attendance_records SET date = DATE(check_in_time) WHERE check_in_time IS NOT NULL");
                $conn->exec("ALTER TABLE attendance_records ADD INDEX idx_attendance_date (date)");
                echo "<p>✅ Date column added and populated from check_in_time</p>";
                
            } catch (Exception $e) {
                echo "<p>❌ Column addition failed: " . $e->getMessage() . "</p>";
            }
        }
    } else {
        echo "<p>✅ Date column already exists</p>";
    }
    
    // Test the fixed queries
    echo "<h4>🧪 Testing QR Attendance Queries</h4>";
    
    try {
        // Test query that was failing
        $testStmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM attendance_records 
            WHERE employee_id = ? AND date = CURDATE()
        ");
        $testStmt->execute([1]);
        $result = $testStmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>✅ Date query test SUCCESSFUL (found " . ($result['count'] ?? 0) . " today)</p>";
        
    } catch (Exception $e) {
        echo "<p>❌ Date query still failing: " . $e->getMessage() . "</p>";
        
        // Alternative test
        try {
            $testStmt = $conn->prepare("
                SELECT COUNT(*) as count 
                FROM attendance_records 
                WHERE employee_id = ? AND DATE(created_at) = CURDATE()
            ");
            $testStmt->execute([1]);
            $result = $testStmt->fetch(PDO::FETCH_ASSOC);
            echo "<p>✅ Fallback DATE(created_at) query works</p>";
            
        } catch (Exception $e2) {
            echo "<p>❌ Both queries failing - deeper database issue</p>";
        }
    }
    
    // Check if we have test employee data
    echo "<h4>👤 Employee Data Check</h4>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employees WHERE company_id = 4");
        $empCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>Test company employees: $empCount</p>";
        
        if ($empCount > 0) {
            $stmt = $conn->query("SELECT id, employee_number, first_name, last_name FROM employees WHERE company_id = 4 LIMIT 3");
            $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<ul>";
            foreach ($employees as $emp) {
                echo "<li>ID: " . ($emp['id'] ?? 'N/A') . " - " . ($emp['employee_number'] ?? 'N/A') . " - " . htmlspecialchars(($emp['first_name'] ?? '') . ' ' . ($emp['last_name'] ?? '')) . "</li>";
            }
            echo "</ul>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ Employee check failed: " . $e->getMessage() . "</p>";
    }
    
    // Check QR locations
    echo "<h4>📍 QR Location Data Check</h4>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = 4");
        $locCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>QR Locations for test company: $locCount</p>";
        
        if ($locCount == 0) {
            echo "<p>⚠️ No QR locations found - this might be why QR scanning fails</p>";
            echo "<p><a href='admin/qr-generator.php' style='color: #dc3545; font-weight: bold;'>Create QR Locations →</a></p>";
        }
        
    } catch (Exception $e) {
        echo "<p>❌ QR location check failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<div style='background: #d1ecf1; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3>🎯 Fix Status</h3>";
    if (!$hasDateColumn && ($hasCreatedAtColumn || $hasCheckInTimeColumn)) {
        echo "<p>✅ Date column issue has been resolved</p>";
        echo "<p>✅ QR attendance should now work properly</p>";
    } elseif ($hasDateColumn) {
        echo "<p>✅ Date column was already present</p>";
        echo "<p>✅ Check if there are other issues</p>";
    } else {
        echo "<p>❌ Unable to fix - missing required date/time columns</p>";
    }
    echo "</div>";
    
    echo "<h3>🔗 Test Links</h3>";
    echo "<ul>";
    echo "<li><a href='employee/qr-attendance.php' style='color: #0056b3;'>Test QR Attendance (Employee)</a></li>";
    echo "<li><a href='qr/activity-selection.php' style='color: #0056b3;'>Test QR Activity Selection</a></li>";
    echo "<li><a href='debug/fix-qr-date-column.php' style='color: #6c757d;'>Detailed Date Column Analysis</a></li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Emergency Fix Failed</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "</style>";
?>