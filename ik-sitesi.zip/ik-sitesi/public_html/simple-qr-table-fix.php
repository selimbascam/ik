<?php
// Simple QR Settings Table Creation
$host = 'localhost';
$dbname = 'u978874874_ik';
$username = 'u978874874_ik';
$password = 'Szb2024!';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "<h2>QR Settings Table Fix</h2>";
    echo "<p>Database connected successfully</p>";
    
    // Create QR settings table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS qr_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            location_tolerance_meters INT DEFAULT 50,
            qr_expiry_minutes INT DEFAULT 5,
            allow_offline_checkin TINYINT(1) DEFAULT 0,
            require_photo TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_company_qr (company_id),
            INDEX idx_company_qr (company_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    echo "<p>QR settings table created/verified</p>";
    
    // Insert default for company 1
    $stmt = $pdo->prepare("
        INSERT IGNORE INTO qr_settings 
        (company_id, location_tolerance_meters, qr_expiry_minutes, allow_offline_checkin, require_photo) 
        VALUES (1, 50, 5, 0, 0)
    ");
    $stmt->execute();
    
    echo "<p>Default QR settings created for company 1</p>";
    
    // Test the query
    $stmt = $pdo->prepare("SELECT * FROM qr_settings WHERE company_id = 1");
    $stmt->execute();
    $qrSettings = $stmt->fetch();
    
    if ($qrSettings) {
        echo "<p><strong>QR Settings Found:</strong></p>";
        echo "<ul>";
        echo "<li>Location Tolerance: {$qrSettings['location_tolerance_meters']} meters</li>";
        echo "<li>QR Expiry: {$qrSettings['qr_expiry_minutes']} minutes</li>";
        echo "<li>Offline Check-in: " . ($qrSettings['allow_offline_checkin'] ? 'Enabled' : 'Disabled') . "</li>";
        echo "<li>Require Photo: " . ($qrSettings['require_photo'] ? 'Enabled' : 'Disabled') . "</li>";
        echo "</ul>";
        
        echo "<p style='color: green;'>✅ QR Settings table is working correctly!</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No QR settings found</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<p><a href='admin/company-settings.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Test Company Settings</a></p>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2 { color: #333; }
ul { background: #f8f9fa; padding: 15px; border-radius: 5px; }
</style>