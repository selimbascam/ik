<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $method = $_SERVER['REQUEST_METHOD'];
    $request = json_decode(file_get_contents('php://input'), 1);
    
    switch ($method) {
        case 'GET':
            if (isset($_GET['employee_id'])) {
                // Get recommendations for specific employee
                $stmt = $conn->prepare("
                    SELECT lr.*, e.first_name, e.last_name, e.employee_code 
                    FROM learning_recommendations lr
                    JOIN employees e ON lr.employee_id = e.id
                    WHERE lr.employee_id = ? AND lr.company_id = ?
                    ORDER BY lr.priority_score DESC
                ");
                $stmt->execute([$_GET['employee_id'], $_SESSION['company_id'] ?? 1]);
                $recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode([
                    'success' => 1,
                    'data' => $recommendations
                ]);
            } else {
                // Get all recommendations for company
                $stmt = $conn->prepare("
                    SELECT lr.*, e.first_name, e.last_name, e.employee_code,
                           d.name as department_name
                    FROM learning_recommendations lr
                    JOIN employees e ON lr.employee_id = e.id
                    LEFT JOIN departments d ON e.department_id = d.id
                    WHERE lr.company_id = ?
                    ORDER BY lr.priority_score DESC, lr.created_at DESC
                    LIMIT 50
                ");
                $stmt->execute([$_SESSION['company_id'] ?? 1]);
                $recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo json_encode([
                    'success' => 1,
                    'data' => $recommendations
                ]);
            }
            break;
            
        case 'POST':
            // Generate new recommendations
            if (isset($request['action']) && $request['action'] === 'generate') {
                $employee_id = $request['employee_id'] ?? null;
                $recommendations = [];
                
                if ($employee_id) {
                    // Generate for specific employee
                    $recommendations = generateEmployeeRecommendations($conn, $employee_id, $_SESSION['company_id'] ?? 1);
                    
                    // Save to database
                    foreach ($recommendations as $rec) {
                        $stmt = $conn->prepare("
                            INSERT INTO learning_recommendations 
                            (company_id, employee_id, recommendation_type, title, description, priority_score, ai_confidence)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE
                            description = VALUES(description),
                            priority_score = VALUES(priority_score),
                            ai_confidence = VALUES(ai_confidence),
                            updated_at = NOW()
                        ");
                        
                        $stmt->execute([
                            $_SESSION['company_id'] ?? 1,
                            $employee_id,
                            $rec['type'],
                            $rec['title'],
                            $rec['description'],
                            $rec['priority'],
                            $rec['confidence']
                        ]);
                    }
                }
                
                echo json_encode([
                    'success' => 1,
                    'message' => count($recommendations) . ' öğrenme önerisi oluşturuldu',
                    'data' => $recommendations
                ]);
            }
            break;
            
        case 'PUT':
            // Update recommendation status
            if (isset($request['id']) && isset($request['status'])) {
                $stmt = $conn->prepare("
                    UPDATE learning_recommendations 
                    SET status = ?, updated_at = NOW()
                    WHERE id = ? AND company_id = ?
                ");
                
                $result = $stmt->execute([
                    $request['status'],
                    $request['id'],
                    $_SESSION['company_id'] ?? 1
                ]);
                
                echo json_encode([
                    'success' => $result,
                    'message' => $result ? 'Öneri durumu güncellendi' : 'Güncelleme başarısız'
                ]);
            }
            break;
            
        case 'DELETE':
            // Delete recommendation
            if (isset($_GET['id'])) {
                $stmt = $conn->prepare("
                    DELETE FROM learning_recommendations 
                    WHERE id = ? AND company_id = ?
                ");
                
                $result = $stmt->execute([$_GET['id'], $_SESSION['company_id'] ?? 1]);
                
                echo json_encode([
                    'success' => $result,
                    'message' => $result ? 'Öneri silindi' : 'Silme başarısız'
                ]);
            }
            break;
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => 0,
        'error' => $e->getMessage()
    ]);
}

// AI-powered recommendation generation function
function generateEmployeeRecommendations($conn, $employee_id, $company_id) {
    $recommendations = [];
    
    // Get employee data
    $stmt = $conn->prepare("
        SELECT e.*, d.name as department_name 
        FROM employees e 
        LEFT JOIN departments d ON e.department_id = d.id 
        WHERE e.id = ? AND e.company_id = ?
    ");
    $stmt->execute([$employee_id, $company_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) return $recommendations;
    
    // Analyze attendance patterns
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_days,
            AVG(TIMESTAMPDIFF(HOUR, check_in_time, check_out_time)) as avg_hours,
            COUNT(CASE WHEN TIME(check_in_time) > '09:30:00' THEN 1 END) as late_arrivals,
            COUNT(CASE WHEN TIMESTAMPDIFF(HOUR, check_in_time, check_out_time) > 9 THEN 1 END) as overtime_days
        FROM attendance_records 
        WHERE employee_id = ? AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute([$employee_id]);
    $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Generate recommendations based on patterns
    if ($attendance && $attendance['late_arrivals'] > 3) {
        $severity = min(100, ($attendance['late_arrivals'] / 10) * 100);
        $recommendations[] = [
            'type' => 'time_management',
            'title' => 'Zaman Yönetimi ve Disiplin Eğitimi',
            'description' => sprintf(
                'Son 30 günde %d kez geç kalındı. Zaman yönetimi becerilerini geliştirmek ve çalışma disiplinini artırmak için özel eğitim programı önerilir.',
                $attendance['late_arrivals']
            ),
            'priority' => $severity,
            'confidence' => 0.85
        ];
    }
    
    if ($attendance && $attendance['overtime_days'] > 8) {
        $recommendations[] = [
            'type' => 'productivity',
            'title' => 'Verimlilik ve İş Organizasyonu',
            'description' => sprintf(
                'Fazla mesai günleri yüksek (%d gün). İş yükü dağılımı ve verimlilik artırıcı teknikler eğitimi önerilir.',
                $attendance['overtime_days']
            ),
            'priority' => min(100, ($attendance['overtime_days'] / 15) * 100),
            'confidence' => 0.78
        ];
    }
    
    // Career development based on tenure
    $tenure_days = (new DateTime())->diff(new DateTime($employee['hire_date']))->days;
    if ($tenure_days > 365 && $tenure_days < 730) {
        $recommendations[] = [
            'type' => 'career_development',
            'title' => 'Orta Vadeli Kariyer Planlama',
            'description' => 'Şirkette 1-2 yıl arası deneyim. Kariyer hedefleri belirleme ve gelişim planı oluşturma eğitimi önerilir.',
            'priority' => 65,
            'confidence' => 0.70
        ];
    }
    
    // Department-specific recommendations
    $dept_recs = getDepartmentRecommendations($employee['department_name']);
    $recommendations = array_merge($recommendations, $dept_recs);
    
    return $recommendations;
}

function getDepartmentRecommendations($department) {
    $recommendations = [];
    
    switch (strtolower($department ?? '')) {
        case 'it':
        case 'bilgi işlem':
            $recommendations[] = [
                'type' => 'technical_skills',
                'title' => 'Siber Güvenlik ve Veri Koruma',
                'description' => 'IT departmanı için güncel siber güvenlik tehditleri, veri koruma yönetmelikleri (KVKK/GDPR) ve güvenli kod geliştirme pratikleri eğitimi.',
                'priority' => 85,
                'confidence' => 0.90
            ];
            break;
            
        case 'sales':
        case 'satış':
            $recommendations[] = [
                'type' => 'sales_skills',
                'title' => 'Dijital Satış ve CRM Yönetimi',
                'description' => 'Modern satış teknikleri, online müşteri ilişkileri yönetimi ve dijital pazarlama entegrasyonu eğitimi.',
                'priority' => 80,
                'confidence' => 0.88
            ];
            break;
            
        case 'hr':
        case 'insan kaynakları':
            $recommendations[] = [
                'type' => 'hr_skills',
                'title' => 'Çalışan Deneyimi ve Yetenek Yönetimi',
                'description' => 'Modern İK pratikleri, çalışan deneyimi tasarımı ve yetenek geliştirme stratejileri eğitimi.',
                'priority' => 75,
                'confidence' => 0.82
            ];
            break;
    }
    
    return $recommendations;
}
?>