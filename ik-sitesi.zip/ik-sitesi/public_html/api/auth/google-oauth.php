<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../includes/oauth-config.php';
require_once __DIR__ . '/../common/database.php';

$db = getDB();

// Handle Google OAuth callback
if (isset($_GET['code']) && isset($_GET['state'])) {
    
    // Verify state parameter
    if (!isset($_SESSION['oauth_state']) || $_GET['state'] !== $_SESSION['oauth_state']) {
        die('Invalid state parameter');
    }
    
    $userType = $_SESSION['oauth_user_type'] ?? 'employee';
    
    // Exchange code for tokens
    $redirectUri = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/api/auth/google-oauth';
    $tokenData = OAuthHelper::exchangeGoogleCode($_GET['code'], $redirectUri);
    
    if (!$tokenData || !isset($tokenData['id_token'])) {
        die('Failed to exchange code for tokens');
    }
    
    // Verify ID token
    $userData = OAuthHelper::verifyGoogleToken($tokenData['id_token']);
    if (!$userData) {
        die('Invalid ID token');
    }
    
    // Get additional user info
    if (isset($tokenData['access_token'])) {
        $userInfo = OAuthHelper::getGoogleUserInfo($tokenData['access_token']);
        if ($userInfo) {
            $userData = array_merge($userData, $userInfo);
        }
    }
    
    // Create or update user
    $result = OAuthHelper::createOrUpdateOAuthUser($userData, 'google', $userType);
    
    if (isset($result['error'])) {
        // Redirect to login with error
        $errorMsg = urlencode($result['error']);
        if ($userType === 'company_admin') {
            header("Location: /company-login?error=$errorMsg");
        } else {
            header("Location: /self-service?error=$errorMsg");
        }
        exit;
    }
    
    // Set session
    if ($result['user_type'] === 'company_admin') {
        $_SESSION['admin_id'] = $result['user']['id'];
        $_SESSION['company_id'] = $result['company_id'];
        $_SESSION['admin_email'] = $result['user']['email'];
        $_SESSION['admin_role'] = 'company_admin';
        $_SESSION['is_owner'] = $result['user']['is_owner'];
        $_SESSION['login_type'] = 'company';
        $_SESSION['auth_method'] = 'google';
        
        header('Location: /company-dashboard');
    } else {
        $_SESSION['user_id'] = $result['user']['id'];
        $_SESSION['user_email'] = $result['user']['email'];
        $_SESSION['user_role'] = $result['user']['role'];
        $_SESSION['login_type'] = 'employee';
        $_SESSION['auth_method'] = 'google';
        
        header('Location: /self-service');
    }
    
    exit;
    
} else {
    // Start OAuth flow
    $userType = $_GET['user_type'] ?? 'employee';
    $redirectUri = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . '/api/auth/google-oauth';
    
    $authUrl = OAuthHelper::getGoogleAuthUrl($redirectUri, null, $userType);
    header("Location: $authUrl");
    exit;
}
?>