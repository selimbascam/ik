<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Sadece POST metodu desteklenir', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), 1);
    
    if (!$input) {
        errorResponse('Geçersiz JSON verisi');
    }

    $username = $input['username'] ?? '';
    $password = $input['password'] ?? '';

    if (empty($username) || empty($password)) {
        errorResponse('Kullanıcı adı ve şifre alanları gereklidir');
    }

    // Sistem yöneticisi girişi kontrol et
    $admin = $db->selectOne(
        'system_admins', 
        'username = :username AND is_active = 1', 
        [':username' => $username]
    );

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        errorResponse('Geçersiz kullanıcı adı veya şifre', 401);
    }

    // Session oluştur
    $_SESSION['system_admin_id'] = $admin['id'];
    $_SESSION['system_admin_username'] = $admin['username'];
    $_SESSION['system_admin_role'] = $admin['role'];
    $_SESSION['system_admin_permissions'] = json_decode($admin['permissions'], 1) ?? [];
    $_SESSION['login_time'] = time();
    $_SESSION['login_type'] = 'system';

    // Son giriş zamanını güncelle
    $db->update(
        'system_admins', 
        ['last_login' => date('Y-m-d H:i:s')], 
        'id = :id', 
        [':id' => $admin['id']]
    );

    $response = [
        'success' => 1,
        'message' => 'Sistem yöneticisi girişi başarılı',
        'admin' => [
            'id' => $admin['id'],
            'username' => $admin['username'],
            'first_name' => $admin['first_name'],
            'last_name' => $admin['last_name'],
            'email' => $admin['email'],
            'role' => $admin['role'],
            'permissions' => json_decode($admin['permissions'], 1) ?? []
        ],
        'redirect' => '/system-dashboard'
    ];

    jsonResponse($response);

} catch (Exception $e) {
    error_log("System Login API Error: " . $e->getMessage());
    errorResponse('Sistem girişi başarısız: ' . $e->getMessage(), 500);
}
?>