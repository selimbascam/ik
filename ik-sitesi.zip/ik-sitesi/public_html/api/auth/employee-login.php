<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Sadece POST metodu desteklenir', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), 1);
    
    if (!$input) {
        errorResponse('Geçersiz JSON verisi');
    }

    $email = $input['email'] ?? '';
    $employeeCode = $input['employee_code'] ?? '';
    $password = $input['password'] ?? '';

    // Email ve personel kodu en az birisi gerekli
    if (empty($email) && empty($employeeCode)) {
        errorResponse('Email veya personel kodu gereklidir');
    }

    if (empty($password)) {
        errorResponse('Şifre gereklidir');
    }

    // Personel arama
    $whereConditions = [];
    $params = [];

    if (!empty($email)) {
        $whereConditions[] = 'email = :email';
        $params[':email'] = $email;
    }

    if (!empty($employeeCode)) {
        $whereConditions[] = 'employee_code = :employee_code';
        $params[':employee_code'] = $employeeCode;
    }

    $whereClause = '(' . implode(' OR ', $whereConditions) . ') AND is_active = 1';

    $employee = $db->selectOne('employees', $whereClause, $params);

    if (!$employee) {
        errorResponse('Geçersiz giriş bilgileri');
    }

    // Şirket kontrolü
    $company = $db->selectOne('companies', 'id = :id AND is_active = 1', [':id' => $employee['company_id']]);
    if (!$company) {
        errorResponse('Şirket hesabı aktif değil');
    }

    // Kullanıcı bilgileri al
    if ($employee['user_id']) {
        $user = $db->selectOne('users', 'id = :id AND is_active = 1', [':id' => $employee['user_id']]);
        
        if (!$user) {
            errorResponse('Kullanıcı hesabı bulunamadı');
        }

        // Şifre kontrolü
        if (!password_verify($password, $user['password_hash'])) {
            errorResponse('Geçersiz şifre');
        }

        // Session oluştur
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['employee_id'] = $employee['id'];
        $_SESSION['company_id'] = $employee['company_id'];
        $_SESSION['employee_code'] = $employee['employee_code'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['login_type'] = 'employee';
        $_SESSION['auth_method'] = 'password';

        // Son giriş tarihini güncelle
        $db->update(
            'users',
            ['last_login' => date('Y-m-d H:i:s')],
            'id = :id',
            [':id' => $user['id']]
        );

        jsonResponse([
            'success' => 1,
            'message' => 'Giriş başarılı',
            'redirect' => '/self-service',
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'first_name' => $user['first_name'],
                'last_name' => $user['last_name'],
                'role' => $user['role']
            ],
            'employee' => [
                'id' => $employee['id'],
                'employee_code' => $employee['employee_code'],
                'first_name' => $employee['first_name'],
                'last_name' => $employee['last_name'],
                'position' => $employee['position']
            ],
            'company' => [
                'id' => $company['id'],
                'name' => $company['name']
            ]
        ]);

    } else {
        errorResponse('Bu personel için kullanıcı hesabı oluşturulmamış. Lütfen şirket yöneticinizle iletişime geçin.');
    }

} catch (Exception $e) {
    error_log("Employee Login API Error: " . $e->getMessage());
    errorResponse('Giriş işlemi başarısız: ' . $e->getMessage(), 500);
}
?>