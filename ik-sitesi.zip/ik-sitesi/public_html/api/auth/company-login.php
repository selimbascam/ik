<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Sadece POST metodu desteklenir', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), 1);
    
    if (!$input) {
        errorResponse('Geçersiz JSON verisi');
    }

    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';

    if (empty($email) || empty($password)) {
        errorResponse('Email ve şifre alanları gereklidir');
    }

    // Şirket yöneticisi girişi kontrol et
    $sql = "
        SELECT ca.*, c.company_name, c.status as company_active,
               cs.status as subscription_status, cs.end_date as subscription_end
        FROM company_admins ca
        JOIN companies c ON ca.company_id = c.id
        LEFT JOIN company_subscriptions cs ON c.id = cs.company_id AND cs.status = 'active'
        WHERE ca.email = :email AND ca.is_active = 1
        ORDER BY cs.end_date DESC
        LIMIT 1
    ";
    
    $stmt = $db->query($sql, [':email' => $email]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        errorResponse('Geçersiz email veya şifre', 401);
    }

    // Şirket aktif mi kontrol et
    if (!$admin['company_active']) {
        errorResponse('Şirket hesabı askıya alınmış', 403);
    }

    // Abonelik kontrol et
    if (!$admin['subscription_status'] || $admin['subscription_status'] !== 'active') {
        errorResponse('Şirket aboneliği aktif değil. Lütfen yönetim ile iletişime geçin.', 403);
    }

    // Abonelik süresi kontrol et
    if ($admin['subscription_end'] && strtotime($admin['subscription_end']) < time()) {
        errorResponse('Şirket aboneliği süresi dolmuş. Lütfen yenileyin.', 403);
    }

    // Session oluştur
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['company_id'] = $admin['company_id'];
    $_SESSION['admin_email'] = $admin['email'];
    $_SESSION['admin_role'] = 'company_admin';
    $_SESSION['is_owner'] = $admin['is_owner'];
    $_SESSION['company_name'] = $admin['company_name'];
    $_SESSION['permissions'] = json_decode($admin['permissions'], 1) ?? [];
    $_SESSION['login_time'] = time();
    $_SESSION['login_type'] = 'company';

    // Son giriş zamanını güncelle
    $db->update(
        'company_admins', 
        ['last_login' => date('Y-m-d H:i:s')], 
        'id = :id', 
        [':id' => $admin['id']]
    );

    // Şirket bilgilerini al
    $company = $db->selectOne('companies', 'id = :id', [':id' => $admin['company_id']]);
    
    // Paket bilgilerini al
    $packageInfo = null;
    if ($admin['subscription_status'] === 'active') {
        $sql = "
            SELECT cp.*, cs.end_date
            FROM company_packages cp
            JOIN company_subscriptions cs ON cp.id = cs.package_id
            WHERE cs.company_id = :company_id AND cs.status = 'active'
            ORDER BY cs.end_date DESC
            LIMIT 1
        ";
        $stmt = $db->query($sql, [':company_id' => $admin['company_id']]);
        $packageInfo = $stmt->fetch();
    }

    $response = [
        'success' => 1,
        'message' => 'Giriş başarılı',
        'admin' => [
            'id' => $admin['id'],
            'first_name' => $admin['first_name'],
            'last_name' => $admin['last_name'],
            'email' => $admin['email'],
            'phone' => $admin['phone'],
            'is_owner' => (bool)$admin['is_owner'],
            'permissions' => json_decode($admin['permissions'], 1) ?? []
        ],
        'company' => [
            'id' => $company['id'],
            'name' => $company['name'],
            'address' => $company['address'],
            'phone' => $company['phone'],
            'email' => $company['email'],
            'tax_number' => $company['tax_number']
        ],
        'package' => $packageInfo ? [
            'name' => $packageInfo['name'],
            'max_employees' => $packageInfo['max_employees'],
            'max_locations' => $packageInfo['max_locations'],
            'features' => json_decode($packageInfo['features'], 1) ?? [],
            'end_date' => $packageInfo['end_date']
        ] : null,
        'redirect' => '/company-dashboard'
    ];

    jsonResponse($response);

} catch (Exception $e) {
    error_log("Company Login API Error: " . $e->getMessage());
    errorResponse('Giriş işlemi başarısız: ' . $e->getMessage(), 500);
}
?>