<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Sadece POST metodu desteklenir', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), 1);
    
    if (!$input) {
        errorResponse('Geçersiz JSON verisi');
    }

    // Required fields validation
    if (empty($input['email']) || empty($input['password'])) {
        errorResponse('Email ve şifre alanları gereklidir');
    }

    $email = trim($input['email']);
    $password = $input['password'];
    $loginType = $input['login_type'] ?? 'user'; // 'user', 'company', 'admin'

    $auth = getAuth();
    $db = getDB();

    switch ($loginType) {
        case 'company':
            // Firma giriş sistemi
            $company = $db->selectOne(
                'companies', 
                'contact_email = :email AND is_active = 1', 
                [':email' => $email]
            );
            
            if (!$company) {
                errorResponse('Firma bulunamadı veya pasif durumda', 401);
            }

            // Firma admin kullanıcısını bul
            $user = $db->selectOne(
                'users', 
                'email = :email AND role = :role AND company_id = :company_id AND is_active = 1', 
                [
                    ':email' => $email,
                    ':role' => 'company_admin',
                    ':company_id' => $company['id']
                ]
            );
            
            if (!$user || !password_verify($password, $user['password_hash'])) {
                errorResponse('Geçersiz email veya şifre', 401);
            }

            // Session oluştur
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['company_id'] = $company['id'];
            $_SESSION['role'] = 'company_admin';
            $_SESSION['login_type'] = 'company';
            $_SESSION['login_time'] = time();

            // Company bilgilerini ekle
            $user['company'] = $company;
            unset($user['password_hash']);

            jsonResponse([
                'success' => 1,
                'message' => 'Firma girişi başarılı',
                'user' => $user,
                'redirect' => '/company-dashboard'
            ]);
            break;

        case 'admin':
            // Sistem admin giriş
            $user = $db->selectOne(
                'users', 
                'email = :email AND role = :role AND is_active = 1', 
                [
                    ':email' => $email,
                    ':role' => 'system_admin'
                ]
            );
            
            if (!$user || !password_verify($password, $user['password_hash'])) {
                errorResponse('Geçersiz admin bilgileri', 401);
            }

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = 'system_admin';
            $_SESSION['login_type'] = 'admin';
            $_SESSION['login_time'] = time();

            unset($user['password_hash']);

            jsonResponse([
                'success' => 1,
                'message' => 'Admin girişi başarılı',
                'user' => $user,
                'redirect' => '/admin-dashboard'
            ]);
            break;

        default:
            // Normal personel giriş
            $user = $db->selectOne(
                'users', 
                'email = :email AND is_active = 1', 
                [':email' => $email]
            );
            
            if (!$user || !password_verify($password, $user['password_hash'])) {
                errorResponse('Geçersiz email veya şifre', 401);
            }

            // Employee bilgilerini al
            $employee = $db->selectOne(
                'employees', 
                'user_id = :user_id AND is_active = 1', 
                [':user_id' => $user['id']]
            );

            if (!$employee) {
                errorResponse('Personel kaydı bulunamadı', 401);
            }

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['employee_id'] = $employee['id'];
            $_SESSION['company_id'] = $employee['company_id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['login_type'] = 'user';
            $_SESSION['login_time'] = time();

            // Last login güncelle
            $db->update('users', 
                ['last_login' => date('Y-m-d H:i:s')], 
                'id = :id', 
                [':id' => $user['id']]
            );

            unset($user['password_hash']);
            $user['employee'] = $employee;

            jsonResponse([
                'success' => 1,
                'message' => 'Giriş başarılı',
                'user' => $user,
                'redirect' => '/dashboard'
            ]);
            break;
    }

} catch (Exception $e) {
    error_log("Login API Error: " . $e->getMessage());
    errorResponse('Giriş işlemi başarısız', 500);
}
?>