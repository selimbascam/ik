<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../../includes/oauth-config.php';
require_once __DIR__ . '/../common/database.php';

header('Content-Type: application/json; charset=utf-8');

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle Apple Sign-In response
    $input = json_decode(file_get_contents('php://input'), 1);
    
    if (!$input || !isset($input['id_token'])) {
        http_response_code(400);
        echo json_encode(['error' => 'ID token gereklidir']);
        exit;
    }
    
    $idToken = $input['id_token'];
    $userType = $input['user_type'] ?? 'employee';
    
    // Verify Apple ID token
    $userData = OAuthHelper::verifyAppleToken($idToken);
    if (!$userData) {
        http_response_code(400);
        echo json_encode(['error' => 'Geçersiz Apple ID token']);
        exit;
    }
    
    // Apple sometimes sends user info in the first sign-in
    if (isset($input['user'])) {
        $userInfo = $input['user'];
        if (isset($userInfo['name'])) {
            $userData['given_name'] = $userInfo['name']['firstName'] ?? '';
            $userData['family_name'] = $userInfo['name']['lastName'] ?? '';
        }
    }
    
    // Create or update user
    $result = OAuthHelper::createOrUpdateOAuthUser($userData, 'apple', $userType);
    
    if (isset($result['error'])) {
        http_response_code(400);
        echo json_encode(['error' => $result['error']]);
        exit;
    }
    
    // Set session
    if ($result['user_type'] === 'company_admin') {
        $_SESSION['admin_id'] = $result['user']['id'];
        $_SESSION['company_id'] = $result['company_id'];
        $_SESSION['admin_email'] = $result['user']['email'];
        $_SESSION['admin_role'] = 'company_admin';
        $_SESSION['is_owner'] = $result['user']['is_owner'];
        $_SESSION['login_type'] = 'company';
        $_SESSION['auth_method'] = 'apple';
        
        echo json_encode([
            'success' => 1,
            'redirect' => '/company-dashboard',
            'user_type' => 'company_admin'
        ]);
    } else {
        $_SESSION['user_id'] = $result['user']['id'];
        $_SESSION['user_email'] = $result['user']['email'];
        $_SESSION['user_role'] = $result['user']['role'];
        $_SESSION['login_type'] = 'employee';
        $_SESSION['auth_method'] = 'apple';
        
        echo json_encode([
            'success' => 1,
            'redirect' => '/self-service',
            'user_type' => 'employee'
        ]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Sadece POST metodu desteklenir']);
}
?>