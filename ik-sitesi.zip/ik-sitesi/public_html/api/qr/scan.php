<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Sadece POST metodu desteklenir', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), 1);
    
    if (!$input) {
        errorResponse('Geçersiz JSON verisi');
    }

    // Required fields validation
    if (empty($input['locationCode']) || empty($input['activityType'])) {
        errorResponse('locationCode ve activityType alanları gereklidir');
    }

    $locationCode = $input['locationCode'];
    $activityType = $input['activityType'];
    $deviceInfo = $input['deviceInfo'] ?? [];

    // QR lokasyonunu doğrula
    $location = $db->selectOne(
        'qr_locations', 
        'location_code = :code AND is_active = 1', 
        [':code' => $locationCode]
    );

    if (!$location) {
        errorResponse('Geçersiz veya pasif QR kod', 400);
    }

    // Demo için sabit employee ID kullan (gerçek uygulamada kartlı okuyucu veya login olacak)
    $employeeId = 1;

    // Employee'ın varlığını kontrol et
    $employee = $db->selectOne('employees', 'id = :id AND is_active = 1', [':id' => $employeeId]);
    if (!$employee) {
        errorResponse('Personel bulunamadı', 404);
    }

    // Aktivite kaydını oluştur
    $activityData = [
        'employee_id' => $employeeId,
        'qr_location_id' => $location['id'],
        'activity_type' => $activityType,
        'timestamp' => date('Y-m-d H:i:s'),
        'device_info' => json_encode($deviceInfo, JSON_UNESCAPED_UNICODE),
        'notes' => $input['notes'] ?? ''
    ];

    $activityId = $db->insert('attendance_activities', $activityData);

    // Attendance record'u güncelle veya oluştur
    $today = date('Y-m-d');
    $attendanceRecord = $db->selectOne(
        'attendance_records', 
        'employee_id = :employee_id AND date = :date', 
        [':employee_id' => $employeeId, ':date' => $today]
    );

    if (!$attendanceRecord) {
        // Yeni attendance record oluştur
        $attendanceData = [
            'employee_id' => $employeeId,
            'date' => $today,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $attendanceRecordId = $db->insert('attendance_records', $attendanceData);
    } else {
        $attendanceRecordId = $attendanceRecord['id'];
    }

    // Activity type'a göre attendance record'u güncelle
    $updateData = ['updated_at' => date('Y-m-d H:i:s')];
    $currentTime = date('H:i:s');

    switch ($activityType) {
        case 'check_in':
            if (!$attendanceRecord || !$attendanceRecord['check_in']) {
                $updateData['check_in'] = $currentTime;
                $updateData['status'] = 'present';
            }
            break;
            
        case 'check_out':
            $updateData['check_out'] = $currentTime;
            
            // Çalışma süresini hesapla
            if ($attendanceRecord && $attendanceRecord['check_in']) {
                $checkIn = new DateTime($today . ' ' . $attendanceRecord['check_in']);
                $checkOut = new DateTime($today . ' ' . $currentTime);
                $workMinutes = $checkOut->diff($checkIn)->h * 60 + $checkOut->diff($checkIn)->i;
                
                // Mola sürelerini çıkar
                $breakDuration = $attendanceRecord['break_duration'] ?? 0;
                $workDuration = max(0, $workMinutes - $breakDuration);
                
                $updateData['work_duration'] = $workDuration;
                
                // Mesai hesapla (8 saat = 480 dakika üzeri)
                $standardWorkMinutes = 480;
                if ($workDuration > $standardWorkMinutes) {
                    $updateData['overtime_duration'] = $workDuration - $standardWorkMinutes;
                }
            }
            break;
            
        case 'tea_break':
        case 'lunch_break':
        case 'smoke_break':
            // Mola başlangıcı olarak kaydet - gerçek uygulamada mola süresi hesaplanır
            // Bu basit implementasyonda sadece aktiviteyi kaydet
            break;
    }

    if (!empty($updateData) && count($updateData) > 1) { // updated_at dışında başka alan varsa
        $db->update(
            'attendance_records', 
            $updateData, 
            'id = :id', 
            [':id' => $attendanceRecordId]
        );
    }

    // Başarılı yanıt
    $response = [
        'success' => 1,
        'message' => 'Aktivite başarıyla kaydedildi',
        'location' => $location['name'],
        'activity_type' => $activityType,
        'timestamp' => date('Y-m-d H:i:s'),
        'employee' => [
            'name' => $employee['first_name'] . ' ' . $employee['last_name'],
            'code' => $employee['employee_code']
        ]
    ];

    jsonResponse($response);

} catch (Exception $e) {
    error_log("QR Scan API Error: " . $e->getMessage());
    errorResponse('QR kod tarama başarısız: ' . $e->getMessage(), 500);
}
?>