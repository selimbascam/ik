<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            // QR lokasyonlarını getir - public API (kimlik doğrulama gerektirmez)
            $companyId = $_GET['company_id'] ?? 1; // Default company
            
            $locations = $db->select(
                'qr_locations', 
                'company_id = :company_id AND is_active = 1', 
                [':company_id' => $companyId],
                'name ASC'
            );
            
            jsonResponse($locations);
            break;

        case 'POST':
            // Yeni QR lokasyonu oluştur - admin/hr gerekli
            getAuth()->requireRole('admin');
            
            $input = json_decode(file_get_contents('php://input'), 1);
            
            if (!$input) {
                errorResponse('Geçersiz JSON verisi');
            }

            // Required fields validation
            $required = ['name', 'location_code', 'location_type'];
            foreach ($required as $field) {
                if (empty($input[$field])) {
                    errorResponse("$field alanı gereklidir");
                }
            }

            // Valid location types
            $validTypes = ['check_in', 'check_out', 'tea_break', 'lunch_break', 'smoke_break', 'other'];
            if (!in_array($input['location_type'], $validTypes)) {
                errorResponse('Geçersiz lokasyon tipi');
            }

            // Check if location code already exists
            if ($db->exists('qr_locations', 'location_code = :code', [':code' => $input['location_code']])) {
                errorResponse('Bu lokasyon kodu zaten kullanılıyor');
            }

            $locationData = [
                'company_id' => $_SESSION['company_id'] ?? 1,
                'name' => $input['name'],
                'location_code' => $input['location_code'],
                'location_type' => $input['location_type'],
                'description' => $input['description'] ?? '',
                'is_active' => $input['is_active'] ?? 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            $locationId = $db->insert('qr_locations', $locationData);
            
            $newLocation = $db->selectOne('qr_locations', 'id = :id', [':id' => $locationId]);
            
            jsonResponse($newLocation, 201);
            break;

        case 'OPTIONS':
            // CORS preflight
            http_response_code(200);
            break;

        default:
            errorResponse('Desteklenmeyen HTTP metodu', 405);
    }

} catch (Exception $e) {
    error_log("QR Locations API Error: " . $e->getMessage());
    errorResponse('Sunucu hatası', 500);
}
?>