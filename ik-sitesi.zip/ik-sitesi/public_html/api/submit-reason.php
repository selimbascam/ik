<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/employee-login.php');
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Only POST method allowed');
    }
    
    $employee_id = $_POST['employee_id'] ?? null;
    $shift_date = $_POST['shift_date'] ?? null;
    $reason_type = $_POST['reason_type'] ?? null;
    $reason_text = trim($_POST['reason_text'] ?? '');
    
    if (!$employee_id || !$shift_date || !$reason_type || !$reason_text) {
        throw new Exception('Tüm alanlar gereklidir');
    }
    
    // Verify employee owns this session
    if ($employee_id != $_SESSION['employee_id']) {
        throw new Exception('Yetkisiz erişim');
    }
    
    $db = new Database();
    $conn = $db->getConnection();
    
    // Insert reason
    $stmt = $conn->prepare("
        INSERT INTO attendance_reasons (employee_id, shift_date, reason_type, reason_text)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
        reason_text = VALUES(reason_text),
        requested_at = CURRENT_TIMESTAMP
    ");
    $stmt->execute([$employee_id, $shift_date, $reason_type, $reason_text]);
    
    // Log the reason submission
    error_log("Reason submitted - Employee: $employee_id, Date: $shift_date, Type: $reason_type, Reason: $reason_text");
    
    // Redirect back to dashboard with success message
    header('Location: ../dashboard/employee-dashboard.php?reason_submitted=1');
    exit;
    
} catch (Exception $e) {
    // Redirect back with error message
    header('Location: ../dashboard/employee-dashboard.php?error=' . urlencode($e->getMessage()));
    exit;
}
?>