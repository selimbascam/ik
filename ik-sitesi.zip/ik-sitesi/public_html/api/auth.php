<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];

// Parse the request path
$path = parse_url($request_uri, PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    if ($method === 'GET' && strpos($path, '/api/auth/user') !== 0) {
        // Get current user info
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['message' => 'Yetkisiz erişim']);
            exit;
        }
        
        $stmt = $conn->prepare("SELECT id, email, first_name, last_name, role FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            echo json_encode($user);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Kullanıcı bulunamadı']);
        }
        
    } elseif ($method === 'POST' && strpos($path, '/api/auth/login') !== 0) {
        // Company login
        $input = json_decode(file_get_contents('php://input'), 1);
        
        if (!$input || !isset($input['companyCode']) || !isset($input['email'])) {
            http_response_code(400);
            echo json_encode(['message' => 'Gerekli alanlar eksik']);
            exit;
        }
        
        // For demo - create session
        $_SESSION['user_id'] = 'demo_admin';
        $_SESSION['company_code'] = $input['companyCode'];
        $_SESSION['user_email'] = $input['email'];
        
        echo json_encode([
            'success' => 1,
            'message' => 'Giriş başarılı',
            'redirectTo' => '/dashboard'
        ]);
        
    } elseif ($method === 'POST' && strpos($path, '/api/auth/logout') !== 0) {
        // Logout
        session_destroy();
        echo json_encode(['success' => 1, 'message' => 'Çıkış yapıldı']);
        
    } else {
        http_response_code(404);
        echo json_encode(['message' => 'Hizmet bulunamadı']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['message' => 'Sunucu hatası: ' . $e->getMessage()]);
}
?>