<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    if ($method === 'GET' && strpos($path, '/api/dashboard/stats') !== 0) {
        // Get dashboard statistics
        $stats = [];
        
        // Total employees
        $stmt = $conn->query("SELECT COUNT(*) as count FROM employees WHERE status = 'active'");
        $stats['totalEmployees'] = $stmt->fetch()['count'];
        
        // Present today
        $today = date('Y-m-d');
        $stmt = $conn->prepare("SELECT COUNT(DISTINCT employee_id) as count FROM attendance_records WHERE DATE(check_in) = ? AND check_out IS NULL");
        $stmt->execute([$today]);
        $stats['presentToday'] = $stmt->fetch()['count'];
        
        // Pending leave requests
        $stmt = $conn->query("SELECT COUNT(*) as count FROM leave_requests WHERE status = 'pending'");
        $stats['leaveRequests'] = $stmt->fetch()['count'];
        
        // Overtime hours this month
        $firstDayOfMonth = date('Y-m-01');
        $stmt = $conn->prepare("SELECT COALESCE(SUM(overtime_hours), 0) as total FROM attendance_records WHERE DATE(check_in) >= ?");
        $stmt->execute([$firstDayOfMonth]);
        $stats['overtimeHours'] = (float)$stmt->fetch()['total'];
        
        echo json_encode($stats);
        
    } else {
        http_response_code(404);
        echo json_encode(['message' => 'Endpoint not found']);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['message' => 'Server error: ' . $e->getMessage()]);
}
?>