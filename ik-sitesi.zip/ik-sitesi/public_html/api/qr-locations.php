<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
        exit;
    }

    $companyId = $_GET['company_id'] ?? 1;
    $locations = [];
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Get all active QR locations for the company
        $stmt = $conn->prepare("
            SELECT 
                id,
                name,
                location_code,
                location_type,
                description,
                latitude,
                longitude,
                created_at
            FROM qr_locations 
            WHERE company_id = ? 
            ORDER BY name ASC
        ");
        
        $stmt->execute([$companyId]);
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Convert latitude/longitude to float if they exist
        foreach ($locations as &$location) {
            if ($location['latitude']) {
                $location['latitude'] = floatval($location['latitude']);
            }
            if ($location['longitude']) {
                $location['longitude'] = floatval($location['longitude']);
            }
        }
        
    } catch (Exception $dbError) {
        // Database not available - return demo locations
        error_log("QR Locations API - Database error: " . $dbError->getMessage());
        $locations = [
            [
                'id' => 1,
                'name' => 'Ana Giriş',
                'location_code' => 'DEMO_001',
                'location_type' => 'entrance',
                'description' => 'Ana giriş kapısı',
                'latitude' => 41.0082,
                'longitude' => 28.9784,
                'created_at' => date('Y-m-d H:i:s')
            ],
            [
                'id' => 2,
                'name' => 'Ofis Katı',
                'location_code' => 'DEMO_002',
                'location_type' => 'office',
                'description' => 'Çalışma alanı',
                'latitude' => 41.0085,
                'longitude' => 28.9787,
                'created_at' => date('Y-m-d H:i:s')
            ],
            [
                'id' => 3,
                'name' => 'Yemekhane',
                'location_code' => 'DEMO_003',
                'location_type' => 'dining',
                'description' => 'Personel yemekhanesi',
                'latitude' => 41.0080,
                'longitude' => 28.9780,
                'created_at' => date('Y-m-d H:i:s')
            ],
            [
                'id' => 4,
                'name' => 'Sigara Alanı',
                'location_code' => 'DEMO_004',
                'location_type' => 'smoking',
                'description' => 'Sigara içme alanı',
                'latitude' => 41.0078,
                'longitude' => 28.9782,
                'created_at' => date('Y-m-d H:i:s')
            ]
        ];
    }
    
    echo json_encode($locations);
    
} catch (Exception $e) {
    error_log("QR Locations API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}
?>