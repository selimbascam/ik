<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    echo json_encode(['success' => 0, 'error' => 'Not logged in']);
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Only POST method allowed');
    }
    
    $input = json_decode(file_get_contents('php://input'), 1);
    if (!$input) {
        $input = $_POST; // Fallback to form data
    }
    
    $employee_id = $_SESSION['employee_id'];
    $activity_type = $input['activity_type'] ?? null;
    $qr_location_id = $input['qr_location_id'] ?? null;
    $latitude = $input['latitude'] ?? null;
    $longitude = $input['longitude'] ?? null;
    $reason_text = $input['reason_text'] ?? null;
    
    if (!$activity_type || !$qr_location_id) {
        throw new Exception('Activity type and location are required');
    }
    
    $db = new Database();
    $conn = $db->getConnection();
    
    // Start transaction
    $conn->beginTransaction();
    
    // Get employee company_id for foreign key safety
    $stmt = $conn->prepare("SELECT company_id FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        throw new Exception('Employee not found');
    }
    
    $company_id = $employee['company_id'];
    
    // Check if company exists (Deepseek validation)
    if (!$company_id) {
        // Find first available company and assign
        $stmt = $conn->prepare("SELECT id FROM companies LIMIT 1");
        $stmt->execute();
        $defaultCompany = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$defaultCompany) {
            // Create a default company
            $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute(['SZB Default Company', 'admin@szb.com.tr', '555-0123', 'Default company']);
            $company_id = $conn->lastInsertId();
        } else {
            $company_id = $defaultCompany['id'];
        }
        
        // Update employee record
        $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
        $stmt->execute([$company_id, $employee_id]);
    }
    
    // Double check company exists
    $stmt = $conn->prepare("SELECT id FROM companies WHERE id = ?");
    $stmt->execute([$company_id]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        throw new Exception('Company verification failed');
    }
    
    // Check if QR location exists and belongs to the same company
    if ($qr_location_id) {
        $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE id = ? AND company_id = ?");
        $stmt->execute([$qr_location_id, $company_id]);
        $qr_location = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$qr_location) {
            throw new Exception('QR location not found or does not belong to your company');
        }
    }
    
    // Get today's shift
    $today = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT 
            es.*,
            st.name as shift_name,
            st.start_time,
            st.end_time,
            st.break_duration
        FROM employee_shifts es
        JOIN shift_templates st ON es.shift_template_id = st.id
        WHERE es.employee_id = ? AND es.shift_date = ?
    ");
    $stmt->execute([$employee_id, $today]);
    $shift = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$shift) {
        throw new Exception('Bugün için atanmış vardiya bulunamadı');
    }
    
    $currentTime = date('H:i:s');
    $currentDateTime = date('Y-m-d H:i:s');
    $tolerance = 15; // 15 minutes tolerance
    
    // Determine new status and timing validation
    $newStatus = 'scheduled';
    $isLate = 0;
    $isEarlyLeave = 0;
    $actualTime = null;
    
    switch ($activity_type) {
        case 'work_in':
            $newStatus = 'checked_in';
            $actualTime = $currentTime;
            
            // Check if late
            $lateCutoff = date('H:i:s', strtotime($shift['start_time'] . ' +' . $tolerance . ' minutes'));
            if ($currentTime > $lateCutoff) {
                $isLate = 1;
                $newStatus = 'late';
            }
            break;
            
        case 'work_out':
            $newStatus = 'checked_out';
            
            // Check if early leave
            $earlyCutoff = date('H:i:s', strtotime($shift['end_time'] . ' -' . $tolerance . ' minutes'));
            if ($currentTime < $earlyCutoff) {
                $isEarlyLeave = 1;
            }
            break;
            
        case 'break_start':
            $newStatus = 'on_break';
            break;
            
        case 'break_end':
            $newStatus = 'checked_in';
            break;
            
        case 'meal_start':
            $newStatus = 'on_break';
            break;
            
        case 'meal_end':
            $newStatus = 'checked_in';
            break;
    }
    
    // Update shift status
    $updateFields = ['status = ?'];
    $updateValues = [$newStatus];
    
    if ($activity_type === 'work_in') {
        $updateFields[] = 'actual_start_time = ?';
        $updateValues[] = $actualTime;
    } elseif ($activity_type === 'work_out') {
        $updateFields[] = 'actual_end_time = ?';
        $updateValues[] = $currentTime;
        
        // Calculate worked minutes
        if ($shift['actual_start_time']) {
            $startTime = new DateTime($today . ' ' . $shift['actual_start_time']);
            $endTime = new DateTime($today . ' ' . $currentTime);
            $workedMinutes = $endTime->diff($startTime)->h * 60 + $endTime->diff($startTime)->i;
            
            // Subtract break duration
            $netWorkedMinutes = max(0, $workedMinutes - $shift['break_duration']);
            
            $updateFields[] = 'worked_minutes = ?';
            $updateValues[] = $netWorkedMinutes;
            
            // Check for overtime (more than 8 hours)
            $overtimeMinutes = max(0, $netWorkedMinutes - 480);
            if ($overtimeMinutes > 0) {
                $updateFields[] = 'overtime_minutes = ?';
                $updateValues[] = $overtimeMinutes;
            }
            
            $updateFields[] = 'is_complete = 1';
        }
    }
    
    // Handle reasons for late/early
    if ($isLate && $reason_text) {
        $updateFields[] = 'late_reason = ?';
        $updateValues[] = $reason_text;
    }
    
    if ($isEarlyLeave && $reason_text) {
        $updateFields[] = 'early_leave_reason = ?';
        $updateValues[] = $reason_text;
    }
    
    $updateValues[] = $shift['id'];
    
    $stmt = $conn->prepare("
        UPDATE employee_shifts 
        SET " . implode(', ', $updateFields) . "
        WHERE id = ?
    ");
    $stmt->execute($updateValues);
    
    // Insert attendance record with company_id (already retrieved above)
    $stmt = $conn->prepare("
        INSERT INTO attendance_records (
            company_id, employee_id, qr_location_id, activity_type, check_in_time, 
            date, latitude, longitude, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $company_id,
        $employee_id,
        $qr_location_id,
        $activity_type,
        $currentDateTime,
        date('Y-m-d'),
        $latitude,
        $longitude,
        $reason_text ?? 'QR kod ile kayıt',
        $currentDateTime
    ]);
    
    // Log reason if provided
    if (($isLate || $isEarlyLeave) && $reason_text) {
        $reasonType = $isLate ? 'late_arrival' : 'early_leave';
        $stmt = $conn->prepare("
            INSERT INTO attendance_reasons (employee_id, shift_date, reason_type, reason_text, status)
            VALUES (?, ?, ?, ?, 'approved')
        ");
        $stmt->execute([$employee_id, $today, $reasonType, $reason_text]);
    }
    
    // Commit transaction
    $conn->commit();
    
    // Clear QR scan data from session
    unset($_SESSION['qr_scan_data']);
    
    // Return success response
    echo json_encode([
        'success' => 1,
        'message' => 'Attendance recorded successfully',
        'activity_type' => $activity_type,
        'status' => $newStatus,
        'worked_minutes' => $netWorkedMinutes ?? 0,
        'overtime_minutes' => $overtimeMinutes ?? 0,
        'is_late' => $isLate,
        'is_early_leave' => $isEarlyLeave
    ]);
    
} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
    }
    
    echo json_encode([
        'success' => 0,
        'error' => $e->getMessage()
    ]);
}
?>