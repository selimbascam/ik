<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    errorResponse('Sadece GET metodu desteklenir', 405);
}

try {
    $action = $_GET['action'] ?? '';
    $employeeId = $_GET['employee_id'] ?? 1; // Demo için sabit employee ID
    $date = $_GET['date'] ?? date('Y-m-d');

    switch ($action) {
        case 'attendance':
            // Günlük devam kaydını getir
            $attendance = $db->selectOne(
                'attendance_records', 
                'employee_id = :employee_id AND date = :date', 
                [':employee_id' => $employeeId, ':date' => $date]
            );

            if (!$attendance) {
                $attendance = [
                    'employee_id' => $employeeId,
                    'date' => $date,
                    'check_in' => null,
                    'check_out' => null,
                    'break_duration' => 0,
                    'work_duration' => 0,
                    'overtime_duration' => 0,
                    'status' => 'absent'
                ];
            }

            jsonResponse($attendance);
            break;

        case 'activities':
            // Günlük aktiviteleri getir
            $sql = "
                SELECT aa.*, ql.name as location_name, ql.location_type
                FROM attendance_activities aa
                JOIN qr_locations ql ON aa.qr_location_id = ql.id
                WHERE aa.employee_id = :employee_id 
                AND DATE(aa.timestamp) = :date
                ORDER BY aa.timestamp DESC
            ";
            
            $stmt = $db->query($sql, [
                ':employee_id' => $employeeId,
                ':date' => $date
            ]);
            
            $activities = $stmt->fetchAll();
            
            jsonResponse($activities);
            break;

        case 'break-entitlements':
            // Mola haklarını getir
            $entitlements = $db->select(
                'employee_break_entitlements', 
                'employee_id = :employee_id', 
                [':employee_id' => $employeeId]
            );

            // Bugünkü tarihi kontrol et ve gerekirse sıfırla
            $today = date('Y-m-d');
            foreach ($entitlements as &$entitlement) {
                if ($entitlement['last_reset_date'] !== $today) {
                    $db->update(
                        'employee_break_entitlements',
                        [
                            'used_minutes_today' => 0,
                            'last_reset_date' => $today
                        ],
                        'id = :id',
                        [':id' => $entitlement['id']]
                    );
                    $entitlement['used_minutes_today'] = 0;
                    $entitlement['last_reset_date'] = $today;
                }
                
                // Kalan süreyi hesapla
                $entitlement['remaining_minutes'] = max(0, 
                    $entitlement['daily_limit_minutes'] - $entitlement['used_minutes_today']
                );
            }

            jsonResponse($entitlements);
            break;

        case 'weekly-summary':
            // Haftalık özet
            $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('monday this week'));
            $endDate = $_GET['end_date'] ?? date('Y-m-d', strtotime('sunday this week'));
            
            $sql = "
                SELECT 
                    date,
                    check_in,
                    check_out,
                    work_duration,
                    overtime_duration,
                    status
                FROM attendance_records 
                WHERE employee_id = :employee_id 
                AND date BETWEEN :start_date AND :end_date
                ORDER BY date ASC
            ";
            
            $stmt = $db->query($sql, [
                ':employee_id' => $employeeId,
                ':start_date' => $startDate,
                ':end_date' => $endDate
            ]);
            
            $weeklyData = $stmt->fetchAll();
            
            // Haftalık istatistikler
            $totalWorkMinutes = 0;
            $totalOvertimeMinutes = 0;
            $presentDays = 0;
            
            foreach ($weeklyData as $day) {
                if ($day['status'] === 'present') {
                    $presentDays++;
                    $totalWorkMinutes += $day['work_duration'] ?? 0;
                    $totalOvertimeMinutes += $day['overtime_duration'] ?? 0;
                }
            }
            
            $summary = [
                'period' => [
                    'start_date' => $startDate,
                    'end_date' => $endDate
                ],
                'daily_records' => $weeklyData,
                'statistics' => [
                    'present_days' => $presentDays,
                    'total_work_hours' => round($totalWorkMinutes / 60, 2),
                    'total_overtime_hours' => round($totalOvertimeMinutes / 60, 2),
                    'average_daily_hours' => $presentDays > 0 ? round($totalWorkMinutes / $presentDays / 60, 2) : 0
                ]
            ];
            
            jsonResponse($summary);
            break;

        case 'employee-info':
            // Personel bilgilerini getir
            $sql = "
                SELECT 
                    e.*,
                    d.name as department_name,
                    c.company_name
                FROM employees e
                LEFT JOIN departments d ON e.department_id = d.id
                LEFT JOIN companies c ON e.company_id = c.id
                WHERE e.id = :employee_id
            ";
            
            $stmt = $db->query($sql, [':employee_id' => $employeeId]);
            $employee = $stmt->fetch();
            
            if (!$employee) {
                errorResponse('Personel bulunamadı', 404);
            }

            // Hassas bilgileri kaldır
            unset($employee['salary']);
            
            jsonResponse($employee);
            break;

        default:
            errorResponse('Geçersiz action parametresi');
    }

} catch (Exception $e) {
    error_log("Employee Self-Service API Error: " . $e->getMessage());
    errorResponse('Sunucu hatası: ' . $e->getMessage(), 500);
}
?>