<?php
// Demo API for testing garnishment module
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'stats':
        echo json_encode([
            'success' => 1,
            'data' => [
                'active_cases' => 3,
                'total_debt' => '28500.00',
                'monthly_deduction' => '4750.00',
                'employees_with_garnishment' => 3
            ]
        ]);
        break;
        
    case 'list':
        echo json_encode([
            'success' => 1,
            'data' => [
                [
                    'id' => 1,
                    'employee_name' => 'Ali Veli',
                    'court_name' => 'İstanbul 1. İcra Müdürlüğü',
                    'case_number' => '2024/1234',
                    'debt_amount' => '15000.00',
                    'remaining_debt' => '12000.00',
                    'current_salary' => '8000.00',
                    'deduction_rate' => '25',
                    'monthly_deduction' => '2000.00',
                    'status' => 'active',
                    'start_date' => '2024-01-15'
                ],
                [
                    'id' => 2,
                    'employee_name' => 'Ayşe Kaya',
                    'court_name' => 'İstanbul 3. İcra Müdürlüğü',
                    'case_number' => '2024/5678',
                    'debt_amount' => '8500.00',
                    'remaining_debt' => '6500.00',
                    'current_salary' => '6500.00',
                    'deduction_rate' => '15',
                    'monthly_deduction' => '975.00',
                    'status' => 'active',
                    'start_date' => '2024-02-01'
                ],
                [
                    'id' => 3,
                    'employee_name' => 'Mehmet Özkan',
                    'court_name' => 'Ankara 2. İcra Müdürlüğü',
                    'case_number' => '2024/9876',
                    'debt_amount' => '12000.00',
                    'remaining_debt' => '10000.00',
                    'current_salary' => '7000.00',
                    'deduction_rate' => '25',
                    'monthly_deduction' => '1750.00',
                    'status' => 'active',
                    'start_date' => '2024-03-01'
                ]
            ]
        ]);
        break;
        
    case 'employees':
        echo json_encode([
            'success' => 1,
            'data' => [
                ['id' => 4, 'first_name' => 'Fatma', 'last_name' => 'Demir', 'salary' => '9000.00'],
                ['id' => 5, 'first_name' => 'Can', 'last_name' => 'Yılmaz', 'salary' => '8500.00'],
                ['id' => 6, 'first_name' => 'Zeynep', 'last_name' => 'Ak', 'salary' => '7500.00'],
                ['id' => 7, 'first_name' => 'Emre', 'last_name' => 'Şahin', 'salary' => '10000.00']
            ]
        ]);
        break;
        
    case 'create':
        // Simulate creating new garnishment
        $input = json_decode(file_get_contents('php://input'), 1);
        
        // Validate deduction rate
        if (isset($input['deduction_rate']) && $input['deduction_rate'] > 25) {
            echo json_encode([
                'success' => 0,
                'error' => 'Kesinti oranı %25\'i geçemez!'
            ]);
            break;
        }
        
        // Simulate success
        echo json_encode([
            'success' => 1,
            'message' => 'İcra dosyası başarıyla kaydedildi',
            'garnishment_id' => rand(100, 999)
        ]);
        break;
        
    case 'payments':
        $garnishmentId = $_GET['garnishment_id'] ?? 1;
        echo json_encode([
            'success' => 1,
            'data' => [
                [
                    'id' => 1,
                    'payment_amount' => '2000.00',
                    'formatted_date' => '01.02.2024',
                    'payment_method' => 'salary_deduction'
                ],
                [
                    'id' => 2,
                    'payment_amount' => '1000.00',
                    'formatted_date' => '15.02.2024',
                    'payment_method' => 'manual'
                ]
            ]
        ]);
        break;
        
    default:
        http_response_code(400);
        echo json_encode(['success' => 0, 'error' => 'Invalid action']);
        break;
}
?>