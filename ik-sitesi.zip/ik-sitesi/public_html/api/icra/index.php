<?php
require_once '../../config/config.php';
require_once '../../includes/auth.php';

// Enable CORS and set JSON header
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Start session and check authentication
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as company admin
if (!isset($_SESSION['admin_id']) || $_SESSION['user_type'] !== 'company') {
    http_response_code(401);
    echo json_encode(['success' => 0, 'error' => 'Unauthorized']);
    exit();
}

$companyId = $_SESSION['company_id'];
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            handleGetRequest($action, $companyId);
            break;
        case 'POST':
            handlePostRequest($action, $companyId);
            break;
        case 'PUT':
            handlePutRequest($action, $companyId);
            break;
        case 'DELETE':
            handleDeleteRequest($action, $companyId);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => 0, 'error' => 'Method not allowed']);
            break;
    }
} catch (Exception $e) {
    error_log("İcra API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => 0, 'error' => 'Server error']);
}

function handleGetRequest($action, $companyId) {
    global $pdo;
    
    switch ($action) {
        case 'list':
            // Get all garnishments for company
            $stmt = $pdo->prepare("
                SELECT 
                    g.*,
                    CONCAT(e.first_name, ' ', e.last_name) as employee_name,
                    e.salary as current_salary
                FROM garnishments g
                JOIN employees e ON g.employee_id = e.id
                WHERE e.company_id = ?
                ORDER BY g.created_at DESC
            ");
            $stmt->execute([$companyId]);
            $garnishments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => 1, 'data' => $garnishments]);
            break;
            
        case 'stats':
            // Get garnishment statistics
            $stmt = $pdo->prepare("
                SELECT 
                    COUNT(CASE WHEN g.status = 'active' THEN 1 END) as active_cases,
                    SUM(CASE WHEN g.status = 'active' THEN g.remaining_debt ELSE 0 END) as total_debt,
                    SUM(CASE WHEN g.status = 'active' THEN g.monthly_deduction ELSE 0 END) as monthly_deduction,
                    COUNT(DISTINCT CASE WHEN g.status = 'active' THEN g.employee_id END) as employees_with_garnishment
                FROM garnishments g
                JOIN employees e ON g.employee_id = e.id
                WHERE e.company_id = ?
            ");
            $stmt->execute([$companyId]);
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => 1, 'data' => $stats]);
            break;
            
        case 'employees':
            // Get employees without active garnishments
            $stmt = $pdo->prepare("
                SELECT e.id, e.first_name, e.last_name, e.salary
                FROM employees e
                WHERE e.company_id = ? 
                AND e.is_active = 1
                AND NOT EXISTS (
                    SELECT 1 FROM garnishments g 
                    WHERE g.employee_id = e.id AND g.status = 'active'
                )
                ORDER BY e.first_name, e.last_name
            ");
            $stmt->execute([$companyId]);
            $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => 1, 'data' => $employees]);
            break;
            
        case 'payments':
            $garnishmentId = $_GET['garnishment_id'] ?? null;
            if (!$garnishmentId) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'Garnishment ID required']);
                return;
            }
            
            // Get payment history
            $stmt = $pdo->prepare("
                SELECT gp.*, DATE_FORMAT(gp.payment_date, '%d.%m.%Y') as formatted_date
                FROM garnishment_payments gp
                JOIN garnishments g ON gp.garnishment_id = g.id
                JOIN employees e ON g.employee_id = e.id
                WHERE gp.garnishment_id = ? AND e.company_id = ?
                ORDER BY gp.payment_date DESC
            ");
            $stmt->execute([$garnishmentId, $companyId]);
            $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => 1, 'data' => $payments]);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => 0, 'error' => 'Invalid action']);
            break;
    }
}

function handlePostRequest($action, $companyId) {
    global $pdo;
    $input = json_decode(file_get_contents('php://input'), 1);
    
    switch ($action) {
        case 'create':
            // Create new garnishment
            $requiredFields = ['employee_id', 'court_name', 'case_number', 'debt_amount', 'deduction_rate', 'start_date'];
            
            foreach ($requiredFields as $field) {
                if (!isset($input[$field]) || empty($input[$field])) {
                    http_response_code(400);
                    echo json_encode(['success' => 0, 'error' => "Missing required field: $field"]);
                    return;
                }
            }
            
            // Validate deduction rate (maximum 25%)
            if ($input['deduction_rate'] > 25) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'Kesinti oranı %25\'i geçemez!']);
                return;
            }
            
            // Check if employee belongs to company
            $stmt = $pdo->prepare("SELECT id, salary FROM employees WHERE id = ? AND company_id = ? AND is_active = 1");
            $stmt->execute([$input['employee_id'], $companyId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$employee) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'Geçersiz personel seçimi']);
                return;
            }
            
            // Check if employee already has active garnishment
            $stmt = $pdo->prepare("SELECT id FROM garnishments WHERE employee_id = ? AND status = 'active'");
            $stmt->execute([$input['employee_id']]);
            if ($stmt->fetch()) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'Bu personelin zaten aktif bir icra dosyası bulunmaktadır']);
                return;
            }
            
            // Calculate monthly deduction based on current salary
            $monthlySalary = $employee['salary'];
            $deductionRate = $input['deduction_rate'] / 100;
            $monthlyDeduction = $monthlySalary * $deductionRate;
            
            // Ensure we don't exceed legal limits (25% of net salary)
            $maxDeduction = $monthlySalary * 0.25;
            if ($monthlyDeduction > $maxDeduction) {
                $monthlyDeduction = $maxDeduction;
            }
            
            // Insert garnishment
            $stmt = $pdo->prepare("
                INSERT INTO garnishments (
                    employee_id, court_name, case_number, debt_amount, 
                    remaining_debt, deduction_rate, monthly_deduction, 
                    start_date, description, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())
            ");
            
            $stmt->execute([
                $input['employee_id'],
                $input['court_name'],
                $input['case_number'],
                $input['debt_amount'],
                $input['debt_amount'], // Initially remaining debt equals total debt
                $input['deduction_rate'],
                $monthlyDeduction,
                $input['start_date'],
                $input['description'] ?? null
            ]);
            
            echo json_encode([
                'success' => 1, 
                'message' => 'İcra dosyası başarıyla kaydedildi',
                'garnishment_id' => $pdo->lastInsertId()
            ]);
            break;
            
        case 'calculate':
            // Calculate all deductions for current month
            $stmt = $pdo->prepare("
                UPDATE garnishments g
                JOIN employees e ON g.employee_id = e.id
                SET g.monthly_deduction = LEAST(
                    e.salary * (g.deduction_rate / 100),
                    e.salary * 0.25
                )
                WHERE e.company_id = ? AND g.status = 'active'
            ");
            $stmt->execute([$companyId]);
            
            echo json_encode([
                'success' => 1, 
                'message' => 'Tüm kesintiler yasal limitler çerçevesinde yeniden hesaplandı'
            ]);
            break;
            
        case 'add-payment':
            // Add payment record
            $requiredFields = ['garnishment_id', 'payment_amount', 'payment_date'];
            
            foreach ($requiredFields as $field) {
                if (!isset($input[$field]) || empty($input[$field])) {
                    http_response_code(400);
                    echo json_encode(['success' => 0, 'error' => "Missing required field: $field"]);
                    return;
                }
            }
            
            // Verify garnishment belongs to company
            $stmt = $pdo->prepare("
                SELECT g.id, g.remaining_debt 
                FROM garnishments g
                JOIN employees e ON g.employee_id = e.id
                WHERE g.id = ? AND e.company_id = ? AND g.status = 'active'
            ");
            $stmt->execute([$input['garnishment_id'], $companyId]);
            $garnishment = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$garnishment) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'Geçersiz icra dosyası']);
                return;
            }
            
            $pdo->beginTransaction();
            
            try {
                // Add payment record
                $stmt = $pdo->prepare("
                    INSERT INTO garnishment_payments (
                        garnishment_id, payment_amount, payment_date, created_at
                    ) VALUES (?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $input['garnishment_id'],
                    $input['payment_amount'],
                    $input['payment_date']
                ]);
                
                // Update remaining debt
                $newRemainingDebt = max(0, $garnishment['remaining_debt'] - $input['payment_amount']);
                $newStatus = $newRemainingDebt == 0 ? 'completed' : 'active';
                
                $stmt = $pdo->prepare("
                    UPDATE garnishments 
                    SET remaining_debt = ?, status = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([$newRemainingDebt, $newStatus, $input['garnishment_id']]);
                
                $pdo->commit();
                
                echo json_encode([
                    'success' => 1, 
                    'message' => 'Ödeme kaydı başarıyla eklendi'
                ]);
                
            } catch (Exception $e) {
                $pdo->rollback();
                throw $e;
            }
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => 0, 'error' => 'Invalid action']);
            break;
    }
}

function handlePutRequest($action, $companyId) {
    global $pdo;
    $input = json_decode(file_get_contents('php://input'), 1);
    
    switch ($action) {
        case 'update':
            $garnishmentId = $input['id'] ?? null;
            if (!$garnishmentId) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'Garnishment ID required']);
                return;
            }
            
            // Verify garnishment belongs to company
            $stmt = $pdo->prepare("
                SELECT g.id 
                FROM garnishments g
                JOIN employees e ON g.employee_id = e.id
                WHERE g.id = ? AND e.company_id = ?
            ");
            $stmt->execute([$garnishmentId, $companyId]);
            
            if (!$stmt->fetch()) {
                http_response_code(403);
                echo json_encode(['success' => 0, 'error' => 'Unauthorized']);
                return;
            }
            
            // Update garnishment
            $updateFields = [];
            $values = [];
            
            $allowedFields = ['court_name', 'case_number', 'debt_amount', 'deduction_rate', 'description'];
            foreach ($allowedFields as $field) {
                if (isset($input[$field])) {
                    $updateFields[] = "$field = ?";
                    $values[] = $input[$field];
                }
            }
            
            if (empty($updateFields)) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'No fields to update']);
                return;
            }
            
            $values[] = $garnishmentId;
            
            $stmt = $pdo->prepare("
                UPDATE garnishments 
                SET " . implode(', ', $updateFields) . ", updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute($values);
            
            echo json_encode(['success' => 1, 'message' => 'İcra dosyası güncellendi']);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => 0, 'error' => 'Invalid action']);
            break;
    }
}

function handleDeleteRequest($action, $companyId) {
    global $pdo;
    
    switch ($action) {
        case 'close':
            $garnishmentId = $_GET['id'] ?? null;
            if (!$garnishmentId) {
                http_response_code(400);
                echo json_encode(['success' => 0, 'error' => 'Garnishment ID required']);
                return;
            }
            
            // Verify and close garnishment
            $stmt = $pdo->prepare("
                UPDATE garnishments g
                JOIN employees e ON g.employee_id = e.id
                SET g.status = 'closed', g.updated_at = NOW()
                WHERE g.id = ? AND e.company_id = ? AND g.status = 'active'
            ");
            $stmt->execute([$garnishmentId, $companyId]);
            
            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(['success' => 0, 'error' => 'İcra dosyası bulunamadı']);
                return;
            }
            
            echo json_encode(['success' => 1, 'message' => 'İcra dosyası kapatıldı']);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['success' => 0, 'error' => 'Invalid action']);
            break;
    }
}
?>