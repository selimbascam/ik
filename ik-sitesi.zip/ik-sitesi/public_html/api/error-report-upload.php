<?php
/**
 * SZB İK Takip - Hata Raporu Yükleme API
 * JSON formatında hata raporu kabul eder ve sisteme kaydeder
 */

header('Content-Type: application/json; charset=utf-8');
require_once '../includes/config.php';

// Sadece POST isteklerini kabul et
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Sadece POST istekleri kabul edilir']);
    exit;
}

try {
    // JSON verisini al
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Geçersiz JSON formatı: ' . json_last_error_msg());
    }
    
    // Veri yapısını kontrol et
    if (!isset($data['errors']) || !is_array($data['errors'])) {
        throw new Exception('Hata listesi bulunamadı veya geçersiz format');
    }
    
    $processed = 0;
    $failed = 0;
    $errors = [];
    
    // Her hatayı sisteme kaydet
    foreach ($data['errors'] as $errorData) {
        try {
            // Gerekli alanları kontrol et
            if (!isset($errorData['error_message'])) {
                $errors[] = 'Hata mesajı eksik: ' . json_encode($errorData);
                $failed++;
                continue;
            }
            
            // Hata verisini normalize et
            $errorInfo = [
                'message' => $errorData['error_message'],
                'context' => [
                    'imported_from' => 'api_upload',
                    'upload_time' => date('Y-m-d H:i:s'),
                    'original_data' => $errorData
                ],
                'severity' => $errorData['severity'] ?? 'medium'
            ];
            
            // Ek bilgileri context'e ekle
            if (isset($errorData['error_context'])) {
                $originalContext = is_string($errorData['error_context']) ? 
                    json_decode($errorData['error_context'], true) : 
                    $errorData['error_context'];
                
                if (is_array($originalContext)) {
                    $errorInfo['context'] = array_merge($errorInfo['context'], $originalContext);
                }
            }
            
            // Sisteme kaydet
            $errorId = ErrorLogger::logError(
                $errorInfo['message'],
                $errorInfo['context'],
                $errorInfo['severity']
            );
            
            if ($errorId) {
                $processed++;
                
                // Eğer çözüm bilgisi varsa güncelle
                if (isset($errorData['status']) && $errorData['status'] === 'solved' && 
                    isset($errorData['solution_notes'])) {
                    ErrorLogger::markAsSolved(
                        $errorId, 
                        $errorData['solution_notes'],
                        $errorData['solved_by'] ?? 'API Upload'
                    );
                }
            } else {
                $failed++;
                $errors[] = 'Kayıt başarısız: ' . $errorData['error_message'];
            }
            
        } catch (Exception $e) {
            $failed++;
            $errors[] = 'İşleme hatası: ' . $e->getMessage();
        }
    }
    
    // Sonucu döndür
    $response = [
        'success' => true,
        'processed' => $processed,
        'failed' => $failed,
        'total' => count($data['errors']),
        'message' => "{$processed} hata başarıyla kaydedildi, {$failed} hata işlenemedi"
    ];
    
    if (!empty($errors)) {
        $response['errors'] = $errors;
    }
    
    // İstatistik bilgisi varsa ekle
    if (isset($data['statistics'])) {
        $response['uploaded_statistics'] = $data['statistics'];
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'message' => 'Hata raporu yüklenirken bir sorun oluştu'
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    // Bu hatayı da kaydet
    logError("Error report upload failed: " . $e->getMessage(), [
        'input_size' => strlen($input ?? ''),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ], 'medium');
}
?>