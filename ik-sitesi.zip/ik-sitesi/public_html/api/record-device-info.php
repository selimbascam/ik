<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Set JSON response headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle OPTIONS request for CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Only POST method allowed');
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), 1);
    if (!$input) {
        $input = $_POST; // Fallback to form data
    }
    
    $db = new Database();
    $conn = $db->getConnection();
    
    // Extract device information
    $employee_id = $input['employee_id'] ?? null;
    $company_id = $input['company_id'] ?? $_SESSION['company_id'] ?? null;
    $qr_location_id = $input['qr_location_id'] ?? null;
    $action_type = $input['action_type'] ?? 'checkin';
    
    // Device fingerprint - combination of multiple factors
    $device_info = [
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'screen_resolution' => $input['screen_resolution'] ?? '',
        'timezone_offset' => $input['timezone_offset'] ?? '',
        'browser_name' => $input['browser_name'] ?? '',
        'operating_system' => $input['operating_system'] ?? '',
        'device_type' => $input['device_type'] ?? 'unknown'
    ];
    
    $device_fingerprint = hash('sha256', json_encode($device_info));
    
    // Get IP address
    $ip_address = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? 
                 $_SERVER['HTTP_X_FORWARDED_FOR'] ?? 
                 $_SERVER['HTTP_X_REAL_IP'] ?? 
                 $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    // Clean IP if it contains multiple IPs
    if (strpos($ip_address, ',') !== 0) {
        $ip_address = trim(explode(',', $ip_address)[0]);
    }
    
    // Location data
    $latitude = $input['latitude'] ?? null;
    $longitude = $input['longitude'] ?? null;
    $location_accuracy = $input['location_accuracy'] ?? null;
    
    // MAC address (usually not available in web browsers for security reasons)
    $mac_address = $input['mac_address'] ?? null;
    
    // Generate session ID if not provided
    $session_id = $input['session_id'] ?? session_id();
    
    // Insert device record
    $stmt = $conn->prepare("
        INSERT INTO device_records (
            company_id, employee_id, session_id, device_fingerprint, ip_address, mac_address,
            user_agent, device_type, browser_name, operating_system, screen_resolution,
            timezone_offset, latitude, longitude, location_accuracy, location_timestamp,
            qr_location_id, action_type, success
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, TRUE)
    ");
    
    $stmt->execute([
        $company_id,
        $employee_id,
        $session_id,
        $device_fingerprint,
        $ip_address,
        $mac_address,
        $device_info['user_agent'],
        $device_info['device_type'],
        $device_info['browser_name'],
        $device_info['operating_system'],
        $device_info['screen_resolution'],
        $device_info['timezone_offset'],
        $latitude,
        $longitude,
        $location_accuracy,
        $qr_location_id,
        $action_type
    ]);
    
    $device_record_id = $conn->lastInsertId();
    
    // Update or create employee-device relationship
    if ($employee_id && $company_id) {
        $stmt = $conn->prepare("
            INSERT INTO employee_devices (
                company_id, employee_id, device_fingerprint, device_name, device_type, usage_count
            ) VALUES (?, ?, ?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE 
                last_seen = CURTIME()STAMP,
                usage_count = usage_count + 1,
                device_type = VALUES(device_type)
        ");
        
        $device_name = $device_info['operating_system'] . ' - ' . $device_info['browser_name'];
        $stmt->execute([
            $company_id,
            $employee_id,
            $device_fingerprint,
            $device_name,
            $device_info['device_type']
        ]);
        
        // Check for security events
        checkSecurityEvents($conn, $company_id, $employee_id, $device_fingerprint, $ip_address, $latitude, $longitude);
    }
    
    // Return success response
    echo json_encode([
        'success' => 1,
        'device_record_id' => $device_record_id,
        'device_fingerprint' => $device_fingerprint,
        'message' => 'Device information recorded successfully'
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => 0,
        'error' => $e->getMessage()
    ]);
}

function checkSecurityEvents($conn, $company_id, $employee_id, $device_fingerprint, $ip_address, $latitude, $longitude) {
    try {
        // Check if this is a new device for the employee
        $stmt = $conn->prepare("
            SELECT COUNT(*) as count FROM employee_devices 
            WHERE employee_id = ? AND device_fingerprint = ?
        ");
        $stmt->execute([$employee_id, $device_fingerprint]);
        $device_exists = $stmt->fetch()['count'] > 0;
        
        if (!$device_exists) {
            // Log new device event
            $stmt = $conn->prepare("
                INSERT INTO device_security_logs (
                    company_id, employee_id, device_fingerprint, ip_address, 
                    event_type, severity, description, metadata
                ) VALUES (?, ?, ?, ?, 'new_device', 'medium', ?, ?)
            ");
            
            $description = "New device detected for employee";
            $metadata = json_encode([
                'latitude' => $latitude,
                'longitude' => $longitude,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            
            $stmt->execute([
                $company_id, $employee_id, $device_fingerprint, $ip_address, $description, $metadata
            ]);
        }
        
        // Check for multiple simultaneous devices (within last 5 minutes)
        $stmt = $conn->prepare("
            SELECT COUNT(DISTINCT device_fingerprint) as device_count 
            FROM device_records 
            WHERE employee_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ");
        $stmt->execute([$employee_id]);
        $recent_devices = $stmt->fetch()['device_count'];
        
        if ($recent_devices > 1) {
            $stmt = $conn->prepare("
                INSERT INTO device_security_logs (
                    company_id, employee_id, device_fingerprint, ip_address,
                    event_type, severity, description, metadata
                ) VALUES (?, ?, ?, ?, 'multiple_devices', 'high', ?, ?)
            ");
            
            $description = "Multiple devices used simultaneously";
            $metadata = json_encode([
                'device_count' => $recent_devices,
                'timeframe' => '5 minutes'
            ]);
            
            $stmt->execute([
                $company_id, $employee_id, $device_fingerprint, $ip_address, $description, $metadata
            ]);
        }
        
    } catch (Exception $e) {
        // Log security check error but don't fail the main operation
        error_log("Security check error: " . $e->getMessage());
    }
}
?>