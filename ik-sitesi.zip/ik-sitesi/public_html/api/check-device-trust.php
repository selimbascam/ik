<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Set JSON response headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle OPTIONS request for CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Only POST method allowed');
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), 1);
    if (!$input) {
        $input = $_POST; // Fallback to form data
    }
    
    $employee_id = $input['employee_id'] ?? null;
    $device_fingerprint = $input['device_fingerprint'] ?? null;
    
    if (!$employee_id || !$device_fingerprint) {
        throw new Exception('Employee ID and device fingerprint are required');
    }
    
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if device is trusted for this employee - with fallback for missing columns
    try {
        $stmt = $conn->prepare("
            SELECT is_trusted, COALESCE(is_blocked, 0) as is_blocked
            FROM employee_devices 
            WHERE employee_id = ? AND device_fingerprint = ?
        ");
    } catch (PDOException $e) {
        // Fallback without is_blocked column
        $stmt = $conn->prepare("
            SELECT is_trusted, 0 as is_blocked
            FROM employee_devices 
            WHERE employee_id = ? AND device_fingerprint = ?
        ");
    }
    $stmt->execute([$employee_id, $device_fingerprint]);
    $device = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$device) {
        // Device doesn't exist yet
        echo json_encode([
            'success' => 1,
            'is_trusted' => 0,
            'is_blocked' => 0,
            'device_exists' => 0,
            'message' => 'Device not registered yet'
        ]);
    } else {
        echo json_encode([
            'success' => 1,
            'is_trusted' => (bool)$device['is_trusted'],
            'is_blocked' => (bool)($device['is_blocked'] ?? 0),
            'device_exists' => 1,
            'message' => ($device['is_blocked'] ?? 0) ? 'Device is blocked' : 
                        ($device['is_trusted'] ? 'Device is trusted' : 'Device is unknown')
        ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => 0,
        'error' => $e->getMessage()
    ]);
}
?>