<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$auth = getAuth();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// Firma admin yetkisi kontrolü
$auth->requireAuth();
if (!in_array($_SESSION['role'], ['company_admin', 'system_admin'])) {
    errorResponse('Bu işlem için yetkiniz yok', 403);
}

$companyId = $_SESSION['company_id'] ?? null;
if (!$companyId && $_SESSION['role'] !== 'system_admin') {
    errorResponse('Firma bilgisi bulunamadı', 400);
}

try {
    switch ($method) {
        case 'GET':
            // Personel listesi getir
            $action = $_GET['action'] ?? 'list';
            
            switch ($action) {
                case 'list':
                    $sql = "
                        SELECT 
                            e.*,
                            u.email,
                            u.role as user_role,
                            u.is_active as user_active,
                            u.last_login,
                            d.name as department_name
                        FROM employees e
                        LEFT JOIN users u ON e.user_id = u.id
                        LEFT JOIN departments d ON e.department_id = d.id
                        WHERE e.company_id = :company_id
                        ORDER BY e.first_name, e.last_name
                    ";
                    
                    $stmt = $db->query($sql, [':company_id' => $companyId]);
                    $employees = $stmt->fetchAll();
                    
                    jsonResponse($employees);
                    break;

                case 'stats':
                    // Personel istatistikleri
                    $totalEmployees = $db->count('employees', 'company_id = :company_id AND is_active = 1', [':company_id' => $companyId]);
                    $activeUsers = $db->count('users u JOIN employees e ON u.id = e.user_id', 'e.company_id = :company_id AND u.is_active = 1', [':company_id' => $companyId]);
                    
                    // Bugün gelen personel sayısı
                    $today = date('Y-m-d');
                    $presentToday = $db->count(
                        'attendance_records ar JOIN employees e ON ar.employee_id = e.id', 
                        'e.company_id = :company_id AND ar.date = :date AND ar.status = :status', 
                        [':company_id' => $companyId, ':date' => $today, ':status' => 'present']
                    );

                    jsonResponse([
                        'total_employees' => $totalEmployees,
                        'active_users' => $activeUsers,
                        'present_today' => $presentToday,
                        'departments' => $db->count('departments', 'company_id = :company_id', [':company_id' => $companyId])
                    ]);
                    break;

                default:
                    errorResponse('Geçersiz action parametresi');
            }
            break;

        case 'POST':
            // Yeni personel ekle
            $input = json_decode(file_get_contents('php://input'), 1);
            
            if (!$input) {
                errorResponse('Geçersiz JSON verisi');
            }

            // Required fields validation
            $required = ['first_name', 'last_name', 'email', 'employee_code'];
            foreach ($required as $field) {
                if (empty($input[$field])) {
                    errorResponse("$field alanı gereklidir");
                }
            }

            // Email ve employee code benzersizlik kontrolü
            $existingUser = $db->selectOne('users', 'email = :email', [':email' => $input['email']]);
            if ($existingUser) {
                errorResponse('Bu email adresi zaten kullanılıyor');
            }

            $existingEmployee = $db->selectOne('employees', 'employee_code = :code AND company_id = :company_id', [
                ':code' => $input['employee_code'],
                ':company_id' => $companyId
            ]);
            if ($existingEmployee) {
                errorResponse('Bu personel kodu zaten kullanılıyor');
            }

            // Transaction başlat
            $db->getConnection()->beginTransaction();

            try {
                // Kullanıcı oluştur (opsiyonel)
                $userId = null;
                if (!empty($input['create_user']) && !empty($input['password'])) {
                    $userData = [
                        'email' => trim($input['email']),
                        'password_hash' => password_hash($input['password'], PASSWORD_DEFAULT),
                        'first_name' => trim($input['first_name']),
                        'last_name' => trim($input['last_name']),
                        'role' => $input['role'] ?? 'employee',
                        'company_id' => $companyId,
                        'is_active' => 1,
                        'created_at' => date('Y-m-d H:i:s')
                    ];

                    $userId = $db->insert('users', $userData);
                }

                // Personel oluştur
                $employeeData = [
                    'user_id' => $userId,
                    'company_id' => $companyId,
                    'department_id' => $input['department_id'] ?? null,
                    'employee_code' => trim($input['employee_code']),
                    'first_name' => trim($input['first_name']),
                    'last_name' => trim($input['last_name']),
                    'email' => trim($input['email']),
                    'phone' => trim($input['phone'] ?? ''),
                    'position' => trim($input['position'] ?? ''),
                    'hire_date' => $input['hire_date'] ?? date('Y-m-d'),
                    'salary' => $input['salary'] ?? null,
                    'is_active' => 1,
                    'created_at' => date('Y-m-d H:i:s')
                ];

                $employeeId = $db->insert('employees', $employeeData);

                // Varsayılan mola haklarını oluştur
                $defaultBreaks = [
                    ['employee_id' => $employeeId, 'break_type' => 'tea_break', 'daily_limit_minutes' => 30],
                    ['employee_id' => $employeeId, 'break_type' => 'lunch_break', 'daily_limit_minutes' => 60],
                    ['employee_id' => $employeeId, 'break_type' => 'smoke_break', 'daily_limit_minutes' => 20]
                ];

                foreach ($defaultBreaks as $breakEntitlement) {
                    $db->insert('employee_break_entitlements', $breakEntitlement);
                }

                $db->getConnection()->commit();

                // Yeni personeli getir
                $newEmployee = $db->selectOne('employees', 'id = :id', [':id' => $employeeId]);
                
                jsonResponse([
                    'success' => 1,
                    'message' => 'Personel başarıyla eklendi',
                    'employee' => $newEmployee
                ], 201);

            } catch (Exception $e) {
                $db->getConnection()->rollBack();
                throw $e;
            }
            break;

        case 'PUT':
            // Personel güncelle
            $employeeId = $_GET['id'] ?? null;
            if (!$employeeId) {
                errorResponse('Personel ID gereklidir');
            }

            // Personelin bu firmaya ait olduğunu kontrol et
            $employee = $db->selectOne('employees', 'id = :id AND company_id = :company_id', [
                ':id' => $employeeId,
                ':company_id' => $companyId
            ]);

            if (!$employee) {
                errorResponse('Personel bulunamadı', 404);
            }

            $input = json_decode(file_get_contents('php://input'), 1);
            
            if (!$input) {
                errorResponse('Geçersiz JSON verisi');
            }

            // Güncellenebilir alanlar
            $updateData = [];
            $allowedFields = ['first_name', 'last_name', 'email', 'phone', 'position', 'department_id', 'salary', 'is_active'];
            
            foreach ($allowedFields as $field) {
                if (isset($input[$field])) {
                    $updateData[$field] = $input[$field];
                }
            }

            if (empty($updateData)) {
                errorResponse('Güncellenecek alan bulunamadı');
            }

            $updateData['updated_at'] = date('Y-m-d H:i:s');

            $db->update('employees', $updateData, 'id = :id', [':id' => $employeeId]);

            jsonResponse([
                'success' => 1,
                'message' => 'Personel bilgileri güncellendi'
            ]);
            break;

        case 'DELETE':
            // Personel sil (soft delete)
            $employeeId = $_GET['id'] ?? null;
            if (!$employeeId) {
                errorResponse('Personel ID gereklidir');
            }

            // Personelin bu firmaya ait olduğunu kontrol et
            $employee = $db->selectOne('employees', 'id = :id AND company_id = :company_id', [
                ':id' => $employeeId,
                ':company_id' => $companyId
            ]);

            if (!$employee) {
                errorResponse('Personel bulunamadı', 404);
            }

            // Soft delete
            $db->update('employees', 
                ['is_active' => 0, 'updated_at' => date('Y-m-d H:i:s')], 
                'id = :id', 
                [':id' => $employeeId]
            );

            // User varsa onu da pasif yap
            if ($employee['user_id']) {
                $db->update('users', 
                    ['is_active' => 0, 'updated_at' => date('Y-m-d H:i:s')], 
                    'id = :id', 
                    [':id' => $employee['user_id']]
                );
            }

            jsonResponse([
                'success' => 1,
                'message' => 'Personel pasif duruma alındı'
            ]);
            break;

        default:
            errorResponse('Desteklenmeyen HTTP metodu', 405);
    }

} catch (Exception $e) {
    error_log("Company Employees API Error: " . $e->getMessage());
    errorResponse('İşlem başarısız: ' . $e->getMessage(), 500);
}
?>