<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../common/database.php';
require_once __DIR__ . '/../common/auth.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Sadece POST metodu desteklenir', 405);
}

try {
    $input = json_decode(file_get_contents('php://input'), 1);
    
    if (!$input) {
        errorResponse('Geçersiz JSON verisi');
    }

    // Required fields validation
    $required = [
        'company_name', 'company_email', 'company_phone', 'tax_number',
        'admin_first_name', 'admin_last_name', 'admin_email', 'admin_phone', 'admin_password',
        'package_id'
    ];
    
    foreach ($required as $field) {
        if (empty($input[$field])) {
            errorResponse("$field alanı gereklidir");
        }
    }

    // Email format kontrolü
    if (!filter_var($input['company_email'], FILTER_VALIDATE_EMAIL)) {
        errorResponse('Geçersiz şirket email formatı');
    }
    
    if (!filter_var($input['admin_email'], FILTER_VALIDATE_EMAIL)) {
        errorResponse('Geçersiz yönetici email formatı');
    }

    // Email ve vergi numarası benzersizlik kontrolü
    if ($db->exists('companies', 'email = :email', [':email' => $input['company_email']])) {
        errorResponse('Bu email adresi zaten kayıtlı');
    }
    
    if ($db->exists('companies', 'tax_number = :tax_number', [':tax_number' => $input['tax_number']])) {
        errorResponse('Bu vergi numarası zaten kayıtlı');
    }
    
    if ($db->exists('company_admins', 'email = :email', [':email' => $input['admin_email']])) {
        errorResponse('Bu yönetici email adresi zaten kayıtlı');
    }

    // Paket kontrolü
    $package = $db->selectOne('company_packages', 'id = :id AND is_active = 1', [':id' => $input['package_id']]);
    if (!$package) {
        errorResponse('Geçersiz paket seçimi');
    }

    // Şifre gücü kontrolü
    if (strlen($input['admin_password']) < 6) {
        errorResponse('Şifre en az 6 karakter olmalıdır');
    }

    // Transaction başlat
    $db->getConnection()->beginTransaction();

    try {
        // 1. Şirket oluştur
        $companyData = [
            'name' => $input['company_name'],
            'address' => $input['company_address'] ?? '',
            'phone' => $input['company_phone'],
            'email' => $input['company_email'],
            'tax_number' => $input['tax_number'],
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $companyId = $db->insert('companies', $companyData);

        // 2. Şirket yöneticisi oluştur
        $adminData = [
            'company_id' => $companyId,
            'first_name' => $input['admin_first_name'],
            'last_name' => $input['admin_last_name'],
            'email' => $input['admin_email'],
            'phone' => $input['admin_phone'],
            'password_hash' => password_hash($input['admin_password'], PASSWORD_DEFAULT),
            'is_owner' => 1,
            'permissions' => json_encode(['all_company_permissions']),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $adminId = $db->insert('company_admins', $adminData);

        // 3. Abonelik oluştur (30 gün deneme süresi)
        $subscriptionData = [
            'company_id' => $companyId,
            'package_id' => $input['package_id'],
            'start_date' => date('Y-m-d'),
            'end_date' => date('Y-m-d', strtotime('+30 days')), // 30 gün deneme
            'status' => 'active',
            'payment_method' => 'trial',
            'amount_paid' => 0.00,
            'notes' => '30 gün ücretsiz deneme süresi',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $subscriptionId = $db->insert('company_subscriptions', $subscriptionData);

        // 4. Varsayılan şirket ayarları
        $defaultSettings = [
            ['setting_key' => 'work_hours_start', 'setting_value' => '09:00', 'data_type' => 'string', 'description' => 'Normal mesai başlangıç saati'],
            ['setting_key' => 'work_hours_end', 'setting_value' => '18:00', 'data_type' => 'string', 'description' => 'Normal mesai bitiş saati'],
            ['setting_key' => 'lunch_break_duration', 'setting_value' => '60', 'data_type' => 'integer', 'description' => 'Öğle yemeği molası süresi (dakika)'],
            ['setting_key' => 'overtime_rate', 'setting_value' => '1.5', 'data_type' => 'float', 'description' => 'Mesai ücreti katsayısı'],
            ['setting_key' => 'allow_early_checkin', 'setting_value' => 'true', 'data_type' => 'boolean', 'description' => 'Erken giriş izni'],
            ['setting_key' => 'require_photo_checkin', 'setting_value' => 'false', 'data_type' => 'boolean', 'description' => 'Giriş sırasında fotoğraf zorunluluğu'],
            ['setting_key' => 'timezone', 'setting_value' => 'Europe/Istanbul', 'data_type' => 'string', 'description' => 'Şirket saat dilimi']
        ];

        foreach ($defaultSettings as $setting) {
            $setting['company_id'] = $companyId;
            $setting['updated_at'] = date('Y-m-d H:i:s');
            $db->insert('company_settings', $setting);
        }

        // 5. Varsayılan departman oluştur
        $defaultDepartment = [
            'company_id' => $companyId,
            'name' => 'Genel',
            'description' => 'Varsayılan departman',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $departmentId = $db->insert('departments', $defaultDepartment);

        // 6. Varsayılan izin türleri
        $defaultLeaveTypes = [
            ['name' => 'Yıllık İzin', 'annual_limit' => 14, 'color' => '#007bff'],
            ['name' => 'Hastalık İzni', 'annual_limit' => 10, 'color' => '#dc3545'],
            ['name' => 'Mazeret İzni', 'annual_limit' => 5, 'color' => '#ffc107']
        ];

        foreach ($defaultLeaveTypes as $leaveType) {
            $leaveType['company_id'] = $companyId;
            $db->insert('leave_types', $leaveType);
        }

        // 7. Varsayılan vardiya
        $defaultShift = [
            'company_id' => $companyId,
            'name' => 'Normal Mesai',
            'start_time' => '09:00:00',
            'end_time' => '18:00:00',
            'break_duration' => 60
        ];
        
        $db->insert('shifts', $defaultShift);

        // Transaction commit
        $db->getConnection()->commit();

        // Başarılı kayıt yanıtı
        $response = [
            'success' => 1,
            'message' => 'Şirket kaydı başarıyla tamamlandı! 30 gün ücretsiz deneme süreniz başladı.',
            'company_id' => $companyId,
            'admin_id' => $adminId,
            'subscription_id' => $subscriptionId,
            'package' => [
                'name' => $package['name'],
                'max_employees' => $package['max_employees'],
                'max_locations' => $package['max_locations']
            ],
            'trial_end_date' => date('Y-m-d', strtotime('+30 days')),
            'next_steps' => [
                'Email ile giriş yapabilirsiniz',
                'İlk personellerinizi ekleyebilirsiniz', 
                'QR lokasyonlarınızı oluşturabilirsiniz',
                'Sistem ayarlarınızı yapılandırabilirsiniz'
            ]
        ];

        jsonResponse($response, 201);

    } catch (Exception $e) {
        // Transaction rollback
        $db->getConnection()->rollback();
        throw $e;
    }

} catch (Exception $e) {
    error_log("Company Registration API Error: " . $e->getMessage());
    errorResponse('Şirket kaydı başarısız: ' . $e->getMessage(), 500);
}
?>