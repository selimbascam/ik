<?php
// Common utility functions

function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function errorResponse($message, $statusCode = 400) {
    jsonResponse([
        'success' => 0,
        'message' => $message
    ], $statusCode);
}

function successResponse($data = [], $message = 'İşlem başarılı') {
    jsonResponse([
        'success' => 1,
        'message' => $message,
        'data' => $data
    ]);
}

function validateInput($data, $rules) {
    $errors = [];
    
    foreach ($rules as $field => $rule) {
        $value = $data[$field] ?? null;
        
        // Required check
        if (isset($rule['required']) && $rule['required'] && empty($value)) {
            $errors[$field] = $rule['message'] ?? "$field gerekli";
            continue;
        }
        
        // Skip other validations if field is empty and not required
        if (empty($value)) {
            continue;
        }
        
        // Min length
        if (isset($rule['min']) && strlen($value) < $rule['min']) {
            $errors[$field] = $rule['message'] ?? "$field en az {$rule['min']} karakter olmalı";
        }
        
        // Max length
        if (isset($rule['max']) && strlen($value) > $rule['max']) {
            $errors[$field] = $rule['message'] ?? "$field en fazla {$rule['max']} karakter olmalı";
        }
        
        // Email format
        if (isset($rule['email']) && $rule['email'] && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $errors[$field] = $rule['message'] ?? "$field geçerli bir email adresi olmalı";
        }
        
        // Numeric
        if (isset($rule['numeric']) && $rule['numeric'] && !is_numeric($value)) {
            $errors[$field] = $rule['message'] ?? "$field sayısal bir değer olmalı";
        }
        
        // Date format
        if (isset($rule['date']) && $rule['date']) {
            $date = DateTime::createFromFormat('Y-m-d', $value);
            if (!$date || $date->format('Y-m-d') !== $value) {
                $errors[$field] = $rule['message'] ?? "$field geçerli bir tarih olmalı (YYYY-MM-DD)";
            }
        }
        
        // Time format
        if (isset($rule['time']) && $rule['time']) {
            $time = DateTime::createFromFormat('H:i:s', $value);
            if (!$time || $time->format('H:i:s') !== $value) {
                $errors[$field] = $rule['message'] ?? "$field geçerli bir saat olmalı (HH:MM:SS)";
            }
        }
        
        // Enum values
        if (isset($rule['enum']) && !in_array($value, $rule['enum'])) {
            $allowed = implode(', ', $rule['enum']);
            $errors[$field] = $rule['message'] ?? "$field şu değerlerden biri olmalı: $allowed";
        }
    }
    
    return $errors;
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function formatDateTime($datetime, $format = 'Y-m-d H:i:s') {
    if (empty($datetime)) {
        return null;
    }
    
    $date = new DateTime($datetime);
    return $date->format($format);
}

function formatDate($date, $format = 'Y-m-d') {
    return formatDateTime($date, $format);
}

function formatTime($time, $format = 'H:i') {
    if (empty($time)) {
        return null;
    }
    
    $dateTime = DateTime::createFromFormat('H:i:s', $time);
    if (!$dateTime) {
        $dateTime = new DateTime($time);
    }
    
    return $dateTime->format($format);
}

function calculateDuration($startTime, $endTime) {
    if (empty($startTime) || empty($endTime)) {
        return 0;
    }
    
    $start = new DateTime($startTime);
    $end = new DateTime($endTime);
    
    if ($end < $start) {
        // Next day scenario
        $end->add(new DateInterval('P1D'));
    }
    
    $interval = $start->diff($end);
    return ($interval->h * 60) + $interval->i; // Return minutes
}

function minutesToHours($minutes) {
    if ($minutes <= 0) {
        return '0:00';
    }
    
    $hours = floor($minutes / 60);
    $mins = $minutes % 60;
    
    return sprintf('%d:%02d', $hours, $mins);
}

function getCurrentDate() {
    return date('Y-m-d');
}

function getCurrentDateTime() {
    return date('Y-m-d H:i:s');
}

function getCurrentTime() {
    return date('H:i:s');
}

function getStartOfWeek($date = null) {
    $date = $date ? new DateTime($date) : new DateTime();
    $date->modify('monday this week');
    return $date->format('Y-m-d');
}

function getEndOfWeek($date = null) {
    $date = $date ? new DateTime($date) : new DateTime();
    $date->modify('sunday this week');
    return $date->format('Y-m-d');
}

function getStartOfMonth($date = null) {
    $date = $date ? new DateTime($date) : new DateTime();
    return $date->format('Y-m-01');
}

function getEndOfMonth($date = null) {
    $date = $date ? new DateTime($date) : new DateTime();
    return $date->format('Y-m-t');
}

function isWeekend($date) {
    $dayOfWeek = date('N', strtotime($date));
    return $dayOfWeek >= 6; // Saturday = 6, Sunday = 7
}

function getBusinessDays($startDate, $endDate) {
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $end->modify('+1 day'); // Include end date
    
    $period = new DatePeriod($start, new DateInterval('P1D'), $end);
    $businessDays = 0;
    
    foreach ($period as $date) {
        if (!isWeekend($date->format('Y-m-d'))) {
            $businessDays++;
        }
    }
    
    return $businessDays;
}

function generateQRCode($data, $size = 200) {
    // Simple QR code generation URL (you can use a QR service or library)
    $encoded = urlencode($data);
    return "https://api.qrserver.com/v1/create-qr-code/?size={$size}x{$size}&data={$encoded}";
}

function logError($message, $context = []) {
    $log = [
        'timestamp' => getCurrentDateTime(),
        'message' => $message,
        'context' => $context,
        'user_id' => $_SESSION['user_id'] ?? null,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ];
    
    error_log(json_encode($log, JSON_UNESCAPED_UNICODE));
}

function corsHeaders() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        exit(0);
    }
}

function getRequestMethod() {
    return $_SERVER['REQUEST_METHOD'];
}

function getRequestData() {
    $method = getRequestMethod();
    
    switch ($method) {
        case 'GET':
            return $_GET;
        case 'POST':
        case 'PUT':
        case 'DELETE':
            $input = file_get_contents('php://input');
            $data = json_decode($input, 1);
            return $data ?: $_POST;
        default:
            return [];
    }
}

function checkRateLimit($identifier, $maxRequests = 60, $timeWindow = 3600) {
    // Simple rate limiting (in production, use Redis or database)
    $key = "rate_limit_" . md5($identifier);
    $file = sys_get_temp_dir() . "/$key";
    
    $current = time();
    $requests = [];
    
    if (file_exists($file)) {
        $requests = json_decode(file_get_contents($file), 1) ?: [];
    }
    
    // Clean old requests
    $requests = array_filter($requests, function($time) use ($current, $timeWindow) {
        return ($current - $time) < $timeWindow;
    });
    
    if (count($requests) >= $maxRequests) {
        return false;
    }
    
    $requests[] = $current;
    file_put_contents($file, json_encode($requests));
    
    return true;
}
?>