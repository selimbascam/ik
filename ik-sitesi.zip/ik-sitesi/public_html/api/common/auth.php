<?php
require_once __DIR__ . '/database.php';

class Auth {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    public function login($username, $password) {
        $user = $this->db->selectOne('users', 'username = :username AND is_active = 1', [
            ':username' => $username
        ]);

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['login_time'] = time();

            // Update last login
            $this->db->update('users', 
                ['last_login' => date('Y-m-d H:i:s')], 
                'id = :id', 
                [':id' => $user['id']]
            );

            // Get employee info if exists
            $employee = $this->db->selectOne('employees', 'user_id = :user_id', [
                ':user_id' => $user['id']
            ]);

            if ($employee) {
                $_SESSION['employee_id'] = $employee['id'];
                $_SESSION['company_id'] = $employee['company_id'];
            }

            return true;
        }

        return false;
    }

    public function logout() {
        session_destroy();
        return true;
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && 
               isset($_SESSION['login_time']) && 
               (time() - $_SESSION['login_time']) < SESSION_TIMEOUT;
    }

    public function getCurrentUser() {
        if (!$this->isLoggedIn()) {
            return null;
        }

        $user = $this->db->selectOne('users', 'id = :id', [
            ':id' => $_SESSION['user_id']
        ]);

        if ($user) {
            unset($user['password_hash']); // Don't return password
            
            // Add employee info if available
            if (isset($_SESSION['employee_id'])) {
                $employee = $this->db->selectOne('employees', 'id = :id', [
                    ':id' => $_SESSION['employee_id']
                ]);
                $user['employee'] = $employee;
            }
        }

        return $user;
    }

    public function requireAuth() {
        if (!$this->isLoggedIn()) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }
    }

    public function requireRole($role) {
        $this->requireAuth();
        
        if ($_SESSION['role'] !== $role && $_SESSION['role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden']);
            exit;
        }
    }

    public function hasRole($role) {
        return $this->isLoggedIn() && 
               ($_SESSION['role'] === $role || $_SESSION['role'] === 'admin');
    }

    public function createUser($userData) {
        // Hash password
        $userData['password_hash'] = password_hash($userData['password'], PASSWORD_DEFAULT);
        unset($userData['password']);

        // Set defaults
        $userData['created_at'] = date('Y-m-d H:i:s');
        $userData['is_active'] = 1;

        return $this->db->insert('users', $userData);
    }

    public function updatePassword($userId, $newPassword) {
        $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        
        return $this->db->update('users', 
            ['password_hash' => $passwordHash, 'updated_at' => date('Y-m-d H:i:s')], 
            'id = :id', 
            [':id' => $userId]
        );
    }

    public function getUserById($userId) {
        $user = $this->db->selectOne('users', 'id = :id', [':id' => $userId]);
        if ($user) {
            unset($user['password_hash']);
        }
        return $user;
    }
}

// Global auth instance
function getAuth() {
    static $auth = null;
    if ($auth === null) {
        $auth = new Auth();
    }
    return $auth;
}

// Helper function for API responses
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Helper function for error responses
function errorResponse($message, $statusCode = 400) {
    jsonResponse(['error' => $message], $statusCode);
}
?>