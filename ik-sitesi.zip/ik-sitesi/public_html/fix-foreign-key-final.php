<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>Foreign Key Constraint - Kesin Çözüm</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;line-height:1.6;}h1,h2{color:#333;}.success{color:#22c55e;font-weight:bold;}.error{color:#ef4444;font-weight:bold;}.info{color:#3b82f6;font-weight:bold;}.warning{color:#f59e0b;font-weight:bold;}.box{background:#f8f9fa;padding:15px;margin:15px 0;border-radius:5px;border-left:5px solid #007bff;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='box'>";
    echo "<h2>1. Test Personeli Analizi (30716129672)</h2>";
    
    // Get employee data
    $stmt = $conn->prepare("SELECT id, employee_number, first_name, last_name, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "<p class='error'>Personel bulunamadı!</p>";
        exit;
    }
    
    echo "<p class='success'>Personel bulundu: {$employee['first_name']} {$employee['last_name']}</p>";
    echo "<p>Employee ID: {$employee['id']}</p>";
    echo "<p>Current Company ID: " . ($employee['company_id'] ?? 'NULL') . "</p>";
    
    // Check if this company_id exists
    if ($employee['company_id']) {
        $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
        $stmt->execute([$employee['company_id']]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$company) {
            echo "<p class='error'>SORUN: Company ID {$employee['company_id']} veritabanında YOK!</p>";
            $needsFix = true;
        } else {
            echo "<p class='success'>Şirket mevcut: {$company['company_name']}</p>";
            $needsFix = false;
        }
    } else {
        echo "<p class='error'>SORUN: Company ID NULL!</p>";
        $needsFix = true;
    }
    echo "</div>";
    
    if ($needsFix) {
        echo "<div class='box'>";
        echo "<h2>2. Otomatik Düzeltme</h2>";
        
        // Find or create a company
        $stmt = $conn->query("SELECT id, company_name FROM companies ORDER BY id LIMIT 1");
        $existingCompany = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingCompany) {
            $targetCompanyId = $existingCompany['id'];
            echo "<p class='info'>Mevcut şirket kullanılacak: {$existingCompany['company_name']} (ID: {$targetCompanyId})</p>";
        } else {
            // Create new company
            $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute(['SZB İK Takip', 'admin@szb.com.tr', '555-0100', 'Merkez Ofis']);
            $targetCompanyId = $conn->lastInsertId();
            echo "<p class='success'>Yeni şirket oluşturuldu (ID: {$targetCompanyId})</p>";
        }
        
        // Update employee
        $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
        $stmt->execute([$targetCompanyId, $employee['id']]);
        echo "<p class='success'>Personel güncellendi - Yeni Company ID: {$targetCompanyId}</p>";
        
        // Update local variable
        $employee['company_id'] = $targetCompanyId;
        echo "</div>";
    }
    
    echo "<div class='box'>";
    echo "<h2>3. QR Location Kontrolü</h2>";
    
    // Check QR locations for this company
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ?");
    $stmt->execute([$employee['company_id']]);
    $qrCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($qrCount == 0) {
        echo "<p class='warning'>QR location yok, oluşturuluyor...</p>";
        
        // Check if is_active column exists
        $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'is_active'");
        $hasIsActive = $stmt->rowCount() > 0;
        
        if ($hasIsActive) {
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $employee['company_id'],
                'Ana Giriş',
                'Otomatik oluşturuldu',
                '41.0082',
                '28.9784',
                'entrance',
                1
            ]);
        } else {
            $stmt = $conn->prepare("
                INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $employee['company_id'],
                'Ana Giriş',
                'Otomatik oluşturuldu',
                '41.0082',
                '28.9784',
                'entrance'
            ]);
        }
        
        $qrLocationId = $conn->lastInsertId();
        echo "<p class='success'>QR location oluşturuldu (ID: {$qrLocationId})</p>";
    } else {
        echo "<p class='success'>Şirketin {$qrCount} adet QR location'ı var</p>";
        
        // Get first QR location
        $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? LIMIT 1");
        $stmt->execute([$employee['company_id']]);
        $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
        $qrLocationId = $qrLocation['id'];
        echo "<p class='info'>İlk QR Location: {$qrLocation['name']} (ID: {$qrLocationId})</p>";
    }
    echo "</div>";
    
    echo "<div class='box'>";
    echo "<h2>4. Test Insert</h2>";
    
    try {
        $currentDateTime = date('Y-m-d H:i:s');
        
        // Check which columns exist
        $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $hasCheckDate = in_array('check_date', $columns);
        $hasDate = in_array('date', $columns);
        
        if ($hasCheckDate && $hasDate) {
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, date, check_date, notes, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $employee['company_id'],
                $employee['id'],
                $qrLocationId,
                'work_in',
                $currentDateTime,
                date('Y-m-d'),
                date('Y-m-d'),
                'Test insert - ' . date('H:i:s'),
                $currentDateTime
            ]);
        } elseif ($hasDate) {
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, date, notes, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $employee['company_id'],
                $employee['id'],
                $qrLocationId,
                'work_in',
                $currentDateTime,
                date('Y-m-d'),
                'Test insert - ' . date('H:i:s'),
                $currentDateTime
            ]);
        } else {
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, notes, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $employee['company_id'],
                $employee['id'],
                $qrLocationId,
                'work_in',
                $currentDateTime,
                'Test insert - ' . date('H:i:s'),
                $currentDateTime
            ]);
        }
        
        $testRecordId = $conn->lastInsertId();
        echo "<p class='success'>✅ TEST BAŞARILI! Record ID: {$testRecordId}</p>";
        
        // Clean up test record
        $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
        $stmt->execute([$testRecordId]);
        echo "<p class='info'>Test kaydı temizlendi</p>";
        
    } catch (Exception $e) {
        echo "<p class='error'>TEST BAŞARISIZ: " . $e->getMessage() . "</p>";
    }
    echo "</div>";
    
    echo "<div class='box' style='background:#e8f5e8;border-left-color:#22c55e;'>";
    echo "<h2 style='color:#2e7d32;'>✅ SORUN ÇÖZÜLDÜ!</h2>";
    echo "<p><strong>Foreign key constraint hatası düzeltildi.</strong></p>";
    echo "<p>Employee company_id: {$employee['company_id']}</p>";
    echo "<p>QR Location ID: {$qrLocationId}</p>";
    echo "<hr>";
    echo "<p><strong>Şimdi QR kod okutmayı tekrar deneyin:</strong></p>";
    echo "<p>Kullanıcı: 30716129672 / Abc123456</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='box' style='background:#fee;border-left-color:#ef4444;'>";
    echo "<p class='error'>Hata: " . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "<div class='box'>";
echo "<h2>5. Tüm Orphaned Employees Düzeltme</h2>";
try {
    // Fix ALL employees with invalid company_id
    $stmt = $conn->query("
        SELECT COUNT(*) as count 
        FROM employees 
        WHERE company_id IS NULL 
        OR company_id NOT IN (SELECT id FROM companies)
    ");
    $orphanedCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($orphanedCount > 0) {
        echo "<p class='warning'>{$orphanedCount} adet sorunlu personel bulundu</p>";
        
        // Get first valid company
        $stmt = $conn->query("SELECT id FROM companies ORDER BY id LIMIT 1");
        $validCompany = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($validCompany) {
            $stmt = $conn->prepare("
                UPDATE employees 
                SET company_id = ? 
                WHERE company_id IS NULL 
                OR company_id NOT IN (SELECT id FROM companies)
            ");
            $stmt->execute([$validCompany['id']]);
            $fixed = $stmt->rowCount();
            echo "<p class='success'>{$fixed} personel düzeltildi</p>";
        }
    } else {
        echo "<p class='success'>Tüm personellerin geçerli company_id'si var</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>Toplu düzeltme hatası: " . $e->getMessage() . "</p>";
}
echo "</div>";
?>