<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔧 Employee Table Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get current table structure
    $result = $conn->query("DESCRIBE employees");
    $existingColumns = [];
    while ($column = $result->fetch()) {
        $existingColumns[$column['Field']] = $column;
    }
    
    echo "<h3>📊 Current Columns</h3>";
    echo "<ul>";
    foreach ($existingColumns as $colName => $colInfo) {
        echo "<li><strong>$colName</strong> ({$colInfo['Type']})</li>";
    }
    echo "</ul>";
    
    $addedColumns = [];
    
    // Add employee_number if missing
    if (!isset($existingColumns['employee_number'])) {
        $conn->query("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) AFTER id");
        $addedColumns[] = 'employee_number';
        echo "<p style='color: green;'>✅ Added employee_number column</p>";
        
        // Generate employee numbers
        $stmt = $conn->prepare("SELECT id FROM employees ORDER BY id");
        $stmt->execute();
        $employees = $stmt->fetchAll();
        
        foreach ($employees as $employee) {
            $employeeNumber = 'EMP' . str_pad($employee['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            $updateStmt->execute([$employeeNumber, $employee['id']]);
        }
        echo "<p style='color: green;'>✅ Generated employee numbers for " . count($employees) . " employees</p>";
    }
    
    // Add employee_code if missing (alternative identifier)
    if (!isset($existingColumns['employee_code'])) {
        $conn->query("ALTER TABLE employees ADD COLUMN employee_code VARCHAR(20) AFTER employee_number");
        $addedColumns[] = 'employee_code';
        echo "<p style='color: green;'>✅ Added employee_code column</p>";
    }
    
    // Add is_active if missing
    if (!isset($existingColumns['is_active'])) {
        $conn->query("ALTER TABLE employees ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER status");
        $addedColumns[] = 'is_active';
        echo "<p style='color: green;'>✅ Added is_active column</p>";
        
        // Set all existing employees as active
        $conn->query("UPDATE employees SET is_active = 1 WHERE is_active IS NULL");
    }
    
    if (empty($addedColumns)) {
        echo "<p style='color: green;'>✅ All required columns already exist</p>";
    } else {
        echo "<p style='color: blue;'>📋 Added columns: " . implode(', ', $addedColumns) . "</p>";
    }
    
    // Test shift management query
    echo "<h3>🔧 Test Shift Management Query</h3>";
    $testQuery = "SELECT 
                    id, 
                    COALESCE(first_name, '') as first_name, 
                    COALESCE(last_name, '') as last_name, 
                    COALESCE(employee_number, CONCAT('EMP', LPAD(id, 4, '0'))) as employee_number,
                    COALESCE(department_id, 0) as department_id
                  FROM employees 
                  WHERE company_id = ? 
                  LIMIT 5";
    
    $stmt = $conn->prepare($testQuery);
    $stmt->execute([1]); // Test with company_id = 1
    $employees = $stmt->fetchAll();
    
    echo "<p style='color: green;'>✅ Query executed successfully</p>";
    echo "<p>Found " . count($employees) . " employees for testing</p>";
    
    if (count($employees) > 0) {
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr style='background: #f0f0f0;'>";
        echo "<th style='padding: 8px;'>ID</th>";
        echo "<th style='padding: 8px;'>Employee Number</th>";
        echo "<th style='padding: 8px;'>Name</th>";
        echo "<th style='padding: 8px;'>Department ID</th>";
        echo "</tr>";
        
        foreach ($employees as $emp) {
            echo "<tr>";
            echo "<td style='padding: 8px;'>{$emp['id']}</td>";
            echo "<td style='padding: 8px;'>{$emp['employee_number']}</td>";
            echo "<td style='padding: 8px;'>{$emp['first_name']} {$emp['last_name']}</td>";
            echo "<td style='padding: 8px;'>{$emp['department_id']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>SQL State: " . ($e->getCode() ?? 'Unknown') . "</p>";
}

echo "<h3>🔗 Ready to Test</h3>";
echo "<div>";
echo "<a href='admin/shift-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Test Shift Management</a>";
echo "<a href='admin/employee-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Employee Management</a>";
echo "<a href='admin/dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
table { width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
</style>