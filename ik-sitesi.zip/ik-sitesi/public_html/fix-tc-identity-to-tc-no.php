<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

/**
 * Fix all tc_identity references to tc_no for consistent naming
 * This addresses the "Unknown column 'tc_identity'" error in shift management
 */

echo "<h2>🔧 TC Identity to TC_NO Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if tc_identity column exists
    $columnsCheck = $conn->query("SHOW COLUMNS FROM employees")->fetchAll(PDO::FETCH_ASSOC);
    $columns = array_column($columnsCheck, 'Field');
    
    $hasTcIdentity = in_array('tc_identity', $columns);
    $hasTcNo = in_array('tc_no', $columns);
    
    echo "<h3>📊 Current Database Status:</h3>";
    echo "<p>• tc_identity column exists: " . ($hasTcIdentity ? "✅ Yes" : "❌ No") . "</p>";
    echo "<p>• tc_no column exists: " . ($hasTcNo ? "✅ Yes" : "❌ No") . "</p>";
    
    if ($hasTcIdentity && !$hasTcNo) {
        echo "<h3>🔄 Renaming tc_identity to tc_no...</h3>";
        
        // Rename the column
        $conn->exec("ALTER TABLE employees CHANGE tc_identity tc_no VARCHAR(11)");
        echo "<p style='color: green;'>✅ Successfully renamed tc_identity to tc_no</p>";
        
    } elseif ($hasTcIdentity && $hasTcNo) {
        echo "<h3>🔄 Both columns exist - Merging data...</h3>";
        
        // Copy tc_identity data to tc_no where tc_no is empty
        $stmt = $conn->prepare("
            UPDATE employees 
            SET tc_no = tc_identity 
            WHERE (tc_no IS NULL OR tc_no = '') 
            AND tc_identity IS NOT NULL 
            AND tc_identity != ''
        ");
        $stmt->execute();
        $merged = $stmt->rowCount();
        
        echo "<p style='color: green;'>✅ Merged $merged records from tc_identity to tc_no</p>";
        
        // Drop the old tc_identity column
        $conn->exec("ALTER TABLE employees DROP COLUMN tc_identity");
        echo "<p style='color: green;'>✅ Dropped tc_identity column</p>";
        
    } elseif (!$hasTcIdentity && !$hasTcNo) {
        echo "<h3>➕ Creating tc_no column...</h3>";
        
        // Create tc_no column
        $conn->exec("ALTER TABLE employees ADD COLUMN tc_no VARCHAR(11) AFTER id");
        echo "<p style='color: green;'>✅ Created tc_no column</p>";
        
    } else {
        echo "<h3>✅ tc_no column already exists and tc_identity doesn't</h3>";
        echo "<p>Database is already in the correct state.</p>";
    }
    
    // Sync tc_no with employee_number and employee_code
    echo "<h3>🔄 Synchronizing TC fields...</h3>";
    
    // Use employee_number as master if tc_no is empty
    $stmt = $conn->prepare("
        UPDATE employees 
        SET tc_no = employee_number,
            employee_code = employee_number
        WHERE (tc_no IS NULL OR tc_no = '') 
        AND employee_number IS NOT NULL 
        AND employee_number != ''
    ");
    $stmt->execute();
    $synced1 = $stmt->rowCount();
    
    // Use tc_no as master for employee_number and employee_code
    $stmt = $conn->prepare("
        UPDATE employees 
        SET employee_number = tc_no,
            employee_code = tc_no
        WHERE tc_no IS NOT NULL 
        AND tc_no != ''
    ");
    $stmt->execute();
    $synced2 = $stmt->rowCount();
    
    echo "<p style='color: green;'>✅ Synced $synced1 records using employee_number as master</p>";
    echo "<p style='color: green;'>✅ Synced $synced2 records using tc_no as master</p>";
    
    // Verify final state
    echo "<h3>🔍 Final Verification:</h3>";
    
    $stmt = $conn->query("
        SELECT 
            COUNT(*) as total,
            COUNT(tc_no) as with_tc_no,
            COUNT(CASE WHEN tc_no = employee_number AND employee_number = employee_code THEN 1 END) as fully_synced
        FROM employees
    ");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p>• Total employees: {$stats['total']}</p>";
    echo "<p>• Employees with tc_no: {$stats['with_tc_no']}</p>";
    echo "<p>• Fully synced (tc_no = employee_number = employee_code): {$stats['fully_synced']}</p>";
    
    // Test the specific employee
    echo "<h3>🧪 Testing Employee 30716129672:</h3>";
    
    $stmt = $conn->prepare("
        SELECT id, tc_no, employee_number, employee_code, first_name, last_name
        FROM employees 
        WHERE tc_no = '30716129672' 
           OR employee_number = '30716129672' 
           OR employee_code = '30716129672'
    ");
    $stmt->execute();
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testEmployee) {
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; color: #155724;'>";
        echo "<h4>✅ Employee 30716129672 Found!</h4>";
        echo "<p><strong>ID:</strong> {$testEmployee['id']}</p>";
        echo "<p><strong>TC No:</strong> {$testEmployee['tc_no']}</p>";
        echo "<p><strong>Employee Number:</strong> {$testEmployee['employee_number']}</p>";
        echo "<p><strong>Employee Code:</strong> {$testEmployee['employee_code']}</p>";
        echo "<p><strong>Name:</strong> {$testEmployee['first_name']} {$testEmployee['last_name']}</p>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
        echo "<p>❌ Employee 30716129672 not found. You may need to create this employee.</p>";
        echo "</div>";
    }
    
    echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 5px; color: #0c5460; margin-top: 20px;'>";
    echo "<h4>🎯 Next Steps:</h4>";
    echo "<ol>";
    echo "<li>Vardiya yönetimi sayfasını test edin</li>";
    echo "<li>'Unknown column tc_identity' hatası artık görülmemeli</li>";
    echo "<li>Personel listesi doğru şekilde gösterilmeli</li>";
    echo "<li>TC kimlik sistemi tutarlı çalışmalı</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Error occurred:</h4>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
</style>