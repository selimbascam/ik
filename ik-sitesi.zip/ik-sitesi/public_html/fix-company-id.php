<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>Company ID Fix - Kesin Çözüm</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;line-height:1.6;}h1,h2{color:#333;}.success{color:#22c55e;font-weight:bold;}.error{color:#ef4444;font-weight:bold;}.info{color:#3b82f6;font-weight:bold;}.warning{color:#f59e0b;font-weight:bold;}.box{background:#f8f9fa;padding:15px;margin:15px 0;border-radius:5px;border-left:5px solid #007bff;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='box'>";
    echo "<h2>1. Mevcut Durum Analizi</h2>";
    
    // Check all employees with NULL or invalid company_id
    $stmt = $conn->query("
        SELECT e.id, e.employee_number, e.first_name, e.last_name, e.company_id
        FROM employees e
        WHERE e.company_id IS NULL 
        OR e.company_id NOT IN (SELECT id FROM companies)
    ");
    $invalidEmployees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($invalidEmployees) {
        echo "<p class='error'>Sorunlu personel sayısı: " . count($invalidEmployees) . "</p>";
        foreach ($invalidEmployees as $emp) {
            echo "<p>- {$emp['employee_number']} {$emp['first_name']} {$emp['last_name']} - Company ID: " . ($emp['company_id'] ?? 'NULL') . "</p>";
        }
    } else {
        echo "<p class='success'>Tüm personellerin geçerli company_id'si var</p>";
    }
    echo "</div>";
    
    echo "<div class='box'>";
    echo "<h2>2. Varsayılan Şirket Oluşturma</h2>";
    
    // Check if we have any company
    $stmt = $conn->query("SELECT id, company_name FROM companies LIMIT 1");
    $existingCompany = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$existingCompany) {
        // Create a default company
        $stmt = $conn->prepare("
            INSERT INTO companies (company_name, email, phone, address, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute(['SZB Default Company', 'admin@szb.com.tr', '555-0123', 'Varsayılan şirket']);
        $defaultCompanyId = $conn->lastInsertId();
        echo "<p class='success'>Varsayılan şirket oluşturuldu - ID: {$defaultCompanyId}</p>";
    } else {
        $defaultCompanyId = $existingCompany['id'];
        echo "<p class='info'>Mevcut şirket kullanılacak: {$existingCompany['company_name']} - ID: {$defaultCompanyId}</p>";
    }
    echo "</div>";
    
    echo "<div class='box'>";
    echo "<h2>3. Tüm Sorunlu Personelleri Düzeltme</h2>";
    
    // Fix all employees with NULL or invalid company_id
    $stmt = $conn->prepare("
        UPDATE employees 
        SET company_id = ? 
        WHERE company_id IS NULL 
        OR company_id NOT IN (SELECT id FROM companies)
    ");
    $stmt->execute([$defaultCompanyId]);
    $affectedRows = $stmt->rowCount();
    
    if ($affectedRows > 0) {
        echo "<p class='success'>{$affectedRows} personelin company_id'si düzeltildi</p>";
    } else {
        echo "<p class='info'>Düzeltilecek personel bulunamadı</p>";
    }
    echo "</div>";
    
    echo "<div class='box'>";
    echo "<h2>4. QR Lokasyon Kontrolü</h2>";
    
    // Ensure the company has QR locations
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ? AND is_active = 1");
    $stmt->execute([$defaultCompanyId]);
    $locationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($locationCount == 0) {
        // Create a default QR location
        $stmt = $conn->prepare("
            INSERT INTO qr_locations 
            (company_id, name, description, latitude, longitude, location_type, is_active, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $defaultCompanyId,
            'Ana Giriş',
            'Varsayılan QR lokasyonu',
            '41.0082',
            '28.9784',
            'entrance',
            1
        ]);
        $qrLocationId = $conn->lastInsertId();
        echo "<p class='success'>QR lokasyonu oluşturuldu - ID: {$qrLocationId}</p>";
    } else {
        echo "<p class='success'>Şirketin {$locationCount} adet aktif QR lokasyonu var</p>";
    }
    echo "</div>";
    
    echo "<div class='box'>";
    echo "<h2>5. Test Personeli Kontrolü (30716129672)</h2>";
    
    $stmt = $conn->prepare("
        SELECT e.id, e.employee_number, e.first_name, e.last_name, e.company_id, c.company_name
        FROM employees e
        LEFT JOIN companies c ON e.company_id = c.id
        WHERE e.employee_number = ?
    ");
    $stmt->execute(['30716129672']);
    $testEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testEmployee) {
        echo "<p class='success'>Test personeli bulundu:</p>";
        echo "<ul>";
        echo "<li>Ad Soyad: {$testEmployee['first_name']} {$testEmployee['last_name']}</li>";
        echo "<li>Personel ID: {$testEmployee['id']}</li>";
        echo "<li>Şirket: {$testEmployee['company_name']} (ID: {$testEmployee['company_id']})</li>";
        echo "</ul>";
        
        // Test insert
        echo "<h3>Attendance Insert Testi</h3>";
        try {
            // Get a QR location for this company
            $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? AND is_active = 1 LIMIT 1");
            $stmt->execute([$testEmployee['company_id']]);
            $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($qrLocation) {
                $currentDateTime = date('Y-m-d H:i:s');
                
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (company_id, employee_id, qr_location_id, activity_type, check_in_time, date, notes, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $result = $stmt->execute([
                    $testEmployee['company_id'],
                    $testEmployee['id'],
                    $qrLocation['id'],
                    'work_in',
                    $currentDateTime,
                    date('Y-m-d'),
                    'Test kaydı - ' . date('H:i:s'),
                    $currentDateTime
                ]);
                
                if ($result) {
                    $recordId = $conn->lastInsertId();
                    echo "<p class='success'>✓ Test kaydı başarıyla oluşturuldu (ID: {$recordId})</p>";
                    
                    // Clean up
                    $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
                    $stmt->execute([$recordId]);
                    echo "<p class='info'>Test kaydı temizlendi</p>";
                }
            } else {
                echo "<p class='error'>QR lokasyonu bulunamadı</p>";
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>Test başarısız: " . $e->getMessage() . "</p>";
        }
        
    } else {
        echo "<p class='error'>Test personeli bulunamadı</p>";
    }
    echo "</div>";
    
    echo "<div class='box' style='background:#e8f5e8;border-left-color:#22c55e;'>";
    echo "<h2 style='color:#2e7d32;'>✓ DÜZELTME TAMAMLANDI</h2>";
    echo "<p><strong>Tüm personellerin company_id'leri düzeltildi</strong></p>";
    echo "<p><strong>QR lokasyonları kontrol edildi ve oluşturuldu</strong></p>";
    echo "<p><strong>Foreign key constraint hatası çözüldü</strong></p>";
    echo "<hr>";
    echo "<p><strong>Şimdi QR kodu test edebilirsiniz:</strong></p>";
    echo "<p>Personel Girişi: 30716129672 / 123456</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='box' style='background:#fee;border-left-color:#ef4444;'>";
    echo "<p class='error'>Hata: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?>