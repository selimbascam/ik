<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Quick Employee 30716129672 Creation</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Delete existing if any
    $conn->prepare("DELETE FROM employees WHERE employee_number = ?")->execute(['30716129672']);
    echo "<p>Cleared existing employee 30716129672</p>";
    
    // Simple direct insert
    $stmt = $conn->prepare("
        INSERT INTO employees (employee_number, first_name, last_name, password, company_id, status, is_active) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $hashedPassword = password_hash('123456', PASSWORD_DEFAULT);
    $result = $stmt->execute(['30716129672', 'Test', 'Personel', $hashedPassword, 1, 'active', 1]);
    
    if ($result) {
        echo "<p style='color: green; font-weight: bold;'>✅ Employee 30716129672 created successfully!</p>";
        
        // Verify creation
        $verify = $conn->prepare("SELECT id, first_name, last_name, employee_number FROM employees WHERE employee_number = ?");
        $verify->execute(['30716129672']);
        $employee = $verify->fetch();
        
        if ($employee) {
            echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
            echo "<h4>Employee Created:</h4>";
            echo "<ul>";
            echo "<li>ID: {$employee['id']}</li>";
            echo "<li>Name: {$employee['first_name']} {$employee['last_name']}</li>";
            echo "<li>Number: {$employee['employee_number']}</li>";
            echo "</ul>";
            echo "<p><strong>Login with:</strong></p>";
            echo "<ul>";
            echo "<li>Employee Number: 30716129672</li>";
            echo "<li>Password: 123456</li>";
            echo "</ul>";
            echo "</div>";
            
            echo "<p><a href='auth/employee-login.php' target='_blank'>Test Login Now</a></p>";
        }
        
    } else {
        echo "<p style='color: red;'>❌ Failed to create employee</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    
    // Try even simpler approach
    echo "<p>Trying minimal approach...</p>";
    try {
        $conn->exec("
            INSERT INTO employees (employee_number, first_name, last_name, password) 
            VALUES ('30716129672', 'Test', 'Personel', '" . password_hash('123456', PASSWORD_DEFAULT) . "')
        ");
        echo "<p style='color: green;'>✅ Minimal employee created</p>";
    } catch (Exception $e2) {
        echo "<p style='color: red;'>Even minimal failed: " . $e2->getMessage() . "</p>";
        
        // Show table structure
        echo "<h4>Employee Table Structure:</h4>";
        $columns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll();
        foreach ($columns as $col) {
            echo "<p>{$col['Field']} - {$col['Type']} - " . ($col['Null'] == 'YES' ? 'NULL' : 'NOT NULL') . "</p>";
        }
    }
}
?>