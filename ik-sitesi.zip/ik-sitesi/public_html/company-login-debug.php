<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Şirket Giriş Debug ve Çözüm</h1>";
echo "<style>body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>1. Companies Tablosu Kontrolü</h3>";
    
    // Check companies table
    $stmt = $conn->query("SHOW TABLES LIKE 'companies'");
    $tableExists = $stmt->rowCount() > 0;
    
    if (!$tableExists) {
        echo "<p>❌ Companies tablosu bulunamadı. Oluşturuluyor...</p>";
        
        $createTable = "
        CREATE TABLE companies (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) DEFAULT NULL,
            company_name VARCHAR(255) NOT NULL,
            phone VARCHAR(50) DEFAULT NULL,
            address TEXT DEFAULT NULL,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        
        $conn->exec($createTable);
        echo "<p>✅ Companies tablosu oluşturuldu</p>";
    } else {
        echo "<p>✅ Companies tablosu mevcut</p>";
    }
    
    // Check table structure
    $stmt = $conn->query("SHOW COLUMNS FROM companies");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h4>Tablo Yapısı:</h4>";
    echo "<ul>";
    foreach ($columns as $col) {
        echo "<li>" . $col['Field'] . " (" . $col['Type'] . ")</li>";
    }
    echo "</ul>";
    
    echo "<h3>2. Test Şirket Verisi Kontrolü</h3>";
    
    // Check test company
    $testEmail = 'test@szb.com.tr';
    $testPassword = '123456';
    
    $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
    $stmt->execute([$testEmail]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        echo "<p>❌ Test şirket bulunamadı. Oluşturuluyor...</p>";
        
        $stmt = $conn->prepare("
            INSERT INTO companies (email, password, company_name, phone, address) 
            VALUES (?, ?, 'Test Şirket Ltd.', '555-0123', 'Test Adres, İstanbul')
        ");
        $stmt->execute([$testEmail, $testPassword]);
        
        echo "<p>✅ Test şirket oluşturuldu</p>";
        
        // Re-fetch the company
        $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
        $stmt->execute([$testEmail]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "<p>✅ Test şirket bulundu: " . htmlspecialchars($company['company_name']) . "</p>";
    }
    
    // Check password
    if ($company) {
        echo "<h4>Şifre Kontrolü:</h4>";
        
        $currentPassword = $company['password'];
        echo "<p>Mevcut şifre: " . ($currentPassword ? substr($currentPassword, 0, 10) . "..." : "BOŞ") . "</p>";
        
        $passwordTests = [
            'Plain text' => ($currentPassword === $testPassword),
            'MD5 hash' => (md5($testPassword) === $currentPassword),
            'Password hash' => password_verify($testPassword, $currentPassword)
        ];
        
        $validPassword = false;
        foreach ($passwordTests as $type => $result) {
            echo "<p>$type test: " . ($result ? '✅ GEÇER' : '❌ GEÇMEZ') . "</p>";
            if ($result) $validPassword = true;
        }
        
        if (!$validPassword) {
            echo "<p>⚠️ Şifre düzeltiliyor...</p>";
            $stmt = $conn->prepare("UPDATE companies SET password = ? WHERE id = ?");
            $stmt->execute([$testPassword, $company['id']]);
            echo "<p>✅ Şifre düz metin olarak güncellendi</p>";
        }
    }
    
    echo "<h3>3. Session Test</h3>";
    
    session_start();
    
    // Test session creation
    $_SESSION['test_company_id'] = $company['id'] ?? 1;
    $_SESSION['test_email'] = $testEmail;
    $_SESSION['test_time'] = date('Y-m-d H:i:s');
    
    echo "<p>✅ Session başlatıldı</p>";
    echo "<p>Session ID: " . session_id() . "</p>";
    echo "<p>Test değerler kaydedildi</p>";
    
    echo "<h3>4. Giriş Simülasyonu</h3>";
    
    if ($company) {
        // Simulate successful login
        $_SESSION['user_id'] = $company['id'];
        $_SESSION['company_id'] = $company['id'];
        $_SESSION['user_email'] = $company['email'];
        $_SESSION['admin_email'] = $company['email'];
        $_SESSION['company_name'] = $company['company_name'];
        $_SESSION['user_role'] = 'admin';
        $_SESSION['user_type'] = 'company';
        $_SESSION['login_type'] = 'company';
        $_SESSION['user_name'] = 'Şirket Yöneticisi';
        $_SESSION['is_admin'] = true;
        
        echo "<p>✅ Session değerleri ayarlandı:</p>";
        echo "<ul>";
        echo "<li>Company ID: " . $_SESSION['company_id'] . "</li>";
        echo "<li>Email: " . $_SESSION['user_email'] . "</li>";
        echo "<li>Company Name: " . $_SESSION['company_name'] . "</li>";
        echo "<li>User Type: " . $_SESSION['user_type'] . "</li>";
        echo "</ul>";
        
        echo "<h4>Dashboard Erişim Testi:</h4>";
        $dashboardFile = __DIR__ . '/admin/dashboard.php';
        if (file_exists($dashboardFile)) {
            echo "<p>✅ Dashboard dosyası mevcut: admin/dashboard.php</p>";
            echo "<p><a href='admin/dashboard.php' style='color: #0056b3; font-weight: bold;'>Dashboard'a Git →</a></p>";
        } else {
            echo "<p>❌ Dashboard dosyası bulunamadı</p>";
        }
    }
    
    echo "<h3>5. Giriş Sayfaları Test</h3>";
    
    $loginPages = [
        'company-login-simple.php' => 'Basit Şirket Girişi',
        'auth/company-login-fixed.php' => 'Düzeltilmiş Şirket Girişi',
        'auth/company-login.php' => 'Ana Şirket Girişi'
    ];
    
    foreach ($loginPages as $file => $name) {
        $fullPath = __DIR__ . '/' . $file;
        if (file_exists($fullPath)) {
            echo "<p>✅ <a href='$file' style='color: #0056b3;'>$name →</a></p>";
        } else {
            echo "<p>❌ $name bulunamadı ($file)</p>";
        }
    }
    
    echo "<h3>6. Çözüm Özeti</h3>";
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>✅ Şirket Girişi Hazır</h4>";
    echo "<p><strong>Test Bilgileri:</strong></p>";
    echo "<p>Email: test@szb.com.tr</p>";
    echo "<p>Şifre: 123456</p>";
    echo "<p><strong>Tavsiye edilen giriş sayfası:</strong></p>";
    echo "<p><a href='company-login-simple.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;'>Basit Şirket Girişi →</a></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Hata</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>