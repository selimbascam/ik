<?php
/**
 * Comprehensive MySQL Format Fix - Tüm PostgreSQL syntax hatalarını düzelt
 */
echo "<h2>Comprehensive MySQL Format Fix</h2>";
echo "<pre style='background: #f5f5f5; padding: 20px; border-radius: 5px; font-family: monospace;'>";

$fixedFiles = 0;
$totalIssues = 0;

echo "🔧 MySQL formatında tüm PostgreSQL syntax hatalarını düzeltiyorum...\n\n";

// PostgreSQL to MySQL syntax mappings
$sqlMappings = [
    // Date/Time functions
    "CURRENT_DATE" => "CURDATE()",
    "CURRENT_TIME" => "CURTIME()", 
    "CURRENT_TIMESTAMP" => "NOW()",
    
    // Interval syntax
    "INTERVAL '1 DAY'" => "INTERVAL 1 DAY",
    "INTERVAL '7 DAY'" => "INTERVAL 7 DAY",
    "INTERVAL '30 DAY'" => "INTERVAL 30 DAY",
    "INTERVAL '1 MONTH'" => "INTERVAL 1 MONTH",
    "INTERVAL '1 YEAR'" => "INTERVAL 1 YEAR",
    
    // Boolean values
    " true," => " 1,",
    " false," => " 0,",
    "= true" => "= 1",
    "= false" => "= 0",
    
    // String concatenation
    " || " => " CONCAT",
    
    // Limit offset syntax
    "LIMIT \$1 OFFSET \$2" => "LIMIT ?, ?",
    
    // Array syntax (if any)
    "ARRAY[" => "JSON_ARRAY(",
    
    // Double quotes to backticks for identifiers (be careful)
    '"user"' => '`user`',
    '"order"' => '`order`',
    '"group"' => '`group`',
];

// Additional specific fixes
$specificFixes = [
    // Fix INTERVAL syntax in learning recommendations
    'DATE_SUB(NOW(), INTERVAL 30 DAY)' => 'DATE_SUB(NOW(), INTERVAL 30 DAY)', // Already correct
    
    // Fix session handling
    'session_start();' => "if (session_status() === PHP_SESSION_NONE) {\n    session_start();\n}",
];

// Files to process
$targetDirs = [
    'includes/',
    'api/',
    'admin/',
    'employee/',
    'qr/',
    'super-admin/',
];

$totalFilesProcessed = 0;

foreach ($targetDirs as $dir) {
    if (!is_dir($dir)) continue;
    
    $files = glob($dir . '*.php');
    foreach ($files as $file) {
        $filename = basename($file);
        $content = file_get_contents($file);
        
        if ($content === false) {
            echo "❌ $file - Dosya okunamadı\n";
            continue;
        }
        
        $originalContent = $content;
        $issuesFound = 0;
        
        // Apply SQL mappings
        foreach ($sqlMappings as $search => $replace) {
            if (strpos($content, $search) !== false) {
                $content = str_replace($search, $replace, $content);
                $issuesFound++;
            }
        }
        
        // Apply specific fixes
        foreach ($specificFixes as $search => $replace) {
            if (strpos($content, $search) !== false && strpos($content, 'if (session_status()') === false) {
                $content = str_replace($search, $replace, $content);
                $issuesFound++;
            }
        }
        
        // Fix common PostgreSQL patterns
        $patterns = [
            // Fix LIMIT with placeholders
            '/LIMIT \$(\d+) OFFSET \$(\d+)/' => 'LIMIT ?, ?',
            
            // Fix boolean comparisons
            '/= true\b/' => '= 1',
            '/= false\b/' => '= 0',
            '/\btrue\b(?=\s*[,\)])/' => '1',
            '/\bfalse\b(?=\s*[,\)])/' => '0',
            
            // Fix string concatenation (basic cases)
            "/(['\"][^'\"]*['\"])\s*\|\|\s*(['\"][^'\"]*['\"])/" => "CONCAT($1, $2)",
        ];
        
        foreach ($patterns as $pattern => $replacement) {
            $newContent = preg_replace($pattern, $replacement, $content);
            if ($newContent !== $content) {
                $content = $newContent;
                $issuesFound++;
            }
        }
        
        // Write file if changes were made
        if ($content !== $originalContent) {
            if (file_put_contents($file, $content) !== false) {
                echo "✅ $file - $issuesFound MySQL düzeltmesi yapıldı\n";
                $fixedFiles++;
                $totalIssues += $issuesFound;
            } else {
                echo "❌ $file - Dosya yazılamadı\n";
            }
        }
        
        $totalFilesProcessed++;
    }
}

echo "\n" . str_repeat("=", 60) . "\n";
echo "📊 MYSQL FORMAT FIX ÖZET:\n";
echo "✅ İşlenen dosya sayısı: $totalFilesProcessed\n";
echo "✅ Düzeltilen dosya sayısı: $fixedFiles\n";
echo "✅ Toplam düzeltilen issue: $totalIssues\n";

// Specific critical files check
echo "\n🔍 KRİTİK DOSYALAR KONTROLÜ:\n";
$criticalFiles = [
    'includes/attendance-helper.php',
    'includes/config.php',
    'admin/company-settings.php',
    'api/icra/index.php',
    'qr/qr-reader.php'
];

foreach ($criticalFiles as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        $issues = [];
        
        // Check for common PostgreSQL syntax
        if (strpos($content, 'CURRENT_DATE') !== false && strpos($content, 'CURDATE()') === false) {
            $issues[] = 'CURRENT_DATE → CURDATE()';
        }
        if (strpos($content, '= true') !== false) {
            $issues[] = 'Boolean true → 1';
        }
        if (strpos($content, 'session_start();') !== false && strpos($content, 'session_status()') === false) {
            $issues[] = 'Session fix needed';
        }
        
        if (empty($issues)) {
            echo "✅ $file - MySQL uyumlu\n";
        } else {
            echo "⚠️ $file - Kalan issues: " . implode(', ', $issues) . "\n";
        }
    } else {
        echo "❓ $file - Dosya bulunamadı\n";
    }
}

echo "\n🎉 MySQL FORMAT FIX TAMAMLANDI!\n";
echo "\n📝 Yapılan ana düzeltmeler:\n";
echo "- PostgreSQL date functions → MySQL functions\n";
echo "- Boolean values (true/false → 1/0)\n";
echo "- Session management güvenliği\n";
echo "- INTERVAL syntax optimization\n";
echo "- String concatenation fixes\n";

?>
</pre>

<hr>
<p><strong>Bu script şunları düzeltti:</strong></p>
<ul>
    <li>PostgreSQL syntax → MySQL syntax</li>
    <li>Date/time functions compatibility</li>
    <li>Boolean value handling</li>
    <li>Session management security</li>
    <li>SQL query optimization</li>
</ul>

<p><a href="admin/company-settings.php">🔧 Test Company Settings</a> | 
   <a href="qr/qr-reader.php">📱 Test QR Reader</a> | 
   <a href="employee/dashboard.php">👤 Test Employee Dashboard</a></p>