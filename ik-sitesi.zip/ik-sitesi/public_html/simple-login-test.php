<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔐 Basit Employee Login Testi</h1>";
echo "<style>body{font-family:Arial; margin:20px;} .success{color:green;} .error{color:red;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    echo "<p class='success'>✅ Database bağlantısı başarılı</p>";
    
    // Test personel 30716129672
    $stmt = $conn->prepare("SELECT id, first_name, last_name, password FROM employees WHERE employee_number = ? OR employee_code = ? OR id = ?");
    $employee_id = "30716129672";
    $stmt->execute([$employee_id, $employee_id, $employee_id]);
    $employee = $stmt->fetch();
    
    if ($employee) {
        echo "<p class='success'>✅ Personel bulundu: " . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . "</p>";
        echo "<p>Password hash: " . substr($employee['password'], 0, 30) . "...</p>";
        
        // Test şifre
        $test_password = "Abc123456";
        if (password_verify($test_password, $employee['password'])) {
            echo "<p class='success'>✅ ŞİFRE DOĞRU! password_verify() başarılı</p>";
            
            // Session oluştur
            $_SESSION['employee_id'] = $employee['id'];
            $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
            
            echo "<p class='success'>✅ Session oluşturuldu</p>";
            echo "<p><a href='employee/dashboard.php'>→ Dashboard'a Git</a></p>";
        } else {
            echo "<p class='error'>❌ Şifre hatalı!</p>";
        }
    } else {
        echo "<p class='error'>❌ Personel bulunamadı!</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ HATA: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "<hr>";
echo "<p><a href='auth/employee-login.php'>← Employee Login</a></p>";
?>