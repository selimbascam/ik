<?php
// System Evaluation Report - Based on Analysis Results
require_once '../includes/config.php';

// Super admin check
if (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1) {
    header('Location: ../auth/super-admin-login.php');
    exit();
}

// Analysis data from uploaded file
$analysisData = [
    "generated_at" => "2025-08-10 17:39:26",
    "server_info" => [
        "php_version" => "8.1.31",
        "server_software" => "LiteSpeed",
        "host" => "szb.com.tr"
    ],
    "database" => [
        "status" => "connected",
        "tables_count" => 17,
        "companies_count" => 1,
        "employees_count" => 1,
        "attendance_records_count" => 1
    ],
    "test_results" => [
        "total_tests" => 23,
        "successful_tests" => 19,
        "failed_tests" => 4,
        "success_rate" => 82.6
    ]
];

// Calculate system health score
$healthScore = 0;

// Database connectivity (25 points)
if ($analysisData['database']['status'] === 'connected') {
    $healthScore += 25;
}

// Test success rate (50 points based on percentage)
$healthScore += ($analysisData['test_results']['success_rate'] * 0.5);

// System components (25 points)
$componentsScore = 0;
if ($analysisData['database']['tables_count'] >= 15) $componentsScore += 10; // Comprehensive tables
if ($analysisData['database']['companies_count'] >= 1) $componentsScore += 5;  // Active companies
if ($analysisData['database']['employees_count'] >= 1) $componentsScore += 5;   // Active employees
if ($analysisData['server_info']['php_version'] >= '8.0') $componentsScore += 5; // Modern PHP

$healthScore += $componentsScore;

// Determine health status
$healthStatus = 'Kritik';
$healthColor = 'red';
if ($healthScore >= 90) {
    $healthStatus = 'Mükemmel';
    $healthColor = 'green';
} elseif ($healthScore >= 80) {
    $healthStatus = 'İyi';
    $healthColor = 'blue';
} elseif ($healthScore >= 70) {
    $healthStatus = 'Orta';
    $healthColor = 'yellow';
} elseif ($healthScore >= 60) {
    $healthStatus = 'Zayıf';
    $healthColor = 'orange';
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Değerlendirme Raporu - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .health-excellent { background: linear-gradient(135deg, #10b981, #059669); }
        .health-good { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        .health-medium { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .health-poor { background: linear-gradient(135deg, #f97316, #ea580c); }
        .health-critical { background: linear-gradient(135deg, #ef4444, #dc2626); }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Sistem Değerlendirme Raporu</h1>
                    <p class="text-gray-600 mt-2">Analiz Tarihi: <?php echo $analysisData['generated_at']; ?></p>
                </div>
                <div class="text-right">
                    <div class="health-<?php echo $healthColor === 'green' ? 'excellent' : ($healthColor === 'blue' ? 'good' : ($healthColor === 'yellow' ? 'medium' : ($healthColor === 'orange' ? 'poor' : 'critical'))); ?> text-white px-6 py-3 rounded-full">
                        <div class="text-2xl font-bold"><?php echo round($healthScore); ?>%</div>
                        <div class="text-sm"><?php echo $healthStatus; ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Executive Summary -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">📊 Yönetici Özeti</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-green-50 p-4 rounded-lg">
                    <h3 class="font-semibold text-green-800">Başarılı Testler</h3>
                    <div class="text-2xl font-bold text-green-600"><?php echo $analysisData['test_results']['successful_tests']; ?>/<?php echo $analysisData['test_results']['total_tests']; ?></div>
                    <div class="text-sm text-green-600"><?php echo $analysisData['test_results']['success_rate']; ?>% başarı oranı</div>
                </div>
                <div class="bg-blue-50 p-4 rounded-lg">
                    <h3 class="font-semibold text-blue-800">Veritabanı Durumu</h3>
                    <div class="text-2xl font-bold text-blue-600">Bağlantılı</div>
                    <div class="text-sm text-blue-600"><?php echo $analysisData['database']['tables_count']; ?> tablo aktif</div>
                </div>
                <div class="bg-purple-50 p-4 rounded-lg">
                    <h3 class="font-semibold text-purple-800">Sistem Teknolojisi</h3>
                    <div class="text-2xl font-bold text-purple-600">Modern</div>
                    <div class="text-sm text-purple-600">PHP <?php echo $analysisData['server_info']['php_version']; ?> + LiteSpeed</div>
                </div>
            </div>
        </div>

        <!-- Detailed Analysis -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <!-- System Performance -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Sistem Performansı</h2>
                
                <div class="space-y-4">
                    <div>
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-sm font-medium text-gray-700">Test Başarı Oranı</span>
                            <span class="text-sm text-gray-500"><?php echo $analysisData['test_results']['success_rate']; ?>%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-green-600 h-2 rounded-full" style="width: <?php echo $analysisData['test_results']['success_rate']; ?>%"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-sm font-medium text-gray-700">Veritabanı Sağlığı</span>
                            <span class="text-sm text-gray-500">100%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-blue-600 h-2 rounded-full" style="width: 100%"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-sm font-medium text-gray-700">Teknoloji Güncelliği</span>
                            <span class="text-sm text-gray-500">95%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-purple-600 h-2 rounded-full" style="width: 95%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Components -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🔧 Sistem Bileşenleri</h2>
                
                <div class="space-y-3">
                    <div class="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                        <div>
                            <div class="font-medium text-green-800">Veritabanı Tabloları</div>
                            <div class="text-sm text-green-600">Tam kapsamlı yapı</div>
                        </div>
                        <div class="text-green-600 font-bold"><?php echo $analysisData['database']['tables_count']; ?></div>
                    </div>
                    
                    <div class="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                        <div>
                            <div class="font-medium text-blue-800">Aktif Şirketler</div>
                            <div class="text-sm text-blue-600">Kayıtlı ve aktif</div>
                        </div>
                        <div class="text-blue-600 font-bold"><?php echo $analysisData['database']['companies_count']; ?></div>
                    </div>
                    
                    <div class="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                        <div>
                            <div class="font-medium text-purple-800">Personel Kayıtları</div>
                            <div class="text-sm text-purple-600">Sistemde kayıtlı</div>
                        </div>
                        <div class="text-purple-600 font-bold"><?php echo $analysisData['database']['employees_count']; ?></div>
                    </div>
                    
                    <div class="flex justify-between items-center p-3 bg-orange-50 rounded-lg">
                        <div>
                            <div class="font-medium text-orange-800">Yoklama Kayıtları</div>
                            <div class="text-sm text-orange-600">Mevcut kayıtlar</div>
                        </div>
                        <div class="text-orange-600 font-bold"><?php echo $analysisData['database']['attendance_records_count']; ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Issues and Recommendations -->
        <div class="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <!-- Issues Found -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">⚠️ Tespit Edilen Sorunlar</h2>
                
                <div class="space-y-3">
                    <div class="flex items-start space-x-3 p-3 bg-red-50 rounded-lg">
                        <div class="text-red-500 mt-1">❌</div>
                        <div>
                            <div class="font-medium text-red-800">404 Hatası - Admin Sayfaları</div>
                            <div class="text-sm text-red-600">Bazı admin sayfalarına erişilemiyor</div>
                        </div>
                    </div>
                    
                    <div class="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
                        <div class="text-yellow-500 mt-1">⚠️</div>
                        <div>
                            <div class="font-medium text-yellow-800">QR Sistem Erişim Sorunları</div>
                            <div class="text-sm text-yellow-600">Tüm QR sistem bileşenleri erişilebilir değil</div>
                        </div>
                    </div>
                    
                    <div class="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                        <div class="text-blue-500 mt-1">ℹ️</div>
                        <div>
                            <div class="font-medium text-blue-800">Veritabanı Bakımı</div>
                            <div class="text-sm text-blue-600">Düzenli bakım önerilir</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Items -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold text-gray-900 mb-4">🎯 Öncelikli Eylemler</h2>
                
                <div class="space-y-3">
                    <div class="flex items-start space-x-3 p-3 bg-red-50 rounded-lg border-l-4 border-red-500">
                        <div class="text-red-600 font-bold">1</div>
                        <div>
                            <div class="font-medium text-red-800">Yüksek Öncelik</div>
                            <div class="text-sm text-red-600">Admin sayfası 404 hatalarını düzelt</div>
                        </div>
                    </div>
                    
                    <div class="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg border-l-4 border-yellow-500">
                        <div class="text-yellow-600 font-bold">2</div>
                        <div>
                            <div class="font-medium text-yellow-800">Orta Öncelik</div>
                            <div class="text-sm text-yellow-600">QR sistem bileşenlerini kontrol et</div>
                        </div>
                    </div>
                    
                    <div class="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                        <div class="text-blue-600 font-bold">3</div>
                        <div>
                            <div class="font-medium text-blue-800">Düşük Öncelik</div>
                            <div class="text-sm text-blue-600">Veritabanı optimizasyonu yap</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Technical Details -->
        <div class="mt-6 bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">🔍 Teknik Detaylar</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="font-medium text-gray-700">Sunucu Yazılımı</div>
                    <div class="text-lg font-bold text-gray-900"><?php echo $analysisData['server_info']['server_software']; ?></div>
                </div>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="font-medium text-gray-700">PHP Versiyonu</div>
                    <div class="text-lg font-bold text-gray-900"><?php echo $analysisData['server_info']['php_version']; ?></div>
                </div>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="font-medium text-gray-700">Ana Makine</div>
                    <div class="text-lg font-bold text-gray-900"><?php echo $analysisData['server_info']['host']; ?></div>
                </div>
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="font-medium text-gray-700">Sistem Puanı</div>
                    <div class="text-lg font-bold text-<?php echo $healthColor; ?>-600"><?php echo round($healthScore); ?>/100</div>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="mt-6 flex flex-wrap gap-4 justify-center">
            <a href="system-tools/comprehensive-analysis.php" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                🔄 Yeni Analiz Çalıştır
            </a>
            <a href="../debug/test-qr-gate-behavior.php" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors">
                🚪 QR Sistemi Test Et
            </a>
            <a href="index.php" class="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors">
                ← Super Admin Panel
            </a>
        </div>
    </div>
</body>
</html>