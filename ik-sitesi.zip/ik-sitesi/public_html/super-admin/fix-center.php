<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'system-tools/auth-check.php';

$current_page = 'fix-center';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hata Düzeltme Merkezi - Süper Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f7fa;
            color: #333;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
        }
        
        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f4f8;
        }
        
        .card-icon {
            width: 50px;
            height: 50px;
            background: #f0f4f8;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }
        
        .card-title {
            flex: 1;
        }
        
        .card-title h3 {
            font-size: 1.3rem;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .card-title .status {
            font-size: 0.85rem;
            padding: 4px 12px;
            border-radius: 20px;
            display: inline-block;
        }
        
        .status-critical {
            background: #fee;
            color: #c33;
        }
        
        .status-warning {
            background: #fff4e5;
            color: #ff6b00;
        }
        
        .status-info {
            background: #e3f2fd;
            color: #1976d2;
        }
        
        .card-body {
            margin-bottom: 20px;
        }
        
        .card-body p {
            line-height: 1.6;
            color: #566573;
            margin-bottom: 15px;
        }
        
        .problem-list {
            background: #f8f9fa;
            border-left: 4px solid #e74c3c;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        
        .problem-list h4 {
            color: #e74c3c;
            margin-bottom: 10px;
            font-size: 0.95rem;
        }
        
        .problem-list ul {
            list-style: none;
            padding: 0;
        }
        
        .problem-list li {
            padding: 5px 0;
            font-size: 0.9rem;
            color: #666;
        }
        
        .problem-list li:before {
            content: "▸ ";
            color: #e74c3c;
        }
        
        .solution-list {
            background: #f0f8ff;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }
        
        .solution-list h4 {
            color: #3498db;
            margin-bottom: 10px;
            font-size: 0.95rem;
        }
        
        .solution-list ul {
            list-style: none;
            padding: 0;
        }
        
        .solution-list li {
            padding: 5px 0;
            font-size: 0.9rem;
            color: #666;
        }
        
        .solution-list li:before {
            content: "✓ ";
            color: #27ae60;
            font-weight: bold;
        }
        
        .action-button {
            display: inline-block;
            padding: 12px 24px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            margin-right: 10px;
        }
        
        .action-button:hover {
            background: #2980b9;
            transform: translateX(2px);
        }
        
        .action-button.danger {
            background: #e74c3c;
        }
        
        .action-button.danger:hover {
            background: #c0392b;
        }
        
        .action-button.success {
            background: #27ae60;
        }
        
        .action-button.success:hover {
            background: #219a52;
        }
        
        .nav-button {
            display: inline-block;
            padding: 10px 20px;
            background: rgba(255,255,255,0.2);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .nav-button:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .category-header {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 30px 0 20px 0;
            border-left: 5px solid #3498db;
        }
        
        .category-header h2 {
            color: #2c3e50;
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 Hata Düzeltme Merkezi</h1>
            <p>Sistem hatalarını tespit edip düzelten özel araçlar</p>
            <a href="index.php" class="nav-button">← Ana Panele Dön</a>
        </div>
        
        <div class="category-header">
            <h2>🗄️ Veritabanı Düzeltmeleri</h2>
        </div>
        
        <div class="grid">
            <!-- QR Locations Fix -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">📍</div>
                    <div class="card-title">
                        <h3>QR Lokasyon Tablosu Düzeltici</h3>
                        <span class="status status-critical">Kritik</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> QR lokasyon oluşturma sırasında karşılaşılan veritabanı hatalarını düzeltir.</p>
                    
                    <div class="problem-list">
                        <h4>Düzelttiği Sorunlar:</h4>
                        <ul>
                            <li>Column not found: 'location_code' hatası</li>
                            <li>Eksik tablo sütunları (name, latitude, longitude vb.)</li>
                            <li>NULL değer hataları</li>
                            <li>Foreign key constraint hataları</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yaptığı İşlemler:</h4>
                        <ul>
                            <li>Eksik sütunları otomatik ekler</li>
                            <li>Varsayılan değerleri atar</li>
                            <li>Tablo yapısını kontrol eder</li>
                            <li>Index ve key'leri düzenler</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="../admin/fix-qr-locations-columns.php" class="action-button">Düzeltmeyi Çalıştır</a>
                    <a href="system-tools/fix-qr-locations.php" class="action-button success">Alternatif Düzeltici</a>
                </div>
            </div>
            
            <!-- Sessions Table Fix -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">🔐</div>
                    <div class="card-title">
                        <h3>Session Tablosu Düzeltici</h3>
                        <span class="status status-warning">Önemli</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> Oturum yönetimi hatalarını düzeltir ve session tablosunu onarır.</p>
                    
                    <div class="problem-list">
                        <h4>Düzelttiği Sorunlar:</h4>
                        <ul>
                            <li>Session çakışması hataları</li>
                            <li>Multiple session_start() uyarıları</li>
                            <li>Session tablosu eksikliği</li>
                            <li>Expired session temizleme</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yaptığı İşlemler:</h4>
                        <ul>
                            <li>Session tablosunu oluşturur/onarır</li>
                            <li>Eski sessionları temizler</li>
                            <li>Index'leri optimize eder</li>
                            <li>Session ayarlarını kontrol eder</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="system-tools/fix-session-table.php" class="action-button">Düzeltmeyi Çalıştır</a>
                </div>
            </div>
            
            <!-- Employee Tables Fix -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">👥</div>
                    <div class="card-title">
                        <h3>Personel Tabloları Düzeltici</h3>
                        <span class="status status-warning">Önemli</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> Personel yönetimi ile ilgili tablo hatalarını düzeltir.</p>
                    
                    <div class="problem-list">
                        <h4>Düzelttiği Sorunlar:</h4>
                        <ul>
                            <li>device_records tablosu eksikliği</li>
                            <li>employee_devices tablosu hataları</li>
                            <li>attendance_activities eksik sütunlar</li>
                            <li>Foreign key ilişki hataları</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yaptığı İşlemler:</h4>
                        <ul>
                            <li>Eksik tabloları oluşturur</li>
                            <li>İlişkileri düzeltir</li>
                            <li>Index'leri ekler</li>
                            <li>Veri bütünlüğünü kontrol eder</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="system-tools/fix-employee-tables.php" class="action-button">Düzeltmeyi Çalıştır</a>
                </div>
            </div>
            
            <!-- Database Charset Fix -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">🌐</div>
                    <div class="card-title">
                        <h3>Karakter Seti Düzeltici</h3>
                        <span class="status status-info">Bakım</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> Türkçe karakter sorunlarını ve charset hatalarını düzeltir.</p>
                    
                    <div class="problem-list">
                        <h4>Düzelttiği Sorunlar:</h4>
                        <ul>
                            <li>Türkçe karakter görüntüleme hataları</li>
                            <li>UTF-8 encoding sorunları</li>
                            <li>Collation uyumsuzlukları</li>
                            <li>Import/Export karakter hataları</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yaptığı İşlemler:</h4>
                        <ul>
                            <li>Tüm tabloları utf8mb4'e çevirir</li>
                            <li>Collation'ları düzeltir</li>
                            <li>Connection charset'i ayarlar</li>
                            <li>Mevcut verileri dönüştürür</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="system-tools/fix-charset.php" class="action-button">Düzeltmeyi Çalıştır</a>
                </div>
            </div>
        </div>
        
        <div class="category-header">
            <h2>🔧 Sistem Düzeltmeleri</h2>
        </div>
        
        <div class="grid">
            <!-- Permissions Fix -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">🔒</div>
                    <div class="card-title">
                        <h3>Dosya İzinleri Düzeltici</h3>
                        <span class="status status-warning">Önemli</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> Dosya ve klasör izin sorunlarını düzeltir.</p>
                    
                    <div class="problem-list">
                        <h4>Düzelttiği Sorunlar:</h4>
                        <ul>
                            <li>Upload klasörü yazma hataları</li>
                            <li>Log dosyası oluşturma sorunları</li>
                            <li>Cache yazma hataları</li>
                            <li>Session dosya izinleri</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yaptığı İşlemler:</h4>
                        <ul>
                            <li>Upload klasörlerini kontrol eder</li>
                            <li>Gerekli izinleri ayarlar (755/644)</li>
                            <li>Eksik klasörleri oluşturur</li>
                            <li>.htaccess dosyalarını düzenler</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="system-tools/fix-permissions.php" class="action-button">Düzeltmeyi Çalıştır</a>
                </div>
            </div>
            
            <!-- Cache Clear -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">🗑️</div>
                    <div class="card-title">
                        <h3>Önbellek Temizleyici</h3>
                        <span class="status status-info">Bakım</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> Sistem önbelleklerini temizler ve performans sorunlarını giderir.</p>
                    
                    <div class="problem-list">
                        <h4>Temizlediği Alanlar:</h4>
                        <ul>
                            <li>PHP OpCache</li>
                            <li>Session önbellekleri</li>
                            <li>Geçici dosyalar</li>
                            <li>Eski log kayıtları</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yaptığı İşlemler:</h4>
                        <ul>
                            <li>OpCache'i sıfırlar</li>
                            <li>Eski sessionları siler</li>
                            <li>Temp dosyaları temizler</li>
                            <li>Sistem performansını artırır</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="system-tools/clear-cache.php" class="action-button">Temizliği Başlat</a>
                </div>
            </div>
        </div>
        
        <div class="category-header">
            <h2>🚨 Acil Durum Araçları</h2>
        </div>
        
        <div class="grid">
            <!-- Emergency Reset -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">🚨</div>
                    <div class="card-title">
                        <h3>Acil Durum Sıfırlama</h3>
                        <span class="status status-critical">Kritik</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> Sistem kilitlenmelerinde acil müdahale sağlar.</p>
                    
                    <div class="problem-list">
                        <h4>Kullanım Durumları:</h4>
                        <ul>
                            <li>Tüm kullanıcılar giriş yapamıyor</li>
                            <li>Sistem tamamen kilitlendi</li>
                            <li>Kritik veritabanı hataları</li>
                            <li>Session corruption</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yaptığı İşlemler:</h4>
                        <ul>
                            <li>Tüm sessionları temizler</li>
                            <li>Geçici kilitlenmeleri kaldırır</li>
                            <li>Error loglarını sıfırlar</li>
                            <li>Sistemi güvenli moda alır</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="system-tools/emergency-reset.php" class="action-button danger" onclick="return confirm('DİKKAT: Bu işlem tüm aktif oturumları sonlandıracak! Devam etmek istiyor musunuz?')">Acil Sıfırlama</a>
                </div>
            </div>
            
            <!-- Database Backup -->
            <div class="card">
                <div class="card-header">
                    <div class="card-icon">💾</div>
                    <div class="card-title">
                        <h3>Veritabanı Yedekleme</h3>
                        <span class="status status-info">Bakım</span>
                    </div>
                </div>
                <div class="card-body">
                    <p><strong>Amaç:</strong> Kritik işlemler öncesi veritabanı yedeği alır.</p>
                    
                    <div class="problem-list">
                        <h4>Ne Zaman Kullanılır:</h4>
                        <ul>
                            <li>Büyük güncellemeler öncesi</li>
                            <li>Veri düzeltmeleri öncesi</li>
                            <li>Sistem değişiklikleri öncesi</li>
                            <li>Düzenli yedekleme için</li>
                        </ul>
                    </div>
                    
                    <div class="solution-list">
                        <h4>Yedeklenen Veriler:</h4>
                        <ul>
                            <li>Tüm tablo yapıları</li>
                            <li>Tüm veriler</li>
                            <li>Index ve key'ler</li>
                            <li>Stored procedures</li>
                        </ul>
                    </div>
                </div>
                <div class="card-footer">
                    <a href="system-tools/backup-database.php" class="action-button success">Yedek Al</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>