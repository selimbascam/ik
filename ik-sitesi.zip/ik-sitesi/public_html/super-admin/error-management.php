<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/error-logger.php';

// Süper admin kontrolü
if (!isset($_SESSION['super_admin'])) {
    header('Location: index.php');
    exit();
}

// AJAX istekleri
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_status':
                $result = ErrorLogger::updateStatus(
                    $_POST['error_id'], 
                    $_POST['status'], 
                    $_POST['notes'] ?? ''
                );
                echo json_encode(['success' => $result]);
                break;
                
            case 'mark_solved':
                $result = ErrorLogger::markAsSolved(
                    $_POST['error_id'], 
                    $_POST['solution'], 
                    $_SESSION['user_email'] ?? 'Super Admin'
                );
                echo json_encode(['success' => $result]);
                break;
                
            case 'export_report':
                $filters = [
                    'status' => $_POST['status_filter'] ?? null,
                    'severity' => $_POST['severity_filter'] ?? null,
                    'date_from' => $_POST['date_from'] ?? null
                ];
                
                $reportPath = ErrorLogger::exportReport(null, $filters);
                if ($reportPath) {
                    echo json_encode([
                        'success' => true, 
                        'download_url' => str_replace($_SERVER['DOCUMENT_ROOT'], '', $reportPath)
                    ]);
                } else {
                    echo json_encode(['success' => false]);
                }
                break;
        }
    }
    exit();
}

// Filtreler
$statusFilter = $_GET['status'] ?? '';
$severityFilter = $_GET['severity'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';

$filters = array_filter([
    'status' => $statusFilter ?: null,
    'severity' => $severityFilter ?: null,
    'date_from' => $dateFrom ?: null,
    'limit' => 50
]);

// Verileri al
$errors = ErrorLogger::getErrors($filters);
$stats = ErrorLogger::getErrorStats();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hata Yönetim Sistemi - SZB İK Takip</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header p { opacity: 0.9; }
        
        .nav {
            background: white;
            padding: 15px 20px;
            border-bottom: 1px solid #ddd;
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .nav a {
            color: #555;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.2s;
        }
        
        .nav a:hover { background: #f0f0f0; }
        .nav a.active { background: #667eea; color: white; }
        
        .container { max-width: 1200px; margin: 20px auto; padding: 0 20px; }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-card h3 { color: #333; margin-bottom: 10px; }
        .stat-card .number { font-size: 32px; font-weight: bold; margin-bottom: 5px; }
        .stat-card .label { color: #666; font-size: 14px; }
        
        .status-unsolved { color: #e74c3c; }
        .status-investigating { color: #f39c12; }
        .status-solved { color: #27ae60; }
        .status-ignored { color: #95a5a6; }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filters select, .filters input, .filters button {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        .btn {
            background: #667eea;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .btn:hover { background: #5a67d8; }
        .btn-export { background: #27ae60; }
        .btn-export:hover { background: #2ecc71; }
        
        .error-list {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .error-item {
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            position: relative;
        }
        
        .error-item:last-child { border-bottom: none; }
        
        .error-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
        }
        
        .error-code { font-family: monospace; font-weight: bold; color: #667eea; }
        .error-time { color: #666; font-size: 14px; }
        
        .error-message {
            background: #f8f9fa;
            padding: 15px;
            border-left: 4px solid #e74c3c;
            margin: 10px 0;
            border-radius: 0 5px 5px 0;
        }
        
        .error-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin: 15px 0;
            font-size: 14px;
        }
        
        .error-detail span {
            font-weight: bold;
            color: #333;
        }
        
        .severity {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .severity-critical { background: #e74c3c; color: white; }
        .severity-high { background: #f39c12; color: white; }
        .severity-medium { background: #3498db; color: white; }
        .severity-low { background: #95a5a6; color: white; }
        
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .status-badge.unsolved { background: #e74c3c; color: white; }
        .status-badge.investigating { background: #f39c12; color: white; }
        .status-badge.solved { background: #27ae60; color: white; }
        .status-badge.ignored { background: #95a5a6; color: white; }
        
        .error-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        
        .error-actions button {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }
        
        .toggle-details {
            background: #f8f9fa;
            color: #333;
            border: 1px solid #ddd;
        }
        
        .mark-solved { background: #27ae60; color: white; }
        .mark-investigating { background: #f39c12; color: white; }
        .mark-ignored { background: #95a5a6; color: white; }
        
        .error-context {
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin: 10px 0;
            display: none;
            font-family: monospace;
            font-size: 12px;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .solution-form {
            background: #e8f5e8;
            border: 1px solid #27ae60;
            border-radius: 5px;
            padding: 15px;
            margin: 10px 0;
            display: none;
        }
        
        .solution-form textarea {
            width: 100%;
            min-height: 80px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            resize: vertical;
        }
        
        .no-errors {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        @media (max-width: 768px) {
            .filters { flex-direction: column; align-items: stretch; }
            .error-header { flex-direction: column; gap: 10px; }
            .error-details { grid-template-columns: 1fr; }
            .error-actions { flex-wrap: wrap; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🛠️ Hata Yönetim Sistemi</h1>
        <p>Tüm sistem hatalarının otomatik kayıt ve çözüm takip merkezi</p>
    </div>
    
    <nav class="nav">
        <a href="index.php">Ana Sayfa</a>
        <a href="error-management.php" class="active">Hata Yönetimi</a>
        <a href="system-tools/comprehensive-analysis.php">Sistem Analizi</a>
        <a href="../auth/logout.php">Çıkış</a>
    </nav>
    
    <div class="container">
        <!-- İstatistikler -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="number"><?= $stats['total_errors'] ?? 0 ?></div>
                <div class="label">Toplam Hata</div>
            </div>
            <div class="stat-card">
                <div class="number status-unsolved"><?= $stats['unsolved'] ?? 0 ?></div>
                <div class="label">Çözülmedi</div>
            </div>
            <div class="stat-card">
                <div class="number status-investigating"><?= $stats['investigating'] ?? 0 ?></div>
                <div class="label">İnceleniyor</div>
            </div>
            <div class="stat-card">
                <div class="number status-solved"><?= $stats['solved'] ?? 0 ?></div>
                <div class="label">Çözüldü</div>
            </div>
            <div class="stat-card">
                <div class="number"><?= $stats['critical'] ?? 0 ?></div>
                <div class="label">Kritik Hata</div>
            </div>
        </div>
        
        <!-- Filtreler -->
        <div class="filters">
            <form method="GET" style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                <select name="status">
                    <option value="">Tüm Durumlar</option>
                    <option value="unsolved" <?= $statusFilter === 'unsolved' ? 'selected' : '' ?>>Çözülmedi</option>
                    <option value="investigating" <?= $statusFilter === 'investigating' ? 'selected' : '' ?>>İnceleniyor</option>
                    <option value="solved" <?= $statusFilter === 'solved' ? 'selected' : '' ?>>Çözüldü</option>
                    <option value="ignored" <?= $statusFilter === 'ignored' ? 'selected' : '' ?>>Göz Ardı</option>
                </select>
                
                <select name="severity">
                    <option value="">Tüm Önem Seviyeleri</option>
                    <option value="critical" <?= $severityFilter === 'critical' ? 'selected' : '' ?>>Kritik</option>
                    <option value="high" <?= $severityFilter === 'high' ? 'selected' : '' ?>>Yüksek</option>
                    <option value="medium" <?= $severityFilter === 'medium' ? 'selected' : '' ?>>Orta</option>
                    <option value="low" <?= $severityFilter === 'low' ? 'selected' : '' ?>>Düşük</option>
                </select>
                
                <input type="date" name="date_from" value="<?= htmlspecialchars($dateFrom) ?>" placeholder="Başlangıç Tarihi">
                
                <button type="submit" class="btn">Filtrele</button>
            </form>
            
            <button onclick="exportReport()" class="btn btn-export">📊 Rapor İndir</button>
        </div>
        
        <!-- Hata Listesi -->
        <div class="error-list">
            <?php if (empty($errors)): ?>
                <div class="no-errors">
                    <h3>🎉 Harika! Seçilen kriterlerde hata bulunamadı.</h3>
                    <p>Bu, sisteminizin sağlıklı çalıştığını gösterir.</p>
                </div>
            <?php else: ?>
                <?php foreach ($errors as $error): ?>
                    <div class="error-item" data-error-id="<?= $error['id'] ?>">
                        <div class="error-header">
                            <div>
                                <span class="error-code"><?= htmlspecialchars($error['error_code']) ?></span>
                                <span class="severity severity-<?= $error['severity'] ?>"><?= strtoupper($error['severity']) ?></span>
                                <span class="status-badge <?= $error['status'] ?>"><?= strtoupper($error['status']) ?></span>
                            </div>
                            <div class="error-time"><?= date('d.m.Y H:i:s', strtotime($error['created_at'])) ?></div>
                        </div>
                        
                        <div class="error-message">
                            <?= htmlspecialchars($error['error_message']) ?>
                        </div>
                        
                        <div class="error-details">
                            <?php if ($error['page_url']): ?>
                                <div class="error-detail">
                                    <span>Sayfa:</span> <?= htmlspecialchars($error['page_url']) ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($error['user_id']): ?>
                                <div class="error-detail">
                                    <span>Kullanıcı:</span> <?= htmlspecialchars($error['user_id']) ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($error['company_id']): ?>
                                <div class="error-detail">
                                    <span>Şirket ID:</span> <?= htmlspecialchars($error['company_id']) ?>
                                </div>
                            <?php endif; ?>
                            
                            <div class="error-detail">
                                <span>IP:</span> <?= htmlspecialchars($error['ip_address']) ?>
                            </div>
                        </div>
                        
                        <?php if ($error['solution_notes']): ?>
                            <div class="error-message" style="border-left-color: #27ae60; background: #e8f5e8;">
                                <strong>Çözüm:</strong> <?= htmlspecialchars($error['solution_notes']) ?>
                                <br><small>Çözen: <?= htmlspecialchars($error['solved_by']) ?> - <?= date('d.m.Y H:i', strtotime($error['solved_at'])) ?></small>
                            </div>
                        <?php endif; ?>
                        
                        <div class="error-context" id="context-<?= $error['id'] ?>">
                            <strong>Context:</strong><br>
                            <?= htmlspecialchars(json_encode(json_decode($error['error_context'], true), JSON_PRETTY_PRINT)) ?>
                            
                            <?php if ($error['stack_trace']): ?>
                                <br><br><strong>Stack Trace:</strong><br>
                                <?= htmlspecialchars($error['stack_trace']) ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="solution-form" id="solution-<?= $error['id'] ?>">
                            <h4>Çözüm Notları</h4>
                            <textarea placeholder="Bu hatanın nasıl çözüldüğünü açıklayın..."></textarea>
                            <br><br>
                            <button onclick="saveSolution(<?= $error['id'] ?>)" class="btn">Çözüm Kaydet</button>
                            <button onclick="closeSolutionForm(<?= $error['id'] ?>)" class="toggle-details">İptal</button>
                        </div>
                        
                        <div class="error-actions">
                            <button onclick="toggleDetails(<?= $error['id'] ?>)" class="toggle-details">Detayları Göster/Gizle</button>
                            
                            <?php if ($error['status'] !== 'solved'): ?>
                                <button onclick="showSolutionForm(<?= $error['id'] ?>)" class="mark-solved">Çözüldü İşaretle</button>
                                <button onclick="updateStatus(<?= $error['id'] ?>, 'investigating')" class="mark-investigating">İnceleniyor</button>
                                <button onclick="updateStatus(<?= $error['id'] ?>, 'ignored')" class="mark-ignored">Göz Ardı Et</button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function toggleDetails(errorId) {
            const context = document.getElementById('context-' + errorId);
            context.style.display = context.style.display === 'block' ? 'none' : 'block';
        }
        
        function showSolutionForm(errorId) {
            const form = document.getElementById('solution-' + errorId);
            form.style.display = 'block';
        }
        
        function closeSolutionForm(errorId) {
            const form = document.getElementById('solution-' + errorId);
            form.style.display = 'none';
        }
        
        function saveSolution(errorId) {
            const form = document.getElementById('solution-' + errorId);
            const textarea = form.querySelector('textarea');
            const solution = textarea.value.trim();
            
            if (!solution) {
                alert('Lütfen çözüm notlarını girin.');
                return;
            }
            
            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=mark_solved&error_id=${errorId}&solution=${encodeURIComponent(solution)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Çözüm kaydedilirken hata oluştu.');
                }
            });
        }
        
        function updateStatus(errorId, status) {
            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=update_status&error_id=${errorId}&status=${status}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Durum güncellenirken hata oluştu.');
                }
            });
        }
        
        function exportReport() {
            const formData = new FormData();
            formData.append('action', 'export_report');
            
            // Mevcut filtreleri ekle
            const params = new URLSearchParams(window.location.search);
            if (params.get('status')) formData.append('status_filter', params.get('status'));
            if (params.get('severity')) formData.append('severity_filter', params.get('severity'));
            if (params.get('date_from')) formData.append('date_from', params.get('date_from'));
            
            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.open(data.download_url, '_blank');
                } else {
                    alert('Rapor oluşturulurken hata oluştu.');
                }
            });
        }
        
        // Sayfa yüklendiğinde istatistikleri güncelle
        setInterval(() => {
            location.reload();
        }, 60000); // Her dakika yenile
    </script>
</body>
</html>