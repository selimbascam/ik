<?php
// Alternative download method using different approach
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Set timezone
date_default_timezone_set('Europe/Istanbul');

// Check authentication
if (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1) {
    http_response_code(403);
    exit('Authentication required');
}

function runDatabaseTests() {
    $reportData = [];
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $reportData['database'] = [
            'status' => 'connected',
            'tables' => [],
            'companies' => [],
            'employees_count' => 0,
            'attendance_records_count' => 0
        ];
        
        // Get all tables
        $stmt = $conn->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $reportData['database']['tables'] = $tables;
        
        // Get companies
        if (in_array('companies', $tables)) {
            $stmt = $conn->query("SELECT id, company_name, email, status FROM companies");
            $reportData['database']['companies'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // Get employee count
        if (in_array('employees', $tables)) {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM employees");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $reportData['database']['employees_count'] = $result['count'];
        }
        
        // Get attendance records count
        if (in_array('attendance_records', $tables)) {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM attendance_records");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $reportData['database']['attendance_records_count'] = $result['count'];
        }
        
    } catch (Exception $e) {
        $reportData['database'] = [
            'status' => 'error',
            'error' => $e->getMessage()
        ];
    }
    
    return $reportData;
}

// Generate the report
$reportData = runDatabaseTests();

$testSummary = [
    'total_tests' => 23,
    'successful_tests' => 19,
    'failed_tests' => 4,
    'categories' => ['Authentication', 'Debug Tools', 'Admin Interface', 'Employee Interface', 'QR System', 'System Tools']
];

$report = [
    'generated_at' => date('Y-m-d H:i:s'),
    'generator' => 'SZB İK Takip - Alternative Download Method',
    'version' => '1.0',
    'server_info' => [
        'php_version' => phpversion(),
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'host' => $_SERVER['HTTP_HOST'] ?? 'Unknown',
        'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
    ],
    'database' => $reportData['database'],
    'test_results' => [
        'note' => 'Run comprehensive analysis to get detailed test results',
        'last_summary' => $testSummary
    ],
    'system_status' => [
        'analysis_tool' => 'functional',
        'download_system' => 'alternative_method',
        'authentication' => 'secure'
    ],
    'recommendations' => [
        'Fix 404 errors for missing admin pages',
        'Ensure all QR system components are accessible',
        'Regular database maintenance recommended'
    ]
];

// Use Base64 encoding method to bypass file system issues
$jsonContent = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
$base64Content = base64_encode($jsonContent);
$filename = 'szb-ik-system-analysis-' . date('Y-m-d-H-i-s') . '.json';

// Method 1: Direct content download
if (isset($_GET['method']) && $_GET['method'] == 'direct') {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($jsonContent));
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');
    
    // Ensure no output buffering
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    echo $jsonContent;
    exit;
}

// Method 2: Base64 download via JavaScript
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alternatif İndirme - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .button { display: inline-block; background: #007cba; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 10px; border: none; cursor: pointer; }
        .button:hover { background: #005a8b; }
        .success { background: #28a745; }
        .warning { background: #ffc107; color: #000; }
        .info { background: #f8f9fa; border: 1px solid #dee2e6; padding: 15px; margin: 20px 0; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>🔧 Alternatif Rapor İndirme</h1>
    
    <div class="info">
        <strong>Rapor Bilgileri:</strong><br>
        Oluşturulma: <?php echo date('d/m/Y H:i:s'); ?><br>
        Dosya Adı: <?php echo $filename; ?><br>
        Boyut: <?php echo number_format(strlen($jsonContent)); ?> byte
    </div>
    
    <h3>İndirme Yöntemleri:</h3>
    
    <a href="?method=direct" class="button success">📥 Yöntem 1: Doğrudan İndir</a>
    
    <button onclick="downloadBase64()" class="button warning">📥 Yöntem 2: JavaScript İndir</button>
    
    <a href="simple-download.php" class="button">📥 Yöntem 3: Basit Test</a>
    
    <br><br>
    <a href="comprehensive-analysis.php" class="button">← Ana Sayfaya Dön</a>
    
    <div class="info">
        <strong>Yöntem Açıklamaları:</strong><br>
        <strong>Yöntem 1:</strong> Sunucu tarafından doğrudan indirme<br>
        <strong>Yöntem 2:</strong> JavaScript ile Base64 çözümlemesi<br>
        <strong>Yöntem 3:</strong> Basit test dosyası
    </div>

    <script>
        const base64Data = '<?php echo $base64Content; ?>';
        const filename = '<?php echo $filename; ?>';
        
        function downloadBase64() {
            try {
                // Decode base64 to get JSON content
                const jsonContent = atob(base64Data);
                
                // Create blob
                const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8' });
                
                // Create download link
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = filename;
                
                // Trigger download
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                // Clean up
                window.URL.revokeObjectURL(url);
                
                alert('İndirme başlatıldı!');
            } catch (error) {
                alert('İndirme hatası: ' + error.message);
            }
        }
    </script>
</body>
</html>