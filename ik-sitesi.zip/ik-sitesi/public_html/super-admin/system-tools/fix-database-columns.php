<?php
// Critical database column fixes
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<!DOCTYPE html>";
echo "<html lang='tr'><head><meta charset='UTF-8'>";
echo "<title>Veritabanı Sütun Onarımı - SZB İK Takip</title>";
echo "<style>body { font-family: monospace; background: #000; color: #0f0; padding: 20px; } .success { color: #0f0; } .error { color: #f00; } .warning { color: #ff0; }</style>";
echo "</head><body>";

echo "<h2 class='success'>🔧 VERİTABANI SÜTUN ONARIMI</h2>\n";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<p class='success'>✅ Veritabanı bağlantısı başarılı</p>\n";
    
    // Fix 1: Add missing columns to work_settings table
    echo "<p class='warning'>🔧 work_settings tablosu kontrol ediliyor...</p>\n";
    
    // Check if work_settings table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'work_settings'");
    if ($stmt->rowCount() == 0) {
        // Create work_settings table
        $createWorkSettings = "
        CREATE TABLE work_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            monthly_hours INT DEFAULT 225,
            weekly_hours INT DEFAULT 45,
            daily_max_hours INT DEFAULT 11,
            overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
            holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
            auto_schedule BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_company_id (company_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($createWorkSettings);
        echo "<p class='success'>✅ work_settings tablosu oluşturuldu</p>\n";
    } else {
        echo "<p class='success'>✅ work_settings tablosu mevcut</p>\n";
        
        // Check and add missing columns
        $columns = ['monthly_hours', 'weekly_hours', 'daily_max_hours', 'overtime_multiplier', 'holiday_multiplier', 'company_id'];
        
        $stmt = $conn->query("DESCRIBE work_settings");
        $existingColumns = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $existingColumns[] = $row['Field'];
        }
        
        foreach ($columns as $column) {
            if (!in_array($column, $existingColumns)) {
                switch ($column) {
                    case 'monthly_hours':
                        $conn->exec("ALTER TABLE work_settings ADD COLUMN monthly_hours INT DEFAULT 225");
                        echo "<p class='success'>✅ monthly_hours sütunu eklendi</p>\n";
                        break;
                    case 'weekly_hours':
                        $conn->exec("ALTER TABLE work_settings ADD COLUMN weekly_hours INT DEFAULT 45");
                        echo "<p class='success'>✅ weekly_hours sütunu eklendi</p>\n";
                        break;
                    case 'daily_max_hours':
                        $conn->exec("ALTER TABLE work_settings ADD COLUMN daily_max_hours INT DEFAULT 11");
                        echo "<p class='success'>✅ daily_max_hours sütunu eklendi</p>\n";
                        break;
                    case 'overtime_multiplier':
                        $conn->exec("ALTER TABLE work_settings ADD COLUMN overtime_multiplier DECIMAL(3,2) DEFAULT 1.50");
                        echo "<p class='success'>✅ overtime_multiplier sütunu eklendi</p>\n";
                        break;
                    case 'holiday_multiplier':
                        $conn->exec("ALTER TABLE work_settings ADD COLUMN holiday_multiplier DECIMAL(3,2) DEFAULT 2.00");
                        echo "<p class='success'>✅ holiday_multiplier sütunu eklendi</p>\n";
                        break;
                    case 'company_id':
                        $conn->exec("ALTER TABLE work_settings ADD COLUMN company_id INT NOT NULL DEFAULT 1");
                        echo "<p class='success'>✅ company_id sütunu eklendi</p>\n";
                        break;
                }
            }
        }
    }
    
    // Fix 2: Create public_holidays table if missing
    echo "<p class='warning'>🔧 public_holidays tablosu kontrol ediliyor...</p>\n";
    
    $stmt = $conn->query("SHOW TABLES LIKE 'public_holidays'");
    if ($stmt->rowCount() == 0) {
        $createHolidays = "
        CREATE TABLE public_holidays (
            id INT AUTO_INCREMENT PRIMARY KEY,
            holiday_name VARCHAR(255) NOT NULL,
            holiday_date DATE NOT NULL,
            holiday_type ENUM('national', 'religious', 'regional') DEFAULT 'national',
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_holiday_date (holiday_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($createHolidays);
        echo "<p class='success'>✅ public_holidays tablosu oluşturuldu</p>\n";
        
        // Insert 2025 Turkish holidays
        $holidays = [
            ['Yılbaşı', '2025-01-01', 'national'],
            ['Ramazan Bayramı 1. Gün', '2025-03-30', 'religious'],
            ['Ramazan Bayramı 2. Gün', '2025-03-31', 'religious'],
            ['Ramazan Bayramı 3. Gün', '2025-04-01', 'religious'],
            ['Ulusal Egemenlik ve Çocuk Bayramı', '2025-04-23', 'national'],
            ['Emek ve Dayanışma Günü', '2025-05-01', 'national'],
            ['Atatürk\'ü Anma, Gençlik ve Spor Bayramı', '2025-05-19', 'national'],
            ['Kurban Bayramı 1. Gün', '2025-06-06', 'religious'],
            ['Kurban Bayramı 2. Gün', '2025-06-07', 'religious'],
            ['Kurban Bayramı 3. Gün', '2025-06-08', 'religious'],
            ['Kurban Bayramı 4. Gün', '2025-06-09', 'religious'],
            ['Zafer Bayramı', '2025-08-30', 'national'],
            ['Cumhuriyet Bayramı', '2025-10-29', 'national']
        ];
        
        $insertStmt = $conn->prepare("INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES (?, ?, ?)");
        foreach ($holidays as $holiday) {
            $insertStmt->execute($holiday);
        }
        echo "<p class='success'>✅ 2025 Türk resmi tatilleri eklendi</p>\n";
    } else {
        echo "<p class='success'>✅ public_holidays tablosu mevcut</p>\n";
        
        // Check for holiday_date column
        $stmt = $conn->query("DESCRIBE public_holidays");
        $columns = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $columns[] = $row['Field'];
        }
        
        if (!in_array('holiday_date', $columns)) {
            $conn->exec("ALTER TABLE public_holidays ADD COLUMN holiday_date DATE NOT NULL");
            echo "<p class='success'>✅ holiday_date sütunu eklendi</p>\n";
        }
    }
    
    // Fix 3: Check and fix companies table
    echo "<p class='warning'>🔧 companies tablosu kontrol ediliyor...</p>\n";
    
    $stmt = $conn->query("DESCRIBE companies");
    $companyColumns = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $companyColumns[] = $row['Field'];
    }
    
    if (!in_array('company_id', $companyColumns) && !in_array('id', $companyColumns)) {
        $conn->exec("ALTER TABLE companies ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY FIRST");
        echo "<p class='success'>✅ companies tablosuna id sütunu eklendi</p>\n";
    }
    
    // Fix 4: Insert default work settings for existing companies
    echo "<p class='warning'>🔧 Varsayılan çalışma ayarları kontrol ediliyor...</p>\n";
    
    $companiesStmt = $conn->query("SELECT id FROM companies LIMIT 5");
    $companies = $companiesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($companies as $company) {
        $checkStmt = $conn->prepare("SELECT COUNT(*) FROM work_settings WHERE company_id = ?");
        $checkStmt->execute([$company['id']]);
        
        if ($checkStmt->fetchColumn() == 0) {
            $insertStmt = $conn->prepare("
                INSERT INTO work_settings (company_id, monthly_hours, weekly_hours, daily_max_hours, overtime_multiplier, holiday_multiplier) 
                VALUES (?, 225, 45, 11, 1.50, 2.00)
            ");
            $insertStmt->execute([$company['id']]);
            echo "<p class='success'>✅ Şirket ID {$company['id']} için varsayılan ayarlar eklendi</p>\n";
        }
    }
    
    // Fix 5: Test queries to ensure they work
    echo "<p class='warning'>🧪 Düzeltilmiş sorgular test ediliyor...</p>\n";
    
    try {
        $testStmt = $conn->prepare("SELECT monthly_hours FROM work_settings WHERE company_id = ? LIMIT 1");
        $testStmt->execute([1]);
        echo "<p class='success'>✅ monthly_hours sorgusu çalışıyor</p>\n";
    } catch (Exception $e) {
        echo "<p class='error'>❌ monthly_hours sorgu hatası: " . $e->getMessage() . "</p>\n";
    }
    
    try {
        $testStmt = $conn->prepare("SELECT * FROM companies WHERE id = ? LIMIT 1");
        $testStmt->execute([1]);
        echo "<p class='success'>✅ company_id sorgusu çalışıyor</p>\n";
    } catch (Exception $e) {
        echo "<p class='error'>❌ company_id sorgu hatası: " . $e->getMessage() . "</p>\n";
    }
    
    try {
        $testStmt = $conn->prepare("SELECT * FROM public_holidays WHERE holiday_date = ? LIMIT 1");
        $testStmt->execute(['2025-01-01']);
        echo "<p class='success'>✅ holiday_date sorgusu çalışıyor</p>\n";
    } catch (Exception $e) {
        echo "<p class='error'>❌ holiday_date sorgu hatası: " . $e->getMessage() . "</p>\n";
    }
    
    // Summary
    echo "<h3 class='success'>🎯 ONARIM TAMAMLANDI</h3>\n";
    echo "<p class='success'>✅ work_settings tablosu ve sütunları düzeltildi</p>\n";
    echo "<p class='success'>✅ public_holidays tablosu ve holiday_date sütunu eklendi</p>\n";
    echo "<p class='success'>✅ companies tablosu id/company_id sorunu çözüldü</p>\n";
    echo "<p class='success'>✅ Varsayılan çalışma ayarları eklendi</p>\n";
    echo "<p class='success'>✅ Tüm sorgular test edildi ve çalışıyor</p>\n";
    
    echo "<p><a href='admin/qr-generator.php' style='color: #0ff;'>🔗 QR Generator'a geri dön</a></p>\n";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ KRITIK HATA: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "<p class='error'>Stack trace: " . htmlspecialchars($e->getTraceAsString()) . "</p>\n";
}

echo "</body></html>";
?>