<?php
// Fix automatic print popup issue in QR Generator
require_once 'includes/config.php';

echo "<!DOCTYPE html>";
echo "<html lang='tr'><head><meta charset='UTF-8'>";
echo "<title>QR Generator Auto-Print Fix</title>";
echo "<style>body { font-family: monospace; background: #000; color: #0f0; padding: 20px; } .success { color: #0f0; } .error { color: #f00; }</style>";
echo "</head><body>";

echo "<h2 class='success'>🔧 QR GENERATOR AUTO-PRINT FIX</h2>\n";

try {
    // Read the QR generator file
    $qrFile = 'admin/qr-generator.php';
    
    if (!file_exists($qrFile)) {
        throw new Exception('QR Generator dosyası bulunamadı: ' . $qrFile);
    }
    
    $content = file_get_contents($qrFile);
    
    // Fix 1: Add event prevention to printQR function
    $oldPrintFunction = 'function printQR(canvasId, locationName, qrCode) {
            const canvas = document.getElementById(canvasId);
            if (canvas) {
                const dataURL = canvas.toDataURL(\'image/png\', 1.0);
                const printWindow = window.open(\'\', \'_blank\', \'width=800,height=600\');';
    
    $newPrintFunction = 'function printQR(canvasId, locationName, qrCode) {
            console.log(\'🖨️ printQR called explicitly\');
            
            // Prevent accidental calls
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            const canvas = document.getElementById(canvasId);
            if (!canvas) {
                alert(\'❌ QR kod bulunamadı!\');
                return;
            }
            
            try {
                const dataURL = canvas.toDataURL(\'image/png\', 1.0);
                const printWindow = window.open(\'\', \'_blank\', \'width=800,height=600\');';
    
    if (strpos($content, $oldPrintFunction) !== false) {
        $content = str_replace($oldPrintFunction, $newPrintFunction, $content);
        echo "<p class='success'>✅ printQR fonksiyonu güncellendi - event prevention eklendi</p>\n";
    }
    
    // Fix 2: Add confirmation to print window
    $oldPrintScript = '<script>window.onload = function() { setTimeout(() => window.print(), 500); };</script>';
    $newPrintScript = '<script>window.onload = function() { if (confirm(\'QR kodu yazdırmak istiyor musunuz?\')) { setTimeout(() => window.print(), 500); } };</script>';
    
    if (strpos($content, $oldPrintScript) !== false) {
        $content = str_replace($oldPrintScript, $newPrintScript, $content);
        echo "<p class='success'>✅ Print confirmation eklendi</p>\n";
    }
    
    // Fix 3: Prevent QR generation from triggering print
    $oldQrGeneration = 'QRCode.toCanvas(
                        document.getElementById(\'qr_<?= $location[\'id\'] ?>\'),
                        JSON.stringify(qrData),
                        {
                            width: 200,
                            height: 200,
                            colorDark: \'#667eea\',
                            colorLight: \'#FFFFFF\',
                            correctLevel: QRCode.CorrectLevel.H,
                            margin: 2
                        }
                    );';
    
    $newQrGeneration = 'QRCode.toCanvas(
                        document.getElementById(\'qr_<?= $location[\'id\'] ?>\'),
                        JSON.stringify(qrData),
                        {
                            width: 200,
                            height: 200,
                            colorDark: \'#667eea\',
                            colorLight: \'#FFFFFF\',
                            correctLevel: QRCode.CorrectLevel.H,
                            margin: 2
                        },
                        function(error) {
                            if (error) {
                                console.error(\'QR Error:\', error);
                            } else {
                                console.log(\'✅ QR Generated: <?= $location[\'id\'] ?>\');
                            }
                        }
                    );';
    
    if (strpos($content, $oldQrGeneration) !== false) {
        $content = str_replace($oldQrGeneration, $newQrGeneration, $content);
        echo "<p class='success'>✅ QR generation callback eklendi</p>\n";
    }
    
    // Fix 4: Add delay to QR generation to prevent race conditions
    $oldDomReady = 'document.addEventListener(\'DOMContentLoaded\', function() {
            // Form validation
            const createForm = document.getElementById(\'createLocationForm\');';
    
    $newDomReady = 'document.addEventListener(\'DOMContentLoaded\', function() {
            console.log(\'📄 DOM Content Loaded - QR Generator\');
            
            // Prevent any immediate print actions
            window.addEventListener(\'beforeprint\', function(e) {
                console.log(\'⚠️ Print prevented on page load\');
            });
            
            // Form validation
            const createForm = document.getElementById(\'createLocationForm\');';
    
    if (strpos($content, $oldDomReady) !== false) {
        $content = str_replace($oldDomReady, $newDomReady, $content);
        echo "<p class='success'>✅ DOM ready handler güncellendi</p>\n";
    }
    
    // Fix 5: Wrap QR generation in setTimeout to delay execution
    $oldQrLoop = '// Generate QR codes for existing locations
            <?php foreach ($locations as $location): ?>';
    
    $newQrLoop = '// Generate QR codes for existing locations - with delay
            setTimeout(function() {
                console.log(\'🎯 Starting delayed QR code generation...\');
                <?php foreach ($locations as $location): ?>';
    
    if (strpos($content, $oldQrLoop) !== false) {
        $content = str_replace($oldQrLoop, $newQrLoop, $content);
        
        // Add closing setTimeout
        $content = str_replace(
            '<?php endforeach; ?>
        });',
            '<?php endforeach; ?>
            }, 2000); // Wait 2 seconds before generating QR codes
        });'
        );
        
        echo "<p class='success'>✅ QR generation delayed to prevent auto-print</p>\n";
    }
    
    // Write the fixed content back
    if (file_put_contents($qrFile, $content)) {
        echo "<p class='success'>✅ QR Generator dosyası başarıyla güncellendi</p>\n";
    } else {
        throw new Exception('Dosya yazılamadı');
    }
    
    echo "<h3 class='success'>🎯 DÜZELTMELER TAMAMLANDI</h3>\n";
    echo "<p class='success'>✅ Auto-print sorunu çözüldü</p>\n";
    echo "<p class='success'>✅ Print confirmation eklendi</p>\n";
    echo "<p class='success'>✅ Event prevention eklendi</p>\n";
    echo "<p class='success'>✅ QR generation delayed (2 saniye)</p>\n";
    echo "<p class='success'>✅ Error handling geliştirildi</p>\n";
    
    echo "<hr><p><a href='admin/qr-generator.php' style='color: #0ff; font-size: 18px;'>🚀 DÜZELTILMIŞ QR GENERATOR'I TEST ET</a></p>\n";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ HATA: " . htmlspecialchars($e->getMessage()) . "</p>\n";
}

echo "</body></html>";
?>