<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔍 Ana QR Generator Debug</h2>";
echo "<p><strong>Dosya:</strong> admin/qr-generator.php</p>";

// Test file existence and size
$file = 'admin/qr-generator.php';
if (file_exists($file)) {
    $size = filesize($file);
    echo "<p>✅ Dosya mevcut - Boyut: " . number_format($size) . " bytes</p>";
    
    // Check last modification
    $modTime = filemtime($file);
    echo "<p>📅 Son düzenleme: " . date('Y-m-d H:i:s', $modTime) . "</p>";
    
    // Check if it's the working version
    $content = file_get_contents($file);
    if (strpos($content, 'QRCode library ready!') !== false) {
        echo "<p>✅ Çalışan versiyon algılandı (retry sistemi var)</p>";
    } else {
        echo "<p>⚠️ Eski versiyon olabilir</p>";
    }
    
    if (strpos($content, 'json_encode($locations)') !== false) {
        echo "<p>✅ JSON encoding sistemi var</p>";
    } else {
        echo "<p>❌ PHP foreach döngüsü problemi olabilir</p>";
    }
    
    // Check canvas attributes
    if (strpos($content, 'width="200" height="200"') !== false) {
        echo "<p>✅ Canvas boyutları düzeltilmiş</p>";
    } else {
        echo "<p>❌ Canvas boyut problemi</p>";
    }
    
    // Check JavaScript functions
    if (strpos($content, 'downloadQR(locationId)') !== false) {
        echo "<p>✅ Download fonksiyonu güncel</p>";
    } else {
        echo "<p>❌ Download fonksiyonu eski</p>";
    }
    
} else {
    echo "<p>❌ Dosya bulunamadı!</p>";
}

echo "<hr>";
echo "<h3>📋 Test Linkler:</h3>";
echo "<ul>";
echo "<li><a href='admin/qr-generator.php'>Ana QR Generator</a></li>";
echo "<li><a href='admin/qr-generator-working.php'>Çalışan Versiyon</a></li>";
echo "<li><a href='test-qr-working.php'>QR Test Sayfası</a></li>";
echo "</ul>";

// Database test
if (isset($_SESSION['company_id'])) {
    echo "<h3>🗃️ Database Test:</h3>";
    try {
        $db = new Database();
        $conn = $db->getConnection();
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE company_id = ?");
        $stmt->execute([$_SESSION['company_id']]);
        $count = $stmt->fetch()['count'];
        echo "<p>📍 Toplam QR lokasyon: {$count}</p>";
    } catch (Exception $e) {
        echo "<p>❌ Database hatası: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>⚠️ Session yok - login gerekli</p>";
}
?>