<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Database Emergency Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Current companies table structure:</h3>";
    try {
        $stmt = $conn->query("DESCRIBE companies");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<pre>";
        foreach ($columns as $column) {
            echo $column['Field'] . " - " . $column['Type'] . "\n";
        }
        echo "</pre>";
        
        // Check which columns are missing
        $existingColumns = array_column($columns, 'Field');
        $requiredColumns = ['company_code', 'company_type', 'status', 'created_at'];
        $missingColumns = array_diff($requiredColumns, $existingColumns);
        
        echo "<h3>Missing columns: " . implode(', ', $missingColumns) . "</h3>";
        
        // Add missing columns one by one
        if (in_array('company_code', $missingColumns)) {
            echo "Adding company_code column...<br>";
            $conn->exec("ALTER TABLE companies ADD COLUMN company_code VARCHAR(10) UNIQUE AFTER company_name");
            echo "✓ company_code added<br>";
        }
        
        if (in_array('company_type', $missingColumns)) {
            echo "Adding company_type column...<br>";
            $conn->exec("ALTER TABLE companies ADD COLUMN company_type ENUM('corporate', 'individual') DEFAULT 'corporate' AFTER tax_number");
            echo "✓ company_type added<br>";
        }
        
        if (in_array('status', $missingColumns)) {
            echo "Adding status column...<br>";
            $conn->exec("ALTER TABLE companies ADD COLUMN status VARCHAR(20) DEFAULT 'active' AFTER company_type");
            echo "✓ status added<br>";
        }
        
        if (in_array('created_at', $missingColumns)) {
            echo "Adding created_at column...<br>";
            $conn->exec("ALTER TABLE companies ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP AFTER status");
            echo "✓ created_at added<br>";
        }
        
        echo "<h3>Updated table structure:</h3>";
        $stmt = $conn->query("DESCRIBE companies");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<pre>";
        foreach ($columns as $column) {
            echo $column['Field'] . " - " . $column['Type'] . "\n";
        }
        echo "</pre>";
        
        // Update existing companies with auto-generated codes
        echo "<h3>Updating existing companies with codes...</h3>";
        $stmt = $conn->query("SELECT id, company_name FROM companies WHERE company_code IS NULL OR company_code = ''");
        $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $codeCounter = 1;
        foreach ($companies as $company) {
            $newCode = 'AAA' . str_pad($codeCounter, 5, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE companies SET company_code = ? WHERE id = ?");
            $updateStmt->execute([$newCode, $company['id']]);
            echo "Updated company '{$company['company_name']}' with code: $newCode<br>";
            $codeCounter++;
        }
        
        echo "<h3>✅ Database fix completed successfully!</h3>";
        
    } catch (PDOException $e) {
        echo "<h3>❌ Error: " . $e->getMessage() . "</h3>";
    }
    
} catch (Exception $e) {
    echo "<h3>❌ Connection error: " . $e->getMessage() . "</h3>";
}

echo "<p><a href='admin/company-setup.php'>← Back to Company Setup</a></p>";
echo "<p><a href='super-admin/'>← Back to Super Admin</a></p>";
?>