<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🚨 Acil Veritabanı Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>1️⃣ Employees Tablosu Kontrolü</h2>";
    
    // Check if password column exists
    $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'password'");
    $password_column = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$password_column) {
        echo "<div style='color: red;'>❌ Password sütunu yok, ekleniyor...</div>";
        $conn->exec("ALTER TABLE employees ADD COLUMN password VARCHAR(255) AFTER email");
        echo "<div style='color: green;'>✅ Password sütunu eklendi</div>";
    } else {
        echo "<div style='color: green;'>✅ Password sütunu var</div>";
    }
    
    echo "<h2>2️⃣ Companies Tablosu Kontrolü</h2>";
    
    // Check if company_name column exists
    $stmt = $conn->query("SHOW COLUMNS FROM companies LIKE 'company_name'");
    $company_name_column = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company_name_column) {
        echo "<div style='color: red;'>❌ company_name sütunu yok, ekleniyor...</div>";
        $conn->exec("ALTER TABLE companies ADD COLUMN company_name VARCHAR(255) AFTER id");
        echo "<div style='color: green;'>✅ company_name sütunu eklendi</div>";
    } else {
        echo "<div style='color: green;'>✅ company_name sütunu var</div>";
    }
    
    echo "<h2>3️⃣ Test Verisi Kontrolü</h2>";
    
    // Check if we have any companies
    $stmt = $conn->query("SELECT COUNT(*) as count FROM companies");
    $company_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($company_count == 0) {
        echo "<div style='color: orange;'>⚠️ Hiç şirket yok, demo şirket ekleniyor...</div>";
        $stmt = $conn->prepare("INSERT INTO companies (company_name, company_code, email, status) VALUES (?, ?, ?, 'active')");
        $stmt->execute(['Demo Şirket', 'DEMO001', 'info@demo.com']);
        echo "<div style='color: green;'>✅ Demo şirket eklendi</div>";
    }
    
    // Get company ID
    $stmt = $conn->query("SELECT id FROM companies LIMIT 1");
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    $company_id = $company['id'];
    
    // Check if we have any employees
    $stmt = $conn->query("SELECT COUNT(*) as count FROM employees");
    $employee_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($employee_count == 0) {
        echo "<div style='color: orange;'>⚠️ Hiç personel yok, demo personel ekleniyor...</div>";
        
        $demo_employees = [
            ['EMP001', 'Ahmet', 'Yılmaz', 'ahmet@demo.com', 'demo123'],
            ['EMP002', 'Ayşe', 'Kaya', 'ayse@demo.com', 'demo123'],
            ['EMP003', 'Mehmet', 'Demir', 'mehmet@demo.com', 'demo123']
        ];
        
        foreach ($demo_employees as $emp) {
            $stmt = $conn->prepare("
                INSERT INTO employees 
                (company_id, employee_number, first_name, last_name, email, password, status, hire_date) 
                VALUES (?, ?, ?, ?, ?, SHA2(?, 256), 'active', CURDATE())
            ");
            $stmt->execute([$company_id, $emp[0], $emp[1], $emp[2], $emp[3], $emp[4]]);
            echo "<div style='color: green;'>✅ {$emp[1]} {$emp[2]} eklendi (No: {$emp[0]}, Şifre: {$emp[4]})</div>";
        }
    } else {
        echo "<div style='color: green;'>✅ Personel verisi var ($employee_count kayıt)</div>";
        
        // Update existing employees to have passwords
        $stmt = $conn->exec("UPDATE employees SET password = SHA2('demo123', 256) WHERE password IS NULL OR password = ''");
        echo "<div style='color: green;'>✅ Şifresiz personellere şifre atandı</div>";
    }
    
    echo "<h2>4️⃣ Final Test</h2>";
    
    // Test the exact query from employee-login.php
    $stmt = $conn->prepare("
        SELECT e.id, e.first_name, e.last_name, e.email, e.employee_number, 
               e.company_id, c.company_name, c.company_code
        FROM employees e 
        JOIN companies c ON e.company_id = c.id 
        WHERE e.employee_number = ? AND e.password = SHA2(?, 256) AND e.status = 'active'
        LIMIT 1
    ");
    $stmt->execute(['EMP001', 'demo123']);
    $test_result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($test_result) {
        echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
        echo "<h3>✅ BAŞARILI! Personel girişi çalışıyor</h3>";
        echo "<p><strong>Test Sonucu:</strong></p>";
        echo "<pre>" . print_r($test_result, true) . "</pre>";
        echo "<p><strong>Giriş Bilgileri:</strong></p>";
        echo "<ul>";
        echo "<li>Personel No: EMP001</li>";
        echo "<li>Şifre: demo123</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
        echo "<h3>❌ Test başarısız</h3>";
        echo "<p>Sorgu sonuç döndürmedi.</p>";
        echo "</div>";
    }
    
    // Show all employees for reference
    echo "<h2>5️⃣ Tüm Personel Listesi</h2>";
    $stmt = $conn->query("
        SELECT e.employee_number, e.first_name, e.last_name, e.email, 
               c.company_name, e.status,
               CASE WHEN e.password IS NOT NULL THEN 'VAR' ELSE 'YOK' END as password_status
        FROM employees e 
        LEFT JOIN companies c ON e.company_id = c.id
    ");
    $all_employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($all_employees) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Personel No</th><th>Ad Soyad</th><th>Email</th><th>Şirket</th><th>Durum</th><th>Şifre</th></tr>";
        foreach ($all_employees as $emp) {
            echo "<tr>";
            echo "<td><strong>{$emp['employee_number']}</strong></td>";
            echo "<td>{$emp['first_name']} {$emp['last_name']}</td>";
            echo "<td>{$emp['email']}</td>";
            echo "<td>{$emp['company_name']}</td>";
            echo "<td>{$emp['status']}</td>";
            echo "<td style='color: " . ($emp['password_status'] === 'VAR' ? 'green' : 'red') . ";'>{$emp['password_status']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ Kritik Hata</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div style='text-align: center; margin: 20px 0;'>";
echo "<a href='auth/employee-login.php' style='background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-size: 18px;'>🚀 ŞİMDİ PERSONEL GİRİŞİ TEST ET</a>";
echo "</div>";
?>