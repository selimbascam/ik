<?php
// Debug download issues
require_once '../../includes/config.php';

// Check authentication
if (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1) {
    die('Authentication required');
}

echo "<h2>Download Debug Information</h2>";

// Check PHP extensions
echo "<h3>PHP Extensions:</h3>";
echo "ZipArchive available: " . (class_exists('ZipArchive') ? 'YES' : 'NO') . "<br>";

// Check directory permissions
$testDir = dirname(__FILE__) . '/temp_reports/';
echo "<h3>Directory Information:</h3>";
echo "Test directory: " . $testDir . "<br>";
echo "Directory exists: " . (is_dir($testDir) ? 'YES' : 'NO') . "<br>";
echo "Directory writable: " . (is_writable(dirname(__FILE__)) ? 'YES' : 'NO') . "<br>";

// Try creating test directory
if (!is_dir($testDir)) {
    $created = mkdir($testDir, 0755, true);
    echo "Directory creation: " . ($created ? 'SUCCESS' : 'FAILED') . "<br>";
} else {
    echo "Directory writable: " . (is_writable($testDir) ? 'YES' : 'NO') . "<br>";
}

// Test file creation
$testFile = $testDir . 'test.txt';
$testResult = file_put_contents($testFile, 'test content');
echo "Test file creation: " . ($testResult !== false ? 'SUCCESS' : 'FAILED') . "<br>";

if (file_exists($testFile)) {
    echo "Test file readable: " . (is_readable($testFile) ? 'YES' : 'NO') . "<br>";
    unlink($testFile);
}

// Test ZIP creation
if (class_exists('ZipArchive')) {
    $zip = new ZipArchive();
    $zipFile = $testDir . 'test.zip';
    $result = $zip->open($zipFile, ZipArchive::CREATE);
    echo "<h3>ZIP Test:</h3>";
    echo "ZIP open result: " . $result . " (TRUE=" . ZipArchive::CREATE . ")<br>";
    
    if ($result === TRUE) {
        $zip->addFromString('test.txt', 'Test content');
        $closeResult = $zip->close();
        echo "ZIP close result: " . ($closeResult ? 'SUCCESS' : 'FAILED') . "<br>";
        
        if (file_exists($zipFile)) {
            echo "ZIP file created: YES<br>";
            echo "ZIP file size: " . filesize($zipFile) . " bytes<br>";
            unlink($zipFile);
        } else {
            echo "ZIP file created: NO<br>";
        }
    }
}

// Test alternative simple download
echo "<h3>Alternative Download Test:</h3>";
echo '<a href="simple-download.php">Test Simple JSON Download</a><br>';

// Clean up
if (is_dir($testDir) && count(scandir($testDir)) == 2) {
    rmdir($testDir);
}
?>