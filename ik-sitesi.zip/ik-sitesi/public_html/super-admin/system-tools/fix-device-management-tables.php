<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();

    echo "<h1>🛡️ Cihaz Yönetimi Database Düzeltmeleri</h1>";

    // Check which device-related tables exist
    $deviceTables = ['employee_devices', 'device_records', 'device_security_logs'];
    $existingTables = [];
    
    echo "<h2>1️⃣ Mevcut Tablo Kontrolü</h2>";
    
    foreach ($deviceTables as $table) {
        $stmt = $conn->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$table]);
        if ($stmt->rowCount() > 0) {
            $existingTables[] = $table;
            echo "<div style='color: #155724; background: #d4edda; padding: 8px; border-radius: 4px; margin: 5px 0;'>";
            echo "✅ $table tablosu mevcut";
            echo "</div>";
        } else {
            echo "<div style='color: #721c24; background: #f8d7da; padding: 8px; border-radius: 4px; margin: 5px 0;'>";
            echo "❌ $table tablosu eksik";
            echo "</div>";
        }
    }
    
    echo "<h2>2️⃣ Eksik Tabloları Oluşturma</h2>";
    
    // Create employee_devices table
    if (!in_array('employee_devices', $existingTables)) {
        $conn->exec("
            CREATE TABLE employee_devices (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                device_fingerprint VARCHAR(255) NOT NULL,
                device_name VARCHAR(100),
                device_type ENUM('mobile', 'tablet', 'desktop', 'unknown') DEFAULT 'unknown',
                operating_system VARCHAR(50),
                browser_name VARCHAR(50),
                browser_version VARCHAR(20),
                screen_resolution VARCHAR(20),
                timezone VARCHAR(50),
                language VARCHAR(10),
                is_trusted BOOLEAN DEFAULT 0,
                is_blocked BOOLEAN DEFAULT 0,
                first_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                trust_granted_by INT,
                trust_granted_at TIMESTAMP NULL,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY unique_employee_device (employee_id, device_fingerprint),
                INDEX idx_employee_id (employee_id),
                INDEX idx_device_fingerprint (device_fingerprint),
                INDEX idx_trust_status (is_trusted, is_blocked),
                FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ employee_devices tablosu oluşturuldu";
        echo "</div>";
    }
    
    // Create device_records table
    if (!in_array('device_records', $existingTables)) {
        $conn->exec("
            CREATE TABLE device_records (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                qr_location_id INT,
                activity_type VARCHAR(50) NOT NULL,
                device_fingerprint VARCHAR(255),
                ip_address VARCHAR(45),
                mac_address VARCHAR(17),
                user_agent TEXT,
                device_platform VARCHAR(50),
                device_browser VARCHAR(50),
                screen_width INT,
                screen_height INT,
                timezone VARCHAR(50),
                language VARCHAR(10),
                latitude DECIMAL(10, 8),
                longitude DECIMAL(11, 8),
                location_accuracy DECIMAL(8, 2),
                gps_enabled BOOLEAN DEFAULT 0,
                network_type VARCHAR(20),
                battery_level INT,
                is_charging BOOLEAN DEFAULT 0,
                canvas_fingerprint VARCHAR(255),
                webgl_fingerprint VARCHAR(255),
                audio_fingerprint VARCHAR(255),
                fonts_list TEXT,
                plugins_list TEXT,
                recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_employee_activity (employee_id, activity_type),
                INDEX idx_device_fingerprint (device_fingerprint),
                INDEX idx_recorded_date (recorded_at),
                INDEX idx_location (latitude, longitude),
                FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ device_records tablosu oluşturuldu";
        echo "</div>";
    }
    
    // Create device_security_logs table
    if (!in_array('device_security_logs', $existingTables)) {
        $conn->exec("
            CREATE TABLE device_security_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                device_fingerprint VARCHAR(255),
                event_type ENUM('new_device', 'suspicious_activity', 'location_mismatch', 'blocked_attempt', 'trust_granted', 'trust_revoked') NOT NULL,
                severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
                description TEXT NOT NULL,
                ip_address VARCHAR(45),
                user_agent TEXT,
                location_data JSON,
                additional_data JSON,
                is_resolved BOOLEAN DEFAULT 0,
                resolved_by INT,
                resolved_at TIMESTAMP NULL,
                resolution_notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_employee_event (employee_id, event_type),
                INDEX idx_severity (severity),
                INDEX idx_created_date (created_at),
                INDEX idx_resolved_status (is_resolved),
                FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ device_security_logs tablosu oluşturuldu";
        echo "</div>";
    }
    
    echo "<h2>3️⃣ Test Verileri Ekleme</h2>";
    
    // Insert sample device data for testing (if employees exist)
    $stmt = $conn->prepare("SELECT id, first_name, last_name FROM employees LIMIT 3");
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($employees) {
        foreach ($employees as $employee) {
            // Check if device record exists
            $stmt = $conn->prepare("SELECT id FROM employee_devices WHERE employee_id = ?");
            $stmt->execute([$employee['id']]);
            
            if ($stmt->rowCount() == 0) {
                // Add sample device
                $deviceFingerprint = 'demo_' . $employee['id'] . '_' . md5(uniqid());
                $stmt = $conn->prepare("
                    INSERT INTO employee_devices (
                        employee_id, device_fingerprint, device_name, device_type,
                        operating_system, browser_name, is_trusted
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $employee['id'],
                    $deviceFingerprint,
                    'Demo Cihazı - ' . $employee['first_name'],
                    'mobile',
                    'Android 12',
                    'Chrome Mobile',
                    1
                ]);
                
                echo "<div style='color: #155724; background: #d4edda; padding: 8px; border-radius: 4px; margin: 5px 0;'>";
                echo "✅ {$employee['first_name']} {$employee['last_name']} için demo cihaz eklendi";
                echo "</div>";
            }
        }
    }
    
    echo "<h2>4️⃣ Sistem Durumu</h2>";
    
    // Show table status
    foreach ($deviceTables as $table) {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM $table");
        $stmt->execute();
        $count = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<div style='background: #f8f9fa; border: 1px solid #dee2e6; padding: 10px; border-radius: 5px; margin: 5px 0;'>";
        echo "<strong>$table:</strong> {$count['count']} kayıt";
        echo "</div>";
    }
    
    echo "<h2>✅ Cihaz Yönetimi Sistemi Hazır!</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>🎯 Oluşturulan Özellikler:</h3>";
    echo "<ul>";
    echo "<li>✅ Personel cihaz kayıt sistemi</li>";
    echo "<li>✅ Cihaz güvenlik takibi</li>";
    echo "<li>✅ Otomatik fingerprinting</li>";
    echo "<li>✅ Admin onay/engelleme sistemi</li>";
    echo "<li>✅ Güvenlik olay günlüğü</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='admin/device-management.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🛡️ Cihaz Yönetimi</a>";
    echo "<a href='view-device-records.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>📱 Cihaz Kayıtları</a>";
    echo "<a href='dashboard/company-dashboard.php' style='background: #6c757d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>📊 Dashboard</a>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ Hata</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><strong>Satır:</strong> " . $e->getLine() . "</p>";
    echo "<p><strong>Dosya:</strong> " . $e->getFile() . "</p>";
    echo "</div>";
}
?>