<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Employee Password Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if password column exists in employees table
    $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'password'");
    if ($stmt->rowCount() === 0) {
        // Add password column
        $conn->exec("ALTER TABLE employees ADD COLUMN password VARCHAR(255) AFTER email");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ Password column added to employees table";
        echo "</div>";
        
        // Set default passwords for existing employees
        $conn->exec("UPDATE employees SET password = SHA2('szb123456', 256) WHERE password IS NULL OR password = ''");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ Default passwords set for existing employees (szb123456)";
        echo "</div>";
    } else {
        echo "<div style='color: #856404; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "ℹ️ Password column already exists in employees table";
        echo "</div>";
    }
    
    // Show current employees
    $stmt = $conn->query("SELECT id, employee_number, first_name, last_name, email FROM employees LIMIT 5");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Current Employees:</h3>";
    echo "<table style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th style='border: 1px solid #ddd; padding: 8px;'>ID</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px;'>Employee No</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px;'>Name</th>";
    echo "<th style='border: 1px solid #ddd; padding: 8px;'>Email</th>";
    echo "</tr>";
    
    foreach ($employees as $emp) {
        echo "<tr>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . $emp['id'] . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . htmlspecialchars($emp['employee_number']) . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) . "</td>";
        echo "<td style='border: 1px solid #ddd; padding: 8px;'>" . htmlspecialchars($emp['email']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "<div style='color: #721c24; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ Error: " . htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo "<br><a href='admin/employee-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Test Employee Management</a>";
?>