<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<div style='max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif;'>";
echo "<h1 style='background: #dc3545; color: white; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>🔧 Eksik Tabloları Düzelt</h1>";
echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";

echo "<p><strong>attendance_activities ve public_holidays tablolarını ekliyoruz...</strong></p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📋 1. Mevcut Tabloları Kontrol Et</h2>";
    $stmt = $conn->query("SHOW TABLES");
    $existingTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $missingTables = ['attendance_activities', 'public_holidays'];
    $tableStatus = [];
    
    foreach ($missingTables as $table) {
        $exists = in_array($table, $existingTables);
        $tableStatus[$table] = $exists;
        $status = $exists ? "✅ Mevcut" : "❌ Eksik";
        $color = $exists ? "green" : "red";
        echo "<p style='color: $color;'><strong>$table:</strong> $status</p>";
    }
    
    // Create attendance_activities table
    if (!$tableStatus['attendance_activities']) {
        echo "<h2>🛠️ 2. attendance_activities Tablosunu Oluştur</h2>";
        
        $sql = "CREATE TABLE `attendance_activities` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `employee_id` int(11) NOT NULL,
            `company_id` int(11) NOT NULL,
            `activity_type` enum('work_in','work_out','break_start','break_end','meal_start','meal_end') NOT NULL,
            `activity_date` date NOT NULL,
            `activity_time` datetime NOT NULL,
            `location_latitude` decimal(10,8) DEFAULT NULL,
            `location_longitude` decimal(11,8) DEFAULT NULL,
            `qr_location_id` int(11) DEFAULT NULL,
            `device_info` text DEFAULT NULL,
            `ip_address` varchar(45) DEFAULT NULL,
            `notes` text DEFAULT NULL,
            `status` enum('pending','confirmed','rejected') DEFAULT 'confirmed',
            `created_at` datetime DEFAULT current_timestamp(),
            `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `idx_activity_employee` (`employee_id`),
            KEY `idx_activity_company` (`company_id`),
            KEY `idx_activity_date` (`activity_date`),
            KEY `idx_activity_type` (`activity_type`),
            KEY `idx_activity_qr_location` (`qr_location_id`),
            CONSTRAINT `fk_activity_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_activity_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE,
            CONSTRAINT `fk_activity_qr_location` FOREIGN KEY (`qr_location_id`) REFERENCES `qr_locations` (`id`) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ <strong>attendance_activities</strong> tablosu başarıyla oluşturuldu!";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "⚠️ attendance_activities tablosu zaten mevcut";
        echo "</div>";
    }
    
    // Create public_holidays table
    if (!$tableStatus['public_holidays']) {
        echo "<h2>🛠️ 3. public_holidays Tablosunu Oluştur</h2>";
        
        $sql = "CREATE TABLE `public_holidays` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `company_id` int(11) DEFAULT NULL,
            `holiday_name` varchar(255) NOT NULL,
            `holiday_date` date NOT NULL,
            `holiday_type` enum('national','religious','custom','bridge') DEFAULT 'national',
            `is_paid` tinyint(1) DEFAULT 1,
            `is_active` tinyint(1) DEFAULT 1,
            `description` text DEFAULT NULL,
            `created_at` datetime DEFAULT current_timestamp(),
            `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            KEY `idx_holiday_date` (`holiday_date`),
            KEY `idx_holiday_company` (`company_id`),
            KEY `idx_holiday_type` (`holiday_type`),
            CONSTRAINT `fk_holiday_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ <strong>public_holidays</strong> tablosu başarıyla oluşturuldu!";
        echo "</div>";
        
        // Insert Turkish national holidays
        echo "<h3>📅 Türk Resmi Tatilleri Ekleniyor</h3>";
        
        $holidays = [
            ['Yeni Yıl', '2025-01-01', 'national', 'Miladi yılbaşı resmi tatili'],
            ['Ulusal Egemenlik ve Çocuk Bayramı', '2025-04-23', 'national', '23 Nisan Ulusal Egemenlik ve Çocuk Bayramı'],
            ['İşçi Bayramı', '2025-05-01', 'national', '1 Mayıs Emek ve Dayanışma Günü'],
            ['Atatürk\'ü Anma Gençlik ve Spor Bayramı', '2025-05-19', 'national', '19 Mayıs Atatürk\'ü Anma Gençlik ve Spor Bayramı'],
            ['Demokrasi ve Millî Birlik Günü', '2025-07-15', 'national', '15 Temmuz Demokrasi ve Millî Birlik Günü'],
            ['Zafer Bayramı', '2025-08-30', 'national', '30 Ağustos Zafer Bayramı'],
            ['Cumhuriyet Bayramı', '2025-10-29', 'national', '29 Ekim Cumhuriyet Bayramı'],
            ['Ramazan Bayramı 1. Gün', '2025-03-31', 'religious', 'Ramazan Bayramı birinci günü'],
            ['Ramazan Bayramı 2. Gün', '2025-04-01', 'religious', 'Ramazan Bayramı ikinci günü'],
            ['Ramazan Bayramı 3. Gün', '2025-04-02', 'religious', 'Ramazan Bayramı üçüncü günü'],
            ['Kurban Bayramı 1. Gün', '2025-06-07', 'religious', 'Kurban Bayramı birinci günü'],
            ['Kurban Bayramı 2. Gün', '2025-06-08', 'religious', 'Kurban Bayramı ikinci günü'],
            ['Kurban Bayramı 3. Gün', '2025-06-09', 'religious', 'Kurban Bayramı üçüncü günü'],
            ['Kurban Bayramı 4. Gün', '2025-06-10', 'religious', 'Kurban Bayramı dördüncü günü']
        ];
        
        $stmt = $conn->prepare("INSERT IGNORE INTO public_holidays (company_id, holiday_name, holiday_date, holiday_type, is_paid, description) VALUES (NULL, ?, ?, ?, 1, ?)");
        
        $addedCount = 0;
        foreach ($holidays as $holiday) {
            $stmt->execute($holiday);
            if ($stmt->rowCount() > 0) {
                $addedCount++;
            }
        }
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ <strong>$addedCount</strong> resmi tatil eklendi";
        echo "</div>";
        
    } else {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "⚠️ public_holidays tablosu zaten mevcut";
        echo "</div>";
    }
    
    // Test the tables
    echo "<h2>🧪 4. Tabloları Test Et</h2>";
    
    try {
        // Test attendance_activities
        $stmt = $conn->prepare("SELECT COUNT(*) FROM attendance_activities");
        $stmt->execute();
        $activitiesCount = $stmt->fetchColumn();
        
        // Test public_holidays
        $stmt = $conn->prepare("SELECT COUNT(*) FROM public_holidays");
        $stmt->execute();
        $holidaysCount = $stmt->fetchColumn();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h3>✅ Tüm Testler Başarılı!</h3>";
        echo "<ul>";
        echo "<li><strong>attendance_activities:</strong> $activitiesCount kayıt (erişilebilir)</li>";
        echo "<li><strong>public_holidays:</strong> $holidaysCount kayıt (erişilebilir)</li>";
        echo "</ul>";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Test hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    echo "<h2>🎉 İşlem Tamamlandı!</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>Yapılan İşlemler:</h3>";
    echo "<ul>";
    echo "<li>✅ <strong>attendance_activities</strong> tablosu oluşturuldu (aktivite takibi)</li>";
    echo "<li>✅ <strong>public_holidays</strong> tablosu oluşturuldu (resmi tatiller)</li>";
    echo "<li>✅ 2025 Türk resmi tatilleri eklendi</li>";
    echo "<li>✅ Foreign key bağlantıları kuruldu</li>";
    echo "<li>✅ Sistem hatası düzeltildi</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='emergency-fix-session.php' style='background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🔄 Sistem Kontrolü</a>";
    echo "<a href='auth/employee-login.php' style='background: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>👤 Employee Login</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Kritik Hata</h3>";
    echo "<p>Veritabanı hatası: " . $e->getMessage() . "</p>";
    echo "<p><strong>Çözüm:</strong> Veritabanı bağlantınızı kontrol edin ve yeniden deneyin.</p>";
    echo "</div>";
}

echo "</div>";
echo "</div>";
?>