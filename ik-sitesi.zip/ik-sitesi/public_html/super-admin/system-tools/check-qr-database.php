<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>QR Locations Veritabanı Kontrol</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if qr_locations table exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'qr_locations'");
    $stmt->execute();
    $tableExists = $stmt->rowCount() > 0;
    
    if ($tableExists) {
        echo "<p>✅ qr_locations tablosu mevcut</p>";
        
        // Check table structure
        $stmt = $conn->prepare("DESCRIBE qr_locations");
        $stmt->execute();
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>Tablo Yapısı:</h3>";
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $column) {
            echo "<tr>";
            echo "<td>{$column['Field']}</td>";
            echo "<td>{$column['Type']}</td>";
            echo "<td>{$column['Null']}</td>";
            echo "<td>{$column['Key']}</td>";
            echo "<td>{$column['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Check existing data
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations");
        $stmt->execute();
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>Mevcut kayıt sayısı: {$count}</p>";
        
        if ($count > 0) {
            echo "<h3>Örnek Kayıt:</h3>";
            $stmt = $conn->prepare("SELECT * FROM qr_locations LIMIT 1");
            $stmt->execute();
            $sample = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "<pre>";
            print_r($sample);
            echo "</pre>";
        }
        
    } else {
        echo "<p>❌ qr_locations tablosu bulunamadı!</p>";
        echo "<p>Tablo oluşturuluyor...</p>";
        
        $createTable = "
        CREATE TABLE qr_locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            name VARCHAR(255) NOT NULL,
            qr_code VARCHAR(100) UNIQUE NOT NULL,
            location_type VARCHAR(50) DEFAULT 'office',
            description TEXT,
            latitude DECIMAL(10, 8),
            longitude DECIMAL(11, 8),
            address VARCHAR(500),
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW() ON UPDATE NOW()
        )";
        
        if ($conn->exec($createTable)) {
            echo "<p>✅ qr_locations tablosu oluşturuldu!</p>";
        } else {
            echo "<p>❌ Tablo oluşturulamadı!</p>";
        }
    }
    
    // Required columns for QR system
    $requiredColumns = [
        'id', 'company_id', 'name', 'qr_code', 'location_type', 
        'description', 'latitude', 'longitude', 'address', 'is_active', 'created_at'
    ];
    
    echo "<h3>Gerekli Sütun Kontrolü:</h3>";
    foreach ($requiredColumns as $reqCol) {
        $found = false;
        foreach ($columns as $col) {
            if ($col['Field'] === $reqCol) {
                $found = true;
                break;
            }
        }
        echo "<p>" . ($found ? "✅" : "❌") . " {$reqCol}</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Hata: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='admin/qr-generator-original.php'>QR Generator'a Git</a></p>";
echo "<p><a href='admin/qr-generator.php'>Ana QR Generator'a Git</a></p>";
?>