<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>SZB İK Takip - Database Overview</h1>";
echo "<p><strong>Multi-tenant HR Management System</strong></p>";
echo "<p>Updated: " . date('d.m.Y H:i') . "</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get all table names
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_NUM);
    
    if (empty($tables)) {
        echo "<div style='color: red; font-weight: bold;'>❌ No tables found! Database needs to be created.</div>";
        echo "<p><a href='create-database.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Create Database Now</a></p>";
    } else {
        echo "<h2>📊 Database Tables (" . count($tables) . " total)</h2>";
        echo "<table border='1' cellpadding='8' cellspacing='0' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background: #f8f9fa;'><th>Table Name</th><th>Columns</th><th>Row Count</th><th>Description</th></tr>";
        
        $tableDescriptions = [
            'sessions' => '🔐 PHP Session Management',
            'companies' => '🏢 Multi-tenant Company Data',
            'users' => '👤 Admin & System Users',
            'departments' => '🏬 Company Departments',
            'employees' => '👥 Employee Records',
            'qr_locations' => '📍 GPS-enabled QR Workplaces',
            'attendance_activities' => '⚡ Work/Break Activity Types',
            'attendance_records' => '📝 GPS + QR Attendance Logs',
            'leave_types' => '🏖️ Leave Categories',
            'leave_requests' => '📋 Employee Leave Requests',
            'shifts' => '⏰ Work Shift Definitions',
            'employee_shifts' => '📅 Shift Assignments',
            'employee_break_entitlements' => '☕ Break Allowances',
            'employee_documents' => '📄 Personnel File Documents',
            'employee_trainings' => '🎓 Training Records',
            'garnishments' => '⚖️ Legal Wage Deductions'
        ];
        
        foreach ($tables as $table) {
            $tableName = $table[0];
            
            // Get column count
            $stmt = $conn->query("DESCRIBE $tableName");
            $columns = $stmt->fetchAll();
            $columnCount = count($columns);
            
            // Get row count
            $stmt = $conn->query("SELECT COUNT(*) as count FROM $tableName");
            $rowCount = $stmt->fetch()['count'];
            
            $description = $tableDescriptions[$tableName] ?? '📋 General Data';
            
            $rowStyle = $rowCount > 0 ? '' : 'color: #666;';
            echo "<tr style='$rowStyle'>";
            echo "<td><strong>$tableName</strong></td>";
            echo "<td>$columnCount</td>";
            echo "<td>$rowCount</td>";
            echo "<td>$description</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Show detailed structure for key tables
        echo "<h2>🔍 Key Table Structures</h2>";
        
        $keyTables = ['companies', 'employees', 'attendance_records', 'qr_locations'];
        foreach ($keyTables as $tableName) {
            if (in_array([$tableName], $tables)) {
                echo "<h3>📋 $tableName</h3>";
                $stmt = $conn->query("DESCRIBE $tableName");
                $columns = $stmt->fetchAll();
                
                echo "<table border='1' cellpadding='5' style='border-collapse: collapse; margin-bottom: 20px;'>";
                echo "<tr style='background: #e9ecef;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
                foreach ($columns as $column) {
                    echo "<tr>";
                    echo "<td><code>" . $column['Field'] . "</code></td>";
                    echo "<td>" . $column['Type'] . "</td>";
                    echo "<td>" . $column['Null'] . "</td>";
                    echo "<td>" . $column['Key'] . "</td>";
                    echo "<td>" . ($column['Default'] ?? 'NULL') . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        }
        
        // Show sample data
        echo "<h2>📊 Sample Data</h2>";
        
        // Companies
        echo "<h3>🏢 Companies</h3>";
        $stmt = $conn->query("SELECT company_name, company_code, company_type, status FROM companies LIMIT 5");
        $companies = $stmt->fetchAll();
        if (!empty($companies)) {
            echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
            echo "<tr style='background: #f8f9fa;'><th>Company Name</th><th>Code</th><th>Type</th><th>Status</th></tr>";
            foreach ($companies as $company) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($company['company_name']) . "</td>";
                echo "<td><code>" . $company['company_code'] . "</code></td>";
                echo "<td>" . ucfirst($company['company_type']) . "</td>";
                echo "<td><span style='color: " . ($company['status'] === 'active' ? 'green' : 'red') . ";'>●</span> " . $company['status'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color: #666;'>No companies found.</p>";
        }
        
        // Employees  
        echo "<h3>👥 Employees</h3>";
        $stmt = $conn->query("SELECT first_name, last_name, employee_number, position, status FROM employees LIMIT 5");
        $employees = $stmt->fetchAll();
        if (!empty($employees)) {
            echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
            echo "<tr style='background: #f8f9fa;'><th>Name</th><th>Employee #</th><th>Position</th><th>Status</th></tr>";
            foreach ($employees as $employee) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . "</td>";
                echo "<td><code>" . $employee['employee_number'] . "</code></td>";
                echo "<td>" . htmlspecialchars($employee['position'] ?? '-') . "</td>";
                echo "<td><span style='color: " . ($employee['status'] === 'active' ? 'green' : 'red') . ";'>●</span> " . $employee['status'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p style='color: #666;'>No employees found.</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<div style='color: red; background: #f8d7da; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<strong>❌ Database Connection Error:</strong><br>";
    echo htmlspecialchars($e->getMessage());
    echo "</div>";
    echo "<p><strong>Next Steps:</strong></p>";
    echo "<ol>";
    echo "<li>Check database credentials in includes/config.php</li>";
    echo "<li>Ensure MySQL server is running</li>";
    echo "<li>Run mysql_schema_complete.sql to create tables</li>";
    echo "</ol>";
}

echo "<hr>";
echo "<h2>🛠️ Quick Actions</h2>";
echo "<p>";
echo "<a href='installation-guide.php' style='background: #17a2b8; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>📖 Kurulum Rehberi</a>";
echo "<a href='create-database.php' style='background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>Create Database</a>";
echo "<a href='fix-database-now.php' style='background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>Fix Database</a>";
echo "<a href='fix-password-columns.php' style='background: #ffc107; color: #212529; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔐 Fix Passwords</a>";
echo "<a href='update-super-admin.php' style='background: #dc3545; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>👑 Fix Super Admin</a>";
echo "<a href='fix-qr-locations.php' style='background: #6c757d; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>📍 Fix QR Locations</a>";
echo "<a href='fix-duplicate-qr.php' style='background: #e83e8c; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔄 Fix Duplicates</a>";
echo "<a href='fix-attendance-columns.php' style='background: #6610f2; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>📊 Fix Attendance</a>";
echo "<a href='super-admin/' style='background: #6f42c1; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>Super Admin</a>";
echo "<a href='admin/company-setup.php' style='background: #fd7e14; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>Company Setup</a>";
echo "<a href='google-maps-setup.php' style='background: #17a2b8; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🗺️ Google Maps Setup</a>";
echo "<a href='test-google-maps.php' style='background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🧪 Test Google Maps</a>";
echo "<a href='test-company-switch.php' style='background: #007bff; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔄 Test Company Switch</a>";
echo "<a href='admin/user-password-management.php' style='background: #6f42c1; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔐 Password Management</a>";
echo "<a href='test-password-management.php' style='background: #e83e8c; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🧪 Test Passwords</a>";
echo "<a href='test-dashboard-cards.php' style='background: #20c997; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🎴 Test Dashboard</a>";
echo "<a href='quick-company-access.php' style='background: #fd7e14; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🚀 Quick Access</a>";
echo "<a href='fix-switch-company.php' style='background: #dc3545; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-right: 10px;'>🔧 Fix Switch</a>";
echo "<a href='direct-switch.php?code=ZEY03008' style='background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px;'>🎯 Direct Switch</a>";
echo "</p>";

echo "<hr>";
echo "<p style='color: #666; font-size: 12px;'>SZB İK Takip v1.0 - Multi-tenant HR Management System</p>";
?>