<?php
session_start();
echo "<h1>🔍 QR Session Debug</h1>";

echo "<h2>Current Session Contents:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h2>QR Scan Data Analysis:</h2>";
if (isset($_SESSION['qr_scan_data'])) {
    $qrData = $_SESSION['qr_scan_data'];
    echo "<div style='background: #e7f3ff; padding: 15px; border-radius: 5px;'>";
    echo "<h3>✅ qr_scan_data EXISTS</h3>";
    echo "<pre>" . print_r($qrData, true) . "</pre>";
    
    // Test location_id extraction
    $locationId = $qrData['location_id'] ?? $qrData['id'] ?? null;
    
    if ($locationId) {
        echo "<div style='background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>✅ Location ID Found: $locationId</h4>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>❌ Location ID NOT FOUND</h4>";
        echo "<p>Available keys: " . implode(', ', array_keys($qrData)) . "</p>";
        echo "</div>";
    }
} else {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ qr_scan_data NOT SET</h3>";
    echo "<p>Session'da QR verisi yok!</p>";
    echo "</div>";
}

echo "<h2>Fix Session Data:</h2>";
echo "<form method='post'>";
echo "<button type='submit' name='fix_session' style='background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px;'>Fix QR Session Data</button>";
echo "</form>";

if (isset($_POST['fix_session'])) {
    $_SESSION['qr_scan_data'] = [
        'location_id' => 1,
        'id' => 1,
        'location_code' => 'LOC001',
        'location_name' => 'Ana Giriş',
        'name' => 'Ana Giriş',
        'latitude' => 41.108297,
        'longitude' => 29.022776,
        'location_type' => 'entrance',
        'company_id' => 1
    ];
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>✅ Session Fixed!</h3>";
    echo "<p>QR scan data has been set with location_id</p>";
    echo "</div>";
    
    header("refresh:2;");
}

echo "<div style='margin: 20px 0;'>";
echo "<a href='qr/activity-selection.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Test Activity Selection</a>";
echo "</div>";
?>