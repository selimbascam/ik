<?php
// Super admin authentication check
require_once '../../includes/config.php';

// Check if user is logged in as super admin
if (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1) {
    header('Location: ../index.php');
    exit;
}
?>