<?php
// Direct Download - Standalone system without session dependencies
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set timezone
date_default_timezone_set('Europe/Istanbul');

// Clear all output buffers
while (ob_get_level()) {
    ob_end_clean();
}

// Basic authentication check - allow if accessing from super admin area
$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$isFromSuperAdmin = strpos($requestUri, '/super-admin/') !== false;

if (!$isFromSuperAdmin) {
    http_response_code(403);
    exit('Access denied');
}

// Generate basic system report
$report = [
    'generated_at' => date('Y-m-d H:i:s'),
    'generator' => 'SZB İK Takip - Direct Download System',
    'version' => '1.0',
    'download_method' => 'direct',
    'server_info' => [
        'php_version' => phpversion(),
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'host' => $_SERVER['HTTP_HOST'] ?? 'Unknown',
        'timezone' => date_default_timezone_get(),
        'max_execution_time' => ini_get('max_execution_time'),
        'memory_limit' => ini_get('memory_limit')
    ],
    'system_status' => [
        'status' => 'operational',
        'timestamp' => time(),
        'date_formatted' => date('d/m/Y H:i:s')
    ]
];

// Try to connect to database
try {
    // Database connection parameters (adjust as needed)
    $host = 'localhost';
    $dbname = 'szb_ik_takip';
    $username = 'root';
    $password = '';
    
    // Try PDO connection
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
    
    $report['database'] = [
        'status' => 'connected',
        'host' => $host,
        'database_name' => $dbname
    ];
    
    // Get basic stats
    try {
        $stmt = $pdo->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $report['database']['tables_count'] = count($tables);
        $report['database']['tables'] = array_slice($tables, 0, 20); // First 20 tables
        
        // Companies count
        if (in_array('companies', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM companies");
            $result = $stmt->fetch();
            $report['database']['companies_count'] = $result['count'];
        }
        
        // Employees count
        if (in_array('employees', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM employees");
            $result = $stmt->fetch();
            $report['database']['employees_count'] = $result['count'];
        }
        
        // Attendance records count
        if (in_array('attendance_records', $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM attendance_records");
            $result = $stmt->fetch();
            $report['database']['attendance_records_count'] = $result['count'];
        }
        
    } catch (Exception $e) {
        $report['database']['stats_error'] = $e->getMessage();
    }
    
} catch (Exception $e) {
    $report['database'] = [
        'status' => 'error',
        'error' => $e->getMessage()
    ];
}

// Add system recommendations
$report['recommendations'] = [
    'Check database connectivity regularly',
    'Monitor QR attendance system functionality',
    'Verify user authentication systems',
    'Review system logs for errors'
];

$report['test_summary'] = [
    'total_components' => 5,
    'status' => 'System Analysis Complete',
    'timestamp' => date('c')
];

// Generate JSON content
$jsonContent = json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Determine download method
$method = $_GET['method'] ?? 'json';
$filename = 'szb-ik-direct-report-' . date('Y-m-d-H-i-s');

switch ($method) {
    case 'json':
        // Direct JSON download
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.json"');
        header('Content-Length: ' . strlen($jsonContent));
        header('Cache-Control: no-cache, must-revalidate');
        header('Pragma: no-cache');
        echo $jsonContent;
        exit;
        
    case 'txt':
        // Text format download
        $textContent = "SZB İK TAKİP - SİSTEM ANALİZİ RAPORU\n";
        $textContent .= "==========================================\n\n";
        $textContent .= "Tarih: " . $report['generated_at'] . "\n";
        $textContent .= "Versiyon: " . $report['version'] . "\n";
        $textContent .= "Sunucu: " . $report['server_info']['host'] . "\n";
        $textContent .= "PHP: " . $report['server_info']['php_version'] . "\n\n";
        
        $textContent .= "VERİTABANI DURUMU:\n";
        $textContent .= "Durum: " . $report['database']['status'] . "\n";
        if (isset($report['database']['tables_count'])) {
            $textContent .= "Tablo Sayısı: " . $report['database']['tables_count'] . "\n";
        }
        if (isset($report['database']['companies_count'])) {
            $textContent .= "Şirket Sayısı: " . $report['database']['companies_count'] . "\n";
        }
        if (isset($report['database']['employees_count'])) {
            $textContent .= "Personel Sayısı: " . $report['database']['employees_count'] . "\n";
        }
        
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.txt"');
        header('Content-Length: ' . strlen($textContent));
        header('Cache-Control: no-cache, must-revalidate');
        echo $textContent;
        exit;
        
    case 'csv':
        // CSV format download
        $csvContent = "Alan,Değer\n";
        $csvContent .= "Tarih," . $report['generated_at'] . "\n";
        $csvContent .= "Sistem," . $report['generator'] . "\n";
        $csvContent .= "Sunucu," . $report['server_info']['host'] . "\n";
        $csvContent .= "PHP Versiyon," . $report['server_info']['php_version'] . "\n";
        $csvContent .= "Veritabanı Durum," . $report['database']['status'] . "\n";
        
        if (isset($report['database']['tables_count'])) {
            $csvContent .= "Tablo Sayısı," . $report['database']['tables_count'] . "\n";
        }
        if (isset($report['database']['companies_count'])) {
            $csvContent .= "Şirket Sayısı," . $report['database']['companies_count'] . "\n";
        }
        if (isset($report['database']['employees_count'])) {
            $csvContent .= "Personel Sayısı," . $report['database']['employees_count'] . "\n";
        }
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        header('Content-Length: ' . strlen($csvContent));
        echo $csvContent;
        exit;
        
    case 'test':
        // Test the download without file headers
        echo "<h2>Download Test Result</h2>";
        echo "<p>Report generated successfully at: " . date('Y-m-d H:i:s') . "</p>";
        echo "<p>JSON size: " . strlen($jsonContent) . " bytes</p>";
        echo "<p>Database status: " . $report['database']['status'] . "</p>";
        echo "<hr>";
        echo "<h3>Available Downloads:</h3>";
        echo "<a href='?method=json'>JSON Download</a> | ";
        echo "<a href='?method=txt'>Text Download</a> | ";
        echo "<a href='?method=csv'>CSV Download</a>";
        echo "<hr>";
        echo "<pre>" . htmlspecialchars($jsonContent) . "</pre>";
        exit;
        
    default:
        // Default: Show download options
        echo "<!DOCTYPE html>
<html><head><title>Direct Download</title></head><body>
<h2>Direct Download - Sistem Raporu</h2>
<p>Tarih: " . date('d/m/Y H:i:s') . "</p>
<h3>İndirme Seçenekleri:</h3>
<a href='?method=json' style='display:block;margin:10px 0;padding:10px;background:#007cba;color:white;text-decoration:none;'>JSON İndir</a>
<a href='?method=txt' style='display:block;margin:10px 0;padding:10px;background:#28a745;color:white;text-decoration:none;'>Metin İndir</a>
<a href='?method=csv' style='display:block;margin:10px 0;padding:10px;background:#ffc107;color:black;text-decoration:none;'>CSV İndir</a>
<a href='?method=test' style='display:block;margin:10px 0;padding:10px;background:#6c757d;color:white;text-decoration:none;'>Test Görüntüle</a>
</body></html>";
        exit;
}
?>