<?php
// Emergency session fix - clear all sessions and test basic functionality
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<div style='font-family: Arial; max-width: 600px; margin: 50px auto; padding: 20px;'>";
echo "<h1 style='color: #d63384;'>🆘 Emergency Session Fix</h1>";

// Destroy any existing sessions
if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
    echo "<p>✅ Mevcut session sonlandırıldı</p>";
}

// Clear session files if possible
if (function_exists('session_save_path')) {
    $sessionPath = session_save_path();
    echo "<p>Session path: $sessionPath</p>";
}

// Test basic PHP functionality
echo "<h2>Temel Test</h2>";
echo "<p>✅ PHP Version: " . PHP_VERSION . "</p>";
echo "<p>✅ Zaman: " . date('Y-m-d H:i:s') . "</p>";

// Test config loading
echo "<h2>Config Test</h2>";
try {
    require_once 'includes/config.php';
    echo "<p>✅ Config yüklendi</p>";
    echo "<p>✅ APP_NAME: " . APP_NAME . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Config hatası: " . $e->getMessage() . "</p>";
}

// Test database
echo "<h2>Database Test</h2>";
try {
    require_once 'includes/database.php';
    $db = new Database();
    $conn = $db->getConnection();
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM companies");
    $result = $stmt->fetch();
    echo "<p>✅ Database bağlantısı başarılı</p>";
    echo "<p>✅ Companies: " . $result['count'] . " kayıt</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database hatası: " . $e->getMessage() . "</p>";
}

// Test session restart
echo "<h2>Session Restart Test</h2>";
try {
    session_start();
    $_SESSION['test'] = 'working';
    echo "<p>✅ Yeni session başlatıldı</p>";
    echo "<p>✅ Session ID: " . session_id() . "</p>";
    echo "<p>✅ Test session variable: " . $_SESSION['test'] . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Session hatası: " . $e->getMessage() . "</p>";
}

echo "<h2>Test Links</h2>";
echo "<div style='margin: 20px 0;'>";
echo "<a href='test-simple.php' style='background: #0d6efd; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Test Simple</a>";
echo "<a href='auth/employee-login.php' style='background: #198754; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>Employee Login</a>";
echo "<a href='qr/qr-reader.php' style='background: #dc3545; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>QR Reader (Direct)</a>";
echo "</div>";

echo "<p style='margin-top: 30px; padding: 15px; background: #f8f9fa; border-left: 4px solid #0d6efd;'>";
echo "<strong>Sonraki Adımlar:</strong><br>";
echo "1. Employee Login sayfasını test edin<br>";
echo "2. EMP001 / szb123456 ile giriş yapın<br>";
echo "3. QR Reader sayfası açılmalı<br>";
echo "</p>";

echo "</div>";
?>