<?php
require_once 'auth-check.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karakter Seti Düzeltme - Süper Admin</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        .header { background: linear-gradient(135deg, #fd7e14 0%, #e55a4f 100%); color: white; padding: 30px; margin: -20px -20px 20px -20px; border-radius: 8px 8px 0 0; }
        .status { padding: 15px; border-radius: 8px; margin: 15px 0; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .info { background: #cce7ff; color: #004085; border: 1px solid #b6d7ff; }
        .warning { background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
        .test-text { font-size: 18px; padding: 10px; background: #f8f9fa; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🌐 Karakter Seti Düzeltme</h1>
            <p>UTF-8 ve Türkçe karakter desteği onarımı</p>
        </div>
        
        <div class="status info">
            <h3>📋 Charset Kontrol Testi</h3>
            <p>Aşağıdaki Türkçe karakterlerin doğru görüntülenip görüntülenmediğini kontrol edin:</p>
            
            <div class="test-text">
                <strong>Test Metni:</strong> Çalışan, işçi, müdür, şirket, öğrenci, ürün, güvenlik, sağlık
            </div>
            
            <div class="test-text">
                <strong>Büyük Harfler:</strong> ÇĞIİÖŞÜ
            </div>
            
            <div class="test-text">
                <strong>Küçük Harfler:</strong> çğıiöşü
            </div>
        </div>
        
        <div class="status success">
            <h3>✅ PHP Charset Bilgileri</h3>
            <ul>
                <li><strong>Default Charset:</strong> <?php echo ini_get('default_charset'); ?></li>
                <li><strong>Internal Encoding:</strong> <?php echo mb_internal_encoding(); ?></li>
                <li><strong>HTTP Output:</strong> <?php echo ini_get('default_charset') ?: 'Belirsiz'; ?></li>
                <li><strong>Multibyte Support:</strong> <?php echo extension_loaded('mbstring') ? '✅ Aktif' : '❌ Pasif'; ?></li>
            </ul>
        </div>
        
        <div class="status warning">
            <h3>⚙️ Charset Düzeltme Önerileri</h3>
            <p>Karakter seti sorunları için aşağıdaki adımları uygulayın:</p>
            
            <h4>1. Veritabanı Seviyesi:</h4>
            <ul>
                <li>Veritabanı: <code>ALTER DATABASE szb_ik_takip CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;</code></li>
                <li>Tablolar: <code>ALTER TABLE table_name CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;</code></li>
            </ul>
            
            <h4>2. PHP Seviyesi:</h4>
            <ul>
                <li>Her PHP dosyasının başına: <code>&lt;?php header('Content-Type: text/html; charset=UTF-8'); ?&gt;</code></li>
                <li>Database bağlantısında: <code>mysqli_set_charset($connection, "utf8mb4");</code></li>
            </ul>
            
            <h4>3. HTML Seviyesi:</h4>
            <ul>
                <li>Meta tag: <code>&lt;meta charset="UTF-8"&gt;</code></li>
                <li>HTML5 doctype: <code>&lt;!DOCTYPE html&gt;</code></li>
            </ul>
        </div>
        
        <div class="status info">
            <h3>🔧 Otomatik Düzeltme Komutları</h3>
            <p>Aşağıdaki SQL komutlarını veritabanınızda çalıştırabilirsiniz:</p>
            
            <div style="background: #2d3436; color: #dfe6e9; padding: 15px; border-radius: 8px; font-family: monospace; margin: 10px 0;">
-- Veritabanı charset düzeltme<br>
ALTER DATABASE szb_ik_takip CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;<br><br>

-- Tüm tabloları utf8mb4'e çevir<br>
SET foreign_key_checks = 0;<br>
SELECT CONCAT('ALTER TABLE ', table_name, ' CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;')<br>
FROM information_schema.tables<br>
WHERE table_schema = 'szb_ik_takip';<br>
SET foreign_key_checks = 1;
            </div>
        </div>
        
        <div class="status">
            <h3>📱 Test Sonuçları</h3>
            <p><strong>Mevcut Sayfa Encoding:</strong> <?php echo mb_detect_encoding('Çalışan İşçi Müdür'); ?></p>
            <p><strong>Browser Charset:</strong> UTF-8 (Meta tag ile belirtildi)</p>
            <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
            <p><strong>Sistem Locale:</strong> <?php echo setlocale(LC_ALL, 0); ?></p>
        </div>
        
        <a href="../index.php" class="back-btn">← Süper Admin Panel</a>
    </div>
</body>
</html>