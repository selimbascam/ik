<?php
// Fix All Links - Comprehensive Link Correction
echo "<h1>Tüm Link Düzeltmeleri</h1>";
echo "<p>Başlangıç: " . date('Y-m-d H:i:s') . "</p><hr>";

$fixes = [];

// 1. Fix dashboard/company-dashboard.php links
$file = 'dashboard/company-dashboard.php';
if (file_exists($file)) {
    $content = file_get_contents($file);
    $originalContent = $content;
    
    // Fix navigation links
    $content = str_replace('href="../admin/employee-management.php"', 'href="/ik/admin/employee-management.php"', $content);
    $content = str_replace('href="../admin/qr-generator.php"', 'href="/ik/admin/qr-generator.php"', $content);
    $content = str_replace('href="../attendance/records.php"', 'href="/ik/attendance/records.php"', $content);
    $content = str_replace('href="../admin/company-settings.php"', 'href="/ik/admin/company-settings.php"', $content);
    $content = str_replace('href="../auth/logout.php"', 'href="/ik/auth/logout.php"', $content);
    
    if ($content !== $originalContent) {
        file_put_contents($file, $content);
        $fixes[] = "Fixed links in $file";
        echo "✅ $file - Links fixed<br>";
    } else {
        echo "✅ $file - No changes needed<br>";
    }
}

// 2. Fix auth/company-login.php links
$file = 'auth/company-login.php';
if (file_exists($file)) {
    $content = file_get_contents($file);
    $originalContent = $content;
    
    // Fix redirect links
    $content = str_replace("header('Location: ../dashboard/company-dashboard.php');", "header('Location: /ik/dashboard/company-dashboard.php');", $content);
    $content = str_replace('href="../super-admin/index.php"', 'href="/ik/super-admin/index.php"', $content);
    $content = str_replace('href="../auth/employee-login.php"', 'href="/ik/auth/employee-login.php"', $content);
    
    if ($content !== $originalContent) {
        file_put_contents($file, $content);
        $fixes[] = "Fixed links in $file";
        echo "✅ $file - Links fixed<br>";
    } else {
        echo "✅ $file - No changes needed<br>";
    }
}

// 3. Fix qr/qr-reader.php links
$file = 'qr/qr-reader.php';
if (file_exists($file)) {
    $content = file_get_contents($file);
    $originalContent = $content;
    
    // Fix navigation and redirect links
    $content = str_replace("window.location.href = 'activity-selection.php", "window.location.href = '/ik/qr/activity-selection.php", $content);
    $content = str_replace('href="../dashboard/company-dashboard.php"', 'href="/ik/dashboard/company-dashboard.php"', $content);
    $content = str_replace('href="../auth/employee-login.php"', 'href="/ik/auth/employee-login.php"', $content);
    
    if ($content !== $originalContent) {
        file_put_contents($file, $content);
        $fixes[] = "Fixed links in $file";
        echo "✅ $file - Links fixed<br>";
    } else {
        echo "✅ $file - No changes needed<br>";
    }
}

// 4. Fix qr/activity-selection.php links
$file = 'qr/activity-selection.php';
if (file_exists($file)) {
    $content = file_get_contents($file);
    $originalContent = $content;
    
    // Fix redirect links
    $content = str_replace("header('Location: ../dashboard/employee-dashboard.php');", "header('Location: /ik/dashboard/employee-dashboard.php');", $content);
    $content = str_replace("header('Location: ../attendance/success.php');", "header('Location: /ik/attendance/success.php');", $content);
    $content = str_replace('href="../qr/qr-reader.php"', 'href="/ik/qr/qr-reader.php"', $content);
    
    if ($content !== $originalContent) {
        file_put_contents($file, $content);
        $fixes[] = "Fixed links in $file";
        echo "✅ $file - Links fixed<br>";
    } else {
        echo "✅ $file - No changes needed<br>";
    }
}

// 5. Fix admin/employee-management.php links
$file = 'admin/employee-management.php';
if (file_exists($file)) {
    $content = file_get_contents($file);
    $originalContent = $content;
    
    // Fix navigation links
    $content = str_replace('href="../dashboard/company-dashboard.php"', 'href="/ik/dashboard/company-dashboard.php"', $content);
    $content = str_replace('action="employee-management.php"', 'action="/ik/admin/employee-management.php"', $content);
    
    if ($content !== $originalContent) {
        file_put_contents($file, $content);
        $fixes[] = "Fixed links in $file";
        echo "✅ $file - Links fixed<br>";
    } else {
        echo "✅ $file - No changes needed<br>";
    }
}

// 6. Fix attendance/records.php links
$file = 'attendance/records.php';
if (file_exists($file)) {
    $content = file_get_contents($file);
    $originalContent = $content;
    
    // Fix navigation links
    $content = str_replace('href="../dashboard/company-dashboard.php"', 'href="/ik/dashboard/company-dashboard.php"', $content);
    $content = str_replace('href="../admin/work-settings.php"', 'href="/ik/admin/work-settings.php"', $content);
    
    if ($content !== $originalContent) {
        file_put_contents($file, $content);
        $fixes[] = "Fixed links in $file";
        echo "✅ $file - Links fixed<br>";
    } else {
        echo "✅ $file - No changes needed<br>";
    }
}

echo "<hr>";
echo "<h2>Özet</h2>";
echo "<p>Toplam düzeltme: " . count($fixes) . "</p>";
foreach ($fixes as $fix) {
    echo "• $fix<br>";
}

echo "<p>Bitiş: " . date('Y-m-d H:i:s') . "</p>";
?>