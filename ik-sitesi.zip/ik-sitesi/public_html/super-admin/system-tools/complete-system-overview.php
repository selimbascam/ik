<?php
require_once 'includes/config.php';
require_once 'includes/database.php';
require_once 'includes/holiday-calculator.php';

echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>SZB İK Takip - Tam Sistem Analizi</title>";
echo "<script src='https://cdn.tailwindcss.com'></script>";
echo "<style>";
echo "body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }";
echo ".status-good { background: #d4edda; color: #155724; }";
echo ".status-warning { background: #fff3cd; color: #856404; }";
echo ".status-error { background: #f8d7da; color: #721c24; }";
echo ".module-card { transition: transform 0.2s; } .module-card:hover { transform: translateY(-2px); }";
echo "</style>";
echo "</head>";
echo "<body class='bg-gray-50 min-h-screen'>";

// Header
echo "<div class='bg-white shadow-sm border-b'>";
echo "<div class='max-w-7xl mx-auto px-4 py-4'>";
echo "<div class='flex items-center justify-between'>";
echo "<div class='flex items-center space-x-4'>";
echo "<div class='w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center'>";
echo "<span class='text-white text-2xl font-bold'>S</span>";
echo "</div>";
echo "<div>";
echo "<h1 class='text-2xl font-bold text-gray-900'>SZB İK Takip</h1>";
echo "<p class='text-sm text-gray-500'>Kapsamlı Sistem Analizi</p>";
echo "</div>";
echo "</div>";
echo "<div class='text-right text-sm text-gray-500'>";
echo "<div>Kontrol: " . date('d.m.Y H:i:s') . "</div>";
echo "<div>Platform: MySQL + PHP</div>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";

$systemHealth = [];
$criticalIssues = [];
$recommendations = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div class='max-w-7xl mx-auto px-4 py-6'>";
    
    // 1. CORE SYSTEM STATUS
    echo "<section class='mb-8'>";
    echo "<h2 class='text-xl font-semibold text-gray-800 mb-4'>🏗️ Temel Sistem Durumu</h2>";
    echo "<div class='grid grid-cols-1 md:grid-cols-4 gap-4'>";
    
    // Database Connection
    $dbStatus = 'good';
    try {
        $conn->query("SELECT 1");
        echo "<div class='bg-white p-4 rounded-lg shadow module-card'>";
        echo "<div class='flex items-center'>";
        echo "<div class='w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3'>";
        echo "<span class='text-green-600 text-xl'>✅</span>";
        echo "</div>";
        echo "<div>";
        echo "<div class='font-semibold text-gray-800'>Veritabanı</div>";
        echo "<div class='text-sm text-green-600'>Bağlantı Aktif</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        $systemHealth['database'] = 'good';
    } catch (Exception $e) {
        $dbStatus = 'error';
        $criticalIssues[] = "Veritabanı bağlantı hatası";
        $systemHealth['database'] = 'error';
    }
    
    // PHP Status
    echo "<div class='bg-white p-4 rounded-lg shadow module-card'>";
    echo "<div class='flex items-center'>";
    echo "<div class='w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3'>";
    echo "<span class='text-blue-600 text-xl'>🐘</span>";
    echo "</div>";
    echo "<div>";
    echo "<div class='font-semibold text-gray-800'>PHP</div>";
    echo "<div class='text-sm text-blue-600'>v" . PHP_VERSION . "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    
    // Session Status
    $sessionStatus = session_status() == PHP_SESSION_ACTIVE ? 'good' : 'warning';
    $sessionIcon = $sessionStatus == 'good' ? '✅' : '⚠️';
    $sessionText = $sessionStatus == 'good' ? 'Aktif' : 'Pasif';
    $sessionColor = $sessionStatus == 'good' ? 'green' : 'yellow';
    
    echo "<div class='bg-white p-4 rounded-lg shadow module-card'>";
    echo "<div class='flex items-center'>";
    echo "<div class='w-10 h-10 bg-{$sessionColor}-100 rounded-lg flex items-center justify-center mr-3'>";
    echo "<span class='text-{$sessionColor}-600 text-xl'>$sessionIcon</span>";
    echo "</div>";
    echo "<div>";
    echo "<div class='font-semibold text-gray-800'>Oturum</div>";
    echo "<div class='text-sm text-{$sessionColor}-600'>$sessionText</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    
    // Holiday Calculator
    try {
        $testHolidays = TurkishHolidayCalculator::getHolidaysForYear(date('Y'));
        $holidayCount = count($testHolidays);
        echo "<div class='bg-white p-4 rounded-lg shadow module-card'>";
        echo "<div class='flex items-center'>";
        echo "<div class='w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mr-3'>";
        echo "<span class='text-purple-600 text-xl'>🎉</span>";
        echo "</div>";
        echo "<div>";
        echo "<div class='font-semibold text-gray-800'>Tatil Hesaplayıcı</div>";
        echo "<div class='text-sm text-purple-600'>$holidayCount Tatil</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        $systemHealth['holidays'] = 'good';
    } catch (Exception $e) {
        $systemHealth['holidays'] = 'error';
        $criticalIssues[] = "Tatil hesaplayıcı hatası";
    }
    
    echo "</div>";
    echo "</section>";
    
    // 2. DATA OVERVIEW
    echo "<section class='mb-8'>";
    echo "<h2 class='text-xl font-semibold text-gray-800 mb-4'>📊 Veri Durumu</h2>";
    echo "<div class='grid grid-cols-2 md:grid-cols-5 gap-4'>";
    
    $dataTables = [
        'companies' => ['icon' => '🏢', 'name' => 'Şirketler', 'color' => 'blue'],
        'employees' => ['icon' => '👥', 'name' => 'Personel', 'color' => 'green'],
        'qr_locations' => ['icon' => '📍', 'name' => 'QR Lokasyon', 'color' => 'purple'],
        'attendance_records' => ['icon' => '📝', 'name' => 'Devam Kayıtları', 'color' => 'orange'],
        'public_holidays' => ['icon' => '🎊', 'name' => 'Tatil Günleri', 'color' => 'pink']
    ];
    
    foreach ($dataTables as $table => $info) {
        try {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM $table");
            $count = $stmt->fetch()['count'];
            
            echo "<div class='bg-white p-4 rounded-lg shadow module-card'>";
            echo "<div class='text-center'>";
            echo "<div class='text-2xl mb-2'>{$info['icon']}</div>";
            echo "<div class='text-2xl font-bold text-{$info['color']}-600'>$count</div>";
            echo "<div class='text-sm text-gray-600'>{$info['name']}</div>";
            echo "</div>";
            echo "</div>";
        } catch (Exception $e) {
            echo "<div class='bg-white p-4 rounded-lg shadow module-card border-l-4 border-red-500'>";
            echo "<div class='text-center'>";
            echo "<div class='text-2xl mb-2'>❌</div>";
            echo "<div class='text-sm text-red-600'>Tablo Hatası</div>";
            echo "<div class='text-xs text-gray-500'>{$info['name']}</div>";
            echo "</div>";
            echo "</div>";
            $criticalIssues[] = "$table tablosu erişilemez";
        }
    }
    
    echo "</div>";
    echo "</section>";
    
    // 3. FEATURE MODULES STATUS
    echo "<section class='mb-8'>";
    echo "<h2 class='text-xl font-semibold text-gray-800 mb-4'>🚀 Özellik Modülleri</h2>";
    echo "<div class='grid grid-cols-1 md:grid-cols-3 gap-6'>";
    
    $modules = [
        [
            'title' => 'Kimlik Doğrulama',
            'files' => ['auth/employee-login.php', 'auth/company-login.php'],
            'description' => 'Personel ve şirket giriş sistemleri',
            'icon' => '🔐'
        ],
        [
            'title' => 'QR Kod Sistemi', 
            'files' => ['qr/qr-reader.php', 'qr/activity-selection.php'],
            'description' => 'QR kod okutma ve aktivite seçimi',
            'icon' => '📱'
        ],
        [
            'title' => 'Devam Takibi',
            'files' => ['attendance/records.php', 'attendance/tracker.php'],
            'description' => 'Çalışma saati ve mola takibi',
            'icon' => '⏰'
        ],
        [
            'title' => 'Yönetim Panelleri',
            'files' => ['dashboard/company-dashboard.php', 'dashboard/employee-dashboard.php'],
            'description' => 'Şirket ve personel kontrol panelleri',
            'icon' => '📋'
        ],
        [
            'title' => 'Çalışma Planlaması',
            'files' => ['admin/work-settings.php', 'admin/holiday-management.php'],
            'description' => 'Mesai ayarları ve tatil yönetimi',
            'icon' => '⚙️'
        ],
        [
            'title' => 'Sistem Yönetimi',
            'files' => ['system-check.php', 'setup-work-settings.php'],
            'description' => 'Sistem kontrolü ve kurulum araçları',
            'icon' => '🔧'
        ]
    ];
    
    foreach ($modules as $module) {
        $allFilesExist = true;
        $fileStatuses = [];
        
        foreach ($module['files'] as $file) {
            $exists = file_exists($file);
            $fileStatuses[] = $exists;
            if (!$exists) {
                $allFilesExist = false;
            }
        }
        
        $statusColor = $allFilesExist ? 'green' : 'red';
        $statusIcon = $allFilesExist ? '✅' : '❌';
        $statusText = $allFilesExist ? 'Çalışır' : 'Eksik Dosya';
        
        echo "<div class='bg-white rounded-lg shadow module-card'>";
        echo "<div class='p-6'>";
        echo "<div class='flex items-center justify-between mb-4'>";
        echo "<div class='flex items-center'>";
        echo "<span class='text-3xl mr-3'>{$module['icon']}</span>";
        echo "<div>";
        echo "<h3 class='font-semibold text-gray-800'>{$module['title']}</h3>";
        echo "<p class='text-sm text-gray-600'>{$module['description']}</p>";
        echo "</div>";
        echo "</div>";
        echo "<div class='text-{$statusColor}-600'>$statusIcon</div>";
        echo "</div>";
        
        echo "<div class='border-t pt-4'>";
        echo "<div class='text-xs text-gray-500 mb-2'>Dosya Durumu:</div>";
        foreach ($module['files'] as $i => $file) {
            $icon = $fileStatuses[$i] ? '✓' : '✗';
            $color = $fileStatuses[$i] ? 'green' : 'red';
            echo "<div class='text-xs text-{$color}-600 mb-1'>$icon $file</div>";
        }
        echo "</div>";
        echo "</div>";
        echo "</div>";
    }
    
    echo "</div>";
    echo "</section>";
    
    // 4. RECENT ACTIVITY
    echo "<section class='mb-8'>";
    echo "<h2 class='text-xl font-semibold text-gray-800 mb-4'>📈 Son Aktiviteler</h2>";
    echo "<div class='bg-white rounded-lg shadow p-6'>";
    
    try {
        $stmt = $conn->query("
            SELECT ar.*, e.first_name, e.last_name, aa.name as activity_name, c.company_name
            FROM attendance_records ar
            JOIN employees e ON ar.employee_id = e.id
            JOIN attendance_activities aa ON ar.activity_id = aa.id
            JOIN companies c ON e.company_id = c.id
            ORDER BY ar.check_in_time DESC
            LIMIT 10
        ");
        $recentActivities = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($recentActivities)) {
            echo "<div class='overflow-x-auto'>";
            echo "<table class='min-w-full divide-y divide-gray-200'>";
            echo "<thead class='bg-gray-50'>";
            echo "<tr>";
            echo "<th class='px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase'>Tarih/Saat</th>";
            echo "<th class='px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase'>Personel</th>";
            echo "<th class='px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase'>Aktivite</th>";
            echo "<th class='px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase'>Şirket</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody class='divide-y divide-gray-200'>";
            
            foreach ($recentActivities as $activity) {
                echo "<tr class='hover:bg-gray-50'>";
                echo "<td class='px-4 py-2 text-sm text-gray-900'>";
                echo date('d.m.Y H:i', strtotime($activity['check_in_time']));
                echo "</td>";
                echo "<td class='px-4 py-2 text-sm text-gray-900'>";
                echo "{$activity['first_name']} {$activity['last_name']}";
                echo "</td>";
                echo "<td class='px-4 py-2 text-sm text-gray-600'>";
                echo $activity['activity_name'];
                echo "</td>";
                echo "<td class='px-4 py-2 text-sm text-gray-600'>";
                echo $activity['company_name'];
                echo "</td>";
                echo "</tr>";
            }
            
            echo "</tbody>";
            echo "</table>";
            echo "</div>";
        } else {
            echo "<div class='text-center py-8 text-gray-500'>";
            echo "<div class='text-4xl mb-2'>📝</div>";
            echo "<p>Henüz aktivite kaydı bulunmuyor</p>";
            echo "</div>";
        }
    } catch (Exception $e) {
        echo "<div class='text-center py-8 text-red-500'>";
        echo "<div class='text-4xl mb-2'>❌</div>";
        echo "<p>Aktivite verilerine erişilemiyor</p>";
        echo "</div>";
    }
    
    echo "</div>";
    echo "</section>";
    
    // 5. SYSTEM HEALTH SUMMARY
    $healthScore = 0;
    $totalChecks = count($systemHealth);
    foreach ($systemHealth as $status) {
        if ($status === 'good') $healthScore++;
    }
    $healthPercentage = $totalChecks > 0 ? ($healthScore / $totalChecks) * 100 : 0;
    
    echo "<section class='mb-8'>";
    echo "<h2 class='text-xl font-semibold text-gray-800 mb-4'>🎯 Sistem Sağlık Durumu</h2>";
    echo "<div class='bg-white rounded-lg shadow p-6'>";
    
    $statusColor = $healthPercentage >= 90 ? 'green' : ($healthPercentage >= 70 ? 'yellow' : 'red');
    $statusText = $healthPercentage >= 90 ? 'MÜKEMMEL' : ($healthPercentage >= 70 ? 'İYİ' : 'DİKKAT GEREKLİ');
    $statusIcon = $healthPercentage >= 90 ? '🟢' : ($healthPercentage >= 70 ? '🟡' : '🔴');
    
    echo "<div class='text-center mb-6'>";
    echo "<div class='text-6xl mb-4'>$statusIcon</div>";
    echo "<div class='text-3xl font-bold text-{$statusColor}-600 mb-2'>$statusText</div>";
    echo "<div class='text-xl text-gray-600'>" . number_format($healthPercentage, 1) . "% Sağlıklı</div>";
    echo "</div>";
    
    if (!empty($criticalIssues)) {
        echo "<div class='bg-red-50 border-l-4 border-red-400 p-4 mb-4'>";
        echo "<h4 class='font-semibold text-red-800 mb-2'>⚠️ Kritik Sorunlar</h4>";
        foreach ($criticalIssues as $issue) {
            echo "<div class='text-sm text-red-700'>• $issue</div>";
        }
        echo "</div>";
    }
    
    echo "<div class='grid grid-cols-1 md:grid-cols-3 gap-4 mt-6'>";
    echo "<div class='text-center p-4 bg-green-50 rounded-lg'>";
    echo "<div class='text-2xl font-bold text-green-600'>$healthScore</div>";
    echo "<div class='text-sm text-green-600'>Çalışan Modül</div>";
    echo "</div>";
    echo "<div class='text-center p-4 bg-blue-50 rounded-lg'>";
    echo "<div class='text-2xl font-bold text-blue-600'>" . (count($modules) * 2) . "</div>";
    echo "<div class='text-sm text-blue-600'>Toplam Özellik</div>";
    echo "</div>";
    echo "<div class='text-center p-4 bg-purple-50 rounded-lg'>";
    echo "<div class='text-2xl font-bold text-purple-600'>" . count($dataTables) . "</div>";
    echo "<div class='text-sm text-purple-600'>Veri Tablosu</div>";
    echo "</div>";
    echo "</div>";
    
    echo "</div>";
    echo "</section>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='max-w-4xl mx-auto px-4 py-6'>";
    echo "<div class='bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded'>";
    echo "<h2 class='font-bold'>❌ Sistem Analiz Hatası</h2>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
    echo "</div>";
}

// Footer
echo "<div class='bg-white border-t mt-8'>";
echo "<div class='max-w-7xl mx-auto px-4 py-6'>";
echo "<div class='text-center'>";
echo "<div class='grid grid-cols-2 md:grid-cols-5 gap-4 mb-6'>";

$footerLinks = [
    ['name' => '🏠 Ana Sayfa', 'url' => 'system-status-dashboard.php'],
    ['name' => '🔍 Detaylı Kontrol', 'url' => 'system-check.php'],
    ['name' => '⚙️ Sistem Kurulum', 'url' => 'setup-work-settings.php'],
    ['name' => '🧪 Test Araçları', 'url' => 'test-holiday-calculator.php'],
    ['name' => '🔧 Süper Admin', 'url' => 'dashboard/super-admin.php']
];

foreach ($footerLinks as $link) {
    echo "<a href='{$link['url']}' class='block p-3 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm transition-colors'>";
    echo $link['name'];
    echo "</a>";
}

echo "</div>";
echo "<div class='text-sm text-gray-500'>";
echo "<div>SZB İK Takip - v2.0 | PHP " . PHP_VERSION . " | MySQL</div>";
echo "<div>Son Kontrol: " . date('d.m.Y H:i:s') . "</div>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "</body>";
echo "</html>";
?>