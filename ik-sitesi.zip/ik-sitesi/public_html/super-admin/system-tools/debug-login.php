<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Login Debug - SZB İK Takip</h2>";

// Test database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
    echo "✅ Database connection successful<br><br>";
    
    // Check companies table
    echo "<h3>Companies Table:</h3>";
    $stmt = $conn->query("SELECT * FROM companies LIMIT 5");
    $companies = $stmt->fetchAll();
    
    if (empty($companies)) {
        echo "❌ No companies found. Need to add demo data.<br>";
        
        // Add demo company
        $stmt = $conn->prepare("
            INSERT INTO companies (company_name, company_code, email, password, phone, address, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            'Demo Şirketi A.Ş.',
            'DEMO001', 
            'admin@demo.com',
            'demo123', // Plain text password
            '+90 312 123 4567',
            'Atatürk Bulvarı No:123 Çankaya/Ankara',
            'active'
        ]);
        echo "✅ Demo company added<br>";
        
        // Fetch again
        $stmt = $conn->query("SELECT * FROM companies LIMIT 5");
        $companies = $stmt->fetchAll();
    }
    
    foreach ($companies as $company) {
        echo "🏢 Company: {$company['company_name']}<br>";
        echo "📧 Email: {$company['email']}<br>";
        echo "🔑 Password: {$company['password']}<br>";
        echo "🏷️ Code: " . ($company['company_code'] ?? 'NOT SET') . "<br>";
        echo "📍 Status: " . ($company['status'] ?? 'NOT SET') . "<br><br>";
    }
    
    // Test login with exact credentials
    echo "<h3>Login Test:</h3>";
    $testCode = 'DEMO001';
    $testEmail = 'admin@demo.com';
    $testPassword = 'demo123';
    
    $stmt = $conn->prepare("SELECT * FROM companies WHERE company_code = ? AND email = ? AND password = ?");
    $stmt->execute([$testCode, $testEmail, $testPassword]);
    $loginResult = $stmt->fetch();
    
    if ($loginResult) {
        echo "✅ Login SUCCESS with credentials:<br>";
        echo "- Company Code: $testCode<br>";
        echo "- Email: $testEmail<br>";
        echo "- Password: $testPassword<br>";
    } else {
        echo "❌ Login FAILED with credentials:<br>";
        echo "- Company Code: $testCode<br>";
        echo "- Email: $testEmail<br>";
        echo "- Password: $testPassword<br>";
        
        // Try different combinations
        echo "<br>Trying different password combinations:<br>";
        $possiblePasswords = ['demo123', 'Demo123', SHA1('demo123'), md5('demo123'), password_hash('demo123', PASSWORD_DEFAULT)];
        
        foreach ($possiblePasswords as $pass) {
            $stmt = $conn->prepare("SELECT * FROM companies WHERE company_code = ? AND email = ? AND password = ?");
            $stmt->execute([$testCode, $testEmail, $pass]);
            if ($stmt->fetch()) {
                echo "✅ Found match with password: $pass<br>";
                break;
            }
        }
    }
    
    // Check employees table too
    echo "<h3>Employees Table:</h3>";
    $stmt = $conn->query("SELECT * FROM employees LIMIT 3");
    $employees = $stmt->fetchAll();
    
    if (empty($employees)) {
        echo "❌ No employees found. Adding demo employee...<br>";
        
        $stmt = $conn->prepare("
            INSERT INTO employees (company_id, employee_number, first_name, last_name, email, password, position, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            1, 'EMP001', 'Ahmet', 'Yılmaz', 'ahmet@demo.com', 
            'emp123', 'Yazılım Geliştirici', 'active'
        ]);
        echo "✅ Demo employee added<br>";
    }
    
    foreach ($employees as $emp) {
        echo "👤 Employee: {$emp['first_name']} {$emp['last_name']}<br>";
        echo "📧 Email: {$emp['email']}<br>";
        echo "🔑 Password: {$emp['password']}<br>";
        echo "🏷️ Number: {$emp['employee_number']}<br><br>";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
    echo "This means database is not accessible. Using demo mode.<br>";
}

echo "<hr>";
echo "<h3>Login Links:</h3>";
echo '<a href="auth/company-login.php" style="background: #3B82F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-right: 10px;">Yönetici Girişi</a>';
echo '<a href="auth/employee-login.php" style="background: #10B981; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Personel Girişi</a>';
?>