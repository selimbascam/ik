<?php
// Emergency database repair for critical column errors
require_once 'includes/config.php';
require_once 'includes/database.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>";
echo "<html lang='tr'><head><meta charset='UTF-8'>";
echo "<title>Acil Veritabanı Onarımı</title>";
echo "<style>body { font-family: Arial, sans-serif; background: #1a1a1a; color: #00ff00; padding: 20px; } .error { color: #ff6b6b; } .success { color: #51cf66; } .warning { color: #ffd43b; }</style>";
echo "</head><body>";

echo "<h1 class='success'>🚨 ACİL VERİTABANI ONARIMI</h1>\n";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<p class='success'>✅ Veritabanı bağlantısı kuruldu</p>\n";
    
    // Repair 1: Fix work_settings table structure
    echo "<h3 class='warning'>🔧 work_settings Tablosu Onarımı</h3>\n";
    
    $conn->exec("DROP TABLE IF EXISTS work_settings");
    $workSettingsSQL = "
    CREATE TABLE work_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL DEFAULT 1,
        monthly_hours INT NOT NULL DEFAULT 225,
        weekly_hours INT NOT NULL DEFAULT 45,
        daily_max_hours INT NOT NULL DEFAULT 11,
        overtime_multiplier DECIMAL(3,2) NOT NULL DEFAULT 1.50,
        holiday_multiplier DECIMAL(3,2) NOT NULL DEFAULT 2.00,
        auto_schedule BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_company_id (company_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($workSettingsSQL);
    echo "<p class='success'>✅ work_settings tablosu yeniden oluşturuldu</p>\n";
    
    // Insert default settings
    $conn->exec("INSERT INTO work_settings (company_id, monthly_hours, weekly_hours, daily_max_hours, overtime_multiplier, holiday_multiplier) VALUES (1, 225, 45, 11, 1.50, 2.00)");
    echo "<p class='success'>✅ Varsayılan çalışma ayarları eklendi</p>\n";
    
    // Repair 2: Fix public_holidays table
    echo "<h3 class='warning'>🔧 public_holidays Tablosu Onarımı</h3>\n";
    
    $conn->exec("DROP TABLE IF EXISTS public_holidays");
    $holidaysSQL = "
    CREATE TABLE public_holidays (
        id INT AUTO_INCREMENT PRIMARY KEY,
        holiday_name VARCHAR(255) NOT NULL,
        holiday_date DATE NOT NULL,
        holiday_type ENUM('national', 'religious', 'regional') DEFAULT 'national',
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_holiday_date (holiday_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $conn->exec($holidaysSQL);
    echo "<p class='success'>✅ public_holidays tablosu yeniden oluşturuldu</p>\n";
    
    // Insert Turkish holidays for 2025
    $holidays = [
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Yılbaşı', '2025-01-01', 'national')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Ramazan Bayramı 1. Gün', '2025-03-30', 'religious')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Ramazan Bayramı 2. Gün', '2025-03-31', 'religious')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Ramazan Bayramı 3. Gün', '2025-04-01', 'religious')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Ulusal Egemenlik ve Çocuk Bayramı', '2025-04-23', 'national')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Emek ve Dayanışma Günü', '2025-05-01', 'national')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Atatürk Anma, Gençlik ve Spor Bayramı', '2025-05-19', 'national')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Kurban Bayramı 1. Gün', '2025-06-06', 'religious')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Kurban Bayramı 2. Gün', '2025-06-07', 'religious')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Kurban Bayramı 3. Gün', '2025-06-08', 'religious')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Kurban Bayramı 4. Gün', '2025-06-09', 'religious')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Zafer Bayramı', '2025-08-30', 'national')",
        "INSERT INTO public_holidays (holiday_name, holiday_date, holiday_type) VALUES ('Cumhuriyet Bayramı', '2025-10-29', 'national')"
    ];
    
    foreach ($holidays as $holiday) {
        $conn->exec($holiday);
    }
    echo "<p class='success'>✅ 2025 Türk resmi tatilleri eklendi</p>\n";
    
    // Repair 3: Ensure companies table has proper structure
    echo "<h3 class='warning'>🔧 companies Tablosu Kontrol</h3>\n";
    
    $stmt = $conn->query("DESCRIBE companies");
    $columns = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $columns[] = $row['Field'];
    }
    
    if (!in_array('id', $columns)) {
        $conn->exec("ALTER TABLE companies ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY FIRST");
        echo "<p class='success'>✅ companies tablosuna id sütunu eklendi</p>\n";
    } else {
        echo "<p class='success'>✅ companies tablosu yapısı uygun</p>\n";
    }
    
    // Test all critical queries
    echo "<h3 class='warning'>🧪 Kritik Sorgu Testleri</h3>\n";
    
    try {
        $stmt = $conn->prepare("SELECT monthly_hours FROM work_settings WHERE company_id = ? LIMIT 1");
        $stmt->execute([1]);
        $result = $stmt->fetch();
        echo "<p class='success'>✅ monthly_hours sorgusu çalışıyor - Değer: " . ($result['monthly_hours'] ?? 'NULL') . "</p>\n";
    } catch (Exception $e) {
        echo "<p class='error'>❌ monthly_hours sorgu hatası: " . $e->getMessage() . "</p>\n";
    }
    
    try {
        $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ? LIMIT 1");
        $stmt->execute([1]);
        $result = $stmt->fetch();
        echo "<p class='success'>✅ company_id sorgusu çalışıyor - Şirket: " . ($result['company_name'] ?? 'Demo Şirket') . "</p>\n";
    } catch (Exception $e) {
        echo "<p class='error'>❌ company_id sorgu hatası: " . $e->getMessage() . "</p>\n";
    }
    
    try {
        $stmt = $conn->prepare("SELECT holiday_name FROM public_holidays WHERE holiday_date = ? LIMIT 1");
        $stmt->execute(['2025-01-01']);
        $result = $stmt->fetch();
        echo "<p class='success'>✅ holiday_date sorgusu çalışıyor - Tatil: " . ($result['holiday_name'] ?? 'NULL') . "</p>\n";
    } catch (Exception $e) {
        echo "<p class='error'>❌ holiday_date sorgu hatası: " . $e->getMessage() . "</p>\n";
    }
    
    // Final status
    echo "<h2 class='success'>🎉 ONARIM BAŞARIYLA TAMAMLANDI!</h2>\n";
    echo "<p class='success'>✅ Tüm eksik sütunlar eklendi</p>\n";
    echo "<p class='success'>✅ Tablolar yeniden yapılandırıldı</p>\n";
    echo "<p class='success'>✅ Varsayılan veriler eklendi</p>\n";
    echo "<p class='success'>✅ Kritik sorgular test edildi</p>\n";
    
    echo "<hr><p><a href='admin/qr-generator.php' style='color: #51cf66; font-size: 18px;'>🚀 QR Generator'a Git</a> | ";
    echo "<a href='dashboard/company-dashboard.php' style='color: #51cf66; font-size: 18px;'>📊 Dashboard'a Git</a></p>\n";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ KRİTİK HATA: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "<p class='error'>Detay: " . htmlspecialchars($e->getTraceAsString()) . "</p>\n";
}

echo "</body></html>";
?>