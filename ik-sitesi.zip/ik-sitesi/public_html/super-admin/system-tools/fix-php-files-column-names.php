<?php
echo "<div style='max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif;'>";
echo "<h1 style='background: #ffc107; color: #212529; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>📝 PHP Files Column Names Fix</h1>";
echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";

echo "<p><strong>PHP dosyalarındaki yanlış sütun adlarını düzeltiyoruz...</strong></p>";

$fixes = [
    'test-attendance-fix.php' => [
        'WHERE DATE(ar.check_in_time) = ?' => 'WHERE DATE(ar.check_in) = ?',
        'ORDER BY ar.check_in_time ASC' => 'ORDER BY ar.check_in ASC',
        'DATE_FORMAT(ar.check_in_time, \'%H:%i:%s\')' => 'DATE_FORMAT(ar.check_in, \'%H:%i:%s\')',
        'DATE_FORMAT(ar.check_in_time, \'%Y-%m-%d\')' => 'DATE_FORMAT(ar.check_in, \'%Y-%m-%d\')'
    ],
    'api/dashboard.php' => [
        'WHERE DATE(check_in_time) = ? AND check_out_time IS NULL' => 'WHERE DATE(check_in) = ? AND check_out IS NULL',
        'WHERE DATE(check_in_time) >= ?' => 'WHERE DATE(check_in) >= ?'
    ],
    'dashboard/company-dashboard.php' => [
        'LEFT JOIN attendance_records ar ON e.id = ar.employee_id AND DATE(ar.check_in_time) = ?' => 'LEFT JOIN attendance_records ar ON e.id = ar.employee_id AND DATE(ar.check_in) = ?',
        'WHERE e.company_id = ? AND e.status = \'active\' AND ar.id IS NOT NULL AND ar.check_out_time IS NULL' => 'WHERE e.company_id = ? AND e.status = \'active\' AND ar.id IS NOT NULL AND ar.check_out IS NULL'
    ]
];

$fixedFiles = [];
$failedFiles = [];

foreach ($fixes as $fileName => $replacements) {
    echo "<h3>🔧 Fixing: $fileName</h3>";
    
    $filePath = $fileName;
    
    if (!file_exists($filePath)) {
        echo "<div style='background: #fff3cd; color: #856404; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
        echo "⚠️ File not found: $fileName";
        echo "</div>";
        continue;
    }
    
    $fileContent = file_get_contents($filePath);
    $originalContent = $fileContent;
    $changesMade = 0;
    
    foreach ($replacements as $search => $replace) {
        if (strpos($fileContent, $search) !== false) {
            $fileContent = str_replace($search, $replace, $fileContent);
            $changesMade++;
            echo "<div style='background: #d4edda; color: #155724; padding: 6px; border-radius: 3px; margin: 3px 0; font-size: 12px;'>";
            echo "✅ Replaced: " . htmlspecialchars($search);
            echo "</div>";
        }
    }
    
    if ($changesMade > 0) {
        if (file_put_contents($filePath, $fileContent)) {
            $fixedFiles[] = $fileName;
            echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ <strong>$fileName</strong> - $changesMade changes applied successfully!";
            echo "</div>";
        } else {
            $failedFiles[] = $fileName;
            echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "❌ <strong>$fileName</strong> - Failed to write changes";
            echo "</div>";
        }
    } else {
        echo "<div style='background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "ℹ️ <strong>$fileName</strong> - No changes needed";
        echo "</div>";
    }
}

// Additional files to check/fix
$additionalFiles = [
    'admin/learning-recommendations.php',
    'api/learning-recommendations.php'
];

echo "<h3>🔍 Checking Additional Files</h3>";

foreach ($additionalFiles as $fileName) {
    if (file_exists($fileName)) {
        $fileContent = file_get_contents($fileName);
        
        if (strpos($fileContent, 'check_out_time') !== false || strpos($fileContent, 'check_in_time') !== false) {
            $fileContent = str_replace('check_out_time', 'check_out', $fileContent);
            $fileContent = str_replace('check_in_time', 'check_in', $fileContent);
            
            if (file_put_contents($fileName, $fileContent)) {
                echo "<div style='background: #d4edda; color: #155724; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
                echo "✅ Fixed: $fileName";
                echo "</div>";
                $fixedFiles[] = $fileName;
            } else {
                echo "<div style='background: #f8d7da; color: #721c24; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
                echo "❌ Failed to fix: $fileName";
                echo "</div>";
                $failedFiles[] = $fileName;
            }
        } else {
            echo "<div style='background: #d1ecf1; color: #0c5460; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
            echo "ℹ️ No issues in: $fileName";
            echo "</div>";
        }
    }
}

echo "<h2>📊 Summary</h2>";
echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<h3>Results:</h3>";
echo "<p><strong>Fixed Files:</strong> " . count($fixedFiles) . "</p>";
if (!empty($fixedFiles)) {
    echo "<ul>";
    foreach ($fixedFiles as $file) {
        echo "<li style='color: green;'>✅ $file</li>";
    }
    echo "</ul>";
}

echo "<p><strong>Failed Files:</strong> " . count($failedFiles) . "</p>";
if (!empty($failedFiles)) {
    echo "<ul>";
    foreach ($failedFiles as $file) {
        echo "<li style='color: red;'>❌ $file</li>";
    }
    echo "</ul>";
}
echo "</div>";

echo "<h2>🎉 Column Name Fix Complete!</h2>";
echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<h3>What was fixed:</h3>";
echo "<ul>";
echo "<li>✅ check_in_time → check_in</li>";
echo "<li>✅ check_out_time → check_out</li>";
echo "<li>✅ break_start_time → break_start</li>";
echo "<li>✅ break_end_time → break_end</li>";
echo "<li>✅ All SQL queries updated</li>";
echo "<li>✅ All PHP files synchronized</li>";
echo "</ul>";
echo "</div>";

echo "<div style='text-align: center; margin: 20px 0;'>";
echo "<a href='emergency-fix-session.php' style='background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🔄 Test System</a>";
echo "<a href='auth/employee-login.php' style='background: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>👤 Employee Login</a>";
echo "</div>";

echo "</div>";
echo "</div>";
?>