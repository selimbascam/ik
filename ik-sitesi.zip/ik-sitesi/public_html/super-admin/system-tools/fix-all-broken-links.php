<?php
require_once 'includes/config.php';

echo "<h1>🔧 Bozuk Link Onarma Aracı</h1>";

// Düzeltme işlemleri
$fixes = [];

// 1. pages/company-register.php --> admin/company-setup.php yönlendirmesi
if (!file_exists('pages/company-register.php')) {
    file_put_contents('pages/company-register.php', '<?php
header("Location: ../admin/company-setup.php");
exit;
?>');
    $fixes[] = "pages/company-register.php yönlendirme dosyası oluşturuldu";
}

// 2. qr/scanner.php --> qr-reader.php yönlendirmesi
if (!file_exists('qr/scanner.php')) {
    file_put_contents('qr/scanner.php', '<?php
header("Location: qr-reader.php");
exit;
?>');
    $fixes[] = "qr/scanner.php yönlendirme dosyası oluşturuldu";
}

// 3. dashboard/super-admin.php varsa kontrol et, yoksa oluştur
if (!file_exists('dashboard/super-admin.php')) {
    file_put_contents('dashboard/super-admin.php', '<?php
header("Location: ../super-admin/index.php");
exit;
?>');
    $fixes[] = "dashboard/super-admin.php yönlendirme dosyası oluşturuldu";
}

// 4. employees/list.php varsa kontrol et
if (!file_exists('employees/list.php')) {
    file_put_contents('employees/list.php', '<?php
header("Location: ../admin/employee-management.php");
exit;
?>');
    $fixes[] = "employees/list.php yönlendirme dosyası oluşturuldu";
}

// 5. reports/ klasörü kontrol et
if (!is_dir('reports')) {
    mkdir('reports');
    $fixes[] = "reports/ klasörü oluşturuldu";
}

// 6. settings/ klasörü kontrol et
if (!is_dir('settings')) {
    mkdir('settings');
    $fixes[] = "settings/ klasörü oluşturuldu";
}

// 7. settings/company.php oluştur
if (!file_exists('settings/company.php')) {
    file_put_contents('settings/company.php', '<?php
header("Location: ../admin/work-settings.php");
exit;
?>');
    $fixes[] = "settings/company.php yönlendirme dosyası oluşturuldu";
}

// 8. Eksik QR lokasyon dosyaları
if (!file_exists('qr/locations.php')) {
    file_put_contents('qr/locations.php', '<?php
header("Location: ../admin/qr-generator.php");
exit;
?>');
    $fixes[] = "qr/locations.php yönlendirme dosyası oluşturuldu";
}

// 9. attendance/tracker.php kontrol et
if (!file_exists('attendance/tracker.php')) {
    file_put_contents('attendance/tracker.php', '<?php
header("Location: records.php");
exit;
?>');
    $fixes[] = "attendance/tracker.php yönlendirme dosyası oluşturuldu";
}

// 10. reports/earnings-calculator.php varsa kontrol et
if (!file_exists('reports/earnings-calculator.php')) {
    file_put_contents('reports/earnings-calculator.php', '<?php
header("Location: ../attendance/records.php");
exit;
?>');
    $fixes[] = "reports/earnings-calculator.php yönlendirme dosyası oluşturuldu";
}

// Sonuçları göster
if (!empty($fixes)) {
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h2>✅ Başarıyla Düzeltilen Linkler</h2>";
    foreach ($fixes as $fix) {
        echo "<div>• $fix</div>";
    }
    echo "</div>";
} else {
    echo "<div style='background: #cce5ff; padding: 15px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h2>ℹ️ Tüm linkler zaten çalışır durumda</h2>";
    echo "</div>";
}

echo "<div style='text-align: center; margin: 30px 0;'>";
echo "<a href='test-all-links.php' style='background: #007bff; color: white; padding: 15px 25px; text-decoration: none; border-radius: 8px; font-weight: bold;'>🔍 Link Testini Çalıştır</a>";
echo "</div>";

echo "<div style='margin-top: 30px; padding: 15px; background: #f8f9fa; border-radius: 8px; text-align: center; color: #6c757d;'>";
echo "<small>SZB İK Takip - Bozuk Link Onarma Aracı | " . date('d.m.Y H:i:s') . "</small>";
echo "</div>";
?>