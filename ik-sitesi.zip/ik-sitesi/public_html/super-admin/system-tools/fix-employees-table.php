<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Employees Tablosu Tam Düzeltme</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check current table structure
    echo "<h2>📋 Mevcut Tablo Yapısı</h2>";
    $stmt = $conn->query("DESCRIBE employees");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $existing_columns = [];
    foreach ($columns as $col) {
        $existing_columns[] = $col['Field'];
    }
    
    echo "<p>Mevcut sütunlar: " . implode(', ', $existing_columns) . "</p>";
    
    // Required columns for employee login
    $required_columns = [
        'password' => "VARCHAR(255) COMMENT 'Şifreli parola'",
        'working_hours' => "VARCHAR(50) DEFAULT '09:00-17:00' COMMENT 'Çalışma saatleri'",
        'location' => "VARCHAR(255) COMMENT 'Çalışma lokasyonu'",
        'profile_image' => "VARCHAR(255) COMMENT 'Profil resmi URL'"
    ];
    
    $added_columns = [];
    
    // Add missing columns
    foreach ($required_columns as $column => $definition) {
        if (!in_array($column, $existing_columns)) {
            try {
                $sql = "ALTER TABLE employees ADD COLUMN $column $definition";
                $conn->exec($sql);
                $added_columns[] = $column;
                echo "<div style='color: green;'>✅ Sütun eklendi: $column</div>";
            } catch (Exception $e) {
                echo "<div style='color: red;'>❌ Sütun eklenemedi ($column): " . $e->getMessage() . "</div>";
            }
        } else {
            echo "<div style='color: blue;'>ℹ️ Sütun zaten var: $column</div>";
        }
    }
    
    // Insert demo employees with passwords if table is empty
    $stmt = $conn->query("SELECT COUNT(*) as count FROM employees");
    $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($count == 0) {
        echo "<h2>👥 Demo Personel Ekleniyor</h2>";
        
        // First ensure we have companies
        $stmt = $conn->query("SELECT COUNT(*) as count FROM companies");
        $company_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($company_count == 0) {
            // Add demo company
            $stmt = $conn->prepare("
                INSERT INTO companies (company_name, company_code, email, phone, address, status) 
                VALUES (?, ?, ?, ?, ?, 'active')
            ");
            $stmt->execute(['Demo Şirket', 'DEMO001', 'info@demo.com', '0212 555 0001', 'İstanbul', 'active']);
            echo "<div style='color: green;'>✅ Demo şirket eklendi</div>";
        }
        
        // Get first company ID
        $stmt = $conn->query("SELECT id FROM companies LIMIT 1");
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        $company_id = $company['id'];
        
        // Add demo employees
        $demo_employees = [
            [
                'employee_number' => 'EMP001',
                'first_name' => 'Ahmet',
                'last_name' => 'Yılmaz',
                'email' => 'ahmet@demo.com',
                'phone' => '0532 111 1111',
                'position' => 'Yazılım Geliştirici',
                'password' => 'demo123'
            ],
            [
                'employee_number' => 'EMP002', 
                'first_name' => 'Ayşe',
                'last_name' => 'Kaya',
                'email' => 'ayse@demo.com',
                'phone' => '0532 222 2222',
                'position' => 'İK Uzmanı',
                'password' => 'demo123'
            ]
        ];
        
        foreach ($demo_employees as $emp) {
            try {
                $stmt = $conn->prepare("
                    INSERT INTO employees 
                    (company_id, employee_number, first_name, last_name, email, phone, position, password, status, hire_date) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, SHA2(?, 256), 'active', CURDATE())
                ");
                $stmt->execute([
                    $company_id,
                    $emp['employee_number'],
                    $emp['first_name'],
                    $emp['last_name'],
                    $emp['email'],
                    $emp['phone'],
                    $emp['position'],
                    $emp['password']
                ]);
                echo "<div style='color: green;'>✅ Demo personel eklendi: {$emp['first_name']} {$emp['last_name']} (Şifre: {$emp['password']})</div>";
            } catch (Exception $e) {
                echo "<div style='color: red;'>❌ Personel eklenemedi: " . $e->getMessage() . "</div>";
            }
        }
    } else {
        echo "<h2>👥 Mevcut Personel Şifrelerini Güncelle</h2>";
        
        // Update existing employees to have demo passwords
        $stmt = $conn->prepare("
            UPDATE employees 
            SET password = SHA2('demo123', 256) 
            WHERE password IS NULL OR password = ''
        ");
        $affected = $stmt->execute();
        echo "<div style='color: green;'>✅ Şifresiz personellere 'demo123' şifresi atandı</div>";
    }
    
    // Final verification
    echo "<h2>🧪 Son Kontrol</h2>";
    $stmt = $conn->prepare("
        SELECT e.id, e.employee_number, e.first_name, e.last_name, 
               c.company_name, 
               CASE WHEN e.password IS NOT NULL THEN 'VAR' ELSE 'YOK' END as password_status
        FROM employees e 
        LEFT JOIN companies c ON e.company_id = c.id 
        LIMIT 5
    ");
    $stmt->execute();
    $test_employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($test_employees) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Personel No</th><th>Ad Soyad</th><th>Şirket</th><th>Şifre</th></tr>";
        foreach ($test_employees as $emp) {
            echo "<tr>";
            echo "<td>{$emp['id']}</td>";
            echo "<td>{$emp['employee_number']}</td>";
            echo "<td>{$emp['first_name']} {$emp['last_name']}</td>";
            echo "<td>{$emp['company_name']}</td>";
            echo "<td style='color: " . ($emp['password_status'] === 'VAR' ? 'green' : 'red') . ";'>{$emp['password_status']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h2>✅ Employees Tablosu Tamamen Düzeltildi!</h2>";
    echo "<p><strong>Test Bilgileri:</strong></p>";
    echo "<ul>";
    echo "<li>Personel No: EMP001, Şifre: demo123</li>";
    echo "<li>Personel No: EMP002, Şifre: demo123</li>";
    echo "</ul>";
    echo "<p>Artık personel girişi sayfası tam olarak çalışacak.</p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ Hata Oluştu</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div style='text-align: center; margin: 20px 0;'>";
echo "<a href='auth/employee-login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 0 5px;'>🔍 Personel Girişi Test Et</a>";
echo "<a href='verify-database-schema.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 0 5px;'>📋 Şema Kontrolü</a>";
echo "</div>";
?>