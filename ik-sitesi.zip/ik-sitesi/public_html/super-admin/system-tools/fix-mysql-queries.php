<?php
// Fix MySQL Queries - Convert PostgreSQL syntax to MySQL
echo "<h1>MySQL Sorgu Düzeltmeleri</h1>";
echo "<p>Başlangıç: " . date('Y-m-d H:i:s') . "</p><hr>";

$fixes = [];

// Files to check and fix
$phpFiles = [
    'includes/database.php',
    'admin/company-setup.php', 
    'admin/employee-management.php',
    'dashboard/company-dashboard.php',
    'qr/activity-selection.php',
    'attendance/records.php',
    'auth/company-login.php',
    'auth/employee-login.php'
];

foreach ($phpFiles as $file) {
    if (!file_exists($file)) {
        echo "❌ $file - File not found<br>";
        continue;
    }
    
    $content = file_get_contents($file);
    $originalContent = $content;
    $fileFixed = false;
    
    echo "<strong>Checking $file:</strong><br>";
    
    // 1. Fix column references - PostgreSQL vs MySQL
    // companies.name -> companies.company_name
    if (strpos($content, 'c.name') !== false && strpos($content, 'companies c') !== false) {
        $content = str_replace('c.name', 'c.company_name', $content);
        echo "&nbsp;&nbsp;✅ Fixed c.name -> c.company_name<br>";
        $fileFixed = true;
    }
    
    // 2. Fix SERIAL to AUTO_INCREMENT
    if (strpos($content, 'SERIAL') !== false) {
        $content = str_replace('SERIAL', 'INT AUTO_INCREMENT', $content);
        echo "&nbsp;&nbsp;✅ Fixed SERIAL -> INT AUTO_INCREMENT<br>";
        $fileFixed = true;
    }
    
    // 3. Fix BOOLEAN to TINYINT(1)
    if (strpos($content, 'BOOLEAN') !== false) {
        $content = str_replace('BOOLEAN', 'TINYINT(1)', $content);
        echo "&nbsp;&nbsp;✅ Fixed BOOLEAN -> TINYINT(1)<br>";
        $fileFixed = true;
    }
    
    // 4. Fix PostgreSQL cast syntax
    if (strpos($content, '::') !== false) {
        // Remove PostgreSQL cast syntax
        $content = preg_replace('/::[\w\(\)]+/', '', $content);
        echo "&nbsp;&nbsp;✅ Removed PostgreSQL cast syntax<br>";
        $fileFixed = true;
    }
    
    // 5. Fix JSONB to JSON
    if (strpos($content, 'JSONB') !== false) {
        $content = str_replace('JSONB', 'JSON', $content);
        echo "&nbsp;&nbsp;✅ Fixed JSONB -> JSON<br>";
        $fileFixed = true;
    }
    
    // 6. Fix PostgreSQL specific functions
    if (strpos($content, 'NOW()') !== false) {
        // NOW() is fine in MySQL, but check context
        echo "&nbsp;&nbsp;ℹ️ NOW() found - OK for MySQL<br>";
    }
    
    // 7. Fix password hashing - ensure MySQL compatible
    if (strpos($content, 'password_hash') !== false) {
        echo "&nbsp;&nbsp;ℹ️ password_hash() found - OK for MySQL<br>";
    }
    
    // 8. Ensure proper MySQL table engine
    if (strpos($content, 'CREATE TABLE') !== false && strpos($content, 'ENGINE=') === false) {
        $content = str_replace('CREATE TABLE', 'CREATE TABLE', $content);
        // Add ENGINE=InnoDB to table creation if not present
        $content = preg_replace('/\);$/', ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;', $content);
        echo "&nbsp;&nbsp;✅ Added MySQL ENGINE and CHARSET<br>";
        $fileFixed = true;
    }
    
    if ($fileFixed) {
        file_put_contents($file, $content);
        $fixes[] = "Fixed MySQL compatibility in $file";
        echo "&nbsp;&nbsp;💾 File updated<br>";
    } else {
        echo "&nbsp;&nbsp;✅ No MySQL issues found<br>";
    }
    
    echo "<br>";
}

// Special fixes for database connection
$dbFile = 'includes/database.php';
if (file_exists($dbFile)) {
    $content = file_get_contents($dbFile);
    $originalContent = $content;
    
    // Ensure PDO MySQL configuration
    if (strpos($content, 'PDO::MYSQL_ATTR_INIT_COMMAND') === false) {
        $content = str_replace(
            'PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION',
            'PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"',
            $content
        );
        echo "✅ Added MySQL UTF8MB4 initialization<br>";
    }
    
    if ($content !== $originalContent) {
        file_put_contents($dbFile, $content);
        $fixes[] = "Updated MySQL configuration in $dbFile";
    }
}

echo "<hr>";
echo "<h2>Özet</h2>";
echo "<p>Toplam düzeltme: " . count($fixes) . "</p>";
foreach ($fixes as $fix) {
    echo "• $fix<br>";
}

echo "<p>Bitiş: " . date('Y-m-d H:i:s') . "</p>";
?>