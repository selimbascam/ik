<?php
require_once 'auth-check.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veritabanı Onarımı - Süper Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
        }
        .header {
            background: linear-gradient(135deg, #dc3545 0%, #bd2130 100%);
            color: white;
            padding: 30px;
            margin: -20px -20px 20px -20px;
            border-radius: 8px 8px 0 0;
        }
        .repair-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .repair-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #dc3545;
        }
        .repair-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 5px 5px 5px 0;
        }
        .repair-btn:hover {
            background: #c82333;
        }
        .safe-btn {
            background: #28a745;
        }
        .safe-btn:hover {
            background: #218838;
        }
        .warning-btn {
            background: #ffc107;
            color: #333;
        }
        .warning-btn:hover {
            background: #e0a800;
        }
        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        .warning-box {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 8px;
            color: #856404;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔧 Veritabanı Onarımı</h1>
            <p>Kritik veritabanı onarım araçları</p>
        </div>
        
        <div class="warning-box">
            <h3>⚠️ DİKKAT!</h3>
            <p>Bu araçlar veritabanında değişiklik yapabilir. Kullanmadan önce yedek almayı unutmayın!</p>
        </div>
        
        <div class="repair-grid">
            <div class="repair-card">
                <h3>🛠️ Tablo Onarımları</h3>
                <p>Eksik tablolar ve sütunları onar</p>
                <a href="../../create-missing-tables.php" class="repair-btn safe-btn" target="_blank">Eksik Tablolar</a>
                <a href="../../setup-missing-tables.php" class="repair-btn safe-btn" target="_blank">Tablo Kurulumu</a>
                <a href="../../direct-table-setup.php" class="repair-btn warning-btn" target="_blank">Direkt Tablo</a>
            </div>
            
            <div class="repair-card">
                <h3>📱 QR Lokasyon Onarımları</h3>
                <p>QR kod tablosu ve sütun hatalarını düzelt</p>
                <a href="../fix-center.php" class="repair-btn">Hata Merkezi</a>
                <a href="../../admin/emergency-fix-qr-table.php" class="repair-btn" target="_blank">Acil QR Düzeltme</a>
                <a href="../../admin/fix-qr-locations-columns.php" class="repair-btn" target="_blank">QR Sütun Düzeltme</a>
            </div>
            
            <div class="repair-card">
                <h3>🔐 Oturum Onarımları</h3>
                <p>Session tablosu ve oturum sorunlarını çöz</p>
                <a href="fix-session-table.php" class="repair-btn">Session Tablosu</a>
                <a href="session-tools.php" class="repair-btn safe-btn">Oturum Araçları</a>
                <a href="../../auth/logout.php" class="repair-btn warning-btn" target="_blank">Oturumları Temizle</a>
            </div>
            
            <div class="repair-card">
                <h3>👥 Personel Tabloları</h3>
                <p>Employee ve ilgili tabloları onar</p>
                <a href="fix-employee-tables.php" class="repair-btn">Personel Tabloları</a>
                <a href="../../setup-demo-locations.php" class="repair-btn safe-btn" target="_blank">Demo Lokasyonlar</a>
                <a href="../../add-device-info-columns.php" class="repair-btn safe-btn" target="_blank">Cihaz Sütunları</a>
            </div>
            
            <div class="repair-card">
                <h3>🌐 Karakter Seti Onarımları</h3>
                <p>UTF-8 ve charset sorunlarını düzelt</p>
                <a href="fix-charset.php" class="repair-btn">Charset Düzeltme</a>
                <a href="../../includes/database-fix.php" class="repair-btn safe-btn" target="_blank">DB Fix Include</a>
            </div>
            
            <div class="repair-card">
                <h3>🏢 Şirket Sistemi</h3>
                <p>Company tablosu ve çoklu şirket sistemi</p>
                <a href="../../admin/company-setup.php" class="repair-btn safe-btn" target="_blank">Şirket Kurulumu</a>
                <a href="../../create-database.php" class="repair-btn warning-btn" target="_blank">Veritabanı Oluştur</a>
                <a href="../../install-database.php" class="repair-btn" target="_blank">DB Kurulumu</a>
            </div>
            
            <div class="repair-card">
                <h3>📊 Veri Tutarlılığı</h3>
                <p>Veri bütünlüğü ve foreign key kontrolü</p>
                <a href="../../setup-work-settings.php" class="repair-btn safe-btn" target="_blank">İş Ayarları</a>
                <a href="../../setup-activity-types-table.php" class="repair-btn safe-btn" target="_blank">Aktivite Tipleri</a>
                <a href="../../setup-learning-engine.php" class="repair-btn safe-btn" target="_blank">Öğrenme Motoru</a>
            </div>
            
            <div class="repair-card">
                <h3>🚨 Acil Durum Araçları</h3>
                <p>Kritik sistem hatalarını hızla çöz</p>
                <a href="../../update-super-admin.php" class="repair-btn" target="_blank">Süper Admin Güncelle</a>
                <a href="../../google-maps-setup.php" class="repair-btn safe-btn" target="_blank">Google Maps</a>
                <a href="../system-logs.php" class="repair-btn safe-btn">Sistem Logları</a>
            </div>
        </div>
        
        <div style="margin-top: 30px; padding: 20px; background: #d1ecf1; border-radius: 8px; border-left: 4px solid #17a2b8;">
            <h3>ℹ️ Onarım Sırası Önerisi</h3>
            <ol>
                <li><strong>Veritabanı Oluştur</strong> - İlk kurulum için</li>
                <li><strong>Eksik Tablolar</strong> - Temel tabloları oluştur</li>
                <li><strong>QR Sütun Düzeltme</strong> - QR sistem hatalarını çöz</li>
                <li><strong>Session Tablosu</strong> - Oturum sistemini düzelt</li>
                <li><strong>Charset Düzeltme</strong> - Türkçe karakter sorunlarını çöz</li>
                <li><strong>Şirket Kurulumu</strong> - Multi-tenant sistemi aktifleştir</li>
            </ol>
        </div>
        
        <a href="../index.php" class="back-btn">← Süper Admin Panel</a>
    </div>
</body>
</html>