<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Duplicate QR Code Fix</h1>";
echo "<p>Düzeltme: Duplicate qr_code hatalarını çözüyor...</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div style='background: #f8f9fa; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; margin-bottom: 20px;'>";
    echo "<h3>🔍 Duplicate QR Code Düzeltme İşlemleri:</h3>";
    
    $fixCount = 0;
    $errorCount = 0;
    
    // Find duplicate qr_codes
    $stmt = $conn->query("
        SELECT qr_code, COUNT(*) as count 
        FROM qr_locations 
        GROUP BY qr_code 
        HAVING COUNT(*) > 1
    ");
    $duplicates = $stmt->fetchAll();
    
    if (empty($duplicates)) {
        echo "<div style='color: green;'>✓ Duplicate qr_code bulunamadı</div>";
    } else {
        echo "<div style='color: orange;'>⚠ " . count($duplicates) . " duplicate qr_code bulundu - düzeltiliyor...</div>";
        
        foreach ($duplicates as $duplicate) {
            echo "<br><strong>Duplicate QR Code:</strong> {$duplicate['qr_code']} ({$duplicate['count']} adet)<br>";
            
            // Get all records with this qr_code
            $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE qr_code = ? ORDER BY id");
            $stmt->execute([$duplicate['qr_code']]);
            $records = $stmt->fetchAll();
            
            // Keep first record, fix others
            foreach ($records as $index => $record) {
                if ($index === 0) {
                    echo "- Korunuyor: ID {$record['id']} - {$record['name']}<br>";
                    continue;
                }
                
                // Generate new unique qr_code
                $newQrCode = generateUniqueQrCode($conn, $record['company_id']);
                
                // Update record
                $updateStmt = $conn->prepare("UPDATE qr_locations SET qr_code = ? WHERE id = ?");
                $updateStmt->execute([$newQrCode, $record['id']]);
                
                echo "- Düzeltildi: ID {$record['id']} - {$record['name']} -> $newQrCode<br>";
                $fixCount++;
            }
        }
    }
    
    // Check for missing qr_codes (NULL or empty)
    $stmt = $conn->query("SELECT * FROM qr_locations WHERE qr_code IS NULL OR qr_code = ''");
    $missingQr = $stmt->fetchAll();
    
    if (!empty($missingQr)) {
        echo "<br><div style='color: orange;'>⚠ " . count($missingQr) . " kayıtta qr_code eksik - dolduru...</div>";
        
        foreach ($missingQr as $record) {
            $newQrCode = generateUniqueQrCode($conn, $record['company_id']);
            
            $updateStmt = $conn->prepare("UPDATE qr_locations SET qr_code = ? WHERE id = ?");
            $updateStmt->execute([$newQrCode, $record['id']]);
            
            echo "- Eklendi: ID {$record['id']} - {$record['name']} -> $newQrCode<br>";
            $fixCount++;
        }
    } else {
        echo "<div style='color: green;'>✓ Tüm kayıtlarda qr_code mevcut</div>";
    }
    
    echo "</div>";
    
    if ($errorCount === 0) {
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px;'>";
        echo "<h3>🎉 QR Code Duplicates Başarıyla Düzeltildi!</h3>";
        echo "<p><strong>Özet:</strong></p>";
        echo "<ul>";
        echo "<li>✓ $fixCount düzeltme yapıldı</li>";
        echo "<li>✓ Tüm qr_code değerleri benzersiz</li>";
        echo "<li>✓ Eksik qr_code değerleri dolduruldu</li>";
        echo "<li>✓ Duplicate constraint violation çözüldü</li>";
        echo "</ul>";
        echo "<p><strong>Sonraki Adımlar:</strong></p>";
        echo "<ul>";
        echo "<li>Şirket kayıt sistemi artık QR lokasyonları oluşturabilir</li>";
        echo "<li>QR duplicate hatası çözüldü</li>";
        echo "<li>Yeni şirketler sorunsuz oluşturulabilir</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
        echo "<h3>⚠ Kısmi Düzeltme Tamamlandı</h3>";
        echo "<p><strong>Özet:</strong></p>";
        echo "<ul>";
        echo "<li>✓ $fixCount düzeltme başarılı</li>";
        echo "<li>❌ $errorCount hata oluştu</li>";
        echo "</ul>";
        echo "</div>";
    }
    
    // Show current QR codes status
    echo "<div style='background: #e3f2fd; padding: 15px; border: 1px solid #bbdefb; border-radius: 5px; margin-top: 20px;'>";
    echo "<h3>📋 Güncel QR Code Durumu:</h3>";
    
    $stmt = $conn->query("
        SELECT 
            COUNT(*) as total_qr_codes,
            COUNT(DISTINCT qr_code) as unique_qr_codes,
            COUNT(*) - COUNT(DISTINCT qr_code) as duplicates
        FROM qr_locations 
        WHERE qr_code IS NOT NULL AND qr_code != ''
    ");
    $status = $stmt->fetch();
    
    echo "<table style='width: 100%; border-collapse: collapse; margin-top: 10px;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Metrik</th>";
    echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Değer</th>";
    echo "</tr>";
    echo "<tr><td style='border: 1px solid #dee2e6; padding: 8px;'>Toplam QR Location</td><td style='border: 1px solid #dee2e6; padding: 8px;'>{$status['total_qr_codes']}</td></tr>";
    echo "<tr><td style='border: 1px solid #dee2e6; padding: 8px;'>Benzersiz QR Code</td><td style='border: 1px solid #dee2e6; padding: 8px;'>{$status['unique_qr_codes']}</td></tr>";
    echo "<tr><td style='border: 1px solid #dee2e6; padding: 8px;'>Duplicate</td><td style='border: 1px solid #dee2e6; padding: 8px; color: " . ($status['duplicates'] > 0 ? 'red' : 'green') . ";'>{$status['duplicates']}</td></tr>";
    echo "</table>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Düzeltme Hatası</h3>";
    echo "<p><strong>Hata:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

function generateUniqueQrCode($conn, $companyId) {
    // Get company code
    $stmt = $conn->prepare("SELECT company_code FROM companies WHERE id = ?");
    $stmt->execute([$companyId]);
    $company = $stmt->fetch();
    $companyCode = $company['company_code'] ?? 'UNK';
    
    // Generate unique QR code
    $attempts = 0;
    do {
        $attempts++;
        $timestamp = time();
        $random = str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
        $qrCode = 'QR_' . $companyCode . '_' . $timestamp . '_' . $random;
        
        // Check if exists
        $checkStmt = $conn->prepare("SELECT id FROM qr_locations WHERE qr_code = ?");
        $checkStmt->execute([$qrCode]);
        $exists = $checkStmt->fetch();
        
        if (!$exists) {
            return $qrCode;
        }
        
    } while ($attempts < 10);
    
    // Fallback - use UUID-like
    return 'QR_' . $companyCode . '_' . uniqid();
}

echo "<hr>";
echo "<p><a href='admin/company-setup.php'>← Şirket Kayıt Sayfasına Dön</a></p>";
echo "<p><a href='database-overview.php'>📊 Veritabanı Durumunu Kontrol Et</a></p>";
?>