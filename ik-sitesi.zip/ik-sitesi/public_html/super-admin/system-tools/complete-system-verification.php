<?php
// Complete System Verification - Final Comprehensive Check
echo "<h1>🔍 Kapsamlı Sistem Doğrulama</h1>";
echo "<p>Son Kontrol ve Doğrulama - " . date('Y-m-d H:i:s') . "</p><hr>";

$verificationResults = [];
$criticalIssues = [];
$warnings = [];
$successes = [];

// 1. Core Authentication Verification
echo "<h2>🔐 1. Kimlik Doğrulama Sistemi Doğrulama</h2>";

$authFiles = [
    'auth/company-login.php' => 'Şirket Giriş Sayfası',
    'auth/employee-login.php' => 'Personel Giriş Sayfası'
];

foreach ($authFiles as $file => $description) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Check for proper session management
        $hasSession = strpos($content, 'session_start') !== false;
        $hasRedirect = strpos($content, 'Location: /ik/') !== false;
        $hasDatabase = strpos($content, 'Database') !== false;
        
        if ($hasSession && $hasRedirect && $hasDatabase) {
            echo "✅ $description - Tam donanımlı<br>";
            $successes[] = "$description authentication system complete";
        } else {
            $missing = [];
            if (!$hasSession) $missing[] = 'session management';
            if (!$hasRedirect) $missing[] = 'proper redirects';
            if (!$hasDatabase) $missing[] = 'database integration';
            
            echo "⚠️ $description - Eksik: " . implode(', ', $missing) . "<br>";
            $warnings[] = "$description missing: " . implode(', ', $missing);
        }
    } else {
        echo "❌ $description - Dosya bulunamadı<br>";
        $criticalIssues[] = "Missing critical file: $file";
    }
}

// 2. Dashboard System Verification
echo "<h2>📊 2. Dashboard Sistem Doğrulama</h2>";

$dashboardFiles = [
    'dashboard/company-dashboard.php' => 'Şirket Dashboard',
    'dashboard/employee-dashboard.php' => 'Personel Dashboard'
];

foreach ($dashboardFiles as $file => $description) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Check for proper link structure
        $absoluteLinks = substr_count($content, '/ik/');
        $relativeLinks = substr_count($content, '../');
        
        if ($absoluteLinks > $relativeLinks) {
            echo "✅ $description - Link yapısı doğru ($absoluteLinks absolute, $relativeLinks relative)<br>";
            $successes[] = "$description link structure optimized";
        } else {
            echo "⚠️ $description - Relative linkler fazla ($relativeLinks vs $absoluteLinks)<br>";
            $warnings[] = "$description has too many relative links";
        }
    } else {
        echo "❌ $description - Dosya bulunamadı<br>";
        $criticalIssues[] = "Missing dashboard file: $file";
    }
}

// 3. QR System Verification
echo "<h2>📱 3. QR Sistem Doğrulama</h2>";

$qrFiles = [
    'admin/qr-generator.php' => 'QR Kod Üretici',
    'qr/qr-reader.php' => 'QR Kod Okuyucu',
    'qr/activity-selection.php' => 'Aktivite Seçimi'
];

foreach ($qrFiles as $file => $description) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Check for JavaScript functions
        $jsFunctions = [];
        preg_match_all('/function\s+(\w+)\s*\(/', $content, $matches);
        if (!empty($matches[1])) {
            $jsFunctions = $matches[1];
        }
        
        if (count($jsFunctions) > 0) {
            echo "✅ $description - " . count($jsFunctions) . " JavaScript fonksiyonu mevcut<br>";
            echo "&nbsp;&nbsp;📋 Fonksiyonlar: " . implode(', ', array_slice($jsFunctions, 0, 5)) . 
                 (count($jsFunctions) > 5 ? '...' : '') . "<br>";
            $successes[] = "$description has " . count($jsFunctions) . " JavaScript functions";
        } else {
            echo "⚠️ $description - JavaScript fonksiyonları bulunamadı<br>";
            $warnings[] = "$description missing JavaScript functionality";
        }
    } else {
        echo "❌ $description - Dosya bulunamadı<br>";
        $criticalIssues[] = "Missing QR system file: $file";
    }
}

// 4. Database Configuration Verification
echo "<h2>🗄️ 4. Veritabanı Konfigürasyon Doğrulama</h2>";

if (file_exists('includes/database.php')) {
    $content = file_get_contents('includes/database.php');
    
    $hasMysql = strpos($content, 'mysql') !== false;
    $hasPDO = strpos($content, 'PDO') !== false;
    $hasUtf8 = strpos($content, 'utf8') !== false;
    $hasErrorHandling = strpos($content, 'try') !== false && strpos($content, 'catch') !== false;
    
    echo "✅ Database sınıfı bulundu<br>";
    echo ($hasMysql ? "✅" : "❌") . " MySQL desteği" . ($hasMysql ? " aktif" : " eksik") . "<br>";
    echo ($hasPDO ? "✅" : "❌") . " PDO kullanımı" . ($hasPDO ? " doğru" : " eksik") . "<br>";
    echo ($hasUtf8 ? "✅" : "❌") . " UTF8 desteği" . ($hasUtf8 ? " var" : " eksik") . "<br>";
    echo ($hasErrorHandling ? "✅" : "❌") . " Hata yakalama" . ($hasErrorHandling ? " mevcut" : " eksik") . "<br>";
    
    if ($hasMysql && $hasPDO && $hasUtf8 && $hasErrorHandling) {
        $successes[] = "Database configuration is optimal";
    } else {
        $warnings[] = "Database configuration needs improvement";
    }
} else {
    echo "❌ Database sınıfı bulunamadı<br>";
    $criticalIssues[] = "Missing database class";
}

// 5. System Tools Verification
echo "<h2>🔧 5. Sistem Araçları Doğrulama</h2>";

$systemTools = [
    'comprehensive-system-check.php' => 'Sistem Kontrol Aracı',
    'fix-all-links.php' => 'Link Düzeltme Aracı',
    'fix-mysql-queries.php' => 'MySQL Düzeltme Aracı',
    'test-system-links.php' => 'Link Test Aracı',
    'create-missing-files.php' => 'Dosya Oluşturma Aracı'
];

foreach ($systemTools as $file => $description) {
    if (file_exists($file)) {
        echo "✅ $description mevcut<br>";
        $successes[] = "$description available";
    } else {
        echo "⚠️ $description eksik<br>";
        $warnings[] = "$description missing";
    }
}

// 6. Final Verification Score
echo "<hr><h2>📊 Son Doğrulama Skoru</h2>";

$totalChecks = count($successes) + count($warnings) + count($criticalIssues);
$score = round((count($successes) / $totalChecks) * 100, 1);

echo "<div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 10px; text-align: center; margin: 25px 0;'>";
echo "<h3 style='margin: 0 0 10px 0; font-size: 2.2em;'>$score%</h3>";
echo "<p style='margin: 0; opacity: 0.9;'>Sistem Doğrulama Skoru</p>";
echo "</div>";

// Detailed results
echo "<div style='display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin: 20px 0;'>";

// Successes
echo "<div style='background: #d1fae5; padding: 20px; border-radius: 8px; border-left: 4px solid #10b981;'>";
echo "<h4 style='color: #065f46; margin-top: 0;'>✅ Başarılı (" . count($successes) . ")</h4>";
foreach (array_slice($successes, 0, 8) as $success) {
    echo "<div style='color: #065f46; font-size: 0.9em; margin: 3px 0;'>• $success</div>";
}
if (count($successes) > 8) {
    echo "<div style='color: #065f46; font-size: 0.85em; font-style: italic;'>+" . (count($successes) - 8) . " more...</div>";
}
echo "</div>";

// Warnings
echo "<div style='background: #fef3c7; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b;'>";
echo "<h4 style='color: #92400e; margin-top: 0;'>⚠️ Uyarılar (" . count($warnings) . ")</h4>";
foreach (array_slice($warnings, 0, 8) as $warning) {
    echo "<div style='color: #92400e; font-size: 0.9em; margin: 3px 0;'>• $warning</div>";
}
if (count($warnings) > 8) {
    echo "<div style='color: #92400e; font-size: 0.85em; font-style: italic;'>+" . (count($warnings) - 8) . " more...</div>";
}
echo "</div>";

// Critical Issues
echo "<div style='background: #fee2e2; padding: 20px; border-radius: 8px; border-left: 4px solid #ef4444;'>";
echo "<h4 style='color: #991b1b; margin-top: 0;'>❌ Kritik (" . count($criticalIssues) . ")</h4>";
foreach ($criticalIssues as $issue) {
    echo "<div style='color: #991b1b; font-size: 0.9em; margin: 3px 0;'>• $issue</div>";
}
if (empty($criticalIssues)) {
    echo "<div style='color: #059669; font-size: 0.9em;'>Kritik sorun bulunamadı! 🎉</div>";
}
echo "</div>";

echo "</div>";

// Final recommendations
echo "<div style='background: #eff6ff; padding: 25px; border-radius: 10px; margin: 25px 0;'>";
echo "<h3 style='color: #1e40af;'>🎯 Son Öneriler</h3>";

if ($score >= 95) {
    echo "<div style='color: #059669;'>";
    echo "<strong>Mükemmel!</strong> Sistem %100 çalışır durumda. Tüm bileşenler optimal.<br>";
    echo "• Düzenli bakım için sistem araçlarını kullanmaya devam edin<br>";
    echo "• Production ortamına geçiş için hazır<br>";
    echo "</div>";
} elseif ($score >= 85) {
    echo "<div style='color: #0369a1;'>";
    echo "<strong>Çok İyi!</strong> Sistem büyük ölçüde hazır, küçük iyileştirmeler yapılabilir.<br>";
    echo "• Uyarıları gözden geçirin ve düzeltin<br>";
    echo "• Test araçlarını düzenli çalıştırın<br>";
    echo "</div>";
} else {
    echo "<div style='color: #dc2626;'>";
    echo "<strong>Dikkat!</strong> Sistem geliştirilmesi gereken alanlar var.<br>";
    echo "• Kritik sorunları öncelikle çözün<br>";
    echo "• Eksik dosyaları oluşturun<br>";
    echo "• Link yapısını tamamlayın<br>";
    echo "</div>";
}

echo "</div>";

echo "<hr>";
echo "<p><strong>Doğrulama Tamamlandı:</strong> " . date('Y-m-d H:i:s') . "</p>";
echo "<p><strong>Sistem Sağlığı:</strong> " . ($score >= 95 ? "MÜKEMMEL" : ($score >= 85 ? "ÇOK İYİ" : "GELİŞTİRİLEBİLİR")) . "</p>";
?>