<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

// Emergency system repair and optimization
echo "<h1>🚨 Acil Sistem Onarımı</h1>";
echo "<div style='font-family: Arial; margin: 20px; background: #f8f9fa; padding: 20px; border-radius: 8px;'>";

$repairs = [];
$critical_fixes = [];

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // 1. CRITICAL DATABASE REPAIRS
    echo "<h2>🗄️ Kritik Veritabanı Onarımları</h2>";
    
    // Check and repair tables
    $tables = ['companies', 'employees', 'attendance_records', 'qr_locations', 'work_settings', 'public_holidays'];
    foreach ($tables as $table) {
        try {
            $stmt = $conn->query("CHECK TABLE $table");
            $result = $stmt->fetch();
            if ($result['Msg_text'] !== 'OK') {
                $conn->query("REPAIR TABLE $table");
                $critical_fixes[] = "Tablo onarıldı: $table";
            }
        } catch (Exception $e) {
            $critical_fixes[] = "Tablo kontrolü başarısız: $table - " . $e->getMessage();
        }
    }
    
    // 2. MISSING COLUMNS EMERGENCY FIX
    $essential_columns = [
        'employees' => [
            'password' => "ALTER TABLE employees ADD COLUMN password VARCHAR(255) AFTER email",
            'status' => "ALTER TABLE employees ADD COLUMN status ENUM('active', 'inactive') DEFAULT 'active'",
            'created_at' => "ALTER TABLE employees ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP"
        ],
        'companies' => [
            'company_code' => "ALTER TABLE companies ADD COLUMN company_code VARCHAR(10) UNIQUE",
            'status' => "ALTER TABLE companies ADD COLUMN status VARCHAR(20) DEFAULT 'active'"
        ],
        'qr_locations' => [
            'latitude' => "ALTER TABLE qr_locations ADD COLUMN latitude DECIMAL(10,8)",
            'longitude' => "ALTER TABLE qr_locations ADD COLUMN longitude DECIMAL(11,8)"
        ]
    ];
    
    foreach ($essential_columns as $table => $columns) {
        foreach ($columns as $column => $sql) {
            try {
                $stmt = $conn->query("SHOW COLUMNS FROM $table LIKE '$column'");
                if ($stmt->rowCount() === 0) {
                    $conn->exec($sql);
                    $critical_fixes[] = "Kritik sütun eklendi: $table.$column";
                }
            } catch (Exception $e) {
                $critical_fixes[] = "Sütun ekleme başarısız: $table.$column";
            }
        }
    }
    
    // 3. EMERGENCY DATA POPULATION
    // Add demo company if none exists
    $stmt = $conn->query("SELECT COUNT(*) FROM companies");
    if ($stmt->fetchColumn() === 0) {
        $stmt = $conn->prepare("INSERT INTO companies (company_name, company_code, email, password, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['Demo Şirket', 'DEMO001', 'admin@demo.com', password_hash('demo123', PASSWORD_DEFAULT), 'active']);
        $critical_fixes[] = "Acil demo şirket oluşturuldu";
    }
    
    // Add demo employees if none exists
    $stmt = $conn->query("SELECT COUNT(*) FROM employees");
    if ($stmt->fetchColumn() === 0) {
        $stmt = $conn->prepare("INSERT INTO employees (company_id, employee_number, first_name, last_name, email, password, status) VALUES (1, ?, ?, ?, ?, ?, ?)");
        $demoEmployees = [
            ['EMP001', 'Demo', 'Personel1', 'emp001@demo.com'],
            ['EMP002', 'Demo', 'Personel2', 'emp002@demo.com'],
            ['EMP003', 'Demo', 'Personel3', 'emp003@demo.com']
        ];
        
        foreach ($demoEmployees as $emp) {
            $stmt->execute(array_merge($emp, [password_hash('demo123', PASSWORD_DEFAULT), 'active']));
        }
        $critical_fixes[] = "Acil demo personeller oluşturuldu (3 adet)";
    }
    
    // 4. ESSENTIAL WORK SETTINGS
    $stmt = $conn->query("SELECT COUNT(*) FROM work_settings");
    if ($stmt->fetchColumn() === 0) {
        $stmt = $conn->prepare("INSERT INTO work_settings (company_id, monthly_hours, weekly_hours, daily_max_hours, overtime_multiplier, holiday_multiplier, hourly_rate) VALUES (1, 225, 45, 11, 1.5, 2.0, 50.00)");
        $stmt->execute();
        $critical_fixes[] = "Acil çalışma ayarları oluşturuldu";
    }
    
    // 5. QR LOCATIONS EMERGENCY
    $stmt = $conn->query("SELECT COUNT(*) FROM qr_locations");
    if ($stmt->fetchColumn() === 0) {
        $emergencyLocations = [
            ['Demo Ana Giriş', 'QR_DEMO_001', 1, 41.0082, 28.9784],
            ['Demo Ofis', 'QR_DEMO_002', 1, 41.0085, 28.9787],
            ['Demo Yemekhane', 'QR_DEMO_003', 1, 41.0080, 28.9780]
        ];
        
        $stmt = $conn->prepare("INSERT INTO qr_locations (name, qr_code, company_id, latitude, longitude) VALUES (?, ?, ?, ?, ?)");
        foreach ($emergencyLocations as $loc) {
            $stmt->execute($loc);
        }
        $critical_fixes[] = "Acil QR lokasyonları oluşturuldu (3 adet)";
    }
    
    // 6. CURRENT YEAR HOLIDAYS
    $currentYear = date('Y');
    $stmt = $conn->prepare("SELECT COUNT(*) FROM public_holidays WHERE year = ?");
    $stmt->execute([$currentYear]);
    if ($stmt->fetchColumn() < 5) {
        $emergencyHolidays = [
            ['Yılbaşı', "$currentYear-01-01"],
            ['Ulusal Egemenlik ve Çocuk Bayramı', "$currentYear-04-23"],
            ['İşçi Bayramı', "$currentYear-05-01"],
            ['Atatürk\'ü Anma Gençlik ve Spor Bayramı', "$currentYear-05-19"],
            ['Zafer Bayramı', "$currentYear-08-30"],
            ['Cumhuriyet Bayramı', "$currentYear-10-29"]
        ];
        
        $stmt = $conn->prepare("INSERT IGNORE INTO public_holidays (holiday_name, holiday_date, year, holiday_type) VALUES (?, ?, ?, 'national')");
        foreach ($emergencyHolidays as $holiday) {
            $stmt->execute([$holiday[0], $holiday[1], $currentYear]);
        }
        $critical_fixes[] = "$currentYear yılı acil tatilleri eklendi";
    }
    
} catch (Exception $e) {
    $critical_fixes[] = "Acil onarım hatası: " . $e->getMessage();
}

// 7. FILE SYSTEM EMERGENCY REPAIRS
$criticalFiles = [
    'auth/employee-login.php' => 'Personel giriş sayfası',
    'auth/company-login.php' => 'Şirket giriş sayfası',
    'dashboard/company-dashboard.php' => 'Şirket paneli',
    'qr/qr-reader.php' => 'QR okuyucu',
    'admin/work-settings.php' => 'Çalışma ayarları'
];

foreach ($criticalFiles as $file => $desc) {
    if (!file_exists($file)) {
        $critical_fixes[] = "KRİTİK DOSYA EKSİK: $desc ($file)";
    } elseif (filesize($file) === 0) {
        $critical_fixes[] = "KRİTİK DOSYA BOŞ: $desc ($file)";
    } else {
        $repairs[] = "$desc mevcut ve çalışır durumda";
    }
}

// DISPLAY RESULTS
if (!empty($critical_fixes)) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; margin: 15px 0; border-radius: 5px;'>";
    echo "<h3 style='color: #721c24; margin-top: 0;'>🚨 Kritik Onarımlar Gerçekleştirildi</h3>";
    foreach ($critical_fixes as $fix) {
        echo "<div style='color: #721c24; margin: 5px 0;'>• $fix</div>";
    }
    echo "</div>";
}

if (!empty($repairs)) {
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; margin: 15px 0; border-radius: 5px;'>";
    echo "<h3 style='color: #155724; margin-top: 0;'>✅ Sistem Kontrolleri</h3>";
    foreach ($repairs as $repair) {
        echo "<div style='color: #155724; margin: 5px 0;'>• $repair</div>";
    }
    echo "</div>";
}

// EMERGENCY STATUS
$totalIssues = count($critical_fixes);
if ($totalIssues === 0) {
    echo "<div style='text-align: center; background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<div style='font-size: 48px; margin-bottom: 10px;'>✅</div>";
    echo "<div style='font-size: 24px; color: #155724; font-weight: bold;'>SİSTEM ACİL DURUMDA DEĞİL</div>";
    echo "<div style='color: #155724;'>Tüm kritik bileşenler çalışır durumda</div>";
    echo "</div>";
} else {
    echo "<div style='text-align: center; background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<div style='font-size: 48px; margin-bottom: 10px;'>🔧</div>";
    echo "<div style='font-size: 24px; color: #856404; font-weight: bold;'>ACİL ONARIM TAMAMLANDI</div>";
    echo "<div style='color: #856404;'>$totalIssues kritik sorun giderildi</div>";
    echo "</div>";
}

echo "<div style='text-align: center; margin: 30px 0;'>";
echo "<a href='general-accuracy-check.php' style='background: #007bff; color: white; padding: 15px 25px; text-decoration: none; border-radius: 8px; margin: 0 10px;'>🎯 Doğruluk Kontrolü</a>";
echo "<a href='system-health-monitor.php' style='background: #28a745; color: white; padding: 15px 25px; text-decoration: none; border-radius: 8px; margin: 0 10px;'>💚 Sağlık Monitörü</a>";
echo "</div>";

echo "<div style='text-align: center; color: #666; margin-top: 30px;'>";
echo "<small>SZB İK Takip - Acil Sistem Onarımı | " . date('d.m.Y H:i:s') . "</small>";
echo "</div>";

echo "</div>";
?>