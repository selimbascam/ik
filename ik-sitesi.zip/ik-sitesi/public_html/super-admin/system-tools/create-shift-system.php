<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();

    echo "<h1>🕒 Vardiya Sistemi Database Kurulumu</h1>";

    // 1. Shift Templates Table (Vardiya Şablonları)
    echo "<h2>1️⃣ Shift Templates Tablosu</h2>";
    $stmt = $conn->prepare("
        CREATE TABLE IF NOT EXISTS shift_templates (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            name VARCHAR(100) NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            break_duration INT DEFAULT 0 COMMENT 'Minutes',
            is_active BOOLEAN DEFAULT 1,
            color_code VARCHAR(7) DEFAULT '#3B82F6',
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_company_active (company_id, is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $stmt->execute();
    echo "✅ Shift Templates tablosu oluşturuldu<br>";

    // 2. Employee Shifts Table (Personel Vardiyaları)
    echo "<h2>2️⃣ Employee Shifts Tablosu</h2>";
    $stmt = $conn->prepare("
        CREATE TABLE IF NOT EXISTS employee_shifts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            shift_template_id INT NOT NULL,
            shift_date DATE NOT NULL,
            actual_start_time TIME,
            actual_end_time TIME,
            status ENUM('scheduled', 'checked_in', 'on_break', 'checked_out', 'absent', 'late', 'early_leave') DEFAULT 'scheduled',
            late_reason TEXT,
            early_leave_reason TEXT,
            absence_reason TEXT,
            break_minutes INT DEFAULT 0,
            worked_minutes INT DEFAULT 0,
            overtime_minutes INT DEFAULT 0,
            is_complete BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_employee_date (employee_id, shift_date),
            INDEX idx_employee_date (employee_id, shift_date),
            INDEX idx_shift_template (shift_template_id),
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
            FOREIGN KEY (shift_template_id) REFERENCES shift_templates(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $stmt->execute();
    echo "✅ Employee Shifts tablosu oluşturuldu<br>";

    // 3. Attendance Reasons Table (Sebep Kayıtları)
    echo "<h2>3️⃣ Attendance Reasons Tablosu</h2>";
    $stmt = $conn->prepare("
        CREATE TABLE IF NOT EXISTS attendance_reasons (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            shift_date DATE NOT NULL,
            reason_type ENUM('late_arrival', 'early_leave', 'no_checkout', 'absence') NOT NULL,
            reason_text TEXT NOT NULL,
            requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            admin_notes TEXT,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_employee_date (employee_id, shift_date),
            INDEX idx_reason_type (reason_type, status),
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $stmt->execute();
    echo "✅ Attendance Reasons tablosu oluşturuldu<br>";

    // 4. Monthly Work Summary Table (Aylık Çalışma Özeti)
    echo "<h2>4️⃣ Monthly Work Summary Tablosu</h2>";
    $stmt = $conn->prepare("
        CREATE TABLE IF NOT EXISTS monthly_work_summary (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            work_year YEAR NOT NULL,
            work_month TINYINT NOT NULL,
            total_scheduled_hours DECIMAL(6,2) DEFAULT 0,
            total_worked_hours DECIMAL(6,2) DEFAULT 0,
            total_overtime_hours DECIMAL(6,2) DEFAULT 0,
            total_break_hours DECIMAL(6,2) DEFAULT 0,
            total_late_minutes INT DEFAULT 0,
            total_early_leave_minutes INT DEFAULT 0,
            days_present INT DEFAULT 0,
            days_absent INT DEFAULT 0,
            days_late INT DEFAULT 0,
            days_early_leave INT DEFAULT 0,
            base_salary DECIMAL(10,2),
            overtime_rate DECIMAL(4,2) DEFAULT 1.5,
            calculated_salary DECIMAL(10,2),
            bonus_amount DECIMAL(10,2) DEFAULT 0,
            penalty_amount DECIMAL(10,2) DEFAULT 0,
            final_salary DECIMAL(10,2),
            is_finalized BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_employee_month (employee_id, work_year, work_month),
            INDEX idx_employee_period (employee_id, work_year, work_month),
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $stmt->execute();
    echo "✅ Monthly Work Summary tablosu oluşturuldu<br>";

    // 5. Shift Break Periods Table (Vardiya Mola Dönemleri)
    echo "<h2>5️⃣ Shift Break Periods Tablosu</h2>";
    $stmt = $conn->prepare("
        CREATE TABLE IF NOT EXISTS shift_break_periods (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_shift_id INT NOT NULL,
            break_start_time DATETIME NOT NULL,
            break_end_time DATETIME,
            break_minutes INT DEFAULT 0,
            break_type ENUM('lunch', 'coffee', 'smoking', 'other') DEFAULT 'other',
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_employee_shift (employee_shift_id),
            FOREIGN KEY (employee_shift_id) REFERENCES employee_shifts(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    $stmt->execute();
    echo "✅ Shift Break Periods tablosu oluşturuldu<br>";

    // Insert default shift templates
    echo "<h2>6️⃣ Varsayılan Vardiya Şablonları</h2>";
    
    $defaultShifts = [
        ['Sabah Vardiyası', '08:00:00', '17:00:00', 60, '#3B82F6', 'Standart sabah vardiyası (8:00-17:00, 1 saat mola)'],
        ['Öğle Vardiyası', '12:00:00', '21:00:00', 60, '#10B981', 'Öğle vardiyası (12:00-21:00, 1 saat mola)'],
        ['Gece Vardiyası', '22:00:00', '06:00:00', 30, '#8B5CF6', 'Gece vardiyası (22:00-06:00, 30 dk mola)'],
        ['Yarım Gün', '08:00:00', '13:00:00', 30, '#F59E0B', 'Yarım gün çalışma (8:00-13:00, 30 dk mola)'],
        ['Esnek Çalışma', '09:00:00', '18:00:00', 60, '#EF4444', 'Esnek çalışma saatleri (9:00-18:00, 1 saat mola)']
    ];

    foreach ($defaultShifts as $shift) {
        $stmt = $conn->prepare("
            INSERT IGNORE INTO shift_templates (company_id, name, start_time, end_time, break_duration, color_code, description)
            VALUES (1, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute($shift);
        echo "➕ {$shift[0]} şablonu eklendi<br>";
    }

    // Sample shift assignments for current month
    echo "<h2>7️⃣ Örnek Vardiya Atamaları (Bu Ay)</h2>";
    
    // Get employees
    $stmt = $conn->prepare("SELECT id FROM employees WHERE company_id = 1 LIMIT 5");
    $stmt->execute();
    $employees = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if ($employees) {
        $today = new DateTime();
        $firstDay = new DateTime($today->format('Y-m-01'));
        $lastDay = new DateTime($today->format('Y-m-t'));
        
        // Get shift templates
        $stmt = $conn->prepare("SELECT id FROM shift_templates WHERE company_id = 1 ORDER BY id LIMIT 3");
        $stmt->execute();
        $shiftTemplates = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $assignmentCount = 0;
        for ($date = clone $firstDay; $date <= $lastDay; $date->add(new DateInterval('P1D'))) {
            // Skip weekends for this demo
            if ($date->format('N') >= 6) continue;
            
            foreach ($employees as $employeeId) {
                $shiftTemplateId = $shiftTemplates[array_rand($shiftTemplates)];
                
                $stmt = $conn->prepare("
                    INSERT IGNORE INTO employee_shifts (employee_id, shift_template_id, shift_date)
                    VALUES (?, ?, ?)
                ");
                $stmt->execute([$employeeId, $shiftTemplateId, $date->format('Y-m-d')]);
                $assignmentCount++;
            }
        }
        echo "✅ {$assignmentCount} vardiya ataması oluşturuldu<br>";
    }

    echo "<h2>✅ Vardiya Sistemi Kurulumu Tamamlandı!</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>🎯 Özellikler:</h3>";
    echo "<ul>";
    echo "<li>✅ Vardiya şablonları ve atama sistemi</li>";
    echo "<li>✅ Geç gelme/erken çıkma sebep kayıt sistemi</li>";
    echo "<li>✅ Mola süreleri takibi</li>";
    echo "<li>✅ Aylık çalışma özeti ve maaş hesaplama</li>";
    echo "<li>✅ 225 saat/ay esaslı hesaplama altyapısı</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='admin/shift-management.php' style='background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🕒 Vardiya Yönetimi</a>";
    echo "<a href='dashboard/employee-dashboard.php' style='background: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>👤 Personel Paneli</a>";
    echo "<a href='dashboard/company-dashboard.php' style='background: #FF9800; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>📊 Ana Panel</a>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ Hata</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>