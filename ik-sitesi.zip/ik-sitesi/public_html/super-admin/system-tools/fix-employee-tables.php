<?php
require_once 'auth-check.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Tabloları Düzeltme - Süper Admin</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        .header { background: linear-gradient(135deg, #17a2b8 0%, #138496 100%); color: white; padding: 30px; margin: -20px -20px 20px -20px; border-radius: 8px 8px 0 0; }
        .status { padding: 15px; border-radius: 8px; margin: 15px 0; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .info { background: #cce7ff; color: #004085; border: 1px solid #b6d7ff; }
        .back-btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
        .tool-link { display: inline-block; padding: 8px 16px; background: #17a2b8; color: white; text-decoration: none; border-radius: 5px; margin: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>👥 Personel Tabloları Düzeltme</h1>
            <p>Employee ve ilgili tabloları onarım araçları</p>
        </div>
        
        <div class="status info">
            <h3>📋 Personel Sistemi Kontrol Listesi</h3>
            <p>Aşağıdaki tabloların varlığını ve yapısını kontrol edin:</p>
            <ul>
                <li><strong>employees:</strong> Temel personel bilgileri</li>
                <li><strong>employee_devices:</strong> Personel cihaz kayıtları</li>
                <li><strong>device_records:</strong> Cihaz kullanım geçmişi</li>
                <li><strong>attendance_records:</strong> Devam kayıtları</li>
                <li><strong>attendance_activities:</strong> Aktivite tipleri</li>
                <li><strong>activity_types:</strong> Giriş/çıkış/mola tipleri</li>
            </ul>
        </div>
        
        <div class="status success">
            <h3>🔧 Mevcut Düzeltme Araçları</h3>
            <p>Employee tabloları için kullanılabilir araçlar:</p>
            
            <a href="../../create-missing-tables.php" class="tool-link" target="_blank">📊 Eksik Tablolar</a>
            <a href="../../setup-missing-tables.php" class="tool-link" target="_blank">⚙️ Tablo Kurulumu</a>
            <a href="../../add-device-info-columns.php" class="tool-link" target="_blank">📱 Cihaz Sütunları</a>
            <a href="../../setup-activity-types-table.php" class="tool-link" target="_blank">📋 Aktivite Tipleri</a>
            <a href="../../create-device-tracking-table.php" class="tool-link" target="_blank">🔍 Cihaz Takip</a>
        </div>
        
        <div class="status info">
            <h3>📈 Önerilen Düzeltme Sırası</h3>
            <ol>
                <li><strong>Eksik Tablolar:</strong> Temel tabloları oluştur</li>
                <li><strong>Cihaz Sütunları:</strong> Device tracking için gerekli sütunları ekle</li>
                <li><strong>Aktivite Tipleri:</strong> Giriş/çıkış aktivite tiplerini kur</li>
                <li><strong>Cihaz Takip:</strong> Device tracking tablosunu aktifleştir</li>
                <li><strong>Tablo Kurulumu:</strong> Final kontrol ve eksik parçaları tamamla</li>
            </ol>
        </div>
        
        <div class="status">
            <h3>⚠️ Dikkat Edilmesi Gerekenler</h3>
            <ul>
                <li>Veritabanı değişiklikleri öncesi yedek alın</li>
                <li>Multi-tenant yapıyı bozmayın (company_id foreign keys)</li>
                <li>Mevcut veriler varsa ALTER TABLE komutlarını dikkatli kullanın</li>
                <li>UTF-8 charset ayarlarını kontrol edin</li>
            </ul>
        </div>
        
        <a href="../index.php" class="back-btn">← Süper Admin Panel</a>
    </div>
</body>
</html>