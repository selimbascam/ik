<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<div style='max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif;'>";
echo "<h1 style='background: #28a745; color: white; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>🔧 Employee Table Fix</h1>";
echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📋 1. Employee Tablo Yapısını Kontrol Et</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM employees");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p><strong>Mevcut sütunlar:</strong></p>";
    echo "<ul>";
    $columnNames = [];
    foreach ($columns as $column) {
        $columnNames[] = $column['Field'];
        echo "<li><strong>{$column['Field']}</strong> - {$column['Type']}</li>";
    }
    echo "</ul>";
    echo "</div>";
    
    // Check which columns are missing
    $requiredColumns = ['department', 'position', 'salary'];
    $missingColumns = [];
    
    foreach ($requiredColumns as $reqCol) {
        if (!in_array($reqCol, $columnNames)) {
            $missingColumns[] = $reqCol;
        }
    }
    
    if (!empty($missingColumns)) {
        echo "<h2>🛠️ 2. Eksik Sütunları Ekle</h2>";
        
        foreach ($missingColumns as $col) {
            try {
                switch($col) {
                    case 'department':
                        $sql = "ALTER TABLE employees ADD COLUMN department VARCHAR(100) DEFAULT 'Genel'";
                        break;
                    case 'position':
                        $sql = "ALTER TABLE employees ADD COLUMN position VARCHAR(100) DEFAULT 'Personel'";
                        break;
                    case 'salary':
                        $sql = "ALTER TABLE employees ADD COLUMN salary DECIMAL(10,2) DEFAULT 4500.00";
                        break;
                }
                
                $conn->exec($sql);
                echo "<div style='background: #d4edda; color: #155724; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
                echo "✅ <strong>$col</strong> sütunu eklendi";
                echo "</div>";
            } catch (Exception $e) {
                echo "<div style='background: #f8d7da; color: #721c24; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
                echo "❌ $col eklenemedi: " . $e->getMessage();
                echo "</div>";
            }
        }
    } else {
        echo "<div style='background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "ℹ️ Tüm gerekli sütunlar mevcut";
        echo "</div>";
    }
    
    // Now create test employee with minimal required fields
    echo "<h2>👤 3. Test Personeli Oluştur (Güvenli SQL)</h2>";
    
    // First check if EMP001 exists
    $stmt = $conn->prepare("SELECT id FROM employees WHERE employee_number = 'EMP001'");
    $stmt->execute();
    
    if (!$stmt->fetch()) {
        // Get company ID
        $stmt = $conn->query("SELECT id FROM companies LIMIT 1");
        $company = $stmt->fetch();
        $companyId = $company ? $company['id'] : 1;
        
        // Build dynamic insert based on existing columns
        $insertData = [
            'employee_number' => 'EMP001',
            'first_name' => 'Test',
            'last_name' => 'Personel',
            'email' => 'test@szb.com.tr',
            'phone' => '0555 123 4567',
            'password' => 'MD5(\'szb123456\')',
            'company_id' => $companyId,
            'hire_date' => date('Y-m-d'),
            'status' => 'active'
        ];
        
        // Add optional columns if they exist
        if (in_array('department', $columnNames)) {
            $insertData['department'] = 'IT';
        }
        if (in_array('position', $columnNames)) {
            $insertData['position'] = 'Test Personeli';
        }
        if (in_array('salary', $columnNames)) {
            $insertData['salary'] = 5000.00;
        }
        
        // Build SQL dynamically
        $columns = array_keys($insertData);
        $values = [];
        $params = [];
        
        foreach ($insertData as $col => $val) {
            if ($col === 'password') {
                $values[] = "MD5(?)";
                $params[] = 'szb123456';
            } else {
                $values[] = "?";
                $params[] = $val;
            }
        }
        
        $sql = "INSERT INTO employees (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $values) . ")";
        
        try {
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            
            echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<h3>✅ Test personeli başarıyla oluşturuldu!</h3>";
            echo "<ul>";
            echo "<li><strong>Personel No:</strong> EMP001</li>";
            echo "<li><strong>Şifre:</strong> szb123456</li>";
            echo "<li><strong>Ad Soyad:</strong> Test Personel</li>";
            echo "</ul>";
            echo "</div>";
        } catch (Exception $e) {
            echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "❌ Personel oluşturma hatası: " . $e->getMessage();
            echo "</div>";
            
            // Try simpler insert
            echo "<h3>🔄 Basit SQL ile tekrar deneniyor...</h3>";
            
            try {
                $simpleSQL = "INSERT INTO employees (employee_number, first_name, last_name, email, password, company_id, status) 
                             VALUES ('EMP001', 'Test', 'Personel', 'test@szb.com.tr', MD5('szb123456'), $companyId, 'active')";
                $conn->exec($simpleSQL);
                
                echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                echo "✅ Personel başarıyla oluşturuldu (basit SQL)";
                echo "</div>";
            } catch (Exception $e2) {
                echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                echo "❌ Basit SQL de başarısız: " . $e2->getMessage();
                echo "</div>";
            }
        }
    } else {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "⚠️ EMP001 zaten mevcut";
        echo "</div>";
    }
    
    // Test login
    echo "<h2>🔑 4. Login Test</h2>";
    $stmt = $conn->prepare("
        SELECT e.*, c.company_name 
        FROM employees e 
        JOIN companies c ON e.company_id = c.id 
        WHERE e.employee_number = 'EMP001' AND e.password = MD5('szb123456')
    ");
    $stmt->execute();
    $emp = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($emp) {
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h3>✅ Login testi başarılı!</h3>";
        echo "<ul>";
        echo "<li><strong>ID:</strong> {$emp['id']}</li>";
        echo "<li><strong>Ad Soyad:</strong> {$emp['first_name']} {$emp['last_name']}</li>";
        echo "<li><strong>Şirket:</strong> {$emp['company_name']}</li>";
        echo "<li><strong>Durum:</strong> {$emp['status']}</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Login testi başarısız";
        echo "</div>";
    }
    
    echo "<h2>📊 5. Tüm Personeller</h2>";
    $stmt = $conn->query("SELECT employee_number, first_name, last_name, status FROM employees ORDER BY id");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<table style='width: 100%; border-collapse: collapse;'>";
    echo "<tr style='background: #e9ecef;'>";
    echo "<th style='padding: 8px; text-align: left; border: 1px solid #dee2e6;'>Personel No</th>";
    echo "<th style='padding: 8px; text-align: left; border: 1px solid #dee2e6;'>Ad Soyad</th>";
    echo "<th style='padding: 8px; text-align: left; border: 1px solid #dee2e6;'>Durum</th>";
    echo "</tr>";
    
    foreach ($employees as $emp) {
        $bgColor = ($emp['employee_number'] === 'EMP001') ? '#d4edda' : 'white';
        echo "<tr style='background: $bgColor;'>";
        echo "<td style='padding: 8px; border: 1px solid #dee2e6;'>{$emp['employee_number']}</td>";
        echo "<td style='padding: 8px; border: 1px solid #dee2e6;'>{$emp['first_name']} {$emp['last_name']}</td>";
        echo "<td style='padding: 8px; border: 1px solid #dee2e6;'>{$emp['status']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='auth/employee-login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>👤 Login Test Et</a>";
    echo "<a href='emergency-fix-session.php' style='background: #dc3545; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🔧 Sistem Kontrolü</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Kritik Hata</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "</div>";
echo "</div>";
?>