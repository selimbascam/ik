<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo '<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapsamlı Giriş Testi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">';

echo '<div class="max-w-6xl mx-auto p-6">';
echo '<h1 class="text-3xl font-bold text-center mb-8 text-gray-800">🔐 Kapsamlı Giriş Sistemi Kontrolü</h1>';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // 1. Database Connection Test
    echo '<div class="bg-white rounded-lg shadow-md p-6 mb-6">';
    echo '<h2 class="text-xl font-bold mb-4 text-gray-700">1. Veritabanı Bağlantısı</h2>';
    echo '<div class="bg-green-100 text-green-800 p-3 rounded">✅ Veritabanı bağlantısı başarılı</div>';
    echo '</div>';
    
    // 2. Session Status
    echo '<div class="bg-white rounded-lg shadow-md p-6 mb-6">';
    echo '<h2 class="text-xl font-bold mb-4 text-gray-700">2. Session Durumu</h2>';
    echo '<div class="space-y-2">';
    echo '<p><strong>Session ID:</strong> ' . session_id() . '</p>';
    echo '<p><strong>Session Status:</strong> ' . (session_status() === PHP_SESSION_ACTIVE ? '✅ Aktif' : '❌ Pasif') . '</p>';
    
    if (!empty($_SESSION)) {
        echo '<p><strong>Session İçeriği:</strong></p>';
        echo '<pre class="bg-gray-100 p-3 rounded overflow-x-auto">';
        print_r($_SESSION);
        echo '</pre>';
    } else {
        echo '<p class="text-gray-500">Session boş</p>';
    }
    echo '</div>';
    echo '</div>';
    
    // 3. Test Accounts
    echo '<div class="bg-white rounded-lg shadow-md p-6 mb-6">';
    echo '<h2 class="text-xl font-bold mb-4 text-gray-700">3. Test Hesapları</h2>';
    
    // Company Admin Test
    $stmt = $conn->query("SELECT id, email, company_id, role FROM users WHERE role = 'admin' LIMIT 5");
    $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo '<div class="mb-4">';
    echo '<h3 class="font-semibold mb-2 text-blue-700">🏢 Şirket Yöneticileri:</h3>';
    if (!empty($admins)) {
        echo '<table class="w-full border-collapse">';
        echo '<tr class="bg-gray-100">';
        echo '<th class="border p-2 text-left">Email</th>';
        echo '<th class="border p-2 text-left">Şirket ID</th>';
        echo '<th class="border p-2 text-left">Rol</th>';
        echo '<th class="border p-2 text-left">Test Et</th>';
        echo '</tr>';
        foreach ($admins as $admin) {
            echo '<tr>';
            echo '<td class="border p-2">' . $admin['email'] . '</td>';
            echo '<td class="border p-2">' . $admin['company_id'] . '</td>';
            echo '<td class="border p-2">' . $admin['role'] . '</td>';
            echo '<td class="border p-2">';
            echo '<form action="auth/company-login.php" method="POST" class="inline">';
            echo '<input type="hidden" name="email" value="' . $admin['email'] . '">';
            echo '<input type="hidden" name="password" value="szb123456">';
            echo '<button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600">Giriş</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo '<p class="text-gray-500">Yönetici hesabı bulunamadı</p>';
    }
    echo '</div>';
    
    // Employee Test
    $stmt = $conn->query("SELECT id, employee_number, first_name, last_name, company_id, status FROM employees WHERE status = 'active' LIMIT 5");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo '<div class="mb-4">';
    echo '<h3 class="font-semibold mb-2 text-green-700">👥 Personeller:</h3>';
    if (!empty($employees)) {
        echo '<table class="w-full border-collapse">';
        echo '<tr class="bg-gray-100">';
        echo '<th class="border p-2 text-left">Personel No</th>';
        echo '<th class="border p-2 text-left">Ad Soyad</th>';
        echo '<th class="border p-2 text-left">Şirket ID</th>';
        echo '<th class="border p-2 text-left">Durum</th>';
        echo '<th class="border p-2 text-left">Test Et</th>';
        echo '</tr>';
        foreach ($employees as $emp) {
            echo '<tr>';
            echo '<td class="border p-2">' . $emp['employee_number'] . '</td>';
            echo '<td class="border p-2">' . $emp['first_name'] . ' ' . $emp['last_name'] . '</td>';
            echo '<td class="border p-2">' . $emp['company_id'] . '</td>';
            echo '<td class="border p-2">' . $emp['status'] . '</td>';
            echo '<td class="border p-2">';
            echo '<form action="auth/employee-login.php" method="POST" class="inline">';
            echo '<input type="hidden" name="employee_id" value="' . $emp['employee_number'] . '">';
            echo '<input type="hidden" name="password" value="szb123456">';
            echo '<button type="submit" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600">Giriş</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo '<p class="text-gray-500">Personel bulunamadı</p>';
    }
    echo '</div>';
    
    // Super Admin
    echo '<div>';
    echo '<h3 class="font-semibold mb-2 text-red-700">🔐 Süper Admin:</h3>';
    echo '<div class="bg-red-50 p-4 rounded">';
    echo '<p>Email: super@admin.com</p>';
    echo '<p>Şifre: SZB2025Admin!</p>';
    echo '<a href="super-admin/" class="inline-block mt-2 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Süper Admin Girişi</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // 4. Create Test Accounts
    echo '<div class="bg-white rounded-lg shadow-md p-6 mb-6">';
    echo '<h2 class="text-xl font-bold mb-4 text-gray-700">4. Test Hesapları Oluştur</h2>';
    
    // Check if test company exists
    $stmt = $conn->prepare("SELECT id FROM companies WHERE company_code = 'TEST'");
    $stmt->execute();
    $testCompany = $stmt->fetch();
    
    if (!$testCompany) {
        echo '<p class="mb-4">Test şirketi oluşturuluyor...</p>';
        
        $stmt = $conn->prepare("
            INSERT INTO companies (company_name, company_code, contact_email, contact_phone, address, status)
            VALUES ('Test Şirketi', 'TEST', 'test@szb.com.tr', '0212 555 0000', 'İstanbul', 'active')
        ");
        $stmt->execute();
        $testCompanyId = $conn->lastInsertId();
        
        echo '<div class="bg-green-100 text-green-800 p-3 rounded mb-4">✅ Test şirketi oluşturuldu (ID: ' . $testCompanyId . ')</div>';
    } else {
        $testCompanyId = $testCompany['id'];
        echo '<div class="bg-blue-100 text-blue-800 p-3 rounded mb-4">ℹ️ Test şirketi mevcut (ID: ' . $testCompanyId . ')</div>';
    }
    
    // Create test admin
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = 'admin@test.com'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $stmt = $conn->prepare("
            INSERT INTO users (company_id, email, password, role)
            VALUES (?, 'admin@test.com', MD5('szb123456'), 'admin')
        ");
        $stmt->execute([$testCompanyId]);
        echo '<div class="bg-green-100 text-green-800 p-3 rounded mb-2">✅ Test admin oluşturuldu: admin@test.com / szb123456</div>';
    }
    
    // Create test employee
    $stmt = $conn->prepare("SELECT id FROM employees WHERE employee_number = 'TEST001'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        $stmt = $conn->prepare("
            INSERT INTO employees (company_id, employee_number, first_name, last_name, email, password, status, hire_date)
            VALUES (?, 'TEST001', 'Test', 'Kullanıcı', 'test.user@test.com', MD5('szb123456'), 'active', CURDATE())
        ");
        $stmt->execute([$testCompanyId]);
        echo '<div class="bg-green-100 text-green-800 p-3 rounded mb-2">✅ Test personel oluşturuldu: TEST001 / szb123456</div>';
    }
    
    echo '</div>';
    
    // 5. Quick Access Links
    echo '<div class="bg-white rounded-lg shadow-md p-6 mb-6">';
    echo '<h2 class="text-xl font-bold mb-4 text-gray-700">5. Hızlı Erişim Linkleri</h2>';
    echo '<div class="grid grid-cols-2 md:grid-cols-4 gap-4">';
    
    $links = [
        ['auth/company-login.php', '🏢 Şirket Girişi', 'bg-blue-500'],
        ['auth/employee-login.php', '👥 Personel Girişi', 'bg-green-500'],
        ['super-admin/', '🔐 Süper Admin', 'bg-red-500'],
        ['admin/dashboard.php', '📊 Dashboard', 'bg-purple-500'],
        ['qr/qr-reader.php', '📱 QR Okuyucu', 'bg-yellow-500'],
        ['emergency-fix-session.php', '🔧 Session Fix', 'bg-gray-500'],
        ['quick-fix-employee.php', '👤 Employee Fix', 'bg-indigo-500'],
        ['fix-work-settings.php', '⚙️ Settings Fix', 'bg-pink-500']
    ];
    
    foreach ($links as $link) {
        echo '<a href="' . $link[0] . '" class="' . $link[2] . ' text-white p-4 rounded-lg text-center hover:opacity-90 transition">';
        echo '<div class="text-2xl mb-2">' . substr($link[1], 0, 2) . '</div>';
        echo '<div class="text-sm">' . substr($link[1], 3) . '</div>';
        echo '</a>';
    }
    
    echo '</div>';
    echo '</div>';
    
} catch (Exception $e) {
    echo '<div class="bg-red-100 text-red-800 p-4 rounded">';
    echo '<h3 class="font-bold mb-2">❌ Kritik Hata!</h3>';
    echo '<p>' . $e->getMessage() . '</p>';
    echo '</div>';
}

echo '</div>';
echo '</body></html>';
?>