<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();

    echo "<h1>🔧 Şirket Ayarları Database Düzeltmeleri</h1>";

    // Check current companies table structure
    echo "<h2>1️⃣ Mevcut Tablo Yapısı Kontrolü</h2>";
    $stmt = $conn->prepare("DESCRIBE companies");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>Companies Tablosu Mevcut Sütunları:</h3>";
    foreach ($columns as $column) {
        echo "- " . $column['Field'] . " (" . $column['Type'] . ")<br>";
    }
    echo "</div>";
    
    // Check which columns are missing
    $existingColumns = array_column($columns, 'Field');
    $requiredColumns = ['website', 'tax_number', 'time_zone'];
    $missingColumns = array_diff($requiredColumns, $existingColumns);
    
    if (!empty($missingColumns)) {
        echo "<h2>2️⃣ Eksik Sütunları Ekleme</h2>";
        
        foreach ($missingColumns as $column) {
            try {
                switch ($column) {
                    case 'website':
                        $conn->exec("ALTER TABLE companies ADD COLUMN website VARCHAR(255)");
                        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                        echo "✅ website sütunu eklendi";
                        echo "</div>";
                        break;
                        
                    case 'tax_number':
                        $conn->exec("ALTER TABLE companies ADD COLUMN tax_number VARCHAR(20)");
                        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                        echo "✅ tax_number sütunu eklendi";
                        echo "</div>";
                        break;
                        
                    case 'time_zone':
                        $conn->exec("ALTER TABLE companies ADD COLUMN time_zone VARCHAR(50) DEFAULT 'Europe/Istanbul'");
                        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                        echo "✅ time_zone sütunu eklendi";
                        echo "</div>";
                        break;
                }
            } catch (Exception $e) {
                echo "<div style='color: #721c24; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                echo "❌ $column sütunu eklenirken hata: " . $e->getMessage();
                echo "</div>";
            }
        }
    } else {
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ Tüm gerekli sütunlar mevcut";
        echo "</div>";
    }
    
    // Check and create settings tables if they don't exist
    echo "<h2>3️⃣ Ayar Tablolarını Kontrol Etme</h2>";
    
    // Work Settings Table
    $stmt = $conn->prepare("SHOW TABLES LIKE 'work_settings'");
    $stmt->execute();
    if ($stmt->rowCount() == 0) {
        $conn->exec("
            CREATE TABLE work_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                daily_work_hours DECIMAL(4,2) DEFAULT 8.00,
                weekly_work_hours DECIMAL(4,2) DEFAULT 40.00,
                monthly_work_hours DECIMAL(5,2) DEFAULT 225.00,
                overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
                holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
                weekend_multiplier DECIMAL(3,2) DEFAULT 1.50,
                grace_period_minutes INT DEFAULT 15,
                late_penalty_amount DECIMAL(8,2) DEFAULT 0.00,
                min_break_duration INT DEFAULT 30,
                max_break_duration INT DEFAULT 120,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ work_settings tablosu oluşturuldu";
        echo "</div>";
    } else {
        echo "<div style='color: #856404; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "ℹ️ work_settings tablosu zaten mevcut";
        echo "</div>";
    }
    
    // QR Settings Table
    $stmt = $conn->prepare("SHOW TABLES LIKE 'qr_settings'");
    $stmt->execute();
    if ($stmt->rowCount() == 0) {
        $conn->exec("
            CREATE TABLE qr_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                location_tolerance_meters INT DEFAULT 100,
                qr_expiry_minutes INT DEFAULT 60,
                allow_offline_checkin BOOLEAN DEFAULT 0,
                require_photo BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ qr_settings tablosu oluşturuldu";
        echo "</div>";
    } else {
        echo "<div style='color: #856404; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "ℹ️ qr_settings tablosu zaten mevcut";
        echo "</div>";
    }
    
    // Notification Settings Table
    $stmt = $conn->prepare("SHOW TABLES LIKE 'notification_settings'");
    $stmt->execute();
    if ($stmt->rowCount() == 0) {
        $conn->exec("
            CREATE TABLE notification_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                company_id INT NOT NULL,
                email_notifications BOOLEAN DEFAULT 1,
                sms_notifications BOOLEAN DEFAULT 0,
                slack_webhook_url VARCHAR(255),
                email_templates JSON,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ notification_settings tablosu oluşturuldu";
        echo "</div>";
    } else {
        echo "<div style='color: #856404; background: #fff3cd; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "ℹ️ notification_settings tablosu zaten mevcut";
        echo "</div>";
    }
    
    echo "<h2>4️⃣ Test Verileri Ekleme</h2>";
    
    // Add default settings for existing companies
    $stmt = $conn->prepare("SELECT id FROM companies");
    $stmt->execute();
    $companies = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($companies as $companyId) {
        // Add default work settings if not exists
        $stmt = $conn->prepare("SELECT id FROM work_settings WHERE company_id = ?");
        $stmt->execute([$companyId]);
        if ($stmt->rowCount() == 0) {
            $stmt = $conn->prepare("
                INSERT INTO work_settings (company_id, daily_work_hours, weekly_work_hours, monthly_work_hours)
                VALUES (?, 8.00, 40.00, 225.00)
            ");
            $stmt->execute([$companyId]);
            echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ Şirket $companyId için varsayılan çalışma ayarları eklendi";
            echo "</div>";
        }
        
        // Add default QR settings if not exists
        $stmt = $conn->prepare("SELECT id FROM qr_settings WHERE company_id = ?");
        $stmt->execute([$companyId]);
        if ($stmt->rowCount() == 0) {
            $stmt = $conn->prepare("
                INSERT INTO qr_settings (company_id, location_tolerance_meters, qr_expiry_minutes)
                VALUES (?, 100, 60)
            ");
            $stmt->execute([$companyId]);
            echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ Şirket $companyId için varsayılan QR ayarları eklendi";
            echo "</div>";
        }
        
        // Add default notification settings if not exists
        $stmt = $conn->prepare("SELECT id FROM notification_settings WHERE company_id = ?");
        $stmt->execute([$companyId]);
        if ($stmt->rowCount() == 0) {
            $stmt = $conn->prepare("
                INSERT INTO notification_settings (company_id, email_notifications, sms_notifications)
                VALUES (?, 1, 0)
            ");
            $stmt->execute([$companyId]);
            echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ Şirket $companyId için varsayılan bildirim ayarları eklendi";
            echo "</div>";
        }
    }
    
    echo "<h2>✅ Düzeltmeler Tamamlandı!</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>🎯 Yapılan İşlemler:</h3>";
    echo "<ul>";
    echo "<li>✅ Companies tablosu eksik sütunları eklendi</li>";
    echo "<li>✅ Ayar tabloları kontrol edildi ve oluşturuldu</li>";
    echo "<li>✅ Varsayılan ayarlar eklendi</li>";
    echo "<li>✅ Database şeması şirket ayarları ile uyumlu hale getirildi</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='admin/company-settings.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🏢 Şirket Ayarları</a>";
    echo "<a href='dashboard/company-dashboard.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>📊 Dashboard</a>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ Hata</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?>