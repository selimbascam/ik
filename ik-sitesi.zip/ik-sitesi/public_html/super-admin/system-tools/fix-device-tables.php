<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<div style='max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif;'>";
echo "<h1 style='background: #FF5722; color: white; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>🛠️ Device Tables Fix</h1>";
echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";

echo "<p><strong>Device_records ve Employee_devices Tablolarını Oluşturma</strong></p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check existing tables
    echo "<h2>1️⃣ Mevcut Tabloları Kontrol Et</h2>";
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p><strong>Veritabanındaki tablolar:</strong></p>";
    echo "<ul>";
    foreach ($tables as $table) {
        $highlight = (in_array($table, ['device_records', 'employee_devices'])) ? 'style="color: green; font-weight: bold;"' : '';
        echo "<li $highlight>$table</li>";
    }
    echo "</ul>";
    echo "</div>";
    
    // Create device_records table
    echo "<h2>2️⃣ Device_records Tablosu Oluştur</h2>";
    
    if (!in_array('device_records', $tables)) {
        $sql = "CREATE TABLE device_records (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            device_fingerprint VARCHAR(255),
            device_platform VARCHAR(100),
            device_browser VARCHAR(100),
            device_ip_address VARCHAR(45),
            device_user_agent TEXT,
            device_mac_address VARCHAR(17),
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
            INDEX idx_employee_device (employee_id),
            INDEX idx_device_fingerprint (device_fingerprint)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ device_records tablosu başarıyla oluşturuldu";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "⚠️ device_records tablosu zaten mevcut";
        echo "</div>";
    }
    
    // Create employee_devices table
    echo "<h2>3️⃣ Employee_devices Tablosu Oluştur</h2>";
    
    if (!in_array('employee_devices', $tables)) {
        $sql = "CREATE TABLE employee_devices (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            device_fingerprint VARCHAR(255) UNIQUE,
            device_name VARCHAR(100),
            device_type VARCHAR(50),
            is_trusted BOOLEAN DEFAULT FALSE,
            last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
            INDEX idx_employee_devices (employee_id),
            INDEX idx_device_fingerprint_unique (device_fingerprint)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $conn->exec($sql);
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ employee_devices tablosu başarıyla oluşturuldu";
        echo "</div>";
    } else {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "⚠️ employee_devices tablosu zaten mevcut";
        echo "</div>";
    }
    
    // Test the tables
    echo "<h2>4️⃣ Tabloları Test Et</h2>";
    
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM device_records");
        $stmt->execute();
        $deviceRecordsCount = $stmt->fetchColumn();
        
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employee_devices");
        $stmt->execute();
        $employeeDevicesCount = $stmt->fetchColumn();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h3>✅ Tablo Testleri Başarılı!</h3>";
        echo "<p><strong>device_records:</strong> $deviceRecordsCount kayıt</p>";
        echo "<p><strong>employee_devices:</strong> $employeeDevicesCount kayıt</p>";
        echo "</div>";
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Tablo test hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    // Test employee management safety check query
    echo "<h2>5️⃣ Employee Management Sorgu Testi</h2>";
    
    try {
        $stmt = $conn->prepare("
            SELECT 
                (SELECT COUNT(*) FROM attendance_records WHERE employee_id = ?) +
                (SELECT COUNT(*) FROM employee_shifts WHERE employee_id = ?) +
                (SELECT COUNT(*) FROM device_records WHERE employee_id = ?) +
                (SELECT COUNT(*) FROM employee_devices WHERE employee_id = ?) as total_related
        ");
        $stmt->execute([1, 1, 1, 1]); // Test with employee ID 1
        $totalRelated = $stmt->fetchColumn();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ Employee management güvenlik sorgusu çalışıyor";
        echo "<p>Test sonucu (Employee ID 1): $totalRelated ilgili kayıt</p>";
        echo "</div>";
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Employee management sorgu hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    echo "<h2>✅ Device Tables Fix Tamamlandı</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>🔧 Yapılan İşlemler:</h3>";
    echo "<ul>";
    echo "<li>✅ <strong>device_records</strong> tablosu oluşturuldu</li>";
    echo "<li>✅ <strong>employee_devices</strong> tablosu oluşturuldu</li>";
    echo "<li>✅ Foreign key ilişkileri kuruldu</li>";
    echo "<li>✅ Index'ler eklendi (performans için)</li>";
    echo "<li>✅ Employee management sorgu testleri yapıldı</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='admin/employee-management.php' style='background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>👥 Personel Yönetimi Test</a>";
    echo "<a href='test-employee-management-fix.php' style='background: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🧪 Genel Test</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Kritik Hata</h3>";
    echo "Hata: " . $e->getMessage();
    echo "</div>";
}

echo "</div>";
echo "</div>";
?>