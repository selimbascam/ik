<?php
// Don't use auth-check.php here as it might interfere with download
require_once '../../includes/config.php';
require_once '../../includes/database.php';

// Set timezone
date_default_timezone_set('Europe/Istanbul');

// Check general authentication for page access (non-download requests)
if (!isset($_GET['download']) && (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1)) {
    header('Location: ../index.php');
    exit;
}

$analysisData = [];
$testResults = [];
$reportData = [];

function testUrl($url, $description, $category = 'General') {
    global $testResults;
    
    $fullUrl = "http://" . $_SERVER['HTTP_HOST'] . "/ik/" . ltrim($url, '/');
    
    $context = stream_context_create([
        "http" => [
            "timeout" => 10,
            "method" => "GET"
        ]
    ]);
    
    $result = [
        'url' => $url,
        'full_url' => $fullUrl,
        'description' => $description,
        'category' => $category,
        'status' => 'unknown',
        'http_code' => 0,
        'response_time' => 0,
        'content_length' => 0,
        'error' => null,
        'tested_at' => date('Y-m-d H:i:s')
    ];
    
    $startTime = microtime(true);
    
    try {
        $response = @file_get_contents($fullUrl, false, $context);
        $result['response_time'] = round((microtime(true) - $startTime) * 1000, 2);
        
        if ($response !== false) {
            $result['status'] = 'success';
            $result['http_code'] = 200;
            $result['content_length'] = strlen($response);
            
            // Check for common error indicators
            if (strpos($response, 'Fatal error') !== false || 
                strpos($response, 'Parse error') !== false ||
                strpos($response, 'Warning') !== false) {
                $result['status'] = 'error';
                $result['error'] = 'PHP Error detected in response';
            }
        } else {
            $result['status'] = 'error';
            $result['error'] = 'Failed to load page';
        }
        
    } catch (Exception $e) {
        $result['status'] = 'error';
        $result['error'] = $e->getMessage();
        $result['response_time'] = round((microtime(true) - $startTime) * 1000, 2);
    }
    
    $testResults[] = $result;
    return $result;
}

function runDatabaseTests() {
    global $reportData;
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $reportData['database'] = [
            'status' => 'connected',
            'tables' => [],
            'companies' => [],
            'employees_count' => 0,
            'attendance_records_count' => 0
        ];
        
        // Get all tables
        $stmt = $conn->query("SHOW TABLES");
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $reportData['database']['tables'] = $tables;
        
        // Get companies
        if (in_array('companies', $tables)) {
            $stmt = $conn->query("SELECT id, company_name, email, status FROM companies");
            $reportData['database']['companies'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // Get employee count
        if (in_array('employees', $tables)) {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM employees");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $reportData['database']['employees_count'] = $result['count'];
        }
        
        // Get attendance records count
        if (in_array('attendance_records', $tables)) {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM attendance_records");
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $reportData['database']['attendance_records_count'] = $result['count'];
        }
        
    } catch (Exception $e) {
        $reportData['database'] = [
            'status' => 'error',
            'error' => $e->getMessage()
        ];
    }
}

// Special handling for download requests - check session without redirect
if (isset($_GET['download']) && $_GET['download'] === 'report') {
    // Check authentication specifically for download
    if (!isset($_SESSION['super_admin']) || $_SESSION['super_admin'] !== 1) {
        // Return JSON error instead of redirect for AJAX/download requests
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Authentication required', 'redirect' => '../index.php']);
        exit;
    }
}

// Generate download report if requested
if (isset($_GET['download']) && $_GET['download'] === 'report') {
    runDatabaseTests();
    
    // Run all tests
    $allTests = [
        // Authentication Tests
        ['auth/company-login.php', 'Company Login Page', 'Authentication'],
        ['auth/employee-login.php', 'Employee Login Page', 'Authentication'],
        ['super-admin/', 'Super Admin Panel', 'Authentication'],
        
        // Debug & Test Tools
        ['debug/quick-login-test.php', 'Quick Login Test', 'Debug Tools'],
        ['debug/test-company-login-credentials.php', 'Company Login Debug', 'Debug Tools'],
        ['debug/test-qr-system.php', 'QR System Test', 'Debug Tools'],
        ['debug/qr-error-fix.php', 'QR Error Fix Tool', 'Debug Tools'],
        ['test-login-direct.php', 'Direct Login Test', 'Debug Tools'],
        ['test-employee-qr.php', 'Employee QR Test', 'Debug Tools'],
        
        // Admin Panels
        ['admin/dashboard.php', 'Admin Dashboard', 'Admin Interface'],
        ['admin/employee-management.php', 'Employee Management', 'Admin Interface'],
        ['admin/shift-management.php', 'Shift Management', 'Admin Interface'],
        ['admin/attendance-reports.php', 'Attendance Reports', 'Admin Interface'],
        ['admin/qr-management.php', 'QR Code Management', 'Admin Interface'],
        
        // Employee Interface
        ['employee/dashboard.php', 'Employee Dashboard', 'Employee Interface'],
        ['employee/attendance-records.php', 'Employee Attendance', 'Employee Interface'],
        ['employee/profile.php', 'Employee Profile', 'Employee Interface'],
        
        // QR System
        ['qr/qr-reader.php', 'QR Code Reader', 'QR System'],
        ['qr/activity-selection.php', 'Activity Selection', 'QR System'],
        ['qr/generate-qr.php', 'QR Code Generator', 'QR System'],
        
        // API Endpoints
        ['api/attendance.php', 'Attendance API', 'API'],
        ['api/employees.php', 'Employees API', 'API'],
        ['api/reports.php', 'Reports API', 'API'],
        
        // Reports & Analytics
        ['reports/daily-report.php', 'Daily Report', 'Reports'],
        ['reports/monthly-report.php', 'Monthly Report', 'Reports'],
        ['reports/attendance-summary.php', 'Attendance Summary', 'Reports'],
        
        // System Tools
        ['super-admin/system-tools/system-update.php', 'System Update Tool', 'System Tools'],
        ['super-admin/system-tools/database-repair.php', 'Database Repair', 'System Tools'],
        ['super-admin/company-management.php', 'Company Management', 'System Tools']
    ];
    
    foreach ($allTests as $test) {
        testUrl($test[0], $test[1], $test[2]);
    }
    
    // Generate JSON report
    $report = [
        'generated_at' => date('Y-m-d H:i:s'),
        'server_info' => [
            'php_version' => phpversion(),
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'host' => $_SERVER['HTTP_HOST'] ?? 'Unknown',
            'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown'
        ],
        'database' => $reportData['database'],
        'test_results' => $testResults,
        'summary' => [
            'total_tests' => count($testResults),
            'successful_tests' => count(array_filter($testResults, fn($t) => $t['status'] === 'success')),
            'failed_tests' => count(array_filter($testResults, fn($t) => $t['status'] === 'error')),
            'categories' => array_unique(array_column($testResults, 'category'))
        ]
    ];
    
    // Force download headers
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="szb-ik-system-analysis-' . date('Y-m-d-H-i-s') . '.json"');
    header('Content-Length: ' . strlen(json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)));
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    
    // Clear any previous output
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    echo json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Run basic analysis for display
runDatabaseTests();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kapsamlı Sistem Analizi - Süper Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .test-category {
            margin-bottom: 2rem;
        }
        .test-item {
            padding: 1rem;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            margin-bottom: 0.5rem;
            transition: all 0.2s;
        }
        .test-item:hover {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .status-success { border-left: 4px solid #10b981; background-color: #ecfdf5; }
        .status-error { border-left: 4px solid #ef4444; background-color: #fef2f2; }
        .status-loading { border-left: 4px solid #f59e0b; background-color: #fffbeb; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6 max-w-7xl">
        <!-- Header -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">📊 Kapsamlı Sistem Analizi</h1>
                    <p class="text-gray-600 mt-2">SZB İK Takip sisteminin tüm bileşenlerini analiz eder ve rapor oluşturur</p>
                    <p class="text-sm text-gray-500 mt-1">Son analiz: <?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
                <div class="flex space-x-3">
                    <button onclick="downloadReport()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-medium">
                        📥 Rapor İndir (ZIP)
                    </button>
                    <a href="fixed-download.php" target="_blank" class="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors font-medium">
                        ✅ Fixed İndir
                    </a>
                    <a href="instant-download.php" target="_blank" class="bg-blue-500 text-white px-4 py-3 rounded-lg hover:bg-blue-600 transition-colors text-sm">
                        ⚡ Hızlı İndir
                    </a>
                    <a href="direct-download.php" target="_blank" class="bg-purple-500 text-white px-4 py-3 rounded-lg hover:bg-purple-600 transition-colors text-sm">
                        🔗 Direkt İndir
                    </a>
                    <a href="simple-download.php" target="_blank" class="bg-gray-500 text-white px-4 py-3 rounded-lg hover:bg-gray-600 transition-colors text-sm">
                        📄 Basit İndir
                    </a>
                    <a href="qr-gate-behavior-test.php" class="bg-indigo-600 text-white px-4 py-3 rounded-lg hover:bg-indigo-700 transition-colors text-sm">
                        🚪 QR Gate Test
                    </a>
                    <a href="debug-download.php" target="_blank" class="bg-yellow-600 text-white px-4 py-3 rounded-lg hover:bg-yellow-700 transition-colors text-sm">
                        🔧 İndirme Testi
                    </a>
                    <a href="alternative-download.php" target="_blank" class="bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        🔄 Alternatif İndir
                    </a>
                    <a href="../index.php" class="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors">
                        ← Geri Dön
                    </a>
                </div>
            </div>
        </div>

        <!-- Database Status -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-4">🗄️ Veritabanı Durumu</h2>
            <?php if ($reportData['database']['status'] === 'connected'): ?>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div class="text-green-800 font-semibold">✅ Bağlantı</div>
                        <div class="text-sm text-green-600">Başarılı</div>
                    </div>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div class="text-blue-800 font-semibold">📊 Tablolar</div>
                        <div class="text-sm text-blue-600"><?php echo count($reportData['database']['tables']); ?> adet</div>
                    </div>
                    <div class="bg-purple-50 border border-purple-200 rounded-lg p-4">
                        <div class="text-purple-800 font-semibold">🏢 Şirketler</div>
                        <div class="text-sm text-purple-600"><?php echo count($reportData['database']['companies']); ?> adet</div>
                    </div>
                    <div class="bg-orange-50 border border-orange-200 rounded-lg p-4">
                        <div class="text-orange-800 font-semibold">👥 Personeller</div>
                        <div class="text-sm text-orange-600"><?php echo $reportData['database']['employees_count']; ?> adet</div>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div class="text-red-800 font-semibold">❌ Veritabanı Hatası</div>
                    <div class="text-sm text-red-600"><?php echo htmlspecialchars($reportData['database']['error'] ?? 'Bilinmeyen hata'); ?></div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Test Categories -->
        <div class="space-y-6">
            <!-- Authentication Tests -->
            <div class="test-category bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">🔐 Kimlik Doğrulama Testleri</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="test-item status-loading" onclick="testPage('auth/company-login.php', this)">
                        <div class="font-medium">Şirket Giriş Sayfası</div>
                        <div class="text-sm text-gray-600">auth/company-login.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('auth/employee-login.php', this)">
                        <div class="font-medium">Personel Giriş Sayfası</div>
                        <div class="text-sm text-gray-600">auth/employee-login.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('super-admin/', this)">
                        <div class="font-medium">Süper Admin Panel</div>
                        <div class="text-sm text-gray-600">super-admin/</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                </div>
            </div>

            <!-- Debug Tools -->
            <div class="test-category bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">🔧 Hata Ayıklama ve Test Araçları</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="test-item status-loading" onclick="testPage('debug/quick-login-test.php', this)">
                        <div class="font-medium">Hızlı Giriş Testi</div>
                        <div class="text-sm text-gray-600">debug/quick-login-test.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/test-company-login-credentials.php', this)">
                        <div class="font-medium">Şirket Giriş Teşhisi</div>
                        <div class="text-sm text-gray-600">debug/test-company-login-credentials.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/test-qr-system.php', this)">
                        <div class="font-medium">QR Sistem Testi</div>
                        <div class="text-sm text-gray-600">debug/test-qr-system.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/qr-error-fix.php', this)">
                        <div class="font-medium">QR Hata Düzeltme</div>
                        <div class="text-sm text-gray-600">debug/qr-error-fix.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('test-login-direct.php', this)">
                        <div class="font-medium">Direkt Giriş Testi</div>
                        <div class="text-sm text-gray-600">test-login-direct.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('test-employee-qr.php', this)">
                        <div class="font-medium">Personel QR Testi</div>
                        <div class="text-sm text-gray-600">test-employee-qr.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                </div>
            </div>

            <!-- Admin Interface -->
            <div class="test-category bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">⚙️ Yönetici Arayüzü</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="test-item status-loading" onclick="testPage('admin/dashboard.php', this)">
                        <div class="font-medium">Admin Dashboard</div>
                        <div class="text-sm text-gray-600">admin/dashboard.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('admin/employee-management.php', this)">
                        <div class="font-medium">Personel Yönetimi</div>
                        <div class="text-sm text-gray-600">admin/employee-management.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('admin/shift-management.php', this)">
                        <div class="font-medium">Vardiya Yönetimi</div>
                        <div class="text-sm text-gray-600">admin/shift-management.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('admin/attendance-reports.php', this)">
                        <div class="font-medium">Yoklama Raporları</div>
                        <div class="text-sm text-gray-600">admin/attendance-reports.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('admin/qr-management.php', this)">
                        <div class="font-medium">QR Kod Yönetimi</div>
                        <div class="text-sm text-gray-600">admin/qr-management.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                </div>
            </div>

            <!-- Employee Interface -->
            <div class="test-category bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">👤 Personel Arayüzü</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="test-item status-loading" onclick="testPage('employee/dashboard.php', this)">
                        <div class="font-medium">Personel Dashboard</div>
                        <div class="text-sm text-gray-600">employee/dashboard.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('employee/attendance-records.php', this)">
                        <div class="font-medium">Yoklama Kayıtları</div>
                        <div class="text-sm text-gray-600">employee/attendance-records.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('employee/profile.php', this)">
                        <div class="font-medium">Personel Profili</div>
                        <div class="text-sm text-gray-600">employee/profile.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                </div>
            </div>

            <!-- QR System -->
            <div class="test-category bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">📱 QR Kod Sistemi</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="test-item status-loading" onclick="testPage('qr/qr-reader.php', this)">
                        <div class="font-medium">QR Kod Okuyucu (Eski)</div>
                        <div class="text-sm text-gray-600">qr/qr-reader.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('qr/new-qr-reader.php', this)">
                        <div class="font-medium">YENİ QR Kod Okuyucu</div>
                        <div class="text-sm text-gray-600">qr/new-qr-reader.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('qr/enhanced-qr-scanner.php', this)">
                        <div class="font-medium">🚀 Gelişmiş QR Tarayıcı</div>
                        <div class="text-sm text-gray-600">qr/enhanced-qr-scanner.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('qr/qr-test-simple.php', this)">
                        <div class="font-medium">Basit QR Test</div>
                        <div class="text-sm text-gray-600">qr/qr-test-simple.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('qr/activity-selection.php', this)">
                        <div class="font-medium">Aktivite Seçimi</div>
                        <div class="text-sm text-gray-600">qr/activity-selection.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('qr/generate-qr.php', this)">
                        <div class="font-medium">QR Kod Üretici</div>
                        <div class="text-sm text-gray-600">qr/generate-qr.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('qr/simple-qr-processor.php', this)">
                        <div class="font-medium">Basit QR İşleyici</div>
                        <div class="text-sm text-gray-600">qr/simple-qr-processor.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                </div>
            </div>

            <!-- QR Debug & Testing Tools -->
            <div class="test-category bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">🔍 QR Debug ve Test Araçları</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="test-item status-info" onclick="openNewWindow('qr/camera-test-debug.html')">
                        <div class="font-medium">🐛 Kamera Debug Test</div>
                        <div class="text-sm text-gray-600">camera-test-debug.html</div>
                        <div class="test-status text-sm mt-2">📝 HTML - Yeni pencerede açılır</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/test-gate-behaviors-direct.php', this)">
                        <div class="font-medium">🧪 Direkt Gate Test</div>
                        <div class="text-sm text-gray-600">debug/test-gate-behaviors-direct.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/check-qr-gate-behaviors.php', this)">
                        <div class="font-medium">📋 QR Gate Kontrol</div>
                        <div class="text-sm text-gray-600">debug/check-qr-gate-behaviors.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/fix-qr-gate-behaviors.php', this)">
                        <div class="font-medium">🔧 QR Gate Fixer</div>
                        <div class="text-sm text-gray-600">debug/fix-qr-gate-behaviors.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('test-qr-gate-live.php', this)">
                        <div class="font-medium">🧪 Canlı QR Gate Test</div>
                        <div class="text-sm text-gray-600">test-qr-gate-live.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('includes/qr-attendance-fixed.php', this)">
                        <div class="font-medium">⚙️ QR Attendance Helper</div>
                        <div class="text-sm text-gray-600">includes/qr-attendance-fixed.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/qr-gate-behavior-diagnosis.php', this)">
                        <div class="font-medium">🔬 Gate Behavior Tanı</div>
                        <div class="text-sm text-gray-600">debug/qr-gate-behavior-diagnosis.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/comprehensive-qr-test.php', this)">
                        <div class="font-medium">🧪 Kapsamlı QR Test</div>
                        <div class="text-sm text-gray-600">debug/comprehensive-qr-test.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/test-gate-behaviors-direct.php', this)">
                        <div class="font-medium">🎯 Direkt Gate Test</div>
                        <div class="text-sm text-gray-600">debug/test-gate-behaviors-direct.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('debug/qr-behavior-validation.php', this)">
                        <div class="font-medium">✅ QR Behavior Validation</div>
                        <div class="text-sm text-gray-600">debug/qr-behavior-validation.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                </div>
            </div>

            <!-- System Tools -->
            <div class="test-category bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">🛠️ Sistem Araçları</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="test-item status-loading" onclick="testPage('super-admin/system-tools/system-update.php', this)">
                        <div class="font-medium">Sistem Güncelleme</div>
                        <div class="text-sm text-gray-600">super-admin/system-tools/system-update.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('super-admin/system-tools/database-repair.php', this)">
                        <div class="font-medium">Veritabanı Onarımı</div>
                        <div class="text-sm text-gray-600">super-admin/system-tools/database-repair.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                    <div class="test-item status-loading" onclick="testPage('super-admin/company-management.php', this)">
                        <div class="font-medium">Şirket Yönetimi</div>
                        <div class="text-sm text-gray-600">super-admin/company-management.php</div>
                        <div class="test-status text-sm mt-2">🔄 Test edilecek...</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Test All Button -->
        <div class="bg-white rounded-lg shadow-md p-6 mt-6">
            <div class="text-center">
                <button onclick="testAllPages()" class="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-colors font-medium text-lg">
                    🚀 Tüm Sayfaları Test Et
                </button>
                <p class="text-sm text-gray-600 mt-2">Bu işlem birkaç dakika sürebilir</p>
                <div class="mt-4 text-xs text-gray-500">
                    <p>✅ Test tamamlandıktan sonra "📥 Rapor İndir (ZIP)" butonuna tıklayarak</p>
                    <p>sıkıştırılmış raporu indirin (tarayıcı güvenlik uyumlu)</p>
                </div>
            </div>
        </div>

        <!-- Progress Bar -->
        <div id="progress-container" class="bg-white rounded-lg shadow-md p-6 mt-6" style="display: none;">
            <div class="mb-2">
                <div class="flex justify-between">
                    <span class="text-sm font-medium text-blue-700">Test İlerlemesi</span>
                    <span class="text-sm font-medium text-blue-700" id="progress-text">0%</span>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2.5">
                <div class="bg-blue-600 h-2.5 rounded-full transition-all duration-300" id="progress-bar" style="width: 0%"></div>
            </div>
            <div class="mt-2 text-sm text-gray-600" id="current-test">Hazırlanıyor...</div>
        </div>

        <!-- Results Summary -->
        <div id="results-summary" class="bg-white rounded-lg shadow-md p-6 mt-6" style="display: none;">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📊 Test Sonuçları Özeti</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div class="text-green-800 font-semibold">✅ Başarılı</div>
                    <div class="text-2xl font-bold text-green-900" id="success-count">0</div>
                </div>
                <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div class="text-red-800 font-semibold">❌ Başarısız</div>
                    <div class="text-2xl font-bold text-red-900" id="error-count">0</div>
                </div>
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div class="text-blue-800 font-semibold">📊 Toplam</div>
                    <div class="text-2xl font-bold text-blue-900" id="total-count">0</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let testResults = [];
        let currentTestIndex = 0;
        let totalTests = 0;
        
        function downloadReport() {
            // Use the fixed download system
            window.open('fixed-download.php?method=json', '_blank');
        }

        function openNewWindow(url) {
            const fullUrl = url.startsWith('http') ? url : '/ik/' + url;
            window.open(fullUrl, '_blank', 'width=800,height=600,scrollbars=yes,resizable=yes');
        }

        function testPage(url, element) {
            const statusElement = element.querySelector('.test-status');
            statusElement.textContent = '🔄 Test ediliyor...';
            element.className = element.className.replace(/status-\w+/, 'status-loading');

            fetch('/ik/' + url)
                .then(response => {
                    if (response.ok) {
                        statusElement.textContent = '✅ Başarılı (' + response.status + ')';
                        element.className = element.className.replace(/status-\w+/, 'status-success');
                    } else {
                        statusElement.textContent = '❌ Hata (' + response.status + ')';
                        element.className = element.className.replace(/status-\w+/, 'status-error');
                    }
                })
                .catch(error => {
                    statusElement.textContent = '❌ Bağlantı hatası';
                    element.className = element.className.replace(/status-\w+/, 'status-error');
                });
        }

        function testAllPages() {
            const allTestItems = document.querySelectorAll('.test-item:not(.status-info)'); // Exclude HTML files
            totalTests = allTestItems.length;
            currentTestIndex = 0;
            testResults = [];

            document.getElementById('progress-container').style.display = 'block';
            document.getElementById('results-summary').style.display = 'none';

            function testNext() {
                if (currentTestIndex < totalTests) {
                    const testItem = allTestItems[currentTestIndex];
                    const onclickText = testItem.getAttribute('onclick');
                    
                    // Skip HTML files that use openNewWindow
                    if (onclickText && onclickText.includes('openNewWindow')) {
                        currentTestIndex++;
                        setTimeout(testNext, 100);
                        return;
                    }
                    
                    const url = onclickText.match(/'([^']+)'/)[1];
                    const description = testItem.querySelector('.font-medium').textContent;

                    document.getElementById('current-test').textContent = `Test ediliyor: ${description}`;
                    testPage(url, testItem);

                    // Update progress
                    const progress = ((currentTestIndex + 1) / totalTests) * 100;
                    document.getElementById('progress-bar').style.width = progress + '%';
                    document.getElementById('progress-text').textContent = Math.round(progress) + '%';

                    currentTestIndex++;
                    setTimeout(testNext, 1000); // Wait 1 second between tests
                } else {
                    // All tests completed
                    document.getElementById('current-test').textContent = 'Tüm testler tamamlandı!';
                    showResultsSummary();
                }
            }

            testNext();
        }

        function showResultsSummary() {
            const allTestItems = document.querySelectorAll('.test-item');
            let successCount = 0;
            let errorCount = 0;

            allTestItems.forEach(item => {
                if (item.classList.contains('status-success')) {
                    successCount++;
                } else if (item.classList.contains('status-error')) {
                    errorCount++;
                }
            });

            document.getElementById('success-count').textContent = successCount;
            document.getElementById('error-count').textContent = errorCount;
            document.getElementById('total-count').textContent = totalTests;
            document.getElementById('results-summary').style.display = 'block';
        }
    </script>
</body>
</html>