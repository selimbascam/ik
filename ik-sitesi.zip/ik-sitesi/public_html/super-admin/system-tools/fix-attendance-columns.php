<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Attendance Records Column Fix</h1>";
echo "<p>Düzeltme: attendance_records tablosunda eksik 'timestamp' kolonu sorunları...</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div style='background: #f8f9fa; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; margin-bottom: 20px;'>";
    echo "<h3>🔍 Attendance Records Kolonu Düzeltme İşlemleri:</h3>";
    
    $fixCount = 0;
    $errorCount = 0;
    
    // Show current table structure
    echo "<h4>📋 Mevcut Tablo Yapısı:</h4>";
    $columns = $conn->query("SHOW COLUMNS FROM attendance_records")->fetchAll();
    echo "<table style='width: 100%; border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Kolon</th>";
    echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Tip</th>";
    echo "</tr>";
    
    $hasTimestamp = false;
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td style='border: 1px solid #dee2e6; padding: 8px;'>{$col['Field']}</td>";
        echo "<td style='border: 1px solid #dee2e6; padding: 8px;'>{$col['Type']}</td>";
        echo "</tr>";
        
        if ($col['Field'] === 'timestamp') {
            $hasTimestamp = true;
        }
    }
    echo "</table>";
    
    // Check problematic queries and suggest fixes
    echo "<h4>🔧 SQL Query Düzeltmeleri:</h4>";
    
    echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border: 1px solid #ffeaa7; border-radius: 5px; margin: 10px 0;'>";
    echo "<h5>❌ Hatalı Kullanım:</h5>";
    echo "<code>ar.timestamp</code> - Bu kolon attendance_records tablosunda yok<br>";
    echo "<code>ar.activity_type</code> - Bu kolon attendance_records tablosunda yok<br>";
    echo "<code>ar.location_id</code> - Bu kolon yok, <code>ar.qr_location_id</code> kullanılmalı";
    echo "</div>";
    
    echo "<div style='background: #d4edda; color: #155724; padding: 10px; border: 1px solid #c3e6cb; border-radius: 5px; margin: 10px 0;'>";
    echo "<h5>✅ Doğru Kullanım:</h5>";
    echo "<code>ar.created_at</code> - Kayıt oluşturma tarihi için<br>";
    echo "<code>aa.activity_type</code> - Aktivite tipi için (attendance_activities tablosundan JOIN ile)<br>";
    echo "<code>ar.qr_location_id</code> - QR lokasyon ilişkisi için";
    echo "</div>";
    
    // Check for data consistency
    echo "<h4>📊 Veri Tutarlılığı Kontrolü:</h4>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as total FROM attendance_records");
        $total = $stmt->fetch()['total'];
        echo "<div style='color: green;'>✓ Toplam attendance_records: $total</div>";
        
        // Check for missing activity references
        $stmt = $conn->query("
            SELECT COUNT(*) as count 
            FROM attendance_records ar 
            LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id 
            WHERE aa.id IS NULL AND ar.activity_id IS NOT NULL
        ");
        $missingActivities = $stmt->fetch()['count'];
        
        if ($missingActivities > 0) {
            echo "<div style='color: orange;'>⚠ $missingActivities kayıtta geçersiz activity_id referansı var</div>";
        } else {
            echo "<div style='color: green;'>✓ Tüm activity_id referansları geçerli</div>";
        }
        
        // Check for missing QR location references
        $stmt = $conn->query("
            SELECT COUNT(*) as count 
            FROM attendance_records ar 
            LEFT JOIN qr_locations qr ON ar.qr_location_id = qr.id 
            WHERE qr.id IS NULL AND ar.qr_location_id IS NOT NULL
        ");
        $missingLocations = $stmt->fetch()['count'];
        
        if ($missingLocations > 0) {
            echo "<div style='color: orange;'>⚠ $missingLocations kayıtta geçersiz qr_location_id referansı var</div>";
        } else {
            echo "<div style='color: green;'>✓ Tüm qr_location_id referansları geçerli</div>";
        }
        
    } catch (Exception $e) {
        echo "<div style='color: red;'>❌ Veri kontrolü hatası: " . $e->getMessage() . "</div>";
        $errorCount++;
    }
    
    echo "</div>";
    
    if ($errorCount === 0) {
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px;'>";
        echo "<h3>🎉 Attendance Records Tablosu Kontrol Edildi!</h3>";
        echo "<p><strong>Durum Özeti:</strong></p>";
        echo "<ul>";
        echo "<li>✓ Tablo yapısı görüntülendi</li>";
        echo "<li>✓ Kolon kullanım hatalarının düzeltmeleri önerildi</li>";
        echo "<li>✓ Veri tutarlılığı kontrol edildi</li>";
        echo "<li>✓ SQL query'leri düzeltildi (super-admin/index.php, system-logs.php)</li>";
        echo "</ul>";
        echo "<p><strong>Yapılan Düzeltmeler:</strong></p>";
        echo "<ul>";
        echo "<li>ar.timestamp → ar.created_at</li>";
        echo "<li>ar.location_id → ar.qr_location_id</li>";
        echo "<li>ar.activity_type → aa.activity_type (JOIN ile)</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
        echo "<h3>⚠ Kısmi Kontrol Tamamlandı</h3>";
        echo "<p><strong>Özet:</strong></p>";
        echo "<ul>";
        echo "<li>❌ $errorCount hata oluştu</li>";
        echo "<li>⚠ Bazı kontroller tamamlanamadı</li>";
        echo "</ul>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Kontrol Hatası</h3>";
    echo "<p><strong>Hata:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='super-admin/'>← Süper Admin Paneline Dön</a></p>";
echo "<p><a href='database-overview.php'>📊 Veritabanı Durumunu Kontrol Et</a></p>";
?>