<?php
// Fix Device Columns for MySQL - Add device tracking columns to attendance_records
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 MySQL Cihaz Sütunları Düzeltme</h1>";
echo "<p>Attendance_records tablosuna cihaz bilgisi sütunları ekleniyor...</p><hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>🗄️ Mevcut Tablo Yapısı Kontrolü</h3>";
    
    // Check existing columns
    $stmt = $conn->query("DESCRIBE attendance_records");
    $existingColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $deviceColumns = [
        'device_mac_address' => 'VARCHAR(17)',
        'device_ip_address' => 'VARCHAR(45)', 
        'device_user_agent' => 'TEXT',
        'device_fingerprint' => 'VARCHAR(255)',
        'device_platform' => 'VARCHAR(50)',
        'device_browser' => 'VARCHAR(100)'
    ];
    
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<strong>Mevcut Sütunlar:</strong><br>";
    foreach ($existingColumns as $col) {
        $hasDevice = strpos($col, 'device_') === 0;
        echo ($hasDevice ? "✅" : "•") . " $col<br>";
    }
    echo "</div>";
    
    echo "<h3>🔨 Eksik Sütunları Ekleme</h3>";
    
    $addedColumns = [];
    $skippedColumns = [];
    
    foreach ($deviceColumns as $columnName => $columnType) {
        if (in_array($columnName, $existingColumns)) {
            $skippedColumns[] = $columnName;
            echo "<div style='color: #856404; background: #fff3cd; padding: 8px; margin: 5px 0; border-radius: 3px;'>";
            echo "⚠️ <strong>$columnName</strong> sütunu zaten mevcut - atlandı";
            echo "</div>";
        } else {
            try {
                $sql = "ALTER TABLE attendance_records ADD COLUMN $columnName $columnType";
                $conn->exec($sql);
                $addedColumns[] = $columnName;
                
                echo "<div style='color: #155724; background: #d4edda; padding: 8px; margin: 5px 0; border-radius: 3px;'>";
                echo "✅ <strong>$columnName</strong> sütunu başarıyla eklendi ($columnType)";
                echo "</div>";
                
            } catch (Exception $e) {
                echo "<div style='color: #721c24; background: #f8d7da; padding: 8px; margin: 5px 0; border-radius: 3px;'>";
                echo "❌ <strong>$columnName</strong> sütunu eklenemedi: " . $e->getMessage();
                echo "</div>";
            }
        }
    }
    
    echo "<h3>📊 İşlem Özeti</h3>";
    echo "<div style='background: white; padding: 20px; border-radius: 8px; border: 1px solid #ddd;'>";
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;'>";
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; text-align: center;'>";
    echo "<div style='font-size: 24px; font-weight: bold; color: #155724;'>" . count($addedColumns) . "</div>";
    echo "<div style='color: #155724;'>Eklenen Sütun</div>";
    echo "</div>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; text-align: center;'>";
    echo "<div style='font-size: 24px; font-weight: bold; color: #856404;'>" . count($skippedColumns) . "</div>";
    echo "<div style='color: #856404;'>Zaten Mevcut</div>";
    echo "</div>";
    
    echo "<div style='background: #cff4fc; padding: 15px; border-radius: 5px; text-align: center;'>";
    echo "<div style='font-size: 24px; font-weight: bold; color: #055160;'>" . count($deviceColumns) . "</div>";
    echo "<div style='color: #055160;'>Toplam Sütun</div>";
    echo "</div>";
    
    echo "</div>";
    echo "</div>";
    
    // Verify final structure
    echo "<h3>✅ Final Tablo Yapısı</h3>";
    $stmt = $conn->query("DESCRIBE attendance_records");
    $finalColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<table style='width: 100%; border-collapse: collapse;'>";
    echo "<tr style='background: #e9ecef;'><th style='padding: 8px; text-align: left; border: 1px solid #ddd;'>Sütun Adı</th><th style='padding: 8px; text-align: left; border: 1px solid #ddd;'>Tür</th><th style='padding: 8px; text-align: left; border: 1px solid #ddd;'>Null</th><th style='padding: 8px; text-align: left; border: 1px solid #ddd;'>Default</th></tr>";
    
    foreach ($finalColumns as $col) {
        $isDevice = strpos($col['Field'], 'device_') === 0;
        $rowColor = $isDevice ? '#e8f5e8' : '';
        echo "<tr style='background: $rowColor;'>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . ($isDevice ? "🔍 " : "") . $col['Field'] . "</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . $col['Type'] . "</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . $col['Null'] . "</td>";
        echo "<td style='padding: 8px; border: 1px solid #ddd;'>" . ($col['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    
    echo "<h3>🧪 Test Data Insertion</h3>";
    
    // Test inserting sample data
    try {
        $testData = [
            'employee_id' => 1,
            'qr_location_id' => 1,
            'activity_id' => 1,
            'check_in_time' => date('Y-m-d H:i:s'),
            'latitude' => 41.0082,
            'longitude' => 28.9784,
            'distance_meters' => 50,
            'device_mac_address' => '00:1B:44:11:3A:B7',
            'device_ip_address' => '192.168.1.100',
            'device_user_agent' => 'Mozilla/5.0 (Test Device)',
            'device_fingerprint' => md5('test_device_' . time()),
            'device_platform' => 'Test Platform',
            'device_browser' => 'Test Browser'
        ];
        
        $placeholders = str_repeat('?,', count($testData) - 1) . '?';
        $columns = implode(',', array_keys($testData));
        
        $sql = "INSERT INTO attendance_records ($columns) VALUES ($placeholders)";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array_values($testData));
        
        $testId = $conn->lastInsertId();
        
        echo "<div style='color: #155724; background: #d4edda; padding: 15px; margin: 10px 0; border-radius: 5px;'>";
        echo "✅ <strong>Test verisi başarıyla eklendi!</strong><br>";
        echo "Test ID: $testId<br>";
        echo "MAC Adresi: " . $testData['device_mac_address'] . "<br>";
        echo "Platform: " . $testData['device_platform'] . "<br>";
        echo "Fingerprint: " . substr($testData['device_fingerprint'], 0, 16) . "...<br>";
        echo "</div>";
        
        // Clean up test data
        $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
        $stmt->execute([$testId]);
        
        echo "<div style='color: #856404; background: #fff3cd; padding: 8px; margin: 5px 0; border-radius: 3px;'>";
        echo "🧹 Test verisi temizlendi (ID: $testId)";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='color: #721c24; background: #f8d7da; padding: 15px; margin: 10px 0; border-radius: 5px;'>";
        echo "❌ <strong>Test verisi eklenemedi:</strong><br>" . $e->getMessage();
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='color: #721c24; background: #f8d7da; padding: 15px; margin: 10px 0; border-radius: 5px;'>";
    echo "❌ <strong>Hata:</strong> " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<h3>🔗 Sistem Linkleri</h3>";
echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; margin: 20px 0;'>";
echo "<a href='/ik/admin/qr-generator.php' style='background: #7C3AED; color: white; padding: 12px; text-decoration: none; border-radius: 5px; text-align: center;'>🗺️ QR Generator</a>";
echo "<a href='/ik/view-device-records.php' style='background: #059669; color: white; padding: 12px; text-decoration: none; border-radius: 5px; text-align: center;'>📱 Device Records</a>";
echo "<a href='/ik/test-device-tracking.php' style='background: #DC2626; color: white; padding: 12px; text-decoration: none; border-radius: 5px; text-align: center;'>🧪 Device Test</a>";
echo "<a href='/ik/dashboard/company-dashboard.php' style='background: #1D4ED8; color: white; padding: 12px; text-decoration: none; border-radius: 5px; text-align: center;'>🏠 Dashboard</a>";
echo "</div>";

echo "<p><strong>İşlem tamamlandı:</strong> " . date('Y-m-d H:i:s') . "</p>";
?>