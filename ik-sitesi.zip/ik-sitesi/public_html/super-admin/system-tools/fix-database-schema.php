<?php
require_once '../../includes/config.php';
require_once '../../includes/database.php';

echo "<!DOCTYPE html><html><head><title>Veritabanı Şema Düzeltici</title></head><body>";
echo "<h2>🔧 VERİTABANI ŞEMA DÜZELTİCİ</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $fixes = [];
    $errors = [];
    
    echo "<h3>1. Employees tablosu kontrol ediliyor...</h3>";
    
    // Check employee_number vs employee_code
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
        $hasEmployeeNumber = $stmt->fetch();
        
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_code'");
        $hasEmployeeCode = $stmt->fetch();
        
        if ($hasEmployeeNumber && !$hasEmployeeCode) {
            // Rename employee_number to employee_code
            $conn->exec("ALTER TABLE employees CHANGE employee_number employee_code VARCHAR(50) UNIQUE NOT NULL");
            $fixes[] = "✅ employee_number → employee_code olarak yeniden adlandırıldı";
        } elseif (!$hasEmployeeCode) {
            $conn->exec("ALTER TABLE employees ADD COLUMN employee_code VARCHAR(50) UNIQUE NOT NULL AFTER company_id");
            $fixes[] = "✅ employee_code sütunu eklendi";
        }
    } catch (Exception $e) {
        $errors[] = "❌ Employee_code düzeltme hatası: " . $e->getMessage();
    }
    
    // Check password vs password_hash
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'password'");
        $hasPassword = $stmt->fetch();
        
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'password_hash'");
        $hasPasswordHash = $stmt->fetch();
        
        if ($hasPassword && !$hasPasswordHash) {
            // Rename password to password_hash
            $conn->exec("ALTER TABLE employees CHANGE password password_hash VARCHAR(255) NOT NULL");
            $fixes[] = "✅ password → password_hash olarak yeniden adlandırıldı";
        } elseif (!$hasPasswordHash) {
            $conn->exec("ALTER TABLE employees ADD COLUMN password_hash VARCHAR(255) NOT NULL AFTER email");
            $fixes[] = "✅ password_hash sütunu eklendi";
        }
    } catch (Exception $e) {
        $errors[] = "❌ Password_hash düzeltme hatası: " . $e->getMessage();
    }
    
    // Check status vs is_active
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'status'");
        $hasStatus = $stmt->fetch();
        
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'is_active'");
        $hasIsActive = $stmt->fetch();
        
        if ($hasStatus && !$hasIsActive) {
            // Add is_active and migrate data
            $conn->exec("ALTER TABLE employees ADD COLUMN is_active BOOLEAN DEFAULT TRUE AFTER position");
            $conn->exec("UPDATE employees SET is_active = CASE WHEN status = 'active' THEN TRUE ELSE FALSE END");
            $fixes[] = "✅ status → is_active olarak migrate edildi";
        } elseif (!$hasIsActive) {
            $conn->exec("ALTER TABLE employees ADD COLUMN is_active BOOLEAN DEFAULT TRUE AFTER position");
            $fixes[] = "✅ is_active sütunu eklendi";
        }
    } catch (Exception $e) {
        $errors[] = "❌ is_active düzeltme hatası: " . $e->getMessage();
    }
    
    // Check salary vs wage_per_day
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'salary'");
        $hasSalary = $stmt->fetch();
        
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'wage_per_day'");
        $hasWagePerDay = $stmt->fetch();
        
        if ($hasSalary && !$hasWagePerDay) {
            // Rename salary to wage_per_day
            $conn->exec("ALTER TABLE employees CHANGE salary wage_per_day DECIMAL(10,2) DEFAULT NULL");
            $fixes[] = "✅ salary → wage_per_day olarak yeniden adlandırıldı";
        } elseif (!$hasWagePerDay) {
            $conn->exec("ALTER TABLE employees ADD COLUMN wage_per_day DECIMAL(10,2) DEFAULT NULL AFTER position");
            $fixes[] = "✅ wage_per_day sütunu eklendi";
        }
    } catch (Exception $e) {
        $errors[] = "❌ wage_per_day düzeltme hatası: " . $e->getMessage();
    }
    
    echo "<h3>2. Companies tablosu kontrol ediliyor...</h3>";
    
    // Check companies table
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM companies LIKE 'status'");
        $hasStatus = $stmt->fetch();
        
        $stmt = $conn->query("SHOW COLUMNS FROM companies LIKE 'is_active'");
        $hasIsActive = $stmt->fetch();
        
        if ($hasStatus && !$hasIsActive) {
            // Add is_active and migrate data
            $conn->exec("ALTER TABLE companies ADD COLUMN is_active BOOLEAN DEFAULT TRUE AFTER email");
            $conn->exec("UPDATE companies SET is_active = CASE WHEN status = 'active' THEN TRUE ELSE FALSE END");
            $fixes[] = "✅ Companies tablosu status → is_active migrate edildi";
        } elseif (!$hasIsActive) {
            $conn->exec("ALTER TABLE companies ADD COLUMN is_active BOOLEAN DEFAULT TRUE AFTER email");
            $fixes[] = "✅ Companies tablosu is_active sütunu eklendi";
        }
    } catch (Exception $e) {
        $errors[] = "❌ Companies is_active düzeltme hatası: " . $e->getMessage();
    }
    
    echo "<h3>📊 SONUÇLAR:</h3>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h4 style='color: #155724;'>Başarılı Düzeltmeler (" . count($fixes) . "):</h4>";
    foreach ($fixes as $fix) {
        echo "<p style='color: #155724; margin: 5px 0;'>$fix</p>";
    }
    echo "</div>";
    
    if (!empty($errors)) {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4 style='color: #721c24;'>Hatalar (" . count($errors) . "):</h4>";
        foreach ($errors as $error) {
            echo "<p style='color: #721c24; margin: 5px 0;'>$error</p>";
        }
        echo "</div>";
    }
    
    if (empty($fixes) && empty($errors)) {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p style='color: #856404;'>ℹ️ Tüm şema yapıları zaten doğru durumda.</p>";
        echo "</div>";
    }
    
    echo "<br><a href='../index.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>← Super Admin'e Dön</a>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h4 style='color: #721c24;'>Kritik Hata:</h4>";
    echo "<p style='color: #721c24;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "</body></html>";
?>