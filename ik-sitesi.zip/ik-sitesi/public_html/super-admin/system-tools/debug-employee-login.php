<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<div style='max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif;'>";
echo "<h1 style='background: #17a2b8; color: white; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>🔍 Employee Login Debug</h1>";
echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";

echo "<p><strong>Employee login ve QR reader sayfası debug testi...</strong></p>";

// Check current session
echo "<h2>📋 1. Session Control</h2>";
echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
echo "<p><strong>Session Status:</strong> " . (session_status() == PHP_SESSION_ACTIVE ? "✅ Active" : "❌ Inactive") . "</p>";
echo "<p><strong>Session ID:</strong> " . session_id() . "</p>";

if (isset($_SESSION['employee_id'])) {
    echo "<p><strong>Employee ID:</strong> " . $_SESSION['employee_id'] . "</p>";
    echo "<p><strong>Company ID:</strong> " . $_SESSION['company_id'] . "</p>";
    echo "<p><strong>Employee Name:</strong> " . $_SESSION['employee_name'] . "</p>";
} else {
    echo "<p style='color: red;'><strong>Employee Session:</strong> ❌ Not logged in</p>";
}
echo "</div>";

// Test database connection
echo "<h2>🔍 2. Database Connection Test</h2>";
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ Database connection successful";
    echo "</div>";
    
    // Test employee table
    $stmt = $conn->query("SHOW TABLES LIKE 'employees'");
    if ($stmt->fetch()) {
        echo "<div style='background: #d4edda; color: #155724; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
        echo "✅ Employees table exists";
        echo "</div>";
        
        // Check for test employee
        $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number FROM employees WHERE employee_number = 'EMP001'");
        $stmt->execute();
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($employee) {
            echo "<div style='background: #d4edda; color: #155724; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
            echo "✅ Test employee EMP001 exists: " . $employee['first_name'] . " " . $employee['last_name'];
            echo "</div>";
        } else {
            echo "<div style='background: #f8d7da; color: #721c24; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
            echo "❌ Test employee EMP001 not found";
            echo "</div>";
        }
    } else {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
        echo "❌ Employees table not found";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ Database connection failed: " . $e->getMessage();
    echo "</div>";
}

// Test login process
echo "<h2>🔑 3. Manual Login Test</h2>";
echo "<form method='POST' style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
echo "<div style='margin: 10px 0;'>";
echo "<label>Employee Number:</label>";
echo "<input type='text' name='test_employee_id' value='EMP001' style='width: 200px; padding: 5px; border: 1px solid #ccc; border-radius: 3px; margin-left: 10px;'>";
echo "</div>";
echo "<div style='margin: 10px 0;'>";
echo "<label>Password:</label>";
echo "<input type='password' name='test_password' value='szb123456' style='width: 200px; padding: 5px; border: 1px solid #ccc; border-radius: 3px; margin-left: 10px;'>";
echo "</div>";
echo "<button type='submit' name='test_login' style='background: #007bff; color: white; padding: 8px 16px; border: none; border-radius: 3px; cursor: pointer;'>Test Login</button>";
echo "</form>";

if (isset($_POST['test_login'])) {
    $testEmployeeId = $_POST['test_employee_id'] ?? '';
    $testPassword = $_POST['test_password'] ?? '';
    
    echo "<h3>🧪 Login Test Results</h3>";
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $stmt = $conn->prepare("
            SELECT e.id, e.first_name, e.last_name, e.email, e.employee_number, 
                   e.company_id, c.company_name, c.company_code
            FROM employees e 
            JOIN companies c ON e.company_id = c.id 
            WHERE e.employee_number = ? AND e.password = MD5(?) AND e.status = 'active'
        ");
        $stmt->execute([$testEmployeeId, $testPassword]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($employee) {
            echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<h4>✅ Login Successful!</h4>";
            echo "<p><strong>Employee:</strong> " . $employee['first_name'] . " " . $employee['last_name'] . "</p>";
            echo "<p><strong>Company:</strong> " . $employee['company_name'] . "</p>";
            echo "<p><strong>Employee ID:</strong> " . $employee['id'] . "</p>";
            echo "<p><strong>Company ID:</strong> " . $employee['company_id'] . "</p>";
            echo "</div>";
            
            // Set session data
            $_SESSION['employee_id'] = $employee['id'];
            $_SESSION['company_id'] = $employee['company_id'];
            $_SESSION['company_code'] = $employee['company_code'] ?? '';
            $_SESSION['company_name'] = $employee['company_name'] ?? '';
            $_SESSION['user_role'] = 'employee';
            $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
            $_SESSION['employee_number'] = $employee['employee_number'];
            
            echo "<div style='background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "✅ Session data set successfully!";
            echo "</div>";
            
        } else {
            echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "❌ Invalid credentials or inactive employee";
            echo "</div>";
            
            // Debug: Check if employee exists without password
            $stmt = $conn->prepare("SELECT id, employee_number, status FROM employees WHERE employee_number = ?");
            $stmt->execute([$testEmployeeId]);
            $emp = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($emp) {
                echo "<div style='background: #fff3cd; color: #856404; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
                echo "ℹ️ Employee exists but password/status issue - Status: " . $emp['status'];
                echo "</div>";
            } else {
                echo "<div style='background: #f8d7da; color: #721c24; padding: 8px; border-radius: 3px; margin: 5px 0;'>";
                echo "❌ Employee number not found: $testEmployeeId";
                echo "</div>";
            }
        }
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Login test error: " . $e->getMessage();
        echo "</div>";
    }
}

// Test QR reader access
echo "<h2>📱 4. QR Reader Access Test</h2>";
if (isset($_SESSION['employee_id'])) {
    echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ Employee session active - QR reader should be accessible";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='qr/qr-reader.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>📱 Test QR Reader</a>";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ No employee session - QR reader access denied";
    echo "</div>";
}

// Error log check
echo "<h2>📄 5. Recent Error Logs</h2>";
if (function_exists('error_get_last')) {
    $lastError = error_get_last();
    if ($lastError) {
        echo "<div style='background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "<p>Last PHP Error:</p>";
        echo "<pre>" . print_r($lastError, true) . "</pre>";
        echo "</div>";
    } else {
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ No recent PHP errors detected";
        echo "</div>";
    }
}

echo "<h2>🎯 Next Steps</h2>";
echo "<div style='background: #e2e3e5; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<h3>Debugging Results:</h3>";
echo "<ol>";
echo "<li>Test employee login using the form above</li>";
echo "<li>If login successful, click 'Test QR Reader' button</li>";
echo "<li>Check browser console for JavaScript errors</li>";
echo "<li>If QR reader fails, check session data</li>";
echo "</ol>";
echo "</div>";

echo "<div style='text-align: center; margin: 20px 0;'>";
echo "<a href='auth/employee-login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>👤 Regular Login</a>";
echo "<a href='emergency-fix-session.php' style='background: #dc3545; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🔧 System Check</a>";
echo "</div>";

echo "</div>";
echo "</div>";
?>