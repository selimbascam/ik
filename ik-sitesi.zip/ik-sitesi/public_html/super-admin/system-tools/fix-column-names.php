<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<div style='max-width: 800px; margin: 20px auto; font-family: Arial, sans-serif;'>";
echo "<h1 style='background: #28a745; color: white; padding: 15px; margin: 0; border-radius: 8px 8px 0 0;'>🔧 Column Name Fix</h1>";
echo "<div style='background: white; padding: 20px; border: 1px solid #ddd; border-radius: 0 0 8px 8px;'>";

echo "<p><strong>attendance_records tablosundaki sütun adlarını düzeltiyoruz...</strong></p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📋 1. Mevcut Sütunları Kontrol Et</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<p><strong>Mevcut sütunlar:</strong></p>";
    echo "<ul>";
    foreach ($columns as $column) {
        $columnName = $column['Field'];
        $highlight = (in_array($columnName, ['check_in', 'check_out', 'check_in_time', 'check_out_time'])) ? 'style="color: blue; font-weight: bold;"' : '';
        echo "<li $highlight>$columnName</li>";
    }
    echo "</ul>";
    echo "</div>";
    
    // Check if we need to rename columns
    $hasOldColumns = false;
    $columnMap = [];
    
    foreach ($columns as $column) {
        $columnName = $column['Field'];
        if ($columnName === 'check_in_time') {
            $hasOldColumns = true;
            $columnMap['check_in_time'] = 'check_in';
        }
        if ($columnName === 'check_out_time') {
            $hasOldColumns = true;
            $columnMap['check_out_time'] = 'check_out';
        }
        if ($columnName === 'break_start_time') {
            $hasOldColumns = true;
            $columnMap['break_start_time'] = 'break_start';
        }
        if ($columnName === 'break_end_time') {
            $hasOldColumns = true;
            $columnMap['break_end_time'] = 'break_end';
        }
    }
    
    if ($hasOldColumns) {
        echo "<h2>🛠️ 2. Sütun Adlarını Düzelt</h2>";
        
        foreach ($columnMap as $oldName => $newName) {
            echo "<h3>Renaming $oldName → $newName</h3>";
            
            $sql = "ALTER TABLE attendance_records CHANGE `$oldName` `$newName` DATETIME DEFAULT NULL";
            
            try {
                $conn->exec($sql);
                echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                echo "✅ <strong>$oldName</strong> → <strong>$newName</strong> başarıyla değiştirildi!";
                echo "</div>";
            } catch (Exception $e) {
                echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
                echo "❌ Sütun adı değiştirme hatası ($oldName): " . $e->getMessage();
                echo "</div>";
            }
        }
        
    } else {
        echo "<div style='background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "ℹ️ Sütun adları zaten doğru formatında";
        echo "</div>";
    }
    
    // Test the corrected columns
    echo "<h2>🧪 3. Düzeltilmiş Sütunları Test Et</h2>";
    
    try {
        // Test basic query
        $stmt = $conn->prepare("SELECT check_in, check_out, break_start, break_end FROM attendance_records LIMIT 1");
        $stmt->execute();
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "✅ Sütun adları artık doğru! (check_in, check_out, break_start, break_end)";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
        echo "❌ Test hatası: " . $e->getMessage();
        echo "</div>";
    }
    
    echo "<h2>🎉 İşlem Tamamlandı!</h2>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>Yapılan İşlemler:</h3>";
    echo "<ul>";
    echo "<li>✅ Sütun adları kontrol edildi</li>";
    echo "<li>✅ Gerekli sütun adı değişiklikleri yapıldı</li>";
    echo "<li>✅ Veritabanı tutarlılığı sağlandı</li>";
    echo "<li>✅ check_in_time → check_in</li>";
    echo "<li>✅ check_out_time → check_out</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='fix-php-files-column-names.php' style='background: #ffc107; color: #212529; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>📝 PHP Dosyalarını Düzelt</a>";
    echo "<a href='emergency-fix-session.php' style='background: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>🔄 Sistem Kontrolü</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Kritik Hata</h3>";
    echo "<p>Veritabanı hatası: " . $e->getMessage() . "</p>";
    echo "<p><strong>Çözüm:</strong> Veritabanı bağlantınızı kontrol edin ve yeniden deneyin.</p>";
    echo "</div>";
}

echo "</div>";
echo "</div>";
?>