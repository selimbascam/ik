<?php
require_once 'includes/config.php';

echo "<h1>🔍 MySQL Veritabanı Tam Kontrol</h1>";

try {
    // Direct MySQL connection using production credentials
    $host = 'localhost';
    $dbname = 'u978874874_ik';
    $username = 'u978874874_ik';
    $password = 'Szb2013@+-!';
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green;'>✅ MySQL bağlantısı başarılı: $dbname</div>";
    
    // Check all tables
    echo "<h2>📋 Mevcut Tablolar</h2>";
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<p>Toplam " . count($tables) . " tablo bulundu:</p>";
    echo "<ul>";
    foreach ($tables as $table) {
        echo "<li><strong>$table</strong></li>";
    }
    echo "</ul>";
    
    // Check companies table
    echo "<h2>🏢 Companies Tablosu</h2>";
    if (in_array('companies', $tables)) {
        $stmt = $pdo->query("DESCRIBE companies");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        
        $has_company_name = false;
        foreach ($columns as $col) {
            if ($col['Field'] === 'company_name') $has_company_name = true;
            echo "<tr>";
            echo "<td><strong>{$col['Field']}</strong></td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>{$col['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        if (!$has_company_name) {
            echo "<div style='color: red;'>❌ company_name sütunu yok, ekleniyor...</div>";
            $pdo->exec("ALTER TABLE companies ADD COLUMN company_name VARCHAR(255) AFTER id");
            echo "<div style='color: green;'>✅ company_name sütunu eklendi</div>";
        } else {
            echo "<div style='color: green;'>✅ company_name sütunu var</div>";
        }
        
        // Check data
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM companies");
        $count = $stmt->fetch()['count'];
        echo "<p>Toplam şirket sayısı: <strong>$count</strong></p>";
        
        if ($count == 0) {
            echo "<div style='color: orange;'>⚠️ Demo şirket ekleniyor...</div>";
            $stmt = $pdo->prepare("INSERT INTO companies (company_name, company_code, email, status) VALUES (?, ?, ?, 'active')");
            $stmt->execute(['Demo Şirket', 'DEMO001', 'info@demo.com']);
            echo "<div style='color: green;'>✅ Demo şirket eklendi</div>";
        }
    } else {
        echo "<div style='color: red;'>❌ companies tablosu yok</div>";
    }
    
    // Check employees table
    echo "<h2>👥 Employees Tablosu</h2>";
    if (in_array('employees', $tables)) {
        $stmt = $pdo->query("DESCRIBE employees");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Sütun</th><th>Tip</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        
        $has_password = false;
        foreach ($columns as $col) {
            if ($col['Field'] === 'password') $has_password = true;
            echo "<tr>";
            echo "<td><strong>{$col['Field']}</strong></td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>{$col['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        if (!$has_password) {
            echo "<div style='color: red;'>❌ password sütunu yok, ekleniyor...</div>";
            $pdo->exec("ALTER TABLE employees ADD COLUMN password VARCHAR(255) AFTER email");
            echo "<div style='color: green;'>✅ password sütunu eklendi</div>";
        } else {
            echo "<div style='color: green;'>✅ password sütunu var</div>";
        }
        
        // Check data
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM employees");
        $count = $stmt->fetch()['count'];
        echo "<p>Toplam personel sayısı: <strong>$count</strong></p>";
        
        if ($count == 0) {
            echo "<div style='color: orange;'>⚠️ Demo personel ekleniyor...</div>";
            
            // Get company ID
            $stmt = $pdo->query("SELECT id FROM companies LIMIT 1");
            $company = $stmt->fetch();
            $company_id = $company['id'];
            
            $demo_employees = [
                ['EMP001', 'Ahmet', 'Yılmaz', 'ahmet@demo.com', 'demo123'],
                ['EMP002', 'Ayşe', 'Kaya', 'ayse@demo.com', 'demo123'],
                ['EMP003', 'Mehmet', 'Demir', 'mehmet@demo.com', 'demo123']
            ];
            
            foreach ($demo_employees as $emp) {
                $stmt = $pdo->prepare("
                    INSERT INTO employees 
                    (company_id, employee_number, first_name, last_name, email, password, status, hire_date) 
                    VALUES (?, ?, ?, ?, ?, SHA2(?, 256), 'active', CURDATE())
                ");
                $stmt->execute([$company_id, $emp[0], $emp[1], $emp[2], $emp[3], $emp[4]]);
                echo "<div style='color: green;'>✅ {$emp[1]} {$emp[2]} eklendi (No: {$emp[0]})</div>";
            }
        }
    } else {
        echo "<div style='color: red;'>❌ employees tablosu yok</div>";
    }
    
    // Test the login query
    echo "<h2>🧪 Personel Giriş Sorgusu Testi</h2>";
    try {
        $stmt = $pdo->prepare("
            SELECT e.id, e.first_name, e.last_name, e.email, e.employee_number, 
                   e.company_id, c.company_name, c.company_code
            FROM employees e 
            JOIN companies c ON e.company_id = c.id 
            WHERE e.employee_number = ? AND e.password = SHA2(?, 256) AND e.status = 'active'
        ");
        $stmt->execute(['EMP001', 'demo123']);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px;'>";
            echo "<h3>✅ GİRİŞ SORGUSU BAŞARILI!</h3>";
            echo "<p><strong>Test Sonucu:</strong></p>";
            echo "<pre>" . print_r($result, true) . "</pre>";
            echo "<p><strong>Giriş Bilgileri:</strong></p>";
            echo "<ul>";
            echo "<li>Personel No: EMP001</li>";
            echo "<li>Şifre: demo123</li>";
            echo "</ul>";
            echo "</div>";
        } else {
            echo "<div style='color: orange;'>⚠️ Giriş sorgusu sonuç döndürmedi</div>";
        }
        
    } catch (PDOException $e) {
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
        echo "<h3>❌ GİRİŞ SORGUSU HATASI</h3>";
        echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
        echo "</div>";
    }
    
    // List all employees
    echo "<h2>👤 Tüm Personel Listesi</h2>";
    $stmt = $pdo->query("
        SELECT e.employee_number, e.first_name, e.last_name, e.email, 
               c.company_name, e.status,
               CASE WHEN e.password IS NOT NULL THEN 'VAR' ELSE 'YOK' END as password_status
        FROM employees e 
        LEFT JOIN companies c ON e.company_id = c.id
    ");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($employees) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>Personel No</th><th>Ad Soyad</th><th>Email</th><th>Şirket</th><th>Durum</th><th>Şifre</th></tr>";
        foreach ($employees as $emp) {
            echo "<tr>";
            echo "<td><strong>{$emp['employee_number']}</strong></td>";
            echo "<td>{$emp['first_name']} {$emp['last_name']}</td>";
            echo "<td>{$emp['email']}</td>";
            echo "<td>{$emp['company_name']}</td>";
            echo "<td>{$emp['status']}</td>";
            echo "<td style='color: " . ($emp['password_status'] === 'VAR' ? 'green' : 'red') . ";'>{$emp['password_status']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Hiç personel bulunamadı.</p>";
    }
    
} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ MySQL BAĞLANTI HATASI</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><strong>Error Code:</strong> " . $e->getCode() . "</p>";
    echo "</div>";
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
    echo "<h3>❌ GENEL HATA</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<div style='text-align: center; margin: 20px 0;'>";
echo "<a href='auth/employee-login.php' style='background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-size: 18px;'>🚀 PERSONEL GİRİŞİ TEST ET</a>";
echo "</div>";
?>