<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

session_start();

echo "<h1>🔧 Şirket Geçiş Debug</h1>";

// Show all GET and POST parameters
echo "<div style='background: #f8f9fa; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; margin-bottom: 20px;'>";
echo "<h3>📋 Request Parameters:</h3>";
echo "<h4>GET Parameters:</h4>";
echo "<pre>" . print_r($_GET, true) . "</pre>";
echo "<h4>POST Parameters:</h4>";
echo "<pre>" . print_r($_POST, true) . "</pre>";
echo "</div>";

// Show current session
echo "<div style='background: #fff3cd; padding: 15px; border: 1px solid #ffeaa7; border-radius: 5px; margin-bottom: 20px;'>";
echo "<h3>🔍 Current Session:</h3>";
echo "<pre>";
foreach ($_SESSION as $key => $value) {
    echo htmlspecialchars($key) . " = " . htmlspecialchars(is_array($value) ? json_encode($value, JSON_PRETTY_PRINT) : $value) . "\n";
}
echo "</pre>";
echo "</div>";

if (isset($_GET['code'])) {
    $companyCode = $_GET['code'];
    echo "<div style='background: #e3f2fd; padding: 15px; border: 1px solid #2196f3; border-radius: 5px; margin-bottom: 20px;'>";
    echo "<h3>🎯 Company Switch Test for: " . htmlspecialchars($companyCode) . "</h3>";
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Find company by code
        $stmt = $conn->prepare("SELECT * FROM companies WHERE company_code = ?");
        $stmt->execute([$companyCode]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$company) {
            echo "<div style='color: red;'>❌ Company not found with code: " . htmlspecialchars($companyCode) . "</div>";
        } else {
            echo "<div style='color: green;'>✓ Company found:</div>";
            echo "<pre>" . print_r($company, true) . "</pre>";
            
            // Find admin user for this company
            $stmt = $conn->prepare("SELECT * FROM users WHERE company_id = ? AND role = 'admin' LIMIT 1");
            $stmt->execute([$company['id']]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$admin) {
                echo "<div style='color: orange;'>⚠ No admin user found for this company</div>";
            } else {
                echo "<div style='color: green;'>✓ Admin user found:</div>";
                echo "<pre>" . print_r($admin, true) . "</pre>";
                
                // Simulate the session update
                echo "<h4>🔄 Simulating Session Update:</h4>";
                echo "<div style='background: #d4edda; padding: 10px; border: 1px solid #c3e6cb; border-radius: 3px;'>";
                echo "Setting session variables:<br>";
                echo "- user_id: {$admin['id']}<br>";
                echo "- company_id: {$company['id']}<br>";
                echo "- user_role: {$admin['role']}<br>";
                echo "- user_email: {$admin['email']}<br>";
                echo "- super_admin_bypass: true<br>";
                echo "</div>";
                
                // Perform actual session update
                $_SESSION['user_id'] = $admin['id'];
                $_SESSION['company_id'] = $company['id'];
                $_SESSION['user_role'] = $admin['role'];
                $_SESSION['user_email'] = $admin['email'];
                $_SESSION['user_name'] = $admin['first_name'] . ' ' . $admin['last_name'];
                $_SESSION['super_admin_bypass'] = true;
                
                echo "<div style='background: #d1ecf1; padding: 10px; border: 1px solid #bee5eb; border-radius: 3px; margin-top: 10px;'>";
                echo "<strong>✅ Session Updated Successfully!</strong><br>";
                echo "<a href='dashboard/company-dashboard.php' style='background: #28a745; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; margin-top: 10px; display: inline-block;'>🚀 Go to Dashboard</a>";
                echo "</div>";
            }
        }
        
    } catch (Exception $e) {
        echo "<div style='color: red;'>❌ Database Error: " . htmlspecialchars($e->getMessage()) . "</div>";
    }
    
    echo "</div>";
}

// Show all companies for testing
echo "<div style='background: #f8f9fa; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; margin-bottom: 20px;'>";
echo "<h3>🏢 Available Companies for Testing:</h3>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $stmt = $conn->query("SELECT * FROM companies ORDER BY company_name");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($companies)) {
        echo "<div style='color: red;'>❌ No companies found in database</div>";
    } else {
        echo "<table style='width: 100%; border-collapse: collapse;'>";
        echo "<tr style='background: #e9ecef;'>";
        echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Company Name</th>";
        echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Code</th>";
        echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Status</th>";
        echo "<th style='border: 1px solid #dee2e6; padding: 8px; text-align: left;'>Test Link</th>";
        echo "</tr>";
        
        foreach ($companies as $company) {
            echo "<tr>";
            echo "<td style='border: 1px solid #dee2e6; padding: 8px;'>" . htmlspecialchars($company['company_name']) . "</td>";
            echo "<td style='border: 1px solid #dee2e6; padding: 8px;'>" . htmlspecialchars($company['company_code']) . "</td>";
            echo "<td style='border: 1px solid #dee2e6; padding: 8px;'>" . htmlspecialchars($company['status'] ?? 'active') . "</td>";
            echo "<td style='border: 1px solid #dee2e6; padding: 8px;'>";
            echo "<a href='debug-switch-company.php?code=" . urlencode($company['company_code']) . "' ";
            echo "style='background: #007bff; color: white; padding: 4px 8px; text-decoration: none; border-radius: 3px; font-size: 12px;'>";
            echo "🧪 Test Switch</a>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "<div style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</div>";
}

echo "</div>";

echo "<div style='text-align: center; margin: 20px 0;'>";
echo "<a href='super-admin/' style='background: #6f42c1; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>← Super Admin Panel</a>";
echo "<a href='dashboard/company-dashboard.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 0 10px;'>Dashboard (Current Session)</a>";
echo "</div>";
?>