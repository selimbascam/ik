<?php
// Comprehensive System Check and Fix
require_once 'includes/config.php';
require_once 'includes/database.php';

set_time_limit(300); // 5 minutes execution time

echo "<h1>Kapsamlı Sistem Kontrolü ve Düzeltme</h1>";
echo "<p>Başlangıç: " . date('Y-m-d H:i:s') . "</p><hr>";

$errors = [];
$fixes = [];
$warnings = [];

// 1. File Structure Check
echo "<h2>1. Dosya Yapısı Kontrolü</h2>";

$criticalFiles = [
    'auth/company-login.php' => 'Şirket Giriş Sayfası',
    'auth/employee-login.php' => 'Personel Giriş Sayfası',
    'super-admin/index.php' => 'Süper Admin Paneli',
    'super-admin/workflow-tree.php' => 'İş Akış Ağacı',
    'super-admin/system-overview.php' => 'Sistem Genel Bakış',
    'admin/company-setup.php' => 'Şirket Kurulum',
    'admin/qr-generator.php' => 'QR Kod Üretici',
    'admin/employee-management.php' => 'Personel Yönetimi',
    'dashboard/company-dashboard.php' => 'Şirket Dashboard',
    'qr/qr-reader.php' => 'QR Kod Okuyucu',
    'qr/activity-selection.php' => 'Aktivite Seçimi',
    'attendance/records.php' => 'Devam Kayıtları',
    'includes/config.php' => 'Konfigürasyon',
    'includes/database.php' => 'Veritabanı Sınıfı',
    'includes/google-maps-config.php' => 'Google Maps Konfigürasyonu'
];

foreach ($criticalFiles as $file => $description) {
    if (file_exists($file)) {
        echo "✅ $description ($file)<br>";
    } else {
        echo "❌ $description ($file) - EKSIK<br>";
        $errors[] = "Missing file: $file";
    }
}

// 2. Database Connection Test
echo "<h2>2. Veritabanı Bağlantı Testi</h2>";
try {
    $db = new Database();
    $conn = $db->getConnection();
    echo "✅ MySQL bağlantısı başarılı<br>";
    
    // Test critical tables
    $criticalTables = [
        'companies', 'users', 'employees', 'departments', 
        'qr_locations', 'attendance_records', 'attendance_activities',
        'sessions'
    ];
    
    foreach ($criticalTables as $table) {
        $stmt = $conn->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            $count_stmt = $conn->query("SELECT COUNT(*) as count FROM $table");
            $count = $count_stmt->fetch()['count'];
            echo "✅ Tablo $table mevcut ($count kayıt)<br>";
        } else {
            echo "❌ Tablo $table eksik<br>";
            $errors[] = "Missing table: $table";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Veritabanı bağlantı hatası: " . $e->getMessage() . "<br>";
    $errors[] = "Database connection failed: " . $e->getMessage();
}

// 3. Link Structure Analysis
echo "<h2>3. Link Yapısı Analizi</h2>";

function checkLinksInFile($filepath) {
    if (!file_exists($filepath)) return [];
    
    $content = file_get_contents($filepath);
    $links = [];
    
    // Find href links
    preg_match_all('/href=["\']([^"\']+)["\']/', $content, $matches);
    if (!empty($matches[1])) {
        $links = array_merge($links, $matches[1]);
    }
    
    // Find form actions
    preg_match_all('/action=["\']([^"\']+)["\']/', $content, $matches);
    if (!empty($matches[1])) {
        $links = array_merge($links, $matches[1]);
    }
    
    return array_unique($links);
}

$pagesWithLinks = [
    'super-admin/index.php',
    'super-admin/workflow-tree.php',
    'auth/company-login.php',
    'dashboard/company-dashboard.php',
    'admin/qr-generator.php'
];

foreach ($pagesWithLinks as $page) {
    if (file_exists($page)) {
        $links = checkLinksInFile($page);
        echo "<strong>$page:</strong><br>";
        foreach ($links as $link) {
            if (strpos($link, 'http') === 0 || strpos($link, '#') === 0 || strpos($link, 'javascript:') === 0) {
                echo "&nbsp;&nbsp;🔗 $link (external/script)<br>";
            } else {
                $fullPath = dirname($page) . '/' . ltrim($link, '/');
                $fullPath = str_replace('//', '/', $fullPath);
                if (file_exists($fullPath) || file_exists(ltrim($link, '/'))) {
                    echo "&nbsp;&nbsp;✅ $link<br>";
                } else {
                    echo "&nbsp;&nbsp;❌ $link (broken)<br>";
                    $errors[] = "Broken link in $page: $link";
                }
            }
        }
        echo "<br>";
    }
}

// 4. MySQL Query Format Check
echo "<h2>4. MySQL Sorgu Format Kontrolü</h2>";

function checkMySQLQueries($filepath) {
    if (!file_exists($filepath)) return [];
    
    $content = file_get_contents($filepath);
    $issues = [];
    
    // Check for PostgreSQL-specific syntax
    $postgresPatterns = [
        'SERIAL' => 'Should use AUTO_INCREMENT',
        'BOOLEAN' => 'Should use TINYINT(1)',
        'TEXT[]' => 'Should use JSON or separate table',
        'JSONB' => 'Should use JSON',
        '::' => 'PostgreSQL cast syntax not supported in MySQL'
    ];
    
    foreach ($postgresPatterns as $pattern => $suggestion) {
        if (strpos($content, $pattern) !== false) {
            $issues[] = "$pattern found - $suggestion";
        }
    }
    
    // Check for proper MySQL syntax
    if (strpos($content, 'AUTO_INCREMENT') !== false) {
        // Good MySQL syntax found
    }
    
    return $issues;
}

$phpFiles = glob('**/*.php', GLOB_BRACE);
$mysqlIssues = 0;

foreach ($phpFiles as $file) {
    $issues = checkMySQLQueries($file);
    if (!empty($issues)) {
        echo "<strong>$file:</strong><br>";
        foreach ($issues as $issue) {
            echo "&nbsp;&nbsp;⚠️ $issue<br>";
            $warnings[] = "$file: $issue";
            $mysqlIssues++;
        }
    }
}

if ($mysqlIssues === 0) {
    echo "✅ MySQL format kontrolleri temiz<br>";
}

// 5. JavaScript Function Check
echo "<h2>5. JavaScript Fonksiyon Kontrolü</h2>";

function checkJavaScriptFunctions($filepath) {
    if (!file_exists($filepath)) return [];
    
    $content = file_get_contents($filepath);
    $functions = [];
    
    // Find function definitions
    preg_match_all('/function\s+(\w+)\s*\(/', $content, $matches);
    if (!empty($matches[1])) {
        $functions = array_merge($functions, $matches[1]);
    }
    
    // Find onclick handlers
    preg_match_all('/onclick=["\']([^"\']+)["\']/', $content, $matches);
    if (!empty($matches[1])) {
        foreach ($matches[1] as $onclick) {
            preg_match('/(\w+)\s*\(/', $onclick, $funcMatch);
            if (!empty($funcMatch[1])) {
                $functions[] = $funcMatch[1] . ' (onclick)';
            }
        }
    }
    
    return array_unique($functions);
}

$pagesWithJS = [
    'admin/qr-generator.php',
    'qr/qr-reader.php',
    'admin/company-setup.php',
    'dashboard/company-dashboard.php'
];

foreach ($pagesWithJS as $page) {
    if (file_exists($page)) {
        $functions = checkJavaScriptFunctions($page);
        if (!empty($functions)) {
            echo "<strong>$page:</strong><br>";
            foreach ($functions as $func) {
                echo "&nbsp;&nbsp;🔧 $func<br>";
            }
            echo "<br>";
        }
    }
}

// 6. Summary Report
echo "<h2>6. Özet Rapor</h2>";

echo "<div style='background: #f0f0f0; padding: 15px; margin: 10px 0;'>";
echo "<strong>Toplam Hatalar:</strong> " . count($errors) . "<br>";
echo "<strong>Toplam Uyarılar:</strong> " . count($warnings) . "<br>";
echo "<strong>Kontrol Edilen Dosyalar:</strong> " . count($criticalFiles) . "<br>";
echo "</div>";

if (!empty($errors)) {
    echo "<h3>🔴 Kritik Hatalar:</h3>";
    foreach ($errors as $error) {
        echo "• $error<br>";
    }
}

if (!empty($warnings)) {
    echo "<h3>🟡 Uyarılar:</h3>";
    foreach ($warnings as $warning) {
        echo "• $warning<br>";
    }
}

echo "<h3>📋 Önerilen İşlemler:</h3>";
echo "1. Eksik dosyaları oluştur<br>";
echo "2. Bozuk linkleri düzelt<br>";
echo "3. MySQL format uyumluluğunu sağla<br>";
echo "4. JavaScript fonksiyonlarını test et<br>";
echo "5. Veritabanı tablolarını kontrol et<br>";

echo "<hr><p>Bitiş: " . date('Y-m-d H:i:s') . "</p>";

// Auto-fix suggestions
echo "<h3>🔧 Otomatik Düzeltme Araçları:</h3>";
echo "<a href='fix-all-links.php' style='background: #007cba; color: white; padding: 10px; text-decoration: none; margin: 5px; display: inline-block;'>Tüm Linkleri Düzelt</a>";
echo "<a href='fix-mysql-queries.php' style='background: #28a745; color: white; padding: 10px; text-decoration: none; margin: 5px; display: inline-block;'>MySQL Sorgularını Düzelt</a>";
echo "<a href='fix-javascript-functions.php' style='background: #ffc107; color: white; padding: 10px; text-decoration: none; margin: 5px; display: inline-block;'>JS Fonksiyonlarını Düzelt</a>";
echo "<a href='create-missing-files.php' style='background: #dc3545; color: white; padding: 10px; text-decoration: none; margin: 5px; display: inline-block;'>Eksik Dosyaları Oluştur</a>";
?>