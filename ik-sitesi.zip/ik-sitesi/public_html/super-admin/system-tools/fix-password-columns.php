<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Password Column Fix</h1>";
echo "<p>Düzeltme: 'password' kolonları 'password_hash' olarak güncelleniyor...</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div style='background: #f8f9fa; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; margin-bottom: 20px;'>";
    echo "<h3>🔍 Password Kolonu Düzeltme İşlemleri:</h3>";
    
    $fixCount = 0;
    $errorCount = 0;
    
    // Check if employees table has password column (it shouldn't)
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'password'");
        if ($stmt->fetch()) {
            echo "<div style='color: orange;'>⚠ employees tablosunda password kolonu bulundu - kaldırılıyor...</div>";
            $conn->exec("ALTER TABLE employees DROP COLUMN password");
            echo "<div style='color: green;'>✓ employees.password kolonu kaldırıldı</div>";
            $fixCount++;
        } else {
            echo "<div style='color: green;'>✓ employees tablosunda password kolonu yok (doğru)</div>";
        }
    } catch (Exception $e) {
        echo "<div style='color: red;'>❌ employees password kontrol hatası: " . $e->getMessage() . "</div>";
        $errorCount++;
    }
    
    // Check if users table has password_hash column
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM users LIKE 'password_hash'");
        if (!$stmt->fetch()) {
            echo "<div style='color: orange;'>⚠ users tablosunda password_hash kolonu yok - ekleniyor...</div>";
            $conn->exec("ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) NOT NULL AFTER email");
            echo "<div style='color: green;'>✓ users.password_hash kolonu eklendi</div>";
            $fixCount++;
        } else {
            echo "<div style='color: green;'>✓ users.password_hash kolonu mevcut (doğru)</div>";
        }
    } catch (Exception $e) {
        echo "<div style='color: red;'>❌ users password_hash kontrol hatası: " . $e->getMessage() . "</div>";
        $errorCount++;
    }
    
    // Check and rename old password column if exists
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM users LIKE 'password'");
        if ($stmt->fetch()) {
            echo "<div style='color: orange;'>⚠ users tablosunda eski 'password' kolonu bulundu - kaldırılıyor...</div>";
            
            // First check if we have data in password column
            $checkData = $conn->query("SELECT COUNT(*) as count FROM users WHERE password IS NOT NULL AND password != ''")->fetch();
            if ($checkData['count'] > 0) {
                echo "<div style='color: blue;'>📋 {$checkData['count']} kullanıcıda eski password verisi bulundu - taşınıyor...</div>";
                $conn->exec("UPDATE users SET password_hash = password WHERE password IS NOT NULL AND password != '' AND (password_hash IS NULL OR password_hash = '')");
                echo "<div style='color: green;'>✓ Eski password verileri password_hash'e taşındı</div>";
            }
            
            $conn->exec("ALTER TABLE users DROP COLUMN password");
            echo "<div style='color: green;'>✓ Eski users.password kolonu kaldırıldı</div>";
            $fixCount++;
        } else {
            echo "<div style='color: green;'>✓ users tablosunda eski password kolonu yok (doğru)</div>";
        }
    } catch (Exception $e) {
        echo "<div style='color: red;'>❌ users eski password kontrol hatası: " . $e->getMessage() . "</div>";
        $errorCount++;
    }
    
    echo "</div>";
    
    if ($errorCount === 0) {
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px;'>";
        echo "<h3>🎉 Password Kolonları Başarıyla Düzeltildi!</h3>";
        echo "<p><strong>Özet:</strong></p>";
        echo "<ul>";
        echo "<li>✓ $fixCount düzeltme yapıldı</li>";
        echo "<li>✓ users tablosu password_hash kolonu doğru</li>";
        echo "<li>✓ employees tablosunda password kolonu yok (doğru)</li>";
        echo "<li>✓ Tüm password işlemleri şimdi password_hash kullanıyor</li>";
        echo "</ul>";
        echo "<p><strong>Sonraki Adımlar:</strong></p>";
        echo "<ul>";
        echo "<li>Şirket kayıt sistemi artık çalışmalı</li>";
        echo "<li>Login işlemleri password_hash ile doğru çalışacak</li>";
        echo "<li>Eski password verileri korundu ve taşındı</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
        echo "<h3>⚠ Kısmi Düzeltme Tamamlandı</h3>";
        echo "<p><strong>Özet:</strong></p>";
        echo "<ul>";
        echo "<li>✓ $fixCount düzeltme başarılı</li>";
        echo "<li>❌ $errorCount hata oluştu</li>";
        echo "</ul>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Düzeltme Hatası</h3>";
    echo "<p><strong>Hata:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='admin/company-setup.php'>← Şirket Kayıt Sayfasına Dön</a></p>";
echo "<p><a href='database-overview.php'>📊 Veritabanı Durumunu Kontrol Et</a></p>";
?>