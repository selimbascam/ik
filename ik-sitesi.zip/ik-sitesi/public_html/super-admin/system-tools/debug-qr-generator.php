<?php
// Debug QR Generator issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>QR Generator Debug</h2>";

// Test basic PHP
echo "<p>✅ PHP working</p>";

// Test session
session_start();
echo "<p>✅ Session started</p>";

// Test includes
try {
    require_once 'includes/config.php';
    echo "<p>✅ Config loaded</p>";
} catch (Exception $e) {
    echo "<p>❌ Config error: " . $e->getMessage() . "</p>";
}

try {
    require_once 'includes/database.php';
    echo "<p>✅ Database class loaded</p>";
} catch (Exception $e) {
    echo "<p>❌ Database error: " . $e->getMessage() . "</p>";
}

// Test database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
    echo "<p>✅ Database connection successful</p>";
} catch (Exception $e) {
    echo "<p>❌ Database connection error: " . $e->getMessage() . "</p>";
}

// Test session variables
echo "<h3>Session Variables:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

// Test QR locations table
try {
    if (isset($conn)) {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>✅ QR locations table exists, records: " . $result['count'] . "</p>";
    }
} catch (Exception $e) {
    echo "<p>❌ QR locations table error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='admin/qr-generator-simple.php'>Test Simple QR Generator</a></p>";
echo "<p><a href='admin/qr-generator.php'>Test Original QR Generator</a></p>";
?>