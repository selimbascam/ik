<?php
echo "<h1>🔧 Tüm Sütun Hatalarını Düzelt</h1>";

// Get all PHP files
$files = [];
$directories = ['auth', 'api', 'admin', 'dashboard', 'qr', 'attendance', 'reports', 'employees', 'pages'];

foreach ($directories as $dir) {
    if (is_dir($dir)) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
        foreach ($iterator as $file) {
            if ($file->getExtension() === 'php') {
                $files[] = $file->getPathname();
            }
        }
    }
}

// Add root PHP files
$rootFiles = glob('*.php');
$files = array_merge($files, $rootFiles);

$fixes = [
    // Companies table fixes
    'c.name' => 'c.company_name',
    'c.name as company_name' => 'c.company_name',
    
    // Departments table fixes  
    'd.department_name' => 'd.name as department_name',
    
    // Other common issues
    'c.code' => 'c.company_code',
    'u.name' => 'u.first_name',
];

$totalFixes = 0;
$filesFixed = 0;

echo "<div style='margin-bottom: 20px;'>";
echo "<p>Kontrol edilecek dosya sayısı: " . count($files) . "</p>";
echo "</div>";

foreach ($files as $file) {
    if (!file_exists($file)) continue;
    
    $content = file_get_contents($file);
    $originalContent = $content;
    $fileChanges = [];
    
    foreach ($fixes as $wrong => $correct) {
        if (strpos($content, $wrong) !== false) {
            $content = str_replace($wrong, $correct, $content);
            $fileChanges[] = "$wrong → $correct";
        }
    }
    
    if ($content !== $originalContent) {
        file_put_contents($file, $content);
        $filesFixed++;
        $totalFixes += count($fileChanges);
        
        echo "<div style='background: #d4edda; padding: 10px; margin: 5px 0; border-left: 4px solid #28a745;'>";
        echo "<strong>✅ " . htmlspecialchars($file) . "</strong><br>";
        foreach ($fileChanges as $change) {
            echo "<small>• " . htmlspecialchars($change) . "</small><br>";
        }
        echo "</div>";
    }
}

echo "<div style='background: #e9ecef; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h2>📊 Düzeltme Özeti</h2>";
echo "<p><strong>Toplam dosya kontrol edildi:</strong> " . count($files) . "</p>";
echo "<p><strong>Düzeltilen dosya sayısı:</strong> " . $filesFixed . "</p>";
echo "<p><strong>Toplam düzeltme sayısı:</strong> " . $totalFixes . "</p>";
echo "</div>";

if ($totalFixes > 0) {
    echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 5px; border-left: 4px solid #bee5eb;'>";
    echo "<h3>✅ Tüm sütun hataları düzeltildi!</h3>";
    echo "<p>Artık 'Column not found' hataları görmeyeceksiniz.</p>";
    echo "</div>";
} else {
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; border-left: 4px solid #c3e6cb;'>";
    echo "<h3>✅ Hiç sütun hatası bulunamadı!</h3>";
    echo "<p>Tüm dosyalar zaten doğru sütun referansları kullanıyor.</p>";
    echo "</div>";
}

echo "<div style='text-align: center; margin: 20px 0;'>";
echo "<a href='auth/employee-login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 0 5px;'>🔍 Personel Girişi Test Et</a>";
echo "<a href='test-all-pages.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 0 5px;'>📋 Tüm Sayfaları Test Et</a>";
echo "</div>";
?>