<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>QR Generator Hata Debug</h2>";

// Test basic session
session_start();
echo "<p>✅ Session başlatıldı</p>";

// Test include files
try {
    require_once 'includes/config.php';
    echo "<p>✅ Config yüklendi</p>";
} catch (Exception $e) {
    echo "<p>❌ Config hatası: " . $e->getMessage() . "</p>";
}

try {
    require_once 'includes/database.php';
    echo "<p>✅ Database class yüklendi</p>";
} catch (Exception $e) {
    echo "<p>❌ Database hatası: " . $e->getMessage() . "</p>";
}

// Test database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
    echo "<p>✅ Database bağlantısı başarılı</p>";
    
    // Test qr_locations table
    $stmt = $conn->prepare("SHOW TABLES LIKE 'qr_locations'");
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        echo "<p>✅ qr_locations tablosu mevcut</p>";
        
        // Test table structure
        $stmt = $conn->prepare("DESCRIBE qr_locations");
        $stmt->execute();
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>Tablo Yapısı:</h3>";
        foreach ($columns as $col) {
            echo "<p>- {$col['Field']} ({$col['Type']})</p>";
        }
    } else {
        echo "<p>❌ qr_locations tablosu bulunamadı</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Database bağlantı hatası: " . $e->getMessage() . "</p>";
}

// Test session variables
echo "<h3>Session Değişkenleri:</h3>";
if (isset($_SESSION['company_id'])) {
    echo "<p>✅ company_id: " . $_SESSION['company_id'] . "</p>";
} else {
    echo "<p>❌ company_id bulunamadı</p>";
}

if (isset($_SESSION['user_id'])) {
    echo "<p>✅ user_id: " . $_SESSION['user_id'] . "</p>";
} else {
    echo "<p>❌ user_id bulunamadı</p>";
}

// Test form submission simulation
echo "<h3>Form Test:</h3>";
try {
    if ($conn) {
        // Test insert query
        $testQuery = "INSERT INTO qr_locations (company_id, name, qr_code, location_type, description, latitude, longitude, address, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())";
        $stmt = $conn->prepare($testQuery);
        echo "<p>✅ Insert query hazırlandı</p>";
        
        // Generate test QR code
        $qr_code = 'QR_TEST_' . date('YmdHis');
        echo "<p>✅ Test QR kod: {$qr_code}</p>";
        
    }
} catch (Exception $e) {
    echo "<p>❌ Form test hatası: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<p><a href='admin/qr-generator-clean.php'>QR Generator Clean Test</a></p>";
echo "<p><a href='admin/qr-generator.php'>Ana QR Generator Test</a></p>";
?>