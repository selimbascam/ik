<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Duplicate Employee Cleanup</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check for duplicate employee numbers
    echo "<h3>Duplicate Employee Numbers:</h3>";
    $stmt = $conn->prepare("
        SELECT company_id, employee_number, COUNT(*) as count 
        FROM employees 
        GROUP BY company_id, employee_number 
        HAVING COUNT(*) > 1
    ");
    $stmt->execute();
    $duplicates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($duplicates)) {
        echo "<p>No duplicate employee numbers found.</p>";
    } else {
        echo "<ul>";
        foreach ($duplicates as $dup) {
            echo "<li>Company {$dup['company_id']}, Employee {$dup['employee_number']}: {$dup['count']} records</li>";
        }
        echo "</ul>";
        
        // Show detailed duplicate records
        echo "<h3>Detailed Duplicate Records:</h3>";
        foreach ($duplicates as $dup) {
            echo "<h4>Company {$dup['company_id']}, Employee {$dup['employee_number']}:</h4>";
            $stmt = $conn->prepare("
                SELECT id, first_name, last_name, email, created_at, status 
                FROM employees 
                WHERE company_id = ? AND employee_number = ? 
                ORDER BY created_at
            ");
            $stmt->execute([$dup['company_id'], $dup['employee_number']]);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Created</th><th>Status</th><th>Action</th></tr>";
            
            $keepFirst = true;
            foreach ($records as $record) {
                echo "<tr>";
                echo "<td>{$record['id']}</td>";
                echo "<td>{$record['first_name']} {$record['last_name']}</td>";
                echo "<td>{$record['email']}</td>";
                echo "<td>{$record['created_at']}</td>";
                echo "<td>{$record['status']}</td>";
                
                if ($keepFirst) {
                    echo "<td><strong>KEEP (First)</strong></td>";
                    $keepFirst = false;
                } else {
                    echo "<td>";
                    echo "<form method='POST' style='display:inline;'>";
                    echo "<input type='hidden' name='delete_id' value='{$record['id']}'>";
                    echo "<button type='submit' onclick=\"return confirm('Delete this duplicate?')\">DELETE</button>";
                    echo "</form>";
                    echo "</td>";
                }
                echo "</tr>";
            }
            echo "</table><br>";
        }
    }
    
    // Handle deletion
    if ($_POST['delete_id'] ?? false) {
        $deleteId = (int)$_POST['delete_id'];
        $stmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
        $stmt->execute([$deleteId]);
        echo "<p style='color: green;'>Deleted employee record ID: $deleteId</p>";
        echo "<script>setTimeout(() => window.location.reload(), 1000);</script>";
    }
    
    // Show all employees for reference
    echo "<h3>All Employees (for reference):</h3>";
    $stmt = $conn->prepare("
        SELECT id, company_id, employee_number, first_name, last_name, email, status, created_at
        FROM employees 
        ORDER BY company_id, employee_number, created_at
    ");
    $stmt->execute();
    $all_employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Company</th><th>Emp#</th><th>Name</th><th>Email</th><th>Status</th><th>Created</th></tr>";
    foreach ($all_employees as $emp) {
        echo "<tr>";
        echo "<td>{$emp['id']}</td>";
        echo "<td>{$emp['company_id']}</td>";
        echo "<td>{$emp['employee_number']}</td>";
        echo "<td>{$emp['first_name']} {$emp['last_name']}</td>";
        echo "<td>{$emp['email']}</td>";
        echo "<td>{$emp['status']}</td>";
        echo "<td>{$emp['created_at']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?>

<br><br>
<a href="employees/list.php">← Back to Employee Management</a>