<?php
/**
 * ZORLA QR DAVRANIŞI DÜZELTİCİ - DEMO001 için özel
 */
require_once '../includes/config.php';
require_once '../includes/database.php';

$message = "";
$messageType = "info";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // DEMO001 şirketi ID'sini bul
    $stmt = $conn->prepare("SELECT id FROM companies WHERE company_code = 'DEMO001'");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        throw new Exception("DEMO001 şirketi bulunamadı!");
    }
    
    $companyId = $company['id'];
    
    // gate_behavior kolonu kontrolü
    $stmt = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'gate_behavior'");
    if ($stmt->rowCount() == 0) {
        $conn->exec("ALTER TABLE qr_locations ADD COLUMN gate_behavior VARCHAR(50) DEFAULT 'user_choice'");
        $message .= "✅ gate_behavior kolonu eklendi<br>";
    }
    
    // DEMO001'in tüm QR lokasyonlarını güncelle - ZORLA
    $updates = [
        'giriş' => 'work_start',
        'çıkış' => 'work_end', 
        'mola' => 'break_toggle',
        'mola giriş' => 'break_toggle',
        'entrance' => 'work_start',
        'exit' => 'work_end',
        'break' => 'break_toggle'
    ];
    
    $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ?");
    $stmt->execute([$companyId]);
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $fixCount = 0;
    foreach ($locations as $location) {
        $name = mb_strtolower(trim($location['name']), 'UTF-8');
        $newBehavior = 'user_choice';
        
        // Türkçe karakter temizliği
        $cleanName = str_replace(['İ', 'I', 'Ğ', 'Ü', 'Ş', 'Ö', 'Ç'], ['i', 'i', 'ğ', 'ü', 'ş', 'ö', 'ç'], $name);
        
        // Doğrudan eşleştirme
        foreach ($updates as $keyword => $behavior) {
            if (strpos($cleanName, $keyword) !== false) {
                $newBehavior = $behavior;
                break;
            }
        }
        
        // Güncelle
        $updateStmt = $conn->prepare("UPDATE qr_locations SET gate_behavior = ? WHERE id = ?");
        $updateStmt->execute([$newBehavior, $location['id']]);
        $fixCount++;
        
        $message .= "🔄 '{$location['name']}' → {$newBehavior}<br>";
    }
    
    $message .= "<br>✅ Toplam {$fixCount} lokasyon zorla güncellendi!";
    $messageType = "success";
    
    // Son kontrol
    $stmt = $conn->prepare("SELECT name, gate_behavior FROM qr_locations WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $final = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $message .= "<br><br><strong>SON DURUM:</strong><br>";
    foreach ($final as $loc) {
        $message .= "• {$loc['name']}: {$loc['gate_behavior']}<br>";
    }
    
} catch (Exception $e) {
    $message = "❌ Hata: " . $e->getMessage();
    $messageType = "error";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZORLA QR DÜZELTİCİ - SZB İK</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen p-8">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-2xl font-bold mb-4">🔧 ZORLA QR DAVRANIŞI DÜZELTİCİ</h1>
            
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800' : 
                    ($messageType === 'error' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'); 
            ?>">
                <?php echo $message; ?>
            </div>
            
            <div class="text-center space-y-4">
                <a href="../debug-qr-selim.php" target="_blank" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 inline-block">
                    🔍 Debug Raporu Görüntüle
                </a>
                
                <br>
                
                <a href="../qr/qr-reader.php" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 inline-block">
                    📱 QR Okuyucu Test Et
                </a>
                
                <br>
                
                <a href="./" class="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 inline-block">
                    ← Super Admin'e Dön
                </a>
            </div>
        </div>
    </div>
</body>
</html>