<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Session already started in config.php

// Handle logout
if (isset($_GET['logout'])) {
    unset($_SESSION['super_admin']);
    unset($_SESSION['user_email']);
    header('Location: /ik/super-admin/');
    exit;
}

// Simple super admin check (you can enhance this)
$superAdminPassword = 'SZB2025Admin!';
if (!isset($_SESSION['super_admin'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['admin_password'] === $superAdminPassword) {
        $_SESSION['super_admin'] = 1;
        $_SESSION['user_email'] = 'super@admin.com';
    } else {
        // Show login form
        ?>
        <!DOCTYPE html>
        <html lang="tr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Süper Admin Girişi - SZB İK Takip</title>
            <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body class="bg-gray-100 flex items-center justify-center min-h-screen">
            <div class="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
                <div class="text-center mb-6">
                    <div class="text-6xl mb-4">👋</div>
                    <h1 class="text-2xl font-bold">Süper Admin Girişi</h1>
                </div>
                <form method="POST">
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2">Admin Şifresi:</label>
                        <input type="password" name="admin_password" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-red-500" required placeholder="Şifrenizi girin">
                    </div>
                    <button type="submit" class="w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 font-medium">Giriş Yap</button>
                </form>

            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

// Handle actions
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        switch ($action) {
            case 'toggle_company_status':
                $companyId = $_POST['company_id'];
                $currentStatus = $_POST['current_status'];
                $newStatus = $currentStatus === 'active' ? 'inactive' : 'active';
                
                $stmt = $conn->prepare("UPDATE companies SET status = ? WHERE id = ?");
                $stmt->execute([$newStatus, $companyId]);
                
                $message = "Şirket durumu güncellendi: " . ($newStatus === 'active' ? 'Aktif' : 'Pasif');
                $messageType = 'success';
                break;
                
            case 'delete_company':
                $companyId = $_POST['company_id'];
                
                // Start transaction
                $conn->beginTransaction();
                
                // Delete related data
                $conn->prepare("DELETE FROM attendance_records WHERE employee_id IN (SELECT id FROM employees WHERE company_id = ?)")->execute([$companyId]);
                $conn->prepare("DELETE FROM employees WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM qr_locations WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM departments WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM users WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM companies WHERE id = ?")->execute([$companyId]);
                
                $conn->commit();
                
                $message = "Şirket ve tüm ilgili veriler silindi.";
                $messageType = 'success';
                break;
                
            case 'reset_company_data':
                $companyId = $_POST['company_id'];
                
                // Only delete attendance and employee data, keep company structure
                $conn->prepare("DELETE FROM attendance_records WHERE employee_id IN (SELECT id FROM employees WHERE company_id = ?)")->execute([$companyId]);
                $conn->prepare("DELETE FROM employees WHERE company_id = ?")->execute([$companyId]);
                
                $message = "Şirket verileri sıfırlandı (personel ve devam kayıtları silindi).";
                $messageType = 'success';
                break;
        }
        
    } catch (Exception $e) {
        $message = "Hata: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Get all companies with statistics
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Database columns are already fixed by database-fix.php

    $sql = "
        SELECT 
            c.*,
            COUNT(DISTINCT u.id) as admin_count,
            COUNT(DISTINCT e.id) as employee_count,
            COUNT(DISTINCT d.id) as department_count,
            COUNT(DISTINCT qr.id) as qr_location_count,
            COUNT(DISTINCT ar.id) as attendance_count,
            MAX(ar.created_at) as last_activity
        FROM companies c
        LEFT JOIN users u ON c.id = u.company_id
        LEFT JOIN employees e ON c.id = e.company_id
        LEFT JOIN departments d ON c.id = d.company_id
        LEFT JOIN qr_locations qr ON c.id = qr.company_id
        LEFT JOIN attendance_records ar ON e.id = ar.employee_id
        GROUP BY c.id
        ORDER BY c.created_at DESC
    ";
    
    $stmt = $conn->query($sql);
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $companies = [];
    $dbError = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Süper Admin Panel - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <h1 class="text-2xl font-bold text-gray-900">🏢 Süper Admin Panel</h1>
                <nav class="hidden md:flex space-x-4">
                    <a href="index.php" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Ana Sayfa</a>
                    <a href="system-health.php" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Sistem Durumu</a>
                    <a href="company-management.php" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Şirket Yönetimi</a>
                    <a href="../admin/company-setup.php" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Yeni Şirket</a>
                </nav>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">Toplam <?php echo count($companies); ?> Şirket</span>
                    <a href="?logout=1" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">Çıkış</a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Messages -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                    'bg-red-100 text-red-800 border border-red-200'; 
            ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- GÜNCELLE Button - Prominent Position -->
        <div class="mb-8">
            <a href="system-tools/system-update.php" class="block w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg shadow-lg hover:shadow-xl transition-all transform hover:scale-[1.02] p-6">
                <div class="flex items-center justify-center">
                    <span class="text-5xl mr-4">🔄</span>
                    <div class="text-left">
                        <h2 class="text-3xl font-bold mb-2">GÜNCELLE</h2>
                        <p class="text-blue-100 text-lg">Tüm sistem düzeltmelerini tek tıklamayla uygula</p>
                        <div class="mt-2 text-sm text-blue-200">
                            ✓ QR davranış düzeltme • ✓ MySQL uyumluluk • ✓ Tablo güncellemeleri • ✓ Sistem kontrolü
                        </div>
                    </div>
                </div>
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <?php
            $totalCompanies = count($companies);
            $activeCompanies = count(array_filter($companies, fn($c) => ($c['status'] ?? 'active') === 'active'));
            $totalEmployees = array_sum(array_column($companies, 'employee_count'));
            $totalAttendance = array_sum(array_column($companies, 'attendance_count'));
            ?>
            
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-blue-100 rounded-lg">
                        <span class="text-2xl">🏢</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Toplam Şirket</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo $totalCompanies; ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-green-100 rounded-lg">
                        <span class="text-2xl">✅</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Aktif Şirket</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo $activeCompanies; ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-purple-100 rounded-lg">
                        <span class="text-2xl">👥</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Toplam Personel</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo $totalEmployees; ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-orange-100 rounded-lg">
                        <span class="text-2xl">📊</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Toplam Kayıt</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo $totalAttendance; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-lg shadow mb-8">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Hızlı İşlemler</h2>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <a href="system-tools/system-update.php" class="bg-red-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-red-700 transition-colors text-center">
                        🔄 GÜNCELLE
                    </a>
                    <a href="error-management.php" class="bg-orange-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-orange-700 transition-colors text-center">
                        🛠️ Hata Yönetimi
                    </a>
                    <a href="system-tools/comprehensive-analysis.php" class="bg-green-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-green-700 transition-colors text-center">
                        📊 Sistem Analizi
                    </a>
                </div>
            </div>
        </div>

        <!-- System Tools Section -->
        <div class="bg-white rounded-lg shadow mb-8">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">🛠️ Sistem Araçları (Süper Admin)</h2>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                    <a href="error-management.php" class="bg-red-100 hover:bg-red-200 text-red-800 px-4 py-3 rounded-lg font-medium transition-colors text-center border-2 border-red-300">
                        🛠️ Hata Yönetim Sistemi
                    </a>
                    <a href="system-tools/comprehensive-analysis.php" class="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 px-4 py-3 rounded-lg font-medium transition-colors text-center">
                        📊 Tam Sistem Analizi
                    </a>
                    <a href="system-tools/qr-test.php" class="bg-green-100 hover:bg-green-200 text-green-800 px-4 py-3 rounded-lg font-medium transition-colors text-center">
                        📱 QR Kod Test
                    </a>
                    <a href="test-error-system.php" class="bg-purple-100 hover:bg-purple-200 text-purple-800 px-4 py-3 rounded-lg font-medium transition-colors text-center border-2 border-purple-300">
                        🧪 Hata Sistemi Test
                    </a>
                    <a href="fix-critical-errors.php" class="bg-red-100 hover:bg-red-200 text-red-800 px-4 py-3 rounded-lg font-medium transition-colors text-center border-2 border-red-300">
                        🔧 Kritik Hata Düzeltme
                    </a>
                    <a href="emergency-fix.php" class="bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-lg font-medium transition-colors text-center border-2 border-red-700">
                        🚨 Acil Sistem Onarımı
                    </a>
                </div>
                <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                        <h3 class="font-semibold text-green-800 mb-2">✅ Çalışan Araçlar</h3>
                        <ul class="text-sm text-green-700 space-y-1">
                            <li>• Hata Yönetim Sistemi (YENİ)</li>
                            <li>• Tam Sistem Analizi</li>
                            <li>• QR Kod Test</li>
                            <li>• Sistem Güncelleme</li>
                        </ul>
                    </div>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h3 class="font-semibold text-blue-800 mb-2">🚧 Geliştirme Aşamasında</h3>
                        <ul class="text-sm text-blue-700 space-y-1">
                            <li>• Otomatik Yedekleme Sistemi</li>
                            <li>• Kullanıcı Aktivite İzleme</li>
                            <li>• Gelişmiş Raporlama</li>
                            <li>• API Entegrasyonları</li>
                        </ul>
                    </div>
                </div>
                <div class="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p class="text-sm text-yellow-800">
                        <strong>⚠️ Dikkat:</strong> Bu araçlar sistem üzerinde değişiklik yapabilir. Yalnızca gerekli durumlarda kullanınız.
                    </p>
                </div>
            </div>
        </div>

        <!-- Companies Table -->
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Şirket Listesi</h2>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($companies)): ?>
                    <div class="p-6 text-center text-gray-500">
                        <?php if (isset($dbError)): ?>
                            <p class="text-red-600">Veritabanı Hatası: <?php echo htmlspecialchars($dbError); ?></p>
                        <?php else: ?>
                            <p>Henüz şirket eklenmemiş.</p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Şirket</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İstatistikler</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Son Aktivite</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($companies as $company): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center">
                                            <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                                                <span class="text-blue-600 font-bold text-lg">
                                                    <?php echo strtoupper(substr($company['company_code'] ?? $company['company_name'], 0, 2)); ?>
                                                </span>
                                            </div>
                                            <div>
                                                <div class="flex items-center space-x-2">
                                                    <div class="text-sm font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($company['company_name']); ?>
                                                    </div>
                                                    <span class="px-2 py-1 text-xs rounded-full <?php 
                                                        echo ($company['company_type'] ?? 'corporate') === 'individual' 
                                                            ? 'bg-green-100 text-green-800' 
                                                            : 'bg-blue-100 text-blue-800'; 
                                                    ?>">
                                                        <?php echo ($company['company_type'] ?? 'corporate') === 'individual' ? '👤 Gerçek' : '🏢 Tüzel'; ?>
                                                    </span>
                                                </div>
                                                <div class="text-sm text-gray-500">
                                                    Kod: <?php echo htmlspecialchars($company['company_code'] ?? 'N/A'); ?>
                                                </div>
                                                <div class="text-xs text-gray-400">
                                                    <?php echo htmlspecialchars($company['email'] ?? '-'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900">
                                        <div class="space-y-1">
                                            <div>👥 <span class="font-medium"><?php echo $company['employee_count']; ?></span> personel</div>
                                            <div>🏢 <span class="font-medium"><?php echo $company['department_count']; ?></span> departman</div>
                                            <div>📍 <span class="font-medium"><?php echo $company['qr_location_count']; ?></span> QR lokasyon</div>
                                            <div>📊 <span class="font-medium"><?php echo $company['attendance_count']; ?></span> devam kaydı</div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php if (($company['status'] ?? 'active') === 'active'): ?>
                                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                Aktif
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                Pasif
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-500">
                                        <?php if ($company['last_activity']): ?>
                                            <?php echo date('d.m.Y H:i', strtotime($company['last_activity'])); ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                        <div class="text-xs text-gray-400">
                                            Oluşturma: <?php echo date('d.m.Y', strtotime($company['created_at'] ?? 'now')); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 text-sm font-medium space-y-2">
                                        <div class="flex flex-wrap gap-2">
                                            <?php if ($company['company_code']): ?>
                                                <a href="../direct-switch.php?code=<?php echo urlencode($company['company_code']); ?>" 
                                                   class="bg-green-100 text-green-800 px-3 py-1 rounded text-xs hover:bg-green-200"
                                                   title="Direkt şirket geçişi">
                                                    🚀 Şirkete Geç
                                                </a>
                                                <a href="../auth/company-login.php?demo=<?php echo $company['company_code']; ?>" 
                                                   class="bg-blue-100 text-blue-800 px-3 py-1 rounded text-xs hover:bg-blue-200"
                                                   title="Normal giriş">
                                                    🔑 Normal Giriş
                                                </a>
                                            <?php endif; ?>
                                            
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="toggle_company_status">
                                                <input type="hidden" name="company_id" value="<?php echo $company['id']; ?>">
                                                <input type="hidden" name="current_status" value="<?php echo $company['status'] ?? 'active'; ?>">
                                                <button type="submit" 
                                                        class="bg-orange-100 text-orange-800 px-3 py-1 rounded text-xs hover:bg-orange-200"
                                                        onclick="return confirm('Şirket durumunu değiştirmek istediğinizden emin misiniz?')">
                                                    <?php echo ($company['status'] ?? 'active') === 'active' ? 'Pasifleştir' : 'Aktifleştir'; ?>
                                                </button>
                                            </form>
                                            
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="reset_company_data">
                                                <input type="hidden" name="company_id" value="<?php echo $company['id']; ?>">
                                                <button type="submit" 
                                                        class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded text-xs hover:bg-yellow-200"
                                                        onclick="return confirm('Şirket verilerini sıfırlamak istediğinizden emin misiniz? (Personel ve devam kayıtları silinecek)')">
                                                    Sıfırla
                                                </button>
                                            </form>
                                            
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="delete_company">
                                                <input type="hidden" name="company_id" value="<?php echo $company['id']; ?>">
                                                <button type="submit" 
                                                        class="bg-red-100 text-red-800 px-3 py-1 rounded text-xs hover:bg-red-200"
                                                        onclick="return confirm('Şirketi tamamen silmek istediğinizden emin misiniz? Bu işlem geri alınamaz!')">
                                                    Sil
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if (isset($_GET['logout'])): ?>
        <script>
        <?php session_destroy(); ?>
        window.location.href = '<?php echo $_SERVER['PHP_SELF']; ?>';
        </script>
    <?php endif; ?>
</body>
</html>