<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Super admin authentication check
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['super_admin'])) {
    header('Location: index.php');
    exit;
}

// Get system information
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Recent activities
    $recentActivitiesQuery = "
        SELECT 
            'attendance' as type,
            ar.created_at as timestamp,
            CONCAT(e.first_name, ' ', e.last_name) as employee_name,
            c.company_name,
            COALESCE(aa.activity_type, 'unknown') as activity_type,
            qr.name as location_name
        FROM attendance_records ar
        JOIN employees e ON ar.employee_id = e.id
        JOIN companies c ON e.company_id = c.id
        LEFT JOIN qr_locations qr ON ar.qr_location_id = qr.id
        LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id
        ORDER BY ar.created_at DESC
        LIMIT 50
    ";
    
    $stmt = $conn->query($recentActivitiesQuery);
    $recentActivities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // System stats
    $systemStats = [
        'database_size' => 'Hesaplanıyor...',
        'total_records' => 0,
        'disk_usage' => 'N/A',
        'php_version' => phpversion(),
        'mysql_version' => $conn->query("SELECT VERSION() as version")->fetch()['version'] ?? 'Unknown'
    ];
    
    // Count total records
    $tables = ['companies', 'users', 'employees', 'attendance_records', 'qr_locations', 'departments'];
    $totalRecords = 0;
    foreach ($tables as $table) {
        try {
            $count = $conn->query("SELECT COUNT(*) as count FROM $table")->fetch()['count'];
            $totalRecords += $count;
        } catch (Exception $e) {
            // Table might not exist
        }
    }
    $systemStats['total_records'] = $totalRecords;
    
} catch (Exception $e) {
    $error = $e->getMessage();
    $recentActivities = [];
    $systemStats = [];
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Logları - Süper Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="index.php" class="text-blue-600 hover:text-blue-700 mr-4">← Geri</a>
                    <h1 class="text-2xl font-bold text-gray-900">📋 Sistem Logları</h1>
                </div>
                <div class="text-sm text-gray-600">
                    Son güncelleme: <?php echo date('d.m.Y H:i:s'); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- System Info Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-blue-100 rounded-lg">
                        <span class="text-2xl">🗄️</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Toplam Kayıt</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo number_format($systemStats['total_records'] ?? 0); ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-green-100 rounded-lg">
                        <span class="text-2xl">🐘</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">PHP Sürümü</p>
                        <p class="text-lg font-semibold text-gray-900"><?php echo $systemStats['php_version'] ?? 'N/A'; ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-yellow-100 rounded-lg">
                        <span class="text-2xl">🗃️</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">MySQL Sürümü</p>
                        <p class="text-sm font-semibold text-gray-900"><?php echo substr($systemStats['mysql_version'] ?? 'N/A', 0, 10); ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="p-2 bg-purple-100 rounded-lg">
                        <span class="text-2xl">⚡</span>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm text-gray-600">Sistem Durumu</p>
                        <p class="text-lg font-semibold text-green-600">Çalışıyor</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Database Tables Status -->
        <div class="bg-white rounded-lg shadow mb-8">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Veritabanı Tabloları</h2>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <?php
                    $tables = [
                        'companies' => '🏢',
                        'users' => '👤',
                        'employees' => '👥',
                        'departments' => '🏬',
                        'qr_locations' => '📍',
                        'attendance_records' => '📊',
                        'leave_types' => '📝',
                        'employee_documents' => '📄'
                    ];
                    
                    foreach ($tables as $table => $icon) {
                        try {
                            $count = $conn->query("SELECT COUNT(*) as count FROM $table")->fetch()['count'];
                            $status = 'text-green-600';
                            $statusText = 'Aktif';
                        } catch (Exception $e) {
                            $count = 0;
                            $status = 'text-red-600';
                            $statusText = 'Hata';
                        }
                        
                        echo "<div class='bg-gray-50 p-4 rounded-lg'>
                                <div class='flex items-center justify-between'>
                                    <div class='flex items-center'>
                                        <span class='text-2xl mr-2'>$icon</span>
                                        <span class='font-medium'>$table</span>
                                    </div>
                                    <div class='text-right'>
                                        <div class='text-lg font-bold'>$count</div>
                                        <div class='text-xs $status'>$statusText</div>
                                    </div>
                                </div>
                            </div>";
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Recent Activities -->
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Son Aktiviteler</h2>
                <p class="text-sm text-gray-600">Son 50 sistem aktivitesi</p>
            </div>
            <div class="overflow-x-auto">
                <?php if (isset($error)): ?>
                    <div class="p-6 text-center text-red-600">
                        Veritabanı Hatası: <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php elseif (empty($recentActivities)): ?>
                    <div class="p-6 text-center text-gray-500">
                        Henüz aktivite kaydı bulunmuyor.
                    </div>
                <?php else: ?>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Zaman</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Personel</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Şirket</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aktivite</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lokasyon</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($recentActivities as $activity): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo date('d.m.Y H:i', strtotime($activity['timestamp'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <?php echo htmlspecialchars($activity['employee_name'] ?? '-'); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <?php echo htmlspecialchars($activity['company_name'] ?? '-'); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                        $activityType = $activity['activity_type'] ?? 'unknown';
                                        $activityIcons = [
                                            'checkin' => '🟢 Giriş',
                                            'checkout' => '🔴 Çıkış',
                                            'break_start' => '☕ Mola Başlangıcı',
                                            'break_end' => '⚡ Mola Bitişi',
                                            'lunch_start' => '🍽️ Yemek Başlangıcı',
                                            'lunch_end' => '🍽️ Yemek Bitişi'
                                        ];
                                        echo $activityIcons[$activityType] ?? '📊 ' . ucfirst($activityType);
                                        ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <?php echo htmlspecialchars($activity['location_name'] ?? '-'); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- System Commands -->
        <div class="mt-8 bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-lg font-medium text-gray-900">Sistem Komutları</h2>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <button onclick="refreshLogs()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                        🔄 Logları Yenile
                    </button>
                    <button onclick="clearCache()" class="bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700">
                        🧹 Cache Temizle
                    </button>
                    <button onclick="exportLogs()" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700">
                        📥 Logları Dışa Aktar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
    function refreshLogs() {
        window.location.reload();
    }
    
    function clearCache() {
        if (confirm('Cache temizlensin mi?')) {
            alert('Cache temizleme özelliği henüz implementasyonda.');
        }
    }
    
    function exportLogs() {
        alert('Log export özelliği geliştirilme aşamasında.');
    }
    </script>
</body>
</html>