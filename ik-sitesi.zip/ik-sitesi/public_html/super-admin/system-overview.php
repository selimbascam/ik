<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check super admin access
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'super_admin') {
    header('Location: ../auth/company-login.php');
    exit;
}

// System health check functions
function getSystemStats() {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $stats = [];
        
        // Companies count
        $stmt = $conn->query("SELECT COUNT(*) FROM companies WHERE is_active = 1");
        $stats['active_companies'] = $stmt->fetchColumn();
        
        // Total employees
        $stmt = $conn->query("SELECT COUNT(*) FROM employees WHERE status = 'active'");
        $stats['total_employees'] = $stmt->fetchColumn();
        
        // QR locations
        $stmt = $conn->query("SELECT COUNT(*) FROM qr_locations WHERE is_active = 1");
        $stats['qr_locations'] = $stmt->fetchColumn();
        
        // Today's attendance records
        $stmt = $conn->query("SELECT COUNT(*) FROM attendance_records WHERE DATE(check_in_time) = CURDATE()");
        $stats['todays_records'] = $stmt->fetchColumn();
        
        // This week's records
        $stmt = $conn->query("SELECT COUNT(*) FROM attendance_records WHERE YEARWEEK(check_in_time) = YEARWEEK(NOW())");
        $stats['week_records'] = $stmt->fetchColumn();
        
        return $stats;
    } catch (Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

function getRecentActivity() {
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        $stmt = $conn->prepare("
            SELECT 
                ar.check_in_time,
                e.first_name,
                e.last_name,
                e.employee_number,
                c.company_name,
                ql.name as location_name,
                aa.name as activity_name,
                aa.activity_type
            FROM attendance_records ar
            JOIN employees e ON ar.employee_id = e.id
            JOIN companies c ON e.company_id = c.id
            LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
            LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id
            ORDER BY ar.check_in_time DESC
            LIMIT 20
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

function getSystemErrors() {
    $errors = [];
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Check for employees without QR records
        $stmt = $conn->query("
            SELECT COUNT(*) FROM employees e 
            LEFT JOIN attendance_records ar ON e.id = ar.employee_id 
            WHERE ar.id IS NULL AND e.status = 'active'
        ");
        $noRecords = $stmt->fetchColumn();
        if ($noRecords > 0) {
            $errors[] = ['type' => 'warning', 'message' => "$noRecords personelin hiç devam kaydı yok"];
        }
        
        // Check for QR locations without records
        $stmt = $conn->query("
            SELECT COUNT(*) FROM qr_locations ql 
            LEFT JOIN attendance_records ar ON ql.id = ar.qr_location_id 
            WHERE ar.id IS NULL AND ql.is_active = 1
        ");
        $unusedQR = $stmt->fetchColumn();
        if ($unusedQR > 0) {
            $errors[] = ['type' => 'info', 'message' => "$unusedQR QR lokasyonu hiç kullanılmamış"];
        }
        
        // Check for missing work settings
        $stmt = $conn->query("
            SELECT COUNT(*) FROM companies c 
            LEFT JOIN work_settings ws ON c.id = ws.company_id 
            WHERE ws.id IS NULL AND c.is_active = 1
        ");
        $noSettings = $stmt->fetchColumn();
        if ($noSettings > 0) {
            $errors[] = ['type' => 'error', 'message' => "$noSettings şirketin çalışma ayarları eksik"];
        }
        
    } catch (Exception $e) {
        $errors[] = ['type' => 'error', 'message' => 'Sistem kontrol hatası: ' . $e->getMessage()];
    }
    
    return $errors;
}

// Load data
$stats = getSystemStats();
$recentActivity = getRecentActivity();
$systemErrors = getSystemErrors();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Genel Bakış - Süper Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">📊 Sistem Genel Bakış</h1>
                    <p class="text-gray-600 mt-2">Anlık sistem durumu ve istatistikler</p>
                </div>
                <div class="flex space-x-3">
                    <button onclick="window.location.reload()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        🔄 Yenile
                    </button>
                    <a href="workflow-tree.php" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">
                        🌳 İş Akış Ağacı
                    </a>
                    <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                        ← Ana Panel
                    </a>
                </div>
            </div>
        </div>

        <!-- System Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">🏢</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-2xl font-bold text-gray-900"><?php echo $stats['active_companies'] ?? 0; ?></h3>
                        <p class="text-sm text-gray-600">Aktif Şirket</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">👥</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-2xl font-bold text-gray-900"><?php echo $stats['total_employees'] ?? 0; ?></h3>
                        <p class="text-sm text-gray-600">Toplam Personel</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">📱</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-2xl font-bold text-gray-900"><?php echo $stats['qr_locations'] ?? 0; ?></h3>
                        <p class="text-sm text-gray-600">QR Lokasyon</p>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">⏰</span>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-2xl font-bold text-gray-900"><?php echo $stats['todays_records'] ?? 0; ?></h3>
                        <p class="text-sm text-gray-600">Bugünkü Kayıt</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- System Errors/Warnings -->
        <?php if (!empty($systemErrors)): ?>
        <div class="mb-8">
            <h2 class="text-xl font-bold text-gray-900 mb-4">⚠️ Sistem Uyarıları</h2>
            <div class="space-y-3">
                <?php foreach ($systemErrors as $error): ?>
                <div class="p-4 rounded-lg <?php 
                    echo $error['type'] === 'error' ? 'bg-red-100 border border-red-200 text-red-800' : 
                        ($error['type'] === 'warning' ? 'bg-yellow-100 border border-yellow-200 text-yellow-800' : 
                        'bg-blue-100 border border-blue-200 text-blue-800'); 
                ?>">
                    <div class="flex items-center">
                        <div class="text-xl mr-3">
                            <?php echo $error['type'] === 'error' ? '❌' : ($error['type'] === 'warning' ? '⚠️' : 'ℹ️'); ?>
                        </div>
                        <div><?php echo htmlspecialchars($error['message']); ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Recent Activity -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div class="bg-white rounded-lg shadow-md">
                <div class="p-6 border-b border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900">📋 Son Aktiviteler</h2>
                    <p class="text-gray-600 text-sm mt-1">Son 20 devam kaydı</p>
                </div>
                <div class="p-6">
                    <?php if (empty($recentActivity)): ?>
                        <div class="text-center text-gray-500 py-8">
                            <div class="text-4xl mb-4">📭</div>
                            <p>Henüz aktivite kaydı yok</p>
                        </div>
                    <?php else: ?>
                        <div class="space-y-3 max-h-96 overflow-y-auto">
                            <?php foreach ($recentActivity as $activity): ?>
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div class="flex items-center space-x-3">
                                    <div class="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center">
                                        <span class="text-sm">
                                            <?php echo $activity['activity_type'] === 'work_in' ? '🏢' : 
                                                     ($activity['activity_type'] === 'work_out' ? '🚪' : 
                                                     ($activity['activity_type'] === 'break_start' ? '☕' : '⏰')); ?>
                                        </span>
                                    </div>
                                    <div>
                                        <div class="font-medium text-gray-900">
                                            <?php echo htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo htmlspecialchars($activity['company_name']); ?> - 
                                            <?php echo htmlspecialchars($activity['activity_name'] ?? 'Bilinmeyen Aktivite'); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-right text-sm text-gray-500">
                                    <?php echo date('H:i', strtotime($activity['check_in_time'])); ?><br>
                                    <?php echo date('d.m', strtotime($activity['check_in_time'])); ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- System Status -->
            <div class="bg-white rounded-lg shadow-md">
                <div class="p-6 border-b border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900">⚙️ Sistem Durumu</h2>
                    <p class="text-gray-600 text-sm mt-1">Kritik bileşenlerin durumu</p>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <div class="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                                    <span class="text-green-600">✅</span>
                                </div>
                                <div>
                                    <div class="font-medium text-gray-900">Veritabanı Bağlantısı</div>
                                    <div class="text-sm text-gray-500">MySQL aktif ve çalışıyor</div>
                                </div>
                            </div>
                            <div class="text-green-600 font-medium">Aktif</div>
                        </div>
                        
                        <div class="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                    <span class="text-blue-600">📱</span>
                                </div>
                                <div>
                                    <div class="font-medium text-gray-900">QR Kod Sistemi</div>
                                    <div class="text-sm text-gray-500">QR okuma ve oluşturma aktif</div>
                                </div>
                            </div>
                            <div class="text-blue-600 font-medium">Çalışıyor</div>
                        </div>
                        
                        <div class="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                                    <span class="text-purple-600">⏰</span>
                                </div>
                                <div>
                                    <div class="font-medium text-gray-900">Devam Takip</div>
                                    <div class="text-sm text-gray-500">Personel takip sistemi aktif</div>
                                </div>
                            </div>
                            <div class="text-purple-600 font-medium">Aktif</div>
                        </div>
                        
                        <div class="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                                    <span class="text-yellow-600">📊</span>
                                </div>
                                <div>
                                    <div class="font-medium text-gray-900">Raporlama</div>
                                    <div class="text-sm text-gray-500">Haftalık: <?php echo $stats['week_records'] ?? 0; ?> kayıt</div>
                                </div>
                            </div>
                            <div class="text-yellow-600 font-medium">Çalışıyor</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="mt-8">
            <h2 class="text-xl font-bold text-gray-900 mb-4">🚀 Hızlı İşlemler</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <a href="../direct-table-setup.php" target="_blank" class="bg-red-600 text-white p-4 rounded-lg text-center hover:bg-red-700 transition-colors">
                    <div class="text-2xl mb-2">🔧</div>
                    <div class="font-medium">Eksik Tabloları Oluştur</div>
                </a>
                
                <a href="../admin/company-setup.php" target="_blank" class="bg-blue-600 text-white p-4 rounded-lg text-center hover:bg-blue-700 transition-colors">
                    <div class="text-2xl mb-2">🏢</div>
                    <div class="font-medium">Yeni Şirket Ekle</div>
                </a>
                
                <a href="../test-qr-functions.php" target="_blank" class="bg-purple-600 text-white p-4 rounded-lg text-center hover:bg-purple-700 transition-colors">
                    <div class="text-2xl mb-2">🧪</div>
                    <div class="font-medium">QR Sistem Test</div>
                </a>
                
                <a href="../reports/system-report.php" target="_blank" class="bg-green-600 text-white p-4 rounded-lg text-center hover:bg-green-700 transition-colors">
                    <div class="text-2xl mb-2">📈</div>
                    <div class="font-medium">Sistem Raporu</div>
                </a>
            </div>
        </div>
    </div>

    <script>
    // Auto-refresh every 30 seconds
    setInterval(function() {
        window.location.reload();
    }, 30000);
    
    // Display current time
    function updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('tr-TR');
        document.title = `📊 Sistem Genel Bakış (${timeString})`;
    }
    
    updateTime();
    setInterval(updateTime, 1000);
    </script>
</body>
</html>