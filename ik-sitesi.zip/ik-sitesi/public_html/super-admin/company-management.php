<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check super admin access
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'super_admin') {
    header('Location: ../auth/company-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $success = '';
    $error = '';
    
    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'add_company') {
            try {
                // Validate required fields
                $companyName = trim($_POST['company_name'] ?? '');
                $companyCode = trim($_POST['company_code'] ?? '');
                $adminEmail = trim($_POST['admin_email'] ?? '');
                $adminPassword = trim($_POST['admin_password'] ?? '');
                
                if (empty($companyName) || empty($companyCode) || empty($adminEmail) || empty($adminPassword)) {
                    throw new Exception("Şirket adı, kod, yönetici e-posta ve şifre zorunludur.");
                }
                
                // Check if company code exists
                $checkStmt = $conn->prepare("SELECT id FROM companies WHERE company_code = ?");
                $checkStmt->execute([$companyCode]);
                if ($checkStmt->fetch()) {
                    throw new Exception("Bu şirket kodu zaten kullanılıyor.");
                }
                
                // Check if admin email exists
                $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
                $checkStmt->execute([$adminEmail]);
                if ($checkStmt->fetch()) {
                    throw new Exception("Bu e-posta adresi zaten kullanılıyor.");
                }
                
                // Start transaction
                $conn->beginTransaction();
                
                // Insert company
                $stmt = $conn->prepare("
                    INSERT INTO companies (
                        company_name, company_code, address, phone, email, 
                        tax_number, company_type, status, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())
                ");
                $stmt->execute([
                    $companyName,
                    $companyCode,
                    $_POST['address'] ?? '',
                    $_POST['phone'] ?? '',
                    $_POST['company_email'] ?? '',
                    $_POST['tax_number'] ?? '',
                    $_POST['company_type'] ?? 'corporate'
                ]);
                
                $companyId = $conn->lastInsertId();
                
                // Insert admin user
                $stmt = $conn->prepare("
                    INSERT INTO users (
                        company_id, email, password_hash, role, first_name, last_name, 
                        is_active, created_at
                    ) VALUES (?, ?, SHA2(?, 256), 'admin', ?, ?, 1, NOW())
                ");
                $stmt->execute([
                    $companyId,
                    $adminEmail,
                    $adminPassword,
                    $_POST['admin_first_name'] ?? 'Admin',
                    $_POST['admin_last_name'] ?? 'User'
                ]);
                
                // Create default departments
                $stmt = $conn->prepare("
                    INSERT INTO departments (company_id, name, description, is_active, created_at) 
                    VALUES 
                    (?, 'İnsan Kaynakları', 'İK Departmanı', 1, NOW()),
                    (?, 'Genel Müdürlük', 'Yönetim Departmanı', 1, NOW()),
                    (?, 'Operasyon', 'Operasyon Departmanı', 1, NOW())
                ");
                $stmt->execute([$companyId, $companyId, $companyId]);
                
                // Create default work settings
                $stmt = $conn->prepare("
                    INSERT INTO work_settings (
                        company_id, monthly_hours_limit, weekly_hours_limit, daily_hours_limit,
                        overtime_multiplier, weekend_multiplier, holiday_multiplier,
                        created_at
                    ) VALUES (?, 225, 45, 8, 1.5, 2.0, 2.5, NOW())
                ");
                $stmt->execute([$companyId]);
                
                $conn->commit();
                $success = "Şirket başarıyla oluşturuldu. Şirket ID: {$companyId}";
                
            } catch (Exception $e) {
                $conn->rollBack();
                $error = "Hata: " . $e->getMessage();
            }
        }
        
        if ($action === 'update_company') {
            try {
                $stmt = $conn->prepare("
                    UPDATE companies SET 
                        company_name = ?, address = ?, phone = ?, email = ?, 
                        tax_number = ?, company_type = ?, status = ?, updated_at = NOW()
                    WHERE id = ?
                ");
                $stmt->execute([
                    $_POST['company_name'],
                    $_POST['address'],
                    $_POST['phone'],
                    $_POST['email'],
                    $_POST['tax_number'],
                    $_POST['company_type'],
                    $_POST['status'],
                    $_POST['company_id']
                ]);
                $success = "Şirket bilgileri güncellendi.";
            } catch (Exception $e) {
                $error = "Güncelleme hatası: " . $e->getMessage();
            }
        }
        
        if ($action === 'delete_company') {
            try {
                $companyId = $_POST['company_id'];
                
                // Start transaction for cascade delete
                $conn->beginTransaction();
                
                // Delete related data first
                $conn->prepare("DELETE FROM attendance_records WHERE employee_id IN (SELECT id FROM employees WHERE company_id = ?)")->execute([$companyId]);
                $conn->prepare("DELETE FROM employee_shifts WHERE employee_id IN (SELECT id FROM employees WHERE company_id = ?)")->execute([$companyId]);
                $conn->prepare("DELETE FROM leave_requests WHERE employee_id IN (SELECT id FROM employees WHERE company_id = ?)")->execute([$companyId]);
                $conn->prepare("DELETE FROM employees WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM departments WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM users WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM qr_locations WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM work_settings WHERE company_id = ?")->execute([$companyId]);
                $conn->prepare("DELETE FROM companies WHERE id = ?")->execute([$companyId]);
                
                $conn->commit();
                $success = "Şirket ve tüm verileri silindi.";
            } catch (Exception $e) {
                $conn->rollBack();
                $error = "Silme hatası: " . $e->getMessage();
            }
        }
    }
    
    // Get all companies with statistics
    $stmt = $conn->prepare("
        SELECT 
            c.*,
            COALESCE(u.user_count, 0) as user_count,
            COALESCE(e.employee_count, 0) as employee_count,
            COALESCE(d.department_count, 0) as department_count
        FROM companies c
        LEFT JOIN (
            SELECT company_id, COUNT(*) as user_count 
            FROM users 
            WHERE COALESCE(is_active, 1) = 1 
            GROUP BY company_id
        ) u ON c.id = u.company_id
        LEFT JOIN (
            SELECT company_id, COUNT(*) as employee_count 
            FROM employees 
            WHERE COALESCE(status, 'active') = 'active' 
            GROUP BY company_id
        ) e ON c.id = e.company_id
        LEFT JOIN (
            SELECT company_id, COUNT(*) as department_count 
            FROM departments 
            WHERE COALESCE(is_active, 1) = 1 
            GROUP BY company_id
        ) d ON c.id = d.company_id
        ORDER BY c.created_at DESC
    ");
    $stmt->execute();
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Veritabanı hatası: " . $e->getMessage();
    $companies = [];
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Yönetimi - SZB İK Takip</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: #f8fafc;
            color: #1e293b;
            line-height: 1.6;
        }
        
        .header {
            background: white;
            padding: 1rem 2rem;
            border-bottom: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            color: #1e40af;
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .back-link {
            color: #6366f1;
            text-decoration: none;
            font-size: 0.9rem;
            margin-top: 0.5rem;
            display: inline-block;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            font-weight: 500;
        }
        
        .alert.success {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }
        
        .alert.error {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .card h2 {
            color: #1e40af;
            font-size: 1.25rem;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            font-weight: 500;
            color: #374151;
            margin-bottom: 0.5rem;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 0.9rem;
            transition: border-color 0.2s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s;
        }
        
        .btn-primary {
            background: #2563eb;
            color: white;
        }
        
        .btn-primary:hover {
            background: #1d4ed8;
        }
        
        .btn-danger {
            background: #dc2626;
            color: white;
        }
        
        .btn-danger:hover {
            background: #b91c1c;
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #4b5563;
        }
        
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .table th,
        .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table th {
            background: #f9fafb;
            font-weight: 600;
            color: #374151;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-active {
            background: #dcfce7;
            color: #166534;
        }
        
        .status-inactive {
            background: #fef2f2;
            color: #dc2626;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 8px;
            padding: 1rem;
            border-left: 4px solid #2563eb;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: #1e40af;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.9rem;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 12px;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .modal-header h3 {
            color: #1e40af;
            margin: 0;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #6b7280;
        }
        
        .actions {
            display: flex;
            gap: 0.5rem;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 0 0.5rem;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .table {
                font-size: 0.8rem;
            }
            
            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🏢 Şirket Yönetimi</h1>
        <small>Tüm şirketlerin yönetimi ve kontrolü</small>
        <br>
        <a href="../super-admin/dashboard.php" class="back-link">← Super Admin'e Dön</a>
    </div>

    <div class="container">
        <?php if ($success): ?>
            <div class="alert success">✅ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= count($companies) ?></div>
                <div class="stat-label">Toplam Şirket</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= array_sum(array_column($companies, 'user_count')) ?></div>
                <div class="stat-label">Toplam Kullanıcı</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= array_sum(array_column($companies, 'employee_count')) ?></div>
                <div class="stat-label">Toplam Personel</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= count(array_filter($companies, fn($c) => $c['status'] === 'active')) ?></div>
                <div class="stat-label">Aktif Şirket</div>
            </div>
        </div>

        <!-- Add New Company -->
        <div class="card">
            <h2>➕ Yeni Şirket Ekle</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add_company">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Şirket Adı *</label>
                        <input type="text" name="company_name" required>
                    </div>
                    <div class="form-group">
                        <label>Şirket Kodu *</label>
                        <input type="text" name="company_code" required placeholder="ÖRN: ABC123">
                    </div>
                    <div class="form-group">
                        <label>Şirket Türü</label>
                        <select name="company_type">
                            <option value="corporate">Kurumsal</option>
                            <option value="individual">Bireysel</option>
                            <option value="partnership">Ortaklık</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Vergi Numarası</label>
                        <input type="text" name="tax_number">
                    </div>
                    <div class="form-group">
                        <label>Telefon</label>
                        <input type="text" name="phone">
                    </div>
                    <div class="form-group">
                        <label>Şirket E-posta</label>
                        <input type="email" name="company_email">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <textarea name="address" rows="2"></textarea>
                </div>
                
                <h3 style="margin: 1.5rem 0 1rem; color: #1e40af;">Admin Kullanıcı Bilgileri</h3>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Admin E-posta *</label>
                        <input type="email" name="admin_email" required>
                    </div>
                    <div class="form-group">
                        <label>Admin Şifre *</label>
                        <input type="password" name="admin_password" required>
                    </div>
                    <div class="form-group">
                        <label>Admin Adı</label>
                        <input type="text" name="admin_first_name" value="Admin">
                    </div>
                    <div class="form-group">
                        <label>Admin Soyadı</label>
                        <input type="text" name="admin_last_name" value="User">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">➕ Şirket Oluştur</button>
            </form>
        </div>

        <!-- Companies List -->
        <div class="card">
            <h2>📋 Şirket Listesi</h2>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Şirket Adı</th>
                            <th>Kod</th>
                            <th>Tür</th>
                            <th>Durum</th>
                            <th>Kullanıcı</th>
                            <th>Personel</th>
                            <th>Departman</th>
                            <th>Oluşturma</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($companies as $company): ?>
                            <tr>
                                <td><?= htmlspecialchars($company['id'] ?? '') ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($company['company_name'] ?? '') ?></strong>
                                    <?php if (!empty($company['email'])): ?>
                                        <br><small style="color: #6b7280;"><?= htmlspecialchars($company['email']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><code><?= htmlspecialchars($company['company_code'] ?? '') ?></code></td>
                                <td><?= htmlspecialchars($company['company_type'] ?? 'corporate') ?></td>
                                <td>
                                    <span class="status-badge <?= ($company['status'] ?? 'active') === 'active' ? 'status-active' : 'status-inactive' ?>">
                                        <?= ($company['status'] ?? 'active') === 'active' ? 'Aktif' : 'Pasif' ?>
                                    </span>
                                </td>
                                <td><?= (int)($company['user_count'] ?? 0) ?></td>
                                <td><?= (int)($company['employee_count'] ?? 0) ?></td>
                                <td><?= (int)($company['department_count'] ?? 0) ?></td>
                                <td>
                                    <?php if (!empty($company['created_at'])): ?>
                                        <small><?= date('d.m.Y', strtotime($company['created_at'])) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="btn btn-secondary" onclick="editCompany(<?= htmlspecialchars(json_encode($company)) ?>)">✏️</button>
                                        <button class="btn btn-danger" onclick="deleteCompany(<?= $company['id'] ?>, '<?= htmlspecialchars($company['company_name'] ?? '') ?>')">🗑️</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <?php if (empty($companies)): ?>
                            <tr>
                                <td colspan="10" style="text-align: center; padding: 2rem; color: #6b7280;">
                                    Henüz şirket eklenmemiş
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit Company Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Şirket Düzenle</h3>
                <button class="close" onclick="closeEditModal()">&times;</button>
            </div>
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="update_company">
                <input type="hidden" name="company_id" id="edit_company_id">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Şirket Adı</label>
                        <input type="text" name="company_name" id="edit_company_name" required>
                    </div>
                    <div class="form-group">
                        <label>Şirket Türü</label>
                        <select name="company_type" id="edit_company_type">
                            <option value="corporate">Kurumsal</option>
                            <option value="individual">Bireysel</option>
                            <option value="partnership">Ortaklık</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Durum</label>
                        <select name="status" id="edit_status">
                            <option value="active">Aktif</option>
                            <option value="inactive">Pasif</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Telefon</label>
                        <input type="text" name="phone" id="edit_phone">
                    </div>
                    <div class="form-group">
                        <label>E-posta</label>
                        <input type="email" name="email" id="edit_email">
                    </div>
                    <div class="form-group">
                        <label>Vergi Numarası</label>
                        <input type="text" name="tax_number" id="edit_tax_number">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Adres</label>
                    <textarea name="address" id="edit_address" rows="3"></textarea>
                </div>
                
                <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                    <button type="submit" class="btn btn-primary">💾 Güncelle</button>
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">İptal</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function editCompany(company) {
            document.getElementById('edit_company_id').value = company.id || '';
            document.getElementById('edit_company_name').value = company.company_name || '';
            document.getElementById('edit_company_type').value = company.company_type || 'corporate';
            document.getElementById('edit_status').value = company.status || 'active';
            document.getElementById('edit_phone').value = company.phone || '';
            document.getElementById('edit_email').value = company.email || '';
            document.getElementById('edit_tax_number').value = company.tax_number || '';
            document.getElementById('edit_address').value = company.address || '';
            
            document.getElementById('editModal').style.display = 'block';
        }
        
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        function deleteCompany(companyId, companyName) {
            if (confirm(`"${companyName}" şirketini ve tüm verilerini silmek istediğinizden emin misiniz?\n\nBu işlem geri alınamaz!`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete_company">
                    <input type="hidden" name="company_id" value="${companyId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Close modal when clicking outside
        document.getElementById('editModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeEditModal();
            }
        });
        
        // Generate company code
        function generateCompanyCode() {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            const numbers = '0123456789';
            let result = '';
            
            // 3 letters
            for (let i = 0; i < 3; i++) {
                result += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            
            // 3 numbers
            for (let i = 0; i < 3; i++) {
                result += numbers.charAt(Math.floor(Math.random() * numbers.length));
            }
            
            return result;
        }
        
        // Add generate button functionality if needed
        document.addEventListener('DOMContentLoaded', function() {
            const codeInput = document.querySelector('input[name="company_code"]');
            if (codeInput && !codeInput.value) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.textContent = '🎲 Üret';
                btn.className = 'btn btn-secondary';
                btn.style.marginLeft = '0.5rem';
                btn.onclick = () => {
                    codeInput.value = generateCompanyCode();
                };
                codeInput.parentNode.appendChild(btn);
            }
        });
    </script>
</body>
</html>