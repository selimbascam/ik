<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (!isset($_SESSION['super_admin'])) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Durumu - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 py-6">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Sistem Durumu</h1>
                    <a href="index.php" class="text-blue-600 hover:text-blue-800">← Süper Admin'e Dön</a>
                </div>
            </div>
        </header>

        <main class="max-w-7xl mx-auto px-4 py-8">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="text-center py-12">
                    <div class="text-6xl mb-4">⚡</div>
                    <h2 class="text-xl font-semibold mb-2">Sistem Durumu</h2>
                    <p class="text-gray-600 mb-6">Sistem performansı ve sağlık durumu</p>
                    <div class="text-sm text-gray-500">Bu özellik yakında aktif olacak</div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>