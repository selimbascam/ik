<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Super admin authentication check
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in as super admin OR has admin access
$isSuperAdmin = isset($_SESSION['super_admin']) && $_SESSION['super_admin'] === 1;
$isLoggedInAdmin = isset($_SESSION['user_email']) && $_SESSION['user_email'] === 'super@admin.com';

if (!$isSuperAdmin && !$isLoggedInAdmin) {
    header('Location: index.php?error=access_denied');
    exit;
}

// Get company code from URL
$companyCode = $_GET['code'] ?? '';

if (empty($companyCode)) {
    header('Location: index.php?error=invalid_company');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Find company and admin user
    $stmt = $conn->prepare("
        SELECT c.*, u.id as admin_id, u.email as admin_email, u.password as admin_password 
        FROM companies c 
        JOIN users u ON c.id = u.company_id 
        WHERE c.company_code = ? AND u.role = 'admin' 
        LIMIT 1
    ");
    $stmt->execute([$companyCode]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
        header('Location: index.php?error=company_not_found');
        exit;
    }
    
    // Keep super admin session but add company access
    // Don't unset all sessions - keep super admin flag
    
    // Set super admin bypass flag
    $_SESSION['super_admin_bypass'] = 1;
    $_SESSION['original_super_admin'] = 1;
    $_SESSION['super_admin'] = 1; // Keep super admin access
    
    // Set company session data
    $_SESSION['company_id'] = $company['id'];
    $_SESSION['company_code'] = $company['company_code'];
    $_SESSION['company_name'] = $company['company_name'];
    $_SESSION['user_id'] = $company['admin_id'];
    $_SESSION['user_email'] = $company['admin_email'];
    $_SESSION['user_role'] = 'admin';
    $_SESSION['user_name'] = 'Admin (' . $company['company_name'] . ')';
    $_SESSION['logged_in'] = 1;
    
    // Redirect to company dashboard
    header('Location: ../dashboard/company-dashboard.php');
    exit;
    
} catch (Exception $e) {
    header('Location: index.php?error=' . urlencode($e->getMessage()));
    exit;
}
?>