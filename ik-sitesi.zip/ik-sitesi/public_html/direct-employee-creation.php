<?php
// Direct employee creation script
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "Direct Employee Creation Script\n";
echo "==============================\n";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // First show current employees
    echo "Current employees:\n";
    $existing = $conn->query("SELECT employee_number, first_name, last_name FROM employees ORDER BY id")->fetchAll();
    foreach ($existing as $emp) {
        echo "- {$emp['employee_number']} - {$emp['first_name']} {$emp['last_name']}\n";
    }
    echo "\n";
    
    // Check if target employee exists
    $check = $conn->prepare("SELECT id FROM employees WHERE employee_number = ?");
    $check->execute(['30716129672']);
    
    if ($check->fetch()) {
        echo "Employee 30716129672 already exists\n";
    } else {
        echo "Creating employee 30716129672...\n";
        
        // Create the employee
        $stmt = $conn->prepare("
            INSERT INTO employees (employee_number, first_name, last_name, password, company_id, status, is_active) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $hashedPassword = password_hash('123456', PASSWORD_DEFAULT);
        $result = $stmt->execute(['30716129672', 'Test', 'Personel', $hashedPassword, 1, 'active', 1]);
        
        if ($result) {
            echo "SUCCESS: Employee 30716129672 created!\n";
            echo "Login credentials:\n";
            echo "- Employee Number: 30716129672\n";
            echo "- Password: 123456\n";
        } else {
            echo "FAILED to create employee\n";
        }
    }
    
    echo "\nFinal employee list:\n";
    $final = $conn->query("SELECT employee_number, first_name, last_name FROM employees ORDER BY id")->fetchAll();
    foreach ($final as $emp) {
        echo "- {$emp['employee_number']} - {$emp['first_name']} {$emp['last_name']}\n";
    }
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    
    // Show table structure for debugging
    try {
        echo "\nEmployee table structure:\n";
        $columns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll();
        foreach ($columns as $col) {
            $required = ($col['Null'] == 'NO') ? 'REQUIRED' : 'optional';
            echo "- {$col['Field']} ({$col['Type']}) - {$required}\n";
        }
    } catch (Exception $e2) {
        echo "Could not show table structure: " . $e2->getMessage() . "\n";
    }
}

echo "\nScript completed.\n";
?>