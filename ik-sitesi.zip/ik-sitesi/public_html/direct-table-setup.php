<!DOCTYPE html>
<html>
<head>
    <title>Database Table Setup</title>
</head>
<body>
    <h1>Creating Missing Database Tables</h1>
    
<?php
// Direct connection to production database
$servername = "localhost";
$username = "u978874874_ik";
$password = "Szb2013@+-!";
$dbname = "u978874874_ik";

try {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo "<p>✅ Connected to database successfully</p>";

    // 1. Create work_settings table
    $sql = "CREATE TABLE IF NOT EXISTS work_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        monthly_hours_limit INT DEFAULT 225,
        weekly_hours_limit INT DEFAULT 45,
        daily_hours_limit INT DEFAULT 11,
        overtime_multiplier DECIMAL(3,2) DEFAULT 1.50,
        holiday_multiplier DECIMAL(3,2) DEFAULT 2.00,
        is_automatic_schedule TINYINT(1) DEFAULT 1,
        hourly_wage DECIMAL(10,2) DEFAULT 50.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_company_id (company_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    if ($conn->query($sql) === TRUE) {
        echo "<p>✅ work_settings table created successfully</p>";
        
        // Insert default data
        $check = $conn->query("SELECT COUNT(*) as count FROM work_settings WHERE company_id = 1");
        $row = $check->fetch_assoc();
        if ($row['count'] == 0) {
            $insert = "INSERT INTO work_settings (company_id, monthly_hours_limit, weekly_hours_limit, daily_hours_limit, overtime_multiplier, holiday_multiplier, hourly_wage) VALUES (1, 225, 45, 11, 1.50, 2.00, 50.00)";
            if ($conn->query($insert) === TRUE) {
                echo "<p>✅ Default work settings inserted</p>";
            }
        }
    } else {
        echo "<p>❌ Error creating work_settings: " . $conn->error . "</p>";
    }

    // 2. Create public_holidays table
    $sql = "CREATE TABLE IF NOT EXISTS public_holidays (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL DEFAULT 1,
        holiday_date DATE NOT NULL,
        holiday_name VARCHAR(255) NOT NULL,
        holiday_type ENUM('national', 'religious', 'company') DEFAULT 'national',
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_company_date (company_id, holiday_date),
        INDEX idx_date (holiday_date),
        INDEX idx_company (company_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    if ($conn->query($sql) === TRUE) {
        echo "<p>✅ public_holidays table created successfully</p>";
        
        // Insert 2025 holidays
        $check = $conn->query("SELECT COUNT(*) as count FROM public_holidays WHERE YEAR(holiday_date) = 2025 AND company_id = 1");
        $row = $check->fetch_assoc();
        if ($row['count'] == 0) {
            $holidays = [
                "(1, '2025-01-01', 'Yılbaşı', 'national', 'Yeni yıl kutlaması')",
                "(1, '2025-04-23', 'Ulusal Egemenlik ve Çocuk Bayramı', 'national', 'TBMM açılışı ve çocuk bayramı')",
                "(1, '2025-05-01', 'Emek ve Dayanışma Günü', 'national', 'İşçi Bayramı')",
                "(1, '2025-05-19', 'Atatürk\'ü Anma, Gençlik ve Spor Bayramı', 'national', 'Atatürk\'ün Samsun\'a çıkışı')",
                "(1, '2025-07-15', 'Demokrasi ve Milli Birlik Günü', 'national', '15 Temmuz darbe girişimi')",
                "(1, '2025-08-30', 'Zafer Bayramı', 'national', 'Büyük Taarruz başlangıcı')",
                "(1, '2025-10-29', 'Cumhuriyet Bayramı', 'national', 'Türkiye Cumhuriyeti ilanı')",
                "(1, '2025-03-31', 'Ramazan Bayramı 1. Gün', 'religious', 'Ramazan orucunun sona ermesi')",
                "(1, '2025-04-01', 'Ramazan Bayramı 2. Gün', 'religious', 'Ramazan Bayramı ikinci gün')",
                "(1, '2025-04-02', 'Ramazan Bayramı 3. Gün', 'religious', 'Ramazan Bayramı üçüncü gün')",
                "(1, '2025-06-07', 'Kurban Bayramı 1. Gün', 'religious', 'Hac ibadeti ve kurban kesimi')",
                "(1, '2025-06-08', 'Kurban Bayramı 2. Gün', 'religious', 'Kurban Bayramı ikinci gün')",
                "(1, '2025-06-09', 'Kurban Bayramı 3. Gün', 'religious', 'Kurban Bayramı üçüncü gün')",
                "(1, '2025-06-10', 'Kurban Bayramı 4. Gün', 'religious', 'Kurban Bayramı dördüncü gün')"
            ];
            
            $insert = "INSERT INTO public_holidays (company_id, holiday_date, holiday_name, holiday_type, description) VALUES " . implode(", ", $holidays);
            if ($conn->query($insert) === TRUE) {
                echo "<p>✅ 2025 holidays inserted</p>";
            }
        }
    } else {
        echo "<p>❌ Error creating public_holidays: " . $conn->error . "</p>";
    }

    // 3. Create attendance_activities table
    $sql = "CREATE TABLE IF NOT EXISTS attendance_activities (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        name VARCHAR(255) NOT NULL,
        activity_type ENUM('checkin', 'checkout', 'break_start', 'break_end', 'meal_start', 'meal_end', 'work_in', 'work_out') NOT NULL,
        description TEXT,
        is_paid TINYINT(1) DEFAULT 1,
        color_code VARCHAR(7) DEFAULT '#007bff',
        max_duration_minutes INT DEFAULT NULL,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_company_id (company_id),
        INDEX idx_type (activity_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    if ($conn->query($sql) === TRUE) {
        echo "<p>✅ attendance_activities table created successfully</p>";
        
        // Insert default activities
        $check = $conn->query("SELECT COUNT(*) as count FROM attendance_activities WHERE company_id = 1");
        $row = $check->fetch_assoc();
        if ($row['count'] == 0) {
            $activities = [
                "(1, 'İş Giriş', 'work_in', 'Günlük iş başlangıcı', 1, '#28a745')",
                "(1, 'İş Çıkış', 'work_out', 'Günlük iş bitişi', 1, '#dc3545')",
                "(1, 'Öğle Yemeği Başlangıç', 'meal_start', 'Öğle yemeği molası başlangıcı', 0, '#ffc107')",
                "(1, 'Öğle Yemeği Bitiş', 'meal_end', 'Öğle yemeği molası bitişi', 0, '#ffc107')",
                "(1, 'Çay Molası Başlangıç', 'break_start', 'Çay/kahve molası başlangıcı', 0, '#17a2b8')",
                "(1, 'Çay Molası Bitiş', 'break_end', 'Çay/kahve molası bitişi', 0, '#17a2b8')"
            ];
            
            $insert = "INSERT INTO attendance_activities (company_id, name, activity_type, description, is_paid, color_code) VALUES " . implode(", ", $activities);
            if ($conn->query($insert) === TRUE) {
                echo "<p>✅ Default activities inserted</p>";
            }
        }
    } else {
        echo "<p>❌ Error creating attendance_activities: " . $conn->error . "</p>";
    }

    // 4. Update qr_locations table
    $result = $conn->query("SHOW COLUMNS FROM qr_locations LIKE 'qr_code'");
    if ($result->num_rows === 0) {
        $sql = "ALTER TABLE qr_locations ADD COLUMN qr_code VARCHAR(100) UNIQUE";
        if ($conn->query($sql) === TRUE) {
            echo "<p>✅ qr_code column added to qr_locations</p>";
        }
    } else {
        echo "<p>✅ qr_locations.qr_code already exists</p>";
    }

    // 5. Create sessions table
    $sql = "CREATE TABLE IF NOT EXISTS sessions (
        session_id VARCHAR(128) PRIMARY KEY,
        session_data TEXT,
        session_time INT UNSIGNED NOT NULL,
        INDEX idx_time (session_time)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    if ($conn->query($sql) === TRUE) {
        echo "<p>✅ sessions table created successfully</p>";
    } else {
        echo "<p>❌ Error creating sessions: " . $conn->error . "</p>";
    }

    // Test queries
    echo "<h2>Testing Tables</h2>";
    $tables = ['work_settings', 'public_holidays', 'attendance_activities', 'qr_locations', 'sessions'];
    
    foreach ($tables as $table) {
        $result = $conn->query("SELECT COUNT(*) as count FROM $table");
        if ($result) {
            $row = $result->fetch_assoc();
            echo "<p>✅ $table: " . $row['count'] . " records</p>";
        } else {
            echo "<p>❌ Error testing $table: " . $conn->error . "</p>";
        }
    }

    $conn->close();
    echo "<h2>🎉 Database setup completed!</h2>";
    echo '<p><a href="attendance/records.php">Test Attendance Records</a> | <a href="qr/qr-reader.php">Test QR Reader</a></p>';

} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}
?>

</body>
</html>