/**
 * Device Tracking and Fingerprinting System
 * Collects device information for security and attendance tracking
 */

class DeviceTracker {
    constructor() {
        this.deviceInfo = {};
        this.init();
    }
    
    async init() {
        await this.collectDeviceInfo();
    }
    
    async collectDeviceInfo() {
        // Basic device information
        this.deviceInfo = {
            user_agent: navigator.userAgent,
            screen_resolution: `${screen.width}x${screen.height}`,
            timezone_offset: new Date().getTimezoneOffset(),
            language: navigator.language,
            platform: navigator.platform,
            cookie_enabled: navigator.cookieEnabled,
            online: navigator.onLine
        };
        
        // Detect browser
        this.deviceInfo.browser_name = this.detectBrowser();
        
        // Detect operating system
        this.deviceInfo.operating_system = this.detectOS();
        
        // Detect device type
        this.deviceInfo.device_type = this.detectDeviceType();
        
        // Hardware information (if available)
        if (navigator.hardwareConcurrency) {
            this.deviceInfo.cpu_cores = navigator.hardwareConcurrency;
        }
        
        if (navigator.deviceMemory) {
            this.deviceInfo.device_memory = navigator.deviceMemory;
        }
        
        // Network information (if available)
        if (navigator.connection) {
            this.deviceInfo.connection_type = navigator.connection.effectiveType;
            this.deviceInfo.downlink = navigator.connection.downlink;
        }
        
        // Canvas fingerprint (for additional uniqueness)
        this.deviceInfo.canvas_fingerprint = this.getCanvasFingerprint();
        
        // WebGL fingerprint
        this.deviceInfo.webgl_fingerprint = this.getWebGLFingerprint();
    }
    
    detectBrowser() {
        const userAgent = navigator.userAgent;
        
        if (userAgent.includes('Chrome') && !userAgent.includes('Edg')) return 'Chrome';
        if (userAgent.includes('Firefox')) return 'Firefox';
        if (userAgent.includes('Safari') && !userAgent.includes('Chrome')) return 'Safari';
        if (userAgent.includes('Edg')) return 'Edge';
        if (userAgent.includes('Opera') || userAgent.includes('OPR')) return 'Opera';
        
        return 'Unknown';
    }
    
    detectOS() {
        const userAgent = navigator.userAgent;
        
        if (userAgent.includes('Windows')) return 'Windows';
        if (userAgent.includes('Mac OS')) return 'macOS';
        if (userAgent.includes('Linux')) return 'Linux';
        if (userAgent.includes('Android')) return 'Android';
        if (userAgent.includes('iOS') || userAgent.includes('iPhone') || userAgent.includes('iPad')) return 'iOS';
        
        return 'Unknown';
    }
    
    detectDeviceType() {
        const userAgent = navigator.userAgent;
        
        if (/Mobi|Android/i.test(userAgent)) return 'mobile';
        if (/Tablet|iPad/i.test(userAgent)) return 'tablet';
        
        return 'desktop';
    }
    
    getCanvasFingerprint() {
        try {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillText('Device fingerprint canvas 123', 2, 2);
            
            return canvas.toDataURL().slice(-50); // Last 50 chars for uniqueness
        } catch (e) {
            return 'canvas_not_available';
        }
    }
    
    getWebGLFingerprint() {
        try {
            const canvas = document.createElement('canvas');
            const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            
            if (!gl) return 'webgl_not_available';
            
            const renderer = gl.getParameter(gl.RENDERER);
            const vendor = gl.getParameter(gl.VENDOR);
            
            return `${vendor}-${renderer}`.slice(0, 50);
        } catch (e) {
            return 'webgl_error';
        }
    }
    
    async getLocation() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocation not supported'));
                return;
            }
            
            const options = {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 300000 // 5 minutes
            };
            
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    resolve({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                        accuracy: position.coords.accuracy,
                        timestamp: new Date().toISOString()
                    });
                },
                (error) => {
                    reject(error);
                },
                options
            );
        });
    }
    
    async recordDeviceInfo(employeeId, companyId, qrLocationId = null, actionType = 'checkin') {
        try {
            // Get current location
            let location = null;
            try {
                location = await this.getLocation();
            } catch (e) {
                console.warn('Location not available:', e.message);
            }
            
            // Prepare data to send
            const data = {
                employee_id: employeeId,
                company_id: companyId,
                qr_location_id: qrLocationId,
                action_type: actionType,
                session_id: this.getSessionId(),
                ...this.deviceInfo
            };
            
            // Add location data if available
            if (location) {
                data.latitude = location.latitude;
                data.longitude = location.longitude;
                data.location_accuracy = location.accuracy;
            }
            
            // Send to server
            const response = await fetch('/ik/api/record-device-info.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                console.log('Device info recorded successfully:', result.device_fingerprint);
                return result;
            } else {
                throw new Error(result.error || 'Failed to record device info');
            }
            
        } catch (error) {
            console.error('Error recording device info:', error);
            throw error;
        }
    }
    
    getSessionId() {
        // Get or create session ID
        let sessionId = localStorage.getItem('szb_session_id');
        if (!sessionId) {
            sessionId = 'szb_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            localStorage.setItem('szb_session_id', sessionId);
        }
        return sessionId;
    }
    
    getDeviceFingerprint() {
        // Generate a unique fingerprint based on collected info
        const fingerprintData = [
            this.deviceInfo.user_agent,
            this.deviceInfo.screen_resolution,
            this.deviceInfo.timezone_offset,
            this.deviceInfo.language,
            this.deviceInfo.platform,
            this.deviceInfo.canvas_fingerprint,
            this.deviceInfo.webgl_fingerprint
        ].join('|');
        
        return this.simpleHash(fingerprintData);
    }
    
    simpleHash(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return Math.abs(hash).toString(36);
    }
    
    // Utility method to check if device is trusted
    async isDeviceTrusted(employeeId) {
        try {
            const fingerprint = this.getDeviceFingerprint();
            const response = await fetch('/ik/api/check-device-trust.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    employee_id: employeeId,
                    device_fingerprint: fingerprint
                })
            });
            
            const result = await response.json();
            return result.is_trusted || false;
        } catch (error) {
            console.error('Error checking device trust:', error);
            return false;
        }
    }
}

// Global instance
const deviceTracker = new DeviceTracker();

// Auto-record device info on page load for authenticated users
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is authenticated and has employee/company info
    const employeeId = document.querySelector('[data-employee-id]')?.dataset.employeeId;
    const companyId = document.querySelector('[data-company-id]')?.dataset.companyId;
    
    if (employeeId && companyId) {
        // Record device info on page load
        deviceTracker.recordDeviceInfo(employeeId, companyId, null, 'page_visit')
            .catch(error => console.warn('Failed to record device info on page load:', error));
    }
});

// Export for global use
window.DeviceTracker = DeviceTracker;
window.deviceTracker = deviceTracker;