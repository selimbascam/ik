<?php
header("Location: ../admin/work-settings.php");
exit;
?>