<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Critical Shift Date Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Step 1: Check Employee Shifts Table Structure</h3>";
    
    // Check if table exists
    $tables = $conn->query("SHOW TABLES LIKE 'employee_shifts'")->fetchAll();
    
    if (count($tables) == 0) {
        echo "<p style='color: red;'>❌ employee_shifts table does not exist! Creating it now...</p>";
        
        $conn->exec("
            CREATE TABLE employee_shifts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                shift_template_id INT NULL,
                shift_id INT NULL,
                shift_date DATE NOT NULL,
                start_time TIME DEFAULT '09:00:00',
                end_time TIME DEFAULT '17:00:00',
                break_duration INT DEFAULT 60,
                status ENUM('scheduled', 'present', 'absent', 'late', 'early_leave') DEFAULT 'scheduled',
                actual_start_time TIME NULL,
                actual_end_time TIME NULL,
                worked_minutes INT DEFAULT 0,
                overtime_minutes INT DEFAULT 0,
                break_minutes INT DEFAULT 60,
                early_leave_reason TEXT NULL,
                notes TEXT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_employee_id (employee_id),
                INDEX idx_shift_date (shift_date),
                INDEX idx_employee_date (employee_id, shift_date)
            )
        ");
        
        echo "<p style='color: green;'>✅ employee_shifts table created successfully</p>";
        
    } else {
        echo "<p style='color: green;'>✅ employee_shifts table exists</p>";
        
        // Check current structure
        $columns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll();
        $columnNames = array_column($columns, 'Field');
        
        echo "<h4>Current Columns:</h4>";
        echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px;'>";
        foreach ($columnNames as $col) {
            echo "<span style='background: #e9ecef; padding: 2px 8px; margin: 2px; border-radius: 3px; display: inline-block;'>{$col}</span> ";
        }
        echo "</div>";
        
        // Critical: Check if shift_date exists
        if (!in_array('shift_date', $columnNames)) {
            echo "<p style='color: red; font-weight: bold;'>❌ CRITICAL: shift_date column is missing!</p>";
            echo "<p>Adding shift_date column now...</p>";
            
            try {
                $conn->exec("ALTER TABLE employee_shifts ADD COLUMN shift_date DATE NOT NULL DEFAULT '2025-08-01' AFTER shift_id");
                echo "<p style='color: green;'>✅ shift_date column added successfully</p>";
                
                // Update existing records with reasonable dates
                $conn->exec("UPDATE employee_shifts SET shift_date = DATE(created_at) WHERE shift_date = '2025-08-01'");
                echo "<p style='color: green;'>✅ Updated existing records with shift dates</p>";
                
            } catch (Exception $e) {
                echo "<p style='color: red;'>❌ Error adding shift_date: " . $e->getMessage() . "</p>";
            }
        } else {
            echo "<p style='color: green;'>✅ shift_date column exists</p>";
        }
        
        // Check other critical columns
        $requiredColumns = [
            'status' => "ENUM('scheduled', 'present', 'absent', 'late', 'early_leave') DEFAULT 'scheduled'",
            'worked_minutes' => "INT DEFAULT 0",
            'overtime_minutes' => "INT DEFAULT 0",
            'break_duration' => "INT DEFAULT 60",
            'start_time' => "TIME DEFAULT '09:00:00'",
            'end_time' => "TIME DEFAULT '17:00:00'"
        ];
        
        foreach ($requiredColumns as $colName => $colDef) {
            if (!in_array($colName, $columnNames)) {
                echo "<p style='color: orange;'>⚠️ Adding missing column: {$colName}</p>";
                try {
                    $conn->exec("ALTER TABLE employee_shifts ADD COLUMN {$colName} {$colDef}");
                    echo "<p style='color: green;'>✅ {$colName} column added</p>";
                } catch (Exception $e) {
                    echo "<p style='color: red;'>❌ Error adding {$colName}: " . $e->getMessage() . "</p>";
                }
            }
        }
    }
    
    echo "<h3>Step 2: Create Sample Shift Data for Testing</h3>";
    
    // Get active employees
    $employees = $conn->query("SELECT id, first_name, last_name FROM employees LIMIT 3")->fetchAll();
    
    if (count($employees) > 0) {
        echo "<p>Creating sample shifts for " . count($employees) . " employees...</p>";
        
        foreach ($employees as $emp) {
            // Check if employee already has shifts for current month
            $existingShifts = $conn->prepare("
                SELECT COUNT(*) as count 
                FROM employee_shifts 
                WHERE employee_id = ? 
                AND YEAR(shift_date) = 2025 
                AND MONTH(shift_date) = 8
            ");
            $existingShifts->execute([$emp['id']]);
            $hasShifts = $existingShifts->fetch()['count'] > 0;
            
            if (!$hasShifts) {
                // Create shifts for August 2025 (22 working days)
                for ($day = 1; $day <= 31; $day++) {
                    $shiftDate = sprintf('2025-08-%02d', $day);
                    $dayOfWeek = date('N', strtotime($shiftDate));
                    
                    // Skip weekends
                    if ($dayOfWeek <= 5) {
                        $status = 'present';
                        $workedMinutes = 480; // 8 hours
                        $overtimeMinutes = 0;
                        
                        // Add some realistic variation
                        if ($day % 7 == 0) {
                            $status = 'late';
                            $workedMinutes = 450; // 7.5 hours due to lateness
                        } elseif ($day % 13 == 0) {
                            $overtimeMinutes = 60; // 1 hour overtime
                            $workedMinutes = 540; // 9 hours total
                        } elseif ($day % 15 == 0) {
                            $status = 'absent';
                            $workedMinutes = 0;
                        }
                        
                        try {
                            $stmt = $conn->prepare("
                                INSERT INTO employee_shifts (
                                    employee_id, shift_date, start_time, end_time,
                                    status, worked_minutes, overtime_minutes, break_duration
                                ) VALUES (?, ?, '09:00:00', '17:00:00', ?, ?, ?, 60)
                            ");
                            $stmt->execute([$emp['id'], $shiftDate, $status, $workedMinutes, $overtimeMinutes]);
                        } catch (Exception $e) {
                            // Skip if duplicate
                        }
                    }
                }
                echo "<p style='color: green;'>✅ Created shifts for {$emp['first_name']} {$emp['last_name']}</p>";
            } else {
                echo "<p>• {$emp['first_name']} {$emp['last_name']} already has shifts</p>";
            }
        }
    }
    
    echo "<h3>Step 3: Test the Payroll Query</h3>";
    
    // Test the exact query from the API
    $testQuery = "
        SELECT 
            es.*,
            COALESCE(st.start_time, es.start_time, '09:00:00') as start_time,
            COALESCE(st.end_time, es.end_time, '17:00:00') as end_time,
            COALESCE(st.break_duration, es.break_duration, 60) as break_duration
        FROM employee_shifts es
        LEFT JOIN shift_templates st ON es.shift_template_id = st.id
        WHERE es.employee_id = ? 
        AND YEAR(es.shift_date) = ? 
        AND MONTH(es.shift_date) = ?
        ORDER BY es.shift_date
        LIMIT 10
    ";
    
    try {
        $stmt = $conn->prepare($testQuery);
        $stmt->execute([1, 2025, 8]);
        $shifts = $stmt->fetchAll();
        
        echo "<p style='color: green; font-weight: bold;'>✅ SUCCESS! Payroll query works! Found " . count($shifts) . " shifts</p>";
        
        if (count($shifts) > 0) {
            echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
            echo "<tr style='background: #f0f0f0;'>";
            echo "<th style='padding: 8px;'>Date</th>";
            echo "<th style='padding: 8px;'>Status</th>";
            echo "<th style='padding: 8px;'>Hours</th>";
            echo "<th style='padding: 8px;'>Overtime</th>";
            echo "<th style='padding: 8px;'>Start-End</th>";
            echo "</tr>";
            
            foreach (array_slice($shifts, 0, 5) as $shift) {
                $hours = round($shift['worked_minutes'] / 60, 1);
                $overtime = round($shift['overtime_minutes'] / 60, 1);
                echo "<tr>";
                echo "<td style='padding: 8px;'>{$shift['shift_date']}</td>";
                echo "<td style='padding: 8px;'>" . ucfirst($shift['status']) . "</td>";
                echo "<td style='padding: 8px;'>{$hours}h</td>";
                echo "<td style='padding: 8px;'>{$overtime}h</td>";
                echo "<td style='padding: 8px;'>{$shift['start_time']}-{$shift['end_time']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red; font-weight: bold;'>❌ FAILED: " . $e->getMessage() . "</p>";
        echo "<p>This means there's still a problem with the table structure.</p>";
    }
    
    echo "<h3>Step 4: Final Verification</h3>";
    
    // Final structure check
    $finalColumns = $conn->query("SHOW COLUMNS FROM employee_shifts")->fetchAll();
    $finalColumnNames = array_column($finalColumns, 'Field');
    
    $criticalColumns = ['shift_date', 'status', 'worked_minutes', 'overtime_minutes'];
    $allPresent = true;
    
    foreach ($criticalColumns as $col) {
        if (in_array($col, $finalColumnNames)) {
            echo "<p style='color: green;'>✅ {$col} column present</p>";
        } else {
            echo "<p style='color: red;'>❌ {$col} column missing</p>";
            $allPresent = false;
        }
    }
    
    if ($allPresent) {
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>🎉 SUCCESS! All critical columns are present</h4>";
        echo "<p><strong>The payroll API should now work correctly!</strong></p>";
        echo "<p>Test it here: <a href='api/calculate-monthly-summary.php?year=2025&month=08' target='_blank' style='color: #0066cc;'>Calculate Monthly Summary</a></p>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>❌ Some columns are still missing</h4>";
        echo "<p>Manual intervention may be required.</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red; font-weight: bold;'>❌ CRITICAL ERROR: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
    echo "<p>File: " . $e->getFile() . "</p>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
table { width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background: #f0f0f0; }
</style>