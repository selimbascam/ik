# SZB İK Takip - Otomatik Hata Kayıt Sistemi

## 📋 Genel Bakış

SZB İK Takip sistemine otomatik hata kayıt ve çözüm takip sistemi eklenmiştir. Bu sistem tüm kullanıcıların karşılaştığı hataları otomatik olarak kayıt altına alır ve çözüm sürecini takip eder.

## ✅ Kurulum Tamamlandı

### 1. Temel Sistem Dosyaları
- ✅ `includes/error-logger.php` - Ana hata kayıt sınıfı
- ✅ `includes/init-error-logging.php` - Hata yakalayıcıları
- ✅ `includes/config.php` - Otomatik başlatma entegrasyonu
- ✅ `super-admin/error-management.php` - Hata yönetim arayüzü
- ✅ `api/error-report-upload.php` - JSON rapor yükleme API'si

### 2. Entegrasyon Örnekleri
- ✅ `includes/example-error-integration.php` - Kod entegrasyon örnekleri
- ✅ `qr/qr-reader.php` - QR sistem entegrasyonu (örnek)

## 🚀 Nasıl Çalışır

### Otomatik Hata Yakalama
Sistem aşağıdaki hata türlerini otomatik olarak yakalar:

1. **PHP Hataları** - Warning, Notice, Error
2. **Fatal Hatalar** - Parse, Core, Compile hataları  
3. **Exception'lar** - Yakalanmamış tüm exception'lar
4. **Manuel Hatalar** - Kodda elle kaydedilen hatalar

### Hata Kategorileri
- **Database** - Veritabanı işlem hataları
- **QR System** - QR kod okuma/işleme hataları  
- **Session** - Oturum yönetim hataları
- **Authentication** - Giriş/çıkış hataları
- **General** - Genel sistem hataları

### Önem Seviyeleri
- 🔴 **Critical** - Sistem durdurucu hatalar
- 🟠 **High** - Önemli işlevsellik hataları
- 🟡 **Medium** - Orta seviye hatalar
- 🟢 **Low** - Küçük uyarılar

## 📊 Hata Yönetim Sistemi

### Super Admin Erişimi
**URL**: `/super-admin/error-management.php`

### Özellikler
- ✅ Hata listesi ve filtreleme
- ✅ Durum takibi (Çözülmedi, İnceleniyor, Çözüldü, Göz Ardı)  
- ✅ Çözüm notları ekleme
- ✅ İstatistik dashboard'u
- ✅ JSON rapor indirme
- ✅ Gerçek zamanlı güncelleme

### Filtreleme Seçenekleri
- **Durum**: Çözülmedi, İnceleniyor, Çözüldü, Göz Ardı
- **Önem**: Critical, High, Medium, Low  
- **Tarih**: Belirli tarihten sonraki hatalar
- **Şirket**: Şirket bazında filtreleme

## 🔧 Kod Entegrasyonu

### Mevcut Sayfalara Hata Kaydı Ekleme

```php
// Database hataları için
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $result = $stmt->execute([$userId]);
} catch (PDOException $e) {
    logDatabaseError($e->getMessage(), "SELECT query", [$userId]);
}

// QR sistem hataları için
try {
    $qrResult = processQR($qrData);
} catch (Exception $e) {
    logQRError($e->getMessage(), $qrData, ['user_id' => $userId]);
}

// Genel hatalar için
if (!$importantOperation) {
    logError("Operation failed", ['context' => 'data'], 'high');
}
```

### Mevcut Error Handler'lar
```php
logError($message, $context, $severity)       // Genel hata
logDatabaseError($message, $query, $params)   // Database hata  
logQRError($message, $qrData, $context)       // QR sistem hata
logSessionError($message, $context)           // Session hata
logLoginError($message, $email, $context)     // Login hata
```

## 📤 Hata Raporu Formatı

### JSON Yapısı
```json
{
  "system_info": {
    "system_name": "SZB İK Takip",
    "report_generated_at": "2025-08-11 10:30:00",
    "server_info": {
      "php_version": "8.1.31",
      "server_software": "LiteSpeed",
      "memory_usage": 1048576,
      "memory_limit": "256M"
    }
  },
  "statistics": {
    "total_errors": 25,
    "unsolved": 5,
    "investigating": 3, 
    "solved": 15,
    "ignored": 2,
    "critical": 1,
    "high": 4,
    "medium": 15,
    "low": 5
  },
  "errors": [
    {
      "id": 123,
      "error_code": "ERR_20250811_abc123",
      "error_message": "QR kod okunamadı", 
      "error_context": "{...}",
      "severity": "medium",
      "user_id": "emp_001",
      "company_id": 1,
      "page_url": "/qr/qr-reader.php",
      "ip_address": "192.168.1.100",
      "status": "solved",
      "solution_notes": "QR kod tablosu güncellendi",
      "solved_by": "admin@szb.com.tr", 
      "solved_at": "2025-08-11 11:00:00",
      "created_at": "2025-08-11 10:00:00"
    }
  ]
}
```

## 🌐 API Kullanımı

### Hata Raporu Yükleme
**Endpoint**: `POST /api/error-report-upload.php`

```bash
curl -X POST https://szb.com.tr/ik/api/error-report-upload.php \
  -H "Content-Type: application/json" \
  -d @error-report.json
```

### Yanıt Formatı
```json
{
  "success": true,
  "processed": 20,
  "failed": 1, 
  "total": 21,
  "message": "20 hata başarıyla kaydedildi, 1 hata işlenemedi",
  "errors": ["İşleme hatası: Geçersiz veri formatı"]
}
```

## 📂 Dosya Yapısı

```
public_html/
├── includes/
│   ├── error-logger.php           # Ana hata kayıt sistemi
│   ├── init-error-logging.php     # Otomatik başlatma
│   ├── example-error-integration.php # Entegrasyon örnekleri
│   └── config.php                 # Güncellendi (otomatik başlatma)
├── super-admin/
│   └── error-management.php       # Hata yönetim arayüzü
├── api/
│   └── error-report-upload.php    # JSON rapor yükleme API
├── uploads/
│   └── error-reports/             # İndirilen raporlar
├── logs/
│   └── error-log-YYYY-MM-DD.txt   # Yedek log dosyaları
└── docs/
    └── error-logging-system.md    # Bu dokümantasyon
```

## 🔄 Sistem Entegrasyonu Durumu

### Tamamlanan Entegrasyonlar
- ✅ QR Reader (`qr/qr-reader.php`)
- ✅ Config otomatik başlatma  
- ✅ Super Admin menü bağlantısı (manuel ekleme gerekiyor)

### Önerilen Entegrasyonlar
- 🔲 Employee Login (`auth/employee-login.php`)
- 🔲 Company Login (`auth/company-login.php`) 
- 🔲 Database operations (`includes/database.php`)
- 🔲 Attendance processing (`api/process-attendance.php`)
- 🔲 Admin işlemleri (`admin/` klasörü)

## 🎯 Sonraki Adımlar

1. **Test Etme**
   - Super Admin panelinden hata yönetim sistemine erişim
   - QR okuyucuda test hatası oluşturma
   - Hata durumlarını güncelleme

2. **Yaygınlaştırma**  
   - Diğer kritik sayfalara hata kaydı ekleme
   - Kullanıcı eğitimi ve dokümantasyon

3. **İzleme**
   - Günlük hata raporlarını inceleme
   - Tekrarlayan hataları tespit etme
   - Proaktif çözümler geliştirme

---

## 📞 Destek

Hata kayıt sistemi ile ilgili sorunlar için:
- Super Admin paneli > Hata Yönetim Sistemi
- Sistem analiz araçları kullanın
- Log dosyalarını kontrol edin

**Sistem Durumu**: ✅ Aktif ve Çalışır Durumda  
**Son Güncelleme**: 11 Ağustos 2025  
**Sürüm**: 1.0.0