<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 MySQLi Compatibility Emergency Fix</h1>";

// Search for all files with closeCursor() usage
$testFiles = [
    'test-shift-queries.php',
    'fix-shift-management.php', 
    'debug/fix-qr-date-column.php',
    'includes/attendance-helper.php',
    'shift-management-status.php'
];

echo "<h3>🔍 Scanning Files for MySQLi Compatibility Issues</h3>";

$issuesFound = 0;
$filesFixed = 0;

foreach ($testFiles as $file) {
    $fullPath = __DIR__ . '/' . $file;
    
    if (file_exists($fullPath)) {
        $content = file_get_contents($fullPath);
        $hasCloseCursor = strpos($content, 'closeCursor()') !== false;
        $hasCloseCursorVar = strpos($content, '->closeCursor()') !== false;
        
        echo "<h4>📄 " . htmlspecialchars($file) . "</h4>";
        
        if ($hasCloseCursor || $hasCloseCursorVar) {
            echo "<p>❌ Found closeCursor() usage</p>";
            $issuesFound++;
            
            // Auto-fix the file
            $fixedContent = str_replace('->closeCursor();', ' = null;', $content);
            $fixedContent = str_replace('closeCursor();', ' = null;', $fixedContent);
            
            if ($fixedContent !== $content) {
                if (file_put_contents($fullPath, $fixedContent)) {
                    echo "<p>✅ File automatically fixed</p>";
                    $filesFixed++;
                } else {
                    echo "<p>❌ Failed to fix file</p>";
                }
            }
        } else {
            echo "<p>✅ No closeCursor() issues found</p>";
        }
    } else {
        echo "<h4>📄 " . htmlspecialchars($file) . "</h4>";
        echo "<p>⚠️ File not found</p>";
    }
}

echo "<h3>📊 Fix Summary</h3>";
echo "<ul>";
echo "<li>Files scanned: " . count($testFiles) . "</li>";
echo "<li>Issues found: $issuesFound</li>";
echo "<li>Files fixed: $filesFixed</li>";
echo "</ul>";

// Test database connection type
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>🔌 Database Connection Test</h3>";
    echo "<p>Connection type: " . get_class($conn) . "</p>";
    
    if ($conn instanceof PDO) {
        echo "<p>✅ PDO connection - closeCursor() supported</p>";
    } else {
        echo "<p>⚠️ MySQLi connection - closeCursor() NOT supported</p>";
        echo "<p><strong>Fix:</strong> Use \$stmt = null; instead of \$stmt->closeCursor();</p>";
    }
    
    // Test a simple query
    $stmt = $conn->query("SELECT 'Connection test' as test");
    if ($conn instanceof PDO) {
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        $result = $stmt->fetch_assoc();
    }
    echo "<p>✅ Database query test: " . ($result['test'] ?? 'Failed') . "</p>";
    
} catch (Exception $e) {
    echo "<p>❌ Database connection failed: " . $e->getMessage() . "</p>";
}

echo "<h3>🔗 Test Fixed Files</h3>";
echo "<ul>";
echo "<li><a href='test-shift-queries.php' style='color: #0056b3;'>Test Shift Queries</a></li>";
echo "<li><a href='fix-shift-management.php' style='color: #0056b3;'>Fix Shift Management</a></li>";
echo "<li><a href='quick-shift-test.php' style='color: #0056b3;'>Quick Shift Test</a></li>";
echo "</ul>";

if ($issuesFound > 0 && $filesFixed > 0) {
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3>✅ MySQLi Compatibility Fixed</h3>";
    echo "<p>All closeCursor() issues have been resolved.</p>";
    echo "<p>Files are now compatible with both PDO and MySQLi connections.</p>";
    echo "</div>";
} elseif ($issuesFound == 0) {
    echo "<div style='background: #d1ecf1; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3>✅ No MySQLi Issues Found</h3>";
    echo "<p>All scanned files are already compatible.</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "</style>";
?>