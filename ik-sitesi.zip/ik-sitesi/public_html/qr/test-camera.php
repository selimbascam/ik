<?php
// Simple camera test page
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kamera Test</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6">
        <h1 class="text-2xl font-bold mb-4">Kamera Test Sayfası</h1>
        
        <div class="mb-4">
            <video id="video" class="w-full h-64 bg-black rounded" autoplay></video>
        </div>
        
        <div class="space-y-2">
            <button onclick="startCamera()" class="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">
                Kamera Başlat
            </button>
            <button onclick="stopCamera()" class="w-full bg-red-500 text-white py-2 px-4 rounded hover:bg-red-600">
                Kamera Durdur
            </button>
        </div>
        
        <div id="status" class="mt-4 p-3 rounded bg-gray-100 text-sm"></div>
        <div id="console" class="mt-4 p-3 rounded bg-black text-green-400 text-xs font-mono h-32 overflow-y-auto"></div>
    </div>

    <script>
        let stream = null;
        const video = document.getElementById('video');
        const status = document.getElementById('status');
        const consoleDiv = document.getElementById('console');
        
        function log(message) {
            const time = new Date().toLocaleTimeString();
            consoleDiv.innerHTML += `[${time}] ${message}<br>`;
            consoleDiv.scrollTop = consoleDiv.scrollHeight;
            console.log(message);
        }
        
        async function startCamera() {
            try {
                log('Kamera başlatılıyor...');
                status.textContent = 'Kamera izni isteniyor...';
                
                // Method 1: Try with constraints
                try {
                    log('Method 1: Environment camera deneniyor...');
                    stream = await navigator.mediaDevices.getUserMedia({
                        video: { facingMode: 'environment' }
                    });
                    log('✓ Environment camera başarılı');
                } catch (e1) {
                    log('✗ Environment camera başarısız: ' + e1.message);
                    
                    // Method 2: Try any camera
                    try {
                        log('Method 2: Herhangi bir kamera deneniyor...');
                        stream = await navigator.mediaDevices.getUserMedia({
                            video: true
                        });
                        log('✓ Varsayılan kamera başarılı');
                    } catch (e2) {
                        log('✗ Varsayılan kamera başarısız: ' + e2.message);
                        throw e2;
                    }
                }
                
                video.srcObject = stream;
                
                // Check video state
                video.onloadedmetadata = () => {
                    log('✓ Video metadata yüklendi');
                    log('Video boyutları: ' + video.videoWidth + 'x' + video.videoHeight);
                };
                
                video.onplaying = () => {
                    log('✓ Video oynatılıyor');
                };
                
                status.textContent = '✅ Kamera aktif';
                
            } catch (error) {
                log('❌ HATA: ' + error.name + ' - ' + error.message);
                status.textContent = '❌ Hata: ' + error.message;
                
                if (error.name === 'NotAllowedError') {
                    alert('Kamera izni reddedildi. Tarayıcı ayarlarından izin verin.');
                } else if (error.name === 'NotFoundError') {
                    alert('Kamera bulunamadı.');
                } else if (error.name === 'NotReadableError') {
                    alert('Kamera başka bir uygulama tarafından kullanılıyor.');
                } else {
                    alert('Kamera hatası: ' + error.message);
                }
            }
        }
        
        function stopCamera() {
            if (stream) {
                log('Kamera durduruluyor...');
                stream.getTracks().forEach(track => {
                    track.stop();
                    log('✓ Track durduruldu: ' + track.kind);
                });
                video.srcObject = null;
                stream = null;
                status.textContent = '⏹️ Kamera durduruldu';
            }
        }
        
        // Check browser support
        log('Tarayıcı: ' + navigator.userAgent);
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            log('✓ getUserMedia destekleniyor');
        } else {
            log('✗ getUserMedia desteklenmiyor!');
        }
        
        // Check HTTPS
        if (location.protocol === 'https:') {
            log('✓ HTTPS bağlantısı');
        } else {
            log('⚠️ HTTP bağlantısı (kamera çalışmayabilir)');
        }
    </script>
</body>
</html>