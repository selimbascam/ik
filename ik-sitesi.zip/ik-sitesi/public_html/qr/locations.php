<?php
header("Location: ../admin/qr-generator.php");
exit;
?>