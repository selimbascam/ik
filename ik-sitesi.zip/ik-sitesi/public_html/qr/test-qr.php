<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/attendance-helper.php';

// Test için session başlat
if (!isset($_SESSION['employee_id'])) {
    $_SESSION['employee_id'] = 1; // Test employee ID
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Test employee bilgilerini al
    $employeeId = $_SESSION['employee_id'];
    $stmt = $conn->prepare("SELECT id, company_id, first_name, last_name FROM employees WHERE id = ?");
    $stmt->execute([$employeeId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "❌ Employee bulunamadı!<br>";
        exit;
    }
    
    echo "✅ Employee bulundu: " . $employee['first_name'] . " " . $employee['last_name'] . "<br>";
    echo "🏢 Company ID: " . $employee['company_id'] . "<br><br>";
    
    // AttendanceHelper test
    $today = date('Y-m-d');
    $nextAction = AttendanceHelper::determineNextAction($conn, $employeeId, $today);
    
    echo "🎯 Sonraki eylem: " . $nextAction['action'] . "<br>";
    echo "💬 Mesaj: " . $nextAction['message'] . "<br><br>";
    
    // QR location test
    $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? LIMIT 1");
    $stmt->execute([$employee['company_id']]);
    $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($qrLocation) {
        echo "🎯 Test QR Location: " . $qrLocation['name'] . " (ID: " . $qrLocation['id'] . ")<br>";
        
        // Test attendance update
        AttendanceHelper::updateAttendanceRecord(
            $conn, 
            $employeeId, 
            $employee['company_id'], 
            $nextAction['action'], 
            $qrLocation['name'], 
            $qrLocation['id']
        );
        
        echo "✅ Attendance kaydı güncellendi!<br>";
    } else {
        echo "❌ QR Location bulunamadı!<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage() . "<br>";
}
?>

<a href="../employee/dashboard.php">← Dashboard'a dön</a>