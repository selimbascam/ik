<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if user is logged in as employee
if (!isset($_SESSION['employee_id'])) {
    header('Location: /ik/auth/employee-login.php');
    exit;
}

// Get QR location data from session
if (!isset($_SESSION['qr_scan_data'])) {
    header('Location: /ik/qr/qr-reader.php');
    exit;
}

$qrData = $_SESSION['qr_scan_data'];
$employeeId = $_SESSION['employee_id'];
$message = '';
$messageType = '';

// Define activity types with modern icons and descriptions
$activityTypes = [
    [
        'name' => 'work_in',
        'icon' => '🏢',
        'description' => 'İşe giriş kaydı'
    ],
    [
        'name' => 'work_out',
        'icon' => '🚪',
        'description' => 'İşten çıkış kaydı'
    ],
    [
        'name' => 'break_start',
        'icon' => '☕',
        'description' => 'Mola başlangıcı'
    ],
    [
        'name' => 'break_end',
        'icon' => '⚡',
        'description' => 'Mola bitişi'
    ],
    [
        'name' => 'site_visit',
        'icon' => '🚗',
        'description' => 'Saha ziyareti'
    ],
    [
        'name' => 'meeting',
        'icon' => '🤝',
        'description' => 'Toplantı'
    ]
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $activityType = trim($_POST['activity_type'] ?? '');
    $currentLat = trim($_POST['current_lat'] ?? '');
    $currentLng = trim($_POST['current_lng'] ?? '');
    $deviceFingerprint = trim($_POST['device_fingerprint'] ?? '');
    $devicePlatform = trim($_POST['device_platform'] ?? '');
    $deviceBrowser = trim($_POST['device_browser'] ?? '');
    
    if (empty($activityType)) {
        $message = "Lütfen bir aktivite türü seçin.";
        $messageType = "error";
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Get employee details with company validation
            $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$employee) {
                throw new Exception("Personel bulunamadı");
            }

            // CRITICAL FIX: Ensure valid company_id - Modern Activity Selection
            if (!$employee['company_id'] || $employee['company_id'] == 0) {
                error_log("Modern Activity: Employee {$employee['id']} has NULL/0 company_id - applying emergency fix");
                
                $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE status = 'active' ORDER BY id LIMIT 1");
                $stmt->execute();
                $defaultCompany = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$defaultCompany) {
                    // Create emergency company
                    $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                    $stmt->execute(['SZB Emergency Company', 'emergency@szb.com.tr', '555-9999', 'Emergency Company Address', 'active']);
                    $defaultCompany = ['id' => $conn->lastInsertId(), 'company_name' => 'SZB Emergency Company'];
                    error_log("Modern Activity: Created emergency company {$defaultCompany['id']}");
                }
                
                // Update employee with verified company
                $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
                $stmt->execute([$defaultCompany['id'], $employee['id']]);
                $employee['company_id'] = $defaultCompany['id'];
                error_log("Modern Activity: FIXED - Employee {$employee['id']} company_id updated to {$defaultCompany['id']}");
            }
            
            // Get today's shift information
            $today = date('Y-m-d');
            $stmt = $conn->prepare("
                SELECT 
                    es.*,
                    st.name as shift_name,
                    st.start_time,
                    st.end_time,
                    st.break_duration
                FROM employee_shifts es
                JOIN shift_templates st ON es.shift_template_id = st.id
                WHERE es.employee_id = ? AND es.shift_date = ?
            ");
            $stmt->execute([$employeeId, $today]);
            $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Validate shift timing
            $currentTime = date('H:i:s');
            $isLate = 0;
            $isEarlyLeave = 0;
            $tolerance = 15; // minutes
            
            if ($todayShift) {
                $shiftStart = $todayShift['start_time'];
                $shiftEnd = $todayShift['end_time'];
                
                if ($activityType === 'work_in' && $currentTime > date('H:i:s', strtotime($shiftStart . ' +' . $tolerance . ' minutes'))) {
                    $isLate = 1;
                }
                
                if ($activityType === 'work_out' && $currentTime < date('H:i:s', strtotime($shiftEnd . ' -' . $tolerance . ' minutes'))) {
                    $isEarlyLeave = 1;
                }
            }
            
            // Insert attendance record with enhanced data
            $stmt = $conn->prepare("
                INSERT INTO attendance_records (
                    employee_id, 
                    company_id, 
                    activity_type, 
                    latitude, 
                    longitude, 
                    device_fingerprint,
                    device_platform,
                    device_browser,
                    qr_location_id, 
                    recorded_at, 
                    is_late, 
                    is_early_leave,
                    notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, ?)
            ");
            
            $qrLocationId = $qrData['location_id'] ?? null;
            $notes = "Modern Activity Selection - " . ($qrData['location_name'] ?? 'Unknown Location');
            
            $stmt->execute([
                $employeeId,
                $employee['company_id'],
                $activityType,
                $currentLat ?: null,
                $currentLng ?: null,
                $deviceFingerprint ?: null,
                $devicePlatform ?: null,
                $deviceBrowser ?: null,
                $qrLocationId,
                $isLate,
                $isEarlyLeave,
                $notes
            ]);
            
            $message = "Aktivite kaydı başarıyla oluşturuldu!";
            $messageType = "success";
            
            // Clear QR scan data from session
            unset($_SESSION['qr_scan_data']);
            
            // Log successful activity recording
            error_log("Modern Activity: Activity '$activityType' recorded for employee $employeeId at location " . ($qrData['location_name'] ?? 'Unknown'));
            
            // Redirect after 2 seconds
            header("refresh:2;url=../employee/dashboard.php");
            
        } catch (Exception $e) {
            error_log("Modern Activity Selection error: " . $e->getMessage());
            $message = "Kayıt işlemi sırasında bir hata oluştu: " . $e->getMessage();
            $messageType = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktivite Seçimi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .activity-card {
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .activity-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        .activity-card.selected {
            border-color: #667eea;
            background-color: #f0f4ff;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.3);
        }
        .success-message {
            background: #f0fff4;
            color: #22543d;
            border: 1px solid #9ae6b4;
        }
        .error-message {
            background: #fff5f5;
            color: #742a2a;
            border: 1px solid #feb2b2;
        }
        .scan-animation {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body class="gradient-bg flex items-center justify-center py-8 px-4">
    <div class="max-w-2xl w-full">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <span class="text-indigo-600 text-3xl">📋</span>
            </div>
            <h1 class="text-3xl font-bold text-white mb-2">Aktivite Seçimi</h1>
            <p class="text-indigo-100">Ne yaptığınızı seçin ve kaydedin</p>
        </div>

        <!-- QR Location Info -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="font-semibold text-gray-900 flex items-center">
                        <i class="fas fa-map-marker-alt text-indigo-600 mr-2"></i>
                        Lokasyon Bilgisi
                    </h3>
                    <p class="text-lg text-indigo-600 font-medium mt-1"><?php echo htmlspecialchars($qrData['location_name'] ?? 'Bilinmeyen Lokasyon'); ?></p>
                    <p class="text-sm text-gray-500 mt-1"><?php echo htmlspecialchars($qrData['description'] ?? 'Açıklama yok'); ?></p>
                </div>
                <div class="text-right">
                    <div class="bg-indigo-100 text-indigo-800 rounded-full px-3 py-1 text-sm font-medium">
                        <i class="far fa-clock mr-1"></i>
                        <span id="current-time"><?php echo date('H:i'); ?></span>
                    </div>
                    <p class="text-sm text-gray-500 mt-2"><?php echo date('d.m.Y'); ?></p>
                </div>
            </div>
        </div>

        <!-- Message Display -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'success-message' : 'error-message'; ?>">
                <div class="flex items-center">
                    <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
                    <span><?php echo htmlspecialchars($message); ?></span>
                </div>
                <?php if ($messageType === 'success'): ?>
                    <div class="mt-2 text-sm">Personel paneline yönlendiriliyorsunuz...</div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Activity Selection Form -->
        <form method="POST" id="activityForm" class="space-y-6">
            <!-- Hidden location and device fields -->
            <input type="hidden" id="current_lat" name="current_lat">
            <input type="hidden" id="current_lng" name="current_lng">
            <input type="hidden" id="device_mac" name="device_mac">
            <input type="hidden" id="device_fingerprint" name="device_fingerprint">
            <input type="hidden" id="device_platform" name="device_platform">
            <input type="hidden" id="device_browser" name="device_browser">
            
            <div>
                <h3 class="text-lg font-semibold text-white mb-4 flex items-center">
                    <i class="fas fa-tasks mr-2"></i>
                    Aktivite Türünü Seçin
                </h3>
                
                <!-- Activity Types Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php foreach ($activityTypes as $index => $activity): ?>
                        <div class="activity-card bg-white rounded-xl border-2 border-gray-200 p-5 text-center cursor-pointer"
                             data-value="<?php echo htmlspecialchars($activity['name']); ?>">
                            <div class="text-4xl mb-3"><?php echo $activity['icon'] ?? '📝'; ?></div>
                            <h3 class="font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($activity['name']); ?></h3>
                            <?php if (!empty($activity['description'])): ?>
                                <p class="text-sm text-gray-600"><?php echo htmlspecialchars($activity['description']); ?></p>
                            <?php endif; ?>
                            <input type="radio" name="activity_type" value="<?php echo htmlspecialchars($activity['name']); ?>" class="sr-only">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="mt-8">
                <button 
                    type="submit" 
                    id="submitBtn"
                    disabled
                    class="w-full bg-gray-400 text-white py-4 px-6 rounded-xl font-semibold text-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center"
                >
                    <i class="fas fa-mouse-pointer mr-2"></i>
                    Aktivite Seçin
                </button>
            </div>
        </form>

        <!-- Bottom Actions -->
        <div class="mt-8 text-center space-y-4">
            <a href="../employee/qr-attendance-master.php" class="inline-block bg-white text-indigo-600 py-3 px-6 rounded-lg font-medium hover:bg-indigo-50 transition-colors shadow-md scan-animation">
                <i class="fas fa-qrcode mr-2"></i>Yeni QR Kod Okut
            </a>
            <div class="text-center">
                <a href="../employee/dashboard.php" class="text-white hover:text-indigo-200 text-sm">
                    <i class="fas fa-home mr-1"></i>Personel Paneline Dön
                </a>
            </div>
        </div>
    </div>

    <script>
        // Update current time
        function updateClock() {
            const now = new Date();
            const timeStr = now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
            document.getElementById('current-time').textContent = timeStr;
        }
        setInterval(updateClock, 60000);
        updateClock();

        // Device Information Collection
        function collectDeviceInfo() {
            // Generate device fingerprint
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillText('Device fingerprint', 2, 2);
            
            // Get platform information
            const platform = navigator.platform || 'Unknown';
            const userAgent = navigator.userAgent;
            
            // Browser detection
            let browser = 'Unknown';
            if (userAgent.indexOf('Chrome') > -1) browser = 'Chrome';
            else if (userAgent.indexOf('Firefox') > -1) browser = 'Firefox';
            else if (userAgent.indexOf('Safari') > -1) browser = 'Safari';
            else if (userAgent.indexOf('Edge') > -1) browser = 'Edge';
            else if (userAgent.indexOf('Opera') > -1) browser = 'Opera';
            
            // Create device fingerprint hash
            const deviceData = platform + userAgent + screen.width + screen.height + navigator.language;
            const fingerprint = btoa(deviceData).substring(0, 32);
            
            // Set hidden form fields
            document.getElementById('device_fingerprint').value = fingerprint;
            document.getElementById('device_platform').value = platform;
            document.getElementById('device_browser').value = browser;
            
            console.log('📱 Cihaz Bilgileri Toplandı:', { platform, browser, fingerprint });
        }
        
        // Get user location
        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        document.getElementById('current_lat').value = position.coords.latitude;
                        document.getElementById('current_lng').value = position.coords.longitude;
                        console.log('📍 Konum alındı:', position.coords.latitude, position.coords.longitude);
                    },
                    function(error) {
                        console.warn('📍 Konum alınamadı:', error.message);
                    },
                    { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
                );
            }
        }
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            collectDeviceInfo();
            getLocation();
            
            // Activity selection handling
            const activityCards = document.querySelectorAll('.activity-card');
            const submitBtn = document.getElementById('submitBtn');
            
            activityCards.forEach(card => {
                card.addEventListener('click', function() {
                    // Remove selected class from all cards
                    activityCards.forEach(c => c.classList.remove('selected'));
                    
                    // Add selected class to clicked card
                    this.classList.add('selected');
                    
                    // Check the radio button
                    const radio = this.querySelector('input[type="radio"]');
                    radio.checked = true;
                    
                    // Enable submit button
                    submitBtn.disabled = false;
                    submitBtn.className = 'w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 px-6 rounded-xl font-semibold text-lg transition-all duration-200 flex items-center justify-center';
                    submitBtn.innerHTML = '<i class="fas fa-check-circle mr-2"></i>Kaydet ve Devam Et';
                });
            });
            
            // Form submission handling
            document.getElementById('activityForm').addEventListener('submit', function(e) {
                const selectedActivity = document.querySelector('input[name="activity_type"]:checked');
                if (!selectedActivity) {
                    e.preventDefault();
                    alert('Lütfen bir aktivite seçin.');
                    return;
                }

                // Show loading state
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Kaydediliyor...';
            });
        });
    </script>
</body>
</html>