<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if user is logged in as employee
if (!isset($_SESSION['employee_id'])) {
    header('Location: /ik/auth/employee-login.php');
    exit;
}

// Get QR location data from session
if (!isset($_SESSION['qr_scan_data'])) {
    header('Location: /ik/qr/qr-reader.php');
    exit;
}

$qrData = $_SESSION['qr_scan_data'];
$employeeId = $_SESSION['employee_id'];
$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $activityType = trim($_POST['activity_type'] ?? '');
    
    if (empty($activityType)) {
        $message = "Lütfen bir aktivite türü seçin.";
        $messageType = "error";
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Get employee details
            $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$employee) {
                throw new Exception("Personel bulunamadı");
            }
            
            // Get today's shift information for validation
            $today = date('Y-m-d');
            $stmt = $conn->prepare("
                SELECT 
                    es.*,
                    st.name as shift_name,
                    st.start_time,
                    st.end_time,
                    st.break_duration
                FROM employee_shifts es
                JOIN shift_templates st ON es.shift_template_id = st.id
                WHERE es.employee_id = ? AND es.shift_date = ?
            ");
            $stmt->execute([$employeeId, $today]);
            $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Validate shift timing and determine if late/early
            $currentTime = date('H:i:s');
            $isLate = 0;
            $isEarlyLeave = 0;
            $needsReason = 0;
            $tolerance = 15; // 15 minutes tolerance
            
            if ($todayShift) {
                $shiftStart = $todayShift['start_time'];
                $shiftEnd = $todayShift['end_time'];
                
                // Check if arriving late for work_in
                if ($activityType === 'work_in' && $currentTime > date('H:i:s', strtotime($shiftStart . ' +' . $tolerance . ' minutes'))) {
                    $isLate = 1;
                    $needsReason = 1;
                }
                
                // Check if leaving early for work_out
                if ($activityType === 'work_out' && $currentTime < date('H:i:s', strtotime($shiftEnd . ' -' . $tolerance . ' minutes'))) {
                    $isEarlyLeave = 1;
                    $needsReason = 1;
                }
            }
            
            // Get current location from browser (if available)
            $currentLat = $_POST['current_lat'] ?? null;
            $currentLng = $_POST['current_lng'] ?? null;
            
            // Collect device information
            $deviceMacAddress = $_POST['device_mac'] ?? null;
            $deviceIpAddress = $_SERVER['REMOTE_ADDR'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? null;
            $deviceUserAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
            $deviceFingerprint = $_POST['device_fingerprint'] ?? null;
            $devicePlatform = $_POST['device_platform'] ?? null;
            $deviceBrowser = $_POST['device_browser'] ?? null;
            
            // Validate location if coordinates are provided
            $locationValid = 1;
            $distanceError = '';
            
            if ($currentLat && $currentLng) {
                $qrLat = $qrData['latitude'];
                $qrLng = $qrData['longitude'];
                
                // Calculate distance using Haversine formula
                $earthRadius = 6371000; // Earth radius in meters
                $dLat = deg2rad($qrLat - $currentLat);
                $dLng = deg2rad($qrLng - $currentLng);
                $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($currentLat)) * cos(deg2rad($qrLat)) * sin($dLng/2) * sin($dLng/2);
                $c = 2 * atan2(sqrt($a), sqrt(1-$a));
                $distance = $earthRadius * $c;
                
                // Check if within 100 meter tolerance
                if ($distance > 100) {
                    $locationValid = 0;
                    $distanceError = "Konum doğrulaması başarısız! İşyeri QR kodundan " . round($distance) . " metre uzaktasınız. (Maksimum 100m)";
                }
            }
            
            if (!$locationValid) {
                $message = $distanceError;
                $messageType = "error";
            } else {
                // Get location_id from QR data - COMPREHENSIVE FIX for location_id error
                $locationId = null;
                
                // Try multiple ways to get location_id
                if (isset($qrData['location_id'])) {
                    $locationId = $qrData['location_id'];
                } elseif (isset($qrData['id'])) {
                    $locationId = $qrData['id'];
                } elseif (isset($qrData['qr_location_id'])) {
                    $locationId = $qrData['qr_location_id'];
                }
                
                // Debug information
                error_log("QR Data Keys: " . implode(', ', array_keys($qrData)));
                error_log("Location ID extracted: " . ($locationId ?? 'NULL'));
                
                if (!$locationId) {
                    // Show detailed error with available data
                    $available_keys = implode(', ', array_keys($qrData));
                    $error_details = "QR kod verilerinde location_id bulunamadı.\n";
                    $error_details .= "Mevcut alanlar: $available_keys\n";
                    $error_details .= "QR tarama işlemini tekrar yapın.";
                    throw new Exception($error_details);
                }
                
                // Insert attendance activity record with device information
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (employee_id, qr_location_id, activity_id, check_in_time, latitude, longitude, distance_meters, notes,
                     device_mac_address, device_ip_address, device_user_agent, device_fingerprint, device_platform, device_browser) 
                    VALUES (?, ?, (SELECT id FROM attendance_activities WHERE activity_type = ? AND company_id = ? LIMIT 1), NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $distanceMeters = ($currentLat && $currentLng) ? round($distance, 2) : null;
                $notes = "QR kod ile " . $qrData['location_name'] . " lokasyonunda kayıt - Cihaz: " . ($devicePlatform ?? 'Bilinmiyor');
                
                $stmt->execute([
                    $employeeId,
                    $locationId,
                    $activityType,
                    $employee['company_id'],
                    $currentLat,
                    $currentLng,
                    $distanceMeters,
                    $notes,
                    $deviceMacAddress,
                    $deviceIpAddress,
                    $deviceUserAgent,
                    $deviceFingerprint,
                    $devicePlatform,
                    $deviceBrowser
                ]);
                
                // Clear QR scan data from session
                unset($_SESSION['qr_scan_data']);
                
                $recordId = $conn->lastInsertId();
                $message = "✅ Aktivite başarıyla kaydedildi! (Kayıt ID: #$recordId)";
                $messageType = "success";
                
                // Redirect to employee dashboard after showing success
                echo "<script>
                    setTimeout(() => { 
                        window.location.href = '../dashboard/employee-dashboard.php?success=1&record_id=$recordId'; 
                    }, 3000);
                </script>";
            }
            
        } catch (Exception $e) {
            error_log("Activity selection error: " . $e->getMessage());
            $message = "❌ Kayıt hatası: " . $e->getMessage();
            $messageType = "error";
        }
    }
}

// Get available activity types
try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM activity_types WHERE company_id = ? OR company_id IS NULL ORDER BY sort_order, name");
    $stmt->execute([$_SESSION['company_id'] ?? 1]);
    $activityTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $activityTypes = [
        ['name' => 'İş Giriş', 'icon' => '🏢', 'color' => 'green'],
        ['name' => 'İş Çıkış', 'icon' => '🚪', 'color' => 'red'],
        ['name' => 'Yemek Başlangıç', 'icon' => '🍽️', 'color' => 'blue'],
        ['name' => 'Yemek Bitiş', 'icon' => '✅', 'color' => 'blue'],
        ['name' => 'Sigara Molası Başlangıç', 'icon' => '🚬', 'color' => 'yellow'],
        ['name' => 'Sigara Molası Bitiş', 'icon' => '⏰', 'color' => 'yellow'],
        ['name' => 'Çay Molası Başlangıç', 'icon' => '☕', 'color' => 'orange'],
        ['name' => 'Çay Molası Bitiş', 'icon' => '⏰', 'color' => 'orange']
    ];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktivite Seçimi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <div class="text-center mb-6">
            <div class="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-3xl">📋</span>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Aktivite Seçimi</h1>
            <p class="text-gray-600 mt-2">Ne yaptığınızı seçin ve kaydedin</p>
        </div>

        <!-- QR Location Info -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="font-semibold text-gray-900">📍 Lokasyon</h3>
                    <p class="text-lg text-indigo-600 font-medium"><?php echo htmlspecialchars($qrData['location_name']); ?></p>
                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($qrData['description'] ?? ''); ?></p>
                </div>
                <div class="text-right">
                    <p class="text-sm text-gray-500">Zaman</p>
                    <p class="font-medium"><?php echo date('H:i'); ?></p>
                    <p class="text-sm text-gray-500"><?php echo date('d.m.Y'); ?></p>
                </div>
            </div>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-red-100 text-red-800 border border-red-200'; ?>">
                <?php echo htmlspecialchars($message); ?>
                <?php if ($messageType === 'success'): ?>
                    <div class="mt-2 text-sm">Personel paneline yönlendiriliyorsunuz...</div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Activity Selection Form -->
        <form method="POST" id="activityForm" class="space-y-4">
            <!-- Hidden location and device fields -->
            <input type="hidden" id="current_lat" name="current_lat">
            <input type="hidden" id="current_lng" name="current_lng">
            <input type="hidden" id="device_mac" name="device_mac">
            <input type="hidden" id="device_fingerprint" name="device_fingerprint">
            <input type="hidden" id="device_platform" name="device_platform">
            <input type="hidden" id="device_browser" name="device_browser">
            
            <!-- Activity Types Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php foreach ($activityTypes as $activity): ?>
                    <label class="activity-option cursor-pointer">
                        <input type="radio" name="activity_type" value="<?php echo htmlspecialchars($activity['name']); ?>" class="sr-only">
                        <div class="bg-white rounded-xl border-2 border-gray-200 p-6 hover:border-indigo-500 hover:bg-indigo-50 transition-all duration-200 activity-card">
                            <div class="text-center">
                                <div class="text-4xl mb-3"><?php echo $activity['icon'] ?? '📝'; ?></div>
                                <h3 class="font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($activity['name']); ?></h3>
                                <?php if (!empty($activity['description'])): ?>
                                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($activity['description']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </label>
                <?php endforeach; ?>
            </div>

            <!-- Submit Button -->
            <div class="mt-8">
                <button 
                    type="submit" 
                    id="submitBtn"
                    disabled
                    class="w-full bg-gray-400 text-white py-4 px-6 rounded-xl font-semibold text-lg disabled:cursor-not-allowed transition-colors duration-200"
                >
                    Aktivite Seçin
                </button>
            </div>
        </form>

        <!-- Bottom Actions -->
        <div class="mt-6 text-center space-y-3">
            <a href="scanner.php" class="inline-block text-indigo-600 hover:text-indigo-500 font-medium">
                ← Yeni QR Kod Okut
            </a>
            <br>
            <a href="../dashboard/employee-dashboard.php" class="inline-block text-gray-600 hover:text-gray-500">
                Personel Paneli
            </a>
        </div>
    </div>

    <script>
        // Device Information Collection
        function collectDeviceInfo() {
            // Generate device fingerprint
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillText('Device fingerprint', 2, 2);
            const canvasFingerprint = canvas.toDataURL();
            
            // Get platform information
            const platform = navigator.platform || navigator.userAgentData?.platform || 'Unknown';
            const userAgent = navigator.userAgent;
            
            // Browser detection
            let browser = 'Unknown';
            if (userAgent.indexOf('Chrome') > -1) browser = 'Chrome';
            else if (userAgent.indexOf('Firefox') > -1) browser = 'Firefox';
            else if (userAgent.indexOf('Safari') > -1) browser = 'Safari';
            else if (userAgent.indexOf('Edge') > -1) browser = 'Edge';
            else if (userAgent.indexOf('Opera') > -1) browser = 'Opera';
            
            // Create device fingerprint hash
            const deviceData = platform + userAgent + screen.width + screen.height + navigator.language;
            const fingerprint = btoa(deviceData).substring(0, 32);
            
            // Set hidden form fields
            document.getElementById('device_fingerprint').value = fingerprint;
            document.getElementById('device_platform').value = platform;
            document.getElementById('device_browser').value = browser;
            
            console.log('📱 Cihaz Bilgileri Toplandı:', {
                platform: platform,
                browser: browser,
                fingerprint: fingerprint
            });
            
            // Try to get MAC address (limited support)
            tryGetMacAddress();
        }
        
        // Attempt to get MAC address (modern browsers have limitations)
        function tryGetMacAddress() {
            if ('bluetooth' in navigator) {
                // Bluetooth API (limited access)
                navigator.bluetooth.getAvailability().then(available => {
                    if (available) {
                        console.log('📶 Bluetooth mevcut (MAC adresi sınırlı erişim)');
                    }
                }).catch(err => {
                    console.log('📶 Bluetooth erişimi yok');
                });
            }
            
            // Network information API (if available)
            if ('connection' in navigator) {
                const connection = navigator.connection;
                console.log('🌐 Ağ Bilgisi:', {
                    type: connection.effectiveType,
                    downlink: connection.downlink,
                    rtt: connection.rtt
                });
            }
            
            // WebRTC local IP (limited in modern browsers)
            try {
                const rtc = new RTCPeerConnection({iceServers: []});
                rtc.createDataChannel('');
                rtc.createOffer().then(offer => rtc.setLocalDescription(offer));
                rtc.onicecandidate = function(event) {
                    if (event.candidate) {
                        const candidate = event.candidate.candidate;
                        const ipRegex = /(\d+\.\d+\.\d+\.\d+)/;
                        const match = candidate.match(ipRegex);
                        if (match) {
                            console.log('🔍 Yerel IP bulundu:', match[1]);
                        }
                    }
                };
            } catch (err) {
                console.log('🔍 WebRTC IP tespiti başarısız');
            }
        }
        
        // Get user location on page load
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    document.getElementById('current_lat').value = position.coords.latitude;
                    document.getElementById('current_lng').value = position.coords.longitude;
                    console.log('📍 Konum alındı:', position.coords.latitude, position.coords.longitude);
                },
                function(error) {
                    console.warn('📍 Konum alınamadı:', error.message);
                },
                {
                    enableHighAccuracy: 1,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        }
        
        // Initialize device info collection on page load
        document.addEventListener('DOMContentLoaded', function() {
            collectDeviceInfo();
        });

        // Activity selection handling
        const activityOptions = document.querySelectorAll('input[name="activity_type"]');
        const submitBtn = document.getElementById('submitBtn');
        const activityCards = document.querySelectorAll('.activity-card');

        activityOptions.forEach((option, index) => {
            option.addEventListener('change', function() {
                // Reset all cards
                activityCards.forEach(card => {
                    card.classList.remove('border-indigo-500', 'bg-indigo-50', 'ring-2', 'ring-indigo-500');
                    card.classList.add('border-gray-200');
                });

                // Highlight selected card
                if (this.checked) {
                    const selectedCard = activityCards[index];
                    selectedCard.classList.remove('border-gray-200');
                    selectedCard.classList.add('border-indigo-500', 'bg-indigo-50', 'ring-2', 'ring-indigo-500');
                    
                    // Enable submit button
                    submitBtn.disabled = 0;
                    submitBtn.className = 'w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 px-6 rounded-xl font-semibold text-lg transition-colors duration-200';
                    submitBtn.textContent = '✅ Kaydet ve Devam Et';
                }
            });
        });

        // Form submission handling
        document.getElementById('activityForm').addEventListener('submit', function(e) {
            const selectedActivity = document.querySelector('input[name="activity_type"]:checked');
            if (!selectedActivity) {
                e.preventDefault();
                alert('Lütfen bir aktivite seçin.');
                return;
            }

            // Show loading state
            submitBtn.disabled = 1;
            submitBtn.textContent = '⏳ Kaydediliyor...';
            submitBtn.className = 'w-full bg-gray-400 text-white py-4 px-6 rounded-xl font-semibold text-lg cursor-not-allowed';
        });
    </script>
</body>
</html>