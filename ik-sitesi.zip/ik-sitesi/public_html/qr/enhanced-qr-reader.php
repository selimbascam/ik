<?php
// Enhanced QR Reader with DeepSeek Analysis Implementation
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/attendance-helper.php';
require_once '../includes/qr-attendance-fixed.php';

// Session already started in config.php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/employee-login.php');
    exit;
}

$message = '';
$messageType = '';

// Handle QR code scanning
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qrCode = trim($_POST['qr_code'] ?? '');
    
    if (!empty($qrCode)) {
        error_log("Enhanced QR Reader - Received QR code: '$qrCode'");
        
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Begin transaction for data integrity
            $conn->beginTransaction();
            
            // Get employee info first
            $employeeId = $_SESSION['employee_id'];
            
            // Get employee's company_id from database (more reliable than session)
            $stmt = $conn->prepare("SELECT company_id, employee_number FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            $companyId = $employee['company_id'] ?? null;
            
            // Emergency company assignment if needed
            if (!$companyId) {
                // Find first available company
                $stmt = $conn->prepare("SELECT id FROM companies WHERE status = 'active' ORDER BY id LIMIT 1");
                $stmt->execute();
                $defaultCompany = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($defaultCompany) {
                    $companyId = $defaultCompany['id'];
                    
                    // Update employee record with company
                    $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
                    $stmt->execute([$companyId, $employeeId]);
                    
                    error_log("Emergency fix applied: Employee $employeeId assigned to company $companyId");
                } else {
                    // Create a default company if none exists
                    $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, status, created_at) 
                                           VALUES (?, ?, ?, ?, 'active', NOW())");
                    $stmt->execute(['SZB Default Company', 'admin@szb.com.tr', '555-0123', 'Default company address']);
                    $companyId = $conn->lastInsertId();
                    
                    // Update employee record with new company
                    $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
                    $stmt->execute([$companyId, $employeeId]);
                    
                    error_log("Emergency company created: New company $companyId for employee $employeeId");
                }
            }
            
            // Verify company exists and is active
            $stmt = $conn->prepare("SELECT id FROM companies WHERE id = ? AND status = 'active'");
            $stmt->execute([$companyId]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$company) {
                throw new Exception('Şirket bulunamadı veya aktif değil. Lütfen yöneticinizle iletişime geçin.');
            }
            
            // Parse QR code data - support multiple formats
            $locationId = null;
            $qrData = json_decode($qrCode, true);
            
            if ($qrData && isset($qrData['location_id'])) {
                $locationId = intval($qrData['location_id']);
            } elseif (is_numeric($qrCode)) {
                $locationId = intval($qrCode);
            } else {
                // Get first available location from database
                $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = ? AND status = 'active' LIMIT 1");
                $stmt->execute([$companyId]);
                $defaultLocation = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$defaultLocation) {
                    throw new Exception('Bu şirket için tanımlanmış QR lokasyonu bulunamadı.');
                }
                
                $locationId = $defaultLocation['id'];
            }
            
            // Verify location exists and belongs to company
            $stmt = $conn->prepare("SELECT id, name, location_type, gate_behavior 
                                   FROM qr_locations 
                                   WHERE id = ? AND company_id = ? AND status = 'active'");
            $stmt->execute([$locationId, $companyId]);
            $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$qrLocation) {
                throw new Exception("Geçersiz QR lokasyonu. Lokasyon ID: $locationId bulunamadı veya bu şirkete ait değil.");
            }
            
            // Determine gate behavior with intelligent fallback
            $gateBehavior = $qrLocation['gate_behavior'] ?? 'user_choice';
            
            // Smart gate behavior determination based on location name
            if ($gateBehavior === 'user_choice') {
                $qrName = mb_strtolower(trim($qrLocation['name']), 'UTF-8');
                
                // Turkish character normalization
                $qrName = str_replace(['İ', 'I'], 'i', $qrName);
                $qrName = str_replace(['Ğ'], 'ğ', $qrName);
                $qrName = str_replace(['Ü'], 'ü', $qrName);
                $qrName = str_replace(['Ş'], 'ş', $qrName);
                $qrName = str_replace(['Ö'], 'ö', $qrName);
                $qrName = str_replace(['Ç'], 'ç', $qrName);
                
                // Intelligent behavior determination
                if (strpos($qrName, 'mola') !== false || strpos($qrName, 'break') !== false) {
                    $gateBehavior = 'break_toggle';
                } elseif (strpos($qrName, 'giriş') !== false || strpos($qrName, 'giris') !== false || 
                          strpos($qrName, 'entrance') !== false || strpos($qrName, 'entry') !== false) {
                    $gateBehavior = 'work_start';
                } elseif (strpos($qrName, 'çıkış') !== false || strpos($qrName, 'cikis') !== false || 
                          strpos($qrName, 'exit') !== false) {
                    $gateBehavior = 'work_end';
                } else {
                    $gateBehavior = 'user_choice';
                }
            }
            
            // Determine activity type using enhanced logic
            $activityType = QRAttendanceHelper::determineGateAction($conn, $employeeId, $companyId, $locationId, $gateBehavior);
            
            // Check if we have GPS column support
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $hasLatitude = in_array('latitude', $columns);
            $hasLongitude = in_array('longitude', $columns);
            
            // Insert attendance record with proper column mapping
            if ($hasLatitude && $hasLongitude) {
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (company_id, employee_id, qr_location_id, activity_type, check_in_time, 
                     latitude, longitude, notes, created_at, date) 
                    VALUES (?, ?, ?, ?, NOW(), ?, ?, ?, NOW(), CURDATE())
                ");
                
                $stmt->execute([
                    $companyId,
                    $employeeId,
                    $locationId,
                    $activityType,
                    $qrData['latitude'] ?? null,
                    $qrData['longitude'] ?? null,
                    "Enhanced QR - " . $qrLocation['name'] . " (" . $employee['employee_number'] . ")"
                ]);
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (company_id, employee_id, qr_location_id, activity_type, check_in_time, 
                     notes, created_at, date) 
                    VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
                ");
                
                $stmt->execute([
                    $companyId,
                    $employeeId,
                    $locationId,
                    $activityType,
                    "Enhanced QR - " . $qrLocation['name'] . " (" . $employee['employee_number'] . ")"
                ]);
            }
            
            // Commit transaction
            $conn->commit();
            
            // Success message with smart feedback
            $activityMessages = [
                'work_in' => '🟢 İşe giriş yapıldı',
                'work_out' => '🔴 İşten çıkış yapıldı', 
                'work_start' => '🟢 İşe giriş yapıldı',
                'work_end' => '🔴 İşten çıkış yapıldı',
                'break_start' => '🟡 Mola başlatıldı',
                'break_end' => '🟢 Mola bitirildi'
            ];
            
            $message = "✅ " . ($activityMessages[$activityType] ?? 'Kayıt oluşturuldu') . 
                       " - " . $qrLocation['name'] . 
                       " (" . date('H:i') . ")";
            $messageType = "success";
            
            // Auto-redirect for better UX
            header("refresh:3;url=../employee/dashboard.php");
            
        } catch (Exception $e) {
            // Rollback transaction on error
            if (isset($conn) && $conn->inTransaction()) {
                $conn->rollback();
            }
            
            // Log error for debugging
            error_log("Enhanced QR Reader Error: " . $e->getMessage());
            
            $message = "❌ QR kod işleme hatası: " . $e->getMessage();
            $messageType = "error";
        }
    } else {
        $message = "❌ Lütfen geçerli bir QR kodu okutun.";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gelişmiş QR Kod Okuyucu - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/jsqr@1.4.0/dist/jsQR.js"></script>
    <style>
        .camera-container {
            position: relative;
            width: 100%;
            height: 64vh;
            max-height: 400px;
            overflow: hidden;
            border-radius: 12px;
        }
        .scanning-line {
            position: absolute;
            height: 2px;
            width: 100%;
            background: linear-gradient(90deg, transparent, #00ff00, transparent);
            animation: scan 2s linear infinite;
            box-shadow: 0 0 10px #00ff00;
        }
        @keyframes scan {
            0% { top: 0; }
            100% { top: 100%; }
        }
        .pulse {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6 max-w-md">
        <!-- Header -->
        <div class="text-center mb-6">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">🔍 Gelişmiş QR Okuyucu</h1>
            <p class="text-gray-600">DeepSeek Enhanced - Akıllı Devam Takibi</p>
        </div>

        <!-- Success/Error Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 border border-green-300 text-green-800' : 'bg-red-100 border border-red-300 text-red-800'; 
            ?> shadow-sm">
                <div class="flex items-center">
                    <div class="text-lg mr-2">
                        <?php echo $messageType === 'success' ? '✅' : '❌'; ?>
                    </div>
                    <div><?php echo $message; ?></div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Enhanced Camera Scanner -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6 border border-gray-200">
            <h3 class="font-semibold text-gray-900 mb-4 flex items-center">
                📷 Multi-Kamera QR Tarayıcı
                <span class="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Enhanced</span>
            </h3>
            
            <!-- Camera preview container -->
            <div class="camera-container mb-4 border-2 border-gray-200 bg-gray-50">
                <video id="video" class="w-full h-full bg-black rounded-lg" style="display: none;"></video>
                <canvas id="canvas" style="display: none;"></canvas>
                
                <!-- Camera placeholder -->
                <div id="placeholder" class="w-full h-full bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-200 transition-colors">
                    <div class="text-center">
                        <div class="text-5xl mb-3 pulse">📷</div>
                        <p class="text-gray-600 font-medium">Kamerayı başlatmak için tıklayın</p>
                        <p class="text-gray-500 text-sm mt-1">QR kodu taramaya hazır</p>
                    </div>
                </div>

                <!-- Enhanced scanning line -->
                <div id="scanningLine" class="scanning-line" style="display: none;"></div>
            </div>

            <!-- Enhanced Camera Selection -->
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                    🎥 Kamera Seçimi
                </label>
                <select id="cameraSelect" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">🔄 Kameralar yükleniyor...</option>
                </select>
            </div>

            <!-- Enhanced Camera controls -->
            <div class="flex gap-3 mb-4">
                <button id="startBtn" class="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 px-4 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition-all shadow-md">
                    📷 Kamerayı Başlat
                </button>
                <button id="stopBtn" class="flex-1 bg-gradient-to-r from-red-600 to-red-700 text-white py-3 px-4 rounded-lg font-semibold hover:from-red-700 hover:to-red-800 transition-all shadow-md" style="display: none;">
                    ⏹️ Durdur
                </button>
                <button id="switchBtn" class="bg-gradient-to-r from-yellow-600 to-yellow-700 text-white py-3 px-3 rounded-lg font-semibold hover:from-yellow-700 hover:to-yellow-800 transition-all shadow-md" style="display: none;" title="Kamera Değiştir">
                    🔄
                </button>
            </div>

            <!-- Enhanced Status Display -->
            <div id="status" class="text-center p-3 bg-gray-50 rounded-lg text-gray-600 font-medium border"></div>
        </div>

        <!-- Hidden form for QR submission -->
        <form method="POST" id="qrForm" style="display: none;">
            <input type="hidden" id="qrCode" name="qr_code">
        </form>

        <!-- Enhanced Navigation -->
        <div class="text-center space-y-3">
            <a href="../employee/dashboard.php" class="block bg-gradient-to-r from-gray-600 to-gray-700 text-white py-3 px-4 rounded-lg hover:from-gray-700 hover:to-gray-800 transition-all shadow-md">
                ← Personel Dashboard
            </a>
            <div class="text-xs text-gray-500 flex items-center justify-center">
                <span class="mr-1">⚡</span>
                DeepSeek Enhanced QR System v2.0
            </div>
        </div>
    </div>

    <script>
        let stream = null;
        let scanning = 0;
        let cameras = [];
        let currentCameraIndex = 0;
        
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');
        const placeholder = document.getElementById('placeholder');
        const scanningLine = document.getElementById('scanningLine');
        const startBtn = document.getElementById('startBtn');
        const stopBtn = document.getElementById('stopBtn');
        const switchBtn = document.getElementById('switchBtn');
        const cameraSelect = document.getElementById('cameraSelect');
        const status = document.getElementById('status');
        
        // Enhanced camera loading with device prioritization
        async function loadCameras() {
            try {
                status.textContent = '🔍 Kameralar aranıyor...';
                const devices = await navigator.mediaDevices.enumerateDevices();
                cameras = devices.filter(device => device.kind === 'videoinput');
                
                // Enhanced camera sorting: back cameras first
                cameras.sort((a, b) => {
                    const aIsBack = a.label.toLowerCase().includes('back') || 
                                   a.label.toLowerCase().includes('environment') ||
                                   a.label.toLowerCase().includes('rear');
                    const bIsBack = b.label.toLowerCase().includes('back') || 
                                   b.label.toLowerCase().includes('environment') ||
                                   b.label.toLowerCase().includes('rear');
                    if (aIsBack && !bIsBack) return -1;
                    if (!aIsBack && bIsBack) return 1;
                    return 0;
                });
                
                // Enhanced camera dropdown with better labeling
                cameraSelect.innerHTML = cameras.map((camera, index) => {
                    let label = camera.label || `Kamera ${index + 1}`;
                    let emoji = '📷';
                    
                    if (label.toLowerCase().includes('back') || label.toLowerCase().includes('environment') || label.toLowerCase().includes('rear')) {
                        emoji = '📷';
                        label += ' (Arka)';
                    } else if (label.toLowerCase().includes('front') || label.toLowerCase().includes('user') || label.toLowerCase().includes('selfie')) {
                        emoji = '🤳';
                        label += ' (Ön)';
                    }
                    
                    return `<option value="${index}">${emoji} ${label}</option>`;
                }).join('');
                
                status.textContent = `✅ ${cameras.length} kamera bulundu`;
                console.log('Enhanced QR: Cameras loaded:', cameras.length);
                
            } catch (err) {
                console.error('Camera loading error:', err);
                cameraSelect.innerHTML = '<option value="">❌ Kamera listesi alınamadı</option>';
                status.textContent = '❌ Kamera erişim hatası';
            }
        }

        // Enhanced camera start with better error handling
        async function startCamera() {
            console.log('Enhanced QR: Starting camera...');
            status.textContent = '📷 Kamera başlatılıyor...';
            
            try {
                const selectedIndex = parseInt(cameraSelect.value) || 0;
                currentCameraIndex = selectedIndex;
                
                let constraints;
                if (cameras.length > 0 && cameras[selectedIndex]) {
                    // Use specific camera with enhanced constraints
                    constraints = {
                        video: { 
                            deviceId: { exact: cameras[selectedIndex].deviceId },
                            width: { ideal: 1280 },
                            height: { ideal: 720 }
                        }
                    };
                    console.log('Using camera:', cameras[selectedIndex].label);
                } else {
                    // Enhanced fallback to environment camera
                    constraints = {
                        video: { 
                            facingMode: 'environment',
                            width: { ideal: 1280 },
                            height: { ideal: 720 }
                        }
                    };
                    console.log('Using fallback environment camera');
                }
                
                stream = await navigator.mediaDevices.getUserMedia(constraints);
                console.log('Enhanced QR: Camera stream acquired');
                
                video.srcObject = stream;
                video.play();
                
                // Enhanced UI updates
                placeholder.style.display = 'none';
                video.style.display = 'block';
                scanningLine.style.display = 'block';
                startBtn.style.display = 'none';
                stopBtn.style.display = 'block';
                switchBtn.style.display = cameras.length > 1 ? 'block' : 'none';
                status.textContent = '🔍 QR kod aranıyor... (Akıllı tarama aktif)';
                
                // Start enhanced scanning
                video.onloadedmetadata = () => {
                    console.log('Enhanced QR: Video ready, starting scan');
                    scanning = 1;
                    scan();
                };
                
            } catch (err) {
                console.error('Enhanced camera error:', err);
                
                // Enhanced fallback logic
                if (cameras.length > 0 && currentCameraIndex < cameras.length - 1) {
                    console.log('Trying next camera...');
                    currentCameraIndex++;
                    cameraSelect.value = currentCameraIndex;
                    setTimeout(startCamera, 500);
                    return;
                }
                
                status.textContent = '❌ Kamera hatası: ' + err.message;
                alert('Kamera erişimi başarısız: ' + err.message + '\n\nLütfen tarayıcı izinlerini kontrol edin.');
            }
        }
        
        // Enhanced stop camera function
        function stopCamera() {
            console.log('Enhanced QR: Stopping camera...');
            scanning = 0;
            
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            
            // Enhanced UI cleanup
            video.style.display = 'none';
            scanningLine.style.display = 'none';
            placeholder.style.display = 'flex';
            stopBtn.style.display = 'none';
            switchBtn.style.display = 'none';
            startBtn.style.display = 'block';
            status.textContent = 'Kamera durduruldu';
        }
        
        // Enhanced QR code scanning with better detection
        function scan() {
            if (!scanning || video.readyState !== video.HAVE_ENOUGH_DATA) {
                if (scanning) requestAnimationFrame(scan);
                return;
            }
            
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height, {
                inversionAttempts: "dontInvert",
            });
            
            if (code) {
                console.log('Enhanced QR code found:', code.data);
                status.textContent = '✅ QR kod bulundu! İşleniyor...';
                
                // Enhanced user feedback
                scanningLine.style.background = 'linear-gradient(90deg, transparent, #00ff00, transparent)';
                
                // Stop camera
                stopCamera();
                
                // Submit form with enhanced data
                document.getElementById('qrCode').value = code.data;
                document.getElementById('qrForm').submit();
            } else {
                requestAnimationFrame(scan);
            }
        }
        
        // Enhanced camera switching
        function switchCamera() {
            if (cameras.length <= 1) return;
            
            stopCamera();
            currentCameraIndex = (currentCameraIndex + 1) % cameras.length;
            cameraSelect.value = currentCameraIndex;
            setTimeout(startCamera, 500);
        }

        // Enhanced event listeners
        startBtn.addEventListener('click', startCamera);
        stopBtn.addEventListener('click', stopCamera);
        switchBtn.addEventListener('click', switchCamera);
        placeholder.addEventListener('click', startCamera);
        
        // Enhanced camera selection change
        cameraSelect.addEventListener('change', () => {
            if (stream) {
                stopCamera();
                setTimeout(startCamera, 500);
            }
        });
        
        // Enhanced initialization
        document.addEventListener('DOMContentLoaded', async () => {
            status.textContent = '🚀 Sistem başlatılıyor...';
            
            try {
                // Request permission first for better camera labels
                const tempStream = await navigator.mediaDevices.getUserMedia({ video: true });
                tempStream.getTracks().forEach(track => track.stop());
                await loadCameras();
                status.textContent = '✅ Sistem hazır - Kamerayı başlatabilirsiniz';
            } catch (err) {
                console.log('Permission denied, loading cameras without labels');
                await loadCameras();
                status.textContent = '⚠️ Kamera izni gerekli - Başlatmak için tıklayın';
            }
        });
        
        // Enhanced cleanup
        window.addEventListener('beforeunload', stopCamera);
        
        console.log('Enhanced QR Reader v2.0 initialized with DeepSeek analysis');
    </script>
</body>
</html>