<?php
header("Location: qr-reader.php");
exit;
?>