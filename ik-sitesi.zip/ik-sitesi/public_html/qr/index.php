<?php
// Redirect to QR reader
header('Location: qr-reader.php');
exit;
?>