<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if user is logged in
if (!isset($_SESSION['company_id'])) {
    header('Location: ../index.php');
    exit;
}

$company_id = $_SESSION['company_id'];

// Get QR system status
$status_data = [
    'timestamp' => date('Y-m-d H:i:s'),
    'company_id' => $company_id,
    'qr_locations' => [],
    'recent_activities' => [],
    'system_health' => []
];

try {
    // Get QR locations for this company
    $locations_stmt = $pdo->prepare("
        SELECT id, location_name, gate_behavior, latitude, longitude, 
               location_tolerance, is_active, created_at
        FROM qr_locations 
        WHERE company_id = ? 
        ORDER BY location_name
    ");
    $locations_stmt->execute([$company_id]);
    $status_data['qr_locations'] = $locations_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get recent attendance activities
    $activities_stmt = $pdo->prepare("
        SELECT ar.*, e.first_name, e.last_name, ql.location_name, aa.activity_name
        FROM attendance_records ar
        JOIN employees e ON ar.employee_id = e.id
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id
        WHERE e.company_id = ?
        ORDER BY ar.created_at DESC
        LIMIT 10
    ");
    $activities_stmt->execute([$company_id]);
    $status_data['recent_activities'] = $activities_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // System health checks
    $health_checks = [
        'database_connection' => $pdo ? 'OK' : 'FAILED',
        'qr_locations_count' => count($status_data['qr_locations']),
        'active_locations' => count(array_filter($status_data['qr_locations'], function($loc) { return $loc['is_active']; })),
        'jsqr_available' => 'CHECK_CLIENT_SIDE',
        'camera_api' => 'CHECK_CLIENT_SIDE'
    ];
    
    $status_data['system_health'] = $health_checks;
    
} catch (Exception $e) {
    $status_data['error'] = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Sistem Durumu - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/jsqr@1.4.0/dist/jsQR.js"></script>
</head>
<body class="bg-gray-100 min-h-screen py-8">
    <div class="container mx-auto px-4">
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h1 class="text-2xl font-bold text-gray-900 mb-4">📊 QR Sistem Durumu</h1>
            <div class="text-sm text-gray-500">Son Güncelleme: <?= $status_data['timestamp'] ?></div>
        </div>

        <!-- System Health -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">🏥 Sistem Sağlığı</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="p-4 bg-green-50 rounded-lg">
                    <div class="text-green-800 font-semibold">Veritabanı</div>
                    <div class="text-green-600"><?= $status_data['system_health']['database_connection'] ?></div>
                </div>
                <div class="p-4 bg-blue-50 rounded-lg">
                    <div class="text-blue-800 font-semibold">QR Lokasyonları</div>
                    <div class="text-blue-600">
                        <?= $status_data['system_health']['active_locations'] ?>/<?= $status_data['system_health']['qr_locations_count'] ?> Aktif
                    </div>
                </div>
                <div class="p-4 bg-yellow-50 rounded-lg">
                    <div class="text-yellow-800 font-semibold">Browser Desteği</div>
                    <div id="browserSupport" class="text-yellow-600">Kontrol ediliyor...</div>
                </div>
            </div>
        </div>

        <!-- QR Locations -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📍 QR Lokasyonları</h3>
            <?php if (!empty($status_data['qr_locations'])): ?>
            <div class="space-y-3">
                <?php foreach ($status_data['qr_locations'] as $location): ?>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                        <div class="font-medium"><?= htmlspecialchars($location['location_name']) ?></div>
                        <div class="text-sm text-gray-600">
                            Gate Behavior: <?= htmlspecialchars($location['gate_behavior']) ?>
                            | Tolerans: <?= $location['location_tolerance'] ?>m
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="px-2 py-1 text-xs rounded-full <?= $location['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                            <?= $location['is_active'] ? 'Aktif' : 'Pasif' ?>
                        </span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8 text-gray-500">
                Henüz QR lokasyonu tanımlanmamış.
                <div class="mt-2">
                    <a href="../admin/qr-management.php" class="text-blue-600 hover:underline">QR Yönetimi'ne git</a>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Recent Activities -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">📋 Son Aktiviteler</h3>
            <?php if (!empty($status_data['recent_activities'])): ?>
            <div class="space-y-3">
                <?php foreach ($status_data['recent_activities'] as $activity): ?>
                <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                        <div class="font-medium">
                            <?= htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']) ?>
                        </div>
                        <div class="text-sm text-gray-600">
                            <?= htmlspecialchars($activity['activity_name'] ?? 'Bilinmeyen Aktivite') ?>
                            @ <?= htmlspecialchars($activity['location_name'] ?? 'Bilinmeyen Lokasyon') ?>
                        </div>
                    </div>
                    <div class="text-right text-sm text-gray-500">
                        <?= date('d.m.Y H:i', strtotime($activity['created_at'])) ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8 text-gray-500">
                Henüz aktivite kaydı bulunmuyor.
            </div>
            <?php endif; ?>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">🚀 Hızlı İşlemler</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                <a href="enhanced-qr-scanner.php" class="block p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                    <div class="font-semibold text-green-900">🚀 Gelişmiş Tarayıcı</div>
                    <div class="text-xs text-green-700">En yeni QR okuyucu</div>
                </a>
                <a href="new-qr-reader.php" class="block p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                    <div class="font-semibold text-blue-900">📱 Yeni Okuyucu</div>
                    <div class="text-xs text-blue-700">İyileştirilmiş tarama</div>
                </a>
                <a href="qr-test-simple.php" class="block p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors">
                    <div class="font-semibold text-yellow-900">🧪 Basit Test</div>
                    <div class="text-xs text-yellow-700">Minimal test ortamı</div>
                </a>
                <a href="camera-test-debug.html" target="_blank" class="block p-4 bg-red-50 rounded-lg hover:bg-red-100 transition-colors">
                    <div class="font-semibold text-red-900">🐛 Debug Test</div>
                    <div class="text-xs text-red-700">Detaylı kamera testi</div>
                </a>
            </div>
        </div>
    </div>

    <script>
        // Check browser capabilities
        document.addEventListener('DOMContentLoaded', function() {
            const browserSupport = document.getElementById('browserSupport');
            
            let supportStatus = [];
            
            // Check getUserMedia
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                supportStatus.push('Kamera ✓');
            } else {
                supportStatus.push('Kamera ✗');
            }
            
            // Check jsQR
            if (typeof jsQR !== 'undefined') {
                supportStatus.push('jsQR ✓');
            } else {
                supportStatus.push('jsQR ✗');
            }
            
            // Check canvas
            const canvas = document.createElement('canvas');
            if (canvas.getContext && canvas.getContext('2d')) {
                supportStatus.push('Canvas ✓');
            } else {
                supportStatus.push('Canvas ✗');
            }
            
            browserSupport.textContent = supportStatus.join(' | ');
            
            // Update color based on support
            const allSupported = supportStatus.every(s => s.includes('✓'));
            if (allSupported) {
                browserSupport.className = 'text-green-600';
                browserSupport.parentElement.className = 'p-4 bg-green-50 rounded-lg';
            } else {
                browserSupport.className = 'text-red-600';
                browserSupport.parentElement.className = 'p-4 bg-red-50 rounded-lg';
            }
        });
    </script>
</body>
</html>