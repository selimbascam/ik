<?php
// Add Device Information Columns to attendance_records table
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>📱 Cihaz Bilgileri Sütunları Ekleme</h1>";
echo "<p>Attendance Records tablosuna cihaz bilgileri ekleniyor...</p><hr>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if columns already exist
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $existingColumns = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $existingColumns[] = $row['Field'];
    }
    
    $columnsToAdd = [
        'device_mac_address' => "VARCHAR(17) NULL COMMENT 'MAC adresi (AA:BB:CC:DD:EE:FF format)'",
        'device_ip_address' => "VARCHAR(45) NULL COMMENT 'IP adresi (IPv4/IPv6)'",
        'device_user_agent' => "TEXT NULL COMMENT 'Tarayıcı ve cihaz bilgileri'",
        'device_fingerprint' => "VARCHAR(255) NULL COMMENT 'Cihaz parmak izi'",
        'device_platform' => "VARCHAR(50) NULL COMMENT 'İşletim sistemi (Android, iOS, Windows, Mac)'",
        'device_browser' => "VARCHAR(100) NULL COMMENT 'Tarayıcı bilgisi'"
    ];
    
    $addedColumns = [];
    $existingColumnsFound = [];
    
    foreach ($columnsToAdd as $columnName => $columnDefinition) {
        if (!in_array($columnName, $existingColumns)) {
            $sql = "ALTER TABLE attendance_records ADD COLUMN $columnName $columnDefinition";
            $conn->exec($sql);
            $addedColumns[] = $columnName;
            echo "✅ Eklendi: $columnName<br>";
        } else {
            $existingColumnsFound[] = $columnName;
            echo "⚠️ Zaten var: $columnName<br>";
        }
    }
    
    // Verify the changes
    echo "<hr><h3>📋 Tablo Yapısı Kontrolü</h3>";
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background: #f0f0f0;'><th>Sütun Adı</th><th>Veri Tipi</th><th>Null</th><th>Varsayılan</th><th>Açıklama</th></tr>";
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $isNew = in_array($row['Field'], $addedColumns);
        $rowStyle = $isNew ? "background: #d4edda;" : "";
        echo "<tr style='$rowStyle'>";
        echo "<td>" . ($isNew ? "🆕 " : "") . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . ($row['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . ($row['Comment'] ?? '') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<hr><h3>📊 Özet</h3>";
    echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 5px;'>";
    echo "<strong>Eklenen sütunlar:</strong> " . count($addedColumns) . "<br>";
    foreach ($addedColumns as $col) {
        echo "• $col<br>";
    }
    
    if (!empty($existingColumnsFound)) {
        echo "<br><strong>Zaten mevcut sütunlar:</strong> " . count($existingColumnsFound) . "<br>";
        foreach ($existingColumnsFound as $col) {
            echo "• $col<br>";
        }
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px;'>";
    echo "<strong>Hata:</strong> " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p>İşlem tamamlandı: " . date('Y-m-d H:i:s') . "</p>";
echo "<p><a href='qr/activity-selection.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>QR Aktivite Sayfasını Test Et</a></p>";
?>