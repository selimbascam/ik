<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>QR Session Debug</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #f5f5f5; }
        .info { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .success { color: green; }
        .error { color: red; }
        .warning { color: orange; }
    </style>
</head>
<body>
<h1>🔍 QR Session & Database Debug</h1>

<div class="info">
<h3>📋 Session Information</h3>
<pre>
<?php
echo "Session Status: " . (session_status() === PHP_SESSION_ACTIVE ? "✅ Active" : "❌ Inactive") . "\n";
echo "Session ID: " . session_id() . "\n\n";

echo "Session Variables:\n";
foreach ($_SESSION as $key => $value) {
    echo "  $key = " . (is_array($value) ? json_encode($value) : $value) . "\n";
}

if (empty($_SESSION)) {
    echo "⚠️ No session variables found!\n";
}
?>
</pre>
</div>

<div class="info">
<h3>🗄️ Database Check</h3>
<pre>
<?php
try {
    $db = new Database();
    $conn = $db->getConnection();
    echo "✅ Database connection successful\n\n";
    
    // Check companies table
    echo "Companies table:\n";
    $stmt = $conn->query("SELECT id, name FROM companies LIMIT 5");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($companies as $company) {
        echo "  ID: {$company['id']}, Name: {$company['name']}\n";
    }
    
    echo "\nEmployees table (first 3):\n";
    $stmt = $conn->query("SELECT id, employee_number, first_name, last_name, company_id FROM employees LIMIT 3");
    $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($employees as $emp) {
        echo "  ID: {$emp['id']}, Name: {$emp['first_name']} {$emp['last_name']}, Company: {$emp['company_id']}\n";
    }
    
    echo "\nQR Locations table:\n";
    $stmt = $conn->query("SELECT id, name, company_id FROM qr_locations LIMIT 5");
    $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($locations as $loc) {
        echo "  ID: {$loc['id']}, Name: {$loc['name']}, Company: {$loc['company_id']}\n";
    }
    
} catch (Exception $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
}
?>
</pre>
</div>

<div class="info">
<h3>🧪 Test Foreign Key Constraints</h3>
<pre>
<?php
if (isset($_SESSION['employee_id'])) {
    $employeeId = $_SESSION['employee_id'];
    
    try {
        // Get employee's company_id
        $stmt = $conn->prepare("SELECT company_id FROM employees WHERE id = ?");
        $stmt->execute([$employeeId]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($employee) {
            $companyId = $employee['company_id'];
            echo "✅ Employee ID $employeeId belongs to Company ID $companyId\n";
            
            // Check if company exists
            $stmt = $conn->prepare("SELECT id, name FROM companies WHERE id = ?");
            $stmt->execute([$companyId]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                echo "✅ Company ID $companyId exists: {$company['name']}\n";
            } else {
                echo "❌ Company ID $companyId does NOT exist!\n";
            }
            
            // Check QR locations for this company
            $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ?");
            $stmt->execute([$companyId]);
            $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "\nQR Locations for Company $companyId:\n";
            foreach ($locations as $loc) {
                echo "  ID: {$loc['id']}, Name: {$loc['name']}\n";
            }
            
            if (empty($locations)) {
                echo "⚠️ No QR locations found for this company!\n";
            }
            
        } else {
            echo "❌ Employee ID $employeeId not found!\n";
        }
        
    } catch (Exception $e) {
        echo "❌ Test error: " . $e->getMessage() . "\n";
    }
} else {
    echo "⚠️ No employee_id in session - user not logged in\n";
}
?>
</pre>
</div>

<p><a href="/index.php">← Back to Home</a> | <a href="/auth/employee-login.php">Employee Login</a></p>
</body>
</html>