<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Enhanced session security
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 3600,
        'path' => '/',
        'domain' => '',
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

// Regenerate session ID to prevent fixation
if (empty($_SESSION)) {
    session_regenerate_id(true);
}

$message = '';
$messageType = '';

// Handle login with enhanced security
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($email) || empty($password)) {
        $message = "E-posta ve şifre gereklidir.";
        $messageType = 'error';
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Get available tables
            $stmt = $conn->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $companiesTable = in_array('companies', $tables) ? 'companies' : 
                             (in_array('şirketler', $tables) ? 'şirketler' : null);
            
            if (!$companiesTable) {
                throw new Exception("Şirketler tablosu bulunamadı.");
            }
            
            // Get column structure with enhanced mapping
            $stmt = $conn->query("SHOW COLUMNS FROM `$companiesTable`");
            $columnData = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $columns = array_column($columnData, 'Field');
            
            // Enhanced column mapping
            $emailCol = in_array('email', $columns) ? 'email' : 
                       (in_array('admin_email', $columns) ? 'admin_email' : 'email');
            $nameCol = in_array('company_name', $columns) ? 'company_name' : 
                      (in_array('name', $columns) ? 'name' : 'company_name');
            $activeCol = in_array('is_active', $columns) ? 'is_active' : 
                        (in_array('status', $columns) ? 'status' : null);
            
            // Ensure password column exists
            if (!in_array('password', $columns)) {
                try {
                    $conn->exec("ALTER TABLE `$companiesTable` ADD COLUMN password VARCHAR(255) DEFAULT NULL");
                    error_log("Enhanced Company Login: Added password column to $companiesTable");
                } catch (Exception $e) {
                    error_log("Enhanced Company Login: Password column add failed - " . $e->getMessage());
                }
            }
            
            // Find company by email
            $stmt = $conn->prepare("SELECT * FROM `$companiesTable` WHERE `$emailCol` = ?");
            $stmt->execute([$email]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                // Check if company is active
                $isActive = true;
                if ($activeCol && isset($company[$activeCol])) {
                    $isActive = ($company[$activeCol] == 1 || $company[$activeCol] === 'active');
                }
                
                if (!$isActive) {
                    $message = "Şirket hesabı aktif değil. Yöneticinizle iletişime geçin.";
                    $messageType = 'error';
                } else {
                    $passwordValid = false;
                    
                    // Enhanced password verification
                    if (empty($company['password'])) {
                        // First-time login - set password with Argon2ID
                        $hashedPassword = password_hash($password, PASSWORD_ARGON2ID, [
                            'memory_cost' => 65536,
                            'time_cost' => 4,
                            'threads' => 1
                        ]);
                        
                        $updateStmt = $conn->prepare("UPDATE `$companiesTable` SET password = ? WHERE id = ?");
                        $updateStmt->execute([$hashedPassword, $company['id']]);
                        
                        $passwordValid = true;
                        $message = "İlk girişiniz başarılı! Şifreniz güvenle kaydedildi.";
                        error_log("Enhanced Company Login: First-time password set for company " . $company['id']);
                        
                    } elseif (password_verify($password, $company['password'])) {
                        // Argon2ID/bcrypt verification (preferred)
                        $passwordValid = true;
                        error_log("Enhanced Company Login: Argon2ID verification success for company " . $company['id']);
                        
                    } elseif (md5($password) === $company['password']) {
                        // Legacy MD5 - upgrade to Argon2ID
                        $passwordValid = true;
                        $hashedPassword = password_hash($password, PASSWORD_ARGON2ID, [
                            'memory_cost' => 65536,
                            'time_cost' => 4,
                            'threads' => 1
                        ]);
                        
                        $updateStmt = $conn->prepare("UPDATE `$companiesTable` SET password = ? WHERE id = ?");
                        $updateStmt->execute([$hashedPassword, $company['id']]);
                        
                        error_log("Enhanced Company Login: MD5 password upgraded to Argon2ID for company " . $company['id']);
                        
                    } elseif ($password === $company['password']) {
                        // Plain text - upgrade to Argon2ID
                        $passwordValid = true;
                        $hashedPassword = password_hash($password, PASSWORD_ARGON2ID, [
                            'memory_cost' => 65536,
                            'time_cost' => 4,
                            'threads' => 1
                        ]);
                        
                        $updateStmt = $conn->prepare("UPDATE `$companiesTable` SET password = ? WHERE id = ?");
                        $updateStmt->execute([$hashedPassword, $company['id']]);
                        
                        error_log("Enhanced Company Login: Plain text password upgraded to Argon2ID for company " . $company['id']);
                    }
                    
                    if ($passwordValid) {
                        // Set enhanced session variables
                        setEnhancedCompanySession($company, $emailCol, $nameCol);
                        
                        $message = "Giriş başarılı! Yönlendiriliyor...";
                        $messageType = 'success';
                        
                        // Log successful login
                        error_log("Enhanced Company Login: Successful login for company " . $company['id'] . " from IP " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
                        
                        header("refresh:2;url=../admin/dashboard.php");
                        
                    } else {
                        $message = "Geçersiz şifre.";
                        $messageType = 'error';
                        error_log("Enhanced Company Login: Invalid password for email $email");
                    }
                }
            } else {
                $message = "Bu e-posta adresiyle kayıtlı şirket bulunamadı.";
                $messageType = 'error';
                error_log("Enhanced Company Login: Company not found for email $email");
            }
            
        } catch (Exception $e) {
            error_log("Enhanced Company Login error: " . $e->getMessage());
            $message = "Giriş işlemi sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyin.";
            $messageType = 'error';
        }
    }
}

// Enhanced session function
function setEnhancedCompanySession($company, $emailCol, $nameCol) {
    $_SESSION['user_id'] = $company['id'];
    $_SESSION['user_email'] = $company[$emailCol];
    $_SESSION['user_role'] = 'admin';
    $_SESSION['company_id'] = $company['id'];
    $_SESSION['company_name'] = $company[$nameCol] ?? 'Şirket';
    $_SESSION['company_code'] = $company['company_code'] ?? $company['code'] ?? $company['id'];
    $_SESSION['user_name'] = ($company[$nameCol] ?? 'Şirket') . ' Yöneticisi';
    $_SESSION['user_type'] = 'company';
    $_SESSION['login_type'] = 'company';
    $_SESSION['login_time'] = time();
    $_SESSION['session_id'] = session_id();
    
    // Enhanced security: regenerate session ID after successful login
    session_regenerate_id(true);
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Girişi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .login-card {
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
            border-radius: 16px;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .input-focus:focus {
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.3);
            transform: translateY(-1px);
            transition: all 0.2s ease;
        }
        .success-message {
            background: linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%);
            color: #22543d;
            border: 1px solid #9ae6b4;
        }
        .error-message {
            background: linear-gradient(135deg, #fff5f5 0%, #fed7d7 100%);
            color: #742a2a;
            border: 1px solid #feb2b2;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }
        .floating-label {
            transition: all 0.2s ease;
        }
        .pulse-glow {
            animation: pulse-glow 2s ease-in-out infinite alternate;
        }
        @keyframes pulse-glow {
            from { box-shadow: 0 0 20px rgba(102, 126, 234, 0.3); }
            to { box-shadow: 0 0 30px rgba(102, 126, 234, 0.6); }
        }
    </style>
</head>
<body class="gradient-bg flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full">
        <div class="login-card p-8 pulse-glow">
            <!-- Enhanced Header -->
            <div class="text-center mb-8">
                <div class="w-20 h-20 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <i class="fas fa-building text-blue-600 text-3xl"></i>
                </div>
                <h1 class="text-3xl font-bold text-gray-900 mb-2">Gelişmiş Şirket Girişi</h1>
                <p class="text-gray-600">SZB İK Takip - DeepSeek Enhanced</p>
                <div class="mt-2 flex items-center justify-center">
                    <span class="text-xs bg-gradient-to-r from-blue-500 to-purple-500 text-white px-3 py-1 rounded-full">
                        <i class="fas fa-shield-alt mr-1"></i>Argon2ID Güvenlik
                    </span>
                </div>
            </div>

            <!-- Enhanced Messages -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg <?php 
                    echo $messageType === 'success' ? 'success-message' : 'error-message'; 
                ?> shadow-md">
                    <div class="flex items-center">
                        <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle text-green-600' : 'fa-exclamation-circle text-red-600'; ?> mr-3 text-lg"></i>
                        <span class="font-medium"><?php echo htmlspecialchars($message); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Enhanced Login Form -->
            <form method="POST" class="space-y-6">
                <div class="space-y-5">
                    <div>
                        <label for="email" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-envelope mr-2 text-blue-500"></i>E-posta Adresi
                        </label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <i class="fas fa-at text-gray-400"></i>
                            </div>
                            <input type="email" id="email" name="email" required
                                   class="input-focus w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                                   placeholder="ornek@sirket.com"
                                   value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                        </div>
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-lock mr-2 text-blue-500"></i>Şifre
                        </label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                <i class="fas fa-key text-gray-400"></i>
                            </div>
                            <input type="password" id="password" name="password" required
                                   class="input-focus w-full pl-12 pr-12 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                                   placeholder="Güvenli şifrenizi girin">
                            <button type="button" onclick="togglePassword('password')" 
                                    class="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 transition-colors">
                                <i class="fas fa-eye" id="password-icon"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <input id="remember-me" name="remember-me" type="checkbox" 
                               class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded transition-colors">
                        <label for="remember-me" class="ml-2 block text-sm text-gray-700 font-medium">
                            Beni hatırla
                        </label>
                    </div>

                    <div class="text-sm">
                        <a href="../forgot-password.php" class="font-medium text-blue-600 hover:text-blue-800 transition-colors">
                            <i class="fas fa-question-circle mr-1"></i>Şifremi unuttum
                        </a>
                    </div>
                </div>

                <button type="submit" 
                        class="btn-primary w-full text-white py-3 px-6 rounded-lg font-semibold focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 shadow-lg">
                    <i class="fas fa-sign-in-alt mr-2"></i>Güvenli Giriş
                </button>
            </form>

            <!-- Enhanced Links -->
            <div class="mt-8 pt-6 border-t border-gray-200">
                <div class="text-center text-sm space-y-3">
                    <div>
                        <a href="../index.php" class="text-blue-600 hover:text-blue-800 font-medium transition-colors">
                            <i class="fas fa-home mr-1"></i>Ana Sayfa
                        </a>
                        <span class="mx-3 text-gray-300">|</span>
                        <a href="../super-admin/index.php" class="text-purple-600 hover:text-purple-800 font-medium transition-colors">
                            <i class="fas fa-user-shield mr-1"></i>Süper Admin
                        </a>
                    </div>
                    <div>
                        <a href="employee-login.php" class="text-green-600 hover:text-green-800 font-medium transition-colors">
                            <i class="fas fa-users mr-1"></i>Personel Girişi
                        </a>
                    </div>
                </div>
            </div>

            <!-- Enhanced Security Info -->
            <div class="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-100">
                <div class="text-center">
                    <p class="text-xs text-blue-800 font-medium mb-2">
                        <i class="fas fa-shield-alt mr-1"></i>
                        <strong>DeepSeek Enhanced Security</strong>
                    </p>
                    <div class="text-xs text-blue-700 space-y-1">
                        <div>✅ Argon2ID şifreleme</div>
                        <div>✅ Session güvenliği</div>
                        <div>✅ Otomatik şifre yükseltme</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Enhanced Footer -->
        <div class="mt-6 text-center">
            <p class="text-xs text-white opacity-80">
                © <?php echo date('Y'); ?> SZB İK Takip - Enhanced by DeepSeek AI
            </p>
        </div>
    </div>

    <script>
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const icon = document.getElementById('password-icon');
        
        if (field.type === 'password') {
            field.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            field.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }
    
    // Enhanced input animations
    document.addEventListener('DOMContentLoaded', function() {
        const inputs = document.querySelectorAll('input[type="email"], input[type="password"]');
        
        inputs.forEach(input => {
            input.addEventListener('focus', () => {
                input.parentElement.classList.add('transform', 'scale-105');
            });
            
            input.addEventListener('blur', () => {
                input.parentElement.classList.remove('transform', 'scale-105');
            });
        });
        
        // Auto-redirect on success message
        const successMessage = document.querySelector('.success-message');
        if (successMessage) {
            setTimeout(() => {
                successMessage.style.opacity = '0.7';
            }, 1500);
        }
    });
    
    // Form validation enhancement
    document.querySelector('form').addEventListener('submit', function(e) {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        if (!email || !password) {
            e.preventDefault();
            alert('Lütfen tüm alanları doldurun.');
            return;
        }
        
        // Show loading state
        const button = this.querySelector('button[type="submit"]');
        button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Giriş yapılıyor...';
        button.disabled = true;
    });
    </script>
</body>
</html>