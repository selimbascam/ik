<?php
require_once '../includes/config.php';

// Destroy session
session_destroy();

// Clear all session data
$_SESSION = array();

// Redirect to home page
header('Location: ../index.php');
exit;
?>