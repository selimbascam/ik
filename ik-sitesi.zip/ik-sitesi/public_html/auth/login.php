<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SZB İK Takip - Giriş</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            padding: 40px;
            max-width: 500px;
            width: 90%;
            text-align: center;
        }
        
        .logo {
            margin-bottom: 30px;
        }
        
        .logo h1 {
            color: #333;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .logo p {
            color: #666;
            font-size: 1.1em;
        }
        
        .login-options {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 40px;
        }
        
        .login-button {
            display: block;
            padding: 15px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-size: 1.1em;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .login-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        
        .login-button.employee {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        }
        
        .login-button.admin {
            background: linear-gradient(135deg, #fd746c 0%, #ff9068 100%);
        }
        
        .divider {
            margin: 30px 0;
            position: relative;
        }
        
        .divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #ddd;
        }
        
        .divider span {
            background: white;
            padding: 0 20px;
            color: #666;
            position: relative;
        }
        
        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }
            
            .logo h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <h1>🏢 SZB İK Takip</h1>
            <p>İnsan Kaynakları Yönetim Sistemi</p>
        </div>
        
        <div class="login-options">
            <a href="company-login.php" class="login-button">
                👔 Şirket Yönetici Girişi
            </a>
            
            <div class="divider">
                <span>veya</span>
            </div>
            
            <a href="employee-login.php" class="login-button employee">
                👤 Çalışan Girişi
            </a>
            
            <div class="divider">
                <span>yönetim</span>
            </div>
            
            <a href="../super-admin/" class="login-button admin">
                ⚙️ Sistem Yönetimi
            </a>
        </div>
    </div>
</body>
</html>