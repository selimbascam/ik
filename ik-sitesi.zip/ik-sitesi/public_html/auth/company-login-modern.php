<?php
// Modern Company Login - Enhanced with DeepSeek Design
require_once '../includes/config.php';
require_once '../includes/database.php';

// Enhanced session security
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 3600,
        'path' => '/',
        'domain' => '',
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

// Regenerate session ID to prevent fixation
if (empty($_SESSION)) {
    session_regenerate_id(true);
}

$message = '';
$messageType = '';

// Handle login with enhanced security
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($email) || empty($password)) {
        $message = "E-posta ve şifre gereklidir.";
        $messageType = 'error';
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Get available tables
            $stmt = $conn->query("SHOW TABLES");
            $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $companiesTable = in_array('companies', $tables) ? 'companies' : 
                             (in_array('şirketler', $tables) ? 'şirketler' : null);
            
            if (!$companiesTable) {
                throw new Exception("Şirketler tablosu bulunamadı.");
            }
            
            // Get column structure with enhanced mapping
            $stmt = $conn->query("SHOW COLUMNS FROM `$companiesTable`");
            $columnData = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $columns = array_column($columnData, 'Field');
            
            // Enhanced column mapping
            $emailCol = in_array('email', $columns) ? 'email' : 
                       (in_array('admin_email', $columns) ? 'admin_email' : 'email');
            $nameCol = in_array('company_name', $columns) ? 'company_name' : 
                      (in_array('name', $columns) ? 'name' : 'company_name');
            $activeCol = in_array('is_active', $columns) ? 'is_active' : 
                        (in_array('status', $columns) ? 'status' : null);
            
            // Ensure password column exists
            if (!in_array('password', $columns)) {
                try {
                    $conn->exec("ALTER TABLE `$companiesTable` ADD COLUMN password VARCHAR(255) DEFAULT NULL");
                    error_log("Modern Company Login: Added password column to $companiesTable");
                } catch (Exception $e) {
                    error_log("Modern Company Login: Password column add failed - " . $e->getMessage());
                }
            }
            
            // Find company by email
            $stmt = $conn->prepare("SELECT * FROM `$companiesTable` WHERE `$emailCol` = ?");
            $stmt->execute([$email]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                // Check active status
                $isActive = true;
                if ($activeCol) {
                    $isActive = ($activeCol === 'status') ? ($company[$activeCol] === 'active') : 
                               (bool)$company[$activeCol];
                }
                
                if (!$isActive) {
                    $message = "Şirket hesabınız aktif değil. Lütfen yönetici ile iletişime geçin.";
                    $messageType = 'error';
                } else {
                    // Enhanced password verification with automatic migration
                    $passwordValid = false;
                    
                    if (!empty($company['password'])) {
                        // Check if it's already hashed with Argon2ID
                        if (password_verify($password, $company['password'])) {
                            $passwordValid = true;
                        }
                        // Check if it's MD5 hash and migrate
                        elseif (strlen($company['password']) === 32 && md5($password) === $company['password']) {
                            $passwordValid = true;
                            // Migrate to Argon2ID
                            $hashedPassword = password_hash($password, PASSWORD_ARGON2ID, [
                                'memory_cost' => 65536,
                                'time_cost' => 4,
                                'threads' => 1
                            ]);
                            
                            $updateStmt = $conn->prepare("UPDATE `$companiesTable` SET password = ? WHERE id = ?");
                            $updateStmt->execute([$hashedPassword, $company['id']]);
                            
                            error_log("Modern Company Login: MD5 password migrated to Argon2ID for company " . $company['id']);
                        }
                        // Check if it's plain text password
                        elseif ($password === $company['password']) {
                            $passwordValid = true;
                            // Upgrade to Argon2ID
                            $hashedPassword = password_hash($password, PASSWORD_ARGON2ID, [
                                'memory_cost' => 65536,
                                'time_cost' => 4,
                                'threads' => 1
                            ]);
                            
                            $updateStmt = $conn->prepare("UPDATE `$companiesTable` SET password = ? WHERE id = ?");
                            $updateStmt->execute([$hashedPassword, $company['id']]);
                            
                            error_log("Modern Company Login: Plain text password upgraded to Argon2ID for company " . $company['id']);
                        }
                    }
                    
                    if ($passwordValid) {
                        // Set enhanced session variables
                        $_SESSION['user_id'] = $company['id'];
                        $_SESSION['user_email'] = $company[$emailCol];
                        $_SESSION['user_role'] = 'admin';
                        $_SESSION['company_id'] = $company['id'];
                        $_SESSION['company_name'] = $company[$nameCol] ?? 'Şirket';
                        $_SESSION['company_code'] = $company['company_code'] ?? $company['code'] ?? $company['id'];
                        $_SESSION['user_name'] = ($company[$nameCol] ?? 'Şirket') . ' Yöneticisi';
                        $_SESSION['user_type'] = 'company';
                        $_SESSION['login_type'] = 'company';
                        $_SESSION['login_time'] = time();
                        $_SESSION['session_id'] = session_id();
                        
                        // Enhanced security: regenerate session ID after successful login
                        session_regenerate_id(true);
                        
                        $message = "Giriş başarılı! Yönlendiriliyor...";
                        $messageType = 'success';
                        
                        // Log successful login
                        error_log("Modern Company Login: Successful login for company " . $company['id'] . " from IP " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
                        
                        header("refresh:1.5;url=../admin/dashboard.php");
                        
                    } else {
                        $message = "Geçersiz şifre.";
                        $messageType = 'error';
                        error_log("Modern Company Login: Invalid password for email $email");
                    }
                }
            } else {
                $message = "Bu e-posta adresiyle kayıtlı şirket bulunamadı.";
                $messageType = 'error';
                error_log("Modern Company Login: Company not found for email $email");
            }
            
        } catch (Exception $e) {
            error_log("Modern Company Login error: " . $e->getMessage());
            $message = "Giriş işlemi sırasında bir hata oluştu. Lütfen daha sonra tekrar deneyin.";
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Girişi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .login-card {
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
        }
        .input-focus:focus {
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
        }
        .success-message {
            background: #f0fff4;
            color: #22543d;
            border: 1px solid #9ae6b4;
        }
        .error-message {
            background: #fff5f5;
            color: #742a2a;
            border: 1px solid #feb2b2;
        }
        .password-toggle {
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .password-toggle:hover {
            color: #667eea;
        }
    </style>
</head>
<body class="gradient-bg flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full">
        <div class="login-card p-8">
            <!-- Header -->
            <div class="text-center mb-8">
                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-building text-blue-600 text-2xl"></i>
                </div>
                <h1 class="text-2xl font-bold text-gray-900">Şirket Girişi</h1>
                <p class="text-gray-600 mt-2">SZB İK Takip Sistemine Hoş Geldiniz</p>
            </div>

            <!-- Messages -->
            <?php if (!empty($message)): ?>
            <div class="<?php echo $messageType; ?>-message p-4 rounded-lg mb-6">
                <div class="flex items-center">
                    <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
                    <span><?php echo $message; ?></span>
                </div>
            </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" class="space-y-6">
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">E-posta</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input type="email" id="email" name="email" required
                               class="input-focus w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                               placeholder="admin@sirket.com"
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">Şifre</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" id="password" name="password" required
                               class="input-focus w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                               placeholder="Şifrenizi girin">
                        <button type="button" id="toggle-password" 
                                class="password-toggle absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <input id="remember-me" name="remember-me" type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="remember-me" class="ml-2 block text-sm text-gray-700">Beni hatırla</label>
                    </div>

                    <div class="text-sm">
                        <a href="#" class="font-medium text-blue-600 hover:text-blue-500">Şifremi unuttum</a>
                    </div>
                </div>

                <button type="submit" 
                        class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 font-medium transition duration-200">
                    <i class="fas fa-sign-in-alt mr-2"></i>Giriş Yap
                </button>
            </form>

            <!-- Links -->
            <div class="mt-6 text-center text-sm">
                <a href="../index.php" class="text-blue-600 hover:text-blue-800"><i class="fas fa-home mr-1"></i>Ana Sayfaya Dön</a>
                <span class="mx-2 text-gray-400">|</span>
                <a href="../admin/super-admin-login.php" class="text-purple-600 hover:text-purple-800"><i class="fas fa-user-shield mr-1"></i>Süper Admin</a>
            </div>

            <!-- Demo Info -->
            <div class="mt-6 p-4 bg-blue-50 rounded-md">
                <p class="text-xs text-blue-700 text-center">
                    <strong>Modern Design:</strong> DeepSeek tavsiyeli tasarım ile gelişmiş güvenlik özellikleri.
                </p>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="mt-6 text-center">
            <p class="text-xs text-white">© 2025 SZB İK Takip Sistemi. Tüm hakları saklıdır.</p>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const togglePasswordBtn = document.getElementById('toggle-password');
        const passwordInput = document.getElementById('password');
        
        // Toggle password visibility
        togglePasswordBtn.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            const icon = togglePasswordBtn.querySelector('i');
            if (type === 'text') {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
        
        // Add input animation
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('focus', () => {
                input.parentElement.classList.add('ring-2', 'ring-blue-500', 'rounded-md');
            });
            input.addEventListener('blur', () => {
                input.parentElement.classList.remove('ring-2', 'ring-blue-500', 'rounded-md');
            });
        });

        // Success message auto-redirect animation
        <?php if ($messageType === 'success'): ?>
        setTimeout(() => {
            const messageDiv = document.querySelector('.success-message');
            if (messageDiv) {
                messageDiv.innerHTML = '<div class="flex items-center"><i class="fas fa-spinner fa-spin mr-2"></i><span>Yönlendiriliyor...</span></div>';
            }
        }, 500);
        <?php endif; ?>
    });
    </script>
</body>
</html>