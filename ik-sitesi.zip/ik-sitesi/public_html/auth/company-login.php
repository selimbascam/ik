<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$message = '';
$messageType = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($email) || empty($password)) {
        $message = "E-posta ve şifre gereklidir.";
        $messageType = 'error';
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Simple company authentication
            $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
            $stmt->execute([$email]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                $validPassword = false;
                
                // Check different password formats
                if (!empty($company['password'])) {
                    // Try direct match
                    if ($company['password'] === $password) {
                        $validPassword = true;
                    }
                    // Try MD5 hash
                    elseif ($company['password'] === md5($password)) {
                        $validPassword = true;
                    }
                    // Try password_verify for PHP hashed passwords
                    elseif (password_verify($password, $company['password'])) {
                        $validPassword = true;
                    }
                } else {
                    // If no password set, set it for first-time login
                    $hashedPassword = md5($password);
                    $updateStmt = $conn->prepare("UPDATE companies SET password = ? WHERE id = ?");
                    $updateStmt->execute([$hashedPassword, $company['id']]);
                    $validPassword = true;
                }
                
                if ($validPassword) {
                    // Set session variables
                    $_SESSION['company_id'] = $company['id'];
                    $_SESSION['admin_email'] = $company['email'];
                    $_SESSION['company_name'] = $company['company_name'] ?? $company['name'] ?? 'Şirket';
                    $_SESSION['user_type'] = 'company';
                    $_SESSION['user_role'] = 'admin';
                    $_SESSION['user_id'] = $company['id'];
                    $_SESSION['user_email'] = $company['email'];
                    $_SESSION['user_name'] = ($_SESSION['company_name'] ?? 'Şirket') . ' Yöneticisi';
                    
                    // Redirect to admin dashboard
                    header("Location: ../admin/dashboard.php");
                    exit;
                } else {
                    $message = "Geçersiz şifre.";
                    $messageType = 'error';
                }
            } else {
                $message = "Bu e-posta adresi ile kayıtlı şirket bulunamadı.";
                $messageType = 'error';
            }
            
        } catch (Exception $e) {
            $message = "Giriş hatası: " . $e->getMessage();
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Girişi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i class="fas fa-building text-white text-2xl"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Şirket Girişi</h1>
            <p class="text-gray-600"><?php echo APP_NAME; ?> Admin Paneli</p>
        </div>

        <!-- Login Form -->
        <div class="bg-white rounded-xl shadow-xl p-8 border border-gray-100">
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg <?php 
                    echo $messageType === 'success' ? 'bg-green-100 border border-green-300 text-green-800' : 'bg-red-100 border border-red-300 text-red-800'; 
                ?> shadow-sm">
                    <div class="flex items-center">
                        <i class="<?php echo $messageType === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-triangle'; ?> mr-2"></i>
                        <div><?php echo $message; ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-envelope mr-1"></i>
                        E-posta Adresi
                    </label>
                    <input 
                        type="email" 
                        name="email" 
                        id="email"
                        value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                        placeholder="ornek@sirket.com"
                        required
                    >
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-lock mr-1"></i>
                        Şifre
                    </label>
                    <div class="relative">
                        <input 
                            type="password" 
                            name="password" 
                            id="password"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition duration-200"
                            placeholder="••••••••"
                            required
                        >
                        <button 
                            type="button" 
                            onclick="togglePassword()"
                            class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        >
                            <i id="password-icon" class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <button 
                    type="submit" 
                    class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition duration-200 font-medium shadow-lg hover:shadow-xl"
                >
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Giriş Yap
                </button>
            </form>

            <!-- Links -->
            <div class="mt-6 pt-6 border-t border-gray-200">
                <div class="text-center space-y-2">
                    <a href="../auth/employee-login.php" class="text-blue-600 hover:text-blue-800 text-sm block">
                        <i class="fas fa-user mr-1"></i>
                        Personel Girişi
                    </a>
                    <a href="../index.php" class="text-gray-500 hover:text-gray-700 text-sm block">
                        <i class="fas fa-home mr-1"></i>
                        Ana Sayfa
                    </a>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="text-center mt-6 text-gray-500 text-sm">
            <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. Tüm hakları saklıdır.</p>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }

        // Auto-focus on email field
        document.getElementById('email').focus();
    </script>
</body>
</html>