<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Session already started in config.php

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = $_POST['employee_id'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($employee_id) && !empty($password)) {
        try {
            // Force fresh MySQL connection
            $db = new Database();
            $conn = $db->getConnection();
            
            // Verify tables exist
            $stmt = $conn->query("SHOW TABLES LIKE 'employees'");
            if (!$stmt->fetch()) {
                throw new Exception("Employees tablosu bulunamadı. Lütfen veritabanını kontrol edin.");
            }
            
            // Check employee with detailed error handling
            try {
                // First check if password column exists
                $check_stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'password_hash'");
                if (!$check_stmt->fetch()) {
                    throw new Exception("Password_hash sütunu bulunamadı. Veritabanı güncellemesi gerekli.");
                }
                
                // Check companies table structure first
                $companyColumns = $conn->query("SHOW COLUMNS FROM companies")->fetchAll(PDO::FETCH_COLUMN);
                
                $companyNameField = 'id'; // Default fallback
                $companyCodeField = 'id'; // Default fallback
                
                if (in_array('company_name', $companyColumns)) {
                    $companyNameField = 'company_name';
                } elseif (in_array('name', $companyColumns)) {
                    $companyNameField = 'name';
                }
                
                if (in_array('company_code', $companyColumns)) {
                    $companyCodeField = 'company_code';
                }
                
                $stmt = $conn->prepare("
                    SELECT e.id, e.first_name, e.last_name, e.email, e.employee_code, 
                           e.company_id, 
                           c.{$companyNameField} as company_name, 
                           c.{$companyCodeField} as company_code
                    FROM employees e 
                    JOIN companies c ON e.company_id = c.id 
                    WHERE e.employee_code = ? AND e.password_hash = PASSWORD(?) AND e.is_active = TRUE
                ");
            } catch (PDOException $e) {
                // If password column doesn't exist, show helpful error
                if (strpos($e->getMessage(), 'password') !== false) {
                    $error = "Veritabanı hatası: Password sütunu bulunamadı. Lütfen /emergency-fix-database.php sayfasını ziyaret edin.";
                } else {
                    $error = "SQL Hatası: " . $e->getMessage();
                }
                throw new Exception($error);
            }
            $stmt->execute([$employee_id, $password]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($employee) {
                // Session already active, just set variables
                $_SESSION['employee_id'] = $employee['id'];
                $_SESSION['company_id'] = $employee['company_id'];
                $_SESSION['company_code'] = $employee['company_code'] ?? '';
                $_SESSION['company_name'] = $employee['company_name'] ?? '';
                $_SESSION['user_role'] = 'employee';
                $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
                $_SESSION['employee_code'] = $employee['employee_code'];
                
                // Log successful login for debugging
                error_log("Employee login successful - ID: {$employee['id']}, Session: " . session_id());
                
                header('Location: ../employee/dashboard.php');
                exit;
            } else {
                $error = "Geçersiz personel numarası veya şifre.";
            }
        } catch (Exception $e) {
            $error = "Bağlantı hatası: " . $e->getMessage();
            
            // Log the exact error for debugging
            error_log("Employee login error: " . $e->getMessage());
            
            // If it's a column error, show specific help
            if (strpos($e->getMessage(), 'password') !== false) {
                $error .= " <br><br><a href='../emergency-fix-database.php' style='color: #dc3545; font-weight: bold;'>🔧 Veritabanını Düzelt</a>";
            }
        }
    } else {
        $error = "Lütfen tüm alanları doldurun.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Girişi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>

</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">
    <div class="max-w-md w-full space-y-8 p-8">
        <div class="text-center">
            <div class="mx-auto h-16 w-16 bg-green-600 rounded-lg flex items-center justify-center mb-4">
                <span class="text-white font-bold text-2xl">P</span>
            </div>
            <h2 class="text-3xl font-bold text-gray-900">Personel Girişi</h2>
            <p class="mt-2 text-gray-600">Personel self servis paneline erişim</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form class="mt-8 space-y-6" method="POST">
            <div class="space-y-4">
                <div>
                    <label for="employee_id" class="block text-sm font-medium text-gray-700">Personel Numarası</label>
                    <input 
                        id="employee_id" 
                        name="employee_id" 
                        type="text" 
                        required 
                        class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                        placeholder="Personel numaranızı girin"
                        value="<?php echo htmlspecialchars($_POST['employee_id'] ?? ''); ?>"
                    >
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700">Şifre</label>
                    <div class="relative mt-1">
                        <input 
                            id="password" 
                            name="password" 
                            type="password" 
                            required 
                            class="block w-full px-3 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                            placeholder="••••••••"
                        >
                        <button type="button" onclick="togglePassword('password')" 
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                            <svg id="password-eye" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <div>
                <button 
                    type="submit"
                    class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                    Giriş Yap
                </button>
            </div>

            <div class="text-center space-y-2">
                <div>
                    <a href="forgot-password.php" class="text-green-600 hover:text-green-500 text-sm font-medium">
                        🔑 Şifremi Unuttum
                    </a>
                </div>
                <div>
                    <a href="../index.php" class="text-green-600 hover:text-green-500 text-sm">
                        ← Ana sayfaya dön
                    </a>
                </div>
            </div>
        </form>
    </div>

    <script>
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const eyeIcon = document.getElementById(fieldId + '-eye');
        
        if (field.type === 'password') {
            field.type = 'text';
            eyeIcon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
            `;
        } else {
            field.type = 'password';
            eyeIcon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            `;
        }
    }
    </script>
</body>
</html>