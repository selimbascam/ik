<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/email-config.php';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    
    if (empty($email)) {
        $message = "Lütfen e-posta adresinizi girin.";
        $messageType = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Geçerli bir e-posta adresi girin.";
        $messageType = "error";
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Check if email exists in companies table
            $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ?");
            $stmt->execute([$email]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                // Send company credentials
                $subject = "SZB İK Takip - Şirket Giriş Bilgileri";
                $content = "
                    <h2>Merhaba,</h2>
                    <p>Şirket giriş bilgilerinizi talep ettiniz. Aşağıda bilgilerinizi bulabilirsiniz:</p>
                    
                    <div class='credentials'>
                        <h3>Şirket Giriş Bilgileri</h3>
                        <p><strong>Şirket Adı:</strong> {$company['company_name']}</p>
                        <p><strong>Şirket Kodu:</strong> {$company['company_code']}</p>
                        <p><strong>E-posta:</strong> {$company['email']}</p>
                        <p><strong>Şifre:</strong> {$company['password']}</p>
                    </div>
                    
                    <p style='text-align: center;'>
                        <a href='" . BASE_URL . "/auth/company-login.php' class='button'>🏢 Şirket Paneline Giriş Yap</a>
                    </p>
                    
                    <div style='background-color: #fff3cd; padding: 15px; border-radius: 5px; border-left: 4px solid #ffc107;'>
                        <strong>Güvenlik Uyarısı:</strong><br>
                        Güvenliğiniz için giriş yaptıktan sonra şifrenizi değiştirmenizi öneririz.
                    </div>
                ";
                
                $emailBody = getEmailTemplate("Şirket Giriş Bilgileri", $content);
                
                if (sendAdvancedEmail($email, $subject, $emailBody)) {
                    $message = "✅ Şirket giriş bilgileriniz e-posta adresinize gönderildi.";
                    $messageType = "success";
                } else {
                    $message = "❌ E-posta gönderilemedi. Lütfen tekrar deneyin.";
                    $messageType = "error";
                }
            } else {
                // Check if email exists in employees table
                $stmt = $conn->prepare("
                    SELECT e.*, c.company_name 
                    FROM employees e 
                    JOIN companies c ON e.company_id = c.id 
                    WHERE e.email = ?
                ");
                $stmt->execute([$email]);
                $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($employee) {
                    // Send employee credentials
                    $subject = "SZB İK Takip - Personel Giriş Bilgileri";
                    $content = "
                        <h2>Merhaba {$employee['first_name']} {$employee['last_name']},</h2>
                        <p>Personel giriş bilgilerinizi talep ettiniz. Aşağıda bilgilerinizi bulabilirsiniz:</p>
                        
                        <div class='credentials'>
                            <h3>Personel Giriş Bilgileri</h3>
                            <p><strong>Şirket:</strong> {$employee['company_name']}</p>
                            <p><strong>Personel Numarası:</strong> {$employee['employee_code']}</p>
                            <p><strong>E-posta:</strong> {$employee['email']}</p>
                            <p><strong>Şifre:</strong> {$employee['password']}</p>
                        </div>
                        
                        <p style='text-align: center;'>
                            <a href='" . BASE_URL . "/auth/employee-login.php' class='button' style='background-color: #28a745;'>👤 Personel Paneline Giriş Yap</a>
                        </p>
                        
                        <div style='background-color: #d1ecf1; padding: 15px; border-radius: 5px; border-left: 4px solid #17a2b8;'>
                            <strong>QR Kod Giriş:</strong><br>
                            İşyerindeki QR kodları okutarak hızlı giriş-çıkış yapabilirsiniz.
                        </div>
                        
                        <div style='background-color: #fff3cd; padding: 15px; border-radius: 5px; border-left: 4px solid #ffc107; margin-top: 15px;'>
                            <strong>Güvenlik Uyarısı:</strong><br>
                            Güvenliğiniz için giriş yaptıktan sonra şifrenizi değiştirmenizi öneririz.
                        </div>
                    ";
                    
                    $emailBody = getEmailTemplate("Personel Giriş Bilgileri", $content);
                    
                    if (sendAdvancedEmail($email, $subject, $emailBody)) {
                        $message = "✅ Personel giriş bilgileriniz e-posta adresinize gönderildi.";
                        $messageType = "success";
                    } else {
                        $message = "❌ E-posta gönderilemedi. Lütfen tekrar deneyin.";
                        $messageType = "error";
                    }
                } else {
                    $message = "❌ Bu e-posta adresi sistemde kayıtlı değil.";
                    $messageType = "error";
                }
            }
            
        } catch (Exception $e) {
            $message = "❌ Sistem hatası: " . $e->getMessage();
            $messageType = "error";
        }
    }
}

// Email sending function - supports both PHP mail() and SMTP
function sendPasswordEmail($to, $subject, $htmlContent) {
    $from = "noreply@szbiktakip.com"; // Kendi domain'inizle değiştirin
    $fromName = "SZB İK Takip";
    
    // HTML e-posta için headers
    $headers = [
        "MIME-Version: 1.0",
        "Content-Type: text/html; charset=UTF-8",
        "From: {$fromName} <{$from}>",
        "Reply-To: {$from}",
        "X-Mailer: PHP/" . phpversion()
    ];
    
    // PHP'nin yerleşik mail() fonksiyonu ile gönder
    try {
        $success = mail($to, $subject, $htmlContent, implode("\r\n", $headers));
        
        if ($success) {
            error_log("Email sent successfully to: $to");
            return true;
        } else {
            error_log("Failed to send email to: $to");
            return false;
        }
    } catch (Exception $e) {
        error_log("Email sending error: " . $e->getMessage());
        return false;
    }
}

// Alternative SMTP function (uncomment if you want to use SMTP instead)
/*
function sendPasswordEmailSMTP($to, $subject, $htmlContent) {
    // SMTP ayarları - kendi sunucunuza göre düzenleyin
    $smtpHost = 'mail.yourdomain.com';
    $smtpPort = 587;
    $smtpUser = 'noreply@yourdomain.com';
    $smtpPass = 'your_email_password';
    
    // Basic SMTP implementation
    $socket = fsockopen($smtpHost, $smtpPort, $errno, $errstr, 30);
    if (!$socket) {
        error_log("SMTP connection failed: $errstr ($errno)");
        return false;
    }
    
    // SMTP komutları
    $commands = [
        "EHLO localhost\r\n",
        "AUTH LOGIN\r\n",
        base64_encode($smtpUser) . "\r\n",
        base64_encode($smtpPass) . "\r\n",
        "MAIL FROM: <$smtpUser>\r\n",
        "RCPT TO: <$to>\r\n",
        "DATA\r\n",
        "Subject: $subject\r\n",
        "From: SZB İK Takip <$smtpUser>\r\n",
        "Content-Type: text/html; charset=UTF-8\r\n",
        "\r\n",
        $htmlContent . "\r\n",
        ".\r\n",
        "QUIT\r\n"
    ];
    
    foreach ($commands as $command) {
        fwrite($socket, $command);
        usleep(100000); // 0.1 saniye bekle
    }
    
    fclose($socket);
    return true;
}
*/
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifremi Unuttum - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span class="text-white text-2xl font-bold">🔑</span>
            </div>
            <h1 class="text-3xl font-bold text-gray-900"><?php echo APP_NAME; ?></h1>
            <p class="text-gray-600 mt-2">Şifremi Unuttum</p>
        </div>

        <!-- Main Card -->
        <div class="bg-white rounded-2xl shadow-xl p-8">
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-red-100 text-red-800 border border-red-200'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                        E-posta Adresiniz
                    </label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        required
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                        placeholder="ornek@email.com"
                        value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                    >
                    <p class="text-sm text-gray-500 mt-2">
                        Sistemde kayıtlı e-posta adresinizi girin. Giriş bilgileriniz bu adrese gönderilecek.
                    </p>
                </div>

                <button 
                    type="submit"
                    class="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-200 font-semibold"
                >
                    🔑 Şifremi Gönder
                </button>
            </form>

            <!-- Links -->
            <div class="mt-6 text-center space-y-2">
                <div>
                    <a href="company-login.php" class="text-indigo-600 hover:text-indigo-500 text-sm font-medium">
                        ← Şirket Girişi
                    </a>
                </div>
                <div>
                    <a href="employee-login.php" class="text-green-600 hover:text-green-500 text-sm font-medium">
                        ← Personel Girişi
                    </a>
                </div>
                <div>
                    <a href="../index.php" class="text-gray-600 hover:text-gray-500 text-sm">
                        Ana Sayfa
                    </a>
                </div>
            </div>
        </div>

        <!-- Info Card -->
        <div class="mt-6 bg-white/80 backdrop-blur rounded-xl p-6">
            <h3 class="font-semibold text-gray-900 mb-3">💡 Bilgi</h3>
            <ul class="text-sm text-gray-600 space-y-2">
                <li class="flex items-start">
                    <span class="text-indigo-500 mr-2">•</span>
                    Şirket yöneticileri için şirket e-posta adresi
                </li>
                <li class="flex items-start">
                    <span class="text-green-500 mr-2">•</span>
                    Personel için kayıtlı e-posta adresi
                </li>
                <li class="flex items-start">
                    <span class="text-amber-500 mr-2">•</span>
                    E-posta birkaç dakika içinde gelecektir
                </li>
                <li class="flex items-start">
                    <span class="text-red-500 mr-2">•</span>
                    Spam klasörünü kontrol etmeyi unutmayın
                </li>
            </ul>
        </div>
    </div>
</body>
</html>