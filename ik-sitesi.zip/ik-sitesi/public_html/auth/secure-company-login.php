<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/security.php';
require_once '../includes/helpers.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if already logged in
if (isset($_SESSION['company_id']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'company') {
    header('Location: ../company/modern-dashboard.php');
    exit();
}

$message = '';
$messageType = '';
$loginAttempts = 0;

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF protection
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "Güvenlik hatası. Sayfayı yenileyin.";
        $messageType = 'error';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        
        if (empty($email) || empty($password)) {
            $message = "E-posta ve şifre gereklidir.";
            $messageType = 'error';
        } else {
            try {
                $db = new Database();
                $conn = $db->getConnection();
                
                // Rate limiting check
                $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                if (isRateLimited($conn, $clientIp, 'company_login')) {
                    $message = "Çok fazla başarısız giriş denemesi. Lütfen 15 dakika sonra tekrar deneyin.";
                    $messageType = 'error';
                } else {
                    // Determine the correct table name
                    $tables = [];
                    $stmt = $conn->query("SHOW TABLES");
                    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    $companiesTable = in_array('companies', $tables) ? 'companies' : 
                                     (in_array('şirketler', $tables) ? 'şirketler' : 'companies');
                    
                    // Get column structure for compatibility
                    try {
                        $stmt = $conn->query("SHOW COLUMNS FROM `$companiesTable`");
                        $columnData = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        $companyColumns = array_column($columnData, 'Field');
                    } catch (PDOException $e) {
                        throw new Exception("Companies table not found or inaccessible");
                    }
                    
                    // Map column names for compatibility
                    $emailCol = in_array('email', $companyColumns) ? 'email' : 
                               (in_array('admin_email', $companyColumns) ? 'admin_email' : 'email');
                               
                    $nameCol = in_array('company_name', $companyColumns) ? 'company_name' : 
                              (in_array('name', $companyColumns) ? 'name' : 'company_name');
                              
                    $activeCol = in_array('is_active', $companyColumns) ? 'is_active' : 
                                (in_array('status', $companyColumns) ? 'status' : 'is_active');
                    
                    // Check if password column exists
                    if (!in_array('password', $companyColumns)) {
                        $message = "Sistem yapılandırma hatası. Lütfen yöneticinizle iletişime geçin.";
                        $messageType = 'error';
                        logSecurityEvent($conn, 'company_login_config_error', $email, $clientIp);
                    } else {
                        // Find company by email
                        $stmt = execute_safe_query($conn, "SELECT * FROM `$companiesTable` WHERE `$emailCol` = ?", [$email]);
                        $company = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($company) {
                            // Check if company is active
                            $isActive = true;
                            if (isset($company[$activeCol])) {
                                $isActive = ($company[$activeCol] == 1 || $company[$activeCol] === 'active');
                            }
                            
                            if (!$isActive) {
                                $message = "Şirket hesabı aktif değil. Yöneticinizle iletişime geçin.";
                                $messageType = 'error';
                                logSecurityEvent($conn, 'company_login_inactive', $email, $clientIp);
                            } else {
                                // Verify password with secure methods
                                $passwordValid = false;
                                $needsUpgrade = false;
                                
                                // Priority 1: Check modern password_hash()
                                if (password_verify($password, $company['password'])) {
                                    $passwordValid = true;
                                } 
                                // Priority 2: Check Argon2ID (if we're using it)
                                else if (strpos($company['password'], '$argon2id$') === 0 && password_verify($password, $company['password'])) {
                                    $passwordValid = true;
                                }
                                // Priority 3: Legacy MD5 support (with immediate upgrade)
                                else if (strlen($company['password']) === 32 && md5($password) === $company['password']) {
                                    $passwordValid = true;
                                    $needsUpgrade = true;
                                }
                                // Priority 4: Plain text fallback (with immediate upgrade)
                                else if ($company['password'] === $password) {
                                    $passwordValid = true;
                                    $needsUpgrade = true;
                                }
                                
                                if ($passwordValid) {
                                    // Upgrade password if needed
                                    if ($needsUpgrade) {
                                        $hashedPassword = password_hash($password, PASSWORD_ARGON2ID, [
                                            'memory_cost' => 65536, // 64 MB
                                            'time_cost' => 4,       // 4 iterations
                                            'threads' => 3,        // 3 threads
                                        ]);
                                        $updateStmt = execute_safe_query($conn, 
                                            "UPDATE `$companiesTable` SET password = ? WHERE id = ?", 
                                            [$hashedPassword, $company['id']]
                                        );
                                        logSecurityEvent($conn, 'company_password_upgraded', $email, $clientIp);
                                    }
                                    
                                    // Successful login - Set secure session variables
                                    session_regenerate_id(true); // Prevent session fixation
                                    $_SESSION['company_id'] = $company['id'];
                                    $_SESSION['admin_email'] = $company[$emailCol];
                                    $_SESSION['company_name'] = $company[$nameCol] ?? 'Şirket';
                                    $_SESSION['user_type'] = 'company';
                                    $_SESSION['login_type'] = 'company';
                                    $_SESSION['login_time'] = time();
                                    $_SESSION['last_activity'] = time();
                                    
                                    // Log successful login
                                    logSecurityEvent($conn, 'company_login_success', $email, $clientIp);
                                    
                                    $message = "Giriş başarılı! Yönlendiriliyor...";
                                    $messageType = 'success';
                                    
                                    // Clear any rate limiting for this IP
                                    clearRateLimit($conn, $clientIp, 'company_login');
                                    
                                    // Redirect after successful login
                                    echo "<script>
                                        setTimeout(function() {
                                            window.location.href = '../company/modern-dashboard.php';
                                        }, 1500);
                                    </script>";
                                } else {
                                    $message = "Geçersiz şifre.";
                                    $messageType = 'error';
                                    
                                    // Log failed attempt and increment rate limiting
                                    logSecurityEvent($conn, 'company_login_failed_password', $email, $clientIp);
                                    incrementRateLimit($conn, $clientIp, 'company_login');
                                }
                            }
                        } else {
                            $message = "Bu e-posta adresi ile kayıtlı şirket bulunamadı.";
                            $messageType = 'error';
                            
                            // Log failed attempt
                            logSecurityEvent($conn, 'company_login_failed_email', $email, $clientIp);
                            incrementRateLimit($conn, $clientIp, 'company_login');
                        }
                    }
                }
            } catch (Exception $e) {
                error_log("Secure Company Login Error: " . $e->getMessage());
                $message = "Sistemde bir hata oluştu. Lütfen tekrar deneyin.";
                $messageType = 'error';
                
                // Log system error
                $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                logSecurityEvent($conn ?? null, 'company_login_system_error', $email ?? 'unknown', $clientIp, $e->getMessage());
            }
        }
    }
}

// Get current login attempts for display
try {
    $db = new Database();
    $conn = $db->getConnection();
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $loginAttempts = getRateLimitAttempts($conn, $clientIp, 'company_login');
} catch (Exception $e) {
    // Ignore for display purposes
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Güvenli Şirket Girişi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .password-toggle {
            cursor: pointer;
            transition: color 0.2s;
        }
        .password-toggle:hover {
            color: #4b5563;
        }
        .security-indicator {
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            font-weight: bold;
        }
        .security-high {
            background-color: #10b981;
            color: white;
        }
        .security-medium {
            background-color: #f59e0b;
            color: white;
        }
        .security-low {
            background-color: #ef4444;
            color: white;
        }
    </style>
</head>
<body class="gradient-bg min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full">
        <div class="bg-white rounded-lg shadow-xl p-8">
            <!-- Header -->
            <div class="text-center mb-8">
                <div class="text-4xl mb-4">🏢</div>
                <h1 class="text-2xl font-bold text-gray-900">Güvenli Şirket Girişi</h1>
                <p class="text-gray-600 mt-2">SZB İK Takip Sistemine Hoş Geldiniz</p>
                <div class="security-indicator security-high mt-3">GÜVENLI GIRIŞ</div>
            </div>

            <!-- Security Status -->
            <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div class="flex items-center text-sm text-green-700">
                    <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 1L5.5 5.5l1.414 1.414L10 3.828l3.086 3.086L14.5 5.5 10 1zM4.5 8.5L10 14l5.5-5.5-1.414-1.414L10 11.172 5.914 7.086 4.5 8.5z"/>
                    </svg>
                    <span>
                        <strong>Güvenlik:</strong> Argon2ID şifreleme, CSRF koruması, rate limiting aktif
                        <?php if ($loginAttempts > 0): ?>
                            <br><strong>Uyarı:</strong> <?php echo $loginAttempts; ?>/5 başarısız deneme
                        <?php endif; ?>
                    </span>
                </div>
            </div>

            <!-- Messages -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                        'bg-red-100 text-red-800 border border-red-200'; 
                ?>">
                    <div class="flex">
                        <div class="mr-2">
                            <?php echo $messageType === 'success' ? '✅' : '❌'; ?>
                        </div>
                        <div><?php echo safe_html($message); ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" class="space-y-6">
                <?php echo csrf_token_input(); ?>
                
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                        E-posta <span class="text-red-500">*</span>
                    </label>
                    <input type="email" id="email" name="email" required autocomplete="email"
                           class="w-full px-3 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                           placeholder="admin@sirket.com"
                           value="<?php echo safe_html($_POST['email'] ?? ''); ?>">
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                        Şifre <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <input type="password" id="password" name="password" required autocomplete="current-password"
                               class="w-full px-3 py-3 pr-12 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                               placeholder="Güvenli şifrenizi girin">
                        <button type="button" onclick="togglePassword('password')" 
                                class="absolute inset-y-0 right-0 pr-3 flex items-center password-toggle" tabindex="-1">
                            <svg id="password-eye" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Rate limiting warning -->
                <?php if ($loginAttempts >= 3): ?>
                    <div class="p-3 bg-yellow-50 text-yellow-800 border border-yellow-200 rounded-md text-sm">
                        <strong>Dikkat:</strong> <?php echo (5 - $loginAttempts); ?> hakkınız kaldı. 
                        5 başarısız denemeden sonra 15 dakika beklemeniz gerekecek.
                    </div>
                <?php endif; ?>

                <button type="submit" 
                        class="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition font-medium flex items-center justify-center"
                        <?php echo ($loginAttempts >= 5) ? 'disabled' : ''; ?>>
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                    </svg>
                    <?php echo ($loginAttempts >= 5) ? 'Giriş Engellendi' : 'Güvenli Giriş Yap'; ?>
                </button>
            </form>

            <!-- Links -->
            <div class="mt-6 text-center text-sm space-y-2">
                <div>
                    <a href="../index.php" class="text-blue-600 hover:text-blue-800 transition">Ana Sayfaya Dön</a>
                    <span class="mx-2 text-gray-400">|</span>
                    <a href="../auth/employee-login.php" class="text-green-600 hover:text-green-800 transition">Personel Girişi</a>
                </div>
                <div>
                    <a href="../super-admin/index.php" class="text-purple-600 hover:text-purple-800 transition">Süper Admin</a>
                </div>
            </div>

            <!-- Security Info -->
            <div class="mt-6 p-4 bg-gray-50 rounded-md">
                <p class="text-xs text-gray-600 text-center mb-2">
                    <strong>Güvenlik Özellikleri:</strong>
                </p>
                <div class="grid grid-cols-2 gap-2 text-xs text-gray-500">
                    <div class="flex items-center">
                        <span class="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                        Argon2ID Şifreleme
                    </div>
                    <div class="flex items-center">
                        <span class="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                        CSRF Koruması
                    </div>
                    <div class="flex items-center">
                        <span class="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                        Rate Limiting
                    </div>
                    <div class="flex items-center">
                        <span class="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                        Session Security
                    </div>
                </div>
            </div>

            <!-- Demo Info -->
            <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                <p class="text-xs text-blue-700 text-center">
                    <strong>Demo Giriş:</strong> test@szb.com.tr / 123456
                </p>
            </div>
        </div>
    </div>

    <script>
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const eyeIcon = document.getElementById(fieldId + '-eye');
        
        if (field.type === 'password') {
            field.type = 'text';
            eyeIcon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
            `;
        } else {
            field.type = 'password';
            eyeIcon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            `;
        }
    }

    // Auto-hide success messages
    <?php if ($messageType === 'success'): ?>
    setTimeout(function() {
        const successMsg = document.querySelector('.bg-green-100');
        if (successMsg) {
            successMsg.style.transition = 'opacity 0.5s';
            successMsg.style.opacity = '0';
            setTimeout(() => successMsg.remove(), 500);
        }
    }, 3000);
    <?php endif; ?>
    </script>
</body>
</html>