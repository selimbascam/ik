<?php
// Basit ve güvenilir personel girişi
session_start();

require_once '../includes/config.php';
require_once '../includes/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = trim($_POST['employee_id'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (!empty($employee_id) && !empty($password)) {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Basit personel arama
            $stmt = $conn->prepare("
                SELECT id, first_name, last_name, employee_number, company_id, password 
                FROM employees 
                WHERE employee_number = ? OR tc_no = ?
                LIMIT 1
            ");
            $stmt->execute([$employee_id, $employee_id]);
            $employee = $stmt->fetch();
            
            if ($employee) {
                // Şifre kontrolü
                $passwordValid = false;
                
                if (empty($employee['password'])) {
                    // Şifre yoksa giriş izni ver
                    $passwordValid = true;
                } elseif (password_verify($password, $employee['password'])) {
                    // Modern hash kontrolü
                    $passwordValid = true;
                } elseif ($employee['password'] === $password) {
                    // Düz metin şifre
                    $passwordValid = true;
                } elseif (md5($password) === $employee['password']) {
                    // MD5 hash
                    $passwordValid = true;
                }
                
                if ($passwordValid) {
                    // Session başarılı
                    $_SESSION['employee_id'] = $employee['id'];
                    $_SESSION['company_id'] = $employee['company_id'];
                    $_SESSION['user_type'] = 'employee';
                    $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
                    $_SESSION['employee_number'] = $employee['employee_number'];
                    
                    // Dashboard'a yönlendir
                    header('Location: ../employee/dashboard.php');
                    exit();
                } else {
                    $error = 'Şifre yanlış!';
                }
            } else {
                $error = 'Personel bulunamadı!';
            }
            
        } catch (Exception $e) {
            $error = 'Giriş hatası: ' . $e->getMessage();
        }
    } else {
        $error = 'Personel ID ve şifre gerekli!';
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Girişi - SZB İK Takip</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
            <h2 class="text-2xl font-bold text-center mb-6 text-gray-800">Personel Girişi</h2>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Personel Numarası / TC Kimlik No
                    </label>
                    <input 
                        type="text" 
                        name="employee_id" 
                        required 
                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Personel numaranızı girin"
                    >
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Şifre
                    </label>
                    <input 
                        type="password" 
                        name="password" 
                        required 
                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Şifrenizi girin"
                    >
                </div>
                
                <button 
                    type="submit" 
                    class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                    Giriş Yap
                </button>
            </form>
            
            <div class="mt-6 text-center">
                <a href="../index.php" class="text-sm text-blue-600 hover:underline">
                    Ana Sayfaya Dön
                </a>
            </div>
        </div>
    </div>
</body>
</html>