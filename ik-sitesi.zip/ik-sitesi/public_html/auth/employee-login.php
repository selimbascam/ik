<?php
// Session başlat - en başta olmalı
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../includes/config.php';
require_once '../includes/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = $_POST['employee_id'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // IMMEDIATE DEBUG
    echo "<!-- DEBUG: Login attempt with ID='$employee_id', Password='$password' -->";
    
    if (!empty($employee_id) && !empty($password)) {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // MySQL employee authentication with column safety checks
            try {
                // Check if required columns exist first
                $columnCheck = $conn->query("SHOW COLUMNS FROM employees")->fetchAll();
                $columns = array_column($columnCheck, 'Field');
                
                // Build safe query based on available columns
                $passwordField = '';
                if (in_array('password', $columns)) {
                    $passwordField = ', e.password';
                } elseif (in_array('password_hash', $columns)) {
                    $passwordField = ', e.password_hash as password';
                }
                
                $activeField = '';
                if (in_array('is_active', $columns)) {
                    $activeField = 'AND e.is_active = true';
                } elseif (in_array('status', $columns)) {
                    $activeField = "AND (e.status IS NULL OR e.status = '' OR e.status = 'active')";
                }
                
                // TC-Employee sync fields - all should be the same value
                $tcField = '';
                if (in_array('tc_no', $columns)) {
                    $tcField = ', e.tc_no';
                }
                
                $empNumberField = '';
                if (in_array('employee_number', $columns)) {
                    $empNumberField = 'e.employee_number';
                } elseif (in_array('employee_code', $columns)) {
                    $empNumberField = 'e.employee_code as employee_number';
                } else {
                    $empNumberField = "CONCAT('EMP', LPAD(e.id, 4, '0')) as employee_number";
                }
                
                $empCodeField = '';
                if (in_array('employee_code', $columns)) {
                    $empCodeField = ', e.employee_code';
                }
                
                // Search by TC, employee_number, or employee_code (should all be same)
                $whereClause = '';
                if (in_array('tc_no', $columns) && in_array('employee_number', $columns) && in_array('employee_code', $columns)) {
                    $whereClause = "e.tc_no = ? OR e.employee_number = ? OR e.employee_code = ?";
                } elseif (in_array('employee_number', $columns)) {
                    $whereClause = "e.employee_number = ?";
                } elseif (in_array('employee_code', $columns)) {
                    $whereClause = "e.employee_code = ?";
                } else {
                    $whereClause = "CONCAT('EMP', LPAD(e.id, 4, '0')) = ?";
                }
                
                $stmt = $conn->prepare("
                    SELECT e.id, e.first_name, e.last_name, e.email, {$empNumberField}, e.company_id{$passwordField}{$tcField}{$empCodeField}
                    FROM employees e 
                    WHERE {$whereClause} {$activeField}
                    LIMIT 1
                ");
                
                // Execute with appropriate number of parameters
                if (in_array('tc_no', $columns) && in_array('employee_number', $columns) && in_array('employee_code', $columns)) {
                    $stmt->execute([$employee_id, $employee_id, $employee_id]);
                } else {
                    $stmt->execute([$employee_id]);
                }
                
                $employee = $stmt->fetchAll();
                $employee = count($employee) > 0 ? $employee[0] : null;
                
                // If found, sync TC, employee_number, and employee_code to ensure consistency
                if ($employee && in_array('tc_no', $columns) && in_array('employee_number', $columns) && in_array('employee_code', $columns)) {
                    $syncStmt = $conn->prepare("
                        UPDATE employees 
                        SET tc_no = ?, employee_number = ?, employee_code = ?
                        WHERE id = ?
                    ");
                    $syncStmt->execute([$employee_id, $employee_id, $employee_id, $employee['id']]);
                    
                    // Update the employee array with synced values
                    $employee['tc_no'] = $employee_id;
                    $employee['employee_number'] = $employee_id;
                    $employee['employee_code'] = $employee_id;
                }
                
            } catch (Exception $e) {
                // Fallback query without problematic columns
                echo "<!-- DEBUG: Using fallback query due to error: " . $e->getMessage() . " -->";
                $stmt = $conn->prepare("
                    SELECT e.id, e.first_name, e.last_name, e.company_id, e.password,
                           COALESCE(e.employee_number, e.employee_code, CONCAT('EMP', LPAD(e.id, 4, '0'))) as employee_number
                    FROM employees e 
                    WHERE COALESCE(e.employee_number, e.employee_code, CONCAT('EMP', LPAD(e.id, 4, '0'))) = ?
                    LIMIT 1
                ");
                $stmt->execute([$employee_id]);
                $employee = $stmt->fetchAll();
                $employee = count($employee) > 0 ? $employee[0] : null;
            }
            
            // Check password if employee found
            if ($employee) {
                $passwordValid = false;
                
                // Enhanced password verification with debugging
                error_log("Employee Login Debug - Employee ID: {$employee['id']}, Password hash: " . substr($employee['password'] ?? 'NULL', 0, 20));
                
                // IMMEDIATE DEBUG - Show what we found
                echo "<!-- DEBUG: Employee found: ID={$employee['id']}, Name={$employee['first_name']} {$employee['last_name']}, Password=" . (empty($employee['password']) ? 'EMPTY' : 'EXISTS') . " -->";
                echo "<!-- DEBUG: Password value: '" . ($employee['password'] ?? 'NULL') . "' -->";
                
                // SIMPLIFIED: Always allow login if password is empty or null
                if (!$employee['password'] || $employee['password'] === '' || $employee['password'] === null || trim($employee['password'] ?? '') === '') {
                    // No password set - allow login for initial setup
                    $passwordValid = true;
                    error_log("Password check: No password set - allowing login");
                    echo "<!-- DEBUG: Empty password detected - LOGIN ALLOWED -->";
                } elseif (password_verify($password, $employee['password'])) {
                    // Argon2ID/bcrypt verification (preferred method)
                    $passwordValid = true;
                    error_log("Password check: Argon2ID/bcrypt verified SUCCESS");
                    echo "<!-- DEBUG: password_verify() SUCCESS - Argon2ID hash validated -->";
                } elseif ($employee['password'] === $password) {
                    // Plain text password match (legacy)
                    $passwordValid = true;
                    error_log("Password check: Plain text match");
                } elseif (md5($password) === $employee['password']) {
                    // MD5 hashed password match (legacy)
                    $passwordValid = true;
                    error_log("Password check: MD5 hash match");
                } elseif (hash('sha256', $password) === $employee['password']) {
                    // SHA256 hashed password match (legacy)
                    $passwordValid = true;
                    error_log("Password check: SHA256 hash match");
                } else {
                    // Check MySQL PASSWORD() function format - ENHANCED
                    try {
                        // Try both password and password_hash field
                        $passwordField = $employee['password'] ?? $employee['password_hash'] ?? '';
                        
                        $stmt = $conn->prepare("SELECT PASSWORD(?) as mysql_hash");
                        $stmt->execute([$password]);
                        $mysqlResult = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($mysqlResult && $mysqlResult['mysql_hash'] === $passwordField) {
                            $passwordValid = true;
                            error_log("Password check: MySQL PASSWORD() match SUCCESS");
                            echo "<!-- DEBUG: MySQL PASSWORD() verification SUCCESS -->";
                        } else {
                            echo "<!-- DEBUG: MySQL PASSWORD() - Expected: " . substr($passwordField, 0, 20) . "..., Got: " . substr($mysqlResult['mysql_hash'] ?? 'NULL', 0, 20) . "... -->";
                        }
                    } catch (Exception $e) {
                        error_log("MySQL PASSWORD() check failed: " . $e->getMessage());
                        echo "<!-- DEBUG: MySQL PASSWORD() check FAILED: " . $e->getMessage() . " -->";
                    }
                }
                
                // Additional logging for troubleshooting
                if (!$passwordValid) {
                    error_log("Password check FAILED for employee {$employee['id']} - All methods tried");
                    echo "<!-- DEBUG: Password validation FAILED -->";
                } else {
                    echo "<!-- DEBUG: Password validation SUCCESS -->";
                }
                
                if (!$passwordValid) {
                    $employee = null; // Invalid password
                }
            } else {
                // No employee found
                echo "<!-- DEBUG: NO EMPLOYEE FOUND with ID='$employee_id' -->";
                error_log("Employee Login Debug - NO EMPLOYEE FOUND with ID: $employee_id");
            }
            
            if ($employee) {
                // Get company info separately to avoid column conflicts
                try {
                    $compStmt = $conn->prepare("SELECT * FROM companies WHERE id = ?");
                    $compStmt->execute([$employee['company_id']]);
                    $company = $compStmt->fetch(PDO::FETCH_ASSOC);
                    
                    $companyName = 'Şirket';
                    $companyCode = $employee['company_id'];
                    
                    if ($company) {
                        // Flexible field mapping
                        if (isset($company['company_name'])) {
                            $companyName = $company['company_name'];
                        } elseif (isset($company['name'])) {
                            $companyName = $company['name'];
                        }
                        
                        if (isset($company['company_code'])) {
                            $companyCode = $company['company_code'];
                        } elseif (isset($company['code'])) {
                            $companyCode = $company['code'];
                        }
                    }
                    
                } catch (Exception $companyError) {
                    // Company info not critical for login
                    $companyName = 'Şirket';
                    $companyCode = $employee['company_id'];
                }
                
                // Set session variables
                $_SESSION['employee_id'] = $employee['id'];
                $_SESSION['company_id'] = $employee['company_id'];
                $_SESSION['company_code'] = $companyCode;
                $_SESSION['company_name'] = $companyName;
                $_SESSION['user_role'] = 'employee';
                $_SESSION['employee_name'] = $employee['first_name'] . ' ' . $employee['last_name'];
                $_SESSION['employee_code'] = $employee['employee_number'] ?? $employee['employee_code'] ?? ('EMP' . str_pad($employee['id'], 4, '0', STR_PAD_LEFT));
                
                // Success - redirect
                header('Location: ../employee/dashboard.php');
                exit;
            } else {
                $error = "Geçersiz personel numarası veya şifre.";
                echo "<!-- DEBUG: Login FAILED - Employee not found or password invalid -->";
                error_log("Login FAILED for employee_id: $employee_id");
            }
            
        } catch (Exception $e) {
            $error = "Bağlantı hatası: " . $e->getMessage();
            
            // Add helpful error info
            if (strpos($e->getMessage(), 'Column not found') !== false) {
                $error .= " <br><br><a href='../debug/test-employee-login-advanced.php' style='color: #dc3545; font-weight: bold;'>🔧 Veritabanı Yapısını Kontrol Et</a>";
            }
        }
    } else {
        $error = "Lütfen tüm alanları doldurun.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Girişi - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>

</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">
    <div class="max-w-md w-full space-y-8 p-8">
        <div class="text-center">
            <div class="mx-auto h-16 w-16 bg-green-600 rounded-lg flex items-center justify-center mb-4">
                <span class="text-white font-bold text-2xl">P</span>
            </div>
            <h2 class="text-3xl font-bold text-gray-900">Personel Girişi</h2>
            <p class="mt-2 text-gray-600">Personel self servis paneline erişim</p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form class="mt-8 space-y-6" method="POST">
            <div class="space-y-4">
                <div>
                    <label for="employee_id" class="block text-sm font-medium text-gray-700">Personel Numarası</label>
                    <input 
                        id="employee_id" 
                        name="employee_id" 
                        type="text" 
                        required 
                        class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                        placeholder="Personel numaranızı girin"
                        value="<?php echo htmlspecialchars($_POST['employee_id'] ?? ''); ?>"
                    >
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700">Şifre</label>
                    <div class="relative mt-1">
                        <input 
                            id="password" 
                            name="password" 
                            type="password" 
                            required 
                            class="block w-full px-3 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500"
                            placeholder="••••••••"
                        >
                        <button type="button" onclick="togglePassword('password')" 
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600">
                            <svg id="password-eye" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <div>
                <button 
                    type="submit"
                    class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                    Giriş Yap
                </button>
            </div>

            <div class="text-center space-y-2">
                <div>
                    <a href="forgot-password.php" class="text-green-600 hover:text-green-500 text-sm font-medium">
                        🔑 Şifremi Unuttum
                    </a>
                </div>
                <div>
                    <a href="../index.php" class="text-green-600 hover:text-green-500 text-sm">
                        ← Ana sayfaya dön
                    </a>
                </div>
            </div>
        </form>
    </div>

    <script>
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const eyeIcon = document.getElementById(fieldId + '-eye');
        
        if (field.type === 'password') {
            field.type = 'text';
            eyeIcon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21" />
            `;
        } else {
            field.type = 'password';
            eyeIcon.innerHTML = `
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            `;
        }
    }
    </script>
</body>
</html>