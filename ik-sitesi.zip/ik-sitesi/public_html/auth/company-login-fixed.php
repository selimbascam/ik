<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$message = '';
$messageType = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($email) || empty($password)) {
        $message = "E-posta ve şifre gereklidir.";
        $messageType = 'error';
    } else {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Simple company authentication
            $stmt = $conn->prepare("SELECT * FROM companies WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                $passwordValid = false;
                
                // Check password in multiple formats
                if (empty($company['password'])) {
                    // No password set - set it to MD5 of provided password
                    $hashedPassword = md5($password);
                    $updateStmt = $conn->prepare("UPDATE companies SET password = ? WHERE id = ?");
                    $updateStmt->execute([$hashedPassword, $company['id']]);
                    $passwordValid = true;
                    
                } elseif ($company['password'] === $password) {
                    // Plain text match
                    $passwordValid = true;
                    
                } elseif (md5($password) === $company['password']) {
                    // MD5 hash match
                    $passwordValid = true;
                    
                } elseif (password_verify($password, $company['password'])) {
                    // PHP password_hash match
                    $passwordValid = true;
                }
                
                if ($passwordValid) {
                    // Set session variables
                    $_SESSION['user_id'] = $company['id'];
                    $_SESSION['company_id'] = $company['id'];
                    $_SESSION['user_email'] = $company['email'];
                    $_SESSION['admin_email'] = $company['email'];
                    $_SESSION['company_name'] = $company['company_name'] ?? $company['name'] ?? 'Şirket';
                    $_SESSION['company_code'] = $company['company_code'] ?? $company['code'] ?? $company['id'];
                    $_SESSION['user_role'] = 'admin';
                    $_SESSION['user_type'] = 'company';
                    $_SESSION['login_type'] = 'company';
                    $_SESSION['user_name'] = 'Şirket Yöneticisi';
                    
                    $message = "Giriş başarılı! Yönlendiriliyor...";
                    $messageType = 'success';
                    
                    // Redirect to admin dashboard
                    header("Location: ../admin/dashboard.php");
                    exit;
                    
                } else {
                    $message = "Geçersiz şifre.";
                    $messageType = 'error';
                }
                
            } else {
                // Company not found - try to create one for testing
                if ($email === 'test@szb.com.tr' && $password === '123456') {
                    try {
                        $stmt = $conn->prepare("
                            INSERT INTO companies 
                            (company_name, name, email, admin_email, password, company_code, code, is_active, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        
                        $stmt->execute([
                            'SZB Test Şirketi',
                            'SZB Test Şirketi', 
                            'test@szb.com.tr',
                            'test@szb.com.tr',
                            md5('123456'),
                            'SZB001',
                            'SZB001',
                            1,
                            'active'
                        ]);
                        
                        $newCompanyId = $conn->lastInsertId();
                        
                        // Set session for new company
                        $_SESSION['user_id'] = $newCompanyId;
                        $_SESSION['company_id'] = $newCompanyId;
                        $_SESSION['user_email'] = 'test@szb.com.tr';
                        $_SESSION['admin_email'] = 'test@szb.com.tr';
                        $_SESSION['company_name'] = 'SZB Test Şirketi';
                        $_SESSION['company_code'] = 'SZB001';
                        $_SESSION['user_role'] = 'admin';
                        $_SESSION['user_type'] = 'company';
                        $_SESSION['login_type'] = 'company';
                        $_SESSION['user_name'] = 'Şirket Yöneticisi';
                        
                        header("Location: ../admin/dashboard.php");
                        exit;
                        
                    } catch (Exception $insertError) {
                        $message = "Test şirketi oluşturulamadı: " . $insertError->getMessage();
                        $messageType = 'error';
                    }
                } else {
                    $message = "Geçersiz e-posta adresi. Test için: test@szb.com.tr / 123456";
                    $messageType = 'error';
                }
            }
            
        } catch (Exception $e) {
            $message = "Veritabanı hatası: " . $e->getMessage();
            $messageType = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şirket Girişi - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body class="gradient-bg min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full mx-4">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <!-- Header -->
            <div class="text-center mb-8">
                <div class="text-4xl mb-4">🏢</div>
                <h1 class="text-2xl font-bold text-gray-900">Şirket Girişi</h1>
                <p class="text-gray-600 mt-2">SZB İK Takip Sistemine Hoş Geldiniz</p>
            </div>

            <!-- Messages -->
            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 rounded-lg <?php 
                    echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                        'bg-red-100 text-red-800 border border-red-200'; 
                ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" class="space-y-6">
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                        E-posta Adresi
                    </label>
                    <input type="email" 
                           id="email" 
                           name="email" 
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                           placeholder="ornek@sirket.com"
                           required>
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                        Şifre
                    </label>
                    <input type="password" 
                           id="password" 
                           name="password"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                           placeholder="Şifrenizi girin"
                           required>
                </div>

                <button type="submit" 
                        class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition duration-200">
                    Giriş Yap
                </button>
            </form>

            <!-- Test Info -->
            <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                <h3 class="text-sm font-medium text-gray-700 mb-2">Test Bilgileri:</h3>
                <p class="text-xs text-gray-600">E-posta: test@szb.com.tr</p>
                <p class="text-xs text-gray-600">Şifre: 123456</p>
            </div>

            <!-- Links -->
            <div class="mt-6 text-center space-y-2">
                <a href="../auth/employee-login.php" class="text-sm text-blue-600 hover:text-blue-800">
                    Personel Girişi
                </a>
                <br>
                <a href="../debug/test-company-login.php" class="text-sm text-gray-600 hover:text-gray-800">
                    Bağlantı Testi
                </a>
            </div>
        </div>
    </div>
</body>
</html>