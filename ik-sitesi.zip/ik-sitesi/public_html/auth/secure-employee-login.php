<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/security.php';
require_once '../includes/helpers.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if already logged in
if (isset($_SESSION['employee_id']) && isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: ../employee/enhanced-dashboard.php');
    exit();
}

$message = '';
$messageType = '';
$loginAttempts = 0;

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF protection
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "Güvenlik hatası. Sayfayı yenileyin.";
        $messageType = 'error';
    } else {
        $employeeNumber = trim($_POST['employee_number'] ?? '');
        $password = trim($_POST['password'] ?? '');
        
        if (empty($employeeNumber) || empty($password)) {
            $message = "Personel numarası ve şifre gereklidir.";
            $messageType = 'error';
        } else {
            try {
                $db = new Database();
                $conn = $db->getConnection();
                
                // Rate limiting check
                $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                if (isRateLimited($conn, $clientIp, 'employee_login')) {
                    $message = "Çok fazla başarısız giriş denemesi. Lütfen 15 dakika sonra tekrar deneyin.";
                    $messageType = 'error';
                } else {
                    // Determine the correct table name
                    $tables = [];
                    $stmt = $conn->query("SHOW TABLES");
                    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    $employeesTable = in_array('employees', $tables) ? 'employees' : 
                                     (in_array('personel', $tables) ? 'personel' : 'employees');
                    
                    // Get column structure for compatibility
                    try {
                        $stmt = $conn->query("SHOW COLUMNS FROM `$employeesTable`");
                        $columnData = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        $employeeColumns = array_column($columnData, 'Field');
                    } catch (PDOException $e) {
                        throw new Exception("Employees table not found or inaccessible");
                    }
                    
                    // Map column names for compatibility
                    $employeeNumberCol = in_array('employee_number', $employeeColumns) ? 'employee_number' : 
                                        (in_array('personel_no', $employeeColumns) ? 'personel_no' : 'employee_number');
                                        
                    $firstNameCol = in_array('first_name', $employeeColumns) ? 'first_name' : 
                                   (in_array('ad', $employeeColumns) ? 'ad' : 'first_name');
                                   
                    $lastNameCol = in_array('last_name', $employeeColumns) ? 'last_name' : 
                                  (in_array('soyad', $employeeColumns) ? 'soyad' : 'last_name');
                                  
                    $activeCol = in_array('is_active', $employeeColumns) ? 'is_active' : 
                                (in_array('aktif', $employeeColumns) ? 'aktif' : 'is_active');
                    
                    // Check if password column exists
                    if (!in_array('password', $employeeColumns)) {
                        $message = "Sistem yapılandırma hatası. Lütfen yöneticinizle iletişime geçin.";
                        $messageType = 'error';
                        logSecurityEvent($conn, 'employee_login_config_error', $employeeNumber, $clientIp);
                    } else {
                        // Find employee by employee number
                        $stmt = execute_safe_query($conn, "SELECT * FROM `$employeesTable` WHERE `$employeeNumberCol` = ?", [$employeeNumber]);
                        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($employee) {
                            // Check if employee is active
                            $isActive = true;
                            if (isset($employee[$activeCol])) {
                                $isActive = ($employee[$activeCol] == 1 || $employee[$activeCol] === 'active');
                            }
                            
                            if (!$isActive) {
                                $message = "Personel hesabınız aktif değil. Yöneticinizle iletişime geçin.";
                                $messageType = 'error';
                                logSecurityEvent($conn, 'employee_login_inactive', $employeeNumber, $clientIp);
                            } else {
                                // Verify password with secure methods
                                $passwordValid = false;
                                $needsUpgrade = false;
                                
                                // Priority 1: Check modern password_hash()
                                if (password_verify($password, $employee['password'])) {
                                    $passwordValid = true;
                                } 
                                // Priority 2: Check Argon2ID (if we're using it)
                                else if (strpos($employee['password'], '$argon2id$') === 0 && password_verify($password, $employee['password'])) {
                                    $passwordValid = true;
                                }
                                // Priority 3: Legacy MD5 support (with immediate upgrade)
                                else if (strlen($employee['password']) === 32 && md5($password) === $employee['password']) {
                                    $passwordValid = true;
                                    $needsUpgrade = true;
                                }
                                // Priority 4: Plain text fallback (with immediate upgrade)
                                else if ($employee['password'] === $password) {
                                    $passwordValid = true;
                                    $needsUpgrade = true;
                                }
                                
                                if ($passwordValid) {
                                    // Upgrade password if needed
                                    if ($needsUpgrade) {
                                        $hashedPassword = password_hash($password, PASSWORD_ARGON2ID, [
                                            'memory_cost' => 65536, // 64 MB
                                            'time_cost' => 4,       // 4 iterations
                                            'threads' => 3,        // 3 threads
                                        ]);
                                        $updateStmt = execute_safe_query($conn, 
                                            "UPDATE `$employeesTable` SET password = ? WHERE id = ?", 
                                            [$hashedPassword, $employee['id']]
                                        );
                                        logSecurityEvent($conn, 'employee_password_upgraded', $employeeNumber, $clientIp);
                                    }
                                    
                                    // Successful login - Set secure session variables
                                    session_regenerate_id(true); // Prevent session fixation
                                    $_SESSION['employee_id'] = $employee['id'];
                                    $_SESSION['employee_number'] = $employee[$employeeNumberCol];
                                    $_SESSION['first_name'] = $employee[$firstNameCol] ?? '';
                                    $_SESSION['last_name'] = $employee[$lastNameCol] ?? '';
                                    $_SESSION['company_id'] = $employee['company_id'] ?? 0;
                                    $_SESSION['user_type'] = 'employee';
                                    $_SESSION['login_type'] = 'employee';
                                    $_SESSION['login_time'] = time();
                                    $_SESSION['last_activity'] = time();
                                    
                                    // Log successful login
                                    logSecurityEvent($conn, 'employee_login_success', $employeeNumber, $clientIp);
                                    
                                    $message = "Giriş başarılı! Hoş geldiniz " . ($employee[$firstNameCol] ?? 'Personel');
                                    $messageType = 'success';
                                    
                                    // Clear any rate limiting for this IP
                                    clearRateLimit($conn, $clientIp, 'employee_login');
                                    
                                    // Redirect after successful login
                                    echo "<script>
                                        setTimeout(function() {
                                            window.location.href = '../employee/enhanced-dashboard.php';
                                        }, 2000);
                                    </script>";
                                } else {
                                    $message = "Geçersiz şifre. Lütfen şifrenizi kontrol edin.";
                                    $messageType = 'error';
                                    
                                    // Log failed attempt and increment rate limiting
                                    logSecurityEvent($conn, 'employee_login_failed_password', $employeeNumber, $clientIp);
                                    incrementRateLimit($conn, $clientIp, 'employee_login');
                                }
                            }
                        } else {
                            $message = "Bu personel numarası ile kayıtlı personel bulunamadı.";
                            $messageType = 'error';
                            
                            // Log failed attempt
                            logSecurityEvent($conn, 'employee_login_failed_number', $employeeNumber, $clientIp);
                            incrementRateLimit($conn, $clientIp, 'employee_login');
                        }
                    }
                }
            } catch (Exception $e) {
                error_log("Secure Employee Login Error: " . $e->getMessage());
                $message = "Sistemde bir hata oluştu. Lütfen tekrar deneyin.";
                $messageType = 'error';
                
                // Log system error
                $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
                logSecurityEvent($conn ?? null, 'employee_login_system_error', $employeeNumber ?? 'unknown', $clientIp, $e->getMessage());
            }
        }
    }
}

// Get current login attempts for display
try {
    $db = new Database();
    $conn = $db->getConnection();
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $loginAttempts = getRateLimitAttempts($conn, $clientIp, 'employee_login');
} catch (Exception $e) {
    // Ignore for display purposes
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Güvenli Personel Girişi - SZB İK Takip</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .card-hover {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        .password-toggle {
            cursor: pointer;
            transition: color 0.2s;
        }
        .password-toggle:hover {
            color: #4b5563;
        }
        .input-focus:focus {
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .security-badge {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
        }
    </style>
</head>
<body class="gradient-bg min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="mx-auto h-20 w-20 bg-white rounded-full flex items-center justify-center mb-4 shadow-lg">
                <i class="fas fa-user-tie text-3xl text-indigo-600"></i>
            </div>
            <h1 class="text-3xl font-bold text-white">Güvenli Personel Girişi</h1>
            <p class="mt-2 text-indigo-100">SZB İK Takip Sistemine Hoş Geldiniz</p>
            <div class="security-badge mt-3">Enterprise Security</div>
        </div>

        <!-- Login Card -->
        <div class="bg-white rounded-xl shadow-2xl overflow-hidden card-hover">
            <div class="p-8">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-xl font-semibold text-gray-800">Hesabınıza Giriş Yapın</h2>
                    <div class="h-10 w-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                        <i class="fas fa-shield-alt text-indigo-600"></i>
                    </div>
                </div>

                <!-- Security Status -->
                <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div class="flex items-center text-sm text-green-700">
                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 1L5.5 5.5l1.414 1.414L10 3.828l3.086 3.086L14.5 5.5 10 1zM4.5 8.5L10 14l5.5-5.5-1.414-1.414L10 11.172 5.914 7.086 4.5 8.5z"/>
                        </svg>
                        <span>
                            <strong>Güvenlik:</strong> Argon2ID şifreleme, CSRF koruması aktif
                            <?php if ($loginAttempts > 0): ?>
                                <br><strong>Uyarı:</strong> <?php echo $loginAttempts; ?>/5 başarısız deneme
                            <?php endif; ?>
                        </span>
                    </div>
                </div>

                <!-- Messages -->
                <?php if (!empty($message)): ?>
                    <div class="mb-6 p-4 rounded-lg <?php 
                        echo $messageType === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 
                            'bg-red-100 text-red-800 border border-red-200'; 
                    ?>">
                        <div class="flex">
                            <div class="mr-2">
                                <?php echo $messageType === 'success' ? '✅' : '❌'; ?>
                            </div>
                            <div><?php echo safe_html($message); ?></div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Login Form -->
                <form method="POST" class="space-y-6">
                    <?php echo csrf_token_input(); ?>
                    
                    <div>
                        <label for="employee_number" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-id-card mr-2 text-indigo-500"></i>Personel Numarası <span class="text-red-500">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="employee_number" 
                            name="employee_number" 
                            required 
                            autocomplete="username"
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
                            placeholder="Personel numaranızı girin"
                            value="<?php echo safe_html($_POST['employee_number'] ?? ''); ?>"
                        >
                    </div>

                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-key mr-2 text-indigo-500"></i>Şifre <span class="text-red-500">*</span>
                        </label>
                        <div class="relative">
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                required 
                                autocomplete="current-password"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg input-focus focus:outline-none focus:ring-2 focus:ring-indigo-500 transition pr-12"
                                placeholder="Güvenli şifrenizi girin"
                            >
                            <button 
                                type="button" 
                                onclick="togglePassword('password')"
                                class="absolute inset-y-0 right-0 pr-3 flex items-center password-toggle"
                                tabindex="-1"
                            >
                                <i id="password-eye" class="fas fa-eye text-gray-400"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Rate limiting warning -->
                    <?php if ($loginAttempts >= 3): ?>
                        <div class="p-3 bg-yellow-50 text-yellow-800 border border-yellow-200 rounded-md text-sm">
                            <strong>Dikkat:</strong> <?php echo (5 - $loginAttempts); ?> hakkınız kaldı. 
                            5 başarısız denemeden sonra 15 dakika beklemeniz gerekecek.
                        </div>
                    <?php endif; ?>

                    <button 
                        type="submit" 
                        class="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition duration-200 font-semibold flex items-center justify-center"
                        <?php echo ($loginAttempts >= 5) ? 'disabled' : ''; ?>
                    >
                        <i class="fas fa-sign-in-alt mr-2"></i>
                        <?php echo ($loginAttempts >= 5) ? 'Giriş Engellendi' : 'Güvenli Giriş Yap'; ?>
                    </button>
                </form>

                <!-- Demo Credentials -->
                <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                    <h3 class="text-sm font-medium text-gray-700 mb-2 flex items-center">
                        <i class="fas fa-info-circle mr-2 text-indigo-500"></i>Demo Giriş Bilgileri
                    </h3>
                    <div class="text-xs text-gray-600 space-y-1">
                        <p><span class="font-medium">Personel No:</span> 30716129672</p>
                        <p><span class="font-medium">Şifre:</span> 123456</p>
                    </div>
                </div>
            </div>

            <!-- Footer Links -->
            <div class="px-8 py-4 bg-gray-100 border-t border-gray-200">
                <div class="flex justify-between items-center">
                    <a href="../index.php" class="text-sm text-indigo-600 hover:text-indigo-500 font-medium flex items-center">
                        <i class="fas fa-home mr-1"></i> Ana Sayfa
                    </a>
                    <a href="../auth/secure-company-login.php" class="text-sm text-purple-600 hover:text-purple-500 font-medium flex items-center">
                        <i class="fas fa-building mr-1"></i> Şirket Girişi
                    </a>
                </div>
            </div>
        </div>

        <!-- Support Card -->
        <div class="mt-6 bg-white/90 backdrop-blur rounded-xl p-6 shadow-lg">
            <h3 class="font-semibold text-gray-800 mb-3 flex items-center">
                <i class="fas fa-headset mr-2 text-indigo-600"></i> Yardım ve Destek
            </h3>
            <div class="text-sm text-gray-600 space-y-2">
                <p class="flex items-start">
                    <i class="fas fa-phone-alt text-indigo-500 mt-1 mr-2"></i>
                    <span>Destek Hattı: <a href="tel:+902121234567" class="text-indigo-600 font-medium">0212 123 45 67</a></span>
                </p>
                <p class="flex items-start">
                    <i class="fas fa-envelope text-indigo-500 mt-1 mr-2"></i>
                    <span>E-posta: <a href="mailto:destek@szbiktakip.com" class="text-indigo-600 font-medium">destek@szbiktakip.com</a></span>
                </p>
                <p class="flex items-start">
                    <i class="fas fa-clock text-indigo-500 mt-1 mr-2"></i>
                    <span>Çalışma Saatleri: Pazartesi - Cuma, 09:00 - 18:00</span>
                </p>
            </div>
        </div>
    </div>

    <script>
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        const eyeIcon = document.getElementById(fieldId + '-eye');
        
        if (field.type === 'password') {
            field.type = 'text';
            eyeIcon.classList.remove('fa-eye');
            eyeIcon.classList.add('fa-eye-slash');
        } else {
            field.type = 'password';
            eyeIcon.classList.remove('fa-eye-slash');
            eyeIcon.classList.add('fa-eye');
        }
    }

    // Auto-hide success messages
    <?php if ($messageType === 'success'): ?>
    setTimeout(function() {
        const successMsg = document.querySelector('.bg-green-100');
        if (successMsg) {
            successMsg.style.transition = 'opacity 0.5s';
            successMsg.style.opacity = '0';
            setTimeout(() => successMsg.remove(), 500);
        }
    }, 1500);
    <?php endif; ?>
    </script>
</body>
</html>