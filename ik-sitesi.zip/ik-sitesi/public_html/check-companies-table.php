<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Companies Table Structure Check</h2>";
echo "<pre style='background: #f5f5f5; padding: 20px; border-radius: 5px;'>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Show table structure
    echo "🔍 Companies tablosu yapısı:\n\n";
    $stmt = $conn->prepare("SHOW COLUMNS FROM companies");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($columns as $column) {
        echo "  {$column['Field']} - {$column['Type']} - {$column['Null']} - {$column['Default']}\n";
    }
    
    echo "\n📊 Mevcut şirket verileri:\n\n";
    $stmt = $conn->prepare("SELECT * FROM companies LIMIT 5");
    $stmt->execute();
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($companies)) {
        echo "  Hiç şirket kaydı bulunamadı.\n";
    } else {
        foreach ($companies as $company) {
            echo "ID: {$company['id']}\n";
            foreach ($company as $key => $value) {
                if ($key !== 'id') {
                    echo "  $key: " . ($value ?: 'NULL') . "\n";
                }
            }
            echo "\n";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage();
}
?>
</pre>