-- Comprehensive TC Identity Fix for Hostinger
-- Fixes "Unknown column 'tc_identity'" error in shift management

-- Step 1: Check current column structure
SELECT 'Current employee table columns:' as info;
SHOW COLUMNS FROM employees;

-- Step 2: Check if tc_identity exists
SELECT 'Checking for tc_identity column:' as info;
SELECT COUNT(*) as tc_identity_exists 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'employees' 
AND COLUMN_NAME = 'tc_identity';

-- Step 3: Check if tc_no exists
SELECT 'Checking for tc_no column:' as info;
SELECT COUNT(*) as tc_no_exists 
FROM information_schema.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'employees' 
AND COLUMN_NAME = 'tc_no';

-- Step 4A: If tc_identity exists but tc_no doesn't, rename it
-- Run this only if tc_identity exists and tc_no doesn't exist
-- ALTER TABLE employees CHANGE tc_identity tc_no VARCHAR(11);

-- Step 4B: If both exist, merge and drop tc_identity
-- First merge data from tc_identity to tc_no
-- UPDATE employees 
-- SET tc_no = tc_identity 
-- WHERE (tc_no IS NULL OR tc_no = '') 
-- AND tc_identity IS NOT NULL 
-- AND tc_identity != '';

-- Then drop tc_identity column
-- ALTER TABLE employees DROP COLUMN tc_identity;

-- Step 4C: If neither exists, create tc_no
-- ALTER TABLE employees ADD COLUMN tc_no VARCHAR(11) AFTER id;

-- Step 5: Sync all TC-related fields (tc_no = employee_number = employee_code)
-- Use employee_number as master if tc_no is empty
UPDATE employees 
SET tc_no = employee_number,
    employee_code = employee_number
WHERE (tc_no IS NULL OR tc_no = '') 
AND employee_number IS NOT NULL 
AND employee_number != '';

-- Use tc_no as master for employee_number and employee_code
UPDATE employees 
SET employee_number = tc_no,
    employee_code = tc_no
WHERE tc_no IS NOT NULL 
AND tc_no != '';

-- Step 6: Create/Update the specific test employee 30716129672
-- Update if exists
UPDATE employees 
SET tc_no = '30716129672',
    employee_number = '30716129672',
    employee_code = '30716129672',
    first_name = 'Test',
    last_name = 'Personel',
    password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    status = 'active',
    is_active = 1
WHERE tc_no = '30716129672' 
   OR employee_number = '30716129672' 
   OR employee_code = '30716129672'
LIMIT 1;

-- Insert if doesn't exist
INSERT INTO employees (tc_no, employee_number, employee_code, first_name, last_name, password, company_id, status, is_active)
SELECT '30716129672', '30716129672', '30716129672', 'Test', 'Personel', 
       '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1, 'active', 1
WHERE NOT EXISTS (
    SELECT 1 FROM employees 
    WHERE tc_no = '30716129672' 
       OR employee_number = '30716129672' 
       OR employee_code = '30716129672'
);

-- Step 7: Verification
SELECT 'Final verification - Column structure:' as info;
SHOW COLUMNS FROM employees;

SELECT 'Final verification - Employee count by sync status:' as info;
SELECT 
    COUNT(*) as total_employees,
    COUNT(tc_no) as employees_with_tc_no,
    COUNT(CASE WHEN tc_no = employee_number AND employee_number = employee_code THEN 1 END) as fully_synced_employees
FROM employees;

SELECT 'Final verification - Test employee 30716129672:' as info;
SELECT id, tc_no, employee_number, employee_code, first_name, last_name, status, is_active,
       CASE 
           WHEN tc_no = employee_number AND employee_number = employee_code THEN 'SYNCED'
           ELSE 'NOT SYNCED'
       END as sync_status
FROM employees 
WHERE tc_no = '30716129672' 
   OR employee_number = '30716129672' 
   OR employee_code = '30716129672';

SELECT 'Fix complete! Shift management should now work without tc_identity errors.' as result;