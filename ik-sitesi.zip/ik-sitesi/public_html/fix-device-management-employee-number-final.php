<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Device Management Final Employee Number Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Step 1: Check Employee Number Column</h3>";
    
    // Check if employee_number column exists
    $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
    $columns = $stmt->fetchAll();
    
    if (count($columns) == 0) {
        echo "<p style='color: red;'>Employee number column missing! Adding now...</p>";
        
        $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
        echo "<p style='color: green;'>Employee number column added successfully</p>";
        
        // Generate numbers for existing employees
        $employees = $conn->query("SELECT id FROM employees")->fetchAll();
        
        foreach ($employees as $emp) {
            $employeeNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            $updateStmt->execute([$employeeNumber, $emp['id']]);
        }
        
        echo "<p style='color: green;'>Generated employee numbers for " . count($employees) . " employees</p>";
        
    } else {
        echo "<p style='color: green;'>Employee number column exists</p>";
        
        // Check if any employees have NULL employee_number
        $nullCheck = $conn->query("SELECT COUNT(*) as count FROM employees WHERE employee_number IS NULL OR employee_number = ''")->fetch();
        
        if ($nullCheck['count'] > 0) {
            echo "<p style='color: orange;'>Found {$nullCheck['count']} employees with empty employee numbers. Fixing...</p>";
            
            $emptyEmployees = $conn->query("SELECT id FROM employees WHERE employee_number IS NULL OR employee_number = ''")->fetchAll();
            
            foreach ($emptyEmployees as $emp) {
                $employeeNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
                $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
                $updateStmt->execute([$employeeNumber, $emp['id']]);
            }
            
            echo "<p style='color: green;'>Fixed employee numbers for {$nullCheck['count']} employees</p>";
        } else {
            echo "<p style='color: green;'>All employees have employee numbers</p>";
        }
    }
    
    echo "<h3>Step 2: Test Device Management Query</h3>";
    
    // Test the exact query from device-management.php
    $testQuery = "
        SELECT 
            ed.*,
            e.first_name,
            e.last_name,
            e.employee_number
        FROM employee_devices ed
        JOIN employees e ON ed.employee_id = e.id
        WHERE e.company_id = ?
        ORDER BY COALESCE(ed.last_seen_at, ed.created_at) DESC
        LIMIT 5
    ";
    
    try {
        $stmt = $conn->prepare($testQuery);
        $stmt->execute([1]);
        $devices = $stmt->fetchAll();
        
        echo "<p style='color: green;'>Device query successful! Found " . count($devices) . " devices</p>";
        
        if (count($devices) > 0) {
            echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
            echo "<tr style='background: #f0f0f0;'>";
            echo "<th style='padding: 8px;'>Employee Name</th>";
            echo "<th style='padding: 8px;'>Employee Number</th>";
            echo "<th style='padding: 8px;'>Device Fingerprint</th>";
            echo "<th style='padding: 8px;'>Trusted</th>";
            echo "</tr>";
            
            foreach ($devices as $device) {
                echo "<tr>";
                echo "<td style='padding: 8px;'>{$device['first_name']} {$device['last_name']}</td>";
                echo "<td style='padding: 8px;'><strong>{$device['employee_number']}</strong></td>";
                echo "<td style='padding: 8px;'>" . substr($device['device_fingerprint'], 0, 20) . "...</td>";
                echo "<td style='padding: 8px;'>" . ($device['is_trusted'] ? 'Yes' : 'No') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>Device query failed: " . $e->getMessage() . "</p>";
        
        // Check if device tables exist
        $deviceTableCheck = $conn->query("SHOW TABLES LIKE 'employee_devices'");
        if (count($deviceTableCheck->fetchAll()) == 0) {
            echo "<p style='color: orange;'>employee_devices table missing. Creating basic structure...</p>";
            
            $conn->exec("
                CREATE TABLE IF NOT EXISTS employee_devices (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    employee_id INT NOT NULL,
                    device_fingerprint VARCHAR(255) NOT NULL,
                    device_name VARCHAR(255),
                    browser_info TEXT,
                    is_trusted TINYINT(1) DEFAULT 0,
                    last_seen_at TIMESTAMP NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY unique_employee_device (employee_id, device_fingerprint),
                    INDEX idx_employee_id (employee_id)
                )
            ");
            
            echo "<p style='color: green;'>Employee devices table created</p>";
        }
    }
    
    echo "<h3>Step 3: Test Sample Employee Data</h3>";
    
    $employeeCheck = $conn->query("SELECT id, first_name, last_name, employee_number FROM employees LIMIT 3");
    $sampleEmployees = $employeeCheck->fetchAll();
    
    if (count($sampleEmployees) > 0) {
        echo "<p>Sample employees with employee numbers:</p>";
        echo "<ul>";
        foreach ($sampleEmployees as $emp) {
            echo "<li><strong>{$emp['employee_number']}</strong> - {$emp['first_name']} {$emp['last_name']}</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color: orange;'>No employees found in database</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
}

echo "<h3>Test Device Management Page</h3>";
echo "<div>";
echo "<a href='admin/device-management.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Test Device Management</a>";
echo "<a href='admin/dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
table { width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background: #f0f0f0; }
ul { background: #f8f9fa; padding: 15px; border-radius: 5px; }
</style>