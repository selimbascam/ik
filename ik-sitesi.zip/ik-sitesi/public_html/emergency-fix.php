<?php
// Emergency Foreign Key Fix - Uses existing system configuration
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>Emergency Foreign Key Fix</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;line-height:1.6;}h1,h2{color:#333;}.success{color:#22c55e;font-weight:bold;}.error{color:#ef4444;font-weight:bold;}.info{color:#3b82f6;font-weight:bold;}.warning{color:#f59e0b;font-weight:bold;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>Database Connected Successfully</h2>";
    
    // Find the problematic employee
    echo "<h3>Step 1: Find Test Employee</h3>";
    $stmt = $conn->prepare("SELECT id, employee_number, company_id, first_name, last_name FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<p class='success'>Employee found: {$employee['first_name']} {$employee['last_name']}</p>";
        echo "<p>Employee ID: {$employee['id']}</p>";
        echo "<p>Company ID: " . ($employee['company_id'] ?? 'NULL') . "</p>";
        
        // Check company existence
        echo "<h3>Step 2: Check Company</h3>";
        if ($employee['company_id']) {
            $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
            $stmt->execute([$employee['company_id']]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$company) {
                echo "<p class='error'>PROBLEM FOUND: Company ID {$employee['company_id']} does not exist!</p>";
                
                // Create missing company
                echo "<p class='info'>Creating missing company...</p>";
                $stmt = $conn->prepare("INSERT INTO companies (id, company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt->execute([
                    $employee['company_id'],
                    'SZB Company',
                    'admin@szb.com.tr',
                    '555-0123',
                    'Emergency fix creation'
                ]);
                echo "<p class='success'>Company created successfully!</p>";
                
            } else {
                echo "<p class='success'>Company exists: {$company['company_name']}</p>";
            }
        } else {
            echo "<p class='error'>PROBLEM FOUND: Employee has NULL company_id!</p>";
            
            // Find or create a default company
            $stmt = $conn->prepare("SELECT id FROM companies LIMIT 1");
            $stmt->execute();
            $defaultCompany = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$defaultCompany) {
                // Create a company
                $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute(['SZB Default Company', 'admin@szb.com.tr', '555-0123', 'Default company']);
                $companyId = $conn->lastInsertId();
                echo "<p class='success'>Default company created with ID: $companyId</p>";
            } else {
                $companyId = $defaultCompany['id'];
                echo "<p class='info'>Using existing company ID: $companyId</p>";
            }
            
            // Update employee
            $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
            $stmt->execute([$companyId, $employee['id']]);
            echo "<p class='success'>Employee company_id updated to: $companyId</p>";
            
            // Update our local variable
            $employee['company_id'] = $companyId;
        }
        
        // Create QR location if needed
        echo "<h3>Step 3: Ensure QR Location</h3>";
        $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = ? LIMIT 1");
        $stmt->execute([$employee['company_id']]);
        $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$qrLocation) {
            $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $employee['company_id'],
                'Main Entrance',
                'Emergency created QR location',
                '41.0082',
                '28.9784',
                'entrance',
                1
            ]);
            $qrLocationId = $conn->lastInsertId();
            echo "<p class='success'>QR location created with ID: $qrLocationId</p>";
        } else {
            $qrLocationId = $qrLocation['id'];
            echo "<p class='success'>QR location exists with ID: $qrLocationId</p>";
        }
        
        // Test the fix
        echo "<h3>Step 4: Test Attendance Insert</h3>";
        try {
            $currentDateTime = date('Y-m-d H:i:s');
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, date, notes, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $employee['company_id'],
                $employee['id'],
                $qrLocationId,
                'work_in',
                $currentDateTime,
                date('Y-m-d'),
                'Emergency fix test - ' . date('H:i:s'),
                $currentDateTime
            ]);
            
            if ($result) {
                $recordId = $conn->lastInsertId();
                echo "<p class='success'>SUCCESS! Test attendance record created with ID: $recordId</p>";
                
                echo "<div style='background:#e8f5e8;padding:20px;border-radius:8px;margin:20px 0;'>";
                echo "<h3 style='color:#2e7d32;'>FOREIGN KEY CONSTRAINT FIXED!</h3>";
                echo "<p>The QR attendance system should now work correctly.</p>";
                echo "<p><strong>Test with employee login:</strong> 30716129672 / 123456</p>";
                echo "</div>";
                
                // Clean up test record
                $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
                $stmt->execute([$recordId]);
                echo "<p class='info'>Test record cleaned up</p>";
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>Test insert failed: " . $e->getMessage() . "</p>";
            
            // Additional debugging
            echo "<h4>Debug Information:</h4>";
            echo "<ul>";
            echo "<li>Employee ID: " . $employee['id'] . "</li>";
            echo "<li>Company ID: " . $employee['company_id'] . "</li>";
            echo "<li>QR Location ID: " . $qrLocationId . "</li>";
            echo "</ul>";
            
            // Check if these IDs actually exist
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE id = ?");
            $stmt->execute([$employee['id']]);
            $empExists = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<li>Employee exists: " . ($empExists ? 'Yes' : 'No') . "</li>";
            
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM companies WHERE id = ?");
            $stmt->execute([$employee['company_id']]);
            $compExists = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<li>Company exists: " . ($compExists ? 'Yes' : 'No') . "</li>";
            
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE id = ?");
            $stmt->execute([$qrLocationId]);
            $locExists = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<li>QR Location exists: " . ($locExists ? 'Yes' : 'No') . "</li>";
        }
        
    } else {
        echo "<p class='error'>Employee 30716129672 not found!</p>";
        
        // List available employees
        echo "<h3>Available employees:</h3>";
        $stmt = $conn->prepare("SELECT employee_number, first_name, last_name, company_id FROM employees LIMIT 5");
        $stmt->execute();
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($employees as $emp) {
            echo "<p>{$emp['employee_number']} - {$emp['first_name']} {$emp['last_name']} (Company: {$emp['company_id']})</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p class='error'>Database error: " . $e->getMessage() . "</p>";
}

echo "<p><strong>After running this fix, test QR attendance with employee login.</strong></p>";
?>