<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Direkt Şirket Geçişi - SZB İK Takip</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f8f9fa; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid #e9ecef; }
        .success { background: #d1fae5; color: #065f46; padding: 15px; border-radius: 8px; margin: 15px 0; border: 1px solid #a7f3d0; }
        .error { background: #fee2e2; color: #991b1b; padding: 15px; border-radius: 8px; margin: 15px 0; border: 1px solid #fca5a5; }
        .warning { background: #fef3c7; color: #92400e; padding: 15px; border-radius: 8px; margin: 15px 0; border: 1px solid #fcd34d; }
        .info { background: #dbeafe; color: #1e40af; padding: 15px; border-radius: 8px; margin: 15px 0; border: 1px solid #93c5fd; }
        .nav-buttons { text-align: center; margin: 30px 0; padding: 20px; background: #f8f9fa; border-radius: 8px; }
        .nav-button { background: #6f42c1; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 0 10px; display: inline-block; font-weight: bold; }
        .nav-button:hover { background: #5a3291; }
        .nav-button.dashboard { background: #17a2b8; }
        .nav-button.dashboard:hover { background: #138496; }
        .nav-button.database { background: #28a745; }
        .nav-button.database:hover { background: #218838; }
        .company-list { margin: 20px 0; }
        .company-item { background: #f8f9fa; padding: 10px; margin: 5px 0; border-radius: 5px; border: 1px solid #dee2e6; }
        .company-item a { color: #007bff; text-decoration: none; font-weight: bold; }
        .company-item a:hover { text-decoration: underline; }
        h1 { color: #1f2937; margin: 0; }
        h3 { color: #374151; }
        ul { margin: 10px 0; }
        li { margin: 5px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎯 Direkt Şirket Geçişi</h1>
            <p style="color: #6b7280; margin: 10px 0;">Super Admin şirket değiştirme paneli</p>
        </div>
        
        <!-- Navigation at top -->
        <div class="nav-buttons">
            <a href="super-admin/" class="nav-button">👑 Super Admin Paneli</a>
            <a href="dashboard/company-dashboard.php" class="nav-button dashboard">📊 Dashboard</a>
            <a href="database-overview.php" class="nav-button database">🗄️ Database</a>
        </div>
        
        <?php

// Get company code from URL
$companyCode = $_GET['code'] ?? '';

if (empty($companyCode)) {
    echo "<div class='error'>";
    echo "<h3>❌ Şirket Kodu Belirtilmedi</h3>";
    echo "<p>URL'de ?code=COMPANY_CODE parametresi olmalı.</p>";
    echo "<p><strong>Örnek:</strong> direct-switch.php?code=SZB38211</p>";
    echo "</div>";
} else {
    echo "<div class='info'>";
    echo "<h3>🚀 Şirket Geçişi: " . htmlspecialchars($companyCode) . "</h3>";
    echo "<p>Belirtilen şirket koduna geçiliyor...</p>";
    
    try {
        $db = new Database();
        $conn = $db->getConnection();
        
        // Find company and admin user
        $stmt = $conn->prepare("
            SELECT c.*, u.id as admin_id, u.email as admin_email, u.first_name, u.last_name 
            FROM companies c 
            JOIN users u ON c.id = u.company_id 
            WHERE c.company_code = ? AND u.role = 'admin' 
            LIMIT 1
        ");
        $stmt->execute([$companyCode]);
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$company) {
            echo "<div class='error'>";
            echo "<h3>❌ Şirket Bulunamadı</h3>";
            echo "<p>Kod: " . htmlspecialchars($companyCode) . "</p>";
            echo "</div>";
            
            // Show available companies
            echo "<div class='info'>";
            echo "<h4>📋 Mevcut Şirketler:</h4>";
            echo "<div class='company-list'>";
            $stmt = $conn->query("SELECT company_name, company_code FROM companies ORDER BY company_name");
            $companies = $stmt->fetchAll();
            foreach ($companies as $comp) {
                echo "<div class='company-item'>";
                echo "<strong>" . htmlspecialchars($comp['company_name']) . "</strong> - ";
                echo "<a href='direct-switch.php?code=" . urlencode($comp['company_code']) . "'>";
                echo htmlspecialchars($comp['company_code']) . "</a>";
                echo "</div>";
            }
            echo "</div>";
            echo "</div>";
            
        } else {
            echo "<div class='success'>";
            echo "<h3>✅ Şirket Bulundu</h3>";
            echo "<ul>";
            echo "<li><strong>Şirket:</strong> " . htmlspecialchars($company['company_name']) . "</li>";
            echo "<li><strong>Kod:</strong> " . htmlspecialchars($company['company_code']) . "</li>";
            echo "<li><strong>Admin:</strong> " . htmlspecialchars($company['admin_email']) . "</li>";
            echo "<li><strong>Admin Adı:</strong> " . htmlspecialchars(($company['first_name'] ?? '') . ' ' . ($company['last_name'] ?? '')) . "</li>";
            echo "</ul>";
            echo "</div>";
            
            // Clear all session data first
            session_unset();
            
            // Set new session data
            $_SESSION['super_admin'] = true;
            $_SESSION['super_admin_bypass'] = true;
            $_SESSION['original_super_admin'] = true;
            $_SESSION['user_email'] = 'super@admin.com';
            $_SESSION['company_id'] = $company['id'];
            $_SESSION['company_code'] = $company['company_code'];
            $_SESSION['company_name'] = $company['company_name'];
            $_SESSION['user_id'] = $company['admin_id'];
            $_SESSION['user_role'] = 'admin';
            $_SESSION['user_name'] = ($company['first_name'] ?? 'Admin') . ' (' . $company['company_name'] . ')';
            $_SESSION['logged_in'] = true;
            
            echo "<div class='success'>";
            echo "<h3>✅ Session Başarıyla Güncellendi!</h3>";
            echo "<p>Şirket geçişi tamamlandı. Dashboard'a yönlendiriliyorsunuz...</p>";
            echo "</div>";
            
            echo "<div style='text-align: center; margin: 30px 0;'>";
            echo "<a href='dashboard/company-dashboard.php' style='background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-size: 18px; font-weight: bold; box-shadow: 0 2px 5px rgba(0,0,0,0.2);'>🎯 Dashboard'a Git</a>";
            echo "</div>";
            
            // JavaScript redirect after 3 seconds
            echo "<script>";
            echo "setTimeout(function() {";
            echo "    window.location.href = 'dashboard/company-dashboard.php';";
            echo "}, 3000);";
            echo "</script>";
            echo "<p style='text-align: center; color: #666;'>3 saniye sonra otomatik yönlendirileceksiniz...</p>";
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>";
        echo "<h3>❌ Veritabanı Hatası</h3>";
        echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
        echo "</div>";
    }
    
    echo "</div>";
}
?>

        <!-- Navigation at bottom -->
        <div class="nav-buttons">
            <a href="super-admin/" class="nav-button">👑 Super Admin Paneli</a>
            <a href="dashboard/company-dashboard.php" class="nav-button dashboard">📊 Dashboard</a>
            <a href="database-overview.php" class="nav-button database">🗄️ Database</a>
        </div>
        
        <div style="text-align: center; margin-top: 20px; color: #6b7280; font-size: 14px;">
            <p>Super Admin olarak şirketler arasında geçiş yapabilirsiniz</p>
        </div>
    </div>
</body>
</html>