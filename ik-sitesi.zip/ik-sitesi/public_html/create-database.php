<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔧 Database Creation</h1>";
echo "<p>Creating complete database structure for SZB İK Takip...</p>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<div style='background: #f8f9fa; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; margin-bottom: 20px;'>";
    echo "<h3>📋 Database Creation Steps:</h3>";
    
    // Read SQL file
    $sqlFile = '../mysql_schema_complete.sql';
    if (!file_exists($sqlFile)) {
        throw new Exception("SQL schema file not found: $sqlFile");
    }
    
    $sql = file_get_contents($sqlFile);
    if ($sql === false) {
        throw new Exception("Could not read SQL schema file");
    }
    
    // Split SQL into individual statements
    $statements = preg_split('/;\s*$/m', $sql);
    $successCount = 0;
    $errorCount = 0;
    
    echo "<div style='max-height: 400px; overflow-y: auto; background: white; padding: 10px; border: 1px solid #ccc;'>";
    
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if (empty($statement) || strpos($statement, '--') === 0) {
            continue;
        }
        
        try {
            $conn->exec($statement);
            $successCount++;
            
            // Show what was executed
            if (preg_match('/CREATE TABLE (\w+)/', $statement, $matches)) {
                echo "<div style='color: green;'>✓ Created table: <strong>{$matches[1]}</strong></div>";
            } elseif (preg_match('/INSERT INTO (\w+)/', $statement, $matches)) {
                echo "<div style='color: blue;'>✓ Inserted data into: <strong>{$matches[1]}</strong></div>";
            } elseif (preg_match('/DROP TABLE IF EXISTS (\w+)/', $statement, $matches)) {
                echo "<div style='color: orange;'>⚠ Dropped table: <strong>{$matches[1]}</strong></div>";
            } else {
                echo "<div style='color: #666;'>✓ Executed statement</div>";
            }
            
        } catch (PDOException $e) {
            $errorCount++;
            echo "<div style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</div>";
        }
    }
    
    echo "</div>";
    echo "</div>";
    
    if ($errorCount === 0) {
        echo "<div style='background: #d4edda; color: #155724; padding: 15px; border: 1px solid #c3e6cb; border-radius: 5px;'>";
        echo "<h3>🎉 Database Created Successfully!</h3>";
        echo "<p><strong>Summary:</strong></p>";
        echo "<ul>";
        echo "<li>✓ $successCount SQL statements executed</li>";
        echo "<li>✓ 16 tables created</li>";
        echo "<li>✓ Default data inserted</li>";
        echo "<li>✓ Demo company and users created</li>";
        echo "</ul>";
        
        echo "<h4>📊 Default Accounts Created:</h4>";
        echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
        echo "<tr style='background: #f8f9fa;'><th>Account Type</th><th>Email</th><th>Password</th><th>Access</th></tr>";
        echo "<tr><td><strong>Super Admin</strong></td><td>super@admin.com</td><td>secret</td><td>All companies</td></tr>";
        echo "<tr><td><strong>Demo Company Admin</strong></td><td>admin@demo.com</td><td>demo123</td><td>Demo Company (AAA00001)</td></tr>";
        echo "</table>";
        
        echo "<h4>🚀 Next Steps:</h4>";
        echo "<ol>";
        echo "<li><a href='super-admin/'>Access Super Admin Panel</a></li>";
        echo "<li><a href='auth/company-login.php?demo=AAA00001'>Login to Demo Company</a></li>";
        echo "<li><a href='database-overview.php'>View Database Overview</a></li>";
        echo "</ol>";
        
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
        echo "<h3>⚠ Database Creation Completed with Errors</h3>";
        echo "<p><strong>Summary:</strong></p>";
        echo "<ul>";
        echo "<li>✓ $successCount statements succeeded</li>";
        echo "<li>❌ $errorCount statements failed</li>";
        echo "</ul>";
        echo "<p>Some operations may have failed due to existing data or permission issues. Check the log above for details.</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border: 1px solid #f5c6cb; border-radius: 5px;'>";
    echo "<h3>❌ Database Creation Failed</h3>";
    echo "<p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><strong>Possible Solutions:</strong></p>";
    echo "<ul>";
    echo "<li>Check database connection settings in includes/config.php</li>";
    echo "<li>Ensure MySQL server is running and accessible</li>";
    echo "<li>Verify database user has CREATE and INSERT privileges</li>";
    echo "<li>Check if mysql_schema_complete.sql file exists</li>";
    echo "</ul>";
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='database-overview.php'>← Back to Database Overview</a></p>";
?>