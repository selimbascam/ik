<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Employee Status Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Step 1: Check Employee Status Column</h3>";
    
    // Check if status column exists in employees table
    $stmt = $conn->query("SHOW COLUMNS FROM employees LIKE 'status'");
    $columns = $stmt->fetchAll();
    
    if (count($columns) == 0) {
        echo "<p style='color: orange;'>Status column missing in employees table. Adding it now...</p>";
        
        // Add status column
        $conn->exec("ALTER TABLE employees ADD COLUMN status VARCHAR(20) DEFAULT 'active' AFTER employee_number");
        echo "<p style='color: green;'>Status column added successfully</p>";
        
        // Set default status for existing employees
        $conn->exec("UPDATE employees SET status = 'active' WHERE status IS NULL");
        echo "<p style='color: green;'>Set default status 'active' for all existing employees</p>";
        
    } else {
        echo "<p style='color: green;'>Status column already exists</p>";
        
        // Check current status values
        $statusCheck = $conn->query("SELECT status, COUNT(*) as count FROM employees GROUP BY status");
        $statusData = $statusCheck->fetchAll();
        
        echo "<h4>Current Status Distribution:</h4>";
        echo "<ul>";
        foreach ($statusData as $status) {
            echo "<li><strong>" . ($status['status'] ?? 'NULL') . ":</strong> {$status['count']} employees</li>";
        }
        echo "</ul>";
        
        // Fix any NULL status values
        $nullCheck = $conn->query("SELECT COUNT(*) as count FROM employees WHERE status IS NULL")->fetch();
        if ($nullCheck['count'] > 0) {
            echo "<p style='color: orange;'>Found {$nullCheck['count']} employees with NULL status. Setting to 'active'...</p>";
            $conn->exec("UPDATE employees SET status = 'active' WHERE status IS NULL");
            echo "<p style='color: green;'>Fixed NULL status values</p>";
        }
    }
    
    echo "<h3>Step 2: Check Employee Number Column</h3>";
    
    // Also ensure employee_number exists (common issue)
    $empNumCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
    $empNumColumns = $empNumCheck->fetchAll();
    
    if (count($empNumColumns) == 0) {
        echo "<p style='color: orange;'>Employee number column missing. Adding it...</p>";
        
        $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
        
        // Generate employee numbers
        $employees = $conn->query("SELECT id FROM employees")->fetchAll();
        foreach ($employees as $emp) {
            $employeeNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            $updateStmt->execute([$employeeNumber, $emp['id']]);
        }
        
        echo "<p style='color: green;'>Employee number column added and populated</p>";
    } else {
        echo "<p style='color: green;'>Employee number column exists</p>";
    }
    
    echo "<h3>Step 3: Test Payroll Query</h3>";
    
    // Test a common payroll query that would use status
    $testQuery = "
        SELECT 
            e.id,
            e.first_name,
            e.last_name,
            e.employee_number,
            e.status,
            e.position,
            e.salary
        FROM employees e
        WHERE e.company_id = ? AND e.status = 'active'
        LIMIT 5
    ";
    
    try {
        $stmt = $conn->prepare($testQuery);
        $stmt->execute([1]);
        $employees = $stmt->fetchAll();
        
        echo "<p style='color: green;'>Payroll query successful! Found " . count($employees) . " active employees</p>";
        
        if (count($employees) > 0) {
            echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
            echo "<tr style='background: #f0f0f0;'>";
            echo "<th style='padding: 8px;'>Employee No</th>";
            echo "<th style='padding: 8px;'>Name</th>";
            echo "<th style='padding: 8px;'>Status</th>";
            echo "<th style='padding: 8px;'>Position</th>";
            echo "<th style='padding: 8px;'>Salary</th>";
            echo "</tr>";
            
            foreach ($employees as $employee) {
                echo "<tr>";
                echo "<td style='padding: 8px;'><strong>{$employee['employee_number']}</strong></td>";
                echo "<td style='padding: 8px;'>{$employee['first_name']} {$employee['last_name']}</td>";
                echo "<td style='padding: 8px;'>" . ucfirst($employee['status']) . "</td>";
                echo "<td style='padding: 8px;'>" . ($employee['position'] ?? 'Not Set') . "</td>";
                echo "<td style='padding: 8px;'>" . ($employee['salary'] ?? '0') . " TL</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>Payroll query failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>Step 4: Test Different Status Values</h3>";
    
    // Test queries with different status filters
    $statusTests = ['active', 'inactive', 'terminated', 'on_leave'];
    
    foreach ($statusTests as $status) {
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE company_id = 1 AND status = ?");
            $stmt->execute([$status]);
            $result = $stmt->fetch();
            echo "<p><strong>{$status}:</strong> {$result['count']} employees</p>";
        } catch (Exception $e) {
            echo "<p style='color: red;'>Error testing status '{$status}': " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<h3>Step 5: Create Sample Payroll Data</h3>";
    
    // Check if we have salary data
    $salaryCheck = $conn->query("SELECT COUNT(*) as count FROM employees WHERE salary > 0")->fetch();
    
    if ($salaryCheck['count'] == 0) {
        echo "<p style='color: orange;'>No salary data found. Adding sample salary data...</p>";
        
        $employees = $conn->query("SELECT id FROM employees LIMIT 5")->fetchAll();
        foreach ($employees as $emp) {
            $sampleSalary = rand(5000, 15000); // Sample salary between 5000-15000 TL
            $stmt = $conn->prepare("UPDATE employees SET salary = ? WHERE id = ?");
            $stmt->execute([$sampleSalary, $emp['id']]);
        }
        
        echo "<p style='color: green;'>Added sample salary data for testing</p>";
    } else {
        echo "<p style='color: green;'>Salary data exists ({$salaryCheck['count']} employees with salary)</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
    echo "<p>File: " . $e->getFile() . "</p>";
}

echo "<h3>Summary</h3>";
echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
echo "<p><strong>✅ Fixes Applied:</strong></p>";
echo "<ul>";
echo "<li>Added 'status' column to employees table (if missing)</li>";
echo "<li>Set default status as 'active' for all employees</li>";
echo "<li>Added 'employee_number' column (if missing)</li>";
echo "<li>Generated employee numbers in EMP0001 format</li>";
echo "<li>Added sample salary data for payroll testing</li>";
echo "</ul>";
echo "<p><strong>Now payroll queries with 'e.status' should work correctly!</strong></p>";
echo "</div>";

echo "<h3>Test Payroll System</h3>";
echo "<div>";
echo "<a href='admin/dashboard.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Admin Dashboard</a>";
echo "<a href='admin/employee-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Employee Management</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
table { width: 100%; margin: 10px 0; }
th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
th { background: #f0f0f0; }
ul { background: #f8f9fa; padding: 15px; border-radius: 5px; }
</style>