<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔄 Personel İş Akışı Test Sistemi</h1>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Adım 1: Personel Giriş Testi</h3>";
    
    // Test employee credentials
    $testEmployeeNumber = '30716129672';
    $testPassword = '123456';
    
    // Find employee
    $stmt = $conn->prepare("SELECT * FROM employees WHERE employee_number = ?");
    $stmt->execute([$testEmployeeNumber]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<p>✅ Test personel bulundu: " . htmlspecialchars(($employee['first_name'] ?? '') . ' ' . ($employee['last_name'] ?? '')) . "</p>";
        echo "<ul>";
        echo "<li>ID: " . $employee['id'] . "</li>";
        echo "<li>Şirket ID: " . $employee['company_id'] . "</li>";
        echo "<li>Employee Number: " . $employee['employee_number'] . "</li>";
        echo "</ul>";
        
        // Test password
        $passwordValid = false;
        if ($employee['password'] === $testPassword) {
            $passwordValid = true;
            echo "<p>✅ Şifre doğru (plain text)</p>";
        } elseif (password_verify($testPassword, $employee['password'])) {
            $passwordValid = true;
            echo "<p>✅ Şifre doğru (hash)</p>";
        } elseif (md5($testPassword) === $employee['password']) {
            $passwordValid = true;
            echo "<p>✅ Şifre doğru (MD5)</p>";
        } else {
            echo "<p>❌ Şifre yanlış - düzeltiliyor...</p>";
            $stmt = $conn->prepare("UPDATE employees SET password = ? WHERE id = ?");
            $stmt->execute([$testPassword, $employee['id']]);
            $passwordValid = true;
            echo "<p>✅ Şifre düzeltildi</p>";
        }
        
    } else {
        echo "<p>❌ Test personel bulunamadı</p>";
        echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px;'>";
        echo "<h4>Test Personeli Oluştur</h4>";
        echo "<p>Employee Number: $testEmployeeNumber</p>";
        echo "<p>Password: $testPassword</p>";
        echo "</div>";
        exit;
    }
    
    echo "<h3>Adım 2: QR Lokasyonları Kontrolü</h3>";
    
    // Check QR locations for the company
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? AND is_active = 1");
    $stmt->execute([$employee['company_id']]);
    $qrLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p>Şirket QR lokasyonları: " . count($qrLocations) . " adet</p>";
    
    if (empty($qrLocations)) {
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
        echo "<h4>⚠️ QR Lokasyon Eksik</h4>";
        echo "<p>Test için QR lokasyonları oluşturuluyor...</p>";
        
        // Create test QR locations
        $testLocations = [
            ['name' => 'Ana Giriş Kapısı', 'gate_behavior' => 'work_start', 'latitude' => 41.0082, 'longitude' => 28.9784],
            ['name' => 'Mola Alanı', 'gate_behavior' => 'break_toggle', 'latitude' => 41.0085, 'longitude' => 28.9787],
            ['name' => 'Çıkış Kapısı', 'gate_behavior' => 'work_end', 'latitude' => 41.0080, 'longitude' => 28.9781]
        ];
        
        foreach ($testLocations as $loc) {
            try {
                $qrCode = $employee['company_id'] . '|' . $loc['latitude'] . '|' . $loc['longitude'] . '|' . date('Y-m-d H:i:s');
                $stmt = $conn->prepare("
                    INSERT INTO qr_locations 
                    (company_id, name, latitude, longitude, qr_code_data, gate_behavior, is_active, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, 1, NOW())
                ");
                $stmt->execute([
                    $employee['company_id'],
                    $loc['name'],
                    $loc['latitude'],
                    $loc['longitude'],
                    $qrCode,
                    $loc['gate_behavior']
                ]);
                echo "<p>✅ " . $loc['name'] . " oluşturuldu</p>";
            } catch (Exception $e) {
                echo "<p>❌ " . $loc['name'] . " oluşturulamadı: " . $e->getMessage() . "</p>";
            }
        }
        
        // Re-fetch locations
        $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? AND is_active = 1");
        $stmt->execute([$employee['company_id']]);
        $qrLocations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "</div>";
    }
    
    echo "<h4>Mevcut QR Lokasyonları:</h4>";
    echo "<ul>";
    foreach ($qrLocations as $loc) {
        echo "<li>" . htmlspecialchars($loc['name']) . " - " . ($loc['gate_behavior'] ?? 'user_choice') . "</li>";
    }
    echo "</ul>";
    
    echo "<h3>Adım 3: Attendance Records Tablo Kontrolü</h3>";
    
    // Check attendance_records table structure
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredColumns = ['employee_id', 'qr_location_id', 'activity_type', 'check_in_time', 'date'];
    $optionalColumns = ['latitude', 'longitude', 'notes', 'created_at', 'check_date'];
    
    echo "<h4>Gerekli Kolonlar:</h4>";
    echo "<ul>";
    foreach ($requiredColumns as $col) {
        $exists = in_array($col, $columns);
        echo "<li>$col: " . ($exists ? '✅' : '❌') . "</li>";
    }
    echo "</ul>";
    
    echo "<h4>Opsiyonel Kolonlar:</h4>";
    echo "<ul>";
    foreach ($optionalColumns as $col) {
        $exists = in_array($col, $columns);
        echo "<li>$col: " . ($exists ? '✅' : '❌') . "</li>";
    }
    echo "</ul>";
    
    echo "<h3>Adım 4: İş Akışı Simulasyonu</h3>";
    
    $today = date('Y-m-d');
    
    // Clear any existing records for today for clean test
    $stmt = $conn->prepare("DELETE FROM attendance_records WHERE employee_id = ? AND date = ?");
    $stmt->execute([$employee['id'], $today]);
    echo "<p>🧹 Bugünkü test kayıtları temizlendi</p>";
    
    // Simulate work flow
    $workflowSteps = [
        ['step' => 'İşe Giriş', 'activity' => 'work_start', 'location' => 'Ana Giriş Kapısı'],
        ['step' => 'Mola Başlangıcı', 'activity' => 'break_start', 'location' => 'Mola Alanı'],
        ['step' => 'Mola Bitişi', 'activity' => 'break_end', 'location' => 'Mola Alanı'],
        ['step' => 'İşten Çıkış', 'activity' => 'work_end', 'location' => 'Çıkış Kapısı']
    ];
    
    echo "<h4>İş Akışı Test Sonuçları:</h4>";
    echo "<ol>";
    
    foreach ($workflowSteps as $index => $step) {
        // Find matching location
        $location = null;
        foreach ($qrLocations as $loc) {
            if (strpos($loc['name'], explode(' ', $step['location'])[0]) !== false) {
                $location = $loc;
                break;
            }
        }
        
        if (!$location && !empty($qrLocations)) {
            $location = $qrLocations[0]; // Use first available location
        }
        
        if ($location) {
            try {
                // Test insert with column checking
                $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
                $cols = $stmt->fetchAll(PDO::FETCH_COLUMN);
                $hasLatitude = in_array('latitude', $cols);
                $hasLongitude = in_array('longitude', $cols);
                
                if ($hasLatitude && $hasLongitude) {
                    $stmt = $conn->prepare("
                        INSERT INTO attendance_records 
                        (employee_id, qr_location_id, activity_type, check_in_time, latitude, longitude, 
                         notes, created_at, date, check_date) 
                        VALUES (?, ?, ?, NOW(), ?, ?, ?, NOW(), CURDATE(), CURDATE())
                    ");
                    $stmt->execute([
                        $employee['id'],
                        $location['id'],
                        $step['activity'],
                        $location['latitude'] ?? 41.0082,
                        $location['longitude'] ?? 28.9784,
                        "Test: " . $step['step']
                    ]);
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO attendance_records 
                        (employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date, check_date) 
                        VALUES (?, ?, ?, NOW(), ?, NOW(), CURDATE(), CURDATE())
                    ");
                    $stmt->execute([
                        $employee['id'],
                        $location['id'],
                        $step['activity'],
                        "Test: " . $step['step'] . " (GPS yok)"
                    ]);
                }
                
                echo "<li>✅ " . $step['step'] . " - " . $step['activity'] . " (" . htmlspecialchars($location['name']) . ")</li>";
                
                // Add delay between steps for realistic timing
                if ($index < count($workflowSteps) - 1) {
                    sleep(1);
                }
                
            } catch (Exception $e) {
                echo "<li>❌ " . $step['step'] . " hatası: " . $e->getMessage() . "</li>";
            }
        } else {
            echo "<li>❌ " . $step['step'] . " - Uygun lokasyon bulunamadı</li>";
        }
    }
    echo "</ol>";
    
    echo "<h3>Adım 5: Günlük Kayıt Özeti</h3>";
    
    // Get today's records
    $stmt = $conn->prepare("
        SELECT ar.*, ql.name as location_name 
        FROM attendance_records ar 
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id 
        WHERE ar.employee_id = ? AND ar.date = ? 
        ORDER BY ar.check_in_time ASC
    ");
    $stmt->execute([$employee['id'], $today]);
    $todayRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p>Bugün toplam " . count($todayRecords) . " kayıt oluşturuldu:</p>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Zaman</th><th>Aktivite</th><th>Lokasyon</th><th>Notlar</th></tr>";
    
    foreach ($todayRecords as $record) {
        $time = date('H:i:s', strtotime($record['check_in_time']));
        $activity = $record['activity_type'];
        $location = htmlspecialchars($record['location_name'] ?? 'Bilinmiyor');
        $notes = htmlspecialchars($record['notes'] ?? '');
        
        echo "<tr>";
        echo "<td>$time</td>";
        echo "<td>$activity</td>";
        echo "<td>$location</td>";
        echo "<td>$notes</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h3>🔗 Test Linkleri</h3>";
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>✅ İş Akışı Test Tamamlandı</h4>";
    echo "<p><strong>Personel Giriş Bilgileri:</strong></p>";
    echo "<p>Employee Number: $testEmployeeNumber</p>";
    echo "<p>Password: $testPassword</p>";
    
    echo "<h4>Test Sayfaları:</h4>";
    echo "<ul>";
    echo "<li><a href='auth/employee-login.php' style='color: #0056b3; font-weight: bold;'>Personel Giriş →</a></li>";
    echo "<li><a href='employee/qr-attendance.php' style='color: #0056b3;'>QR Attendance →</a></li>";
    echo "<li><a href='employee/dashboard.php' style='color: #0056b3;'>Employee Dashboard →</a></li>";
    echo "<li><a href='attendance/records.php?employee_id=" . $employee['id'] . "' style='color: #6c757d;'>Günlük Kayıtlar →</a></li>";
    echo "</ul>";
    
    echo "<h4>QR Kod Test:</h4>";
    echo "<p>Test QR kodları oluşturuldu. Mobil cihazda QR okutma sayfasından test edebilirsiniz.</p>";
    echo "</div>";
    
    echo "<h3>⚠️ Tespit Edilen Sorunlar ve Düzeltmeler</h3>";
    
    $issues = [];
    
    // Check for common issues
    if (empty($qrLocations)) {
        $issues[] = "QR lokasyonları eksik - otomatik oluşturuldu";
    }
    
    if (!in_array('latitude', $columns) || !in_array('longitude', $columns)) {
        $issues[] = "GPS koordinat kolonları eksik - sisteme GPS güvenlik kontrolü eklendi";
    }
    
    if (empty($issues)) {
        echo "<p>✅ Hiçbir kritik sorun tespit edilmedi</p>";
    } else {
        echo "<ul>";
        foreach ($issues as $issue) {
            echo "<li>✅ $issue</li>";
        }
        echo "</ul>";
    }
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24;'>";
    echo "<h4>❌ Test Hatası</h4>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<style>";
echo "body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }";
echo "table { margin: 10px 0; }";
echo "th, td { padding: 8px; text-align: left; }";
echo "ul { margin: 10px 0; padding-left: 20px; }";
echo "h3 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-top: 30px; }";
echo "</style>";
?>