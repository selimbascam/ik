-- SZB İK Takip - Quick Database Updates
-- Run this to fix immediate issues without full database reload

-- Fix missing is_blocked column in employee_devices
ALTER TABLE employee_devices 
ADD COLUMN IF NOT EXISTS is_blocked TINYINT(1) DEFAULT 0;

-- Fix missing hourly_rate and monthly_hours columns in work_settings  
ALTER TABLE work_settings 
ADD COLUMN IF NOT EXISTS hourly_rate DECIMAL(10,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS monthly_hours INT DEFAULT 225;

-- Fix missing columns in shift_templates
ALTER TABLE shift_templates 
ADD COLUMN IF NOT EXISTS description TEXT,
ADD COLUMN IF NOT EXISTS color_code VARCHAR(7) DEFAULT '#3B82F6',
ADD COLUMN IF NOT EXISTS is_active TINYINT(1) DEFAULT 1;

-- Fix missing shift_template_id column in employee_shifts
ALTER TABLE employee_shifts 
ADD COLUMN IF NOT EXISTS shift_template_id INT,
ADD INDEX IF NOT EXISTS idx_shift_template (shift_template_id);

-- Update existing records to use shift_template_id if they have shift_id
UPDATE employee_shifts 
SET shift_template_id = shift_id 
WHERE shift_template_id IS NULL AND shift_id IS NOT NULL;

-- Ensure employees table has required columns
ALTER TABLE employees 
ADD COLUMN IF NOT EXISTS is_active TINYINT(1) DEFAULT 1,
ADD COLUMN IF NOT EXISTS status ENUM('active', 'inactive', 'terminated') DEFAULT 'active';

-- Create employee_shifts table if it doesn't exist
CREATE TABLE IF NOT EXISTS employee_shifts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    shift_template_id INT NOT NULL,
    shift_date DATE NOT NULL,
    status ENUM('scheduled', 'completed', 'absent', 'late', 'early_leave') DEFAULT 'scheduled',
    late_reason TEXT,
    early_leave_reason TEXT,
    absence_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_employee_date (employee_id, shift_date),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Create shift_templates table if it doesn't exist
CREATE TABLE IF NOT EXISTS shift_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_duration INT DEFAULT 60,
    description TEXT,
    color_code VARCHAR(7) DEFAULT '#3B82F6',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_employee_shifts_template ON employee_shifts(shift_template_id);
CREATE INDEX IF NOT EXISTS idx_employee_shifts_date ON employee_shifts(shift_date);
CREATE INDEX IF NOT EXISTS idx_shift_templates_company ON shift_templates(company_id, is_active);