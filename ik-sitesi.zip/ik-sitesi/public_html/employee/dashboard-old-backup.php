<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle admin bypass for silent employee access
$adminBypass = false;
$bypassEmployeeId = null;
$adminName = '';

if (isset($_GET['admin_bypass']) && !empty($_GET['admin_bypass'])) {
    // Decode admin bypass parameter
    $bypassData = base64_decode(urldecode($_GET['admin_bypass']));
    if ($bypassData) {
        $parts = explode('|', $bypassData);
        if (count($parts) >= 2) {
            $bypassEmployeeId = intval($parts[0]);
            $bypassEmployeeName = $parts[1];
            
            // Set admin bypass session
            $_SESSION['admin_bypass'] = true;
            $_SESSION['admin_bypass_employee_id'] = $bypassEmployeeId;
            $_SESSION['admin_bypass_employee_name'] = $bypassEmployeeName;
            $_SESSION['original_admin_role'] = $_SESSION['user_role'] ?? 'admin';
            $_SESSION['original_admin_name'] = $_SESSION['user_name'] ?? 'Admin';
            
            // Redirect to clean URL
            header('Location: dashboard.php');
            exit;
        }
    }
}

// Check if this is an admin bypass session
if (isset($_SESSION['admin_bypass']) && $_SESSION['admin_bypass'] === true && isset($_SESSION['admin_bypass_employee_id'])) {
    $adminBypass = true;
    $bypassEmployeeId = $_SESSION['admin_bypass_employee_id'];
    $adminName = $_SESSION['original_admin_name'] ?? 'Admin';
} else {
    // Normal employee authentication check
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'employee') {
        header('Location: ../auth/employee-login.php');
        exit;
    }
    $adminBypass = false; // Explicitly set to false for normal employees
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get employee ID based on access type
    $employeeId = $adminBypass ? $bypassEmployeeId : $_SESSION['employee_id'];
    
    // Get employee details with flexible company name field
    try {
        // First get the employee data
        $stmt = $conn->prepare("
            SELECT e.*,
                   (SELECT COUNT(*) FROM attendance_records WHERE employee_id = e.id AND DATE(check_in) = CURDATE()) as today_attendance
            FROM employees e
            WHERE e.id = ?
        ");
        $stmt->execute([$employeeId]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($employee) {
            // Get company info separately to handle column name differences
            $compStmt = $conn->prepare("SELECT * FROM companies WHERE id = ?");
            $compStmt->execute([$employee['company_id']]);
            $company = $compStmt->fetch(PDO::FETCH_ASSOC);
            
            // Flexible company name assignment
            if ($company) {
                if (isset($company['company_name'])) {
                    $employee['company_name'] = $company['company_name'];
                } elseif (isset($company['name'])) {
                    $employee['company_name'] = $company['name'];
                } else {
                    $employee['company_name'] = 'Şirket';
                }
            } else {
                $employee['company_name'] = 'Şirket';
            }
            
            // Ensure all required fields have default values
            $employee['first_name'] = $employee['first_name'] ?? 'Personel';
            $employee['last_name'] = $employee['last_name'] ?? '';
            $employee['employee_number'] = $employee['employee_code'] ?? $employee['employee_number'] ?? 'N/A';
            $employee['email'] = $employee['email'] ?? '';
            $employee['hire_date'] = $employee['hire_date'] ?? $employee['start_date'] ?? date('Y-m-d');
        }
    } catch (Exception $e) {
        // If there's an error, create a basic employee array to prevent undefined variable errors
        $employee = [
            'id' => $employeeId,
            'first_name' => $_SESSION['employee_name'] ?? 'Personel',
            'last_name' => '',
            'employee_number' => $_SESSION['employee_code'] ?? 'N/A',
            'email' => '',
            'hire_date' => date('Y-m-d'),
            'company_name' => $_SESSION['company_name'] ?? 'Şirket',
            'today_attendance' => 0
        ];
    }
    
    if (!$employee) {
        if ($adminBypass) {
            // Clear admin bypass and redirect back
            unset($_SESSION['admin_bypass'], $_SESSION['admin_bypass_employee_id'], $_SESSION['admin_bypass_employee_name']);
            header('Location: ../admin/employee-attendance-list.php?error=employee_not_found');
        } else {
            session_destroy();
            header('Location: ../auth/employee-login.php');
        }
        exit;
    }
    
    // Get today's attendance records with safe defaults
    $todayRecords = [];
    try {
        $stmt = $conn->prepare("
            SELECT * FROM attendance_records 
            WHERE employee_id = ? AND DATE(check_in) = CURDATE()
            ORDER BY check_in DESC
        ");
        $stmt->execute([$employeeId]);
        $todayRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        // Keep empty array if query fails
    }
    
    // Get monthly summary with default values
    $monthlySummary = ['days_worked' => 0, 'total_hours' => 0];
    try {
        $stmt = $conn->prepare("
            SELECT 
                COUNT(DISTINCT DATE(check_in)) as days_worked,
                SUM(TIMESTAMPDIFF(HOUR, check_in, IFNULL(check_out, NOW()))) as total_hours
            FROM attendance_records 
            WHERE employee_id = ? 
            AND MONTH(check_in) = MONTH(CURDATE())
            AND YEAR(check_in) = YEAR(CURDATE())
        ");
        $stmt->execute([$employeeId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $monthlySummary = $result;
        }
    } catch (Exception $e) {
        // Keep default values if query fails
    }
    
    // Get today's shift with safe defaults - Fixed with fallback approach
    $todayShift = null;
    try {
        $stmt = $conn->prepare("
            SELECT 
                DATE_FORMAT(es.shift_date, '%Y-%m-%d') as shift_date,
                COALESCE(es.status, 'scheduled') as status,
                COALESCE(st.name, 'Vardiya') as shift_name,
                COALESCE(TIME_FORMAT(st.start_time, '%H:%i:%s'), '09:00:00') as start_time,
                COALESCE(TIME_FORMAT(st.end_time, '%H:%i:%s'), '17:00:00') as end_time,
                COALESCE(st.break_duration, 60) as break_duration,
                COALESCE(st.color_code, '#3B82F6') as color_code,
                COALESCE(st.description, '') as description
            FROM employee_shifts es
            LEFT JOIN shift_templates st ON es.shift_template_id = st.id AND COALESCE(st.is_active, 1) = 1
            WHERE es.employee_id = ? AND DATE(es.shift_date) = CURDATE()
            ORDER BY es.created_at DESC
            LIMIT 1
        ");
        $stmt->execute([$employeeId]);
        $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        // Fallback approach - try simpler query without shift_templates
        try {
            $stmt = $conn->prepare("
                SELECT 
                    DATE_FORMAT(es.shift_date, '%Y-%m-%d') as shift_date,
                    COALESCE(es.status, 'scheduled') as status,
                    'Vardiya' as shift_name,
                    '09:00:00' as start_time,
                    '17:00:00' as end_time,
                    60 as break_duration,
                    '#3B82F6' as color_code,
                    'Standart vardiya' as description
                FROM employee_shifts es
                WHERE es.employee_id = ? AND DATE(es.shift_date) = CURDATE()
                ORDER BY es.created_at DESC
                LIMIT 1
            ");
            $stmt->execute([$employeeId]);
            $todayShift = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e2) {
            // Keep null if both queries fail
            if ($adminBypass) {
                error_log("Both shift queries failed for employee $employeeId: " . $e->getMessage() . " | " . $e2->getMessage());
            }
        }
    }
    
    // Get upcoming shifts (next 7 days) - MySQL optimized
    $upcomingShifts = [];
    try {
        $stmt = $conn->prepare("
            SELECT 
                DATE_FORMAT(es.shift_date, '%Y-%m-%d') as shift_date,
                COALESCE(es.status, 'scheduled') as status,
                COALESCE(st.name, 'Vardiya') as shift_name,
                COALESCE(TIME_FORMAT(st.start_time, '%H:%i:%s'), '09:00:00') as start_time,
                COALESCE(TIME_FORMAT(st.end_time, '%H:%i:%s'), '17:00:00') as end_time,
                COALESCE(st.break_duration, 60) as break_duration,
                COALESCE(st.color_code, '#3B82F6') as color_code,
                COALESCE(st.description, '') as description
            FROM employee_shifts es
            LEFT JOIN shift_templates st ON es.shift_template_id = st.id AND COALESCE(st.is_active, 1) = 1
            WHERE es.employee_id = ? 
            AND DATE(es.shift_date) > CURDATE() 
            AND DATE(es.shift_date) <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
            ORDER BY es.shift_date ASC
            LIMIT 10
        ");
        $stmt->execute([$employeeId]);
        $upcomingShifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $upcomingShifts = [];
        if ($adminBypass) {
            error_log("Upcoming shifts query error for employee $employeeId: " . $e->getMessage());
        }
    }
    
    // Get recent shifts (last 7 days) - MySQL optimized
    $recentShifts = [];
    try {
        $stmt = $conn->prepare("
            SELECT 
                DATE_FORMAT(es.shift_date, '%Y-%m-%d') as shift_date,
                COALESCE(es.status, 'scheduled') as status,
                COALESCE(st.name, 'Vardiya') as shift_name,
                COALESCE(TIME_FORMAT(st.start_time, '%H:%i:%s'), '09:00:00') as start_time,
                COALESCE(TIME_FORMAT(st.end_time, '%H:%i:%s'), '17:00:00') as end_time,
                COALESCE(st.break_duration, 60) as break_duration,
                COALESCE(st.color_code, '#3B82F6') as color_code,
                COALESCE(st.description, '') as description
            FROM employee_shifts es
            LEFT JOIN shift_templates st ON es.shift_template_id = st.id AND COALESCE(st.is_active, 1) = 1
            WHERE es.employee_id = ? 
            AND DATE(es.shift_date) < CURDATE() 
            AND DATE(es.shift_date) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            ORDER BY es.shift_date DESC
            LIMIT 10
        ");
        $stmt->execute([$employeeId]);
        $recentShifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $recentShifts = [];
        if ($adminBypass) {
            error_log("Recent shifts query error for employee $employeeId: " . $e->getMessage());
        }
    }
    
} catch (Exception $e) {
    $error = "Veritabanı hatası: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Paneli - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50">
    <!-- Admin Bypass Notification -->
    <?php if ($adminBypass): ?>
    <div class="bg-yellow-100 border-l-4 border-yellow-500 p-4">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <span class="text-yellow-600 text-xl">⚠️</span>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-yellow-800">
                            <strong>Admin Görünümü:</strong> <?php echo htmlspecialchars($adminName); ?> olarak <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?> personelinin panelini görüntülüyorsunuz.
                        </p>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <a href="../admin/employee-attendance-list.php?clear_bypass=1" 
                       class="bg-yellow-600 text-white px-3 py-1 rounded text-sm hover:bg-yellow-700 transition-colors">
                        🔙 Admin Paneline Dön
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Personel Paneli</h1>
                    <p class="text-sm text-gray-600">Hoş geldiniz, <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></p>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600"><?php echo htmlspecialchars($employee['company_name']); ?></span>
                    <a href="../auth/logout.php" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                        <i data-lucide="log-out" class="w-4 h-4 inline mr-1"></i>
                        Çıkış
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Employee Info Card -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <p class="text-sm text-gray-600">Personel No</p>
                    <p class="text-lg font-semibold"><?php echo htmlspecialchars($employee['employee_number']); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">E-posta</p>
                    <p class="text-lg font-semibold"><?php echo htmlspecialchars($employee['email'] ?? '-'); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">İşe Giriş Tarihi</p>
                    <p class="text-lg font-semibold"><?php echo date('d.m.Y', strtotime($employee['hire_date'] ?? date('Y-m-d'))); ?></p>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <!-- QR Code Button -->
            <a href="qr-attendance-master.php" class="bg-blue-600 hover:bg-blue-700 text-white rounded-lg p-6 text-center transition duration-200 transform hover:scale-105">
                <div class="text-4xl mb-3">📱</div>
                <h3 class="text-xl font-bold mb-2">QR Kod Okut</h3>
                <p class="text-sm opacity-90">Master sistem - tek çözüm</p>
            </a>

            <!-- Today's Status -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="text-center">
                    <div class="text-4xl mb-3">
                        <?php echo $employee['today_attendance'] > 0 ? '✅' : '⏰'; ?>
                    </div>
                    <h3 class="text-xl font-bold mb-2">Bugünkü Durum</h3>
                    <p class="text-sm text-gray-600">
                        <?php 
                        if ($employee['today_attendance'] > 0) {
                            echo "Giriş yapıldı";
                        } else {
                            echo "Henüz giriş yapılmadı";
                        }
                        ?>
                    </p>
                </div>
            </div>

            <!-- Monthly Summary -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="text-center">
                    <div class="text-4xl mb-3">📊</div>
                    <h3 class="text-xl font-bold mb-2">Aylık Özet</h3>
                    <div class="text-sm text-gray-600">
                        <p><?php echo $monthlySummary['days_worked'] ?? 0; ?> gün çalışıldı</p>
                        <p><?php echo round($monthlySummary['total_hours'] ?? 0); ?> saat</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Today's Shift Schedule -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
            <div class="px-6 py-4 border-b bg-gray-50">
                <h2 class="text-lg font-semibold text-gray-900">📅 Vardiya Programım</h2>
            </div>
            <div class="p-6">
                <!-- Today's Shift -->
                <div class="mb-6">
                    <h3 class="text-md font-semibold text-gray-800 mb-3">🔹 Bugünkü Vardiyam</h3>
                    <?php if ($todayShift): ?>
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h4 class="font-semibold text-blue-900"><?php echo htmlspecialchars($todayShift['shift_name'] ?? 'Tanımsız Vardiya'); ?></h4>
                                    <p class="text-sm text-blue-700">
                                        <?php echo date('H:i', strtotime($todayShift['start_time'] ?? '00:00')); ?> - 
                                        <?php echo date('H:i', strtotime($todayShift['end_time'] ?? '00:00')); ?>
                                        <?php if ($todayShift['break_duration']): ?>
                                            (<?php echo $todayShift['break_duration']; ?> dk mola)
                                        <?php endif; ?>
                                    </p>
                                    <?php if ($todayShift['description']): ?>
                                        <p class="text-xs text-blue-600 mt-1"><?php echo htmlspecialchars($todayShift['description']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="text-right">
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                        <?php 
                                        $statusColors = [
                                            'scheduled' => 'bg-yellow-100 text-yellow-800',
                                            'completed' => 'bg-green-100 text-green-800',
                                            'absent' => 'bg-red-100 text-red-800',
                                            'late' => 'bg-orange-100 text-orange-800',
                                            'early_leave' => 'bg-purple-100 text-purple-800'
                                        ];
                                        echo $statusColors[$todayShift['status']] ?? 'bg-gray-100 text-gray-800';
                                        ?>
                                    ">
                                        <?php 
                                        $statusTexts = [
                                            'scheduled' => 'Planlanmış',
                                            'completed' => 'Tamamlandı',
                                            'absent' => 'Gelmedi',
                                            'late' => 'Geç Kaldı',
                                            'early_leave' => 'Erken Çıktı'
                                        ];
                                        echo $statusTexts[$todayShift['status']] ?? 'Bilinmiyor';
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
                            <p class="text-gray-600">🚫 Bugün için atanmış vardiya bulunmuyor</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Upcoming Shifts -->
                <?php if (!empty($upcomingShifts)): ?>
                <div class="mb-6">
                    <h3 class="text-md font-semibold text-gray-800 mb-3">⏭️ Yaklaşan Vardiyalar (7 Gün)</h3>
                    <div class="space-y-2">
                        <?php foreach ($upcomingShifts as $shift): ?>
                            <div class="bg-gray-50 border rounded-lg p-3">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <span class="font-medium text-gray-900">
                                            <?php echo date('d.m.Y', strtotime($shift['shift_date'])); ?> - 
                                            <?php echo htmlspecialchars($shift['shift_name'] ?? 'Tanımsız'); ?>
                                        </span>
                                        <span class="text-sm text-gray-600 ml-2">
                                            (<?php echo date('H:i', strtotime($shift['start_time'] ?? '00:00')); ?> - 
                                            <?php echo date('H:i', strtotime($shift['end_time'] ?? '00:00')); ?>)
                                        </span>
                                    </div>
                                    <span class="text-xs text-gray-500"><?php echo date('l', strtotime($shift['shift_date'])); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Recent Shifts -->
                <?php if (!empty($recentShifts)): ?>
                <div>
                    <h3 class="text-md font-semibold text-gray-800 mb-3">📋 Son Vardiyalar (7 Gün)</h3>
                    <div class="space-y-2">
                        <?php foreach ($recentShifts as $shift): ?>
                            <div class="bg-gray-50 border rounded-lg p-3">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <span class="font-medium text-gray-900">
                                            <?php echo date('d.m.Y', strtotime($shift['shift_date'])); ?> - 
                                            <?php echo htmlspecialchars($shift['shift_name'] ?? 'Tanımsız'); ?>
                                        </span>
                                        <span class="text-sm text-gray-600 ml-2">
                                            (<?php echo date('H:i', strtotime($shift['start_time'] ?? '00:00')); ?> - 
                                            <?php echo date('H:i', strtotime($shift['end_time'] ?? '00:00')); ?>)
                                        </span>
                                    </div>
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium
                                        <?php 
                                        $statusColors = [
                                            'scheduled' => 'bg-yellow-100 text-yellow-800',
                                            'completed' => 'bg-green-100 text-green-800',
                                            'absent' => 'bg-red-100 text-red-800',
                                            'late' => 'bg-orange-100 text-orange-800',
                                            'early_leave' => 'bg-purple-100 text-purple-800'
                                        ];
                                        echo $statusColors[$shift['status']] ?? 'bg-gray-100 text-gray-800';
                                        ?>
                                    ">
                                        <?php 
                                        $statusTexts = [
                                            'scheduled' => 'Planlanmış',
                                            'completed' => 'Tamamlandı',
                                            'absent' => 'Gelmedi',
                                            'late' => 'Geç Kaldı',
                                            'early_leave' => 'Erken Çıktı'
                                        ];
                                        echo $statusTexts[$shift['status']] ?? 'Bilinmiyor';
                                        ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (empty($todayShift) && empty($upcomingShifts) && empty($recentShifts)): ?>
                <div class="text-center py-8">
                    <div class="text-gray-400 text-4xl mb-4">📅</div>
                    <h3 class="text-lg font-medium text-gray-900 mb-2">Henüz Vardiya Ataması Yok</h3>
                    <p class="text-gray-600">Yöneticiniz tarafından size henüz vardiya ataması yapılmamış.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Today's Records -->
        <?php if (!empty($todayRecords)): ?>
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b bg-gray-50">
                <h2 class="text-lg font-semibold text-gray-900">🕐 Bugünkü Kayıtlar</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Giriş Saati</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Çıkış Saati</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Süre</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lokasyon</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($todayRecords as $record): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo date('H:i', strtotime($record['check_in'])); ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo $record['check_out'] ? date('H:i', strtotime($record['check_out'])) : '-'; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php 
                                if ($record['check_out']) {
                                    $diff = strtotime($record['check_out']) - strtotime($record['check_in']);
                                    echo sprintf('%d saat %d dakika', floor($diff / 3600), floor(($diff % 3600) / 60));
                                } else {
                                    echo 'Devam ediyor';
                                }
                                ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo htmlspecialchars($record['location_name'] ?? 'Bilinmiyor'); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Other Options -->
        <div class="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <a href="shift-schedule.php" class="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition text-center">
                <i data-lucide="calendar-clock" class="w-8 h-8 mx-auto mb-2 text-purple-600"></i>
                <h3 class="font-semibold">Vardiya Programım</h3>
                <p class="text-sm text-gray-600">Haftalık vardiya takvibi</p>
            </a>

            <a href="qr-attendance-master.php" class="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition text-center">
                <i data-lucide="qr-code" class="w-8 h-8 mx-auto mb-2 text-red-600"></i>
                <h3 class="font-semibold">QR Devam Kaydı</h3>
                <p class="text-sm text-gray-600">Giriş-çıkış kayıtları</p>
            </a>

            <a href="attendance-summary.php" class="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition text-center">
                <i data-lucide="bar-chart-3" class="w-8 h-8 mx-auto mb-2 text-green-600"></i>
                <h3 class="font-semibold">Devam Özeti</h3>
                <p class="text-sm text-gray-600">Aylık takip ve hedefler</p>
            </a>

            <a href="attendance-records.php" class="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition text-center">
                <i data-lucide="calendar" class="w-8 h-8 mx-auto mb-2 text-gray-600"></i>
                <h3 class="font-semibold">Detaylı Kayıtlar</h3>
                <p class="text-sm text-gray-600">Tüm kayıtlarım</p>
            </a>

            <a href="profile.php" class="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition text-center">
                <i data-lucide="user" class="w-8 h-8 mx-auto mb-2 text-gray-600"></i>
                <h3 class="font-semibold">Profilim</h3>
                <p class="text-sm text-gray-600">Kişisel bilgilerim</p>
            </a>
        </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>