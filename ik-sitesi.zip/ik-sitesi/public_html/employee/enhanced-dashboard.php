<?php
// Ana Personel Dashboard - QR Kod Okutma Odaklı
// Foreign Key Hatasını Önleyecek Güvenli Sistem
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/security.php';

// Check if user is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/secure-employee-login.php');
    exit();
}

// QR kod işleme - Ana özellik
$qrMessage = '';
$qrMessageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['qr_code'])) {
    $qrCode = trim($_POST['qr_code']);
    
    if (!empty($qrCode)) {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Begin transaction
            $conn->beginTransaction();
            
            $employeeId = $_SESSION['employee_id'];
            
            // CRITICAL: Get employee with company_id validation
            $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number, company_id FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$employee) {
                throw new Exception('Employee not found');
            }
            
            // CRITICAL: Validate company exists (Foreign Key Protection)
            $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
            $stmt->execute([$employee['company_id']]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$company) {
                error_log("CRITICAL: Company {$employee['company_id']} does not exist - Foreign key error prevented");
                throw new Exception("Company validation failed - Foreign key constraint would be violated");
            }
            
            // Parse QR code
            $locationId = null;
            $qrData = json_decode($qrCode, true);
            
            if ($qrData && isset($qrData['location_id'])) {
                $locationId = intval($qrData['location_id']);
            } elseif (is_numeric($qrCode)) {
                $locationId = intval($qrCode);
            } else {
                // Get or create default location
                $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = ? AND is_active = 1 LIMIT 1");
                $stmt->execute([$employee['company_id']]);
                $defaultLocation = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$defaultLocation) {
                    $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, location_type, is_active, created_at) VALUES (?, ?, ?, ?, NOW())");
                    $stmt->execute([$employee['company_id'], 'Default Location', 'entrance', 1]);
                    $locationId = $conn->lastInsertId();
                } else {
                    $locationId = $defaultLocation['id'];
                }
            }
            
            // Verify location belongs to company and get type
            $stmt = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE id = ? AND company_id = ?");
            $stmt->execute([$locationId, $employee['company_id']]);
            $location = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$location) {
                throw new Exception("Location not found for this company");
            }
            
            // Determine activity based on QR location type
            $locationType = $location['location_type'] ?? 'entrance';
            $isEntryQR = in_array($locationType, ['entrance', 'check_in']);
            $isExitQR = in_array($locationType, ['exit', 'check_out']);
            $isBreakQR = in_array($locationType, ['break', 'tea_break', 'lunch_break', 'smoke_break']);
            
            if ($isBreakQR) {
                // BREAK QR: Check last break activity
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at, qr_location_id
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() 
                    AND activity_type IN ('break_start', 'break_end')
                    AND qr_location_id = ?
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId, $locationId]);
                $lastBreakActivity = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($lastBreakActivity) {
                    $timeDiff = time() - strtotime($lastBreakActivity['created_at']);
                    
                    // If less than 2 minutes (120 seconds)
                    if ($timeDiff < 120) {
                        $remainingSeconds = 120 - $timeDiff;
                        $remainingMinutes = ceil($remainingSeconds / 60);
                        $conn->rollback();
                        $qrMessage = "⚠️ Mola kodu zaten okutuldu! {$remainingMinutes} dakika sonra tekrar okutabilirsiniz.";
                        $qrMessageType = 'warning';
                        throw new Exception($qrMessage);
                    }
                    
                    // More than 2 minutes - toggle break activity
                    if ($lastBreakActivity['activity_type'] === 'break_start') {
                        $activityType = 'break_end';
                    } else {
                        $activityType = 'break_start';
                    }
                } else {
                    // First break of the day
                    $activityType = 'break_start';
                }
                
            } elseif ($isEntryQR) {
                // ENTRY QR: Check if already checked in today
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() AND activity_type = 'work_start'
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId]);
                $todayWorkStart = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($todayWorkStart) {
                    $conn->rollback();
                    $qrMessage = "⚠️ Bugün zaten işe giriş yaptınız! (" . date('H:i', strtotime($todayWorkStart['check_in_time'])) . ")";
                    $qrMessageType = 'warning';
                    throw new Exception($qrMessage);
                }
                
                $activityType = 'work_start';
                
            } elseif ($isExitQR) {
                // EXIT QR: Check if there's a work_start today and no work_end yet
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() AND activity_type = 'work_start'
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId]);
                $todayWorkStart = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$todayWorkStart) {
                    $conn->rollback();
                    $qrMessage = "⚠️ Önce işe giriş yapmalısınız!";
                    $qrMessageType = 'warning';
                    throw new Exception($qrMessage);
                }
                
                // Check if already checked out
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() AND activity_type = 'work_end'
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId]);
                $todayWorkEnd = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($todayWorkEnd) {
                    $conn->rollback();
                    $qrMessage = "⚠️ Bugün zaten işten çıkış yaptınız! (" . date('H:i', strtotime($todayWorkEnd['check_in_time'])) . ")";
                    $qrMessageType = 'warning';
                    throw new Exception($qrMessage);
                }
                
                $activityType = 'work_end';
                
            } else {
                // Default behavior for other location types
                $activityType = 'work_start';
            }
            
            // SAFE INSERT: All foreign keys validated
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date) 
                VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
            ");
            
            $notes = "Enhanced Dashboard QR - {$location['name']} ({$employee['employee_number']})";
            $stmt->execute([
                $employee['company_id'], // VALIDATED company_id
                $employee['id'],
                $locationId,
                $activityType,
                $notes
            ]);
            
            $recordId = $conn->lastInsertId();
            $conn->commit();
            
            // Activity-based success messages
            $activityMessages = [
                'work_start' => '✅ 🟢 İşe giriş yapıldı',
                'work_end' => '✅ 🔴 İşten çıkış yapıldı',
                'break_start' => '✅ 🟡 Molaya çıkıldı',
                'break_end' => '✅ 🟢 Mola bitirildi'
            ];
            
            $qrMessage = ($activityMessages[$activityType] ?? 'Kayıt oluşturuldu') . " - " . $location['name'] . " (" . date('H:i') . ")";
            $qrMessageType = 'success';
            
            error_log("Enhanced Dashboard QR Success: Record $recordId created for employee {$employee['id']}");
            
        } catch (Exception $e) {
            if (isset($conn) && $conn->inTransaction()) {
                $conn->rollback();
            }
            
            error_log("Enhanced Dashboard QR Error: " . $e->getMessage());
            $qrMessage = "❌ QR kod hatası: " . $e->getMessage();
            $qrMessageType = 'error';
        }
    } else {
        $qrMessage = "❌ Lütfen geçerli bir QR kod okutun";
        $qrMessageType = 'error';
    }
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $employeeId = $_SESSION['employee_id'];
    $companyId = $_SESSION['company_id'];
    
    // Get employee details
    $stmt = execute_safe_query($conn, "
        SELECT e.*, c.company_name 
        FROM employees e 
        LEFT JOIN companies c ON e.company_id = c.id 
        WHERE e.id = ? AND e.is_active = 1
    ", [$employeeId]);
    
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        session_destroy();
        header('Location: ../auth/secure-employee-login.php?error=session_invalid');
        exit();
    }
    
    // Dashboard data queries
    $currentDate = date('Y-m-d');
    $currentMonth = date('Y-m');
    $currentYear = date('Y');
    
    // 1. Today's work summary
    $todayStmt = execute_safe_query($conn, "
        SELECT 
            COUNT(*) as total_records,
            MIN(CASE WHEN activity_type = 'work_start' THEN check_in_time END) as first_checkin,
            MAX(CASE WHEN activity_type = 'work_end' THEN check_in_time END) as last_checkout,
            SUM(CASE WHEN activity_type = 'break_start' THEN 1 ELSE 0 END) as break_count,
            SUM(CASE WHEN activity_type = 'work_start' THEN 1 ELSE 0 END) as checkin_count,
            SUM(CASE WHEN activity_type = 'work_end' THEN 1 ELSE 0 END) as checkout_count
        FROM attendance_records 
        WHERE employee_id = ? AND date = ?
    ", [$employeeId, $currentDate]);
    
    $todayData = $todayStmt->fetch(PDO::FETCH_ASSOC);
    
    // 2. Monthly work hours
    $monthlyStmt = execute_safe_query($conn, "
        SELECT 
            COUNT(DISTINCT date) as days_worked,
            COUNT(*) as total_activities,
            SUM(CASE WHEN activity_type IN ('work_start', 'work_end') THEN 1 ELSE 0 END) as work_activities
        FROM attendance_records 
        WHERE employee_id = ? AND DATE_FORMAT(date, '%Y-%m') = ?
    ", [$employeeId, $currentMonth]);
    
    $monthlyData = $monthlyStmt->fetch(PDO::FETCH_ASSOC);
    
    // 3. Recent attendance records (last 5)
    $recentStmt = execute_safe_query($conn, "
        SELECT 
            ar.*, 
            ql.name as location_name,
            DATE_FORMAT(ar.check_in_time, '%d.%m.%Y %H:%i') as formatted_time
        FROM attendance_records ar 
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ? 
        ORDER BY ar.check_in_time DESC 
        LIMIT 5
    ", [$employeeId]);
    
    $recentRecords = $recentStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 4. Current work status
    $lastActivityStmt = execute_safe_query($conn, "
        SELECT activity_type, check_in_time, DATE_FORMAT(check_in_time, '%H:%i') as time_only
        FROM attendance_records 
        WHERE employee_id = ? AND date = ?
        ORDER BY check_in_time DESC 
        LIMIT 1
    ", [$employeeId, $currentDate]);
    
    $lastActivity = $lastActivityStmt->fetch(PDO::FETCH_ASSOC);
    
    // 5. Weekly summary
    $weekStart = date('Y-m-d', strtotime('monday this week'));
    $weekEnd = date('Y-m-d', strtotime('sunday this week'));
    
    $weeklyStmt = execute_safe_query($conn, "
        SELECT 
            COUNT(DISTINCT date) as days_this_week,
            COUNT(*) as weekly_activities
        FROM attendance_records 
        WHERE employee_id = ? AND date BETWEEN ? AND ?
    ", [$employeeId, $weekStart, $weekEnd]);
    
    $weeklyData = $weeklyStmt->fetch(PDO::FETCH_ASSOC);
    
    // 6. Quick QR locations
    $qrLocationsStmt = execute_safe_query($conn, "
        SELECT id, name, gate_behavior 
        FROM qr_locations 
        WHERE company_id = ? AND is_active = 1 
        ORDER BY name LIMIT 3
    ", [$companyId]);
    
    $quickLocations = $qrLocationsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate work status
    $currentStatus = 'İşe Başlamamış';
    $statusColor = 'bg-gray-100 text-gray-700';
    $statusIcon = '⚪';
    
    if ($lastActivity) {
        switch ($lastActivity['activity_type']) {
            case 'work_start':
                $currentStatus = 'Çalışıyor (Giriş: ' . $lastActivity['time_only'] . ')';
                $statusColor = 'bg-green-100 text-green-700';
                $statusIcon = '🟢';
                break;
            case 'work_end':
                $currentStatus = 'İş Bitirdi (Çıkış: ' . $lastActivity['time_only'] . ')';
                $statusColor = 'bg-blue-100 text-blue-700';
                $statusIcon = '🔵';
                break;
            case 'break_start':
                $currentStatus = 'Molada (Başlama: ' . $lastActivity['time_only'] . ')';
                $statusColor = 'bg-yellow-100 text-yellow-700';
                $statusIcon = '🟡';
                break;
            case 'break_end':
                $currentStatus = 'Moladan Döndü (' . $lastActivity['time_only'] . ')';
                $statusColor = 'bg-green-100 text-green-700';
                $statusIcon = '🟢';
                break;
        }
    }
    
} catch (Exception $e) {
    error_log("Dashboard Error: " . $e->getMessage());
    $error_message = "Dashboard yüklenirken bir hata oluştu.";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ana Personel Sayfası - <?php echo safe_html($employee['first_name'] ?? ''); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/jsqr@1.4.0/dist/jsQR.js"></script>
    <style>
        .camera-container {
            position: relative;
            background: #1f2937;
        }
        .scanning-line {
            position: absolute;
            height: 2px;
            width: 80%;
            left: 10%;
            background: linear-gradient(90deg, transparent, #00ff00, transparent);
            animation: scan 2s linear infinite;
            box-shadow: 0 0 10px #00ff00;
        }
        @keyframes scan {
            0% { top: 0; }
            100% { top: 100%; }
        }
    </style>
    <script>
        // Auto refresh every 5 minutes
        setTimeout(function() {
            window.location.reload();
        }, 300000);
        
        // Update time display
        function updateTime() {
            const now = new Date();
            document.getElementById('current-time').textContent = now.toLocaleTimeString('tr-TR');
        }
        
        setInterval(updateTime, 1000);
        updateTime();
    </script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h1 class="text-2xl font-bold">SZB İK Takip Dashboard</h1>
                        <p class="text-blue-100">Hoş geldin, <?php echo safe_html($employee['first_name'] ?? ''); ?>!</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-blue-100">Şirket: <?php echo safe_html($employee['company_name'] ?? ''); ?></p>
                        <p class="text-sm text-blue-100">Personel No: <?php echo safe_html($employee['employee_number'] ?? ''); ?></p>
                        <p class="text-lg font-mono" id="current-time"></p>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <!-- QR Kod Okutma Mesajı -->
            <?php if (!empty($qrMessage)): ?>
            <div class="mb-6">
                <div class="<?php echo $qrMessageType === 'success' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-red-100 border-red-500 text-red-700'; ?> border-l-4 p-4 rounded">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas <?php echo $qrMessageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'; ?>"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium"><?php echo $qrMessage; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- ANA QR KOD OKUTMA ALANI - ÖN PLANDA -->
            <div class="mb-8">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <div class="text-center mb-6">
                        <h2 class="text-3xl font-bold text-gray-900 mb-2">QR Kod Okutma</h2>
                        <p class="text-gray-600">İşe giriş/çıkış için QR kodunuzu okutun</p>
                    </div>
                    
                    <!-- Kamera Alanı -->
                    <div class="camera-container bg-gray-100 rounded-lg overflow-hidden mb-4" style="height: 300px;">
                        <video id="video" class="w-full h-full object-cover" autoplay playsinline></video>
                        <canvas id="canvas" style="display: none;"></canvas>
                        <div class="scanning-line"></div>
                    </div>
                    
                    <!-- QR Sonucu ve Form -->
                    <form method="POST" action="">
                        <input type="hidden" name="qr_code" id="qr_result" value="">
                        <div class="flex flex-col items-center space-y-4">
                            <div id="qr-status" class="text-gray-600">Kamera başlatılıyor...</div>
                            <button type="submit" id="submit-qr" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg disabled:opacity-50" disabled>
                                <i class="fas fa-qrcode mr-2"></i>QR Kod Okut
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Current Status Card -->
            <div class="mb-8">
                <div class="<?php echo $statusColor; ?> rounded-lg p-6 shadow-md">
                    <div class="flex items-center justify-between">
                        <div>
                            <h2 class="text-xl font-semibold mb-2">Anlık Durum</h2>
                            <p class="text-lg"><?php echo $statusIcon; ?> <?php echo $currentStatus; ?></p>
                        </div>
                        <div class="text-right">
                            <p class="text-sm opacity-75">Bugün</p>
                            <p class="text-2xl font-bold"><?php echo $todayData['total_records']; ?></p>
                            <p class="text-sm">Kayıt</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <!-- Today's first check-in -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-green-100 p-3 rounded-full">
                            <span class="text-2xl">🌅</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">İlk Giriş</p>
                            <p class="text-xl font-bold text-gray-900">
                                <?php echo $todayData['first_checkin'] ? date('H:i', strtotime($todayData['first_checkin'])) : '---'; ?>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Today's last check-out -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-red-100 p-3 rounded-full">
                            <span class="text-2xl">🌅</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">Son Çıkış</p>
                            <p class="text-xl font-bold text-gray-900">
                                <?php echo $todayData['last_checkout'] ? date('H:i', strtotime($todayData['last_checkout'])) : '---'; ?>
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Monthly days worked -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-blue-100 p-3 rounded-full">
                            <span class="text-2xl">📅</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">Bu Ay</p>
                            <p class="text-xl font-bold text-gray-900">
                                <?php echo $monthlyData['days_worked']; ?> Gün
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Weekly summary -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-purple-100 p-3 rounded-full">
                            <span class="text-2xl">📊</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">Bu Hafta</p>
                            <p class="text-xl font-bold text-gray-900">
                                <?php echo $weeklyData['days_this_week']; ?> Gün
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content Grid -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-xl font-semibold mb-4 text-gray-900">Hızlı İşlemler</h3>
                    
                    <div class="space-y-4">
                        <!-- QR Attendance -->
                        <a href="qr-attendance.php" class="block bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg p-4 hover:from-green-600 hover:to-green-700 transition-all">
                            <div class="flex items-center">
                                <span class="text-2xl mr-3">📱</span>
                                <div>
                                    <h4 class="font-semibold">QR Kod ile Devam</h4>
                                    <p class="text-sm opacity-90">QR kod okutarak giriş/çıkış yap</p>
                                </div>
                            </div>
                        </a>

                        <!-- Attendance Records -->
                        <a href="attendance-records.php" class="block bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg p-4 hover:from-blue-600 hover:to-blue-700 transition-all">
                            <div class="flex items-center">
                                <span class="text-2xl mr-3">📋</span>
                                <div>
                                    <h4 class="font-semibold">Devam Kayıtlarım</h4>
                                    <p class="text-sm opacity-90">Mesai kayıtlarını görüntüle</p>
                                </div>
                            </div>
                        </a>

                        <!-- Profile -->
                        <a href="profile.php" class="block bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg p-4 hover:from-purple-600 hover:to-purple-700 transition-all">
                            <div class="flex items-center">
                                <span class="text-2xl mr-3">👤</span>
                                <div>
                                    <h4 class="font-semibold">Profilim</h4>
                                    <p class="text-sm opacity-90">Bilgilerimi düzenle</p>
                                </div>
                            </div>
                        </a>
                    </div>

                    <!-- Quick QR Locations -->
                    <?php if (!empty($quickLocations)): ?>
                    <div class="mt-6 pt-6 border-t border-gray-200">
                        <h4 class="font-medium text-gray-700 mb-3">Hızlı QR Lokasyonları</h4>
                        <div class="space-y-2">
                            <?php foreach ($quickLocations as $location): ?>
                            <div class="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                                <span class="text-sm font-medium"><?php echo safe_html($location['name']); ?></span>
                                <span class="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                                    <?php echo safe_html($location['gate_behavior'] ?? 'genel'); ?>
                                </span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h3 class="text-xl font-semibold mb-4 text-gray-900">Son Aktiviteler</h3>
                    
                    <?php if (!empty($recentRecords)): ?>
                    <div class="space-y-4">
                        <?php foreach ($recentRecords as $record): ?>
                        <div class="flex items-center justify-between border-l-4 border-blue-400 pl-4 py-2">
                            <div>
                                <div class="flex items-center">
                                    <?php
                                    $activityIcons = [
                                        'work_start' => '🟢',
                                        'work_end' => '🔴',
                                        'work_in' => '🟢',    // Legacy support
                                        'work_out' => '🔴',   // Legacy support
                                        'break_start' => '🟡',
                                        'break_end' => '🟢'
                                    ];
                                    $activityTexts = [
                                        'work_start' => 'İşe Başladı',
                                        'work_end' => 'İşten Çıktı',
                                        'work_in' => 'İşe Başladı',      // Legacy support
                                        'work_out' => 'İşten Çıktı',     // Legacy support
                                        'break_start' => 'Mola Başladı',
                                        'break_end' => 'Mola Bitti'
                                    ];
                                    
                                    $icon = $activityIcons[$record['activity_type']] ?? '⚪';
                                    $text = $activityTexts[$record['activity_type']] ?? $record['activity_type'];
                                    ?>
                                    <span class="mr-2"><?php echo $icon; ?></span>
                                    <div>
                                        <p class="font-medium text-gray-900"><?php echo $text; ?></p>
                                        <p class="text-sm text-gray-600">
                                            <?php echo safe_html($record['location_name'] ?? 'Bilinmiyor'); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-medium text-gray-900">
                                    <?php echo $record['formatted_time']; ?>
                                </p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-4 pt-4 border-t border-gray-200">
                        <a href="attendance-records.php" class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                            Tüm kayıtları görüntüle →
                        </a>
                    </div>
                    
                    <?php else: ?>
                    <div class="text-center py-8">
                        <span class="text-6xl">📝</span>
                        <p class="mt-4 text-gray-600">Henüz aktivite kaydı bulunmuyor.</p>
                        <a href="qr-attendance.php" class="mt-2 inline-block text-blue-600 hover:text-blue-800 font-medium">
                            İlk kaydını oluştur →
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Today's Timeline -->
            <?php if ($todayData['total_records'] > 0): ?>
            <div class="mt-8 bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold mb-4 text-gray-900">Bugünkü Zaman Çizelgesi</h3>
                
                <div class="bg-gray-50 p-4 rounded-lg">
                    <div class="flex items-center justify-between text-sm">
                        <div class="text-center">
                            <p class="font-semibold">Giriş</p>
                            <p class="text-green-600">
                                <?php echo $todayData['checkin_count']; ?> kez
                            </p>
                        </div>
                        <div class="text-center">
                            <p class="font-semibold">Çıkış</p>
                            <p class="text-red-600">
                                <?php echo $todayData['checkout_count']; ?> kez
                            </p>
                        </div>
                        <div class="text-center">
                            <p class="font-semibold">Mola</p>
                            <p class="text-yellow-600">
                                <?php echo $todayData['break_count']; ?> kez
                            </p>
                        </div>
                        <div class="text-center">
                            <p class="font-semibold">Toplam</p>
                            <p class="text-blue-600">
                                <?php echo $todayData['total_records']; ?> kayıt
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <footer class="bg-gray-800 text-white py-6 mt-12">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-sm">&copy; 2024 SZB İK Takip Sistemi</p>
                    </div>
                    <div class="space-x-4">
                        <a href="../index.php" class="text-gray-300 hover:text-white text-sm">Ana Sayfa</a>
                        <a href="../auth/secure-employee-login.php?logout=1" class="text-gray-300 hover:text-white text-sm">Çıkış Yap</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- QR Code Scanner JavaScript -->
    <script>
        let video = document.getElementById('video');
        let canvas = document.getElementById('canvas');
        let qrResult = document.getElementById('qr_result');
        let qrStatus = document.getElementById('qr-status');
        let submitBtn = document.getElementById('submit-qr');
        let canvasContext = canvas.getContext('2d');
        let scanning = false;

        // Start QR scanner
        async function startQRScanner() {
            try {
                qrStatus.textContent = 'Kamera başlatılıyor...';
                
                const stream = await navigator.mediaDevices.getUserMedia({
                    video: { 
                        facingMode: "environment",
                        width: { ideal: 640 },
                        height: { ideal: 480 }
                    }
                });
                
                video.srcObject = stream;
                video.onloadedmetadata = () => {
                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                    qrStatus.textContent = 'QR kod aramaya başladı...';
                    scanning = true;
                    scanQR();
                };
            } catch (err) {
                console.error('Kamera erişim hatası:', err);
                qrStatus.innerHTML = '<span class="text-red-600">Kamera erişimi başarısız. Lütfen kamera izni verin.</span>';
            }
        }

        // Scan for QR codes
        function scanQR() {
            if (!scanning) return;
            
            canvasContext.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = canvasContext.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height);
            
            if (code) {
                console.log('QR Code detected:', code.data);
                qrResult.value = code.data;
                qrStatus.innerHTML = '<span class="text-green-600 font-medium">✅ QR kod okundu! Formu gönderebilirsiniz.</span>';
                submitBtn.disabled = false;
                submitBtn.classList.remove('disabled:opacity-50');
                submitBtn.classList.add('bg-green-600', 'hover:bg-green-700');
                submitBtn.innerHTML = '<i class="fas fa-check-circle mr-2"></i>QR Kod Okutuldu - Gönder';
                
                // Stop scanning
                scanning = false;
                
                // Auto submit after 2 seconds
                setTimeout(() => {
                    if (qrResult.value) {
                        submitBtn.form.submit();
                    }
                }, 2000);
                
            } else {
                requestAnimationFrame(scanQR);
            }
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            startQRScanner();
        });

        // Handle form submission
        submitBtn.addEventListener('click', function(e) {
            if (!qrResult.value) {
                e.preventDefault();
                alert('Lütfen önce QR kodu okutun.');
            }
        });
    </script>

    <!-- Debug Info (Remove in production) -->
    <?php if (defined('DEBUG_MODE') && DEBUG_MODE): ?>
    <div class="fixed bottom-4 right-4 bg-gray-800 text-white p-4 rounded-lg text-xs max-w-md">
        <h5 class="font-bold mb-2">Debug Info:</h5>
        <p>Employee ID: <?php echo $employeeId; ?></p>
        <p>Company ID: <?php echo $companyId; ?></p>
        <p>Today Records: <?php echo $todayData['total_records']; ?></p>
        <p>Page Load: <?php echo date('H:i:s'); ?></p>
    </div>
    <?php endif; ?>
</body>
</html>