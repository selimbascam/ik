<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle admin bypass for silent employee access
$adminBypass = false;
$bypassEmployeeId = null;
$adminName = '';

if (isset($_SESSION['admin_bypass']) && $_SESSION['admin_bypass'] === true && isset($_SESSION['admin_bypass_employee_id'])) {
    $adminBypass = true;
    $bypassEmployeeId = $_SESSION['admin_bypass_employee_id'];
    $adminName = $_SESSION['original_admin_name'] ?? 'Admin';
} else {
    // Normal employee authentication check
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'employee') {
        header('Location: ../auth/employee-login.php');
        exit;
    }
}

$message = '';
$messageType = '';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get employee ID based on access type
    $employeeId = $adminBypass ? $bypassEmployeeId : $_SESSION['employee_id'];
    
    // Handle profile update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        $updateFields = [];
        $params = [];
        
        // Personal Information
        if (isset($_POST['phone'])) {
            $updateFields[] = "phone = ?";
            $params[] = $_POST['phone'];
        }
        if (isset($_POST['address'])) {
            $updateFields[] = "address = ?";
            $params[] = $_POST['address'];
        }
        if (isset($_POST['email'])) {
            $updateFields[] = "email = ?";
            $params[] = $_POST['email'];
        }
        
        // Emergency Contact
        if (isset($_POST['emergency_contact_name'])) {
            $updateFields[] = "emergency_contact_name = ?";
            $params[] = $_POST['emergency_contact_name'];
        }
        if (isset($_POST['emergency_contact_phone'])) {
            $updateFields[] = "emergency_contact_phone = ?";
            $params[] = $_POST['emergency_contact_phone'];
        }
        
        if (!empty($updateFields)) {
            $sql = "UPDATE employees SET " . implode(", ", $updateFields) . ", updated_at = NOW() WHERE id = ?";
            $params[] = $employeeId;
            
            $stmt = $conn->prepare($sql);
            if ($stmt->execute($params)) {
                $message = "✅ Profil bilgileriniz başarıyla güncellendi!";
                $messageType = "success";
            } else {
                $message = "❌ Profil güncelleme sırasında hata oluştu!";
                $messageType = "error";
            }
        }
    }
    
    // Get complete employee details
    $stmt = $conn->prepare("
        SELECT e.*, c.company_name, d.name as department_name,
               u.role as user_role
        FROM employees e
        JOIN companies c ON e.company_id = c.id
        LEFT JOIN departments d ON e.department_id = d.id
        LEFT JOIN users u ON e.user_id = u.id
        WHERE e.id = ?
    ");
    $stmt->execute([$employeeId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        if ($adminBypass) {
            header('Location: ../admin/employee-attendance-list.php?error=employee_not_found');
        } else {
            session_destroy();
            header('Location: ../auth/employee-login.php');
        }
        exit;
    }
    
    // Get work statistics
    $stmt = $conn->prepare("
        SELECT 
            COUNT(DISTINCT DATE(check_in_time)) as total_days_worked,
            SUM(CASE WHEN check_out_time IS NOT NULL 
                THEN TIMESTAMPDIFF(MINUTE, check_in_time, check_out_time) 
                ELSE 0 END) as total_minutes_worked
        FROM attendance_records 
        WHERE employee_id = ? 
        AND YEAR(check_in_time) = YEAR(CURDATE())
    ");
    $stmt->execute([$employeeId]);
    $workStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get recent activity
    $stmt = $conn->prepare("
        SELECT ar.*, aa.name as activity_name, ql.name as location_name
        FROM attendance_records ar
        LEFT JOIN attendance_activities aa ON ar.activity_id = aa.id
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ?
        ORDER BY ar.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$employeeId]);
    $recentActivity = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get employee documents
    $stmt = $conn->prepare("
        SELECT ed.*, dt.type_name, dt.description, dt.is_required
        FROM employee_documents ed
        LEFT JOIN document_types dt ON ed.document_type = dt.type_code
        WHERE ed.employee_id = ?
        ORDER BY dt.sort_order, ed.upload_date DESC
    ");
    $stmt->execute([$employeeId]);
    $employeeDocuments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get required document types
    $stmt = $conn->prepare("
        SELECT * FROM document_types 
        WHERE gender_specific = 'all' 
           OR gender_specific = ?
        ORDER BY sort_order
    ");
    // Assume gender based on employee data or default to 'all'
    $gender = 'all'; // You might want to add gender field to employees table
    $stmt->execute([$gender]);
    $requiredDocuments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Veritabanı hatası: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profilim - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50">
    <!-- Admin Bypass Notification -->
    <?php if ($adminBypass): ?>
    <div class="bg-yellow-100 border-l-4 border-yellow-500 p-4">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <span class="text-yellow-600 text-xl">⚠️</span>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-yellow-800">
                            <strong>Admin Görünümü:</strong> <?php echo htmlspecialchars($adminName); ?> olarak <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?> personelinin profilini görüntülüyorsunuz.
                        </p>
                    </div>
                </div>
                <div class="flex items-center space-x-2">
                    <a href="../admin/employee-attendance-list.php?clear_bypass=1" 
                       class="bg-yellow-600 text-white px-3 py-1 rounded text-sm hover:bg-yellow-700 transition-colors">
                        🔙 Admin Paneline Dön
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center">
                    <a href="dashboard.php" class="mr-4 text-gray-600 hover:text-gray-800">
                        <i data-lucide="arrow-left" class="w-5 h-5"></i>
                    </a>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Personel Profili</h1>
                        <p class="text-sm text-gray-600"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600"><?php echo htmlspecialchars($employee['company_name']); ?></span>
                    <a href="../auth/logout.php" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                        <i data-lucide="log-out" class="w-4 h-4 inline mr-1"></i>
                        Çıkış
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Message -->
        <?php if (!empty($message)): ?>
        <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Left Column - Profile Photo & Quick Stats -->
            <div class="lg:col-span-1">
                <!-- Profile Photo Card -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <div class="text-center">
                        <div class="w-32 h-32 bg-gradient-to-br from-blue-400 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <span class="text-white text-4xl font-bold">
                                <?php echo strtoupper(substr($employee['first_name'], 0, 1) . substr($employee['last_name'], 0, 1)); ?>
                            </span>
                        </div>
                        <h2 class="text-xl font-bold text-gray-900 mb-1">
                            <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                        </h2>
                        <p class="text-gray-600 mb-2"><?php echo htmlspecialchars($employee['position'] ?? 'Pozisyon Belirtilmemiş'); ?></p>
                        <div class="flex justify-center">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                <?php 
                                $statusColors = [
                                    'active' => 'bg-green-100 text-green-800',
                                    'inactive' => 'bg-yellow-100 text-yellow-800',
                                    'terminated' => 'bg-red-100 text-red-800'
                                ];
                                echo $statusColors[$employee['status']] ?? 'bg-gray-100 text-gray-800';
                                ?>
                            ">
                                <?php 
                                $statusTexts = [
                                    'active' => 'Aktif',
                                    'inactive' => 'Pasif',
                                    'terminated' => 'İş Akdi Sona Ermiş'
                                ];
                                echo $statusTexts[$employee['status']] ?? 'Bilinmiyor';
                                ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">📊 İstatistikler</h3>
                    <div class="space-y-4">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Bu Yıl Çalışılan Gün:</span>
                            <span class="font-semibold"><?php echo $workStats['total_days_worked'] ?? 0; ?> gün</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Toplam Çalışma:</span>
                            <span class="font-semibold"><?php echo round(($workStats['total_minutes_worked'] ?? 0) / 60); ?> saat</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">İşe Giriş:</span>
                            <span class="font-semibold"><?php echo $employee['hire_date'] ? date('d.m.Y', strtotime($employee['hire_date'])) : 'Belirtilmemiş'; ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Deneyim:</span>
                            <span class="font-semibold">
                                <?php 
                                if ($employee['hire_date']) {
                                    $diff = date_diff(date_create($employee['hire_date']), date_create('today'));
                                    echo $diff->y . ' yıl ' . $diff->m . ' ay';
                                } else {
                                    echo 'Belirtilmemiş';
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column - Detailed Information -->
            <div class="lg:col-span-2">
                <!-- Tabs -->
                <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div class="border-b border-gray-200">
                        <nav class="-mb-px flex">
                            <button onclick="showTab('personal')" 
                                    class="tab-button py-4 px-6 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                                👤 Kişisel Bilgiler
                            </button>
                            <button onclick="showTab('contact')" 
                                    class="tab-button py-4 px-6 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                                📱 İletişim
                            </button>
                            <button onclick="showTab('employment')" 
                                    class="tab-button py-4 px-6 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                                💼 İş Bilgileri
                            </button>
                            <button onclick="showTab('activity')" 
                                    class="tab-button py-4 px-6 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                                📋 Son Aktiviteler
                            </button>
                            <button onclick="showTab('documents')" 
                                    class="tab-button py-4 px-6 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                                📄 Evraklar
                            </button>
                        </nav>
                    </div>

                    <!-- Personal Information Tab -->
                    <div id="personal-tab" class="tab-content p-6">
                        <h3 class="text-lg font-semibold text-gray-900 mb-6">Kişisel Bilgiler</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Ad</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['first_name']); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Soyad</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['last_name']); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">TC Kimlik No</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo $employee['national_id'] ? htmlspecialchars($employee['national_id']) : 'Belirtilmemiş'; ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Doğum Tarihi</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo $employee['birth_date'] ? date('d.m.Y', strtotime($employee['birth_date'])) : 'Belirtilmemiş'; ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Personel No</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['employee_number']); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Yaş</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php 
                                    if ($employee['birth_date']) {
                                        $age = date_diff(date_create($employee['birth_date']), date_create('today'))->y;
                                        echo $age . ' yaş';
                                    } else {
                                        echo 'Belirtilmemiş';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Information Tab -->
                    <div id="contact-tab" class="tab-content p-6 hidden">
                        <h3 class="text-lg font-semibold text-gray-900 mb-6">İletişim Bilgileri</h3>
                        
                        <form method="POST" class="space-y-6">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">E-posta</label>
                                    <input type="email" name="email" value="<?php echo htmlspecialchars($employee['email'] ?? ''); ?>"
                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
                                    <input type="tel" name="phone" value="<?php echo htmlspecialchars($employee['phone'] ?? ''); ?>"
                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Adres</label>
                                <textarea name="address" rows="3"
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"><?php echo htmlspecialchars($employee['address'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="border-t pt-6">
                                <h4 class="text-md font-semibold text-gray-900 mb-4">🚨 Acil Durum İletişim</h4>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Acil Durum Kişisi</label>
                                        <input type="text" name="emergency_contact_name" 
                                               value="<?php echo htmlspecialchars($employee['emergency_contact_name'] ?? ''); ?>"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Acil Durum Telefonu</label>
                                        <input type="tel" name="emergency_contact_phone" 
                                               value="<?php echo htmlspecialchars($employee['emergency_contact_phone'] ?? ''); ?>"
                                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="flex justify-end">
                                <button type="submit" 
                                        class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    💾 Bilgileri Güncelle
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Employment Information Tab -->
                    <div id="employment-tab" class="tab-content p-6 hidden">
                        <h3 class="text-lg font-semibold text-gray-900 mb-6">İş Bilgileri</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Şirket</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['company_name']); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Departman</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['department_name'] ?? 'Departman Atanmamış'); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Pozisyon</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['position'] ?? 'Pozisyon Belirtilmemiş'); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">İşe Giriş Tarihi</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo $employee['hire_date'] ? date('d.m.Y', strtotime($employee['hire_date'])) : 'Belirtilmemiş'; ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Çalışma Saatleri</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['working_hours'] ?? '09:00-17:00'); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Çalışma Konumu</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo htmlspecialchars($employee['location'] ?? 'Belirtilmemiş'); ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">İstihdam Durumu</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php 
                                    $statusTexts = [
                                        'active' => '✅ Tam Zamanlı (Aktif)',
                                        'inactive' => '⏸️ Pasif',
                                        'terminated' => '❌ İş Akdi Sona Ermiş'
                                    ];
                                    echo $statusTexts[$employee['status']] ?? 'Bilinmiyor';
                                    ?>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Saatlik Ücret</label>
                                <div class="bg-gray-50 px-3 py-2 rounded-md">
                                    <?php echo $employee['hourly_rate'] ? number_format($employee['hourly_rate'], 2) . ' ₺' : 'Belirtilmemiş'; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity Tab -->
                    <div id="activity-tab" class="tab-content p-6 hidden">
                        <h3 class="text-lg font-semibold text-gray-900 mb-6">Son Aktiviteler</h3>
                        
                        <?php if (!empty($recentActivity)): ?>
                        <div class="space-y-4">
                            <?php foreach ($recentActivity as $activity): ?>
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <h4 class="font-medium text-gray-900">
                                            <?php echo htmlspecialchars($activity['activity_name'] ?? 'Aktivite'); ?>
                                        </h4>
                                        <p class="text-sm text-gray-600">
                                            <?php echo $activity['check_in_time'] ? date('d.m.Y H:i', strtotime($activity['check_in_time'])) : 'Tarih belirtilmemiş'; ?>
                                        </p>
                                        <?php if ($activity['location_name']): ?>
                                            <p class="text-xs text-gray-500">
                                                📍 <?php echo htmlspecialchars($activity['location_name']); ?>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-right">
                                        <?php if ($activity['check_out_time']): ?>
                                            <span class="text-sm font-medium text-green-600">
                                                Tamamlandı
                                            </span>
                                            <p class="text-xs text-gray-500">
                                                <?php echo date('H:i', strtotime($activity['check_out_time'])); ?>
                                            </p>
                                        <?php else: ?>
                                            <span class="text-sm font-medium text-blue-600">
                                                Devam Ediyor
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                        <div class="text-center py-8">
                            <div class="text-gray-400 text-4xl mb-4">📋</div>
                            <h3 class="text-lg font-medium text-gray-900 mb-2">Henüz Aktivite Yok</h3>
                            <p class="text-gray-600">Henüz kayıtlı aktiviteniz bulunmamaktadır.</p>
                        </div>
                        <?php endif; ?>
                        
                        <div class="mt-6 text-center">
                            <a href="attendance-records.php" 
                               class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 inline-flex items-center">
                                <i data-lucide="external-link" class="w-4 h-4 mr-2"></i>
                                Tüm Kayıtları Görüntüle
                            </a>
                        </div>
                    </div>

                    <!-- Documents Tab -->
                    <div id="documents-tab" class="tab-content p-6 hidden">
                        <div class="flex justify-between items-center mb-6">
                            <h3 class="text-lg font-semibold text-gray-900">Personel Evrakları</h3>
                            <button onclick="showUploadModal()" 
                                    class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 inline-flex items-center">
                                <i data-lucide="upload" class="w-4 h-4 mr-2"></i>
                                Evrak Yükle
                            </button>
                        </div>
                        
                        <!-- Required Documents List -->
                        <div class="space-y-4">
                            <?php if (!empty($requiredDocuments)): ?>
                                <?php 
                                $uploadedDocs = [];
                                foreach ($employeeDocuments as $doc) {
                                    $uploadedDocs[$doc['document_type']] = $doc;
                                }
                                ?>
                                
                                <?php foreach ($requiredDocuments as $reqDoc): ?>
                                <div class="bg-white border rounded-lg p-4">
                                    <div class="flex items-center justify-between">
                                        <div class="flex-1">
                                            <div class="flex items-center">
                                                <div class="mr-3">
                                                    <?php if (isset($uploadedDocs[$reqDoc['type_code']])): ?>
                                                        <span class="text-green-500 text-xl">✅</span>
                                                    <?php elseif ($reqDoc['is_required']): ?>
                                                        <span class="text-red-500 text-xl">❌</span>
                                                    <?php else: ?>
                                                        <span class="text-gray-400 text-xl">⭕</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div>
                                                    <h4 class="font-medium text-gray-900">
                                                        <?php echo htmlspecialchars($reqDoc['type_name']); ?>
                                                        <?php if ($reqDoc['is_required']): ?>
                                                            <span class="text-red-500 text-sm">*</span>
                                                        <?php endif; ?>
                                                    </h4>
                                                    <p class="text-sm text-gray-600">
                                                        <?php echo htmlspecialchars($reqDoc['description']); ?>
                                                    </p>
                                                    
                                                    <?php if (isset($uploadedDocs[$reqDoc['type_code']])): ?>
                                                        <div class="mt-2">
                                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                                                <?php 
                                                                $statusColors = [
                                                                    'pending' => 'bg-yellow-100 text-yellow-800',
                                                                    'approved' => 'bg-green-100 text-green-800',
                                                                    'rejected' => 'bg-red-100 text-red-800'
                                                                ];
                                                                echo $statusColors[$uploadedDocs[$reqDoc['type_code']]['status']] ?? 'bg-gray-100 text-gray-800';
                                                                ?>
                                                            ">
                                                                <?php 
                                                                $statusTexts = [
                                                                    'pending' => 'İnceleniyor',
                                                                    'approved' => 'Onaylandı',
                                                                    'rejected' => 'Reddedildi'
                                                                ];
                                                                echo $statusTexts[$uploadedDocs[$reqDoc['type_code']]['status']] ?? 'Bilinmiyor';
                                                                ?>
                                                            </span>
                                                            <span class="text-xs text-gray-500 ml-2">
                                                                <?php echo date('d.m.Y H:i', strtotime($uploadedDocs[$reqDoc['type_code']]['upload_date'])); ?>
                                                            </span>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="flex items-center space-x-2">
                                            <?php if (isset($uploadedDocs[$reqDoc['type_code']])): ?>
                                                <button onclick="viewDocument('<?php echo $uploadedDocs[$reqDoc['type_code']]['id']; ?>')" 
                                                        class="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600">
                                                    <i data-lucide="eye" class="w-4 h-4 inline mr-1"></i>
                                                    Görüntüle
                                                </button>
                                                <button onclick="replaceDocument('<?php echo $reqDoc['type_code']; ?>')" 
                                                        class="bg-orange-500 text-white px-3 py-1 rounded text-sm hover:bg-orange-600">
                                                    <i data-lucide="refresh-cw" class="w-4 h-4 inline mr-1"></i>
                                                    Değiştir
                                                </button>
                                            <?php else: ?>
                                                <button onclick="uploadDocument('<?php echo $reqDoc['type_code']; ?>')" 
                                                        class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600">
                                                    <i data-lucide="upload" class="w-4 h-4 inline mr-1"></i>
                                                    Yükle
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="text-center py-8">
                                    <div class="text-gray-400 text-4xl mb-4">📄</div>
                                    <h3 class="text-lg font-medium text-gray-900 mb-2">Evrak Türleri Tanımlanmamış</h3>
                                    <p class="text-gray-600">Henüz evrak türleri tanımlanmamıştır.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Upload Progress -->
                        <div class="mt-6 bg-gray-50 rounded-lg p-4">
                            <h4 class="font-medium text-gray-900 mb-2">📊 Evrak Tamamlanma Durumu</h4>
                            <div class="flex items-center">
                                <?php 
                                $totalRequired = count(array_filter($requiredDocuments, function($doc) { return $doc['is_required']; }));
                                $completedRequired = 0;
                                foreach ($requiredDocuments as $reqDoc) {
                                    if ($reqDoc['is_required'] && isset($uploadedDocs[$reqDoc['type_code']])) {
                                        $completedRequired++;
                                    }
                                }
                                $percentage = $totalRequired > 0 ? round(($completedRequired / $totalRequired) * 100) : 0;
                                ?>
                                <div class="flex-1 bg-gray-200 rounded-full h-2 mr-4">
                                    <div class="bg-green-500 h-2 rounded-full" style="width: <?php echo $percentage; ?>%"></div>
                                </div>
                                <span class="text-sm font-medium text-gray-600">
                                    <?php echo $completedRequired; ?>/<?php echo $totalRequired; ?> Zorunlu Evrak (<?php echo $percentage; ?>%)
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Document Upload Modal -->
    <div id="uploadModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg p-6 w-full max-w-md">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold">Evrak Yükle</h3>
                    <button onclick="closeUploadModal()" class="text-gray-400 hover:text-gray-600">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </div>
                
                <form id="uploadForm" enctype="multipart/form-data">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Evrak Türü</label>
                            <select id="documentType" name="document_type" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <option value="">Evrak türünü seçin</option>
                                <?php foreach ($requiredDocuments as $reqDoc): ?>
                                <option value="<?php echo htmlspecialchars($reqDoc['type_code']); ?>">
                                    <?php echo htmlspecialchars($reqDoc['type_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Dosya</label>
                            <input type="file" id="documentFile" name="document_file" required
                                   accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <p class="text-xs text-gray-500 mt-1">PDF, JPG, PNG, DOC dosyaları kabul edilir (Max: 10MB)</p>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Not (Opsiyonel)</label>
                            <textarea id="documentNotes" name="notes" rows="3"
                                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                      placeholder="Evrak hakkında ek bilgi..."></textarea>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closeUploadModal()" 
                                class="px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50">
                            İptal
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
                            <i data-lucide="upload" class="w-4 h-4 inline mr-1"></i>
                            Yükle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
        
        // Tab switching functionality
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.add('hidden');
            });
            
            // Remove active styling from all buttons
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('border-indigo-500', 'text-indigo-600');
                btn.classList.add('border-transparent', 'text-gray-500');
            });
            
            // Show selected tab
            document.getElementById(tabName + '-tab').classList.remove('hidden');
            
            // Add active styling to selected button
            const activeButton = document.querySelector(`[onclick="showTab('${tabName}')"]`);
            if (activeButton) {
                activeButton.classList.remove('border-transparent', 'text-gray-500');
                activeButton.classList.add('border-indigo-500', 'text-indigo-600');
            }
        }
        
        // Initialize first tab
        document.addEventListener('DOMContentLoaded', function() {
            showTab('personal');
        });
        
        // Document upload functionality
        function showUploadModal() {
            document.getElementById('uploadModal').classList.remove('hidden');
        }
        
        function closeUploadModal() {
            document.getElementById('uploadModal').classList.add('hidden');
            document.getElementById('uploadForm').reset();
        }
        
        function uploadDocument(documentType) {
            document.getElementById('documentType').value = documentType;
            showUploadModal();
        }
        
        function replaceDocument(documentType) {
            document.getElementById('documentType').value = documentType;
            showUploadModal();
        }
        
        function viewDocument(documentId) {
            window.open('view-document.php?id=' + documentId, '_blank');
        }
        
        // Handle form submission
        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<i data-lucide="loader" class="w-4 h-4 inline mr-1 animate-spin"></i> Yükleniyor...';
            submitBtn.disabled = true;
            
            fetch('upload-document.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('✅ Evrak başarıyla yüklendi!');
                    location.reload();
                } else {
                    alert('❌ Hata: ' + (data.message || 'Bilinmeyen hata'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('❌ Dosya yükleme sırasında hata oluştu!');
            })
            .finally(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                closeUploadModal();
            });
        });
    </script>
</body>
</html>