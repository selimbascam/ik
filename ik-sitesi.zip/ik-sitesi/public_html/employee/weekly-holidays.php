<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check employee access
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    header('Location: ../auth/employee-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $message = '';
    $messageType = '';
    
    // Get current employee info
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        throw new Exception("Personel bilgisi bulunamadı");
    }
    
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'save_weekly_holidays') {
            $selectedDays = $_POST['holiday_days'] ?? [];
            
            try {
                // Check if table exists, if not create it
                $checkTable = $conn->query("SHOW TABLES LIKE 'employee_weekly_holidays'");
                if ($checkTable->rowCount() === 0) {
                    $conn->exec("
                        CREATE TABLE employee_weekly_holidays (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            employee_id INT NOT NULL,
                            company_id INT NOT NULL,
                            monday BOOLEAN DEFAULT 0,
                            tuesday BOOLEAN DEFAULT 0,
                            wednesday BOOLEAN DEFAULT 0,
                            thursday BOOLEAN DEFAULT 0,
                            friday BOOLEAN DEFAULT 0,
                            saturday BOOLEAN DEFAULT 1,
                            sunday BOOLEAN DEFAULT 1,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
                            UNIQUE KEY unique_employee (employee_id)
                        )
                    ");
                }
                
                // Prepare day values
                $dayValues = [
                    'monday' => in_array('1', $selectedDays) ? 1 : 0,
                    'tuesday' => in_array('2', $selectedDays) ? 1 : 0,
                    'wednesday' => in_array('3', $selectedDays) ? 1 : 0,
                    'thursday' => in_array('4', $selectedDays) ? 1 : 0,
                    'friday' => in_array('5', $selectedDays) ? 1 : 0,
                    'saturday' => in_array('6', $selectedDays) ? 1 : 0,
                    'sunday' => in_array('0', $selectedDays) ? 1 : 0
                ];
                
                // Insert or update employee holidays
                $stmt = $conn->prepare("
                    INSERT INTO employee_weekly_holidays 
                    (employee_id, company_id, monday, tuesday, wednesday, thursday, friday, saturday, sunday)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                    monday = VALUES(monday),
                    tuesday = VALUES(tuesday),
                    wednesday = VALUES(wednesday),
                    thursday = VALUES(thursday),
                    friday = VALUES(friday),
                    saturday = VALUES(saturday),
                    sunday = VALUES(sunday),
                    updated_at = CURRENT_TIMESTAMP
                ");
                
                $stmt->execute([
                    $employee['id'],
                    $employee['company_id'],
                    $dayValues['monday'],
                    $dayValues['tuesday'],
                    $dayValues['wednesday'],
                    $dayValues['thursday'],
                    $dayValues['friday'],
                    $dayValues['saturday'],
                    $dayValues['sunday']
                ]);
                
                $message = "✅ Haftalık tatil günleriniz başarıyla kaydedildi!";
                $messageType = "success";
                
            } catch (Exception $e) {
                $message = "❌ Kaydetme hatası: " . $e->getMessage();
                $messageType = "error";
            }
        }
    }
    
    // Get current holiday settings
    $currentHolidays = [];
    try {
        $stmt = $conn->prepare("
            SELECT monday, tuesday, wednesday, thursday, friday, saturday, sunday 
            FROM employee_weekly_holidays 
            WHERE employee_id = ?
        ");
        $stmt->execute([$employee['id']]);
        $holidays = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($holidays) {
            if ($holidays['sunday']) $currentHolidays[] = '0';
            if ($holidays['monday']) $currentHolidays[] = '1';
            if ($holidays['tuesday']) $currentHolidays[] = '2';
            if ($holidays['wednesday']) $currentHolidays[] = '3';
            if ($holidays['thursday']) $currentHolidays[] = '4';
            if ($holidays['friday']) $currentHolidays[] = '5';
            if ($holidays['saturday']) $currentHolidays[] = '6';
        } else {
            // Default: Saturday and Sunday
            $currentHolidays = ['0', '6'];
        }
    } catch (Exception $e) {
        // Default holidays if table doesn't exist
        $currentHolidays = ['0', '6'];
    }
    
    // Day names in Turkish
    $dayNames = [
        '0' => 'Pazar',
        '1' => 'Pazartesi', 
        '2' => 'Salı',
        '3' => 'Çarşamba',
        '4' => 'Perşembe',
        '5' => 'Cuma',
        '6' => 'Cumartesi'
    ];
    
} catch (Exception $e) {
    $message = "❌ Sistem hatası: " . $e->getMessage();
    $messageType = "error";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Haftalık Tatil Günleri - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .day-checkbox {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }
        
        .day-checkbox input[type="checkbox"] {
            display: none;
        }
        
        .day-checkbox .checkmark {
            display: block;
            width: 100%;
            padding: 1rem;
            border: 2px solid #e5e7eb;
            border-radius: 0.75rem;
            text-align: center;
            font-weight: 600;
            transition: all 0.3s ease;
            background: white;
        }
        
        .day-checkbox input[type="checkbox"]:checked + .checkmark {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
            transform: scale(1.05);
        }
        
        .day-checkbox:hover .checkmark {
            border-color: #3b82f6;
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <h1 class="text-2xl font-bold text-gray-900">📅 Haftalık Tatil Günleri</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                        ← Ana Sayfa
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="max-w-4xl mx-auto py-8 px-4">
        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-50 border border-green-200 text-green-800' : 'bg-red-50 border border-red-200 text-red-800'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="px-6 py-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
                <h2 class="text-xl font-bold text-gray-900">🏖️ Tatil Günlerinizi Seçin</h2>
                <p class="text-gray-600 mt-1">Haftalık çalışma programınızda hangi günlerin tatil olacağını belirleyin</p>
            </div>

            <div class="p-6">
                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="save_weekly_holidays">
                    
                    <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
                        <?php foreach ($dayNames as $dayNum => $dayName): ?>
                            <label class="day-checkbox">
                                <input type="checkbox" 
                                       name="holiday_days[]" 
                                       value="<?php echo $dayNum; ?>"
                                       <?php echo in_array($dayNum, $currentHolidays) ? 'checked' : ''; ?>>
                                <span class="checkmark">
                                    <div class="text-2xl mb-2">
                                        <?php 
                                        $dayIcons = [
                                            '0' => '☀️', '1' => '💼', '2' => '📊', 
                                            '3' => '⚡', '4' => '🎯', '5' => '🕌', '6' => '🎉'
                                        ];
                                        echo $dayIcons[$dayNum];
                                        ?>
                                    </div>
                                    <?php echo $dayName; ?>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h3 class="font-bold text-blue-900 mb-2">ℹ️ Bilgi:</h3>
                        <ul class="text-sm text-blue-800 space-y-1">
                            <li>• İşaretlediğiniz günler haftalık tatil günleriniz olacaktır</li>
                            <li>• Tatil günlerinde vardiya ataması yapılmayacaktır</li>
                            <li>• En az 1, en fazla 3 gün tatil seçebilirsiniz</li>
                            <li>• Değişiklikleri kaydetmek için "Kaydet" butonuna tıklayın</li>
                        </ul>
                    </div>

                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <h3 class="font-bold text-yellow-900 mb-2">⚠️ Önemli:</h3>
                        <ul class="text-sm text-yellow-800 space-y-1">
                            <li>• Tatil günü değişiklikleri gelecekteki vardiyaları etkiler</li>
                            <li>• Mevcut vardiya programınız yöneticiniz tarafından güncellenebilir</li>
                            <li>• Özel günlerde (bayram vb.) ek tatiller uygulanabilir</li>
                        </ul>
                    </div>

                    <div class="flex justify-between items-center pt-4">
                        <div class="text-sm text-gray-600">
                            <strong>Mevcut Seçim:</strong> 
                            <span id="selected-days" class="font-medium text-blue-600">
                                <?php 
                                if (empty($currentHolidays)) {
                                    echo "Henüz seçim yapılmamış";
                                } else {
                                    $selectedNames = array_map(function($day) use ($dayNames) {
                                        return $dayNames[$day];
                                    }, $currentHolidays);
                                    echo implode(', ', $selectedNames);
                                }
                                ?>
                            </span>
                        </div>
                        
                        <button type="submit" 
                                class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                            💾 Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Current Status -->
        <div class="mt-6 bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-4">📊 Mevcut Çalışma Programınız</h3>
            
            <div class="grid grid-cols-7 gap-2">
                <?php foreach ($dayNames as $dayNum => $dayName): ?>
                    <div class="text-center p-3 rounded-lg <?php echo in_array($dayNum, $currentHolidays) ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'; ?>">
                        <div class="text-lg mb-1">
                            <?php 
                            $dayIcons = [
                                '0' => '☀️', '1' => '💼', '2' => '📊', 
                                '3' => '⚡', '4' => '🎯', '5' => '🕌', '6' => '🎉'
                            ];
                            echo $dayIcons[$dayNum];
                            ?>
                        </div>
                        <div class="text-xs font-medium"><?php echo $dayName; ?></div>
                        <div class="text-xs mt-1">
                            <?php echo in_array($dayNum, $currentHolidays) ? 'TATİL' : 'ÇALIŞMA'; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
        // Update selected days display
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('input[name="holiday_days[]"]');
            const selectedDisplay = document.getElementById('selected-days');
            
            const dayNames = {
                '0': 'Pazar',
                '1': 'Pazartesi', 
                '2': 'Salı',
                '3': 'Çarşamba',
                '4': 'Perşembe',
                '5': 'Cuma',
                '6': 'Cumartesi'
            };
            
            function updateDisplay() {
                const selected = [];
                checkboxes.forEach(function(checkbox) {
                    if (checkbox.checked) {
                        selected.push(dayNames[checkbox.value]);
                    }
                });
                
                if (selected.length === 0) {
                    selectedDisplay.textContent = 'Hiç tatil günü seçilmedi';
                    selectedDisplay.className = 'font-medium text-red-600';
                } else {
                    selectedDisplay.textContent = selected.join(', ');
                    selectedDisplay.className = 'font-medium text-blue-600';
                }
            }
            
            checkboxes.forEach(function(checkbox) {
                checkbox.addEventListener('change', updateDisplay);
            });
            
            // Initial update
            updateDisplay();
        });
    </script>
</body>
</html>