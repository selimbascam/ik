<?php
// Master QR Attendance System - DeepSeek Enhanced Security Version
// Production security settings
ini_set('display_errors', 0);
error_reporting(0);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/qr_master_errors.log');

require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/simple-employee-login.php');
    exit;
}

$message = '';
$messageType = '';

// Handle QR code scanning
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qrCode = trim($_POST['qr_code'] ?? '');
    
    if (!empty($qrCode)) {
        error_log("Master QR System - Processing QR: '$qrCode'");
        
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Begin transaction with enhanced error handling
            $conn->beginTransaction();
            
            $employeeId = $_SESSION['employee_id'];
            
            // Get employee with MANDATORY company check
            $stmt = $conn->prepare("SELECT id, first_name, last_name, employee_number, company_id FROM employees WHERE id = ?");
            $stmt->execute([$employeeId]);
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$employee) {
                throw new Exception('Employee not found');
            }
            
            // CRITICAL FIX: Ensure valid company_id - EMERGENCY ENHANCED VERSION
            if (!$employee['company_id'] || $employee['company_id'] == 0) {
                error_log("Master QR: Employee {$employee['id']} has NULL/0 company_id - applying EMERGENCY fix");
                
                // Try to get any active company (check for both status and is_active columns)
                $stmt = $conn->prepare("SELECT id, company_name FROM companies ORDER BY id LIMIT 1");
                $stmt->execute();
                $defaultCompany = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$defaultCompany) {
                    // Create emergency company - flexible column detection
                    $stmt = $conn->query("SHOW COLUMNS FROM companies");
                    $companyColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    if (in_array('status', $companyColumns)) {
                        $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                        $stmt->execute(['SZB Emergency Company', 'emergency@szb.com.tr', '555-9999', 'Emergency Company Address', 'active']);
                    } else if (in_array('is_active', $companyColumns)) {
                        $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, is_active, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                        $stmt->execute(['SZB Emergency Company', 'emergency@szb.com.tr', '555-9999', 'Emergency Company Address', 1]);
                    } else {
                        $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, NOW())");
                        $stmt->execute(['SZB Emergency Company', 'emergency@szb.com.tr', '555-9999', 'Emergency Company Address']);
                    }
                    
                    $defaultCompany = ['id' => $conn->lastInsertId(), 'company_name' => 'SZB Emergency Company'];
                    error_log("Master QR: EMERGENCY COMPANY CREATED - ID: {$defaultCompany['id']}");
                }
                
                // Update employee with verified company
                $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
                $stmt->execute([$defaultCompany['id'], $employee['id']]);
                $employee['company_id'] = $defaultCompany['id'];
                error_log("Master QR: EMERGENCY FIX APPLIED - Employee {$employee['id']} company_id = {$defaultCompany['id']}");
                
                // TRIPLE-CHECK the fix worked
                $stmt = $conn->prepare("SELECT company_id FROM employees WHERE id = ?");
                $stmt->execute([$employee['id']]);
                $checkResult = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$checkResult || $checkResult['company_id'] != $defaultCompany['id']) {
                    throw new Exception("EMERGENCY FIX FAILED: Employee {$employee['id']} company_id could not be fixed");
                }
                
                error_log("Master QR: EMERGENCY FIX VERIFIED - Employee {$employee['id']} now has company_id {$defaultCompany['id']}");
            }
            
            // ENHANCED: Verify company exists with flexible column check
            $stmt = $conn->query("SHOW COLUMNS FROM companies");
            $companyColumns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // Build flexible query based on available columns
            $selectFields = ['id', 'company_name'];
            if (in_array('status', $companyColumns)) {
                $selectFields[] = 'status';
            }
            if (in_array('is_active', $companyColumns)) {
                $selectFields[] = 'is_active';
            }
            
            $selectQuery = "SELECT " . implode(', ', $selectFields) . " FROM companies WHERE id = ?";
            $stmt = $conn->prepare($selectQuery);
            $stmt->execute([$employee['company_id']]);
            $companyCheck = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$companyCheck) {
                error_log("Master QR: CRITICAL - Company {$employee['company_id']} does not exist - FOREIGN KEY ERROR IMMINENT");
                throw new Exception("FOREIGN KEY VIOLATION BLOCKED: Company {$employee['company_id']} does not exist in companies table");
            }
            
            error_log("Master QR: Company verification PASSED - ID: {$companyCheck['id']}, Name: {$companyCheck['company_name']}");
            
            // DÜZGÜN QR KOD PARSE ETME: şirket_id|hareket_tipi|konum_id|lat,lng
            $locationId = null;
            $expectedMovement = null;
            $qrLatitude = null;
            $qrLongitude = null;
            
            // DEBUG: Log raw QR code content
            $debugMsg = "Master QR DEBUG: Raw QR Code = '{$qrCode}'";
            error_log($debugMsg);
            file_put_contents(__DIR__ . '/../debug/manual_log.txt', date('Y-m-d H:i:s') . " - " . $debugMsg . "\n", FILE_APPEND);
            
            // YENİ FORMAT: şirket_id|hareket_tipi|konum_id|lat,lng
            if (strpos($qrCode, '|') !== false) {
                $qrParts = explode('|', $qrCode);
                
                if (count($qrParts) >= 3) {
                    $qrCompanyId = intval($qrParts[0]);
                    $expectedMovement = trim($qrParts[1]);
                    $locationId = intval($qrParts[2]);
                    
                    // Koordinatlar varsa parse et
                    if (isset($qrParts[3]) && strpos($qrParts[3], ',') !== false) {
                        $coords = explode(',', $qrParts[3]);
                        if (count($coords) == 2) {
                            $qrLatitude = floatval($coords[0]);
                            $qrLongitude = floatval($coords[1]);
                        }
                    }
                    
                    // Şirket kontrolü
                    if ($qrCompanyId != $employee['company_id']) {
                        throw new Exception("Bu QR kod farklı bir şirkete ait! (QR: {$qrCompanyId}, Sizin: {$employee['company_id']})");
                    }
                    
                    error_log("Master QR DEBUG: New format - Company: {$qrCompanyId}, Movement: {$expectedMovement}, Location: {$locationId}");
                } else {
                    throw new Exception('Geçersiz QR kod formatı! Beklenen: şirket|hareket|konum|koordinat');
                }
            }
            // ESKİ FORMAT DESTEĞI (Geriye uyumluluk)
            elseif (is_numeric($qrCode)) {
                $locationId = intval($qrCode);
                error_log("Master QR DEBUG: Legacy numeric format - LocationID = {$locationId}");
            } 
            // JSON format desteği
            else {
                $qrData = json_decode($qrCode, true);
                if (json_last_error() === JSON_ERROR_NONE && isset($qrData['location_id'])) {
                    $locationId = intval($qrData['location_id']);
                    error_log("Master QR DEBUG: JSON format - LocationID = {$locationId}");
                } else {
                // Get default location for company
                $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = ? AND is_active = 1 LIMIT 1");
                $stmt->execute([$employee['company_id']]);
                $defaultLocation = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$defaultLocation) {
                    // Create default location
                    $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, location_type, is_active, created_at) VALUES (?, ?, ?, ?, NOW())");
                    $stmt->execute([$employee['company_id'], 'Default QR Location', 'entrance', 1]);
                    $locationId = $conn->lastInsertId();
                    error_log("Master QR: Created default location {$locationId} for company {$employee['company_id']}");
                } else {
                    $locationId = $defaultLocation['id'];
                }
            }
            
            // Verify location and get type
            $stmt = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE id = ? AND company_id = ?");
            $stmt->execute([$locationId, $employee['company_id']]);
            $location = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$location) {
                $debugMsg = "QR Location {$locationId} not found for company {$employee['company_id']}. Available locations: ";
                
                // Mevcut location'ları listele
                $stmt2 = $conn->prepare("SELECT id, name, location_type FROM qr_locations WHERE company_id = ? ORDER BY id");
                $stmt2->execute([$employee['company_id']]);
                $availableLocations = $stmt2->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($availableLocations as $loc) {
                    $debugMsg .= "{$loc['id']}({$loc['name']}-{$loc['location_type']}) ";
                }
                
                error_log("Master QR ERROR: " . $debugMsg);
                file_put_contents(__DIR__ . '/../debug/manual_log.txt', date('Y-m-d H:i:s') . " - Master QR ERROR: " . $debugMsg . "\n", FILE_APPEND);
                
                throw new Exception("QR Location {$locationId} bulunamadı! Mevcut location'lar: " . implode(', ', array_column($availableLocations, 'id')));
            }
            
            // Determine activity based on QR location type
            $locationType = $location['location_type'] ?? 'entrance';
            $isEntryQR = in_array($locationType, ['entrance', 'check_in']);
            $isExitQR = in_array($locationType, ['exit', 'check_out']);
            $isBreakQR = in_array($locationType, ['break', 'tea_break', 'lunch_break', 'smoke_break']);
            
            // DEBUG: Log location type check
            $debugMsg = "Master QR DEBUG: LocationID={$locationId}, Type='{$locationType}', isEntry={$isEntryQR}, isExit={$isExitQR}, isBreak={$isBreakQR}";
            error_log($debugMsg);
            file_put_contents(__DIR__ . '/../debug/manual_log.txt', date('Y-m-d H:i:s') . " - " . $debugMsg . "\n", FILE_APPEND);
            
            if ($isBreakQR) {
                // BREAK QR: Check last break activity
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at, qr_location_id
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() 
                    AND activity_type IN ('break_start', 'break_end')
                    AND qr_location_id = ?
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId, $locationId]);
                $lastBreakActivity = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($lastBreakActivity) {
                    $timeDiff = time() - strtotime($lastBreakActivity['created_at']);
                    
                    // If less than 2 minutes (120 seconds)
                    if ($timeDiff < 120) {
                        $remainingSeconds = 120 - $timeDiff;
                        $remainingMinutes = ceil($remainingSeconds / 60);
                        $conn->rollback();
                        $message = "⚠️ Mola kodu zaten okutuldu! {$remainingMinutes} dakika sonra tekrar okutabilirsiniz.";
                        $messageType = "warning";
                        throw new Exception($message);
                    }
                    
                    // More than 2 minutes - toggle break activity
                    if ($lastBreakActivity['activity_type'] === 'break_start') {
                        $activityType = 'break_end';
                    } else {
                        $activityType = 'break_start';
                    }
                } else {
                    // First break of the day
                    $activityType = 'break_start';
                }
                
            } elseif ($isEntryQR) {
                // ENTRY QR: Check if already checked in today
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() AND activity_type = 'work_start'
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId]);
                $todayWorkStart = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($todayWorkStart) {
                    $conn->rollback();
                    $message = "⚠️ Bugün zaten işe giriş yaptınız! (" . date('H:i', strtotime($todayWorkStart['check_in_time'])) . ")";
                    $messageType = "warning";
                    throw new Exception($message);
                }
                
                $activityType = 'work_start';
                
            } elseif ($isExitQR) {
                // EXIT QR: Check if there's a work_start today and no work_end yet
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() AND activity_type = 'work_start'
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId]);
                $todayWorkStart = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$todayWorkStart) {
                    $conn->rollback();
                    $message = "⚠️ Önce işe giriş yapmalısınız!";
                    $messageType = "warning";
                    throw new Exception($message);
                }
                
                // Check if already checked out
                $stmt = $conn->prepare("
                    SELECT id, activity_type, check_in_time, created_at
                    FROM attendance_records 
                    WHERE employee_id = ? AND DATE(created_at) = CURDATE() AND activity_type = 'work_end'
                    ORDER BY id DESC LIMIT 1
                ");
                $stmt->execute([$employeeId]);
                $todayWorkEnd = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($todayWorkEnd) {
                    $conn->rollback();
                    $message = "⚠️ Bugün zaten işten çıkış yaptınız! (" . date('H:i', strtotime($todayWorkEnd['check_in_time'])) . ")";
                    $messageType = "warning";
                    throw new Exception($message);
                }
                
                $activityType = 'work_end';
                
            } else {
                // ERROR: Unknown location type - This should not happen!
                error_log("Master QR ERROR: Unknown location type '{$locationType}' for location {$locationId}. Setting to work_start as fallback.");
                $activityType = 'work_start';
            }
            
            // DEBUG: Final activity type
            $debugMsg = "Master QR DEBUG: Final activityType = '{$activityType}' for location '{$location['name']}' (type: {$locationType})";
            error_log($debugMsg);
            file_put_contents(__DIR__ . '/../debug/manual_log.txt', date('Y-m-d H:i:s') . " - " . $debugMsg . "\n", FILE_APPEND);
            
            // Check for GPS columns
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $hasGPS = in_array('latitude', $columns) && in_array('longitude', $columns);
            
            // Insert attendance record with GUARANTEED company_id
            if ($hasGPS) {
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (company_id, employee_id, qr_location_id, activity_type, check_in_time, 
                     latitude, longitude, notes, created_at, date) 
                    VALUES (?, ?, ?, ?, NOW(), ?, ?, ?, NOW(), CURDATE())
                ");
                
                $stmt->execute([
                    $employee['company_id'], // GUARANTEED to be valid
                    $employee['id'],
                    $locationId,
                    $activityType,
                    $qrData['latitude'] ?? null,
                    $qrData['longitude'] ?? null,
                    "Master QR System - {$location['name']} ({$employee['employee_number']})"
                ]);
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO attendance_records 
                    (company_id, employee_id, qr_location_id, activity_type, check_in_time, 
                     notes, created_at, date) 
                    VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
                ");
                
                $stmt->execute([
                    $employee['company_id'], // GUARANTEED to be valid
                    $employee['id'],
                    $locationId,
                    $activityType,
                    "Master QR System - {$location['name']} ({$employee['employee_number']})"
                ]);
            }
            
            $recordId = $conn->lastInsertId();
            $conn->commit();
            
            // Activity-based success messages
            $activityMessages = [
                'work_start' => '✅ 🟢 İşe giriş yapıldı',
                'work_end' => '✅ 🔴 İşten çıkış yapıldı',
                'break_start' => '✅ 🟡 Molaya çıkıldı',
                'break_end' => '✅ 🟢 Mola bitirildi'
            ];
            
            $message = ($activityMessages[$activityType] ?? 'Kayıt oluşturuldu') . " - " . $location['name'] . " (" . date('H:i') . ")";
            $messageType = "success";
            
            error_log("Master QR: Success - Record $recordId created for employee {$employee['id']}");
            
            // Enhanced redirect with JavaScript fallback (DeepSeek recommendation)
            echo '<script>setTimeout(function() { window.location.href = "dashboard.php"; }, 2000);</script>';
            header("refresh:2;url=dashboard.php");
            
        } catch (Exception $e) {
            // Enhanced rollback handling (DeepSeek recommendation)
            if (isset($conn) && $conn->inTransaction()) {
                $conn->rollback();
                error_log("Master QR: Transaction rolled back due to error");
            }
            
            error_log("Master QR Error: " . $e->getMessage());
            error_log("Master QR Error Stack: " . $e->getTraceAsString());
            $message = "❌ QR kod işleme hatası: " . $e->getMessage();
            $messageType = "error";
        }
    } else {
        $message = "❌ Lütfen geçerli bir QR kodu okutun.";
        $messageType = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Kod Okuyucu - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/jsqr@1.4.0/dist/jsQR.js"></script>
    <style>
        .camera-container {
            position: relative;
            width: 100%;
            height: 60vh;
            max-height: 400px;
            overflow: hidden;
            border-radius: 12px;
        }
        .scanning-line {
            position: absolute;
            height: 2px;
            width: 100%;
            background: linear-gradient(90deg, transparent, #00ff00, transparent);
            animation: scan 2s linear infinite;
            box-shadow: 0 0 10px #00ff00;
        }
        @keyframes scan {
            0% { top: 0; }
            100% { top: 100%; }
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-6 max-w-md">
        <!-- Header -->
        <div class="text-center mb-6">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">🔍 QR Kod Okuyucu</h1>
            <p class="text-gray-600">Master System - Tek Çözüm</p>
        </div>

        <!-- Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-6 p-4 rounded-lg <?php 
                echo $messageType === 'success' ? 'bg-green-100 border border-green-300 text-green-800' : 'bg-red-100 border border-red-300 text-red-800'; 
            ?> shadow-sm">
                <div class="flex items-center">
                    <div class="text-lg mr-2">
                        <?php echo $messageType === 'success' ? '✅' : '❌'; ?>
                    </div>
                    <div><?php echo $message; ?></div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Camera Scanner -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6 border border-gray-200">
            <h3 class="font-semibold text-gray-900 mb-4">📷 QR Kod Tarayıcı</h3>
            
            <!-- Camera preview -->
            <div class="camera-container mb-4 border-2 border-gray-200">
                <video id="video" class="w-full h-full bg-black rounded-lg" style="display: none;"></video>
                <canvas id="canvas" style="display: none;"></canvas>
                
                <!-- Camera placeholder -->
                <div id="placeholder" class="w-full h-full bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-200">
                    <div class="text-center">
                        <div class="text-5xl mb-3">📷</div>
                        <p class="text-gray-600 font-medium">Kamerayı başlatmak için tıklayın</p>
                    </div>
                </div>

                <!-- Scanning line -->
                <div id="scanningLine" class="scanning-line" style="display: none;"></div>
            </div>

            <!-- Camera controls -->
            <div class="flex gap-3 mb-4">
                <button id="startBtn" class="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-blue-700">
                    📷 Kamerayı Başlat
                </button>
                <button id="stopBtn" class="flex-1 bg-red-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-red-700" style="display: none;">
                    ⏹️ Durdur
                </button>
            </div>

            <!-- Status -->
            <div id="status" class="text-center p-3 bg-gray-50 rounded-lg text-gray-600 font-medium border"></div>
        </div>

        <!-- Hidden form -->
        <form method="POST" id="qrForm" style="display: none;">
            <input type="hidden" id="qrCode" name="qr_code">
        </form>

        <!-- Navigation -->
        <div class="text-center">
            <a href="dashboard.php" class="block bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700">
                ← Dashboard'a Dön
            </a>
        </div>
    </div>

    <script>
        let stream = null;
        let scanning = 0;
        
        const video = document.getElementById('video');
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');
        const placeholder = document.getElementById('placeholder');
        const scanningLine = document.getElementById('scanningLine');
        const startBtn = document.getElementById('startBtn');
        const stopBtn = document.getElementById('stopBtn');
        const status = document.getElementById('status');
        
        // Start camera
        async function startCamera() {
            status.textContent = '📷 Kamera başlatılıyor...';
            
            try {
                stream = await navigator.mediaDevices.getUserMedia({
                    video: { facingMode: 'environment' }
                });
                
                video.srcObject = stream;
                video.play();
                
                placeholder.style.display = 'none';
                video.style.display = 'block';
                scanningLine.style.display = 'block';
                startBtn.style.display = 'none';
                stopBtn.style.display = 'block';
                status.textContent = '🔍 QR kod aranıyor...';
                
                video.onloadedmetadata = () => {
                    scanning = 1;
                    scan();
                };
                
            } catch (err) {
                status.textContent = '❌ Kamera hatası: ' + err.message;
            }
        }
        
        // Stop camera
        function stopCamera() {
            scanning = 0;
            
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }
            
            video.style.display = 'none';
            scanningLine.style.display = 'none';
            placeholder.style.display = 'flex';
            stopBtn.style.display = 'none';
            startBtn.style.display = 'block';
            status.textContent = 'Kamera durduruldu';
        }
        
        // Scan for QR codes
        function scan() {
            if (!scanning || video.readyState !== video.HAVE_ENOUGH_DATA) {
                if (scanning) requestAnimationFrame(scan);
                return;
            }
            
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height);
            
            if (code) {
                status.textContent = '✅ QR kod bulundu! İşleniyor...';
                stopCamera();
                
                document.getElementById('qrCode').value = code.data;
                document.getElementById('qrForm').submit();
            } else {
                requestAnimationFrame(scan);
            }
        }

        // Event listeners
        startBtn.addEventListener('click', startCamera);
        stopBtn.addEventListener('click', stopCamera);
        placeholder.addEventListener('click', startCamera);
        
        // Cleanup
        window.addEventListener('beforeunload', stopCamera);
    </script>
</body>
</html>