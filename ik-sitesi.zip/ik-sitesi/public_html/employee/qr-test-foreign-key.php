<?php
// Quick test for foreign key constraint
require_once '../includes/config.php';
require_once '../includes/database.php';

echo "<h2>🔧 Foreign Key Test</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Test employee 30716129672
    $employee_number = '30716129672';
    
    $stmt = $conn->prepare("SELECT id, first_name, last_name, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute([$employee_number]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo "❌ Employee not found<br>";
        exit;
    }
    
    echo "✅ Employee: {$employee['first_name']} {$employee['last_name']} (ID: {$employee['id']})<br>";
    echo "Company ID: " . ($employee['company_id'] ?? 'NULL') . "<br>";
    
    if (!$employee['company_id']) {
        echo "❌ NULL company_id - fixing...<br>";
        
        $stmt = $conn->prepare("SELECT id, company_name FROM companies ORDER BY id LIMIT 1");
        $stmt->execute();
        $company = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($company) {
            $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
            $stmt->execute([$company['id'], $employee['id']]);
            echo "✅ Fixed: Company ID set to {$company['id']}<br>";
            $employee['company_id'] = $company['id'];
        }
    }
    
    // Test QR location
    $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? LIMIT 1");
    $stmt->execute([$employee['company_id']]);
    $location = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$location) {
        echo "❌ No QR location - creating...<br>";
        $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, location_type, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$employee['company_id'], 'Default Location', 'entrance', 'active']);
        $location_id = $conn->lastInsertId();
        echo "✅ Created QR location (ID: $location_id)<br>";
        $location = ['id' => $location_id];
    }
    
    // Test insert
    try {
        $stmt = $conn->prepare("
            INSERT INTO attendance_records 
            (company_id, employee_id, qr_location_id, activity_type, check_in_time, notes, created_at, date) 
            VALUES (?, ?, ?, ?, NOW(), ?, NOW(), CURDATE())
        ");
        
        $result = $stmt->execute([
            $employee['company_id'],
            $employee['id'],
            $location['id'],
            'work_start',
            'Foreign key test - ' . date('Y-m-d H:i:s')
        ]);
        
        if ($result) {
            $recordId = $conn->lastInsertId();
            echo "✅ SUCCESS! Test record inserted (ID: $recordId)<br>";
            
            // Clean up
            $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
            $stmt->execute([$recordId]);
            echo "🧹 Test record cleaned up<br>";
        }
        
    } catch (Exception $e) {
        echo "❌ Insert failed: " . $e->getMessage() . "<br>";
    }
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; margin-top: 20px;'>";
    echo "✅ Employee ID: {$employee['id']}<br>";
    echo "✅ Company ID: {$employee['company_id']}<br>";
    echo "✅ QR Location ID: {$location['id']}<br>";
    echo "✅ Foreign key constraint should work now!<br>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>