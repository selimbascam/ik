<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle admin bypass for silent employee access
$adminBypass = false;
$bypassEmployeeId = null;
$uploadedBy = null;

if (isset($_SESSION['admin_bypass']) && $_SESSION['admin_bypass'] === true && isset($_SESSION['admin_bypass_employee_id'])) {
    $adminBypass = true;
    $bypassEmployeeId = $_SESSION['admin_bypass_employee_id'];
    $uploadedBy = $_SESSION['original_admin_id'] ?? null;
} else {
    // Normal employee authentication check
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'employee') {
        echo json_encode(['success' => false, 'message' => 'Yetkilendirme hatası']);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu']);
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get employee ID based on access type
    $employeeId = $adminBypass ? $bypassEmployeeId : $_SESSION['employee_id'];
    
    // Get employee details for company_id
    $stmt = $conn->prepare("SELECT company_id FROM employees WHERE id = ?");
    $stmt->execute([$employeeId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo json_encode(['success' => false, 'message' => 'Personel bulunamadı']);
        exit;
    }
    
    // Validate inputs
    if (!isset($_POST['document_type']) || empty($_POST['document_type'])) {
        echo json_encode(['success' => false, 'message' => 'Evrak türü seçilmeli']);
        exit;
    }
    
    if (!isset($_FILES['document_file']) || $_FILES['document_file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'message' => 'Dosya yükleme hatası']);
        exit;
    }
    
    $file = $_FILES['document_file'];
    $documentType = $_POST['document_type'];
    $notes = $_POST['notes'] ?? '';
    
    // Validate file size (10MB max)
    if ($file['size'] > 10 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'Dosya boyutu 10MB\'ı geçemez']);
        exit;
    }
    
    // Validate file type
    $allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    if (!in_array($file['type'], $allowedTypes)) {
        echo json_encode(['success' => false, 'message' => 'Desteklenmeyen dosya türü']);
        exit;
    }
    
    // Validate document type exists
    $stmt = $conn->prepare("SELECT type_name FROM document_types WHERE type_code = ?");
    $stmt->execute([$documentType]);
    $docTypeInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$docTypeInfo) {
        echo json_encode(['success' => false, 'message' => 'Geçersiz evrak türü']);
        exit;
    }
    
    // Create unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $uniqueFilename = $employeeId . '_' . $documentType . '_' . time() . '.' . $extension;
    
    // For now, store in a local directory until object storage is fully integrated
    $uploadDir = '../uploads/documents/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $filePath = $uploadDir . $uniqueFilename;
    
    if (!move_uploaded_file($file['tmp_name'], $filePath)) {
        echo json_encode(['success' => false, 'message' => 'Dosya kaydetme hatası']);
        exit;
    }
    
    // Check if document already exists for this type
    $stmt = $conn->prepare("SELECT id FROM employee_documents WHERE employee_id = ? AND document_type = ?");
    $stmt->execute([$employeeId, $documentType]);
    $existingDoc = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existingDoc) {
        // Update existing document
        $stmt = $conn->prepare("
            UPDATE employee_documents 
            SET document_name = ?, file_path = ?, file_size = ?, mime_type = ?, 
                uploaded_by = ?, upload_date = NOW(), status = 'pending', notes = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([
            $file['name'],
            $filePath,
            $file['size'],
            $file['type'],
            $uploadedBy,
            $notes,
            $existingDoc['id']
        ]);
    } else {
        // Insert new document
        $stmt = $conn->prepare("
            INSERT INTO employee_documents 
            (employee_id, company_id, document_type, document_name, file_path, file_size, mime_type, uploaded_by, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $employeeId,
            $employee['company_id'],
            $documentType,
            $file['name'],
            $filePath,
            $file['size'],
            $file['type'],
            $uploadedBy,
            $notes
        ]);
    }
    
    echo json_encode([
        'success' => true, 
        'message' => $docTypeInfo['type_name'] . ' başarıyla yüklendi'
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Sistem hatası: ' . $e->getMessage()]);
}
?>