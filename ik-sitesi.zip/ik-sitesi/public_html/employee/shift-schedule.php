<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check employee access
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    header('Location: ../auth/employee-login.php');
    exit;
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get current employee info
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        throw new Exception("Personel bilgisi bulunamadı");
    }
    
    // Get date range (current week + next 3 weeks)
    $startDate = date('Y-m-d', strtotime('monday this week'));
    $endDate = date('Y-m-d', strtotime('monday this week +3 weeks'));
    
    // Ensure shift_templates table exists
    $checkTable = $conn->query("SHOW TABLES LIKE 'shift_templates'");
    if ($checkTable->rowCount() === 0) {
        $conn->exec("
            CREATE TABLE shift_templates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                break_duration INT DEFAULT 60,
                is_active BOOLEAN DEFAULT 1,
                color_code VARCHAR(7) DEFAULT '#3B82F6',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        
        // Add default shift templates
        $conn->exec("
            INSERT INTO shift_templates (name, start_time, end_time, break_duration, color_code) VALUES
            ('Sabah Vardiyası', '09:30:00', '19:30:00', 60, '#3B82F6'),
            ('Gece Vardiyası', '22:00:00', '08:00:00', 60, '#7C3AED'),
            ('Öğle Vardiyası', '13:00:00', '23:00:00', 60, '#059669')
        ");
    }

    // Get employee shift schedule
    $stmt = $conn->prepare("
        SELECT 
            es.shift_date,
            es.status,
            COALESCE(st.name, 'Vardiya') as shift_name,
            COALESCE(st.start_time, '09:30:00') as start_time,
            COALESCE(st.end_time, '19:30:00') as end_time,
            COALESCE(st.break_duration, 60) as break_duration,
            DAYNAME(es.shift_date) as day_name,
            DATE_FORMAT(es.shift_date, '%d.%m.%Y') as formatted_date,
            DATE_FORMAT(es.shift_date, '%w') as day_of_week
        FROM employee_shifts es
        LEFT JOIN shift_templates st ON es.shift_template_id = st.id
        WHERE es.employee_id = ? 
        AND es.shift_date BETWEEN ? AND ?
        ORDER BY es.shift_date
    ");
    $stmt->execute([$employee['id'], $startDate, $endDate]);
    $shifts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get employee holiday settings
    $stmt = $conn->prepare("
        SELECT monday, tuesday, wednesday, thursday, friday, saturday, sunday 
        FROM employee_weekly_holidays 
        WHERE employee_id = ?
    ");
    $stmt->execute([$employee['id']]);
    $holidays = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Organize shifts by week
    $weeklyShifts = [];
    foreach ($shifts as $shift) {
        $weekStart = date('Y-m-d', strtotime('monday', strtotime($shift['shift_date'])));
        if (!isset($weeklyShifts[$weekStart])) {
            $weeklyShifts[$weekStart] = [];
        }
        $weeklyShifts[$weekStart][$shift['shift_date']] = $shift;
    }
    
    // Turkish day names
    $turkishDays = [
        'Monday' => 'Pazartesi',
        'Tuesday' => 'Salı', 
        'Wednesday' => 'Çarşamba',
        'Thursday' => 'Perşembe',
        'Friday' => 'Cuma',
        'Saturday' => 'Cumartesi',
        'Sunday' => 'Pazar'
    ];
    
    function isEmployeeHoliday($dayOfWeek, $holidays) {
        if (!$holidays) return ($dayOfWeek == 0 || $dayOfWeek == 6); // Default weekend
        
        $dayMapping = [
            '0' => 'sunday',
            '1' => 'monday', 
            '2' => 'tuesday',
            '3' => 'wednesday',
            '4' => 'thursday',
            '5' => 'friday',
            '6' => 'saturday'
        ];
        
        $dayColumn = $dayMapping[$dayOfWeek] ?? 'sunday';
        return (bool)($holidays[$dayColumn] ?? false);
    }
    
} catch (Exception $e) {
    $error = "Vardiya programı yüklenirken hata oluştu: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vardiya Programım - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .shift-card {
            transition: all 0.3s ease;
        }
        .shift-card:hover {
            transform: translateY(-2px);
        }
        .holiday-day {
            background: linear-gradient(135deg, #fef3c7, #fde68a);
        }
        .work-day {
            background: linear-gradient(135deg, #dbeafe, #bfdbfe);
        }
        .past-day {
            opacity: 0.6;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm border-b">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <div class="flex items-center space-x-4">
                    <h1 class="text-2xl font-bold text-gray-900">📅 Vardiya Programım</h1>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                        ← Ana Sayfa
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto py-8 px-4">
        <?php if (isset($error)): ?>
            <div class="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 text-red-800">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <!-- Employee Info -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
            <div class="flex items-center space-x-4">
                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                    <span class="text-blue-600 text-2xl">👤</span>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-gray-900">
                        <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>
                    </h2>
                    <p class="text-gray-600">
                        <?php echo htmlspecialchars($employee['department'] ?? 'Genel'); ?> • 
                        No: <?php echo htmlspecialchars($employee['employee_number'] ?? 'Personel No: ' . $employee['id']); ?>
                    </p>
                </div>
            </div>
        </div>

        <!-- Weekly Schedule -->
        <?php if (!empty($weeklyShifts)): ?>
            <?php foreach ($weeklyShifts as $weekStart => $weekShifts): ?>
                <?php 
                $weekEnd = date('Y-m-d', strtotime($weekStart . ' +6 days'));
                $weekLabel = date('d.m.Y', strtotime($weekStart)) . ' - ' . date('d.m.Y', strtotime($weekEnd));
                $isCurrentWeek = (strtotime($weekStart) <= time() && strtotime($weekEnd) >= time());
                ?>
                
                <div class="bg-white rounded-xl shadow-lg mb-8 overflow-hidden">
                    <div class="px-6 py-4 border-b <?php echo $isCurrentWeek ? 'bg-gradient-to-r from-blue-50 to-indigo-50' : 'bg-gray-50'; ?>">
                        <div class="flex items-center justify-between">
                            <h3 class="text-xl font-bold text-gray-900">
                                📆 <?php echo $weekLabel; ?>
                                <?php if ($isCurrentWeek): ?>
                                    <span class="text-sm font-normal text-blue-600 ml-2">(Bu Hafta)</span>
                                <?php endif; ?>
                            </h3>
                        </div>
                    </div>

                    <div class="p-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4">
                            <?php 
                            for ($i = 0; $i < 7; $i++):
                                $currentDate = date('Y-m-d', strtotime($weekStart . " +$i days"));
                                $dayOfWeek = date('w', strtotime($currentDate));
                                $dayName = date('l', strtotime($currentDate));
                                $turkishDayName = $turkishDays[$dayName] ?? $dayName;
                                $isToday = ($currentDate === date('Y-m-d'));
                                $isPast = (strtotime($currentDate) < strtotime('today'));
                                $isHoliday = isEmployeeHoliday($dayOfWeek, $holidays);
                                
                                $shift = $weekShifts[$currentDate] ?? null;
                            ?>
                                <div class="shift-card <?php echo $isPast ? 'past-day' : ''; ?>">
                                    <div class="<?php echo $isHoliday ? 'holiday-day' : 'work-day'; ?> p-4 rounded-lg border-2 
                                                <?php echo $isToday ? 'border-blue-500' : 'border-gray-200'; ?>">
                                        <div class="text-center">
                                            <div class="text-lg font-bold text-gray-900 mb-1">
                                                <?php echo $turkishDayName; ?>
                                                <?php if ($isToday): ?>
                                                    <span class="text-blue-600">•</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="text-sm text-gray-600 mb-3">
                                                <?php echo date('d.m', strtotime($currentDate)); ?>
                                            </div>
                                            
                                            <?php if ($isHoliday): ?>
                                                <div class="text-center">
                                                    <div class="text-2xl mb-2">🏖️</div>
                                                    <div class="text-sm font-medium text-yellow-800">TATİL</div>
                                                </div>
                                            <?php elseif ($shift): ?>
                                                <div class="text-center">
                                                    <div class="text-2xl mb-2">💼</div>
                                                    <div class="text-sm font-medium text-blue-900">
                                                        <?php echo date('H:i', strtotime($shift['start_time'])); ?> - 
                                                        <?php echo date('H:i', strtotime($shift['end_time'])); ?>
                                                    </div>
                                                    <?php if ($shift['shift_name']): ?>
                                                        <div class="text-xs text-gray-600 mt-1">
                                                            <?php echo htmlspecialchars($shift['shift_name']); ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    <div class="text-xs mt-1 px-2 py-1 rounded 
                                                        <?php 
                                                        switch($shift['status']) {
                                                            case 'scheduled': echo 'bg-blue-100 text-blue-800'; break;
                                                            case 'completed': echo 'bg-green-100 text-green-800'; break;
                                                            case 'missed': echo 'bg-red-100 text-red-800'; break;
                                                            default: echo 'bg-gray-100 text-gray-800';
                                                        }
                                                        ?>">
                                                        <?php 
                                                        switch($shift['status']) {
                                                            case 'scheduled': echo 'Planlandı'; break;
                                                            case 'completed': echo 'Tamamlandı'; break;
                                                            case 'missed': echo 'Kaçırıldı'; break;
                                                            default: echo $shift['status'];
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <div class="text-center">
                                                    <div class="text-2xl mb-2">😴</div>
                                                    <div class="text-xs font-medium text-gray-600">İzinli</div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="bg-white rounded-xl shadow-lg p-8 text-center">
                <div class="text-6xl mb-4">📅</div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">Henüz Vardiya Programı Yok</h3>
                <p class="text-gray-600 mb-6">Size henüz bir vardiya programı atanmamış.</p>
                <a href="dashboard.php" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                    Ana Sayfaya Dön
                </a>
            </div>
        <?php endif; ?>

        <!-- Legend -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-4">📋 Açıklamalar</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="flex items-center space-x-3">
                    <div class="w-6 h-6 work-day rounded border-2 border-blue-500"></div>
                    <span class="text-sm">Bugün (Çalışma)</span>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-6 h-6 holiday-day rounded"></div>
                    <span class="text-sm">Tatil Günü</span>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-6 h-6 work-day rounded"></div>
                    <span class="text-sm">Çalışma Günü</span>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-6 h-6 bg-gray-200 rounded opacity-60"></div>
                    <span class="text-sm">Geçmiş Günler</span>
                </div>
            </div>
        </div>
    </div>
</body>
</html>