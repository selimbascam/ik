<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Handle admin bypass for silent employee access
$adminBypass = false;
$bypassEmployeeId = null;

if (isset($_SESSION['admin_bypass']) && $_SESSION['admin_bypass'] === true && isset($_SESSION['admin_bypass_employee_id'])) {
    $adminBypass = true;
    $bypassEmployeeId = $_SESSION['admin_bypass_employee_id'];
} else {
    // Normal employee authentication check
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'employee') {
        header('HTTP/1.0 403 Forbidden');
        exit('Erişim reddedildi');
    }
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('HTTP/1.0 400 Bad Request');
    exit('Geçersiz evrak ID');
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get employee ID based on access type
    $employeeId = $adminBypass ? $bypassEmployeeId : $_SESSION['employee_id'];
    
    // Get document details
    $stmt = $conn->prepare("
        SELECT ed.*, dt.type_name
        FROM employee_documents ed
        LEFT JOIN document_types dt ON ed.document_type = dt.type_code
        WHERE ed.id = ? AND ed.employee_id = ?
    ");
    $stmt->execute([$_GET['id'], $employeeId]);
    $document = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$document) {
        header('HTTP/1.0 404 Not Found');
        exit('Evrak bulunamadı');
    }
    
    // Check if file exists
    if (!file_exists($document['file_path'])) {
        header('HTTP/1.0 404 Not Found');
        exit('Dosya bulunamadı');
    }
    
    // Set appropriate headers
    header('Content-Type: ' . $document['mime_type']);
    header('Content-Length: ' . $document['file_size']);
    header('Content-Disposition: inline; filename="' . $document['document_name'] . '"');
    
    // Output file
    readfile($document['file_path']);
    
} catch (Exception $e) {
    header('HTTP/1.0 500 Internal Server Error');
    exit('Sistem hatası');
}
?>