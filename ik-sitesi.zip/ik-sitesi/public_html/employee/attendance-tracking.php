<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/employee-login.php');
    exit;
}

$employeeId = $_SESSION['employee_id'];
$companyId = $_SESSION['company_id'];
$employeeName = $_SESSION['employee_name'] ?? 'Personel';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get today's records
    $today = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT ar.*, ql.name as location_name, ql.location_type
        FROM attendance_records ar
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE ar.employee_id = ? AND DATE(ar.created_at) = ?
        ORDER BY ar.created_at ASC
    ");
    $stmt->execute([$employeeId, $today]);
    $todayRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get this week's summary
    $weekStart = date('Y-m-d', strtotime('monday this week'));
    $stmt = $conn->prepare("
        SELECT DATE(created_at) as date, 
               MIN(CASE WHEN activity_type = 'work_start' THEN created_at END) as first_in,
               MAX(CASE WHEN activity_type = 'work_end' THEN created_at END) as last_out
        FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) >= ?
        GROUP BY DATE(created_at)
        ORDER BY date DESC
    ");
    $stmt->execute([$employeeId, $weekStart]);
    $weekSummary = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Veri çekme hatası: " . $e->getMessage();
    error_log("Attendance tracking error: " . $e->getMessage());
}

// Turkish activity messages
$activityMessages = [
    'work_start' => '🟢 İşe Başladı',
    'work_end' => '🔴 İşten Çıktı',
    'work_in' => '🟢 İşe Başladı',      // Legacy support
    'work_out' => '🔴 İşten Çıktı',     // Legacy support
    'break_start' => '🟡 Mola Başladı',
    'break_end' => '🟢 Mola Bitti'
];

function calculateWorkTime($firstIn, $lastOut) {
    if (!$firstIn || !$lastOut) return '--';
    $start = new DateTime($firstIn);
    $end = new DateTime($lastOut);
    $diff = $start->diff($end);
    return $diff->format('%H:%I');
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devam Takip - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .activity-icon {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .work_start { background-color: #10b981; }
        .work_end { background-color: #ef4444; }
        .break_start { background-color: #f59e0b; }
        .break_end { background-color: #10b981; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-6 max-w-4xl">
        <!-- Header -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">📊 Devam Takip</h1>
                    <p class="text-gray-600"><?php echo htmlspecialchars($employeeName); ?></p>
                </div>
                <div class="text-right">
                    <div class="text-sm text-gray-500">Bugün</div>
                    <div class="text-lg font-semibold"><?php echo date('d.m.Y'); ?></div>
                </div>
            </div>
        </div>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 class="text-lg font-semibold mb-4">⚡ Hızlı İşlemler</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <a href="qr-unified.php" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-3 rounded-lg text-center font-medium transition">
                    📱 QR Kod Okut
                </a>
                <a href="dashboard.php" class="bg-green-500 hover:bg-green-600 text-white px-4 py-3 rounded-lg text-center font-medium transition">
                    🏠 Dashboard
                </a>
            </div>
        </div>

        <!-- Today's Activity -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 class="text-lg font-semibold mb-4">📅 Bugünkü Aktiviteler</h2>
            
            <?php if (empty($todayRecords)): ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="text-4xl mb-2">⏰</div>
                    <p>Bugün henüz kayıt bulunmuyor.</p>
                    <p class="text-sm">QR kod okutarak giriş yapabilirsiniz.</p>
                </div>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($todayRecords as $record): ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center">
                                <span class="activity-icon <?php echo $record['activity_type']; ?>"></span>
                                <div>
                                    <div class="font-medium">
                                        <?php echo $activityMessages[$record['activity_type']] ?? $record['activity_type']; ?>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?php echo $record['location_name'] ?? 'Bilinmeyen Lokasyon'; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="font-medium"><?php echo date('H:i', strtotime($record['created_at'])); ?></div>
                                <div class="text-xs text-gray-500"><?php echo date('d.m.Y', strtotime($record['created_at'])); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Weekly Summary -->
        <div class="bg-white rounded-lg shadow-sm p-6">
            <h2 class="text-lg font-semibold mb-4">📈 Haftalık Özet</h2>
            
            <?php if (empty($weekSummary)): ?>
                <div class="text-center py-8 text-gray-500">
                    <p>Bu hafta henüz kayıt bulunmuyor.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="border-b">
                                <th class="text-left py-2">Tarih</th>
                                <th class="text-left py-2">İlk Giriş</th>
                                <th class="text-left py-2">Son Çıkış</th>
                                <th class="text-left py-2">Toplam Süre</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($weekSummary as $day): ?>
                                <tr class="border-b border-gray-100">
                                    <td class="py-2 font-medium">
                                        <?php 
                                        $dayName = date('l', strtotime($day['date']));
                                        $turkishDays = [
                                            'Monday' => 'Pazartesi',
                                            'Tuesday' => 'Salı',
                                            'Wednesday' => 'Çarşamba',
                                            'Thursday' => 'Perşembe',
                                            'Friday' => 'Cuma',
                                            'Saturday' => 'Cumartesi',
                                            'Sunday' => 'Pazar'
                                        ];
                                        echo $turkishDays[$dayName] ?? $dayName;
                                        echo '<br><span class="text-xs text-gray-500">' . date('d.m.Y', strtotime($day['date'])) . '</span>';
                                        ?>
                                    </td>
                                    <td class="py-2">
                                        <?php echo $day['first_in'] ? date('H:i', strtotime($day['first_in'])) : '--'; ?>
                                    </td>
                                    <td class="py-2">
                                        <?php echo $day['last_out'] ? date('H:i', strtotime($day['last_out'])) : '--'; ?>
                                    </td>
                                    <td class="py-2 font-medium">
                                        <?php echo calculateWorkTime($day['first_in'], $day['last_out']); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="text-center mt-6 text-gray-500 text-sm">
            <p>Son güncelleme: <?php echo date('H:i'); ?></p>
            <a href="../auth/employee-login.php" class="text-blue-500 hover:text-blue-600">← Giriş Ekranına Dön</a>
        </div>
    </div>

    <script>
        // Auto refresh every 30 seconds if page is visible
        let refreshInterval;
        
        function startAutoRefresh() {
            refreshInterval = setInterval(() => {
                if (!document.hidden) {
                    window.location.reload();
                }
            }, 30000);
        }
        
        function stopAutoRefresh() {
            if (refreshInterval) {
                clearInterval(refreshInterval);
            }
        }
        
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                stopAutoRefresh();
            } else {
                startAutoRefresh();
            }
        });
        
        // Start auto refresh when page loads
        startAutoRefresh();
    </script>
</body>
</html>