<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/attendance-helper.php';

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/employee-login.php');
    exit;
}

$employeeId = $_SESSION['employee_id'];
$employeeName = $_SESSION['employee_name'] ?? 'Personel';
$selectedMonth = $_GET['month'] ?? date('Y-m');

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get employee info
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->execute([$employeeId]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Initialize variables with default values
    $todayRecord = null;
    $todaySummary = [
        'status' => 'Çalışmıyor',
        'total_minutes' => 0,
        'work_minutes' => 0,
        'break_minutes' => 0,
        'payable_hours' => 0,
        'overtime_hours' => 0
    ];
    $monthlySummary = [
        'days_worked' => 0,
        'total_hours' => 0,
        'remaining_hours' => 225,
        'completion_percentage' => 0
    ];
    $weeklyRecords = [];
    
    // Bugünkü özet - Fix column name from 'date' to 'created_at'
    $today = date('Y-m-d');
    $stmt = $conn->prepare("SELECT * FROM attendance_records WHERE employee_id = ? AND DATE(created_at) = ?");
    $stmt->execute([$employeeId, $today]);
    $todayRecord = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($todayRecord) {
        $todaySummary = AttendanceHelper::calculateDailySummary($todayRecord);
    }
    
    // Aylık özet
    $monthlySummary = AttendanceHelper::calculateMonthlySummary($conn, $employeeId, $selectedMonth);
    if (!$monthlySummary) {
        $monthlySummary = [
            'days_worked' => 0,
            'total_hours' => 0,
            'remaining_hours' => 225,
            'completion_percentage' => 0
        ];
    }
    
    // Son 7 günün kayıtları - Fix column references
    $stmt = $conn->prepare("
        SELECT 
            DATE(created_at) as date,
            check_in_time as check_in, 
            MIN(CASE WHEN activity_type = 'break_start' THEN check_in_time END) as break_start,
            MIN(CASE WHEN activity_type = 'break_end' THEN check_in_time END) as break_end,
            MAX(CASE WHEN activity_type = 'work_out' THEN check_in_time END) as check_out,
            'QR Lokasyon' as location
        FROM attendance_records 
        WHERE employee_id = ? AND DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) DESC
    ");
    $stmt->execute([$employeeId]);
    $weeklyRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error = "Veri çekme hatası: " . $e->getMessage();
    error_log("Attendance summary error: " . $e->getMessage());
}

// Turkish month names
$turkishMonths = [
    1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
    5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
    9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık'
];

function formatMinutes($minutes) {
    $hours = floor($minutes / 60);
    $mins = $minutes % 60;
    return sprintf('%d:%02d', $hours, $mins);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devam Özeti - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .progress-bar {
            background: linear-gradient(90deg, #10b981 0%, #f59e0b 70%, #ef4444 90%);
        }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b">
            <div class="max-w-4xl mx-auto px-4 py-4">
                <div class="flex items-center justify-between">
                    <h1 class="text-2xl font-bold text-gray-900">Devam Özeti</h1>
                    <div class="flex items-center space-x-4">
                        <span class="text-gray-600">👤 <?php echo htmlspecialchars($employeeName); ?></span>
                        <a href="dashboard.php" class="text-blue-600 hover:underline">← Panele Dön</a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-4xl mx-auto px-4 py-6 space-y-6">
            
            <?php if (isset($error)): ?>
                <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p class="text-red-700"><?php echo htmlspecialchars($error); ?></p>
                </div>
            <?php endif; ?>

            <!-- Bugünkü Durum -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-semibold mb-4 flex items-center">
                    📅 Bugün (<?php echo date('d.m.Y'); ?>)
                    <span class="ml-auto text-sm font-normal px-3 py-1 rounded-full
                        <?php echo $todaySummary['status'] === 'Çalışıyor' ? 'bg-green-100 text-green-800' : 
                                   ($todaySummary['status'] === 'Molada' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'); ?>">
                        <?php echo htmlspecialchars($todaySummary['status'] ?? 'Çalışmıyor'); ?>
                    </span>
                </h2>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="text-center p-4 bg-blue-50 rounded-lg">
                        <div class="text-2xl font-bold text-blue-600"><?php echo formatMinutes($todaySummary['total_minutes'] ?? 0); ?></div>
                        <div class="text-sm text-gray-600">Toplam Süre</div>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded-lg">
                        <div class="text-2xl font-bold text-green-600"><?php echo formatMinutes($todaySummary['work_minutes'] ?? 0); ?></div>
                        <div class="text-sm text-gray-600">Net Çalışma</div>
                    </div>
                    <div class="text-center p-4 bg-yellow-50 rounded-lg">
                        <div class="text-2xl font-bold text-yellow-600"><?php echo formatMinutes($todaySummary['break_minutes'] ?? 0); ?></div>
                        <div class="text-sm text-gray-600">Mola Süresi</div>
                    </div>
                    <div class="text-center p-4 bg-purple-50 rounded-lg">
                        <div class="text-2xl font-bold text-purple-600"><?php echo number_format($todaySummary['payable_hours'] ?? 0, 1); ?>h</div>
                        <div class="text-sm text-gray-600">Maaş Saati</div>
                        <?php if (($todaySummary['overtime_hours'] ?? 0) > 0): ?>
                            <div class="text-xs text-red-600 font-medium">+<?php echo number_format($todaySummary['overtime_hours'], 1); ?>h fazla mesai</div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($todayRecord && $todayRecord['check_in']): ?>
                <div class="mt-4 pt-4 border-t">
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                            <span class="text-gray-500">Giriş:</span>
                            <div class="font-medium"><?php echo $todayRecord['check_in'] ? date('H:i', strtotime($todayRecord['check_in'])) : '-'; ?></div>
                        </div>
                        <div>
                            <span class="text-gray-500">Mola Başlangıç:</span>
                            <div class="font-medium"><?php echo $todayRecord['break_start'] ? date('H:i', strtotime($todayRecord['break_start'])) : '-'; ?></div>
                        </div>
                        <div>
                            <span class="text-gray-500">Mola Bitiş:</span>
                            <div class="font-medium"><?php echo $todayRecord['break_end'] ? date('H:i', strtotime($todayRecord['break_end'])) : '-'; ?></div>
                        </div>
                        <div>
                            <span class="text-gray-500">Çıkış:</span>
                            <div class="font-medium"><?php echo $todayRecord['check_out'] ? date('H:i', strtotime($todayRecord['check_out'])) : '-'; ?></div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Aylık Özet -->
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-semibold">📊 Aylık Özet</h2>
                    <select onchange="window.location.href='?month='+this.value" class="border rounded px-3 py-1">
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo date('Y') . '-' . sprintf('%02d', $m); ?>" 
                                    <?php echo ($selectedMonth === date('Y') . '-' . sprintf('%02d', $m)) ? 'selected' : ''; ?>>
                                <?php echo $turkishMonths[$m] . ' ' . date('Y'); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="text-center p-4 bg-blue-50 rounded-lg">
                        <div class="text-2xl font-bold text-blue-600"><?php echo $monthlySummary['days_worked'] ?? 0; ?></div>
                        <div class="text-sm text-gray-600">Çalışılan Gün</div>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded-lg">
                        <div class="text-2xl font-bold text-green-600"><?php echo number_format($monthlySummary['total_hours'] ?? 0, 1); ?>h</div>
                        <div class="text-sm text-gray-600">Toplam Saat</div>
                    </div>
                    <div class="text-center p-4 bg-yellow-50 rounded-lg">
                        <div class="text-2xl font-bold text-yellow-600"><?php echo number_format($monthlySummary['remaining_hours'] ?? 225, 1); ?>h</div>
                        <div class="text-sm text-gray-600">Kalan Saat</div>
                    </div>
                    <div class="text-center p-4 bg-purple-50 rounded-lg">
                        <div class="text-2xl font-bold text-purple-600">%<?php echo $monthlySummary['completion_percentage'] ?? 0; ?></div>
                        <div class="text-sm text-gray-600">Tamamlanma</div>
                    </div>
                </div>

                <!-- Progress Bar -->
                <div class="mb-4">
                    <div class="flex justify-between text-sm mb-2">
                        <span>Aylık Hedef: 225 saat</span>
                        <span><?php echo number_format($monthlySummary['total_hours'] ?? 0, 1); ?> / 225 saat</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-3">
                        <div class="progress-bar h-3 rounded-full" style="width: <?php echo min(100, $monthlySummary['completion_percentage'] ?? 0); ?>%"></div>
                    </div>
                </div>
            </div>

            <!-- Son 7 Gün -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-semibold mb-4">📋 Son 7 Gün</h2>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead>
                            <tr class="border-b">
                                <th class="text-left py-2">Tarih</th>
                                <th class="text-left py-2">Giriş</th>
                                <th class="text-left py-2">Mola</th>
                                <th class="text-left py-2">Çıkış</th>
                                <th class="text-left py-2">Toplam</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($weeklyRecords)): ?>
                                <?php foreach ($weeklyRecords as $record): ?>
                                    <?php $summary = AttendanceHelper::calculateDailySummary($record); ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="py-2 font-medium"><?php echo date('d.m.Y', strtotime($record['date'])); ?></td>
                                        <td class="py-2"><?php echo $record['check_in'] ? date('H:i', strtotime($record['check_in'])) : '-'; ?></td>
                                        <td class="py-2">
                                            <?php if ($record['break_start'] && $record['break_end']): ?>
                                                <?php echo date('H:i', strtotime($record['break_start'])) . ' - ' . date('H:i', strtotime($record['break_end'])); ?>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td class="py-2"><?php echo $record['check_out'] ? date('H:i', strtotime($record['check_out'])) : '-'; ?></td>
                                        <td class="py-2 font-medium"><?php echo formatMinutes($summary['work_minutes'] ?? 0); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="py-4 text-center text-gray-500">Son 7 günde kayıt bulunamadı</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Hızlı İşlemler -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-xl font-semibold mb-4">⚡ Hızlı İşlemler</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <a href="qr-unified.php" class="bg-blue-600 text-white text-center py-3 px-4 rounded-lg hover:bg-blue-700 transition">
                        📱 QR Kod Okut
                    </a>
                    <a href="attendance-records.php" class="bg-green-600 text-white text-center py-3 px-4 rounded-lg hover:bg-green-700 transition">
                        📋 Detaylı Kayıtlar
                    </a>
                    <a href="dashboard.php" class="bg-gray-600 text-white text-center py-3 px-4 rounded-lg hover:bg-gray-700 transition">
                        🏠 Ana Panel
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Sayfa otomatik yenilenme (30 saniye)
        setTimeout(() => {
            window.location.reload();
        }, 30000);
    </script>
</body>
</html>