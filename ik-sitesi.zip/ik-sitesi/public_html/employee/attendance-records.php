<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/security.php';

// Check if user is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: ../auth/secure-employee-login.php');
    exit();
}

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    $employeeId = $_SESSION['employee_id'];
    
    // Get employee details
    $stmt = execute_safe_query($conn, "
        SELECT e.*, c.company_name 
        FROM employees e 
        LEFT JOIN companies c ON e.company_id = c.id 
        WHERE e.id = ?
    ", [$employeeId]);
    
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Filtering parameters
    $dateFilter = $_GET['date'] ?? date('Y-m-d');
    $monthFilter = $_GET['month'] ?? date('Y-m');
    $activityFilter = $_GET['activity'] ?? '';
    $viewType = $_GET['view'] ?? 'daily';
    
    // Build query based on view type
    $whereConditions = ["ar.employee_id = ?"];
    $params = [$employeeId];
    
    if ($viewType === 'daily' && $dateFilter) {
        $whereConditions[] = "ar.date = ?";
        $params[] = $dateFilter;
    } elseif ($viewType === 'monthly' && $monthFilter) {
        $whereConditions[] = "DATE_FORMAT(ar.date, '%Y-%m') = ?";
        $params[] = $monthFilter;
    }
    
    if ($activityFilter) {
        $whereConditions[] = "ar.activity_type = ?";
        $params[] = $activityFilter;
    }
    
    $whereClause = implode(' AND ', $whereConditions);
    
    // Get attendance records
    $recordsStmt = execute_safe_query($conn, "
        SELECT 
            ar.*,
            ql.name as location_name,
            ql.gate_behavior,
            DATE_FORMAT(ar.check_in_time, '%d.%m.%Y') as formatted_date,
            DATE_FORMAT(ar.check_in_time, '%H:%i') as formatted_time,
            DATE_FORMAT(ar.check_in_time, '%W') as day_name
        FROM attendance_records ar
        LEFT JOIN qr_locations ql ON ar.qr_location_id = ql.id
        WHERE $whereClause
        ORDER BY ar.check_in_time DESC
        LIMIT 100
    ", $params);
    
    $records = $recordsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get summary statistics
    $summaryStmt = execute_safe_query($conn, "
        SELECT 
            COUNT(*) as total_records,
            COUNT(DISTINCT ar.date) as days_worked,
            SUM(CASE WHEN ar.activity_type = 'work_start' THEN 1 ELSE 0 END) as work_starts,
            SUM(CASE WHEN ar.activity_type = 'work_end' THEN 1 ELSE 0 END) as work_ends,
            SUM(CASE WHEN ar.activity_type LIKE 'break_%' THEN 1 ELSE 0 END) as breaks,
            MIN(ar.check_in_time) as first_record,
            MAX(ar.check_in_time) as last_record
        FROM attendance_records ar
        WHERE $whereClause
    ", $params);
    
    $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    error_log("Attendance Records Error: " . $e->getMessage());
    $error_message = "Kayıtlar yüklenirken bir hata oluştu.";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devam Kayıtlarım - SZB İK Takip</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h1 class="text-2xl font-bold">Devam Kayıtlarım</h1>
                        <p class="text-blue-100"><?php echo safe_html($employee['first_name'] . ' ' . $employee['last_name']); ?></p>
                    </div>
                    <div class="space-x-4">
                        <a href="enhanced-dashboard.php" class="bg-blue-500 hover:bg-blue-400 px-4 py-2 rounded-lg transition-colors">
                            ← Dashboard
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            
            <!-- Filters -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                <h3 class="text-lg font-semibold mb-4">Filtrele</h3>
                
                <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Görünüm</label>
                        <select name="view" class="w-full border border-gray-300 rounded-lg px-3 py-2">
                            <option value="daily" <?php echo $viewType === 'daily' ? 'selected' : ''; ?>>Günlük</option>
                            <option value="monthly" <?php echo $viewType === 'monthly' ? 'selected' : ''; ?>>Aylık</option>
                        </select>
                    </div>
                    
                    <div id="date-filter" <?php echo $viewType !== 'daily' ? 'style="display:none"' : ''; ?>>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tarih</label>
                        <input type="date" name="date" value="<?php echo safe_html($dateFilter); ?>" 
                               class="w-full border border-gray-300 rounded-lg px-3 py-2">
                    </div>
                    
                    <div id="month-filter" <?php echo $viewType !== 'monthly' ? 'style="display:none"' : ''; ?>>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Ay</label>
                        <input type="month" name="month" value="<?php echo safe_html($monthFilter); ?>" 
                               class="w-full border border-gray-300 rounded-lg px-3 py-2">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Aktivite Tipi</label>
                        <select name="activity" class="w-full border border-gray-300 rounded-lg px-3 py-2">
                            <option value="">Tümü</option>
                            <option value="work_start" <?php echo $activityFilter === 'work_start' ? 'selected' : ''; ?>>İşe Başlama</option>
                            <option value="work_end" <?php echo $activityFilter === 'work_end' ? 'selected' : ''; ?>>İş Bitirme</option>
                            <option value="break_start" <?php echo $activityFilter === 'break_start' ? 'selected' : ''; ?>>Mola Başlama</option>
                            <option value="break_end" <?php echo $activityFilter === 'break_end' ? 'selected' : ''; ?>>Mola Bitirme</option>
                        </select>
                    </div>
                    
                    <div class="md:col-span-4">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors">
                            Filtrele
                        </button>
                        <a href="?" class="ml-2 bg-gray-300 hover:bg-gray-400 text-gray-700 px-6 py-2 rounded-lg transition-colors">
                            Temizle
                        </a>
                    </div>
                </form>
            </div>

            <!-- Summary Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-blue-100 p-3 rounded-full">
                            <span class="text-2xl">📊</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">Toplam Kayıt</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $summary['total_records']; ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-green-100 p-3 rounded-full">
                            <span class="text-2xl">📅</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">Çalışılan Gün</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $summary['days_worked']; ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-purple-100 p-3 rounded-full">
                            <span class="text-2xl">⏰</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">Giriş/Çıkış</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $summary['work_starts'] + $summary['work_ends']; ?></p>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center">
                        <div class="bg-yellow-100 p-3 rounded-full">
                            <span class="text-2xl">☕</span>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm text-gray-600">Mola</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo $summary['breaks']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Records Table -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900">
                        Detaylı Kayıtlar 
                        <span class="text-sm font-normal text-gray-600">
                            (<?php echo count($records); ?> kayıt gösteriliyor)
                        </span>
                    </h3>
                </div>

                <?php if (!empty($records)): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Tarih & Saat
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Aktivite
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Lokasyon
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Notlar
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($records as $record): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div>
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo $record['formatted_date']; ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo $record['formatted_time']; ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php
                                    $activityConfig = [
                                        'work_start' => ['icon' => '🟢', 'text' => 'İşe Başladı', 'class' => 'bg-green-100 text-green-800'],
                                        'work_end' => ['icon' => '🔴', 'text' => 'İşten Çıktı', 'class' => 'bg-red-100 text-red-800'],
                                        'work_in' => ['icon' => '🟢', 'text' => 'İşe Başladı', 'class' => 'bg-green-100 text-green-800'],      // Legacy support
                                        'work_out' => ['icon' => '🔴', 'text' => 'İşten Çıktı', 'class' => 'bg-red-100 text-red-800'],         // Legacy support
                                        'break_start' => ['icon' => '🟡', 'text' => 'Mola Başladı', 'class' => 'bg-yellow-100 text-yellow-800'],
                                        'break_end' => ['icon' => '🟢', 'text' => 'Moladan Döndü', 'class' => 'bg-green-100 text-green-800']
                                    ];
                                    
                                    $config = $activityConfig[$record['activity_type']] ?? ['icon' => '⚪', 'text' => $record['activity_type'], 'class' => 'bg-gray-100 text-gray-800'];
                                    ?>
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium <?php echo $config['class']; ?>">
                                        <?php echo $config['icon']; ?> <?php echo $config['text']; ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?php echo safe_html($record['location_name'] ?? 'Bilinmiyor'); ?>
                                    </div>
                                    <?php if ($record['gate_behavior']): ?>
                                    <div class="text-xs text-gray-500">
                                        <?php echo safe_html($record['gate_behavior']); ?>
                                    </div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm text-gray-900 max-w-xs truncate">
                                        <?php echo safe_html($record['notes'] ?? ''); ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <span class="text-6xl">📝</span>
                    <p class="mt-4 text-lg text-gray-600">Seçilen kriterlere uygun kayıt bulunamadı.</p>
                    <p class="mt-2 text-sm text-gray-500">Farklı filtreler deneyebilir veya yeni kayıt oluşturabilirsiniz.</p>
                    <a href="qr-attendance.php" class="mt-4 inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors">
                        Yeni Kayıt Oluştur
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <!-- Quick Actions -->
            <div class="mt-8 flex justify-center space-x-4">
                <a href="qr-attendance.php" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg transition-colors">
                    📱 QR Kod ile Kayıt
                </a>
                <a href="enhanced-dashboard.php" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-colors">
                    🏠 Dashboard'a Dön
                </a>
            </div>
        </div>
    </div>

    <script>
        // Toggle date/month filter based on view type
        document.querySelector('select[name="view"]').addEventListener('change', function() {
            const dateFilter = document.getElementById('date-filter');
            const monthFilter = document.getElementById('month-filter');
            
            if (this.value === 'daily') {
                dateFilter.style.display = 'block';
                monthFilter.style.display = 'none';
            } else {
                dateFilter.style.display = 'none';
                monthFilter.style.display = 'block';
            }
        });
    </script>
</body>
</html>