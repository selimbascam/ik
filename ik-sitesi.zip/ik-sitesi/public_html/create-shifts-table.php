<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Shifts Tablosu Oluşturma</h2>";
echo "<pre style='background: #f5f5f5; padding: 20px; border-radius: 5px; font-family: monospace;'>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check if shifts table exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'shifts'");
    $stmt->execute();
    $shiftsExists = $stmt->rowCount() > 0;
    
    if ($shiftsExists) {
        echo "✅ 'shifts' tablosu zaten mevcut!\n";
    } else {
        echo "🔧 'shifts' tablosu oluşturuluyor...\n";
        
        // Create shifts table
        $sql = "CREATE TABLE shifts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            company_id INT NOT NULL,
            name VARCHAR(100) NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            break_duration INT DEFAULT 60,
            day_of_week TINYINT DEFAULT NULL COMMENT '0=Sunday, 1=Monday, etc. NULL=All days',
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_company_id (company_id),
            INDEX idx_day_of_week (day_of_week),
            FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        
        $conn->exec($sql);
        echo "✅ 'shifts' tablosu başarıyla oluşturuldu!\n";
    }
    
    // Check if employee_shifts table exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'employee_shifts'");
    $stmt->execute();
    $employeeShiftsExists = $stmt->rowCount() > 0;
    
    if ($employeeShiftsExists) {
        echo "✅ 'employee_shifts' tablosu zaten mevcut!\n";
    } else {
        echo "🔧 'employee_shifts' tablosu oluşturuluyor...\n";
        
        // Create employee_shifts table
        $sql = "CREATE TABLE employee_shifts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT NOT NULL,
            shift_id INT NOT NULL,
            effective_date DATE NOT NULL,
            end_date DATE DEFAULT NULL,
            is_active TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_employee_id (employee_id),
            INDEX idx_shift_id (shift_id),
            INDEX idx_effective_date (effective_date),
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
            FOREIGN KEY (shift_id) REFERENCES shifts(id) ON DELETE CASCADE,
            UNIQUE KEY unique_employee_shift (employee_id, shift_id, effective_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        
        $conn->exec($sql);
        echo "✅ 'employee_shifts' tablosu başarıyla oluşturuldu!\n";
    }
    
    // Insert default shifts for existing companies
    $stmt = $conn->prepare("SELECT id, company_name FROM companies ORDER BY id");
    $stmt->execute();
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($companies as $company) {
        // Check if company already has shifts
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM shifts WHERE company_id = ?");
        $stmt->execute([$company['id']]);
        $shiftCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($shiftCount == 0) {
            echo "📅 '{$company['company_name']}' için varsayılan vardiya oluşturuluyor...\n";
            
            // Insert default day shift
            $stmt = $conn->prepare("
                INSERT INTO shifts (company_id, name, start_time, end_time, break_duration, day_of_week, is_active)
                VALUES (?, 'Gündüz Vardiyası', '09:00:00', '18:00:00', 60, NULL, 1)
            ");
            $stmt->execute([$company['id']]);
            echo "  ✅ Gündüz vardiyası eklendi (09:00-18:00)\n";
        } else {
            echo "📅 '{$company['company_name']}' zaten {$shiftCount} vardiyaya sahip\n";
        }
    }
    
    echo "\n🎉 Vardiya sistemi başarıyla kuruldu!\n";
    echo "\n📝 Notlar:\n";
    echo "- QR kod okuyucu artık shifts tablosunu kontrol edebilir\n";
    echo "- Varsayılan çalışma saatleri 09:00-18:00 olarak ayarlandı\n";
    echo "- Şirket yöneticileri vardiyaları yönetebilir\n";
    echo "- Personel atama sistemi hazır\n";
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString();
}
?>
</pre>

<hr>
<p><strong>Bu script ne yapar?</strong></p>
<ol>
    <li>shifts tablosunu oluşturur (yoksa)</li>
    <li>employee_shifts tablosunu oluşturur (yoksa)</li>
    <li>Mevcut şirketler için varsayılan vardiyalar ekler</li>
    <li>QR kod sisteminin düzgün çalışmasını sağlar</li>
</ol>

<p><a href="qr/qr-reader.php">← QR Kod Okuyucuya Dön</a></p>