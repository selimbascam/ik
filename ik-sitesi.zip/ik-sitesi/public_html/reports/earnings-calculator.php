<?php
header("Location: ../attendance/records.php");
exit;
?>