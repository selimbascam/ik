<?php
require_once '../includes/config.php';
require_once '../includes/database.php';

if (!isset($_SESSION['company_id']) && !isset($_SESSION['super_admin'])) {
    header('Location: ../auth/company-login.php');
    exit;
}

$company_id = $_SESSION['company_id'] ?? 1;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raporlar Dashboard - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <header class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 py-6">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Raporlar Dashboard</h1>
                    <a href="../dashboard/company-dashboard.php" class="text-blue-600 hover:text-blue-800">← Dashboard'a Dön</a>
                </div>
            </div>
        </header>

        <main class="max-w-7xl mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="text-center">
                        <div class="text-4xl mb-4">📊</div>
                        <h3 class="text-lg font-semibold mb-2">Devam Raporları</h3>
                        <p class="text-gray-600 mb-4">Günlük, haftalık ve aylık devam analizi</p>
                        <a href="index.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Görüntüle</a>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-6">
                    <div class="text-center">
                        <div class="text-4xl mb-4">💰</div>
                        <h3 class="text-lg font-semibold mb-2">Bordro Raporları</h3>
                        <p class="text-gray-600 mb-4">Maaş hesaplaması ve bordro analizi</p>
                        <a href="earnings-calculator.php" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Görüntüle</a>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow p-6">
                    <div class="text-center">
                        <div class="text-4xl mb-4">📱</div>
                        <h3 class="text-lg font-semibold mb-2">Cihaz Raporları</h3>
                        <p class="text-gray-600 mb-4">Cihaz kullanımı ve lokasyon analizi</p>
                        <a href="../view-device-records.php" class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">Görüntüle</a>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>