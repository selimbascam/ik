<?php
header("Location: ../admin/reports.php");
exit;
?>