<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Employee Password Column Fix</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h3>Step 1: Check Employees Table Structure</h3>";
    
    // Check current columns
    $columns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll();
    $columnNames = array_column($columns, 'Field');
    
    echo "<h4>Current Employee Table Columns:</h4>";
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    foreach ($columnNames as $col) {
        $color = in_array($col, ['password', 'employee_number']) ? 'green' : 'black';
        echo "<span style='background: #e9ecef; padding: 2px 8px; margin: 2px; border-radius: 3px; display: inline-block; color: {$color};'>{$col}</span> ";
    }
    echo "</div>";
    
    // Check if password column exists
    if (!in_array('password', $columnNames)) {
        echo "<p style='color: red; font-weight: bold;'>❌ CRITICAL: password column is missing!</p>";
        echo "<p>Adding password column now...</p>";
        
        try {
            $conn->exec("ALTER TABLE employees ADD COLUMN password VARCHAR(255) NULL AFTER employee_number");
            echo "<p style='color: green;'>✅ Password column added successfully</p>";
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Error adding password column: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color: green;'>✅ Password column exists</p>";
    }
    
    // Check if employee_number column exists
    if (!in_array('employee_number', $columnNames)) {
        echo "<p style='color: orange;'>⚠️ employee_number column missing. Adding it...</p>";
        try {
            $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE NULL AFTER id");
            echo "<p style='color: green;'>✅ Employee_number column added</p>";
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Error adding employee_number: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<h3>Step 2: Set Default Passwords for Existing Employees</h3>";
    
    // Get employees without passwords
    $stmt = $conn->query("SELECT id, first_name, last_name, employee_number FROM employees WHERE password IS NULL OR password = ''");
    $employeesWithoutPassword = $stmt->fetchAll();
    
    if (count($employeesWithoutPassword) > 0) {
        echo "<p>Setting default passwords for " . count($employeesWithoutPassword) . " employees...</p>";
        
        foreach ($employeesWithoutPassword as $emp) {
            // Generate employee number if missing
            $empNumber = $emp['employee_number'];
            if (empty($empNumber)) {
                $empNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
                $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?")->execute([$empNumber, $emp['id']]);
            }
            
            // Set default password (employee number or 123456)
            $defaultPassword = password_hash('123456', PASSWORD_DEFAULT);
            
            $stmt = $conn->prepare("UPDATE employees SET password = ? WHERE id = ?");
            $stmt->execute([$defaultPassword, $emp['id']]);
            
            echo "<p style='color: green;'>✅ {$emp['first_name']} {$emp['last_name']} (#{$empNumber}) - Default password: 123456</p>";
        }
    } else {
        echo "<p style='color: green;'>✅ All employees already have passwords</p>";
    }
    
    echo "<h3>Step 3: Test Employee Login Query</h3>";
    
    // Test the login query that was failing
    $testQuery = "
        SELECT id, first_name, last_name, employee_number, password, status
        FROM employees 
        WHERE employee_number = ? 
        AND (status IS NULL OR status = '' OR status = 'active')
        LIMIT 1
    ";
    
    try {
        $stmt = $conn->prepare($testQuery);
        $stmt->execute(['30716129672']); // Test with the employee number from screenshot
        $employee = $stmt->fetch();
        
        if ($employee) {
            echo "<p style='color: green; font-weight: bold;'>✅ SUCCESS! Employee login query works!</p>";
            echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<p><strong>Employee Found:</strong></p>";
            echo "<ul>";
            echo "<li><strong>Name:</strong> {$employee['first_name']} {$employee['last_name']}</li>";
            echo "<li><strong>Employee Number:</strong> {$employee['employee_number']}</li>";
            echo "<li><strong>Status:</strong> " . ($employee['status'] ?? 'active') . "</li>";
            echo "<li><strong>Password Set:</strong> " . (!empty($employee['password']) ? 'Yes' : 'No') . "</li>";
            echo "</ul>";
            echo "</div>";
            
            // Test password verification
            if (password_verify('123456', $employee['password'])) {
                echo "<p style='color: green;'>✅ Default password (123456) verification works</p>";
            } else {
                echo "<p style='color: orange;'>⚠️ Password verification failed - password may need to be reset</p>";
            }
            
        } else {
            echo "<p style='color: orange;'>⚠️ Employee with number 30716129672 not found</p>";
            
            // Show available employees
            $allEmployees = $conn->query("SELECT employee_number, first_name, last_name FROM employees LIMIT 5")->fetchAll();
            echo "<h4>Available Employees:</h4>";
            foreach ($allEmployees as $emp) {
                echo "<p>• {$emp['employee_number']} - {$emp['first_name']} {$emp['last_name']}</p>";
            }
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red; font-weight: bold;'>❌ FAILED: " . $e->getMessage() . "</p>";
    }
    
    echo "<h3>Step 4: Create Sample Employee for Testing</h3>";
    
    // Check if test employee exists
    $testEmployee = $conn->prepare("SELECT id FROM employees WHERE employee_number = ?");
    $testEmployee->execute(['30716129672']);
    
    if (!$testEmployee->fetch()) {
        echo "<p>Creating test employee with number 30716129672...</p>";
        
        try {
            // Check available columns for INSERT
            $insertColumns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll();
            $availableFields = array_column($insertColumns, 'Field');
            
            $insertFields = ['employee_number', 'first_name', 'last_name', 'password'];
            $insertValues = ['30716129672', 'Test', 'Personel', $hashedPassword];
            $insertPlaceholders = ['?', '?', '?', '?'];
            
            // Add optional fields if they exist
            if (in_array('status', $availableFields)) {
                $insertFields[] = 'status';
                $insertValues[] = 'active';
                $insertPlaceholders[] = '?';
            }
            
            if (in_array('company_id', $availableFields)) {
                $insertFields[] = 'company_id';
                $insertValues[] = 1;
                $insertPlaceholders[] = '?';
            }
            
            if (in_array('department_id', $availableFields)) {
                $insertFields[] = 'department_id';
                $insertValues[] = 1;
                $insertPlaceholders[] = '?';
            }
            
            if (in_array('monthly_salary', $availableFields)) {
                $insertFields[] = 'monthly_salary';
                $insertValues[] = 17000;
                $insertPlaceholders[] = '?';
            } elseif (in_array('wage_per_day', $availableFields)) {
                $insertFields[] = 'wage_per_day';
                $insertValues[] = 500;
                $insertPlaceholders[] = '?';
            }
            
            if (in_array('is_active', $availableFields)) {
                $insertFields[] = 'is_active';
                $insertValues[] = 1;
                $insertPlaceholders[] = '?';
            }
            
            $fieldsStr = implode(', ', $insertFields);
            $placeholdersStr = implode(', ', $insertPlaceholders);
            
            $stmt = $conn->prepare("INSERT INTO employees ({$fieldsStr}) VALUES ({$placeholdersStr})");
            
            $hashedPassword = password_hash('123456', PASSWORD_DEFAULT);
            $insertValues[3] = $hashedPassword; // Update password in values array
            $stmt->execute($insertValues);
            
            echo "<p style='color: green;'>✅ Test employee created successfully</p>";
            echo "<p><strong>Login Credentials:</strong></p>";
            echo "<ul>";
            echo "<li><strong>Employee Number:</strong> 30716129672</li>";
            echo "<li><strong>Password:</strong> 123456</li>";
            echo "</ul>";
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Error creating test employee: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color: green;'>✅ Test employee already exists</p>";
    }
    
    echo "<h3>Step 5: Final Verification</h3>";
    
    // Final structure check
    $finalColumns = $conn->query("SHOW COLUMNS FROM employees")->fetchAll();
    $finalColumnNames = array_column($finalColumns, 'Field');
    
    $criticalColumns = ['password', 'employee_number', 'status'];
    $allPresent = true;
    
    foreach ($criticalColumns as $col) {
        if (in_array($col, $finalColumnNames)) {
            echo "<p style='color: green;'>✅ {$col} column present</p>";
        } else {
            echo "<p style='color: red;'>❌ {$col} column missing</p>";
            $allPresent = false;
        }
    }
    
    if ($allPresent) {
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>🎉 SUCCESS! Employee login system fixed!</h4>";
        echo "<p><strong>The personnel login page should now work correctly!</strong></p>";
        echo "<p><strong>Default login credentials for testing:</strong></p>";
        echo "<ul>";
        echo "<li>Employee Number: 30716129672</li>";
        echo "<li>Password: 123456</li>";
        echo "</ul>";
        echo "<p>Test it here: <a href='auth/employee.php' target='_blank' style='color: #0066cc;'>Employee Login</a></p>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
        echo "<h4>❌ Some columns are still missing</h4>";
        echo "<p>Manual intervention may be required.</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red; font-weight: bold;'>❌ CRITICAL ERROR: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
    echo "<p>File: " . $e->getFile() . "</p>";
}

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3, h4 { color: #333; }
ul { margin: 10px 0; padding-left: 20px; }
</style>