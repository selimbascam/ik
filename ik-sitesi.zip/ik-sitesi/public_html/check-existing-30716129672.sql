-- Check what records exist with 30716129672
-- This will help us understand the conflict

-- Check by employee_number
SELECT id, employee_number, first_name, last_name, employee_code, password, status
FROM employees 
WHERE employee_number = '30716129672';

-- Check by employee_code
SELECT id, employee_number, first_name, last_name, employee_code, password, status
FROM employees 
WHERE employee_code = '30716129672';

-- Show all employees to see the pattern
SELECT id, employee_number, first_name, last_name, employee_code
FROM employees 
ORDER BY id;

-- Check for any NULL or empty employee_numbers
SELECT id, employee_number, first_name, last_name, employee_code
FROM employees 
WHERE employee_number IS NULL OR employee_number = ''
ORDER BY id;