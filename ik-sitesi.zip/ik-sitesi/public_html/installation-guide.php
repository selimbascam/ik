<?php
echo "<!DOCTYPE html>";
echo "<html lang='tr'>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>SZB İK Takip - Kurulum Rehberi</title>";
echo "<style>";
echo "body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 20px; background: #f8f9fa; }";
echo ".container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }";
echo ".step { background: #e3f2fd; border-left: 4px solid #2196f3; padding: 15px; margin: 15px 0; border-radius: 4px; }";
echo ".warning { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 15px 0; border-radius: 4px; }";
echo ".success { background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin: 15px 0; border-radius: 4px; }";
echo ".error { background: #f8d7da; border-left: 4px solid #dc3545; padding: 15px; margin: 15px 0; border-radius: 4px; }";
echo ".code { background: #f8f9fa; border: 1px solid #e9ecef; padding: 10px; border-radius: 4px; font-family: monospace; margin: 10px 0; }";
echo "table { width: 100%; border-collapse: collapse; margin: 15px 0; }";
echo "table, th, td { border: 1px solid #dee2e6; }";
echo "th, td { padding: 12px; text-align: left; }";
echo "th { background: #f8f9fa; font-weight: 600; }";
echo ".btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; margin: 5px; }";
echo ".btn:hover { background: #0056b3; }";
echo ".btn-success { background: #28a745; }";
echo ".btn-warning { background: #ffc107; color: #212529; }";
echo ".btn-danger { background: #dc3545; }";
echo "h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }";
echo "h2 { color: #34495e; margin-top: 30px; }";
echo "h3 { color: #5a6c7d; }";
echo "</style>";
echo "</head>";
echo "<body>";

echo "<div class='container'>";
echo "<h1>🛠️ SZB İK Takip - Veritabanı Kurulum Rehberi</h1>";
echo "<p><strong>Multi-tenant İnsan Kaynakları Yönetim Sistemi</strong></p>";
echo "<p>Güncellenme: " . date('d.m.Y H:i') . "</p>";

echo "<div class='warning'>";
echo "<h3>⚠️ Önemli Uyarı</h3>";
echo "<p>Bu kurulum tüm mevcut verileri silecektir. Yedek aldığınızdan emin olun!</p>";
echo "</div>";

echo "<h2>📋 1. Kurulum Öncesi Gereksinimler</h2>";
echo "<div class='step'>";
echo "<h4>✅ Sistem Gereksinimleri</h4>";
echo "<ul>";
echo "<li>MySQL 8.x veya MariaDB 10.x</li>";
echo "<li>PHP 7.4+ (PDO MySQL extension aktif)</li>";
echo "<li>Web server (Apache/Nginx)</li>";
echo "<li>En az 50MB disk alanı</li>";
echo "</ul>";
echo "</div>";

echo "<div class='step'>";
echo "<h4>🔐 Veritabanı İzinleri</h4>";
echo "<p>Kullanıcının aşağıdaki yetkilere sahip olması gerekir:</p>";
echo "<ul>";
echo "<li>CREATE - Tablo oluşturma</li>";
echo "<li>DROP - Tablo silme (temizlik için)</li>";
echo "<li>INSERT - Veri ekleme</li>";
echo "<li>SELECT - Veri okuma</li>";
echo "<li>ALTER - Tablo değiştirme</li>";
echo "</ul>";
echo "</div>";

echo "<h2>🎯 2. Kurulum Seçenekleri</h2>";

echo "<div class='success'>";
echo "<h3>🚀 Seçenek A: Otomatik Kurulum (Önerilen)</h3>";
echo "<p>Web arayüzü üzerinden tek tıkla kurulum:</p>";
echo "<p><a href='create-database.php' class='btn btn-success'>🔧 Otomatik Kurulum Başlat</a></p>";
echo "<p><small>Bu seçenek tüm tabloları oluşturur, ilişkileri kurar ve demo verileri ekler.</small></p>";
echo "</div>";

echo "<div class='step'>";
echo "<h3>⚙️ Seçenek B: Manuel Kurulum</h3>";
echo "<ol>";
echo "<li>MySQL client veya phpMyAdmin'e giriş yapın</li>";
echo "<li><code>mysql_schema_complete.sql</code> dosyasını çalıştırın</li>";
echo "<li>Hata kontrolü yapın</li>";
echo "<li>Sonuçları doğrulayın</li>";
echo "</ol>";
echo "</div>";

echo "<h2>📊 3. Tablo Oluşturma Sırası</h2>";
echo "<div class='step'>";
echo "<h4>🔄 Dependency Order (Bağımlılık Sırası)</h4>";
echo "<p>Tablolar foreign key ilişkilerine göre şu sırayla oluşturulur:</p>";

echo "<table>";
echo "<tr><th>Sıra</th><th>Tablo Adı</th><th>Açıklama</th><th>Bağımlılık</th></tr>";
$tables = [
    ['1', 'sessions', '🔐 PHP Session Yönetimi', 'Bağımsız'],
    ['2', 'companies', '🏢 Şirket Bilgileri', 'Bağımsız'],
    ['3', 'users', '👤 Kullanıcı Hesapları', 'companies'],
    ['4', 'departments', '🏬 Departmanlar', 'companies'],
    ['5', 'leave_types', '🏖️ İzin Türleri', 'companies'],
    ['6', 'shifts', '⏰ Vardiya Tanımları', 'companies'],
    ['7', 'qr_locations', '📍 QR Lokasyonları', 'companies'],
    ['8', 'attendance_activities', '⚡ Aktivite Türleri', 'companies'],
    ['9', 'employees', '👥 Çalışan Kayıtları', 'users, departments'],
    ['10', 'attendance_records', '📝 Devam Kayıtları', 'employees'],
    ['11', 'leave_requests', '📋 İzin Talepleri', 'employees'],
    ['12', 'employee_shifts', '📅 Vardiya Atamaları', 'employees'],
    ['13', 'employee_break_entitlements', '☕ Mola Hakları', 'employees'],
    ['14', 'employee_documents', '📄 Personel Belgeleri', 'employees'],
    ['15', 'employee_trainings', '🎓 Eğitim Kayıtları', 'employees'],
    ['16', 'garnishments', '⚖️ İcra Takipleri', 'employees']
];

foreach ($tables as $table) {
    echo "<tr>";
    echo "<td>{$table[0]}</td>";
    echo "<td><strong>{$table[1]}</strong></td>";
    echo "<td>{$table[2]}</td>";
    echo "<td><code>{$table[3]}</code></td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

echo "<h2>🎯 4. Varsayılan Veriler</h2>";
echo "<div class='step'>";
echo "<h4>👤 Test Hesapları</h4>";
echo "<table>";
echo "<tr><th>Hesap Türü</th><th>Email</th><th>Şifre</th><th>Erişim Yetkisi</th></tr>";
echo "<tr><td><strong>Super Admin</strong></td><td>super@admin.com</td><td>secret</td><td>Tüm şirketler</td></tr>";
echo "<tr><td><strong>Demo Admin</strong></td><td>admin@demo.com</td><td>demo123</td><td>Demo Şirketi (AAA00001)</td></tr>";
echo "</table>";
echo "</div>";

echo "<div class='step'>";
echo "<h4>🏢 Demo Şirket Verileri</h4>";
echo "<ul>";
echo "<li><strong>Şirket:</strong> Demo Şirketi (Kod: AAA00001)</li>";
echo "<li><strong>Departman:</strong> Genel Müdürlük</li>";
echo "<li><strong>Çalışanlar:</strong> Ahmet Yılmaz, Ayşe Kaya</li>";
echo "<li><strong>QR Lokasyon:</strong> Ana Ofis (GPS: İstanbul)</li>";
echo "<li><strong>Aktiviteler:</strong> 6 adet (İş başı/sonu, mola, yemek)</li>";
echo "<li><strong>İzin Türleri:</strong> 5 adet (Yıllık, hastalık, evlilik vs.)</li>";
echo "<li><strong>Vardiyalar:</strong> 3 adet (Gündüz, akşam, gece)</li>";
echo "</ul>";
echo "</div>";

echo "<h2>✅ 5. Kurulum Doğrulama</h2>";
echo "<div class='step'>";
echo "<h4>🔍 Otomatik Kontroller</h4>";
echo "<p>Kurulum sonrası şu kontrolleri yapın:</p>";
echo "<ol>";
echo "<li><a href='database-overview.php' class='btn'>📊 Veritabanı Durumu</a> - Tablo ve veri kontrolü</li>";
echo "<li><a href='super-admin/' class='btn'>👑 Super Admin Panel</a> - Yönetici girişi</li>";
echo "<li><a href='auth/company-login.php?demo=AAA00001' class='btn'>🏢 Demo Giriş</a> - Şirket paneli</li>";
echo "</ol>";
echo "</div>";

echo "<div class='code'>";
echo "<h4>📝 Manuel SQL Kontrolleri</h4>";
echo "<pre>";
echo "-- 1. Tablo sayısı kontrolü\n";
echo "SELECT COUNT(*) as table_count FROM information_schema.tables \n";
echo "WHERE table_schema = DATABASE();\n";
echo "-- Sonuç: 16 olmalı\n\n";

echo "-- 2. Demo veri kontrolü\n";
echo "SELECT COUNT(*) FROM companies; -- En az 1\n";
echo "SELECT COUNT(*) FROM users;     -- En az 2\n";
echo "SELECT COUNT(*) FROM employees; -- En az 2\n\n";

echo "-- 3. Foreign key kontrolü\n";
echo "SELECT COUNT(*) as fk_count FROM information_schema.KEY_COLUMN_USAGE\n";
echo "WHERE REFERENCED_TABLE_SCHEMA = DATABASE()\n";
echo "  AND REFERENCED_TABLE_NAME IS NOT NULL;\n";
echo "-- Sonuç: 15+ olmalı";
echo "</pre>";
echo "</div>";

echo "<h2>🔧 6. Sorun Giderme</h2>";

echo "<div class='error'>";
echo "<h4>❌ Yaygın Hatalar ve Çözümleri</h4>";
echo "<table>";
echo "<tr><th>Hata Mesajı</th><th>Sebep</th><th>Çözüm</th></tr>";
echo "<tr>";
echo "<td><code>Column 'company_code' doesn't exist</code></td>";
echo "<td>Eski tablo yapısı</td>";
echo "<td><a href='fix-database-now.php' class='btn btn-warning'>🔧 Onar</a></td>";
echo "</tr>";
echo "<tr>";
echo "<td><code>Access denied for user</code></td>";
echo "<td>Yanlış kimlik bilgileri</td>";
echo "<td>config.php dosyasını kontrol edin</td>";
echo "</tr>";
echo "<tr>";
echo "<td><code>Table already exists</code></td>";
echo "<td>Önceki kurulum</td>";
echo "<td>Normal durum, devam edin</td>";
echo "</tr>";
echo "<tr>";
echo "<td><code>Cannot add foreign key</code></td>";
echo "<td>Tablo sırası hatası</td>";
echo "<td>Tabloları sırayla oluşturun</td>";
echo "</tr>";
echo "</table>";
echo "</div>";

echo "<div class='warning'>";
echo "<h4>⚠️ Performans Uyarıları</h4>";
echo "<ul>";
echo "<li>İlk kurulumdan sonra indexlerin optimize edilmesi gerekebilir</li>";
echo "<li>Büyük veri setlerinde ANALYZE TABLE komutunu çalıştırın</li>";
echo "<li>Düzenli olarak OPTIMIZE TABLE yapın</li>";
echo "<li>Eski session kayıtlarını temizleyin</li>";
echo "</ul>";
echo "</div>";

echo "<h2>🚀 7. Kurulum Sonrası Adımlar</h2>";
echo "<div class='success'>";
echo "<h4>✅ Tamamlanması Gerekenler</h4>";
echo "<ol>";
echo "<li><strong>Super Admin Şifresi:</strong> Güvenlik için değiştirin</li>";
echo "<li><strong>İlk Şirket:</strong> Gerçek şirket bilgilerinizi ekleyin</li>";
echo "<li><strong>QR Kodları:</strong> İşyeri lokasyonlarını tanımlayın</li>";
echo "<li><strong>Çalışanlar:</strong> Personel bilgilerini sisteme girin</li>";
echo "<li><strong>Vardiyalar:</strong> Çalışma saatlerinizi ayarlayın</li>";
echo "<li><strong>Yedekleme:</strong> Düzenli yedek stratejisi oluşturun</li>";
echo "</ol>";
echo "</div>";

echo "<h2>📞 8. Destek ve Yardım</h2>";
echo "<div class='step'>";
echo "<h4>🆘 Yardım Kaynakları</h4>";
echo "<ul>";
echo "<li><a href='database-overview.php'>📊 Veritabanı Durumu</a> - Anlık sistem kontrolü</li>";
echo "<li><a href='test-db-structure.php'>🔍 Yapı Analizi</a> - Detaylı tablo incelemesi</li>";
echo "<li><a href='../database_installation_guide.md' target='_blank'>📖 Detaylı Dokümantasyon</a> - Teknik rehber</li>";
echo "<li><a href='../replit.md' target='_blank'>📋 Proje Dokümantasyonu</a> - Genel bilgiler</li>";
echo "</ul>";
echo "</div>";

echo "<hr>";
echo "<div class='text-center' style='text-align: center; margin: 30px 0;'>";
echo "<h3>🎯 Kuruluma Başlamaya Hazır mısınız?</h3>";
echo "<p style='margin: 20px 0;'>";
echo "<a href='create-database.php' class='btn btn-success' style='font-size: 16px; padding: 15px 30px;'>🚀 Kurulumu Başlat</a>";
echo "</p>";
echo "<p style='color: #666; font-size: 14px;'>Kurulum yaklaşık 30 saniye sürer</p>";
echo "</div>";

echo "<hr>";
echo "<p style='color: #666; font-size: 12px; text-align: center;'>";
echo "SZB İK Takip v1.0 - Multi-tenant HR Management System<br>";
echo "Son güncelleme: " . date('d.m.Y H:i') . " | Toplam 16 tablo | GPS + QR destekli";
echo "</p>";

echo "</div>";
echo "</body>";
echo "</html>";
?>