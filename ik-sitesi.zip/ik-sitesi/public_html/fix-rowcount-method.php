<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>🔧 Fix rowCount() Method</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Test if the fix works by checking column existence
    echo "<h3>🧪 Testing rowCount() Fix</h3>";
    
    $columnCheck = $conn->query("SHOW COLUMNS FROM employees LIKE 'employee_number'");
    $columnCount = $columnCheck->rowCount();
    
    if ($columnCount > 0) {
        echo "<p style='color: green;'>✅ employee_number column exists (rowCount: $columnCount)</p>";
    } else {
        echo "<p style='color: red;'>❌ employee_number column missing (rowCount: $columnCount)</p>";
        echo "<p style='color: blue;'>Adding employee_number column...</p>";
        
        // Add the column
        $conn->exec("ALTER TABLE employees ADD COLUMN employee_number VARCHAR(50) UNIQUE AFTER id");
        
        // Generate numbers for existing employees
        $existingEmps = $conn->query("SELECT id FROM employees WHERE employee_number IS NULL OR employee_number = ''");
        $empArray = $existingEmps->fetchAll();
        
        foreach ($empArray as $emp) {
            $empNumber = 'EMP' . str_pad($emp['id'], 4, '0', STR_PAD_LEFT);
            $updateStmt = $conn->prepare("UPDATE employees SET employee_number = ? WHERE id = ?");
            $updateStmt->execute([$empNumber, $emp['id']]);
        }
        
        echo "<p style='color: green;'>✅ Added employee_number column and generated numbers for " . count($empArray) . " employees</p>";
    }
    
    // Test monthly attendance tracking
    echo "<h3>📅 Testing Monthly Attendance Query</h3>";
    $testQuery = "
        SELECT 
            e.id,
            COALESCE(e.employee_number, CONCAT('EMP', LPAD(e.id, 4, '0'))) as employee_number,
            e.first_name,
            e.last_name
        FROM employees e 
        WHERE e.company_id = ? 
        LIMIT 3
    ";
    
    $stmt = $conn->prepare($testQuery);
    $stmt->execute([1]);
    $testEmployees = $stmt->fetchAll();
    
    echo "<p style='color: green;'>✅ Monthly attendance query test passed</p>";
    echo "<p>Found " . count($testEmployees) . " employees for testing</p>";
    
    if (count($testEmployees) > 0) {
        echo "<ul>";
        foreach ($testEmployees as $emp) {
            echo "<li>{$emp['employee_number']} - {$emp['first_name']} {$emp['last_name']}</li>";
        }
        echo "</ul>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Line: " . $e->getLine() . "</p>";
    echo "<p>File: " . $e->getFile() . "</p>";
}

echo "<h3>🔗 Test Attendance Tracking</h3>";
echo "<div>";
echo "<a href='admin/attendance-tracking.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Monthly Attendance</a>";
echo "<a href='admin/employee-attendance-list.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Daily Attendance</a>";
echo "<a href='admin/dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Dashboard</a>";
echo "</div>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
h2, h3 { color: #333; }
</style>