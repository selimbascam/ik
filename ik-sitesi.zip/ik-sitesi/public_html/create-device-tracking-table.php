<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h2>Device Tracking Table Creation</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Create device_records table
    $sql = "CREATE TABLE IF NOT EXISTS device_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT,
        session_id VARCHAR(100),
        device_fingerprint VARCHAR(255),
        ip_address VARCHAR(45),
        mac_address VARCHAR(17),
        user_agent TEXT,
        device_type VARCHAR(50),
        browser_name VARCHAR(50),
        operating_system VARCHAR(50),
        screen_resolution VARCHAR(20),
        timezone_offset INT,
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        location_accuracy DECIMAL(10, 2),
        location_timestamp TIMESTAMP,
        qr_location_id INT,
        action_type ENUM('checkin', 'checkout', 'break_start', 'break_end') NOT NULL,
        success BOOLEAN DEFAULT TRUE,
        error_message TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL,
        FOREIGN KEY (qr_location_id) REFERENCES qr_locations(id) ON DELETE SET NULL,
        INDEX idx_employee_date (employee_id, created_at),
        INDEX idx_ip_address (ip_address),
        INDEX idx_device_fingerprint (device_fingerprint)
    )";
    $conn->exec($sql);
    echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ device_records table created/verified";
    echo "</div>";
    
    // Create employee_devices table for device-employee relationships
    $sql = "CREATE TABLE IF NOT EXISTS employee_devices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT NOT NULL,
        device_fingerprint VARCHAR(255) NOT NULL,
        device_name VARCHAR(100),
        device_type VARCHAR(50),
        first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        is_trusted BOOLEAN DEFAULT FALSE,
        is_blocked BOOLEAN DEFAULT FALSE,
        usage_count INT DEFAULT 1,
        notes TEXT,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
        UNIQUE KEY unique_device_employee (employee_id, device_fingerprint),
        INDEX idx_device_fingerprint (device_fingerprint)
    )";
    $conn->exec($sql);
    echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ employee_devices table created/verified";
    echo "</div>";
    
    // Create device_security_logs table for security events
    $sql = "CREATE TABLE IF NOT EXISTS device_security_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        company_id INT NOT NULL,
        employee_id INT,
        device_fingerprint VARCHAR(255),
        ip_address VARCHAR(45),
        event_type ENUM('new_device', 'suspicious_location', 'multiple_devices', 'blocked_device', 'trusted_device') NOT NULL,
        severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
        description TEXT,
        metadata JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL,
        INDEX idx_severity_date (severity, created_at),
        INDEX idx_employee_event (employee_id, event_type)
    )";
    $conn->exec($sql);
    echo "<div style='color: #155724; background: #d4edda; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "✅ device_security_logs table created/verified";
    echo "</div>";
    
    echo "<h3>Device Tracking System Ready!</h3>";
    echo "<p>All device tracking tables have been created successfully.</p>";
    
    echo "<h4>Features Enabled:</h4>";
    echo "<ul style='margin-left: 20px;'>";
    echo "<li>📱 Device fingerprinting and identification</li>";
    echo "<li>🌍 GPS location tracking with accuracy</li>";
    echo "<li>🔍 IP address and MAC address logging</li>";
    echo "<li>🔒 Employee-device relationship management</li>";
    echo "<li>⚠️ Security event logging and alerts</li>";
    echo "<li>📊 Device usage analytics</li>";
    echo "</ul>";
    
} catch (Exception $e) {
    echo "<div style='color: #721c24; background: #f8d7da; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "❌ Error: " . htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo "<br><a href='admin/device-management.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Device Management</a>";
echo " <a href='view-device-records.php' style='background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 10px;'>View Device Records</a>";
echo " <a href='dashboard/company-dashboard.php' style='background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-left: 10px;'>Dashboard</a>";
?>