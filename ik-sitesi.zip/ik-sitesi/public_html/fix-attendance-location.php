<?php
// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Set HTTP headers for clean output
header('Content-Type: text/html; charset=UTF-8');

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Attendance Location Column</title>
    <style>
        body {
            font-family: monospace;
            background: #f0f0f0;
            margin: 20px;
            line-height: 1.6;
        }
        .success { color: green; }
        .error { color: red; }
        .info { color: blue; }
        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
<div class="container">
<h1>🔧 Attendance Records Location Column Fixer</h1>
<pre>
<?php
// Include files after headers are sent
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/database.php';

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<span class='success'>✅ Connected to MySQL database successfully!</span>\n\n";
    
    // Check current table structure
    echo "<span class='info'>📋 Checking attendance_records table structure...</span>\n";
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasLocation = false;
    echo "Current columns:\n";
    foreach ($columns as $column) {
        echo "  - " . $column['Field'] . " (" . $column['Type'] . ")";
        if ($column['Field'] === 'location') {
            $hasLocation = true;
            echo " <span class='success'>✓</span>";
        }
        echo "\n";
    }
    
    echo "\n";
    
    if (!$hasLocation) {
        echo "<span class='error'>❌ 'location' column is missing!</span>\n";
        echo "<span class='info'>➕ Adding 'location' column now...</span>\n";
        
        try {
            // Add location column
            $conn->exec("ALTER TABLE attendance_records ADD COLUMN location VARCHAR(255) DEFAULT NULL AFTER date");
            echo "<span class='success'>✅ 'location' column added successfully!</span>\n";
            
            // Verify addition
            echo "\n<span class='info'>🔍 Verifying column addition...</span>\n";
            $stmt = $conn->query("SHOW COLUMNS FROM attendance_records LIKE 'location'");
            $column = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($column) {
                echo "<span class='success'>✅ 'location' column confirmed: " . $column['Type'] . "</span>\n";
            }
        } catch (Exception $e) {
            echo "<span class='error'>❌ Failed to add column: " . $e->getMessage() . "</span>\n";
        }
    } else {
        echo "<span class='success'>✅ 'location' column already exists!</span>\n";
    }
    
    // Test insert
    echo "\n<span class='info'>🧪 Testing INSERT with location column...</span>\n";
    $testId = 99999;
    
    try {
        // Delete test record if exists
        $conn->exec("DELETE FROM attendance_records WHERE employee_id = $testId");
        
        // Try insert
        $stmt = $conn->prepare("INSERT INTO attendance_records (employee_id, date, location, device_user_agent, created_at) VALUES (?, ?, ?, ?, NOW())");
        $success = $stmt->execute([$testId, date('Y-m-d'), 'Test Location', 'Test Agent']);
        
        if ($success) {
            echo "<span class='success'>✅ Test INSERT successful! The 'location' column is working correctly.</span>\n";
            // Clean up test record
            $conn->exec("DELETE FROM attendance_records WHERE employee_id = $testId");
            echo "<span class='info'>🧹 Test record cleaned up.</span>\n";
            
            echo "\n<span class='success'>✅ ALL TESTS PASSED! You can now use the QR code reader without errors.</span>\n";
        } else {
            echo "<span class='error'>❌ Test INSERT failed!</span>\n";
        }
    } catch (Exception $e) {
        echo "<span class='error'>❌ Test failed: " . $e->getMessage() . "</span>\n";
    }
    
} catch (Exception $e) {
    echo "<span class='error'>❌ Database connection error: " . $e->getMessage() . "</span>\n";
    echo "Stack trace:\n" . $e->getTraceAsString();
}
?>
</pre>

<hr>
<p><strong>What does this script do?</strong></p>
<ol>
    <li>Connects to your MySQL database</li>
    <li>Checks if the 'location' column exists in attendance_records table</li>
    <li>If missing, adds the column automatically</li>
    <li>Tests that the column works correctly</li>
</ol>
<p><a href="/index.php">← Back to Home</a></p>
</div>
</body>
</html>