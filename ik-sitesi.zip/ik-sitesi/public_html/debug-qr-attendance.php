<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>🔍 QR Attendance Debug & Test</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;background:#f8f9fa;}h1,h2,h3{color:#333;}pre{background:#1e293b;color:#f3f4f6;padding:15px;border-radius:8px;overflow-x:auto;}.success{color:#22c55e;}.error{color:#ef4444;}.warning{color:#f59e0b;}.info{color:#3b82f6;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    echo "<h2>📊 Database Connection Status</h2>";
    echo "<p class='success'>✅ Database connection successful</p>";
    
    // Test employee data
    echo "<h2>👤 Test Employee Data</h2>";
    $stmt = $conn->prepare("SELECT id, employee_number, first_name, last_name, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<p class='success'>✅ Test employee found:</p>";
        echo "<pre>" . json_encode($employee, JSON_PRETTY_PRINT) . "</pre>";
        $test_employee_id = $employee['id'];
        $test_company_id = $employee['company_id'];
    } else {
        echo "<p class='error'>❌ Test employee not found</p>";
        exit;
    }
    
    // Check attendance_records table structure
    echo "<h2>🗃️ Attendance Records Table Structure</h2>";
    $stmt = $conn->query("SHOW COLUMNS FROM attendance_records");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasCompanyId = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'company_id') {
            $hasCompanyId = true;
            echo "<p class='success'>✅ company_id column exists: " . $column['Type'] . " " . $column['Null'] . " " . $column['Key'] . "</p>";
        }
    }
    
    if (!$hasCompanyId) {
        echo "<p class='error'>❌ company_id column missing in attendance_records table</p>";
    }
    
    // Check foreign key constraints
    echo "<h2>🔗 Foreign Key Constraints</h2>";
    $stmt = $conn->query("
        SELECT 
            CONSTRAINT_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE 
        WHERE TABLE_NAME = 'attendance_records' 
        AND REFERENCED_TABLE_NAME IS NOT NULL
        AND TABLE_SCHEMA = DATABASE()
    ");
    $fks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($fks) {
        echo "<p class='success'>✅ Foreign key constraints found:</p>";
        echo "<pre>" . json_encode($fks, JSON_PRETTY_PRINT) . "</pre>";
    } else {
        echo "<p class='warning'>⚠️ No foreign key constraints found</p>";
    }
    
    // Test QR location
    echo "<h2>📍 Test QR Location</h2>";
    $stmt = $conn->prepare("SELECT * FROM qr_locations WHERE company_id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$test_company_id]);
    $qr_location = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($qr_location) {
        echo "<p class='success'>✅ Test QR location found:</p>";
        echo "<pre>" . json_encode($qr_location, JSON_PRETTY_PRINT) . "</pre>";
        $test_qr_location_id = $qr_location['id'];
    } else {
        echo "<p class='warning'>⚠️ No active QR locations found for company</p>";
        $test_qr_location_id = null;
    }
    
    // Test INSERT operation
    echo "<h2>🧪 Test Attendance Record INSERT</h2>";
    
    try {
        $conn->beginTransaction();
        
        $test_data = [
            'company_id' => $test_company_id,
            'employee_id' => $test_employee_id,
            'qr_location_id' => $test_qr_location_id,
            'activity_type' => 'debug_test',
            'check_in_time' => date('Y-m-d H:i:s'),
            'date' => date('Y-m-d'),
            'latitude' => '40.7128',
            'longitude' => '-74.0060',
            'notes' => 'Debug test record',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        echo "<p class='info'>🔄 Attempting INSERT with data:</p>";
        echo "<pre>" . json_encode($test_data, JSON_PRETTY_PRINT) . "</pre>";
        
        $stmt = $conn->prepare("
            INSERT INTO attendance_records (
                company_id, employee_id, qr_location_id, activity_type, 
                check_in_time, date, latitude, longitude, notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            $test_data['company_id'],
            $test_data['employee_id'],
            $test_data['qr_location_id'],
            $test_data['activity_type'],
            $test_data['check_in_time'],
            $test_data['date'],
            $test_data['latitude'],
            $test_data['longitude'],
            $test_data['notes'],
            $test_data['created_at']
        ]);
        
        if ($result) {
            $insertId = $conn->lastInsertId();
            echo "<p class='success'>✅ INSERT successful! Record ID: $insertId</p>";
            
            // Verify the record
            $stmt = $conn->prepare("SELECT * FROM attendance_records WHERE id = ?");
            $stmt->execute([$insertId]);
            $inserted_record = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo "<p class='success'>✅ Inserted record verified:</p>";
            echo "<pre>" . json_encode($inserted_record, JSON_PRETTY_PRINT) . "</pre>";
            
            // Clean up
            $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
            $stmt->execute([$insertId]);
            echo "<p class='info'>🧹 Test record cleaned up</p>";
        } else {
            echo "<p class='error'>❌ INSERT failed</p>";
        }
        
        $conn->commit();
        
    } catch (Exception $e) {
        $conn->rollback();
        echo "<p class='error'>❌ INSERT Error: " . $e->getMessage() . "</p>";
        
        // Check for specific foreign key error
        if (strpos($e->getMessage(), 'foreign key constraint') !== false) {
            echo "<h3>🔍 Foreign Key Constraint Analysis</h3>";
            
            // Check if company exists
            $stmt = $conn->prepare("SELECT id FROM companies WHERE id = ?");
            $stmt->execute([$test_company_id]);
            $company_exists = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company_exists) {
                echo "<p class='success'>✅ Company ID $test_company_id exists in companies table</p>";
            } else {
                echo "<p class='error'>❌ Company ID $test_company_id does NOT exist in companies table</p>";
            }
            
            // Check QR location company_id
            if ($test_qr_location_id) {
                $stmt = $conn->prepare("SELECT company_id FROM qr_locations WHERE id = ?");
                $stmt->execute([$test_qr_location_id]);
                $qr_company = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($qr_company && $qr_company['company_id'] == $test_company_id) {
                    echo "<p class='success'>✅ QR location company_id matches</p>";
                } else {
                    echo "<p class='error'>❌ QR location company_id mismatch</p>";
                }
            }
        }
    }
    
    // Simulate real QR process
    echo "<h2>🎯 Simulate Real QR Process</h2>";
    
    // Set session like employee login
    $_SESSION['employee_id'] = $test_employee_id;
    echo "<p class='info'>📝 Set session employee_id: $test_employee_id</p>";
    
    // Simulate QR data
    $qr_data = [
        'location_id' => $test_qr_location_id,
        'latitude' => '40.7128',
        'longitude' => '-74.0060'
    ];
    
    echo "<p class='info'>📱 Simulating QR scan data:</p>";
    echo "<pre>" . json_encode($qr_data, JSON_PRETTY_PRINT) . "</pre>";
    
    // Test the actual process-attendance.php logic
    echo "<h3>🔄 Testing process-attendance.php Logic</h3>";
    
    $employee_id = $_SESSION['employee_id'];
    $activity_type = 'work_in';
    $qr_location_id = $qr_data['location_id'];
    $latitude = $qr_data['latitude'];
    $longitude = $qr_data['longitude'];
    
    try {
        // Get employee company_id (from process-attendance.php logic)
        $stmt = $conn->prepare("SELECT company_id FROM employees WHERE id = ?");
        $stmt->execute([$employee_id]);
        $emp = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$emp) {
            throw new Exception('Employee not found');
        }
        
        $company_id = $emp['company_id'];
        echo "<p class='success'>✅ Retrieved company_id: $company_id</p>";
        
        // Test the exact INSERT from process-attendance.php
        $currentDateTime = date('Y-m-d H:i:s');
        
        $stmt = $conn->prepare("
            INSERT INTO attendance_records (
                company_id, employee_id, qr_location_id, activity_type, check_in_time, 
                date, latitude, longitude, notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $insert_result = $stmt->execute([
            $company_id,
            $employee_id,
            $qr_location_id,
            $activity_type,
            $currentDateTime,
            date('Y-m-d'),
            $latitude,
            $longitude,
            'QR kod ile kayıt',
            $currentDateTime
        ]);
        
        if ($insert_result) {
            $recordId = $conn->lastInsertId();
            echo "<p class='success'>✅ Real QR process simulation SUCCESS! Record ID: $recordId</p>";
            
            // Clean up
            $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
            $stmt->execute([$recordId]);
            echo "<p class='info'>🧹 Simulation record cleaned up</p>";
        }
        
    } catch (Exception $e) {
        echo "<p class='error'>❌ Real QR process simulation FAILED: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p class='error'>❌ Database connection failed: " . $e->getMessage() . "</p>";
}

echo "<h2>🎯 Summary</h2>";
echo "<div style='background:#e3f2fd;padding:15px;border-radius:8px;margin:20px 0;'>";
echo "<p>This debug script tests the exact QR attendance flow to identify foreign key constraint issues.</p>";
echo "<p>If you see any ❌ errors above, those need to be fixed for QR attendance to work properly.</p>";
echo "</div>";
?>