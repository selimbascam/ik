<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

echo "<h1>Employee Debug - QR Attendance Fix</h1>";
echo "<style>body{font-family:Arial,sans-serif;margin:20px;line-height:1.6;}h1,h2{color:#333;}.success{color:#22c55e;font-weight:bold;}.error{color:#ef4444;font-weight:bold;}.info{color:#3b82f6;font-weight:bold;}.warning{color:#f59e0b;font-weight:bold;}</style>";

try {
    $db = new Database();
    $conn = $db->getConnection();
    
    // Check test employee
    echo "<h2>Employee Status Check</h2>";
    $stmt = $conn->prepare("SELECT id, employee_number, first_name, last_name, company_id FROM employees WHERE employee_number = ?");
    $stmt->execute(['30716129672']);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($employee) {
        echo "<p class='success'>Employee found: {$employee['first_name']} {$employee['last_name']}</p>";
        echo "<p>Employee ID: {$employee['id']}</p>";
        echo "<p>Employee Number: {$employee['employee_number']}</p>";
        echo "<p>Company ID: " . ($employee['company_id'] ? $employee['company_id'] : 'NULL') . "</p>";
        
        if ($employee['company_id']) {
            // Check if company exists
            $stmt = $conn->prepare("SELECT id, company_name FROM companies WHERE id = ?");
            $stmt->execute([$employee['company_id']]);
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($company) {
                echo "<p class='success'>Company exists: {$company['company_name']} (ID: {$company['id']})</p>";
                
                // Check QR locations for this company
                $stmt = $conn->prepare("SELECT id, name FROM qr_locations WHERE company_id = ? AND is_active = 1");
                $stmt->execute([$employee['company_id']]);
                $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo "<p class='info'>QR Locations for this company: " . count($locations) . "</p>";
                foreach ($locations as $location) {
                    echo "<p>- {$location['name']} (ID: {$location['id']})</p>";
                }
                
            } else {
                echo "<p class='error'>PROBLEM: Company ID {$employee['company_id']} does NOT exist in companies table!</p>";
                
                // List available companies
                $stmt = $conn->prepare("SELECT id, company_name FROM companies LIMIT 5");
                $stmt->execute();
                $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo "<p class='info'>Available companies:</p>";
                foreach ($companies as $comp) {
                    echo "<p>- {$comp['company_name']} (ID: {$comp['id']})</p>";
                }
                
                // Fix by assigning to first available company
                if ($companies) {
                    $firstCompanyId = $companies[0]['id'];
                    $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
                    $stmt->execute([$firstCompanyId, $employee['id']]);
                    echo "<p class='success'>FIXED: Employee assigned to company ID: {$firstCompanyId}</p>";
                    
                    // Update our local variable
                    $employee['company_id'] = $firstCompanyId;
                    
                    // Create QR location if needed
                    $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = ?");
                    $stmt->execute([$firstCompanyId]);
                    $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$qrLocation) {
                        $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
                        $stmt->execute([
                            $firstCompanyId,
                            'Debug Fix - Main Entrance',
                            'Auto-created during debug fix',
                            '41.0082',
                            '28.9784',
                            'entrance',
                            1
                        ]);
                        echo "<p class='success'>QR Location created for company</p>";
                    }
                }
            }
        } else {
            echo "<p class='error'>PROBLEM: Employee has NULL company_id!</p>";
            
            // Get first available company
            $stmt = $conn->prepare("SELECT id, company_name FROM companies LIMIT 1");
            $stmt->execute();
            $firstCompany = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$firstCompany) {
                // Create a company
                $stmt = $conn->prepare("INSERT INTO companies (company_name, email, phone, address, created_at) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute(['Debug Fix Company', 'admin@debug.com', '555-DEBUG', 'Auto-created for debug fix']);
                $companyId = $conn->lastInsertId();
                echo "<p class='success'>Company created with ID: {$companyId}</p>";
            } else {
                $companyId = $firstCompany['id'];
                echo "<p class='info'>Using existing company: {$firstCompany['company_name']} (ID: {$companyId})</p>";
            }
            
            // Update employee
            $stmt = $conn->prepare("UPDATE employees SET company_id = ? WHERE id = ?");
            $stmt->execute([$companyId, $employee['id']]);
            echo "<p class='success'>FIXED: Employee assigned to company ID: {$companyId}</p>";
            
            // Update our local variable
            $employee['company_id'] = $companyId;
            
            // Create QR location
            $stmt = $conn->prepare("INSERT INTO qr_locations (company_id, name, description, latitude, longitude, location_type, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $companyId,
                'Debug Fix - Main Entrance',
                'Auto-created during debug fix',
                '41.0082',
                '28.9784',
                'entrance',
                1
            ]);
            echo "<p class='success'>QR Location created for company</p>";
        }
        
        // Final test - try to insert attendance record
        echo "<h2>Final Test - Attendance Insert</h2>";
        try {
            $currentDateTime = date('Y-m-d H:i:s');
            
            // Get a QR location for this company
            $stmt = $conn->prepare("SELECT id FROM qr_locations WHERE company_id = ? AND is_active = 1 LIMIT 1");
            $stmt->execute([$employee['company_id']]);
            $qrLocation = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$qrLocation) {
                throw new Exception("No QR location found for company");
            }
            
            echo "<p class='info'>Using QR Location ID: {$qrLocation['id']}</p>";
            echo "<p class='info'>Using Company ID: {$employee['company_id']}</p>";
            echo "<p class='info'>Using Employee ID: {$employee['id']}</p>";
            
            $stmt = $conn->prepare("
                INSERT INTO attendance_records 
                (company_id, employee_id, qr_location_id, activity_type, check_in_time, date, notes, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $result = $stmt->execute([
                $employee['company_id'],
                $employee['id'],
                $qrLocation['id'],
                'work_in',
                $currentDateTime,
                date('Y-m-d'),
                'Debug test - ' . date('H:i:s'),
                $currentDateTime
            ]);
            
            if ($result) {
                $recordId = $conn->lastInsertId();
                echo "<p class='success'>SUCCESS! Test attendance record created with ID: {$recordId}</p>";
                
                echo "<div style='background:#e8f5e8;padding:20px;border-radius:8px;margin:20px 0;'>";
                echo "<h3 style='color:#2e7d32;'>QR ATTENDANCE SYSTEM FIXED!</h3>";
                echo "<p>Foreign key constraint errors resolved.</p>";
                echo "<p><strong>Test QR attendance now with employee login: 30716129672 / 123456</strong></p>";
                echo "</div>";
                
                // Clean up test record
                $stmt = $conn->prepare("DELETE FROM attendance_records WHERE id = ?");
                $stmt->execute([$recordId]);
                echo "<p class='info'>Test record cleaned up</p>";
                
            } else {
                echo "<p class='error'>Insert failed but no exception thrown</p>";
            }
            
        } catch (Exception $e) {
            echo "<p class='error'>INSERT FAILED: " . $e->getMessage() . "</p>";
            
            // Additional diagnostics
            echo "<h3>Diagnostic Information:</h3>";
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM employees WHERE id = ?");
            $stmt->execute([$employee['id']]);
            $empCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p>Employee exists: " . ($empCount ? 'Yes' : 'No') . "</p>";
            
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM companies WHERE id = ?");
            $stmt->execute([$employee['company_id']]);
            $compCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            echo "<p>Company exists: " . ($compCount ? 'Yes' : 'No') . "</p>";
            
            if (isset($qrLocation)) {
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM qr_locations WHERE id = ?");
                $stmt->execute([$qrLocation['id']]);
                $locCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                echo "<p>QR Location exists: " . ($locCount ? 'Yes' : 'No') . "</p>";
            }
        }
        
    } else {
        echo "<p class='error'>Employee 30716129672 not found!</p>";
        
        // List available employees
        echo "<h3>Available employees:</h3>";
        $stmt = $conn->prepare("SELECT employee_number, first_name, last_name, company_id FROM employees LIMIT 5");
        $stmt->execute();
        $employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($employees as $emp) {
            echo "<p>{$emp['employee_number']} - {$emp['first_name']} {$emp['last_name']} (Company: {$emp['company_id']})</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p class='error'>Database error: " . $e->getMessage() . "</p>";
}

echo "<p><strong>Debug complete. Test QR attendance after this fix.</strong></p>";
?>